opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ADC_Sample
	FNCALL	_main,_Init_System
	FNCALL	_main,___lldiv
	FNCALL	_main,___lmul
	FNCALL	_main,___lwdiv
	FNCALL	_main,___lwmod
	FNCALL	_main,_sw_uart_init
	FNCALL	_main,_uart_send_number
	FNCALL	_main,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNROOT	_main
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_bx_ch
psect	strings,class=STRING,delta=2,noexec
global __pstrings
__pstrings:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 1 byte each
stringcode:stringdir:
movlw high(stringdir)
movwf pclath
movf fsr,w
incf fsr
	addwf pc
	global __stringbase
__stringbase:
	retlw	0
psect	strings
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	32
_bx_ch:
	retlw	011h
	retlw	010h
	retlw	07h
	retlw	05h
	retlw	06h
	retlw	04h
	retlw	0Dh
	retlw	0Ch
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	global __end_of_bx_ch
__end_of_bx_ch:
	global	_bx_ch
	global	_test_adc
	global	_adresult
	global	_OSCCON
_OSCCON	set	20
	global	_T2CON
_T2CON	set	19
	global	_PR2
_PR2	set	17
	global	_INTCON
_INTCON	set	11
	global	_WPUB
_WPUB	set	8
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_TMR2IE
_TMR2IE	set	0x71
	global	_TMR2IF
_TMR2IF	set	0x69
	global	_GIE
_GIE	set	0x5F
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_WPUA
_WPUA	set	136
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_GODONE
_GODONE	set	0x4A9
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RC4
_RC4	set	0x834
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_1:	
	retlw	66	;'B'
	retlw	49	;'1'
	retlw	45	;'-'
	retlw	66	;'B'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	32	;' '
	retlw	65	;'A'
	retlw	68	;'D'
	retlw	67	;'C'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	101	;'e'
	retlw	115	;'s'
	retlw	116	;'t'
	retlw	13
	retlw	10
	retlw	0
psect	strings
	
STR_3:	
	retlw	61	;'='
	retlw	52	;'4'
	retlw	48	;'0'
	retlw	57	;'9'
	retlw	53	;'5'
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	strings
	
STR_42:	
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	83	;'S'
	retlw	72	;'H'
	retlw	79	;'O'
	retlw	82	;'R'
	retlw	84	;'T'
	retlw	0
psect	strings
	
STR_47:	
	retlw	13
	retlw	10
	retlw	32	;' '
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_43:	
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	strings
	
STR_6:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	strings
	
STR_41:	
	retlw	32	;' '
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_48:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	13
	retlw	10
	retlw	0
psect	strings
	
STR_16:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	32	;' '
	retlw	0
psect	strings
	
STR_21:	
	retlw	13
	retlw	10
	retlw	32	;' '
	retlw	0
psect	strings
	
STR_7:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	strings
	
STR_44:	
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_10:	
	retlw	32	;' '
	retlw	63	;'?'
	retlw	91	;'['
	retlw	0
psect	strings
	
STR_45:	
	retlw	46	;'.'
	retlw	0
psect	strings
	
STR_2:	
	retlw	66	;'B'
	retlw	0
psect	strings
	
STR_46:	
	retlw	67	;'C'
	retlw	0
psect	strings
STR_19	equ	STR_10+0
STR_30	equ	STR_10+0
STR_39	equ	STR_10+0
STR_23	equ	STR_3+0
STR_4	equ	STR_2+0
STR_8	equ	STR_2+0
STR_13	equ	STR_2+0
STR_17	equ	STR_2+0
STR_22	equ	STR_2+0
STR_24	equ	STR_2+0
STR_28	equ	STR_2+0
STR_33	equ	STR_2+0
STR_37	equ	STR_2+0
STR_5	equ	STR_47+6
STR_9	equ	STR_47+6
STR_14	equ	STR_47+6
STR_18	equ	STR_47+6
STR_25	equ	STR_47+6
STR_29	equ	STR_47+6
STR_34	equ	STR_47+6
STR_38	equ	STR_47+6
STR_11	equ	STR_7+0
STR_15	equ	STR_6+0
STR_26	equ	STR_6+0
STR_35	equ	STR_6+0
STR_20	equ	STR_16+0
STR_27	equ	STR_16+0
STR_31	equ	STR_16+0
STR_36	equ	STR_16+0
STR_40	equ	STR_16+0
STR_12	equ	STR_21+2
STR_32	equ	STR_21+2
; #config settings
	file	"SC8F096_ADC_Demo.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_test_adc:
       ds      1

_adresult:
       ds      2

	file	"SC8F096_ADC_Demo.as"
	line	#
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	((__pbssBANK0)+0)&07Fh
	clrf	((__pbssBANK0)+1)&07Fh
	clrf	((__pbssBANK0)+2)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_Init_System:	; 1 bytes @ 0x0
?_sw_uart_init:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_uart_send_string:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
??_Isr_Timer:	; 1 bytes @ 0x0
	ds	2
??_Init_System:	; 1 bytes @ 0x2
?_ADC_Sample:	; 1 bytes @ 0x2
??_sw_uart_init:	; 1 bytes @ 0x2
??_uart_send_char:	; 1 bytes @ 0x2
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x2
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x2
	global	?___lmul
?___lmul:	; 4 bytes @ 0x2
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x2
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x2
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x2
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x2
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x3
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x3
	ds	1
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x4
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x4
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x4
	ds	1
??_uart_send_string:	; 1 bytes @ 0x5
	global	uart_send_string@str
uart_send_string@str:	; 1 bytes @ 0x5
	ds	1
??___lwdiv:	; 1 bytes @ 0x6
??___lwmod:	; 1 bytes @ 0x6
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x6
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x6
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x6
	ds	2
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x8
	ds	1
?_uart_send_number:	; 1 bytes @ 0x9
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x9
	ds	1
??___lmul:	; 1 bytes @ 0xA
??___lldiv:	; 1 bytes @ 0xA
	ds	1
??_uart_send_number:	; 1 bytes @ 0xB
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x0
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x0
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x0
	ds	1
	global	ADC_Sample@chs_low
ADC_Sample@chs_low:	; 1 bytes @ 0x1
	ds	1
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x2
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x3
	ds	1
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x4
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x4
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x4
	ds	2
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0x6
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x7
	ds	1
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x8
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x8
	ds	2
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0xA
	ds	2
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0xC
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0xC
	ds	4
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x10
	ds	1
??_main:	; 1 bytes @ 0x11
	ds	8
	global	main@pt
main@pt:	; 4 bytes @ 0x19
	ds	4
	global	_main$542
_main$542:	; 2 bytes @ 0x1D
	ds	2
	global	_main$543
_main$543:	; 2 bytes @ 0x1F
	ds	2
	global	main@tick
main@tick:	; 2 bytes @ 0x21
	ds	2
	global	main@ch
main@ch:	; 1 bytes @ 0x23
	ds	1
	global	main@ch_205
main@ch_205:	; 1 bytes @ 0x24
	ds	1
	global	main@temp_x10
main@temp_x10:	; 2 bytes @ 0x25
	ds	2
	global	main@rt
main@rt:	; 4 bytes @ 0x27
	ds	4
	global	main@ldo_adc
main@ldo_adc:	; 2 bytes @ 0x2B
	ds	2
	global	main@vx_mv
main@vx_mv:	; 2 bytes @ 0x2D
	ds	2
	global	main@vx_mv_207
main@vx_mv_207:	; 2 bytes @ 0x2F
	ds	2
	global	main@ntc_adc
main@ntc_adc:	; 2 bytes @ 0x31
	ds	2
	global	main@ldo_adc_206
main@ldo_adc_206:	; 2 bytes @ 0x33
	ds	2
	global	main@bat_mv
main@bat_mv:	; 4 bytes @ 0x35
	ds	4
	global	main@bat_mv_208
main@bat_mv_208:	; 4 bytes @ 0x39
	ds	4
	global	main@vcc_mv
main@vcc_mv:	; 2 bytes @ 0x3D
	ds	2
	global	main@bx
main@bx:	; 1 bytes @ 0x3F
	ds	1
;!
;!Data Sizes:
;!    Strings     98
;!    Constant    12
;!    Data        0
;!    BSS         3
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     11      11
;!    BANK0            80     64      67
;!    BANK1            80      0       0
;!    BANK3            80      0       0
;!    BANK2            80      0       0

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(1) Largest target is 18
;!		 -> STR_48(CODE[5]), STR_47(CODE[8]), STR_46(CODE[2]), STR_45(CODE[2]), 
;!		 -> STR_44(CODE[4]), STR_43(CODE[8]), STR_42(CODE[9]), STR_41(CODE[6]), 
;!		 -> STR_40(CODE[5]), STR_39(CODE[4]), STR_38(CODE[2]), STR_37(CODE[2]), 
;!		 -> STR_36(CODE[5]), STR_35(CODE[6]), STR_34(CODE[2]), STR_33(CODE[2]), 
;!		 -> STR_32(CODE[2]), STR_31(CODE[5]), STR_30(CODE[4]), STR_29(CODE[2]), 
;!		 -> STR_28(CODE[2]), STR_27(CODE[5]), STR_26(CODE[6]), STR_25(CODE[2]), 
;!		 -> STR_24(CODE[2]), STR_23(CODE[11]), STR_22(CODE[2]), STR_21(CODE[4]), 
;!		 -> STR_20(CODE[5]), STR_19(CODE[4]), STR_18(CODE[2]), STR_17(CODE[2]), 
;!		 -> STR_16(CODE[5]), STR_15(CODE[6]), STR_14(CODE[2]), STR_13(CODE[2]), 
;!		 -> STR_12(CODE[2]), STR_11(CODE[4]), STR_10(CODE[4]), STR_9(CODE[2]), 
;!		 -> STR_8(CODE[2]), STR_7(CODE[4]), STR_6(CODE[6]), STR_5(CODE[2]), 
;!		 -> STR_4(CODE[2]), STR_3(CODE[11]), STR_2(CODE[2]), STR_1(CODE[18]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    _main->_uart_send_number
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    None.
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->___lldiv
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    None.
;!
;!Critical Paths under _main in BANK1
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 8, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                47    47      0   10951
;!                                             17 BANK0     47    47      0
;!                         _ADC_Sample
;!                        _Init_System
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                       _sw_uart_init
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     1     1      0    1410
;!                                              5 COMMON     1     1      0
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_number                                    10     8      2    2980
;!                                              9 COMMON     2     0      2
;!                                              0 BANK0      8     8      0
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0      69
;!                                              2 COMMON     3     3      0
;! ---------------------------------------------------------------------------------
;! (2) ___lwmod                                              5     1      4     477
;!                                              2 COMMON     5     1      4
;! ---------------------------------------------------------------------------------
;! (2) ___lwdiv                                              7     3      4     374
;!                                              2 COMMON     7     3      4
;! ---------------------------------------------------------------------------------
;! (1) _sw_uart_init                                         0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) ___lmul                                              12     4      8    2128
;!                                              2 COMMON     8     0      8
;!                                              0 BANK0      4     4      0
;! ---------------------------------------------------------------------------------
;! (1) ___lldiv                                             13     5      8    1032
;!                                              4 BANK0     13     5      8
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (1) _Init_System                                          0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _ADC_Sample                                          19    18      1     867
;!                                              2 COMMON     5     4      1
;!                                              0 BANK0     14    14      0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 2
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (3) _Isr_Timer                                            2     2      0       0
;!                                              0 COMMON     2     2      0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 3
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ADC_Sample
;!   _Init_System
;!   ___lldiv
;!     ___lmul (ARG)
;!   ___lmul
;!   ___lwdiv
;!   ___lwmod
;!   _sw_uart_init
;!   _uart_send_number
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BITCOMMON            E      0       0       0        0.0%
;!NULL                 0      0       0       0        0.0%
;!CODE                 0      0       0       0        0.0%
;!COMMON               E      B       B       1       78.6%
;!BITSFR0              0      0       0       1        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!SFR1                 0      0       0       2        0.0%
;!STACK                0      0       0       2        0.0%
;!BITBANK0            50      0       0       3        0.0%
;!BANK0               50     40      43       4       83.8%
;!BITSFR3              0      0       0       4        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITBANK1            50      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BANK1               50      0       0       6        0.0%
;!BITBANK3            50      0       0       7        0.0%
;!BANK3               50      0       0       8        0.0%
;!BITBANK2            50      0       0       9        0.0%
;!BANK2               50      0       0      10        0.0%
;!ABS                  0      0      4E      11        0.0%
;!DATA                 0      0      4E      12        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 161 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   39[BANK0 ] unsigned long 
;;  temp_x10        2   37[BANK0 ] unsigned int 
;;  bat_mv          4   57[BANK0 ] unsigned long 
;;  ldo_adc         2   51[BANK0 ] unsigned int 
;;  vx_mv           2   47[BANK0 ] unsigned int 
;;  ch              1   36[BANK0 ] unsigned char 
;;  bat_mv          4   53[BANK0 ] unsigned long 
;;  vx_mv           2   45[BANK0 ] unsigned int 
;;  ldo_adc         2   43[BANK0 ] unsigned int 
;;  ch              1   35[BANK0 ] unsigned char 
;;  ntc_adc         2   49[BANK0 ] unsigned int 
;;  pt              4   25[BANK0 ] unsigned long 
;;  vcc_mv          2   61[BANK0 ] unsigned int 
;;  tick            2   33[BANK0 ] unsigned int 
;;  bx              1   63[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      39       0       0       0
;;      Temps:          0       8       0       0       0
;;      Totals:         0      47       0       0       0
;;Total ram usage:       47 bytes
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		_Init_System
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_sw_uart_init
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	161
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	161
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 5
; Regs used in _main: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	163
	
l1430:	
;SC8F096_ADC.c: 163: Init_System();
	fcall	_Init_System
	line	164
	
l1432:	
;SC8F096_ADC.c: 164: sw_uart_init();
	fcall	_sw_uart_init
	line	166
;SC8F096_ADC.c: 166: ADCON0 = 0x41;
	movlw	low(041h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	176
	
l1434:	
;SC8F096_ADC.c: 176: ANSEL0 |= 0xF0;
	movlw	low(0F0h)
	iorwf	(147)^080h,f	;volatile
	line	177
	
l1436:	
;SC8F096_ADC.c: 177: ANSEL1 |= 0x03;
	movlw	low(03h)
	iorwf	(148)^080h,f	;volatile
	line	178
	
l1438:	
;SC8F096_ADC.c: 178: ANSEL2 |= 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	iorwf	(265)^0100h,f	;volatile
	line	179
	
l1440:	
;SC8F096_ADC.c: 179: ANSEL3 |= 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	iorwf	(140)^080h,f	;volatile
	line	181
	
l1442:	
;SC8F096_ADC.c: 181: uart_send_string("B1-B12 ADC Test\r\n");
	movlw	(low((((STR_1)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	183
	
l1444:	
;SC8F096_ADC.c: 183: unsigned int tick = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(main@tick)
	clrf	(main@tick+1)
	line	187
;SC8F096_ADC.c: 184: unsigned int vcc_mv;
;SC8F096_ADC.c: 185: unsigned char bx;
;SC8F096_ADC.c: 187: while(1)
	
l284:	
	line	189
# 189 "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
clrwdt ;# 
psect	maintext
	line	190
	
l1446:	
;SC8F096_ADC.c: 190: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_main+0)+0+1),f
	movlw	241
movwf	((??_main+0)+0),f
	u1317:
decfsz	((??_main+0)+0),f
	goto	u1317
	decfsz	((??_main+0)+0+1),f
	goto	u1317
opt asmopt_pop

	line	191
	
l1448:	
;SC8F096_ADC.c: 191: tick++;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(main@tick),f
	skipnz
	incf	(main@tick+1),f
	line	192
	
l1450:	
;SC8F096_ADC.c: 192: if(tick % 200 != 0) continue;
	movlw	0C8h
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(main@tick+1),w
	movwf	(___lwmod@dividend+1)
	movf	(main@tick),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	((0+(?___lwmod))),w
iorwf	((1+(?___lwmod))),w
	btfsc	status,2
	goto	u1001
	goto	u1000
u1001:
	goto	l285
u1000:
	goto	l284
	
l285:	
	line	193
# 193 "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
clrwdt ;# 
psect	maintext
	line	196
	
l1454:	
;SC8F096_ADC.c: 196: vcc_mv = 5000;
	movlw	088h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(main@vcc_mv)
	movlw	013h
	movwf	((main@vcc_mv))+1
	line	197
	
l1456:	
;SC8F096_ADC.c: 197: test_adc = ADC_Sample(31, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	198
	
l1458:	
;SC8F096_ADC.c: 198: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u1011
	goto	u1010
u1011:
	goto	l1464
u1010:
	line	200
	
l1460:	
;SC8F096_ADC.c: 199: {
;SC8F096_ADC.c: 200: unsigned long pt = (unsigned long)((4096UL*1.2*1000)) / adresult;
	movf	(_adresult),w	;volatile
	movwf	(___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(main@pt+3)
	movf	(2+(?___lldiv)),w
	movwf	(main@pt+2)
	movf	(1+(?___lldiv)),w
	movwf	(main@pt+1)
	movf	(0+(?___lldiv)),w
	movwf	(main@pt)

	line	201
	
l1462:	
;SC8F096_ADC.c: 201: vcc_mv = (unsigned int)pt;
	movf	(main@pt+1),w
	movwf	(main@vcc_mv+1)
	movf	(main@pt),w
	movwf	(main@vcc_mv)
	line	205
	
l1464:	
;SC8F096_ADC.c: 202: }
;SC8F096_ADC.c: 205: for(bx = 0; bx < 6; bx++)
	clrf	(main@bx)
	line	207
	
l1470:	
;SC8F096_ADC.c: 206: {
;SC8F096_ADC.c: 207: unsigned char ch = bx_ch[bx];
	movf	(main@bx),w
	addlw	low((((_bx_ch)-__stringbase)|8000h))
	movwf	fsr0
	fcall	stringdir
	movwf	(main@ch)
	line	212
	
l1472:	
;SC8F096_ADC.c: 208: unsigned int ldo_adc, vx_mv;
;SC8F096_ADC.c: 209: unsigned long bat_mv;
;SC8F096_ADC.c: 212: test_adc = ADC_Sample(ch, 7);
	movlw	low(07h)
	movwf	(ADC_Sample@adldo)
	movf	(main@ch),w
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	213
	
l1474:	
;SC8F096_ADC.c: 213: if(0xA5 != test_adc) goto print_ntc;
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u1021
	goto	u1020
u1021:
	goto	l1478
u1020:
	goto	l1618
	line	214
	
l1478:	
;SC8F096_ADC.c: 214: ldo_adc = adresult;
	movf	(_adresult+1),w	;volatile
	movwf	(main@ldo_adc+1)
	movf	(_adresult),w	;volatile
	movwf	(main@ldo_adc)
	line	215
	
l1480:	
;SC8F096_ADC.c: 215: vx_mv = (unsigned long)ldo_adc * 3000UL / 4096UL;
	movf	(main@ldo_adc),w
	movwf	(___lmul@multiplier)
	movf	(main@ldo_adc+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	0Bh
	movwf	(___lmul@multiplicand+1)
	movlw	0B8h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(0+?___lmul),w
	movwf	(??_main+0)+0
	movf	(1+?___lmul),w
	movwf	((??_main+0)+0+1)
	movf	(2+?___lmul),w
	movwf	((??_main+0)+0+2)
	movf	(3+?___lmul),w
	movwf	((??_main+0)+0+3)
	movlw	0Ch
u1035:
	clrc
	rrf	(??_main+0)+3,f
	rrf	(??_main+0)+2,f
	rrf	(??_main+0)+1,f
	rrf	(??_main+0)+0,f
u1030:
	addlw	-1
	skipz
	goto	u1035
	movf	1+(??_main+0)+0,w
	movwf	(main@vx_mv+1)
	movf	0+(??_main+0)+0,w
	movwf	(main@vx_mv)
	line	217
	
l1482:	
;SC8F096_ADC.c: 217: if(ldo_adc >= 4090)
	movlw	0Fh
	subwf	(main@ldo_adc+1),w
	movlw	0FAh
	skipnz
	subwf	(main@ldo_adc),w
	skipc
	goto	u1041
	goto	u1040
u1041:
	goto	l1516
u1040:
	line	220
	
l1484:	
;SC8F096_ADC.c: 218: {
;SC8F096_ADC.c: 220: test_adc = ADC_Sample(ch, 0);
	clrf	(ADC_Sample@adldo)
	movf	(main@ch),w
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	221
	
l1486:	
;SC8F096_ADC.c: 221: if(0xA5 != test_adc) goto print_ntc;
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u1051
	goto	u1050
u1051:
	goto	l1490
u1050:
	goto	l1618
	line	222
	
l1490:	
;SC8F096_ADC.c: 222: vx_mv = (unsigned long)adresult * vcc_mv / 4096UL;
	movf	(_adresult),w	;volatile
	movwf	(___lmul@multiplier)
	movf	(_adresult+1),w	;volatile
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movf	(main@vcc_mv),w
	movwf	(___lmul@multiplicand)
	movf	(main@vcc_mv+1),w
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(0+?___lmul),w
	movwf	(??_main+0)+0
	movf	(1+?___lmul),w
	movwf	((??_main+0)+0+1)
	movf	(2+?___lmul),w
	movwf	((??_main+0)+0+2)
	movf	(3+?___lmul),w
	movwf	((??_main+0)+0+3)
	movlw	0Ch
u1065:
	clrc
	rrf	(??_main+0)+3,f
	rrf	(??_main+0)+2,f
	rrf	(??_main+0)+1,f
	rrf	(??_main+0)+0,f
u1060:
	addlw	-1
	skipz
	goto	u1065
	movf	1+(??_main+0)+0,w
	movwf	(main@vx_mv+1)
	movf	0+(??_main+0)+0,w
	movwf	(main@vx_mv)
	line	224
	
l1492:	
;SC8F096_ADC.c: 224: if(adresult >= 4090)
	movlw	0Fh
	subwf	(_adresult+1),w	;volatile
	movlw	0FAh
	skipnz
	subwf	(_adresult),w	;volatile
	skipc
	goto	u1071
	goto	u1070
u1071:
	goto	l1496
u1070:
	line	227
	
l1494:	
;SC8F096_ADC.c: 225: {
;SC8F096_ADC.c: 227: uart_send_string("B");
	movlw	(low((((STR_2)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	228
;SC8F096_ADC.c: 228: uart_send_number(bx+1);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@bx),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	229
;SC8F096_ADC.c: 229: uart_send_string("=4095 OPEN");
	movlw	(low((((STR_3)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	230
;SC8F096_ADC.c: 230: }
	goto	l295
	line	234
	
l1496:	
;SC8F096_ADC.c: 231: else
;SC8F096_ADC.c: 232: {
;SC8F096_ADC.c: 234: bat_mv = (1159UL * vx_mv);
	movf	(main@vx_mv),w
	movwf	(___lmul@multiplier)
	movf	(main@vx_mv+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	04h
	movwf	(___lmul@multiplicand+1)
	movlw	087h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(main@bat_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(main@bat_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(main@bat_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(main@bat_mv)

	line	235
;SC8F096_ADC.c: 235: if(bat_mv > (647UL * (unsigned long)vcc_mv))
	movf	(main@vcc_mv),w
	movwf	(___lmul@multiplier)
	movf	(main@vcc_mv+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	02h
	movwf	(___lmul@multiplicand+1)
	movlw	087h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(main@bat_mv+3),w
	subwf	(3+(?___lmul)),w
	skipz
	goto	u1085
	movf	(main@bat_mv+2),w
	subwf	(2+(?___lmul)),w
	skipz
	goto	u1085
	movf	(main@bat_mv+1),w
	subwf	(1+(?___lmul)),w
	skipz
	goto	u1085
	movf	(main@bat_mv),w
	subwf	(0+(?___lmul)),w
u1085:
	skipnc
	goto	u1081
	goto	u1080
u1081:
	goto	l1514
u1080:
	line	237
	
l1498:	
;SC8F096_ADC.c: 236: {
;SC8F096_ADC.c: 237: bat_mv = (bat_mv - 647UL * (unsigned long)vcc_mv + 1000UL/2) / 1000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_main+0)+0)
	movlw	01h
	movwf	((??_main+0)+0+1)
	movlw	0
	movwf	((??_main+0)+0+2)
	movlw	0
	movwf	((??_main+0)+0+3)
	movf	(main@vcc_mv),w
	movwf	(___lmul@multiplier)
	movf	(main@vcc_mv+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)
	movlw	0FDh
	movwf	(___lmul@multiplicand+1)
	movlw	079h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(0+(?___lmul)),w
	addwf	(main@bat_mv),w
	movwf	((??_main+4)+0+0)
	movlw	0
	skipnc
	movlw	1
	addwf	(1+(?___lmul)),w
	clrf	((??_main+4)+0+2)
	skipnc
	incf	((??_main+4)+0+2),f
	addwf	(main@bat_mv+1),w
	movwf	((??_main+4)+0+1)
	skipnc
	incf	((??_main+4)+0+2),f
	movf	(2+(?___lmul)),w
	addwf	((??_main+4)+0+2),w
	clrf	((??_main+4)+0+3)
	skipnc
	incf	((??_main+4)+0+3),f
	addwf	(main@bat_mv+2),w
	movwf	((??_main+4)+0+2)
	skipnc
	incf	((??_main+4)+0+3),f
	movf	(3+(?___lmul)),w
	addwf	((??_main+4)+0+3),w
	addwf	(main@bat_mv+3),w
	movwf	((??_main+4)+0+3)
	movf	0+(??_main+4)+0,w
	addwf	(??_main+0)+0,f
	movf	1+(??_main+4)+0,w
	skipnc
	incfsz	1+(??_main+4)+0,w
	goto	u1090
	goto	u1091
u1090:
	addwf	(??_main+0)+1,f
u1091:
	movf	2+(??_main+4)+0,w
	skipnc
	incfsz	2+(??_main+4)+0,w
	goto	u1092
	goto	u1093
u1092:
	addwf	(??_main+0)+2,f
u1093:
	movf	3+(??_main+4)+0,w
	skipnc
	incf	3+(??_main+4)+0,w
	addwf	(??_main+0)+3,f
	movf	3+(??_main+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_main+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_main+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_main+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(main@bat_mv+3)
	movf	(2+(?___lldiv)),w
	movwf	(main@bat_mv+2)
	movf	(1+(?___lldiv)),w
	movwf	(main@bat_mv+1)
	movf	(0+(?___lldiv)),w
	movwf	(main@bat_mv)

	line	238
	
l1500:	
;SC8F096_ADC.c: 238: uart_send_string("B");
	movlw	(low((((STR_4)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	239
	
l1502:	
;SC8F096_ADC.c: 239: uart_send_number(bx+1);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@bx),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	240
	
l1504:	
;SC8F096_ADC.c: 240: uart_send_string("=");
	movlw	(low((((STR_5)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	241
	
l1506:	
;SC8F096_ADC.c: 241: uart_send_number(adresult);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_adresult+1),w	;volatile
	movwf	(uart_send_number@num+1)
	movf	(_adresult),w	;volatile
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	242
	
l1508:	
;SC8F096_ADC.c: 242: uart_send_string(" BAT(");
	movlw	(low((((STR_6)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	243
	
l1510:	
;SC8F096_ADC.c: 243: uart_send_number((unsigned int)bat_mv);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@bat_mv+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@bat_mv),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	244
	
l1512:	
;SC8F096_ADC.c: 244: uart_send_string("mV)");
	movlw	(low((((STR_7)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	245
;SC8F096_ADC.c: 245: }
	goto	l295
	line	248
	
l1514:	
;SC8F096_ADC.c: 246: else
;SC8F096_ADC.c: 247: {
;SC8F096_ADC.c: 248: uart_send_string("B");
	movlw	(low((((STR_8)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	249
;SC8F096_ADC.c: 249: uart_send_number(bx+1);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@bx),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	250
;SC8F096_ADC.c: 250: uart_send_string("=");
	movlw	(low((((STR_9)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	251
;SC8F096_ADC.c: 251: uart_send_number(adresult);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_adresult+1),w	;volatile
	movwf	(uart_send_number@num+1)
	movf	(_adresult),w	;volatile
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	252
;SC8F096_ADC.c: 252: uart_send_string(" ?[");
	movlw	(low((((STR_10)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	253
;SC8F096_ADC.c: 253: uart_send_number((unsigned int)vx_mv);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@vx_mv+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@vx_mv),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	254
;SC8F096_ADC.c: 254: uart_send_string("mV)");
	movlw	(low((((STR_11)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	256
	
l295:	
	line	257
;SC8F096_ADC.c: 255: }
;SC8F096_ADC.c: 256: }
;SC8F096_ADC.c: 257: uart_send_string(" ");
	movlw	(low((((STR_12)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	258
;SC8F096_ADC.c: 258: }
	goto	l1536
	line	262
	
l1516:	
;SC8F096_ADC.c: 259: else
;SC8F096_ADC.c: 260: {
;SC8F096_ADC.c: 262: bat_mv = (1159UL * vx_mv);
	movf	(main@vx_mv),w
	movwf	(___lmul@multiplier)
	movf	(main@vx_mv+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	04h
	movwf	(___lmul@multiplicand+1)
	movlw	087h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(main@bat_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(main@bat_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(main@bat_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(main@bat_mv)

	line	263
;SC8F096_ADC.c: 263: if(bat_mv > (647UL * (unsigned long)vcc_mv))
	movf	(main@vcc_mv),w
	movwf	(___lmul@multiplier)
	movf	(main@vcc_mv+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	02h
	movwf	(___lmul@multiplicand+1)
	movlw	087h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(main@bat_mv+3),w
	subwf	(3+(?___lmul)),w
	skipz
	goto	u1105
	movf	(main@bat_mv+2),w
	subwf	(2+(?___lmul)),w
	skipz
	goto	u1105
	movf	(main@bat_mv+1),w
	subwf	(1+(?___lmul)),w
	skipz
	goto	u1105
	movf	(main@bat_mv),w
	subwf	(0+(?___lmul)),w
u1105:
	skipnc
	goto	u1101
	goto	u1100
u1101:
	goto	l1534
u1100:
	line	265
	
l1518:	
;SC8F096_ADC.c: 264: {
;SC8F096_ADC.c: 265: bat_mv = (bat_mv - 647UL * (unsigned long)vcc_mv + 1000UL/2) / 1000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_main+0)+0)
	movlw	01h
	movwf	((??_main+0)+0+1)
	movlw	0
	movwf	((??_main+0)+0+2)
	movlw	0
	movwf	((??_main+0)+0+3)
	movf	(main@vcc_mv),w
	movwf	(___lmul@multiplier)
	movf	(main@vcc_mv+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)
	movlw	0FDh
	movwf	(___lmul@multiplicand+1)
	movlw	079h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(0+(?___lmul)),w
	addwf	(main@bat_mv),w
	movwf	((??_main+4)+0+0)
	movlw	0
	skipnc
	movlw	1
	addwf	(1+(?___lmul)),w
	clrf	((??_main+4)+0+2)
	skipnc
	incf	((??_main+4)+0+2),f
	addwf	(main@bat_mv+1),w
	movwf	((??_main+4)+0+1)
	skipnc
	incf	((??_main+4)+0+2),f
	movf	(2+(?___lmul)),w
	addwf	((??_main+4)+0+2),w
	clrf	((??_main+4)+0+3)
	skipnc
	incf	((??_main+4)+0+3),f
	addwf	(main@bat_mv+2),w
	movwf	((??_main+4)+0+2)
	skipnc
	incf	((??_main+4)+0+3),f
	movf	(3+(?___lmul)),w
	addwf	((??_main+4)+0+3),w
	addwf	(main@bat_mv+3),w
	movwf	((??_main+4)+0+3)
	movf	0+(??_main+4)+0,w
	addwf	(??_main+0)+0,f
	movf	1+(??_main+4)+0,w
	skipnc
	incfsz	1+(??_main+4)+0,w
	goto	u1110
	goto	u1111
u1110:
	addwf	(??_main+0)+1,f
u1111:
	movf	2+(??_main+4)+0,w
	skipnc
	incfsz	2+(??_main+4)+0,w
	goto	u1112
	goto	u1113
u1112:
	addwf	(??_main+0)+2,f
u1113:
	movf	3+(??_main+4)+0,w
	skipnc
	incf	3+(??_main+4)+0,w
	addwf	(??_main+0)+3,f
	movf	3+(??_main+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_main+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_main+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_main+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(main@bat_mv+3)
	movf	(2+(?___lldiv)),w
	movwf	(main@bat_mv+2)
	movf	(1+(?___lldiv)),w
	movwf	(main@bat_mv+1)
	movf	(0+(?___lldiv)),w
	movwf	(main@bat_mv)

	line	266
	
l1520:	
;SC8F096_ADC.c: 266: uart_send_string("B");
	movlw	(low((((STR_13)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	267
	
l1522:	
;SC8F096_ADC.c: 267: uart_send_number(bx+1);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@bx),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	268
	
l1524:	
;SC8F096_ADC.c: 268: uart_send_string("=");
	movlw	(low((((STR_14)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	269
	
l1526:	
;SC8F096_ADC.c: 269: uart_send_number(ldo_adc);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@ldo_adc+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@ldo_adc),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	270
	
l1528:	
;SC8F096_ADC.c: 270: uart_send_string(" BAT(");
	movlw	(low((((STR_15)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	271
	
l1530:	
;SC8F096_ADC.c: 271: uart_send_number((unsigned int)bat_mv);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@bat_mv+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@bat_mv),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	272
	
l1532:	
;SC8F096_ADC.c: 272: uart_send_string("mV) ");
	movlw	(low((((STR_16)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	273
;SC8F096_ADC.c: 273: }
	goto	l1536
	line	276
	
l1534:	
;SC8F096_ADC.c: 274: else
;SC8F096_ADC.c: 275: {
;SC8F096_ADC.c: 276: uart_send_string("B");
	movlw	(low((((STR_17)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	277
;SC8F096_ADC.c: 277: uart_send_number(bx+1);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@bx),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	278
;SC8F096_ADC.c: 278: uart_send_string("=");
	movlw	(low((((STR_18)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	279
;SC8F096_ADC.c: 279: uart_send_number(ldo_adc);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@ldo_adc+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@ldo_adc),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	280
;SC8F096_ADC.c: 280: uart_send_string(" ?[");
	movlw	(low((((STR_19)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	281
;SC8F096_ADC.c: 281: uart_send_number((unsigned int)vx_mv);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@vx_mv+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@vx_mv),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	282
;SC8F096_ADC.c: 282: uart_send_string("mV) ");
	movlw	(low((((STR_20)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	205
	
l1536:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(main@bx),f
	
l1538:	
	movlw	low(06h)
	subwf	(main@bx),w
	skipc
	goto	u1121
	goto	u1120
u1121:
	goto	l1470
u1120:
	line	286
	
l1540:	
;SC8F096_ADC.c: 283: }
;SC8F096_ADC.c: 284: }
;SC8F096_ADC.c: 285: }
;SC8F096_ADC.c: 286: uart_send_string("\r\n ");
	movlw	(low((((STR_21)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	287
# 287 "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
clrwdt ;# 
psect	maintext
	line	290
	
l1542:	
;SC8F096_ADC.c: 290: for(bx = 6; bx < 12; bx++)
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(main@bx)
	line	292
	
l1548:	
;SC8F096_ADC.c: 291: {
;SC8F096_ADC.c: 292: unsigned char ch = bx_ch[bx];
	movf	(main@bx),w
	addlw	low((((_bx_ch)-__stringbase)|8000h))
	movwf	fsr0
	fcall	stringdir
	movwf	(main@ch_205)
	line	296
	
l1550:	
;SC8F096_ADC.c: 293: unsigned int ldo_adc, vx_mv;
;SC8F096_ADC.c: 294: unsigned long bat_mv;
;SC8F096_ADC.c: 296: test_adc = ADC_Sample(ch, 7);
	movlw	low(07h)
	movwf	(ADC_Sample@adldo)
	movf	(main@ch_205),w
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	297
	
l1552:	
;SC8F096_ADC.c: 297: if(0xA5 != test_adc) goto print_ntc;
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u1131
	goto	u1130
u1131:
	goto	l1556
u1130:
	goto	l1618
	line	298
	
l1556:	
;SC8F096_ADC.c: 298: ldo_adc = adresult;
	movf	(_adresult+1),w	;volatile
	movwf	(main@ldo_adc_206+1)
	movf	(_adresult),w	;volatile
	movwf	(main@ldo_adc_206)
	line	299
	
l1558:	
;SC8F096_ADC.c: 299: vx_mv = (unsigned long)ldo_adc * 3000UL / 4096UL;
	movf	(main@ldo_adc_206),w
	movwf	(___lmul@multiplier)
	movf	(main@ldo_adc_206+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	0Bh
	movwf	(___lmul@multiplicand+1)
	movlw	0B8h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(0+?___lmul),w
	movwf	(??_main+0)+0
	movf	(1+?___lmul),w
	movwf	((??_main+0)+0+1)
	movf	(2+?___lmul),w
	movwf	((??_main+0)+0+2)
	movf	(3+?___lmul),w
	movwf	((??_main+0)+0+3)
	movlw	0Ch
u1145:
	clrc
	rrf	(??_main+0)+3,f
	rrf	(??_main+0)+2,f
	rrf	(??_main+0)+1,f
	rrf	(??_main+0)+0,f
u1140:
	addlw	-1
	skipz
	goto	u1145
	movf	1+(??_main+0)+0,w
	movwf	(main@vx_mv_207+1)
	movf	0+(??_main+0)+0,w
	movwf	(main@vx_mv_207)
	line	301
	
l1560:	
;SC8F096_ADC.c: 301: if(ldo_adc >= 4090)
	movlw	0Fh
	subwf	(main@ldo_adc_206+1),w
	movlw	0FAh
	skipnz
	subwf	(main@ldo_adc_206),w
	skipc
	goto	u1151
	goto	u1150
u1151:
	goto	l1594
u1150:
	line	303
	
l1562:	
;SC8F096_ADC.c: 302: {
;SC8F096_ADC.c: 303: test_adc = ADC_Sample(ch, 0);
	clrf	(ADC_Sample@adldo)
	movf	(main@ch_205),w
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	304
	
l1564:	
;SC8F096_ADC.c: 304: if(0xA5 != test_adc) goto print_ntc;
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u1161
	goto	u1160
u1161:
	goto	l1568
u1160:
	goto	l1618
	line	305
	
l1568:	
;SC8F096_ADC.c: 305: vx_mv = (unsigned long)adresult * vcc_mv / 4096UL;
	movf	(_adresult),w	;volatile
	movwf	(___lmul@multiplier)
	movf	(_adresult+1),w	;volatile
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movf	(main@vcc_mv),w
	movwf	(___lmul@multiplicand)
	movf	(main@vcc_mv+1),w
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(0+?___lmul),w
	movwf	(??_main+0)+0
	movf	(1+?___lmul),w
	movwf	((??_main+0)+0+1)
	movf	(2+?___lmul),w
	movwf	((??_main+0)+0+2)
	movf	(3+?___lmul),w
	movwf	((??_main+0)+0+3)
	movlw	0Ch
u1175:
	clrc
	rrf	(??_main+0)+3,f
	rrf	(??_main+0)+2,f
	rrf	(??_main+0)+1,f
	rrf	(??_main+0)+0,f
u1170:
	addlw	-1
	skipz
	goto	u1175
	movf	1+(??_main+0)+0,w
	movwf	(main@vx_mv_207+1)
	movf	0+(??_main+0)+0,w
	movwf	(main@vx_mv_207)
	line	307
	
l1570:	
;SC8F096_ADC.c: 307: if(adresult >= 4090)
	movlw	0Fh
	subwf	(_adresult+1),w	;volatile
	movlw	0FAh
	skipnz
	subwf	(_adresult),w	;volatile
	skipc
	goto	u1181
	goto	u1180
u1181:
	goto	l1574
u1180:
	line	309
	
l1572:	
;SC8F096_ADC.c: 308: {
;SC8F096_ADC.c: 309: uart_send_string("B");
	movlw	(low((((STR_22)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	310
;SC8F096_ADC.c: 310: uart_send_number(bx+1);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@bx),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	311
;SC8F096_ADC.c: 311: uart_send_string("=4095 OPEN");
	movlw	(low((((STR_23)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	312
;SC8F096_ADC.c: 312: }
	goto	l307
	line	315
	
l1574:	
;SC8F096_ADC.c: 313: else
;SC8F096_ADC.c: 314: {
;SC8F096_ADC.c: 315: bat_mv = (1159UL * vx_mv);
	movf	(main@vx_mv_207),w
	movwf	(___lmul@multiplier)
	movf	(main@vx_mv_207+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	04h
	movwf	(___lmul@multiplicand+1)
	movlw	087h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(main@bat_mv_208+3)
	movf	(2+(?___lmul)),w
	movwf	(main@bat_mv_208+2)
	movf	(1+(?___lmul)),w
	movwf	(main@bat_mv_208+1)
	movf	(0+(?___lmul)),w
	movwf	(main@bat_mv_208)

	line	316
;SC8F096_ADC.c: 316: if(bat_mv > (647UL * (unsigned long)vcc_mv))
	movf	(main@vcc_mv),w
	movwf	(___lmul@multiplier)
	movf	(main@vcc_mv+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	02h
	movwf	(___lmul@multiplicand+1)
	movlw	087h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(main@bat_mv_208+3),w
	subwf	(3+(?___lmul)),w
	skipz
	goto	u1195
	movf	(main@bat_mv_208+2),w
	subwf	(2+(?___lmul)),w
	skipz
	goto	u1195
	movf	(main@bat_mv_208+1),w
	subwf	(1+(?___lmul)),w
	skipz
	goto	u1195
	movf	(main@bat_mv_208),w
	subwf	(0+(?___lmul)),w
u1195:
	skipnc
	goto	u1191
	goto	u1190
u1191:
	goto	l1592
u1190:
	line	318
	
l1576:	
;SC8F096_ADC.c: 317: {
;SC8F096_ADC.c: 318: bat_mv = (bat_mv - 647UL * (unsigned long)vcc_mv + 1000UL/2) / 1000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_main+0)+0)
	movlw	01h
	movwf	((??_main+0)+0+1)
	movlw	0
	movwf	((??_main+0)+0+2)
	movlw	0
	movwf	((??_main+0)+0+3)
	movf	(main@vcc_mv),w
	movwf	(___lmul@multiplier)
	movf	(main@vcc_mv+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)
	movlw	0FDh
	movwf	(___lmul@multiplicand+1)
	movlw	079h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(0+(?___lmul)),w
	addwf	(main@bat_mv_208),w
	movwf	((??_main+4)+0+0)
	movlw	0
	skipnc
	movlw	1
	addwf	(1+(?___lmul)),w
	clrf	((??_main+4)+0+2)
	skipnc
	incf	((??_main+4)+0+2),f
	addwf	(main@bat_mv_208+1),w
	movwf	((??_main+4)+0+1)
	skipnc
	incf	((??_main+4)+0+2),f
	movf	(2+(?___lmul)),w
	addwf	((??_main+4)+0+2),w
	clrf	((??_main+4)+0+3)
	skipnc
	incf	((??_main+4)+0+3),f
	addwf	(main@bat_mv_208+2),w
	movwf	((??_main+4)+0+2)
	skipnc
	incf	((??_main+4)+0+3),f
	movf	(3+(?___lmul)),w
	addwf	((??_main+4)+0+3),w
	addwf	(main@bat_mv_208+3),w
	movwf	((??_main+4)+0+3)
	movf	0+(??_main+4)+0,w
	addwf	(??_main+0)+0,f
	movf	1+(??_main+4)+0,w
	skipnc
	incfsz	1+(??_main+4)+0,w
	goto	u1200
	goto	u1201
u1200:
	addwf	(??_main+0)+1,f
u1201:
	movf	2+(??_main+4)+0,w
	skipnc
	incfsz	2+(??_main+4)+0,w
	goto	u1202
	goto	u1203
u1202:
	addwf	(??_main+0)+2,f
u1203:
	movf	3+(??_main+4)+0,w
	skipnc
	incf	3+(??_main+4)+0,w
	addwf	(??_main+0)+3,f
	movf	3+(??_main+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_main+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_main+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_main+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(main@bat_mv_208+3)
	movf	(2+(?___lldiv)),w
	movwf	(main@bat_mv_208+2)
	movf	(1+(?___lldiv)),w
	movwf	(main@bat_mv_208+1)
	movf	(0+(?___lldiv)),w
	movwf	(main@bat_mv_208)

	line	319
	
l1578:	
;SC8F096_ADC.c: 319: uart_send_string("B");
	movlw	(low((((STR_24)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	320
	
l1580:	
;SC8F096_ADC.c: 320: uart_send_number(bx+1);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@bx),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	321
	
l1582:	
;SC8F096_ADC.c: 321: uart_send_string("=");
	movlw	(low((((STR_25)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	322
	
l1584:	
;SC8F096_ADC.c: 322: uart_send_number(ldo_adc);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@ldo_adc_206+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@ldo_adc_206),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	323
	
l1586:	
;SC8F096_ADC.c: 323: uart_send_string(" BAT(");
	movlw	(low((((STR_26)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	324
	
l1588:	
;SC8F096_ADC.c: 324: uart_send_number((unsigned int)bat_mv);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@bat_mv_208+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@bat_mv_208),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	325
	
l1590:	
;SC8F096_ADC.c: 325: uart_send_string("mV) ");
	movlw	(low((((STR_27)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	326
;SC8F096_ADC.c: 326: }
	goto	l307
	line	329
	
l1592:	
;SC8F096_ADC.c: 327: else
;SC8F096_ADC.c: 328: {
;SC8F096_ADC.c: 329: uart_send_string("B");
	movlw	(low((((STR_28)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	330
;SC8F096_ADC.c: 330: uart_send_number(bx+1);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@bx),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	331
;SC8F096_ADC.c: 331: uart_send_string("=");
	movlw	(low((((STR_29)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	332
;SC8F096_ADC.c: 332: uart_send_number(ldo_adc);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@ldo_adc_206+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@ldo_adc_206),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	333
;SC8F096_ADC.c: 333: uart_send_string(" ?[");
	movlw	(low((((STR_30)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	334
;SC8F096_ADC.c: 334: uart_send_number((unsigned int)vx_mv);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@vx_mv_207+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@vx_mv_207),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	335
;SC8F096_ADC.c: 335: uart_send_string("mV) ");
	movlw	(low((((STR_31)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	337
	
l307:	
	line	338
;SC8F096_ADC.c: 336: }
;SC8F096_ADC.c: 337: }
;SC8F096_ADC.c: 338: uart_send_string(" ");
	movlw	(low((((STR_32)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	339
;SC8F096_ADC.c: 339: }
	goto	l1614
	line	343
	
l1594:	
;SC8F096_ADC.c: 340: else
;SC8F096_ADC.c: 341: {
;SC8F096_ADC.c: 343: bat_mv = (1159UL * vx_mv);
	movf	(main@vx_mv_207),w
	movwf	(___lmul@multiplier)
	movf	(main@vx_mv_207+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	04h
	movwf	(___lmul@multiplicand+1)
	movlw	087h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(main@bat_mv_208+3)
	movf	(2+(?___lmul)),w
	movwf	(main@bat_mv_208+2)
	movf	(1+(?___lmul)),w
	movwf	(main@bat_mv_208+1)
	movf	(0+(?___lmul)),w
	movwf	(main@bat_mv_208)

	line	344
;SC8F096_ADC.c: 344: if(bat_mv > (647UL * (unsigned long)vcc_mv))
	movf	(main@vcc_mv),w
	movwf	(___lmul@multiplier)
	movf	(main@vcc_mv+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	02h
	movwf	(___lmul@multiplicand+1)
	movlw	087h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(main@bat_mv_208+3),w
	subwf	(3+(?___lmul)),w
	skipz
	goto	u1215
	movf	(main@bat_mv_208+2),w
	subwf	(2+(?___lmul)),w
	skipz
	goto	u1215
	movf	(main@bat_mv_208+1),w
	subwf	(1+(?___lmul)),w
	skipz
	goto	u1215
	movf	(main@bat_mv_208),w
	subwf	(0+(?___lmul)),w
u1215:
	skipnc
	goto	u1211
	goto	u1210
u1211:
	goto	l1612
u1210:
	line	346
	
l1596:	
;SC8F096_ADC.c: 345: {
;SC8F096_ADC.c: 346: bat_mv = (bat_mv - 647UL * (unsigned long)vcc_mv + 1000UL/2) / 1000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_main+0)+0)
	movlw	01h
	movwf	((??_main+0)+0+1)
	movlw	0
	movwf	((??_main+0)+0+2)
	movlw	0
	movwf	((??_main+0)+0+3)
	movf	(main@vcc_mv),w
	movwf	(___lmul@multiplier)
	movf	(main@vcc_mv+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)
	movlw	0FDh
	movwf	(___lmul@multiplicand+1)
	movlw	079h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(0+(?___lmul)),w
	addwf	(main@bat_mv_208),w
	movwf	((??_main+4)+0+0)
	movlw	0
	skipnc
	movlw	1
	addwf	(1+(?___lmul)),w
	clrf	((??_main+4)+0+2)
	skipnc
	incf	((??_main+4)+0+2),f
	addwf	(main@bat_mv_208+1),w
	movwf	((??_main+4)+0+1)
	skipnc
	incf	((??_main+4)+0+2),f
	movf	(2+(?___lmul)),w
	addwf	((??_main+4)+0+2),w
	clrf	((??_main+4)+0+3)
	skipnc
	incf	((??_main+4)+0+3),f
	addwf	(main@bat_mv_208+2),w
	movwf	((??_main+4)+0+2)
	skipnc
	incf	((??_main+4)+0+3),f
	movf	(3+(?___lmul)),w
	addwf	((??_main+4)+0+3),w
	addwf	(main@bat_mv_208+3),w
	movwf	((??_main+4)+0+3)
	movf	0+(??_main+4)+0,w
	addwf	(??_main+0)+0,f
	movf	1+(??_main+4)+0,w
	skipnc
	incfsz	1+(??_main+4)+0,w
	goto	u1220
	goto	u1221
u1220:
	addwf	(??_main+0)+1,f
u1221:
	movf	2+(??_main+4)+0,w
	skipnc
	incfsz	2+(??_main+4)+0,w
	goto	u1222
	goto	u1223
u1222:
	addwf	(??_main+0)+2,f
u1223:
	movf	3+(??_main+4)+0,w
	skipnc
	incf	3+(??_main+4)+0,w
	addwf	(??_main+0)+3,f
	movf	3+(??_main+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_main+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_main+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_main+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(main@bat_mv_208+3)
	movf	(2+(?___lldiv)),w
	movwf	(main@bat_mv_208+2)
	movf	(1+(?___lldiv)),w
	movwf	(main@bat_mv_208+1)
	movf	(0+(?___lldiv)),w
	movwf	(main@bat_mv_208)

	line	347
	
l1598:	
;SC8F096_ADC.c: 347: uart_send_string("B");
	movlw	(low((((STR_33)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	348
	
l1600:	
;SC8F096_ADC.c: 348: uart_send_number(bx+1);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@bx),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	349
	
l1602:	
;SC8F096_ADC.c: 349: uart_send_string("=");
	movlw	(low((((STR_34)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	350
	
l1604:	
;SC8F096_ADC.c: 350: uart_send_number(ldo_adc);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@ldo_adc_206+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@ldo_adc_206),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	351
	
l1606:	
;SC8F096_ADC.c: 351: uart_send_string(" BAT(");
	movlw	(low((((STR_35)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	352
	
l1608:	
;SC8F096_ADC.c: 352: uart_send_number((unsigned int)bat_mv);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@bat_mv_208+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@bat_mv_208),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	353
	
l1610:	
;SC8F096_ADC.c: 353: uart_send_string("mV) ");
	movlw	(low((((STR_36)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	354
;SC8F096_ADC.c: 354: }
	goto	l1614
	line	357
	
l1612:	
;SC8F096_ADC.c: 355: else
;SC8F096_ADC.c: 356: {
;SC8F096_ADC.c: 357: uart_send_string("B");
	movlw	(low((((STR_37)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	358
;SC8F096_ADC.c: 358: uart_send_number(bx+1);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@bx),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	359
;SC8F096_ADC.c: 359: uart_send_string("=");
	movlw	(low((((STR_38)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	360
;SC8F096_ADC.c: 360: uart_send_number(ldo_adc);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@ldo_adc_206+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@ldo_adc_206),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	361
;SC8F096_ADC.c: 361: uart_send_string(" ?[");
	movlw	(low((((STR_39)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	362
;SC8F096_ADC.c: 362: uart_send_number((unsigned int)vx_mv);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@vx_mv_207+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@vx_mv_207),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	363
;SC8F096_ADC.c: 363: uart_send_string("mV) ");
	movlw	(low((((STR_40)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	290
	
l1614:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(main@bx),f
	
l1616:	
	movlw	low(0Ch)
	subwf	(main@bx),w
	skipc
	goto	u1231
	goto	u1230
u1231:
	goto	l1548
u1230:
	line	370
	
l1618:	
;SC8F096_ADC.c: 370: test_adc = ADC_Sample(18, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	371
	
l1620:	
;SC8F096_ADC.c: 371: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u1241
	goto	u1240
u1241:
	goto	l1660
u1240:
	line	373
	
l1622:	
;SC8F096_ADC.c: 372: {
;SC8F096_ADC.c: 373: unsigned int ntc_adc = adresult;
	movf	(_adresult+1),w	;volatile
	movwf	(main@ntc_adc+1)
	movf	(_adresult),w	;volatile
	movwf	(main@ntc_adc)
	line	375
	
l1624:	
;SC8F096_ADC.c: 375: uart_send_string(" NTC=");
	movlw	(low((((STR_41)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	376
	
l1626:	
;SC8F096_ADC.c: 376: uart_send_number(ntc_adc);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@ntc_adc+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@ntc_adc),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	380
;SC8F096_ADC.c: 380: if(ntc_adc < 100)
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(main@ntc_adc+1),w
	movlw	064h
	skipnz
	subwf	(main@ntc_adc),w
	skipnc
	goto	u1251
	goto	u1250
u1251:
	goto	l1630
u1250:
	line	382
	
l1628:	
;SC8F096_ADC.c: 381: {
;SC8F096_ADC.c: 382: uart_send_string(" T=SHORT");
	movlw	(low((((STR_42)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	383
;SC8F096_ADC.c: 383: }
	goto	l1660
	line	384
	
l1630:	
;SC8F096_ADC.c: 384: else if(ntc_adc > 3996)
	movlw	0Fh
	subwf	(main@ntc_adc+1),w
	movlw	09Dh
	skipnz
	subwf	(main@ntc_adc),w
	skipc
	goto	u1261
	goto	u1260
u1261:
	goto	l1634
u1260:
	line	386
	
l1632:	
;SC8F096_ADC.c: 385: {
;SC8F096_ADC.c: 386: uart_send_string(" T=OPEN");
	movlw	(low((((STR_43)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	387
;SC8F096_ADC.c: 387: }
	goto	l1660
	line	392
	
l1634:	
;SC8F096_ADC.c: 388: else
;SC8F096_ADC.c: 389: {
;SC8F096_ADC.c: 392: unsigned long rt = (unsigned long)ntc_adc * 10000UL / (4096UL - ntc_adc);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	010h
	movwf	(___lldiv@divisor+1)
	movlw	0
	movwf	(___lldiv@divisor)

	movf	(main@ntc_adc),w
	movwf	((??_main+0)+0)
	movf	(main@ntc_adc+1),w
	movwf	((??_main+0)+0+1)
	clrf	((??_main+0)+0+2)
	clrf	((??_main+0)+0+3)
	movf	0+(??_main+0)+0,w
	subwf	(___lldiv@divisor),f
	movf	1+(??_main+0)+0,w
	skipc
	incfsz	1+(??_main+0)+0,w
	goto	u1275
	goto	u1276
u1275:
	subwf	(___lldiv@divisor+1),f
u1276:
	movf	2+(??_main+0)+0,w
	skipc
	incfsz	2+(??_main+0)+0,w
	goto	u1277
	goto	u1278
u1277:
	subwf	(___lldiv@divisor+2),f
u1278:
	movf	3+(??_main+0)+0,w
	skipc
	incfsz	3+(??_main+0)+0,w
	goto	u1279
	goto	u1270
u1279:
	subwf	(___lldiv@divisor+3),f
u1270:

	movf	(main@ntc_adc),w
	movwf	(___lmul@multiplier)
	movf	(main@ntc_adc+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	027h
	movwf	(___lmul@multiplicand+1)
	movlw	010h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(main@rt+3)
	movf	(2+(?___lldiv)),w
	movwf	(main@rt+2)
	movf	(1+(?___lldiv)),w
	movwf	(main@rt+1)
	movf	(0+(?___lldiv)),w
	movwf	(main@rt)

	line	394
	
l1636:	
;SC8F096_ADC.c: 393: unsigned int temp_x10;
;SC8F096_ADC.c: 394: if(rt >= 10000UL)
		movf	(main@rt+3),w
	btfss	status,2
	goto	u1280
	movf	(main@rt+2),w
	btfss	status,2
	goto	u1280
	movlw	39
	subwf	(main@rt+1),w
	skipz
	goto	u1283
	movlw	16
	subwf	(main@rt),w
	skipz
	goto	u1283
u1283:
	btfss	status,0
	goto	u1281
	goto	u1280

u1281:
	goto	l1642
u1280:
	line	395
	
l1638:	
;SC8F096_ADC.c: 395: temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
	movlw	0FAh
	movwf	(main@temp_x10)
	clrf	(main@temp_x10+1)
	
l1640:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0F0h
	movwf	((??_main+0)+0)
	movlw	0D8h
	movwf	((??_main+0)+0+1)
	movlw	0FFh
	movwf	((??_main+0)+0+2)
	movlw	0FFh
	movwf	((??_main+0)+0+3)
	movf	(main@rt),w
	addwf	(??_main+0)+0,f
	movf	(main@rt+1),w
	skipnc
	incfsz	(main@rt+1),w
	goto	u1290
	goto	u1291
u1290:
	addwf	(??_main+0)+1,f
u1291:
	movf	(main@rt+2),w
	skipnc
	incfsz	(main@rt+2),w
	goto	u1292
	goto	u1293
u1292:
	addwf	(??_main+0)+2,f
u1293:
	movf	(main@rt+3),w
	skipnc
	incf	(main@rt+3),w
	addwf	(??_main+0)+3,f
	movf	3+(??_main+0)+0,w
	movwf	(___lmul@multiplier+3)
	movf	2+(??_main+0)+0,w
	movwf	(___lmul@multiplier+2)
	movf	1+(??_main+0)+0,w
	movwf	(___lmul@multiplier+1)
	movf	0+(??_main+0)+0,w
	movwf	(___lmul@multiplier)

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(0+(?___lldiv)),w
	subwf	(main@temp_x10),f
	movf	(1+(?___lldiv)),w
	skipc
	decf	(main@temp_x10+1),f
	subwf	(main@temp_x10+1),f
	goto	l1646
	line	397
	
l1642:	
;SC8F096_ADC.c: 396: else
;SC8F096_ADC.c: 397: temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0
	movwf	(___lmul@multiplier+3)
	movlw	0
	movwf	(___lmul@multiplier+2)
	movlw	027h
	movwf	(___lmul@multiplier+1)
	movlw	010h
	movwf	(___lmul@multiplier)

	movf	(main@rt),w
	subwf	(___lmul@multiplier),f
	movf	(main@rt+1),w
	skipc
	incfsz	(main@rt+1),w
	goto	u1305
	goto	u1306
u1305:
	subwf	(___lmul@multiplier+1),f
u1306:
	movf	(main@rt+2),w
	skipc
	incfsz	(main@rt+2),w
	goto	u1307
	goto	u1308
u1307:
	subwf	(___lmul@multiplier+2),f
u1308:
	movf	(main@rt+3),w
	skipc
	incfsz	(main@rt+3),w
	goto	u1309
	goto	u1300
u1309:
	subwf	(___lmul@multiplier+3),f
u1300:

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(main@temp_x10+1)
	movf	(0+(?___lldiv)),w
	movwf	(main@temp_x10)
	
l1644:	
	movlw	0FAh
	addwf	(main@temp_x10),f
	skipnc
	incf	(main@temp_x10+1),f
	line	399
	
l1646:	
;SC8F096_ADC.c: 399: uart_send_string(" T=");
	movlw	(low((((STR_44)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	400
	
l1648:	
;SC8F096_ADC.c: 400: uart_send_number(temp_x10 / 10);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(main@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(_main$542+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_main$542)
	
l1650:	
;SC8F096_ADC.c: 400: uart_send_number(temp_x10 / 10);
	movf	(_main$542+1),w
	movwf	(uart_send_number@num+1)
	movf	(_main$542),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	401
	
l1652:	
;SC8F096_ADC.c: 401: uart_send_string(".");
	movlw	(low((((STR_45)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	402
	
l1654:	
;SC8F096_ADC.c: 402: uart_send_number(temp_x10 % 10);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@temp_x10+1),w
	movwf	(___lwmod@dividend+1)
	movf	(main@temp_x10),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	movwf	(_main$543+1)
	movf	(0+(?___lwmod)),w
	movwf	(_main$543)
	
l1656:	
;SC8F096_ADC.c: 402: uart_send_number(temp_x10 % 10);
	movf	(_main$543+1),w
	movwf	(uart_send_number@num+1)
	movf	(_main$543),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	403
	
l1658:	
;SC8F096_ADC.c: 403: uart_send_string("C");
	movlw	(low((((STR_46)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	407
	
l1660:	
;SC8F096_ADC.c: 404: }
;SC8F096_ADC.c: 405: }
;SC8F096_ADC.c: 407: uart_send_string("\r\n VCC=");
	movlw	(low((((STR_47)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	408
	
l1662:	
;SC8F096_ADC.c: 408: uart_send_number(vcc_mv);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@vcc_mv+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@vcc_mv),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	409
	
l1664:	
;SC8F096_ADC.c: 409: uart_send_string("mV\r\n");
	movlw	(low((((STR_48)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	411
# 411 "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
clrwdt ;# 
psect	maintext
	goto	l284
	global	start
	ljmp	start
	opt stack 0
	line	413
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 144 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;  str             1    wreg     PTR const unsigned char 
;;		 -> STR_48(5), STR_47(8), STR_46(2), STR_45(2), 
;;		 -> STR_44(4), STR_43(8), STR_42(9), STR_41(6), 
;;		 -> STR_40(5), STR_39(4), STR_38(2), STR_37(2), 
;;		 -> STR_36(5), STR_35(6), STR_34(2), STR_33(2), 
;;		 -> STR_32(2), STR_31(5), STR_30(4), STR_29(2), 
;;		 -> STR_28(2), STR_27(5), STR_26(6), STR_25(2), 
;;		 -> STR_24(2), STR_23(11), STR_22(2), STR_21(4), 
;;		 -> STR_20(5), STR_19(4), STR_18(2), STR_17(2), 
;;		 -> STR_16(5), STR_15(6), STR_14(2), STR_13(2), 
;;		 -> STR_12(2), STR_11(4), STR_10(4), STR_9(2), 
;;		 -> STR_8(2), STR_7(4), STR_6(6), STR_5(2), 
;;		 -> STR_4(2), STR_3(11), STR_2(2), STR_1(18), 
;; Auto vars:     Size  Location     Type
;;  str             1    5[COMMON] PTR const unsigned char 
;;		 -> STR_48(5), STR_47(8), STR_46(2), STR_45(2), 
;;		 -> STR_44(4), STR_43(8), STR_42(9), STR_41(6), 
;;		 -> STR_40(5), STR_39(4), STR_38(2), STR_37(2), 
;;		 -> STR_36(5), STR_35(6), STR_34(2), STR_33(2), 
;;		 -> STR_32(2), STR_31(5), STR_30(4), STR_29(2), 
;;		 -> STR_28(2), STR_27(5), STR_26(6), STR_25(2), 
;;		 -> STR_24(2), STR_23(11), STR_22(2), STR_21(4), 
;;		 -> STR_20(5), STR_19(4), STR_18(2), STR_17(2), 
;;		 -> STR_16(5), STR_15(6), STR_14(2), STR_13(2), 
;;		 -> STR_12(2), STR_11(4), STR_10(4), STR_9(2), 
;;		 -> STR_8(2), STR_7(4), STR_6(6), STR_5(2), 
;;		 -> STR_4(2), STR_3(11), STR_2(2), STR_1(18), 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/100
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         1       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	144
global __ptext1
__ptext1:	;psect for function _uart_send_string
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	144
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 5
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;uart_send_string@str stored from wreg
	movwf	(uart_send_string@str)
	line	146
	
l1324:	
;SC8F096_ADC.c: 146: while(*str) uart_send_char(*str++);
	goto	l1330
	
l1326:	
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringdir
	fcall	_uart_send_char
	
l1328:	
	incf	(uart_send_string@str),f
	
l1330:	
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringdir
	xorlw	0
	skipz
	goto	u891
	goto	u890
u891:
	goto	l1326
u890:
	line	147
	
l270:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 149 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;  num             2    9[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    0[BANK0 ] unsigned char [6]
;;  j               1    7[BANK0 ] unsigned char 
;;  i               1    6[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         2       0       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       8       0       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	line	149
global __ptext2
__ptext2:	;psect for function _uart_send_number
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	149
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 5
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	152
	
l1332:	
;SC8F096_ADC.c: 151: unsigned char buf[6];
;SC8F096_ADC.c: 152: unsigned char i = 0, j;
	clrf	(uart_send_number@i)
	line	153
	
l1334:	
;SC8F096_ADC.c: 153: if(num == 0) { uart_send_char('0'); return; }
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u901
	goto	u900
u901:
	goto	l1346
u900:
	
l1336:	
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l274
	line	154
	
l1340:	
	movf	(uart_send_number@i),w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwmod@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank0
	movwf	indf
	
l1342:	
	incf	(uart_send_number@i),f
	
l1344:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(uart_send_number@num+1)
	movf	(0+(?___lwdiv)),w
	movwf	(uart_send_number@num)
	
l1346:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u911
	goto	u910
u911:
	goto	l1340
u910:
	line	155
	
l1348:	
;SC8F096_ADC.c: 155: for(j = i; j > 0; j--) uart_send_char(buf[j-1]);
	movf	(uart_send_number@i),w
	movwf	(uart_send_number@j)
	
l1350:	
	movf	((uart_send_number@j)),w
	btfss	status,2
	goto	u921
	goto	u920
u921:
	goto	l1354
u920:
	goto	l274
	
l1354:	
	movf	(uart_send_number@j),w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	fcall	_uart_send_char
	
l1356:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decf	(uart_send_number@j),f
	goto	l1350
	line	156
	
l274:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 127 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1    3[COMMON] unsigned char 
;;  i               1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/100
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          1       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	line	127
global __ptext3
__ptext3:	;psect for function _uart_send_char
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	127
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 5
; Regs used in _uart_send_char: [wreg+status,2+status,0]
;uart_send_char@c stored from wreg
	movwf	(uart_send_char@c)
	line	130
	
l1190:	
;SC8F096_ADC.c: 129: unsigned char i;
;SC8F096_ADC.c: 130: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	131
;SC8F096_ADC.c: 131: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	132
	
l1192:	
;SC8F096_ADC.c: 132: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u1327:
decfsz	(??_uart_send_char+0)+0,f
	goto	u1327
	nop
opt asmopt_pop

	line	133
	
l1194:	
;SC8F096_ADC.c: 133: for(i = 0; i < 8; i++)
	clrf	(uart_send_char@i)
	line	134
	
l260:	
	line	135
;SC8F096_ADC.c: 134: {
;SC8F096_ADC.c: 135: if(c & 0x01) RC4 = 1; else RC4 = 0;
	btfss	(uart_send_char@c),(0)&7
	goto	u661
	goto	u660
u661:
	goto	l262
u660:
	
l1200:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l1202
	
l262:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	136
	
l1202:	
;SC8F096_ADC.c: 136: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u1337:
decfsz	(??_uart_send_char+0)+0,f
	goto	u1337
	nop
opt asmopt_pop

	line	137
	
l1204:	
;SC8F096_ADC.c: 137: c >>= 1;
	clrc
	rrf	(uart_send_char@c),f
	line	133
	
l1206:	
	incf	(uart_send_char@i),f
	
l1208:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u671
	goto	u670
u671:
	goto	l260
u670:
	
l261:	
	line	139
;SC8F096_ADC.c: 138: }
;SC8F096_ADC.c: 139: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	140
	
l1210:	
;SC8F096_ADC.c: 140: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u1347:
decfsz	(??_uart_send_char+0)+0,f
	goto	u1347
	nop
opt asmopt_pop

	line	141
	
l1212:	
;SC8F096_ADC.c: 141: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	142
	
l264:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] unsigned int 
;;  dividend        2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext4
__ptext4:	;psect for function ___lwmod
psect	text4
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 5
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l1240:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u721
	goto	u720
u721:
	goto	l1256
u720:
	line	14
	
l1242:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l1246
	line	16
	
l1244:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l1246:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u731
	goto	u730
u731:
	goto	l1244
u730:
	line	20
	
l1248:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u745
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u745:
	skipc
	goto	u741
	goto	u740
u741:
	goto	l1252
u740:
	line	21
	
l1250:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l1252:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l1254:	
	decfsz	(___lwmod@counter),f
	goto	u751
	goto	u750
u751:
	goto	l1248
u750:
	line	25
	
l1256:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l683:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] unsigned int 
;;  dividend        2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] unsigned int 
;;  counter         1    8[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         3       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         7       0       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext5
__ptext5:	;psect for function ___lwdiv
psect	text5
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 5
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l1214:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l1216:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u681
	goto	u680
u681:
	goto	l1236
u680:
	line	16
	
l1218:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l1222
	line	18
	
l1220:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l1222:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u691
	goto	u690
u691:
	goto	l1220
u690:
	line	22
	
l1224:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l1226:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u705
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u705:
	skipc
	goto	u701
	goto	u700
u701:
	goto	l1232
u700:
	line	24
	
l1228:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l1230:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l1232:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l1234:	
	decfsz	(___lwdiv@counter),f
	goto	u711
	goto	u710
u711:
	goto	l1224
u710:
	line	30
	
l1236:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l673:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	_sw_uart_init

;; *************** function _sw_uart_init *****************
;; Defined at:
;;		line 120 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	120
global __ptext6
__ptext6:	;psect for function _sw_uart_init
psect	text6
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	120
	global	__size_of_sw_uart_init
	__size_of_sw_uart_init	equ	__end_of_sw_uart_init-_sw_uart_init
	
_sw_uart_init:	
;incstack = 0
	opt	stack 6
; Regs used in _sw_uart_init: []
	line	122
	
l1322:	
;SC8F096_ADC.c: 122: TRISC &= ~0x10;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	123
;SC8F096_ADC.c: 123: ANSEL2 &= ~0x10;
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	124
;SC8F096_ADC.c: 124: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	125
	
l257:	
	return
	opt stack 0
GLOBAL	__end_of_sw_uart_init
	__end_of_sw_uart_init:
	signat	_sw_uart_init,89
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    2[COMMON] unsigned long 
;;  multiplicand    4    6[COMMON] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    0[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    2[COMMON] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         8       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       4       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext7
__ptext7:	;psect for function ___lmul
psect	text7
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 6
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l1392:	
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l345:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u931
	goto	u930
u931:
	goto	l1396
u930:
	line	122
	
l1394:	
	movf	(___lmul@multiplicand),w
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u941
	addwf	(___lmul@product+1),f
u941:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u942
	addwf	(___lmul@product+2),f
u942:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u943
	addwf	(___lmul@product+3),f
u943:

	line	123
	
l1396:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l1398:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u951
	goto	u950
u951:
	goto	l345
u950:
	line	128
	
l1400:	
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l348:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    4[BANK0 ] unsigned long 
;;  dividend        4    8[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   12[BANK0 ] unsigned long 
;;  counter         1   16[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    4[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      13       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext8
__ptext8:	;psect for function ___lldiv
psect	text8
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 6
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l1404:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l1406:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u961
	goto	u960
u961:
	goto	l1426
u960:
	line	16
	
l1408:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l1412
	line	18
	
l1410:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l1412:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u971
	goto	u970
u971:
	goto	l1410
u970:
	line	22
	
l1414:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l1416:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u985
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u985
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u985
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u985:
	skipc
	goto	u981
	goto	u980
u981:
	goto	l1422
u980:
	line	24
	
l1418:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l1420:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l1422:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l1424:	
	decfsz	(___lldiv@counter),f
	goto	u991
	goto	u990
u991:
	goto	l1414
u990:
	line	30
	
l1426:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l620:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_Init_System

;; *************** function _Init_System *****************
;; Defined at:
;;		line 418 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	418
global __ptext9
__ptext9:	;psect for function _Init_System
psect	text9
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	418
	global	__size_of_Init_System
	__size_of_Init_System	equ	__end_of_Init_System-_Init_System
	
_Init_System:	
;incstack = 0
	opt	stack 6
; Regs used in _Init_System: [wreg+status,2]
	line	420
	
l1360:	
# 420 "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
nop ;# 
	line	421
# 421 "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
clrwdt ;# 
psect	text9
	line	422
	
l1362:	
;SC8F096_ADC.c: 422: OPTION_REG = 0x0F;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(1)	;volatile
	line	423
# 423 "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
clrwdt ;# 
psect	text9
	line	424
;SC8F096_ADC.c: 424: OSCCON = 0X70;
	movlw	low(070h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	426
	
l1364:	
;SC8F096_ADC.c: 426: WPUA = 0B00000000;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(136)^080h	;volatile
	line	427
	
l1366:	
;SC8F096_ADC.c: 427: WPUB = 0B00000000;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	line	428
	
l1368:	
;SC8F096_ADC.c: 428: WPUC = 0B00000000;
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	429
	
l1370:	
;SC8F096_ADC.c: 429: WPUD = 0B00000000;
	clrf	(277)^0100h	;volatile
	line	434
;SC8F096_ADC.c: 434: TRISA = 0xF0; PORTA = 0x0F;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	435
;SC8F096_ADC.c: 435: TRISB = 0x30; PORTB = 0x4F;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	436
;SC8F096_ADC.c: 436: TRISC = 0x07; PORTC = 0x00;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l1372:	
	clrf	(262)^0100h	;volatile
	line	437
	
l1374:	
;SC8F096_ADC.c: 437: TRISD = 0xF0; PORTD = 0x0F;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l1376:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	439
	
l1378:	
;SC8F096_ADC.c: 439: CC0CON = 0;
	bsf	status, 5	;RP0=1, select bank3
	clrf	(405)^0180h	;volatile
	line	440
	
l1380:	
;SC8F096_ADC.c: 440: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	442
	
l1382:	
;SC8F096_ADC.c: 442: PR2 = 249;
	movlw	low(0F9h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(17)	;volatile
	line	443
	
l1384:	
;SC8F096_ADC.c: 443: TMR2IF = 0;
	bcf	(105/8),(105)&7	;volatile
	line	444
	
l1386:	
;SC8F096_ADC.c: 444: TMR2IE = 1;
	bsf	(113/8),(113)&7	;volatile
	line	445
	
l1388:	
;SC8F096_ADC.c: 445: T2CON = 0B00000100;
	movlw	low(04h)
	movwf	(19)	;volatile
	line	446
	
l1390:	
;SC8F096_ADC.c: 446: INTCON = 0XC0;
	movlw	low(0C0h)
	movwf	(11)	;volatile
	line	447
	
l324:	
	return
	opt stack 0
GLOBAL	__end_of_Init_System
	__end_of_Init_System:
	signat	_Init_System,89
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 59 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    2[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    3[BANK0 ] unsigned char 
;;  j               1    0[BANK0 ] unsigned char 
;;  adsum           4    4[BANK0 ] volatile unsigned long 
;;  ad_temp         2   12[BANK0 ] volatile unsigned int 
;;  admax           2   10[BANK0 ] volatile unsigned int 
;;  admin           2    8[BANK0 ] volatile unsigned int 
;;  i               1    2[BANK0 ] unsigned char 
;;  chs_low         1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      14       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      14       0       0       0
;;Total ram usage:       19 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=0
	line	59
global __ptext10
__ptext10:	;psect for function _ADC_Sample
psect	text10
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	59
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 6
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	movwf	(ADC_Sample@adch)
	line	61
	
l1260:	
;SC8F096_ADC.c: 61: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	62
	
l1262:	
;SC8F096_ADC.c: 62: volatile unsigned int admin = 0, admax = 0;
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	63
;SC8F096_ADC.c: 63: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	67
	
l1264:	
;SC8F096_ADC.c: 64: unsigned char chs_low;
;SC8F096_ADC.c: 67: if(adch & 0x10)
	btfss	(ADC_Sample@adch),(4)&7
	goto	u761
	goto	u760
u761:
	goto	l1272
u760:
	line	69
	
l1266:	
;SC8F096_ADC.c: 68: {
;SC8F096_ADC.c: 69: ADCON1 = adldo | 0x40;
	movf	(ADC_Sample@adldo),w
	iorlw	040h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	70
	
l1268:	
;SC8F096_ADC.c: 70: chs_low = adch & 0x0F;
	bcf	status, 5	;RP0=0, select bank0
	movf	(ADC_Sample@adch),w
	movwf	(ADC_Sample@chs_low)
	
l1270:	
	movlw	low(0Fh)
	andwf	(ADC_Sample@chs_low),f
	line	71
;SC8F096_ADC.c: 71: }
	goto	l1274
	line	74
	
l1272:	
;SC8F096_ADC.c: 72: else
;SC8F096_ADC.c: 73: {
;SC8F096_ADC.c: 74: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	75
;SC8F096_ADC.c: 75: chs_low = adch;
	bcf	status, 5	;RP0=0, select bank0
	movf	(ADC_Sample@adch),w
	movwf	(ADC_Sample@chs_low)
	line	79
	
l1274:	
;SC8F096_ADC.c: 76: }
;SC8F096_ADC.c: 78: unsigned char i;
;SC8F096_ADC.c: 79: for(i = 0; i < 34; i++)
	clrf	(ADC_Sample@i)
	line	81
	
l1280:	
;SC8F096_ADC.c: 80: {
;SC8F096_ADC.c: 81: ADCON0 = (unsigned char)(0x81 | (chs_low << 2));
	movf	(ADC_Sample@chs_low),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u775:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u775
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	82
	
l1282:	
;SC8F096_ADC.c: 82: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	6
movwf	((??_ADC_Sample+0)+0),f
	u1357:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u1357
	nop
opt asmopt_pop

	line	83
	
l1284:	
;SC8F096_ADC.c: 83: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	85
	
l1286:	
;SC8F096_ADC.c: 85: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	86
;SC8F096_ADC.c: 86: while(GODONE)
	goto	l243
	
l244:	
	line	88
;SC8F096_ADC.c: 87: {
;SC8F096_ADC.c: 88: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	89
;SC8F096_ADC.c: 89: if(0 == (--j)) return 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u781
	goto	u780
u781:
	goto	l243
u780:
	
l1288:	
	movlw	low(0)
	goto	l246
	line	90
	
l243:	
	line	86
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u791
	goto	u790
u791:
	goto	l244
u790:
	line	92
	
l1292:	
;SC8F096_ADC.c: 90: }
;SC8F096_ADC.c: 92: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
l1294:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	94
	
l1296:	
;SC8F096_ADC.c: 94: if(0 == admax)
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u801
	goto	u800
u801:
	goto	l1300
u800:
	line	96
	
l1298:	
;SC8F096_ADC.c: 95: {
;SC8F096_ADC.c: 96: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	97
;SC8F096_ADC.c: 97: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	98
;SC8F096_ADC.c: 98: }
	goto	l249
	line	99
	
l1300:	
;SC8F096_ADC.c: 99: else if(ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u815
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u815:
	skipnc
	goto	u811
	goto	u810
u811:
	goto	l1304
u810:
	line	100
	
l1302:	
;SC8F096_ADC.c: 100: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	l249
	line	101
	
l1304:	
;SC8F096_ADC.c: 101: else if(ad_temp < admin)
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u825
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u825:
	skipnc
	goto	u821
	goto	u820
u821:
	goto	l249
u820:
	line	102
	
l1306:	
;SC8F096_ADC.c: 102: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	104
	
l249:	
;SC8F096_ADC.c: 104: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u831
	addwf	(ADC_Sample@adsum+1),f	;volatile
u831:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u832
	addwf	(ADC_Sample@adsum+2),f	;volatile
u832:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u833
	addwf	(ADC_Sample@adsum+3),f	;volatile
u833:

	line	79
	
l1308:	
	incf	(ADC_Sample@i),f
	
l1310:	
	movlw	low(022h)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u841
	goto	u840
u841:
	goto	l1280
u840:
	line	107
	
l1312:	
;SC8F096_ADC.c: 105: }
;SC8F096_ADC.c: 107: adsum -= admax;
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u855
	goto	u856
u855:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u856:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u857
	goto	u858
u857:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u858:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u859
	goto	u850
u859:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u850:

	line	108
;SC8F096_ADC.c: 108: if(adsum >= admin)
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u865
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u865
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u865
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u865:
	skipc
	goto	u861
	goto	u860
u861:
	goto	l253
u860:
	line	109
	
l1314:	
;SC8F096_ADC.c: 109: adsum -= admin;
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u875
	goto	u876
u875:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u876:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u877
	goto	u878
u877:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u878:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u879
	goto	u870
u879:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u870:

	goto	l1316
	line	110
	
l253:	
	line	111
;SC8F096_ADC.c: 110: else
;SC8F096_ADC.c: 111: adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	113
	
l1316:	
;SC8F096_ADC.c: 113: adresult = adsum >> 5;
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u885:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u880:
	addlw	-1
	skipz
	goto	u885
	movf	1+(??_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	114
	
l1318:	
;SC8F096_ADC.c: 114: return 0xA5;
	movlw	low(0A5h)
	line	115
	
l246:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 449 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	line	449
global __ptext11
__ptext11:	;psect for function _Isr_Timer
psect	text11
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	449
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 5
; Regs used in _Isr_Timer: []
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Isr_Timer+0)
	movf	pclath,w
	movwf	(??_Isr_Timer+1)
	ljmp	_Isr_Timer
psect	text11
	line	451
	
i1l1186:	
;SC8F096_ADC.c: 451: if(TMR2IF)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(105/8),(105)&7	;volatile
	goto	u65_21
	goto	u65_20
u65_21:
	goto	i1l330
u65_20:
	line	453
	
i1l1188:	
;SC8F096_ADC.c: 452: {
;SC8F096_ADC.c: 453: TMR2IF = 0;
	bcf	(105/8),(105)&7	;volatile
	line	455
	
i1l330:	
	movf	(??_Isr_Timer+1),w
	movwf	pclath
	swapf	(??_Isr_Timer+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
