/**********************************************************
12槽 ADC 采集测试 - 双参数线性标定
SC8F096, 16MHz, UART TX=RC4(J1-CLK), 9600bps
接线: J1-CLK(RC4) → USB-TTL模块RX, J1-GND → 模块GND
注意: 烧录完必须拔掉烧录器, 再接串口模块

标定点: ADC=3345→1.52V, ADC=3457→1.68V (万用表对照)
公式: V_BAT = (1159*V_B1AD - 647*VCC) / 1000
       α=1.159, β=0.647 (双参数线性拟合, 比叠加定理更吻合实测)
**********************************************************/
#pragma warning disable 752
#pragma warning disable 373
#include <sc.h>

#ifndef _XTAL_FREQ
#define _XTAL_FREQ 16000000
#endif

#define     POWER_RATIO      (4096UL*1.2*1000)
#define     SW_TX            RC4
#define     BIT_TIME         104     /* 9600bps */

/* 双参数线性标定: BAT = (α*V_B1AD - β*VCC), α=1.159, β=0.647 */
#define     ALPHA_NUM        1159UL   /* α * 1000 */
#define     BETA_NUM          647UL   /* β * 1000 */
#define     CAL_DEN           1000UL

volatile unsigned int adresult;
volatile unsigned char test_adc;

/* B1..B12对应的ADC通道号 */
const unsigned char bx_ch[12] = {
    17,  /* B1=AN17 */
    16,  /* B2=AN16 */
    7,   /* B3=AN7  */
    5,   /* B4=AN5  */
    6,   /* B5=AN6  */
    4,   /* B6=AN4  */
    13,  /* B7=AN13 */
    12,  /* B8=AN12 */
    28,  /* B9=AN28 */
    29,  /* B10=AN29 */
    27,  /* B11=AN27 */
    26   /* B12=AN26 */
};

unsigned char ADC_Sample(unsigned char adch, unsigned char adldo);
void Init_System(void);
void sw_uart_init(void);
void uart_send_char(unsigned char c);
void uart_send_string(const unsigned char *str);
void uart_send_number(unsigned int num);

/*========================================================================
  ADC采样 - 去极值平均, 累加34次取平均(去min/max剩32个, >>5平均)
  adch: 通道号(0~31), adldo: bit2=1→LDO=3V, =0→VDD参考
  时钟: ADCS=10=Fosc/32, Tad=2μs@16MHz
========================================================================*/
unsigned char ADC_Sample(unsigned char adch, unsigned char adldo)
{
    volatile unsigned long adsum = 0;
    volatile unsigned int admin = 0, admax = 0;
    volatile unsigned int ad_temp = 0;
    unsigned char chs_low;

    /* CHS4: adch bit4 为1表示AN16~AN31 */
    if(adch & 0x10)
    {
        ADCON1 = adldo | 0x40;
        chs_low = adch & 0x0F;
    }
    else
    {
        ADCON1 = adldo;
        chs_low = adch;
    }

    unsigned char i;
    for(i = 0; i < 34; i++)
    {
        ADCON0 = (unsigned char)(0x81 | (chs_low << 2));
        __delay_us(5);
        GODONE = 1;

        unsigned char j = 0;
        while(GODONE)
        {
            __delay_us(2);
            if(0 == (--j)) return 0;
        }

        ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));

        if(0 == admax)
        {
            admax = ad_temp;
            admin = ad_temp;
        }
        else if(ad_temp > admax)
            admax = ad_temp;
        else if(ad_temp < admin)
            admin = ad_temp;

        adsum += ad_temp;
    }

    adsum -= admax;
    if(adsum >= admin)
        adsum -= admin;
    else
        adsum = 0;

    adresult = adsum >> 5;
    return 0xA5;
}

/*========================================================================
  软件UART
========================================================================*/
void sw_uart_init(void)
{
    TRISC &= ~0x10;
    ANSEL2 &= ~0x10;
    SW_TX = 1;
}

void uart_send_char(unsigned char c)
{
    unsigned char i;
    GIE = 0;
    SW_TX = 0;
    __delay_us(BIT_TIME);
    for(i = 0; i < 8; i++)
    {
        if(c & 0x01) SW_TX = 1; else SW_TX = 0;
        __delay_us(BIT_TIME);
        c >>= 1;
    }
    SW_TX = 1;
    __delay_us(BIT_TIME);
    GIE = 1;
}

void uart_send_string(const unsigned char *str)
{
    while(*str) uart_send_char(*str++);
}

void uart_send_number(unsigned int num)
{
    unsigned char buf[6];
    unsigned char i = 0, j;
    if(num == 0) { uart_send_char('0'); return; }
    while(num > 0) { buf[i++] = '0' + (num % 10); num /= 10; }
    for(j = i; j > 0; j--) uart_send_char(buf[j-1]);
}

/*========================================================================
  main
========================================================================*/
void main(void)
{
    Init_System();
    sw_uart_init();

    ADCON0 = 0x41;

    /* ANSEL: 设为模拟输入的引脚
       AN4=RA4, AN5=RA5, AN6=RA6, AN7=RA7     → ANSEL0
       AN12=RB0, AN13=RB1                       → ANSEL1
       AN16=RC0(B2AD), AN17=RC1(B1AD)           → ANSEL2
       AN26=RD2, AN27=RD3                       → ANSEL3
       AN28=RD4, AN29=RD5                       → ANSEL3
       注意: RD2/RD3 同时是 B11/B8 MOSFET栅极, 也是 B10AD/B9AD ADC输入
             这里设为模拟输入后会覆盖输出状态, 需要后期处理 */
    ANSEL0 |= 0xF0;     /* AN4~7=RA4~7 */
    ANSEL1 |= 0x03;     /* AN12~13=RB0~1 */
    ANSEL2 |= 0x07;     /* AN16~17=RC0~1, AN18=RC2(NTC) */
    ANSEL3 |= 0x3C;     /* AN26~29=RD2~5 */

    uart_send_string("B1-B12 ADC Test\r\n");

    unsigned int tick = 0;
    unsigned int vcc_mv;
    unsigned char bx;

    while(1)
    {
        asm("clrwdt");
        __delay_ms(10);
        tick++;
        if(tick % 200 != 0) continue;  /* 2秒一次 */
        asm("clrwdt");

        /* === 第1步: 读VCC(AN31) === */
        vcc_mv = 5000;
        test_adc = ADC_Sample(31, 0);
        if(0xA5 == test_adc)
        {
            unsigned long pt = (unsigned long)(POWER_RATIO) / adresult;
            vcc_mv = (unsigned int)pt;
        }

        /* === 第2步: 读每个Bx, 打印第一行 B1~B6 === */
        for(bx = 0; bx < 6; bx++)
        {
            unsigned char ch = bx_ch[bx];
            unsigned int ldo_adc, vx_mv;
            unsigned long bat_mv;

            /* 先用LDO=3V参考读 */
            test_adc = ADC_Sample(ch, 7);
            if(0xA5 != test_adc) goto print_ntc;
            ldo_adc = adresult;
            vx_mv = (unsigned long)ldo_adc * 3000UL / 4096UL;

            if(ldo_adc >= 4090)
            {
                /* LDO饱和 → 改用VDD参考 */
                test_adc = ADC_Sample(ch, 0);
                if(0xA5 != test_adc) goto print_ntc;
                vx_mv = (unsigned long)adresult * vcc_mv / 4096UL;

                if(adresult >= 4090)
                {
                    /* VDD读数也饱和 → 真·空槽 (V_BxAD≈VCC) */
                    uart_send_string("B");
                    uart_send_number(bx+1);
                    uart_send_string("=4095 OPEN");
                }
                else
                {
                    /* VDD读数未饱和 → 有电池但V_BxAD>3V, 双参数线性反推 */
                    bat_mv = (ALPHA_NUM * vx_mv);
                    if(bat_mv > (BETA_NUM * (unsigned long)vcc_mv))
                    {
                        bat_mv = (bat_mv - BETA_NUM * (unsigned long)vcc_mv + CAL_DEN/2) / CAL_DEN;
                        uart_send_string("B");
                        uart_send_number(bx+1);
                        uart_send_string("=");
                        uart_send_number(adresult);
                        uart_send_string(" BAT(");
                        uart_send_number((unsigned int)bat_mv);
                        uart_send_string("mV)");
                    }
                    else
                    {
                        uart_send_string("B");
                        uart_send_number(bx+1);
                        uart_send_string("=");
                        uart_send_number(adresult);
                        uart_send_string(" ???(");
                        uart_send_number((unsigned int)vx_mv);
                        uart_send_string("mV)");
                    }
                }
                uart_send_string(" ");
            }
            else
            {
                /* 未饱和 → 双参数线性反推电池电压 */
                bat_mv = (ALPHA_NUM * vx_mv);
                if(bat_mv > (BETA_NUM * (unsigned long)vcc_mv))
                {
                    bat_mv = (bat_mv - BETA_NUM * (unsigned long)vcc_mv + CAL_DEN/2) / CAL_DEN;
                    uart_send_string("B");
                    uart_send_number(bx+1);
                    uart_send_string("=");
                    uart_send_number(ldo_adc);
                    uart_send_string(" BAT(");
                    uart_send_number((unsigned int)bat_mv);
                    uart_send_string("mV) ");
                }
                else
                {
                    uart_send_string("B");
                    uart_send_number(bx+1);
                    uart_send_string("=");
                    uart_send_number(ldo_adc);
                    uart_send_string(" ???(");
                    uart_send_number((unsigned int)vx_mv);
                    uart_send_string("mV) ");
                }
            }
        }
        uart_send_string("\r\n ");
        asm("clrwdt");

        /* === 第3步: B7~B12 第二行 === */
        for(bx = 6; bx < 12; bx++)
        {
            unsigned char ch = bx_ch[bx];
            unsigned int ldo_adc, vx_mv;
            unsigned long bat_mv;

            test_adc = ADC_Sample(ch, 7);
            if(0xA5 != test_adc) goto print_ntc;
            ldo_adc = adresult;
            vx_mv = (unsigned long)ldo_adc * 3000UL / 4096UL;

            if(ldo_adc >= 4090)
            {
                test_adc = ADC_Sample(ch, 0);
                if(0xA5 != test_adc) goto print_ntc;
                vx_mv = (unsigned long)adresult * vcc_mv / 4096UL;

                if(adresult >= 4090)
                {
                    uart_send_string("B");
                    uart_send_number(bx+1);
                    uart_send_string("=4095 OPEN");
                }
                else
                {
                    bat_mv = (ALPHA_NUM * vx_mv);
                    if(bat_mv > (BETA_NUM * (unsigned long)vcc_mv))
                {
                    bat_mv = (bat_mv - BETA_NUM * (unsigned long)vcc_mv + CAL_DEN/2) / CAL_DEN;
                    uart_send_string("B");
                    uart_send_number(bx+1);
                    uart_send_string("=");
                    uart_send_number(ldo_adc);
                    uart_send_string(" BAT(");
                    uart_send_number((unsigned int)bat_mv);
                    uart_send_string("mV) ");
                }
                else
                {
                    uart_send_string("B");
                    uart_send_number(bx+1);
                    uart_send_string("=");
                    uart_send_number(ldo_adc);
                    uart_send_string(" ???(");
                    uart_send_number((unsigned int)vx_mv);
                    uart_send_string("mV) ");
                }
            }
            uart_send_string(" ");
        }
        else
        {
            /* 未饱和 → 双参数线性反推电池电压 */
            bat_mv = (ALPHA_NUM * vx_mv);
            if(bat_mv > (BETA_NUM * (unsigned long)vcc_mv))
            {
                bat_mv = (bat_mv - BETA_NUM * (unsigned long)vcc_mv + CAL_DEN/2) / CAL_DEN;
                uart_send_string("B");
                uart_send_number(bx+1);
                uart_send_string("=");
                uart_send_number(ldo_adc);
                uart_send_string(" BAT(");
                uart_send_number((unsigned int)bat_mv);
                uart_send_string("mV) ");
            }
            else
            {
                uart_send_string("B");
                uart_send_number(bx+1);
                uart_send_string("=");
                uart_send_number(ldo_adc);
                uart_send_string(" ???(");
                uart_send_number((unsigned int)vx_mv);
                uart_send_string("mV) ");
            }
        }
    }

    print_ntc:
        /* NTC(AN18=RC2), VDD参考(温度公式基于5V分压设计) */
        test_adc = ADC_Sample(18, 0);
        if(0xA5 == test_adc)
        {
            unsigned int ntc_adc = adresult;

            uart_send_string(" NTC=");
            uart_send_number(ntc_adc);

            /* NTC电路: VDD→10K→AN18(RC2)→NTC(10K@25C)→GND
               ADC≈2048@25°C, ADC<100→短路, ADC>3996→开路 */
            if(ntc_adc < 100)
            {
                uart_send_string(" T=SHORT");
            }
            else if(ntc_adc > 3996)
            {
                uart_send_string(" T=OPEN");
            }
            else
            {
                /* 分压公式: VDD(5V)→10K→RC2→NTC→GND, R_ntc = 10K * ADC / (4096-ADC)
                   CMFA103J3950: R25=10K, B=3950, dR/dT≈445Ω/°C@25°C */
                unsigned long rt = (unsigned long)ntc_adc * 10000UL / (4096UL - ntc_adc);
                unsigned int temp_x10;
                if(rt >= 10000UL)
                    temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
                else
                    temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);

                uart_send_string(" T=");
                uart_send_number(temp_x10 / 10);
                uart_send_string(".");
                uart_send_number(temp_x10 % 10);
                uart_send_string("C");
            }
        }

        uart_send_string("\r\n VCC=");
        uart_send_number(vcc_mv);
        uart_send_string("mV\r\n");

        asm("clrwdt");
    }
}

/*========================================================================
  系统初始化 - MOSFET栅极全部HIGH(关闭)
========================================================================*/
void Init_System(void)
{
    asm("nop");
    asm("clrwdt");
    OPTION_REG = 0x0F;
    asm("clrwdt");
    OSCCON = 0X70;

    WPUA = 0B00000000;
    WPUB = 0B00000000;
    WPUC = 0B00000000;
    WPUD = 0B00000000;

    /* MOSFET栅极全部HIGH(关闭)
       P沟道AO3401: Gate=High→关, Gate=Low→开
       RC2(AN18/NTC)设为模拟输入 */
    TRISA = 0xF0;  PORTA = 0x0F;
    TRISB = 0x30;  PORTB = 0x4F;
    TRISC = 0x07;  PORTC = 0x00;  /* RC2,RC1,RC0输入; RC2用于NTC */
    TRISD = 0xF0;  PORTD = 0x0F;

    CC0CON = 0;
    CC1CON = 0;

    PR2 = 249;
    TMR2IF = 0;
    TMR2IE = 1;
    T2CON = 0B00000100;
    INTCON = 0XC0;
}

void interrupt Isr_Timer(void)
{
    if(TMR2IF)
    {
        TMR2IF = 0;
    }
}
