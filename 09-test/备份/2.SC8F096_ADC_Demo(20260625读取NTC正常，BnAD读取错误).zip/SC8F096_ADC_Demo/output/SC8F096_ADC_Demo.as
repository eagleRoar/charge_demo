opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ADC_Sample
	FNCALL	_main,_AD_Init
	FNCALL	_main,_Init_System
	FNCALL	_main,___ftdiv
	FNCALL	_main,___fttol
	FNCALL	_main,___lldiv
	FNCALL	_main,___lmul
	FNCALL	_main,___lwtoft
	FNCALL	_main,_ntc_to_temp
	FNCALL	_main,_sw_uart_init
	FNCALL	_main,_uart_send_char
	FNCALL	_main,_uart_send_number
	FNCALL	_main,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_ntc_to_temp,___lldiv
	FNCALL	_ntc_to_temp,___lmul
	FNCALL	___lwtoft,___ftpack
	FNCALL	___ftdiv,___ftpack
	FNROOT	_main
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_bx_ch
psect	strings,class=STRING,delta=2,noexec
global __pstrings
__pstrings:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 1 byte each
stringcode:stringdir:
movlw high(stringdir)
movwf pclath
movf fsr,w
incf fsr
	addwf pc
	global __stringbase
__stringbase:
	retlw	0
psect	strings
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	255
_bx_ch:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_bx_ch
__end_of_bx_ch:
	global	_bx_ch
	global	_result
	global	_power_ad
	global	_test_adc
	global	_adresult
	global	_OSCCON
_OSCCON	set	20
	global	_T2CON
_T2CON	set	19
	global	_PR2
_PR2	set	17
	global	_INTCON
_INTCON	set	11
	global	_WPUB
_WPUB	set	8
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_TMR2IE
_TMR2IE	set	0x71
	global	_TMR2IF
_TMR2IF	set	0x69
	global	_GIE
_GIE	set	0x5F
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_WPUA
_WPUA	set	136
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_GODONE
_GODONE	set	0x4A9
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_TRISC2
_TRISC2	set	0x82A
	global	_RC4
_RC4	set	0x834
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_1:	
	retlw	66	;'B'
	retlw	49	;'1'
	retlw	45	;'-'
	retlw	66	;'B'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	32	;' '
	retlw	65	;'A'
	retlw	68	;'D'
	retlw	67	;'C'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	101	;'e'
	retlw	115	;'s'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	82	;'R'
	retlw	67	;'C'
	retlw	52	;'4'
	retlw	13
	retlw	10
	retlw	0
psect	strings
	
STR_5:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	40	;'('
	retlw	0
psect	strings
	
STR_4:	
	retlw	70	;'F'
	retlw	65	;'A'
	retlw	73	;'I'
	retlw	76	;'L'
	retlw	32	;' '
	retlw	0
psect	strings
	
STR_10:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	strings
	
STR_7:	
	retlw	70	;'F'
	retlw	65	;'A'
	retlw	73	;'I'
	retlw	76	;'L'
	retlw	50	;'2'
	retlw	0
psect	strings
	
STR_3:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	13
	retlw	10
	retlw	0
psect	strings
	
STR_2:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_13:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_16:	
	retlw	70	;'F'
	retlw	65	;'A'
	retlw	73	;'I'
	retlw	76	;'L'
	retlw	0
psect	strings
	
STR_6:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	strings
	
STR_14:	
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_8:	
	retlw	32	;' '
	retlw	63	;'?'
	retlw	91	;'['
	retlw	0
psect	strings
	
STR_15:	
	retlw	67	;'C'
	retlw	0
psect	strings
STR_9	equ	STR_6+0
STR_11	equ	STR_6+0
STR_12	equ	STR_1+19
STR_17	equ	STR_1+19
; #config settings
	file	"SC8F096_ADC_Demo.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_result:
       ds      2

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_power_ad:
       ds      2

_test_adc:
       ds      1

_adresult:
       ds      2

	file	"SC8F096_ADC_Demo.as"
	line	#
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
	clrf	((__pbssCOMMON)+1)&07Fh
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	((__pbssBANK0)+0)&07Fh
	clrf	((__pbssBANK0)+1)&07Fh
	clrf	((__pbssBANK0)+2)&07Fh
	clrf	((__pbssBANK0)+3)&07Fh
	clrf	((__pbssBANK0)+4)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_Init_System:	; 1 bytes @ 0x0
?_AD_Init:	; 1 bytes @ 0x0
?_sw_uart_init:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_uart_send_string:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
??_Isr_Timer:	; 1 bytes @ 0x0
	ds	2
??_Init_System:	; 1 bytes @ 0x2
??_AD_Init:	; 1 bytes @ 0x2
?_ADC_Sample:	; 1 bytes @ 0x2
??_sw_uart_init:	; 1 bytes @ 0x2
??_uart_send_char:	; 1 bytes @ 0x2
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x2
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x2
	global	?___ftpack
?___ftpack:	; 3 bytes @ 0x2
	global	?___lmul
?___lmul:	; 4 bytes @ 0x2
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x2
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x2
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x2
	global	___ftpack@arg
___ftpack@arg:	; 3 bytes @ 0x2
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x2
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x3
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x3
	ds	1
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x4
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x4
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x4
	ds	1
??_uart_send_string:	; 1 bytes @ 0x5
	global	uart_send_string@str
uart_send_string@str:	; 1 bytes @ 0x5
	global	___ftpack@exp
___ftpack@exp:	; 1 bytes @ 0x5
	ds	1
??___lwdiv:	; 1 bytes @ 0x6
??___lwmod:	; 1 bytes @ 0x6
	global	___ftpack@sign
___ftpack@sign:	; 1 bytes @ 0x6
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x6
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x6
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x6
	ds	1
??___ftpack:	; 1 bytes @ 0x7
	ds	1
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x8
	ds	2
??_uart_send_number:	; 1 bytes @ 0xA
??___lmul:	; 1 bytes @ 0xA
??___lldiv:	; 1 bytes @ 0xA
??___lwtoft:	; 1 bytes @ 0xA
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	?___lwtoft
?___lwtoft:	; 3 bytes @ 0x0
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x0
	global	___lwtoft@c
___lwtoft@c:	; 2 bytes @ 0x0
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x0
	ds	1
	global	ADC_Sample@ldo_was_off
ADC_Sample@ldo_was_off:	; 1 bytes @ 0x1
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x2
	ds	1
	global	?___ftdiv
?___ftdiv:	; 3 bytes @ 0x3
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x3
	global	___ftdiv@f2
___ftdiv@f2:	; 3 bytes @ 0x3
	ds	1
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x4
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x4
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x4
	ds	2
	global	___ftdiv@f1
___ftdiv@f1:	; 3 bytes @ 0x6
	ds	2
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x8
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x8
	ds	1
??___ftdiv:	; 1 bytes @ 0x9
	ds	1
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0xA
	ds	2
	global	___ftdiv@cntr
___ftdiv@cntr:	; 1 bytes @ 0xC
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0xC
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0xC
	ds	1
	global	___ftdiv@f3
___ftdiv@f3:	; 3 bytes @ 0xD
	ds	3
	global	___ftdiv@exp
___ftdiv@exp:	; 1 bytes @ 0x10
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x10
	ds	1
?_ntc_to_temp:	; 1 bytes @ 0x11
	global	___ftdiv@sign
___ftdiv@sign:	; 1 bytes @ 0x11
	global	ntc_to_temp@adc_val
ntc_to_temp@adc_val:	; 2 bytes @ 0x11
	ds	1
	global	?___fttol
?___fttol:	; 4 bytes @ 0x12
	global	___fttol@f1
___fttol@f1:	; 3 bytes @ 0x12
	ds	1
??_ntc_to_temp:	; 1 bytes @ 0x13
	ds	3
??___fttol:	; 1 bytes @ 0x16
	ds	1
	global	ntc_to_temp@temp
ntc_to_temp@temp:	; 1 bytes @ 0x17
	ds	1
	global	ntc_to_temp@ntc_r
ntc_to_temp@ntc_r:	; 4 bytes @ 0x18
	ds	1
	global	___fttol@sign1
___fttol@sign1:	; 1 bytes @ 0x19
	ds	1
	global	___fttol@lval
___fttol@lval:	; 4 bytes @ 0x1A
	ds	2
?_uart_send_number:	; 1 bytes @ 0x1C
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x1C
	ds	2
	global	___fttol@exp1
___fttol@exp1:	; 1 bytes @ 0x1E
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x1E
	ds	6
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0x24
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x25
	ds	1
??_main:	; 1 bytes @ 0x26
	ds	8
	global	main@tick
main@tick:	; 2 bytes @ 0x2E
	ds	2
	global	main@bat_mv
main@bat_mv:	; 4 bytes @ 0x30
	ds	4
	global	main@vx_mv
main@vx_mv:	; 4 bytes @ 0x34
	ds	4
	global	main@vcc_mv
main@vcc_mv:	; 2 bytes @ 0x38
	ds	2
	global	main@adc_raw
main@adc_raw:	; 2 bytes @ 0x3A
	ds	2
	global	main@power_temp
main@power_temp:	; 4 bytes @ 0x3C
	ds	4
	global	main@i
main@i:	; 1 bytes @ 0x40
	ds	1
;!
;!Data Sizes:
;!    Strings     81
;!    Constant    12
;!    Data        0
;!    BSS         7
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     10      12
;!    BANK0            80     65      70
;!    BANK1            80      0       0
;!    BANK3            80      0       0
;!    BANK2            80      0       0

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(1) Largest target is 22
;!		 -> STR_17(CODE[3]), STR_16(CODE[5]), STR_15(CODE[2]), STR_14(CODE[4]), 
;!		 -> STR_13(CODE[5]), STR_12(CODE[3]), STR_11(CODE[4]), STR_10(CODE[6]), 
;!		 -> STR_9(CODE[4]), STR_8(CODE[4]), STR_7(CODE[6]), STR_6(CODE[4]), 
;!		 -> STR_5(CODE[7]), STR_4(CODE[6]), STR_3(CODE[5]), STR_2(CODE[5]), 
;!		 -> STR_1(CODE[22]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    _main->___lmul
;!    _uart_send_string->_uart_send_char
;!    _ntc_to_temp->___lmul
;!    ___lldiv->___lmul
;!    ___lwtoft->___ftpack
;!    ___ftdiv->___ftpack
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    None.
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_uart_send_number
;!    _uart_send_number->_ntc_to_temp
;!    _ntc_to_temp->___lldiv
;!    ___lldiv->___lmul
;!    ___fttol->___ftdiv
;!    ___ftdiv->___lwtoft
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    None.
;!
;!Critical Paths under _main in BANK1
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 8, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                27    27      0   10252
;!                                             38 BANK0     27    27      0
;!                         _ADC_Sample
;!                            _AD_Init
;!                        _Init_System
;!                            ___ftdiv
;!                            ___fttol
;!                            ___lldiv
;!                             ___lmul
;!                           ___lwtoft
;!                        _ntc_to_temp
;!                       _sw_uart_init
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     1     1      0     573
;!                                              5 COMMON     1     1      0
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_number                                    10     8      2    1329
;!                                             28 BANK0     10     8      2
;!                            ___lwdiv
;!                            ___lwmod
;!                        _ntc_to_temp (ARG)
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0      69
;!                                              2 COMMON     3     3      0
;! ---------------------------------------------------------------------------------
;! (2) ___lwmod                                              5     1      4     265
;!                                              2 COMMON     5     1      4
;! ---------------------------------------------------------------------------------
;! (2) ___lwdiv                                              7     3      4     268
;!                                              2 COMMON     7     3      4
;! ---------------------------------------------------------------------------------
;! (1) _sw_uart_init                                         0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _ntc_to_temp                                         11     9      2    1686
;!                                             17 BANK0     11     9      2
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8     622
;!                                              2 COMMON     8     0      8
;!                                              0 BANK0      4     4      0
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8     396
;!                                              4 BANK0     13     5      8
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (1) ___lwtoft                                             3     0      3    1704
;!                                              0 BANK0      3     0      3
;!                           ___ftpack
;! ---------------------------------------------------------------------------------
;! (1) ___fttol                                             13     9      4     305
;!                                             18 BANK0     13     9      4
;!                            ___ftdiv (ARG)
;!                           ___lwtoft (ARG)
;! ---------------------------------------------------------------------------------
;! (1) ___ftdiv                                             15     9      6    2017
;!                                              3 BANK0     15     9      6
;!                           ___ftpack
;!                           ___lwtoft (ARG)
;! ---------------------------------------------------------------------------------
;! (2) ___ftpack                                             8     3      5    1629
;!                                              2 COMMON     8     3      5
;! ---------------------------------------------------------------------------------
;! (1) _Init_System                                          0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _ADC_Sample                                          19    18      1     765
;!                                              2 COMMON     5     4      1
;!                                              0 BANK0     14    14      0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 2
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (3) _Isr_Timer                                            2     2      0       0
;!                                              0 COMMON     2     2      0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 3
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ADC_Sample
;!   _AD_Init
;!   _Init_System
;!   ___ftdiv
;!     ___ftpack
;!     ___lwtoft (ARG)
;!       ___ftpack
;!   ___fttol
;!     ___ftdiv (ARG)
;!       ___ftpack
;!       ___lwtoft (ARG)
;!         ___ftpack
;!     ___lwtoft (ARG)
;!       ___ftpack
;!   ___lldiv
;!     ___lmul (ARG)
;!   ___lmul
;!   ___lwtoft
;!     ___ftpack
;!   _ntc_to_temp
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!   _sw_uart_init
;!   _uart_send_char
;!   _uart_send_number
;!     ___lwdiv
;!     ___lwmod
;!     _ntc_to_temp (ARG)
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!     _uart_send_char (ARG)
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BITCOMMON            E      0       0       0        0.0%
;!NULL                 0      0       0       0        0.0%
;!CODE                 0      0       0       0        0.0%
;!COMMON               E      A       C       1       85.7%
;!BITSFR0              0      0       0       1        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!SFR1                 0      0       0       2        0.0%
;!STACK                0      0       0       2        0.0%
;!BITBANK0            50      0       0       3        0.0%
;!BANK0               50     41      46       4       87.5%
;!BITSFR3              0      0       0       4        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITBANK1            50      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BANK1               50      0       0       6        0.0%
;!BITBANK3            50      0       0       7        0.0%
;!BANK3               50      0       0       8        0.0%
;!BITBANK2            50      0       0       9        0.0%
;!BANK2               50      0       0      10        0.0%
;!ABS                  0      0      52      11        0.0%
;!DATA                 0      0      52      12        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 261 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vx_mv           4   52[BANK0 ] unsigned long 
;;  bat_mv          4   48[BANK0 ] unsigned long 
;;  adc_raw         2   58[BANK0 ] unsigned int 
;;  i               1   64[BANK0 ] unsigned char 
;;  power_temp      4   60[BANK0 ] volatile unsigned long 
;;  vcc_mv          2   56[BANK0 ] unsigned int 
;;  tick            2   46[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      19       0       0       0
;;      Temps:          0       8       0       0       0
;;      Totals:         0      27       0       0       0
;;Total ram usage:       27 bytes
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		_AD_Init
;;		_Init_System
;;		___ftdiv
;;		___fttol
;;		___lldiv
;;		___lmul
;;		___lwtoft
;;		_ntc_to_temp
;;		_sw_uart_init
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	261
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	261
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 5
; Regs used in _main: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	263
	
l1939:	
;SC8F096_ADC.c: 263: Init_System();
	fcall	_Init_System
	line	264
;SC8F096_ADC.c: 264: AD_Init();
	fcall	_AD_Init
	line	265
	
l1941:	
;SC8F096_ADC.c: 265: sw_uart_init();
	fcall	_sw_uart_init
	line	270
	
l1943:	
;SC8F096_ADC.c: 270: TRISC2 = 1;
	bsf	(2090/8)^0100h,(2090)&7	;volatile
	line	271
	
l1945:	
;SC8F096_ADC.c: 271: ANSEL2 |= 0x04;
	bsf	(265)^0100h+(2/8),(2)&7	;volatile
	line	276
	
l1947:	
;SC8F096_ADC.c: 276: ANSEL0 |= 0xF0;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	iorwf	(147)^080h,f	;volatile
	line	277
	
l1949:	
;SC8F096_ADC.c: 277: ANSEL1 |= 0x30;
	movlw	low(030h)
	iorwf	(148)^080h,f	;volatile
	line	278
	
l1951:	
;SC8F096_ADC.c: 278: ANSEL2 |= 0x03;
	movlw	low(03h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	iorwf	(265)^0100h,f	;volatile
	line	279
	
l1953:	
;SC8F096_ADC.c: 279: ANSEL3 |= 0x30;
	movlw	low(030h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	iorwf	(140)^080h,f	;volatile
	line	281
	
l1955:	
;SC8F096_ADC.c: 281: uart_send_string("B1-B12 ADC Test RC4\r\n");
	movlw	(low((((STR_1)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	283
	
l1957:	
;SC8F096_ADC.c: 283: unsigned int tick = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(main@tick)
	clrf	(main@tick+1)
	line	285
;SC8F096_ADC.c: 285: while (1)
	
l325:	
	line	287
# 287 "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
clrwdt ;# 
psect	maintext
	line	288
	
l1959:	
;SC8F096_ADC.c: 288: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_main+0)+0+1),f
	movlw	241
movwf	((??_main+0)+0),f
	u2057:
decfsz	((??_main+0)+0),f
	goto	u2057
	decfsz	((??_main+0)+0+1),f
	goto	u2057
opt asmopt_pop

	line	290
	
l1961:	
;SC8F096_ADC.c: 290: tick++;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(main@tick),f
	skipnz
	incf	(main@tick+1),f
	line	291
	
l1963:	
;SC8F096_ADC.c: 291: if(tick < 200) continue;
	movlw	0
	subwf	(main@tick+1),w
	movlw	0C8h
	skipnz
	subwf	(main@tick),w
	skipnc
	goto	u1921
	goto	u1920
u1921:
	goto	l1967
u1920:
	goto	l325
	line	292
	
l1967:	
;SC8F096_ADC.c: 292: tick = 0;
	clrf	(main@tick)
	clrf	(main@tick+1)
	line	298
	
l1969:	
;SC8F096_ADC.c: 296: {
;SC8F096_ADC.c: 297: volatile unsigned long power_temp;
;SC8F096_ADC.c: 298: unsigned int vcc_mv = 5000;
	movlw	088h
	movwf	(main@vcc_mv)
	movlw	013h
	movwf	((main@vcc_mv))+1
	line	300
	
l1971:	
;SC8F096_ADC.c: 300: test_adc = ADC_Sample(31, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	301
	
l1973:	
;SC8F096_ADC.c: 301: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u1931
	goto	u1930
u1931:
	goto	l1979
u1930:
	line	303
	
l1975:	
;SC8F096_ADC.c: 302: {
;SC8F096_ADC.c: 303: power_temp = (unsigned long)(((4096UL*1.2*1000)) / adresult);
	movlw	0x0
	movwf	(___ftdiv@f1)
	movlw	0x96
	movwf	(___ftdiv@f1+1)
	movlw	0x4a
	movwf	(___ftdiv@f1+2)
	movf	(_adresult+1),w	;volatile
	movwf	(___lwtoft@c+1)
	movf	(_adresult),w	;volatile
	movwf	(___lwtoft@c)
	fcall	___lwtoft
	movf	(0+(?___lwtoft)),w
	movwf	(___ftdiv@f2)
	movf	(1+(?___lwtoft)),w
	movwf	(___ftdiv@f2+1)
	movf	(2+(?___lwtoft)),w
	movwf	(___ftdiv@f2+2)
	fcall	___ftdiv
	movf	(0+(?___ftdiv)),w
	movwf	(___fttol@f1)
	movf	(1+(?___ftdiv)),w
	movwf	(___fttol@f1+1)
	movf	(2+(?___ftdiv)),w
	movwf	(___fttol@f1+2)
	fcall	___fttol
	movf	(3+(?___fttol)),w
	movwf	(main@power_temp+3)	;volatile
	movf	(2+(?___fttol)),w
	movwf	(main@power_temp+2)	;volatile
	movf	(1+(?___fttol)),w
	movwf	(main@power_temp+1)	;volatile
	movf	(0+(?___fttol)),w
	movwf	(main@power_temp)	;volatile

	line	304
	
l1977:	
;SC8F096_ADC.c: 304: vcc_mv = (unsigned int)(power_temp);
	movf	(main@power_temp+1),w	;volatile
	movwf	(main@vcc_mv+1)
	movf	(main@power_temp),w	;volatile
	movwf	(main@vcc_mv)
	line	307
	
l1979:	
;SC8F096_ADC.c: 305: }
;SC8F096_ADC.c: 307: uart_send_string("VCC=");
	movlw	(low((((STR_2)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	308
	
l1981:	
;SC8F096_ADC.c: 308: uart_send_number(vcc_mv);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@vcc_mv+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@vcc_mv),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	309
	
l1983:	
;SC8F096_ADC.c: 309: uart_send_string("mV\r\n");
	movlw	(low((((STR_3)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	324
	
l1985:	
;SC8F096_ADC.c: 322: {
;SC8F096_ADC.c: 323: unsigned char i;
;SC8F096_ADC.c: 324: for(i = 0; i < 12; i++)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(main@i)
	line	330
	
l1991:	
;SC8F096_ADC.c: 325: {
;SC8F096_ADC.c: 326: unsigned int adc_raw;
;SC8F096_ADC.c: 327: unsigned long bat_mv;
;SC8F096_ADC.c: 330: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	331
	
l1993:	
;SC8F096_ADC.c: 331: if(i < 9) {
	movlw	low(09h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(main@i),w
	skipnc
	goto	u1941
	goto	u1940
u1941:
	goto	l1997
u1940:
	line	332
	
l1995:	
;SC8F096_ADC.c: 332: uart_send_char('1' + i);
	movf	(main@i),w
	addlw	031h
	fcall	_uart_send_char
	line	333
;SC8F096_ADC.c: 333: } else {
	goto	l332
	line	334
	
l1997:	
;SC8F096_ADC.c: 334: uart_send_char('1');
	movlw	low(031h)
	fcall	_uart_send_char
	line	335
;SC8F096_ADC.c: 335: uart_send_char('0' + (i - 9));
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@i),w
	addlw	027h
	fcall	_uart_send_char
	line	336
	
l332:	
	line	337
;SC8F096_ADC.c: 336: }
;SC8F096_ADC.c: 337: uart_send_char('=');
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	340
	
l1999:	
;SC8F096_ADC.c: 340: test_adc = ADC_Sample(bx_ch[i], 7);
	movlw	low(07h)
	movwf	(ADC_Sample@adldo)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@i),w
	addlw	low((((_bx_ch)-__stringbase)|8000h))
	movwf	fsr0
	fcall	stringdir
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	341
	
l2001:	
;SC8F096_ADC.c: 341: if(0xA5 != test_adc) {
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u1951
	goto	u1950
u1951:
	goto	l2011
u1950:
	line	342
	
l2003:	
;SC8F096_ADC.c: 342: uart_send_string("FAIL ");
	movlw	(low((((STR_4)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	343
	
l2005:	
;SC8F096_ADC.c: 343: ADCON0 = 0; ADCON1 = 0; _delay((unsigned long)((100)*(16000000/4000000.0)));
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(149)^080h	;volatile
	
l2007:	
	clrf	(150)^080h	;volatile
	
l2009:	
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_main+0)+0),f
	u2067:
decfsz	(??_main+0)+0,f
	goto	u2067
	nop
opt asmopt_pop

	line	344
;SC8F096_ADC.c: 344: continue;
	goto	l2053
	line	346
	
l2011:	
;SC8F096_ADC.c: 345: }
;SC8F096_ADC.c: 346: adc_raw = adresult;
	movf	(_adresult+1),w	;volatile
	movwf	(main@adc_raw+1)
	movf	(_adresult),w	;volatile
	movwf	(main@adc_raw)
	line	349
;SC8F096_ADC.c: 349: if(adc_raw >= 4090)
	movlw	0Fh
	subwf	(main@adc_raw+1),w
	movlw	0FAh
	skipnz
	subwf	(main@adc_raw),w
	skipc
	goto	u1961
	goto	u1960
u1961:
	goto	l2031
u1960:
	line	351
	
l2013:	
;SC8F096_ADC.c: 350: {
;SC8F096_ADC.c: 351: test_adc = ADC_Sample(bx_ch[i], 0);
	clrf	(ADC_Sample@adldo)
	movf	(main@i),w
	addlw	low((((_bx_ch)-__stringbase)|8000h))
	movwf	fsr0
	fcall	stringdir
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	352
	
l2015:	
;SC8F096_ADC.c: 352: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u1971
	goto	u1970
u1971:
	goto	l2029
u1970:
	line	354
	
l2017:	
;SC8F096_ADC.c: 353: {
;SC8F096_ADC.c: 354: bat_mv = (unsigned long)adresult * vcc_mv / 4096UL;
	movf	(_adresult),w	;volatile
	movwf	(___lmul@multiplier)
	movf	(_adresult+1),w	;volatile
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movf	(main@vcc_mv),w
	movwf	(___lmul@multiplicand)
	movf	(main@vcc_mv+1),w
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(main@bat_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(main@bat_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(main@bat_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(main@bat_mv)

	
l2019:	
	movlw	0Ch
u1985:
	clrc
	rrf	(main@bat_mv+3),f
	rrf	(main@bat_mv+2),f
	rrf	(main@bat_mv+1),f
	rrf	(main@bat_mv),f
	addlw	-1
	skipz
	goto	u1985

	line	355
	
l2021:	
;SC8F096_ADC.c: 355: uart_send_number(adc_raw);
	movf	(main@adc_raw+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@adc_raw),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	356
	
l2023:	
;SC8F096_ADC.c: 356: uart_send_string(" OPEN(");
	movlw	(low((((STR_5)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	357
	
l2025:	
;SC8F096_ADC.c: 357: uart_send_number((unsigned int)bat_mv);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@bat_mv+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@bat_mv),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	358
	
l2027:	
;SC8F096_ADC.c: 358: uart_send_string("mV)");
	movlw	(low((((STR_6)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	359
;SC8F096_ADC.c: 359: }
	goto	l338
	line	361
	
l2029:	
;SC8F096_ADC.c: 360: else
;SC8F096_ADC.c: 361: uart_send_string("FAIL2");
	movlw	(low((((STR_7)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l338
	line	369
	
l2031:	
;SC8F096_ADC.c: 363: else
;SC8F096_ADC.c: 364: {
;SC8F096_ADC.c: 368: unsigned long vx_mv;
;SC8F096_ADC.c: 369: vx_mv = (unsigned long)adc_raw * 3000UL / 4096UL;
	movf	(main@adc_raw),w
	movwf	(___lmul@multiplier)
	movf	(main@adc_raw+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	0Bh
	movwf	(___lmul@multiplicand+1)
	movlw	0B8h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(main@vx_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(main@vx_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(main@vx_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(main@vx_mv)

	
l2033:	
	movlw	0Ch
u1995:
	clrc
	rrf	(main@vx_mv+3),f
	rrf	(main@vx_mv+2),f
	rrf	(main@vx_mv+1),f
	rrf	(main@vx_mv),f
	addlw	-1
	skipz
	goto	u1995

	line	372
	
l2035:	
;SC8F096_ADC.c: 372: if((11UL * vx_mv) < (unsigned long)vcc_mv)
	movf	(main@vcc_mv),w
	movwf	((??_main+0)+0)
	movf	(main@vcc_mv+1),w
	movwf	((??_main+0)+0+1)
	clrf	((??_main+0)+0+2)
	clrf	((??_main+0)+0+3)
	movf	(main@vx_mv+3),w
	movwf	(___lmul@multiplier+3)
	movf	(main@vx_mv+2),w
	movwf	(___lmul@multiplier+2)
	movf	(main@vx_mv+1),w
	movwf	(___lmul@multiplier+1)
	movf	(main@vx_mv),w
	movwf	(___lmul@multiplier)

	movlw	0Bh
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	3+(??_main+0)+0,w
	subwf	(3+(?___lmul)),w
	skipz
	goto	u2005
	movf	2+(??_main+0)+0,w
	subwf	(2+(?___lmul)),w
	skipz
	goto	u2005
	movf	1+(??_main+0)+0,w
	subwf	(1+(?___lmul)),w
	skipz
	goto	u2005
	movf	0+(??_main+0)+0,w
	subwf	(0+(?___lmul)),w
u2005:
	skipnc
	goto	u2001
	goto	u2000
u2001:
	goto	l2039
u2000:
	line	374
	
l2037:	
;SC8F096_ADC.c: 373: {
;SC8F096_ADC.c: 374: uart_send_number(adc_raw);
	movf	(main@adc_raw+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@adc_raw),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	375
;SC8F096_ADC.c: 375: uart_send_string(" ?[");
	movlw	(low((((STR_8)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	376
;SC8F096_ADC.c: 376: uart_send_number((unsigned int)vx_mv);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@vx_mv+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@vx_mv),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	377
;SC8F096_ADC.c: 377: uart_send_string("mV)");
	movlw	(low((((STR_9)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	378
;SC8F096_ADC.c: 378: }
	goto	l338
	line	381
	
l2039:	
;SC8F096_ADC.c: 379: else
;SC8F096_ADC.c: 380: {
;SC8F096_ADC.c: 381: bat_mv = (11UL * vx_mv - (unsigned long)vcc_mv) / 10UL;
	movlw	0Ah
	movwf	(___lldiv@divisor)
	clrf	(___lldiv@divisor+1)
	clrf	(___lldiv@divisor+2)
	clrf	(___lldiv@divisor+3)

	movf	(main@vcc_mv),w
	movwf	((??_main+0)+0)
	movf	(main@vcc_mv+1),w
	movwf	((??_main+0)+0+1)
	clrf	((??_main+0)+0+2)
	clrf	((??_main+0)+0+3)
	movf	(main@vx_mv+3),w
	movwf	(___lmul@multiplier+3)
	movf	(main@vx_mv+2),w
	movwf	(___lmul@multiplier+2)
	movf	(main@vx_mv+1),w
	movwf	(___lmul@multiplier+1)
	movf	(main@vx_mv),w
	movwf	(___lmul@multiplier)

	movlw	0Bh
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(0+?___lmul),w
	movwf	(??_main+4)+0
	movf	(1+?___lmul),w
	movwf	((??_main+4)+0+1)
	movf	(2+?___lmul),w
	movwf	((??_main+4)+0+2)
	movf	(3+?___lmul),w
	movwf	((??_main+4)+0+3)
	movf	0+(??_main+0)+0,w
	subwf	(??_main+4)+0,f
	movf	1+(??_main+0)+0,w
	skipc
	incfsz	1+(??_main+0)+0,w
	goto	u2011
	goto	u2012
u2011:
	subwf	(??_main+4)+1,f
u2012:
	movf	2+(??_main+0)+0,w
	skipc
	incfsz	2+(??_main+0)+0,w
	goto	u2013
	goto	u2014
u2013:
	subwf	(??_main+4)+2,f
u2014:
	movf	3+(??_main+0)+0,w
	skipc
	incfsz	3+(??_main+0)+0,w
	goto	u2015
	goto	u2016
u2015:
	subwf	(??_main+4)+3,f
u2016:

	movf	3+(??_main+4)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_main+4)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_main+4)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_main+4)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(main@bat_mv+3)
	movf	(2+(?___lldiv)),w
	movwf	(main@bat_mv+2)
	movf	(1+(?___lldiv)),w
	movwf	(main@bat_mv+1)
	movf	(0+(?___lldiv)),w
	movwf	(main@bat_mv)

	line	382
	
l2041:	
;SC8F096_ADC.c: 382: uart_send_number(adc_raw);
	movf	(main@adc_raw+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@adc_raw),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	383
	
l2043:	
;SC8F096_ADC.c: 383: uart_send_string(" BAT(");
	movlw	(low((((STR_10)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	384
	
l2045:	
;SC8F096_ADC.c: 384: uart_send_number((unsigned int)bat_mv);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@bat_mv+1),w
	movwf	(uart_send_number@num+1)
	movf	(main@bat_mv),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	385
	
l2047:	
;SC8F096_ADC.c: 385: uart_send_string("mV)");
	movlw	(low((((STR_11)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	387
	
l338:	
	line	388
;SC8F096_ADC.c: 386: }
;SC8F096_ADC.c: 387: }
;SC8F096_ADC.c: 388: uart_send_char(' ');
	movlw	low(020h)
	fcall	_uart_send_char
	line	391
	
l2049:	
;SC8F096_ADC.c: 391: if(i == 5) uart_send_string("\r\n");
		movlw	5
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	xorwf	((main@i)),w
	btfss	status,2
	goto	u2021
	goto	u2020
u2021:
	goto	l2053
u2020:
	
l2051:	
	movlw	(low((((STR_12)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	324
	
l2053:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(main@i),f
	
l2055:	
	movlw	low(0Ch)
	subwf	(main@i),w
	skipc
	goto	u2031
	goto	u2030
u2031:
	goto	l1991
u2030:
	line	396
	
l2057:	
;SC8F096_ADC.c: 392: }
;SC8F096_ADC.c: 393: }
;SC8F096_ADC.c: 396: uart_send_string("NTC=");
	movlw	(low((((STR_13)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	397
	
l2059:	
;SC8F096_ADC.c: 397: test_adc = ADC_Sample(18, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	398
	
l2061:	
;SC8F096_ADC.c: 398: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u2041
	goto	u2040
u2041:
	goto	l2065
u2040:
	line	400
	
l2063:	
;SC8F096_ADC.c: 399: {
;SC8F096_ADC.c: 400: uart_send_number(adresult);
	movf	(_adresult+1),w	;volatile
	movwf	(uart_send_number@num+1)
	movf	(_adresult),w	;volatile
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	401
;SC8F096_ADC.c: 401: uart_send_string(" T=");
	movlw	(low((((STR_14)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	402
;SC8F096_ADC.c: 402: uart_send_number(ntc_to_temp(adresult));
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_adresult+1),w	;volatile
	movwf	(ntc_to_temp@adc_val+1)
	movf	(_adresult),w	;volatile
	movwf	(ntc_to_temp@adc_val)
	fcall	_ntc_to_temp
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	403
;SC8F096_ADC.c: 403: uart_send_string("C");
	movlw	(low((((STR_15)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	404
;SC8F096_ADC.c: 404: }
	goto	l2073
	line	407
	
l2065:	
;SC8F096_ADC.c: 405: else
;SC8F096_ADC.c: 406: {
;SC8F096_ADC.c: 407: uart_send_string("FAIL");
	movlw	(low((((STR_16)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	408
	
l2067:	
;SC8F096_ADC.c: 408: ADCON0 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(149)^080h	;volatile
	line	409
	
l2069:	
;SC8F096_ADC.c: 409: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	410
	
l2071:	
;SC8F096_ADC.c: 410: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_main+0)+0),f
	u2077:
decfsz	(??_main+0)+0,f
	goto	u2077
	nop
opt asmopt_pop

	line	414
	
l2073:	
;SC8F096_ADC.c: 411: }
;SC8F096_ADC.c: 412: }
;SC8F096_ADC.c: 414: uart_send_string("\r\n");
	movlw	(low((((STR_17)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l325
	global	start
	ljmp	start
	opt stack 0
	line	417
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 179 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;  str             1    wreg     PTR const unsigned char 
;;		 -> STR_17(3), STR_16(5), STR_15(2), STR_14(4), 
;;		 -> STR_13(5), STR_12(3), STR_11(4), STR_10(6), 
;;		 -> STR_9(4), STR_8(4), STR_7(6), STR_6(4), 
;;		 -> STR_5(7), STR_4(6), STR_3(5), STR_2(5), 
;;		 -> STR_1(22), 
;; Auto vars:     Size  Location     Type
;;  str             1    5[COMMON] PTR const unsigned char 
;;		 -> STR_17(3), STR_16(5), STR_15(2), STR_14(4), 
;;		 -> STR_13(5), STR_12(3), STR_11(4), STR_10(6), 
;;		 -> STR_9(4), STR_8(4), STR_7(6), STR_6(4), 
;;		 -> STR_5(7), STR_4(6), STR_3(5), STR_2(5), 
;;		 -> STR_1(22), 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/100
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         1       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	179
global __ptext1
__ptext1:	;psect for function _uart_send_string
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	179
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 5
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;uart_send_string@str stored from wreg
	movwf	(uart_send_string@str)
	line	181
	
l1515:	
;SC8F096_ADC.c: 181: while(*str != '\0')
	goto	l1521
	line	182
	
l1517:	
;SC8F096_ADC.c: 182: uart_send_char(*str++);
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringdir
	fcall	_uart_send_char
	
l1519:	
	incf	(uart_send_string@str),f
	line	181
	
l1521:	
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringdir
	xorlw	0
	skipz
	goto	u1311
	goto	u1310
u1311:
	goto	l1517
u1310:
	line	183
	
l277:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 190 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;  num             2   28[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6   30[BANK0 ] unsigned char [6]
;;  j               1   37[BANK0 ] unsigned char 
;;  i               1   36[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      10       0       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	line	190
global __ptext2
__ptext2:	;psect for function _uart_send_number
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	190
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 5
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	193
	
l1523:	
;SC8F096_ADC.c: 192: unsigned char buf[6];
;SC8F096_ADC.c: 193: unsigned char i = 0;
	clrf	(uart_send_number@i)
	line	196
	
l1525:	
;SC8F096_ADC.c: 194: unsigned char j;
;SC8F096_ADC.c: 196: if(num == 0)
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u1321
	goto	u1320
u1321:
	goto	l1537
u1320:
	line	198
	
l1527:	
;SC8F096_ADC.c: 197: {
;SC8F096_ADC.c: 198: uart_send_char('0');
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l281
	line	204
	
l1531:	
;SC8F096_ADC.c: 203: {
;SC8F096_ADC.c: 204: buf[i++] = '0' + (num % 10);
	movf	(uart_send_number@i),w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwmod@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank0
	movwf	indf
	
l1533:	
	incf	(uart_send_number@i),f
	line	205
	
l1535:	
;SC8F096_ADC.c: 205: num /= 10;
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(uart_send_number@num+1)
	movf	(0+(?___lwdiv)),w
	movwf	(uart_send_number@num)
	line	202
	
l1537:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u1331
	goto	u1330
u1331:
	goto	l1531
u1330:
	line	208
	
l1539:	
;SC8F096_ADC.c: 206: }
;SC8F096_ADC.c: 208: for(j = i; j > 0; j--)
	movf	(uart_send_number@i),w
	movwf	(uart_send_number@j)
	
l1541:	
	movf	((uart_send_number@j)),w
	btfss	status,2
	goto	u1341
	goto	u1340
u1341:
	goto	l1545
u1340:
	goto	l281
	line	209
	
l1545:	
;SC8F096_ADC.c: 209: uart_send_char(buf[j-1]);
	movf	(uart_send_number@j),w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	fcall	_uart_send_char
	line	208
	
l1547:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decf	(uart_send_number@j),f
	goto	l1541
	line	210
	
l281:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 146 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1    3[COMMON] unsigned char 
;;  i               1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          1       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_string
;;		_uart_send_number
;;		_main
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	line	146
global __ptext3
__ptext3:	;psect for function _uart_send_char
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	146
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 5
; Regs used in _uart_send_char: [wreg+status,2+status,0]
;uart_send_char@c stored from wreg
	movwf	(uart_send_char@c)
	line	150
	
l1307:	
;SC8F096_ADC.c: 148: unsigned char i;
;SC8F096_ADC.c: 150: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	153
;SC8F096_ADC.c: 153: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	154
	
l1309:	
;SC8F096_ADC.c: 154: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u2087:
decfsz	(??_uart_send_char+0)+0,f
	goto	u2087
	nop
opt asmopt_pop

	line	157
	
l1311:	
;SC8F096_ADC.c: 157: for(i = 0; i < 8; i++)
	clrf	(uart_send_char@i)
	line	158
	
l267:	
	line	159
;SC8F096_ADC.c: 158: {
;SC8F096_ADC.c: 159: if(c & 0x01)
	btfss	(uart_send_char@c),(0)&7
	goto	u891
	goto	u890
u891:
	goto	l269
u890:
	line	160
	
l1317:	
;SC8F096_ADC.c: 160: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l1319
	line	161
	
l269:	
	line	162
;SC8F096_ADC.c: 161: else
;SC8F096_ADC.c: 162: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	163
	
l1319:	
;SC8F096_ADC.c: 163: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u2097:
decfsz	(??_uart_send_char+0)+0,f
	goto	u2097
	nop
opt asmopt_pop

	line	164
	
l1321:	
;SC8F096_ADC.c: 164: c >>= 1;
	clrc
	rrf	(uart_send_char@c),f
	line	157
	
l1323:	
	incf	(uart_send_char@i),f
	
l1325:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u901
	goto	u900
u901:
	goto	l267
u900:
	
l268:	
	line	168
;SC8F096_ADC.c: 165: }
;SC8F096_ADC.c: 168: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	169
	
l1327:	
;SC8F096_ADC.c: 169: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u2107:
decfsz	(??_uart_send_char+0)+0,f
	goto	u2107
	nop
opt asmopt_pop

	line	171
	
l1329:	
;SC8F096_ADC.c: 171: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	172
	
l271:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] unsigned int 
;;  dividend        2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext4
__ptext4:	;psect for function ___lwmod
psect	text4
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 5
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l1419:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u1101
	goto	u1100
u1101:
	goto	l1435
u1100:
	line	14
	
l1421:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l1425
	line	16
	
l1423:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l1425:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u1111
	goto	u1110
u1111:
	goto	l1423
u1110:
	line	20
	
l1427:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u1125
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u1125:
	skipc
	goto	u1121
	goto	u1120
u1121:
	goto	l1431
u1120:
	line	21
	
l1429:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l1431:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l1433:	
	decfsz	(___lwmod@counter),f
	goto	u1131
	goto	u1130
u1131:
	goto	l1427
u1130:
	line	25
	
l1435:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l710:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] unsigned int 
;;  dividend        2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] unsigned int 
;;  counter         1    8[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : B00/0
;;		Unchanged: B00/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         3       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         7       0       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext5
__ptext5:	;psect for function ___lwdiv
psect	text5
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 5
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l1393:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l1395:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u1061
	goto	u1060
u1061:
	goto	l1415
u1060:
	line	16
	
l1397:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l1401
	line	18
	
l1399:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l1401:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u1071
	goto	u1070
u1071:
	goto	l1399
u1070:
	line	22
	
l1403:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l1405:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u1085
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u1085:
	skipc
	goto	u1081
	goto	u1080
u1081:
	goto	l1411
u1080:
	line	24
	
l1407:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l1409:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l1411:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l1413:	
	decfsz	(___lwdiv@counter),f
	goto	u1091
	goto	u1090
u1091:
	goto	l1403
u1090:
	line	30
	
l1415:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l700:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	_sw_uart_init

;; *************** function _sw_uart_init *****************
;; Defined at:
;;		line 132 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	132
global __ptext6
__ptext6:	;psect for function _sw_uart_init
psect	text6
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	132
	global	__size_of_sw_uart_init
	__size_of_sw_uart_init	equ	__end_of_sw_uart_init-_sw_uart_init
	
_sw_uart_init:	
;incstack = 0
	opt	stack 6
; Regs used in _sw_uart_init: []
	line	134
	
l1513:	
;SC8F096_ADC.c: 134: TRISC &= ~0x10;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	135
;SC8F096_ADC.c: 135: ANSEL2 &= ~0x10;
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	136
;SC8F096_ADC.c: 136: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	137
	
l264:	
	return
	opt stack 0
GLOBAL	__end_of_sw_uart_init
	__end_of_sw_uart_init:
	signat	_sw_uart_init,89
	global	_ntc_to_temp

;; *************** function _ntc_to_temp *****************
;; Defined at:
;;		line 222 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;  adc_val         2   17[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  ntc_r           4   24[BANK0 ] unsigned long 
;;  temp            1   23[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      11       0       0       0
;;Total ram usage:       11 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	line	222
global __ptext7
__ptext7:	;psect for function _ntc_to_temp
psect	text7
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	222
	global	__size_of_ntc_to_temp
	__size_of_ntc_to_temp	equ	__end_of_ntc_to_temp-_ntc_to_temp
	
_ntc_to_temp:	
;incstack = 0
	opt	stack 5
; Regs used in _ntc_to_temp: [wreg+status,2+status,0+pclath+cstack]
	line	228
	
l1873:	
;SC8F096_ADC.c: 224: unsigned long ntc_r;
;SC8F096_ADC.c: 225: unsigned char temp;
;SC8F096_ADC.c: 228: if(adc_val == 0 || adc_val >= 4095)
	movf	((ntc_to_temp@adc_val)),w
iorwf	((ntc_to_temp@adc_val+1)),w
	btfsc	status,2
	goto	u1761
	goto	u1760
u1761:
	goto	l1877
u1760:
	
l1875:	
	movlw	0Fh
	subwf	(ntc_to_temp@adc_val+1),w
	movlw	0FFh
	skipnz
	subwf	(ntc_to_temp@adc_val),w
	skipc
	goto	u1771
	goto	u1770
u1771:
	goto	l1881
u1770:
	line	229
	
l1877:	
;SC8F096_ADC.c: 229: return 25;
	movlw	low(019h)
	goto	l292
	line	232
	
l1881:	
;SC8F096_ADC.c: 232: ntc_r = (unsigned long)adc_val * 10000UL / (4096UL - adc_val);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	010h
	movwf	(___lldiv@divisor+1)
	movlw	0
	movwf	(___lldiv@divisor)

	movf	(ntc_to_temp@adc_val),w
	movwf	((??_ntc_to_temp+0)+0)
	movf	(ntc_to_temp@adc_val+1),w
	movwf	((??_ntc_to_temp+0)+0+1)
	clrf	((??_ntc_to_temp+0)+0+2)
	clrf	((??_ntc_to_temp+0)+0+3)
	movf	0+(??_ntc_to_temp+0)+0,w
	subwf	(___lldiv@divisor),f
	movf	1+(??_ntc_to_temp+0)+0,w
	skipc
	incfsz	1+(??_ntc_to_temp+0)+0,w
	goto	u1785
	goto	u1786
u1785:
	subwf	(___lldiv@divisor+1),f
u1786:
	movf	2+(??_ntc_to_temp+0)+0,w
	skipc
	incfsz	2+(??_ntc_to_temp+0)+0,w
	goto	u1787
	goto	u1788
u1787:
	subwf	(___lldiv@divisor+2),f
u1788:
	movf	3+(??_ntc_to_temp+0)+0,w
	skipc
	incfsz	3+(??_ntc_to_temp+0)+0,w
	goto	u1789
	goto	u1780
u1789:
	subwf	(___lldiv@divisor+3),f
u1780:

	movf	(ntc_to_temp@adc_val),w
	movwf	(___lmul@multiplier)
	movf	(ntc_to_temp@adc_val+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	027h
	movwf	(___lmul@multiplicand+1)
	movlw	010h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(ntc_to_temp@ntc_r+3)
	movf	(2+(?___lldiv)),w
	movwf	(ntc_to_temp@ntc_r+2)
	movf	(1+(?___lldiv)),w
	movwf	(ntc_to_temp@ntc_r+1)
	movf	(0+(?___lldiv)),w
	movwf	(ntc_to_temp@ntc_r)

	line	235
	
l1883:	
;SC8F096_ADC.c: 235: if(ntc_r > 22000) temp = 10;
		movf	(ntc_to_temp@ntc_r+3),w
	btfss	status,2
	goto	u1790
	movf	(ntc_to_temp@ntc_r+2),w
	btfss	status,2
	goto	u1790
	movlw	85
	subwf	(ntc_to_temp@ntc_r+1),w
	skipz
	goto	u1793
	movlw	241
	subwf	(ntc_to_temp@ntc_r),w
	skipz
	goto	u1793
u1793:
	btfss	status,0
	goto	u1791
	goto	u1790

u1791:
	goto	l1887
u1790:
	
l1885:	
	movlw	low(0Ah)
	movwf	(ntc_to_temp@temp)
	goto	l294
	line	236
	
l1887:	
;SC8F096_ADC.c: 236: else if(ntc_r > 15800) temp = 15;
		movf	(ntc_to_temp@ntc_r+3),w
	btfss	status,2
	goto	u1800
	movf	(ntc_to_temp@ntc_r+2),w
	btfss	status,2
	goto	u1800
	movlw	61
	subwf	(ntc_to_temp@ntc_r+1),w
	skipz
	goto	u1803
	movlw	185
	subwf	(ntc_to_temp@ntc_r),w
	skipz
	goto	u1803
u1803:
	btfss	status,0
	goto	u1801
	goto	u1800

u1801:
	goto	l1891
u1800:
	
l1889:	
	movlw	low(0Fh)
	movwf	(ntc_to_temp@temp)
	goto	l294
	line	237
	
l1891:	
;SC8F096_ADC.c: 237: else if(ntc_r > 12500) temp = 20;
		movf	(ntc_to_temp@ntc_r+3),w
	btfss	status,2
	goto	u1810
	movf	(ntc_to_temp@ntc_r+2),w
	btfss	status,2
	goto	u1810
	movlw	48
	subwf	(ntc_to_temp@ntc_r+1),w
	skipz
	goto	u1813
	movlw	213
	subwf	(ntc_to_temp@ntc_r),w
	skipz
	goto	u1813
u1813:
	btfss	status,0
	goto	u1811
	goto	u1810

u1811:
	goto	l1895
u1810:
	
l1893:	
	movlw	low(014h)
	movwf	(ntc_to_temp@temp)
	goto	l294
	line	238
	
l1895:	
;SC8F096_ADC.c: 238: else if(ntc_r > 10000) temp = 25;
		movf	(ntc_to_temp@ntc_r+3),w
	btfss	status,2
	goto	u1820
	movf	(ntc_to_temp@ntc_r+2),w
	btfss	status,2
	goto	u1820
	movlw	39
	subwf	(ntc_to_temp@ntc_r+1),w
	skipz
	goto	u1823
	movlw	17
	subwf	(ntc_to_temp@ntc_r),w
	skipz
	goto	u1823
u1823:
	btfss	status,0
	goto	u1821
	goto	u1820

u1821:
	goto	l1899
u1820:
	
l1897:	
	movlw	low(019h)
	movwf	(ntc_to_temp@temp)
	goto	l294
	line	239
	
l1899:	
;SC8F096_ADC.c: 239: else if(ntc_r > 8050) temp = 30;
		movf	(ntc_to_temp@ntc_r+3),w
	btfss	status,2
	goto	u1830
	movf	(ntc_to_temp@ntc_r+2),w
	btfss	status,2
	goto	u1830
	movlw	31
	subwf	(ntc_to_temp@ntc_r+1),w
	skipz
	goto	u1833
	movlw	115
	subwf	(ntc_to_temp@ntc_r),w
	skipz
	goto	u1833
u1833:
	btfss	status,0
	goto	u1831
	goto	u1830

u1831:
	goto	l1903
u1830:
	
l1901:	
	movlw	low(01Eh)
	movwf	(ntc_to_temp@temp)
	goto	l294
	line	240
	
l1903:	
;SC8F096_ADC.c: 240: else if(ntc_r > 6590) temp = 35;
		movf	(ntc_to_temp@ntc_r+3),w
	btfss	status,2
	goto	u1840
	movf	(ntc_to_temp@ntc_r+2),w
	btfss	status,2
	goto	u1840
	movlw	25
	subwf	(ntc_to_temp@ntc_r+1),w
	skipz
	goto	u1843
	movlw	191
	subwf	(ntc_to_temp@ntc_r),w
	skipz
	goto	u1843
u1843:
	btfss	status,0
	goto	u1841
	goto	u1840

u1841:
	goto	l1907
u1840:
	
l1905:	
	movlw	low(023h)
	movwf	(ntc_to_temp@temp)
	goto	l294
	line	241
	
l1907:	
;SC8F096_ADC.c: 241: else if(ntc_r > 5460) temp = 40;
		movf	(ntc_to_temp@ntc_r+3),w
	btfss	status,2
	goto	u1850
	movf	(ntc_to_temp@ntc_r+2),w
	btfss	status,2
	goto	u1850
	movlw	21
	subwf	(ntc_to_temp@ntc_r+1),w
	skipz
	goto	u1853
	movlw	85
	subwf	(ntc_to_temp@ntc_r),w
	skipz
	goto	u1853
u1853:
	btfss	status,0
	goto	u1851
	goto	u1850

u1851:
	goto	l1911
u1850:
	
l1909:	
	movlw	low(028h)
	movwf	(ntc_to_temp@temp)
	goto	l294
	line	242
	
l1911:	
;SC8F096_ADC.c: 242: else if(ntc_r > 4570) temp = 45;
		movf	(ntc_to_temp@ntc_r+3),w
	btfss	status,2
	goto	u1860
	movf	(ntc_to_temp@ntc_r+2),w
	btfss	status,2
	goto	u1860
	movlw	17
	subwf	(ntc_to_temp@ntc_r+1),w
	skipz
	goto	u1863
	movlw	219
	subwf	(ntc_to_temp@ntc_r),w
	skipz
	goto	u1863
u1863:
	btfss	status,0
	goto	u1861
	goto	u1860

u1861:
	goto	l1915
u1860:
	
l1913:	
	movlw	low(02Dh)
	movwf	(ntc_to_temp@temp)
	goto	l294
	line	243
	
l1915:	
;SC8F096_ADC.c: 243: else if(ntc_r > 3870) temp = 50;
		movf	(ntc_to_temp@ntc_r+3),w
	btfss	status,2
	goto	u1870
	movf	(ntc_to_temp@ntc_r+2),w
	btfss	status,2
	goto	u1870
	movlw	15
	subwf	(ntc_to_temp@ntc_r+1),w
	skipz
	goto	u1873
	movlw	31
	subwf	(ntc_to_temp@ntc_r),w
	skipz
	goto	u1873
u1873:
	btfss	status,0
	goto	u1871
	goto	u1870

u1871:
	goto	l1919
u1870:
	
l1917:	
	movlw	low(032h)
	movwf	(ntc_to_temp@temp)
	goto	l294
	line	244
	
l1919:	
;SC8F096_ADC.c: 244: else if(ntc_r > 3300) temp = 55;
		movf	(ntc_to_temp@ntc_r+3),w
	btfss	status,2
	goto	u1880
	movf	(ntc_to_temp@ntc_r+2),w
	btfss	status,2
	goto	u1880
	movlw	12
	subwf	(ntc_to_temp@ntc_r+1),w
	skipz
	goto	u1883
	movlw	229
	subwf	(ntc_to_temp@ntc_r),w
	skipz
	goto	u1883
u1883:
	btfss	status,0
	goto	u1881
	goto	u1880

u1881:
	goto	l1923
u1880:
	
l1921:	
	movlw	low(037h)
	movwf	(ntc_to_temp@temp)
	goto	l294
	line	245
	
l1923:	
;SC8F096_ADC.c: 245: else if(ntc_r > 2840) temp = 60;
		movf	(ntc_to_temp@ntc_r+3),w
	btfss	status,2
	goto	u1890
	movf	(ntc_to_temp@ntc_r+2),w
	btfss	status,2
	goto	u1890
	movlw	11
	subwf	(ntc_to_temp@ntc_r+1),w
	skipz
	goto	u1893
	movlw	25
	subwf	(ntc_to_temp@ntc_r),w
	skipz
	goto	u1893
u1893:
	btfss	status,0
	goto	u1891
	goto	u1890

u1891:
	goto	l1927
u1890:
	
l1925:	
	movlw	low(03Ch)
	movwf	(ntc_to_temp@temp)
	goto	l294
	line	246
	
l1927:	
;SC8F096_ADC.c: 246: else if(ntc_r > 2460) temp = 65;
		movf	(ntc_to_temp@ntc_r+3),w
	btfss	status,2
	goto	u1900
	movf	(ntc_to_temp@ntc_r+2),w
	btfss	status,2
	goto	u1900
	movlw	9
	subwf	(ntc_to_temp@ntc_r+1),w
	skipz
	goto	u1903
	movlw	157
	subwf	(ntc_to_temp@ntc_r),w
	skipz
	goto	u1903
u1903:
	btfss	status,0
	goto	u1901
	goto	u1900

u1901:
	goto	l1931
u1900:
	
l1929:	
	movlw	low(041h)
	movwf	(ntc_to_temp@temp)
	goto	l294
	line	247
	
l1931:	
;SC8F096_ADC.c: 247: else if(ntc_r > 2140) temp = 70;
		movf	(ntc_to_temp@ntc_r+3),w
	btfss	status,2
	goto	u1910
	movf	(ntc_to_temp@ntc_r+2),w
	btfss	status,2
	goto	u1910
	movlw	8
	subwf	(ntc_to_temp@ntc_r+1),w
	skipz
	goto	u1913
	movlw	93
	subwf	(ntc_to_temp@ntc_r),w
	skipz
	goto	u1913
u1913:
	btfss	status,0
	goto	u1911
	goto	u1910

u1911:
	goto	l1935
u1910:
	
l1933:	
	movlw	low(046h)
	movwf	(ntc_to_temp@temp)
	goto	l294
	line	248
	
l1935:	
;SC8F096_ADC.c: 248: else temp = 75;
	movlw	low(04Bh)
	movwf	(ntc_to_temp@temp)
	
l294:	
	line	250
;SC8F096_ADC.c: 250: return temp;
	movf	(ntc_to_temp@temp),w
	line	251
	
l292:	
	return
	opt stack 0
GLOBAL	__end_of_ntc_to_temp
	__end_of_ntc_to_temp:
	signat	_ntc_to_temp,4217
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    2[COMMON] unsigned long 
;;  multiplicand    4    6[COMMON] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    0[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    2[COMMON] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         8       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       4       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ntc_to_temp
;;		_main
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext8
__ptext8:	;psect for function ___lmul
psect	text8
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 5
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l1331:	
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l372:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u911
	goto	u910
u911:
	goto	l1335
u910:
	line	122
	
l1333:	
	movf	(___lmul@multiplicand),w
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u921
	addwf	(___lmul@product+1),f
u921:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u922
	addwf	(___lmul@product+2),f
u922:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u923
	addwf	(___lmul@product+3),f
u923:

	line	123
	
l1335:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l1337:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u931
	goto	u930
u931:
	goto	l372
u930:
	line	128
	
l1339:	
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l375:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    4[BANK0 ] unsigned long 
;;  dividend        4    8[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   12[BANK0 ] unsigned long 
;;  counter         1   16[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    4[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      13       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ntc_to_temp
;;		_main
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext9
__ptext9:	;psect for function ___lldiv
psect	text9
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 5
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l1367:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l1369:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u1021
	goto	u1020
u1021:
	goto	l1389
u1020:
	line	16
	
l1371:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l1375
	line	18
	
l1373:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l1375:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u1031
	goto	u1030
u1031:
	goto	l1373
u1030:
	line	22
	
l1377:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l1379:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u1045
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u1045
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u1045
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u1045:
	skipc
	goto	u1041
	goto	u1040
u1041:
	goto	l1385
u1040:
	line	24
	
l1381:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l1383:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l1385:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l1387:	
	decfsz	(___lldiv@counter),f
	goto	u1051
	goto	u1050
u1051:
	goto	l1377
u1050:
	line	30
	
l1389:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l647:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	___lwtoft

;; *************** function ___lwtoft *****************
;; Defined at:
;;		line 28 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwtoft.c"
;; Parameters:    Size  Location     Type
;;  c               2    0[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  3    0[BANK0 ] float 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       3       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		___ftpack
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwtoft.c"
	line	28
global __ptext10
__ptext10:	;psect for function ___lwtoft
psect	text10
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwtoft.c"
	line	28
	global	__size_of___lwtoft
	__size_of___lwtoft	equ	__end_of___lwtoft-___lwtoft
	
___lwtoft:	
;incstack = 0
	opt	stack 5
; Regs used in ___lwtoft: [wreg+status,2+status,0+pclath+cstack]
	line	30
	
l1733:	
	movf	(___lwtoft@c),w
	movwf	(___ftpack@arg)
	movf	(___lwtoft@c+1),w
	movwf	(___ftpack@arg+1)
	clrf	(___ftpack@arg+2)
	movlw	low(08Eh)
	movwf	(___ftpack@exp)
	clrf	(___ftpack@sign)
	fcall	___ftpack
	movf	(0+(?___ftpack)),w
	movwf	(?___lwtoft)
	movf	(1+(?___ftpack)),w
	movwf	(?___lwtoft+1)
	movf	(2+(?___ftpack)),w
	movwf	(?___lwtoft+2)
	line	31
	
l715:	
	return
	opt stack 0
GLOBAL	__end_of___lwtoft
	__end_of___lwtoft:
	signat	___lwtoft,4219
	global	___fttol

;; *************** function ___fttol *****************
;; Defined at:
;;		line 44 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\fttol.c"
;; Parameters:    Size  Location     Type
;;  f1              3   18[BANK0 ] float 
;; Auto vars:     Size  Location     Type
;;  lval            4   26[BANK0 ] unsigned long 
;;  exp1            1   30[BANK0 ] unsigned char 
;;  sign1           1   25[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4   18[BANK0 ] long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       6       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0      13       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\fttol.c"
	line	44
global __ptext11
__ptext11:	;psect for function ___fttol
psect	text11
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\fttol.c"
	line	44
	global	__size_of___fttol
	__size_of___fttol	equ	__end_of___fttol-___fttol
	
___fttol:	
;incstack = 0
	opt	stack 6
; Regs used in ___fttol: [wreg+status,2+status,0]
	line	49
	
l1693:	
	movf	(___fttol@f1),w
	movwf	((??___fttol+0)+0)
	movf	(___fttol@f1+1),w
	movwf	((??___fttol+0)+0+1)
	movf	(___fttol@f1+2),w
	movwf	((??___fttol+0)+0+2)
	clrc
	rlf	(??___fttol+0)+1,w
	rlf	(??___fttol+0)+2,w
	movwf	(___fttol@exp1)
	movf	(((___fttol@exp1))),w
	btfss	status,2
	goto	u1551
	goto	u1550
u1551:
	goto	l1697
u1550:
	line	50
	
l1695:	
	clrf	(?___fttol)
	clrf	(?___fttol+1)
	clrf	(?___fttol+2)
	clrf	(?___fttol+3)
	goto	l606
	line	51
	
l1697:	
	movf	(___fttol@f1),w
	movwf	((??___fttol+0)+0)
	movf	(___fttol@f1+1),w
	movwf	((??___fttol+0)+0+1)
	movf	(___fttol@f1+2),w
	movwf	((??___fttol+0)+0+2)
	movlw	017h
u1565:
	clrc
	rrf	(??___fttol+0)+2,f
	rrf	(??___fttol+0)+1,f
	rrf	(??___fttol+0)+0,f
u1560:
	addlw	-1
	skipz
	goto	u1565
	movf	0+(??___fttol+0)+0,w
	movwf	(___fttol@sign1)
	line	52
	
l1699:	
	bsf	(___fttol@f1)+(15/8),(15)&7
	line	53
	
l1701:	
	movlw	0FFh
	andwf	(___fttol@f1),f
	movlw	0FFh
	andwf	(___fttol@f1+1),f
	movlw	0
	andwf	(___fttol@f1+2),f
	line	54
	
l1703:	
	movf	(___fttol@f1),w
	movwf	(___fttol@lval)
	movf	(___fttol@f1+1),w
	movwf	((___fttol@lval))+1
	movf	(___fttol@f1+2),w
	movwf	((___fttol@lval))+2
	clrf	((___fttol@lval))+3
	line	55
	
l1705:	
	movlw	08Eh
	subwf	(___fttol@exp1),f
	line	56
	
l1707:	
	btfss	(___fttol@exp1),7
	goto	u1571
	goto	u1570
u1571:
	goto	l1717
u1570:
	line	57
	
l1709:	
	movf	(___fttol@exp1),w
	xorlw	80h
	addlw	-((-15)^80h)
	skipnc
	goto	u1581
	goto	u1580
u1581:
	goto	l1713
u1580:
	goto	l1695
	line	60
	
l1713:	
	clrc
	rrf	(___fttol@lval+3),f
	rrf	(___fttol@lval+2),f
	rrf	(___fttol@lval+1),f
	rrf	(___fttol@lval),f
	line	61
	
l1715:	
	incfsz	(___fttol@exp1),f
	goto	u1591
	goto	u1590
u1591:
	goto	l1713
u1590:
	goto	l1725
	line	63
	
l1717:	
	movlw	low(018h)
	subwf	(___fttol@exp1),w
	skipc
	goto	u1601
	goto	u1600
u1601:
	goto	l1723
u1600:
	goto	l1695
	line	66
	
l1721:	
	clrc
	rlf	(___fttol@lval),f
	rlf	(___fttol@lval+1),f
	rlf	(___fttol@lval+2),f
	rlf	(___fttol@lval+3),f
	line	67
	decf	(___fttol@exp1),f
	line	65
	
l1723:	
	movf	((___fttol@exp1)),w
	btfss	status,2
	goto	u1611
	goto	u1610
u1611:
	goto	l1721
u1610:
	line	70
	
l1725:	
	movf	((___fttol@sign1)),w
	btfsc	status,2
	goto	u1621
	goto	u1620
u1621:
	goto	l1729
u1620:
	line	71
	
l1727:	
	comf	(___fttol@lval),f
	comf	(___fttol@lval+1),f
	comf	(___fttol@lval+2),f
	comf	(___fttol@lval+3),f
	incf	(___fttol@lval),f
	skipnz
	incf	(___fttol@lval+1),f
	skipnz
	incf	(___fttol@lval+2),f
	skipnz
	incf	(___fttol@lval+3),f
	line	72
	
l1729:	
	movf	(___fttol@lval+3),w
	movwf	(?___fttol+3)
	movf	(___fttol@lval+2),w
	movwf	(?___fttol+2)
	movf	(___fttol@lval+1),w
	movwf	(?___fttol+1)
	movf	(___fttol@lval),w
	movwf	(?___fttol)

	line	73
	
l606:	
	return
	opt stack 0
GLOBAL	__end_of___fttol
	__end_of___fttol:
	signat	___fttol,4220
	global	___ftdiv

;; *************** function ___ftdiv *****************
;; Defined at:
;;		line 56 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\ftdiv.c"
;; Parameters:    Size  Location     Type
;;  f2              3    3[BANK0 ] float 
;;  f1              3    6[BANK0 ] float 
;; Auto vars:     Size  Location     Type
;;  f3              3   13[BANK0 ] float 
;;  sign            1   17[BANK0 ] unsigned char 
;;  exp             1   16[BANK0 ] unsigned char 
;;  cntr            1   12[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  3    3[BANK0 ] float 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       6       0       0       0
;;      Locals:         0       6       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0      15       0       0       0
;;Total ram usage:       15 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		___ftpack
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\ftdiv.c"
	line	56
global __ptext12
__ptext12:	;psect for function ___ftdiv
psect	text12
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\ftdiv.c"
	line	56
	global	__size_of___ftdiv
	__size_of___ftdiv	equ	__end_of___ftdiv-___ftdiv
	
___ftdiv:	
;incstack = 0
	opt	stack 5
; Regs used in ___ftdiv: [wreg+status,2+status,0+pclath+cstack]
	line	63
	
l1653:	
	movf	(___ftdiv@f1),w
	movwf	((??___ftdiv+0)+0)
	movf	(___ftdiv@f1+1),w
	movwf	((??___ftdiv+0)+0+1)
	movf	(___ftdiv@f1+2),w
	movwf	((??___ftdiv+0)+0+2)
	clrc
	rlf	(??___ftdiv+0)+1,w
	rlf	(??___ftdiv+0)+2,w
	movwf	(___ftdiv@exp)
	movf	(((___ftdiv@exp))),w
	btfss	status,2
	goto	u1511
	goto	u1510
u1511:
	goto	l1657
u1510:
	line	64
	
l1655:	
	clrf	(?___ftdiv)
	clrf	(?___ftdiv+1)
	clrf	(?___ftdiv+2)
	goto	l570
	line	65
	
l1657:	
	movf	(___ftdiv@f2),w
	movwf	((??___ftdiv+0)+0)
	movf	(___ftdiv@f2+1),w
	movwf	((??___ftdiv+0)+0+1)
	movf	(___ftdiv@f2+2),w
	movwf	((??___ftdiv+0)+0+2)
	clrc
	rlf	(??___ftdiv+0)+1,w
	rlf	(??___ftdiv+0)+2,w
	movwf	(___ftdiv@sign)
	movf	(((___ftdiv@sign))),w
	btfss	status,2
	goto	u1521
	goto	u1520
u1521:
	goto	l571
u1520:
	line	66
	
l1659:	
	clrf	(?___ftdiv)
	clrf	(?___ftdiv+1)
	clrf	(?___ftdiv+2)
	goto	l570
	
l571:	
	line	67
	clrf	(___ftdiv@f3)
	clrf	(___ftdiv@f3+1)
	clrf	(___ftdiv@f3+2)
	line	68
	
l1661:	
	movlw	low(089h)
	addwf	(___ftdiv@sign),w
	movwf	(??___ftdiv+0)+0
	movf	0+(??___ftdiv+0)+0,w
	subwf	(___ftdiv@exp),f
	line	69
	
l1663:	
	movf	0+(___ftdiv@f1)+02h,w
	movwf	(___ftdiv@sign)
	line	70
	
l1665:	
	movf	0+(___ftdiv@f2)+02h,w
	xorwf	(___ftdiv@sign),f
	line	71
	
l1667:	
	movlw	low(080h)
	andwf	(___ftdiv@sign),f
	line	72
	
l1669:	
	bsf	(___ftdiv@f1)+(15/8),(15)&7
	line	73
	
l1671:	
	movlw	0FFh
	andwf	(___ftdiv@f1),f
	movlw	0FFh
	andwf	(___ftdiv@f1+1),f
	movlw	0
	andwf	(___ftdiv@f1+2),f
	line	74
	
l1673:	
	bsf	(___ftdiv@f2)+(15/8),(15)&7
	line	75
	
l1675:	
	movlw	0FFh
	andwf	(___ftdiv@f2),f
	movlw	0FFh
	andwf	(___ftdiv@f2+1),f
	movlw	0
	andwf	(___ftdiv@f2+2),f
	line	76
	
l1677:	
	movlw	low(018h)
	movwf	(___ftdiv@cntr)
	line	78
	
l1679:	
	clrc
	rlf	(___ftdiv@f3),f
	rlf	(___ftdiv@f3+1),f
	rlf	(___ftdiv@f3+2),f
	line	79
	movf	(___ftdiv@f2+2),w
	subwf	(___ftdiv@f1+2),w
	skipz
	goto	u1535
	movf	(___ftdiv@f2+1),w
	subwf	(___ftdiv@f1+1),w
	skipz
	goto	u1535
	movf	(___ftdiv@f2),w
	subwf	(___ftdiv@f1),w
u1535:
	skipc
	goto	u1531
	goto	u1530
u1531:
	goto	l1685
u1530:
	line	80
	
l1681:	
	movf	(___ftdiv@f2),w
	subwf	(___ftdiv@f1),f
	movf	(___ftdiv@f2+1),w
	skipc
	incfsz	(___ftdiv@f2+1),w
	subwf	(___ftdiv@f1+1),f
	movf	(___ftdiv@f2+2),w
	skipc
	incf	(___ftdiv@f2+2),w
	subwf	(___ftdiv@f1+2),f
	line	81
	
l1683:	
	bsf	(___ftdiv@f3)+(0/8),(0)&7
	line	83
	
l1685:	
	clrc
	rlf	(___ftdiv@f1),f
	rlf	(___ftdiv@f1+1),f
	rlf	(___ftdiv@f1+2),f
	line	84
	
l1687:	
	decfsz	(___ftdiv@cntr),f
	goto	u1541
	goto	u1540
u1541:
	goto	l1679
u1540:
	line	85
	
l1689:	
	movf	(___ftdiv@f3),w
	movwf	(___ftpack@arg)
	movf	(___ftdiv@f3+1),w
	movwf	(___ftpack@arg+1)
	movf	(___ftdiv@f3+2),w
	movwf	(___ftpack@arg+2)
	movf	(___ftdiv@exp),w
	movwf	(___ftpack@exp)
	movf	(___ftdiv@sign),w
	movwf	(___ftpack@sign)
	fcall	___ftpack
	movf	(0+(?___ftpack)),w
	movwf	(?___ftdiv)
	movf	(1+(?___ftpack)),w
	movwf	(?___ftdiv+1)
	movf	(2+(?___ftpack)),w
	movwf	(?___ftdiv+2)
	line	86
	
l570:	
	return
	opt stack 0
GLOBAL	__end_of___ftdiv
	__end_of___ftdiv:
	signat	___ftdiv,8315
	global	___ftpack

;; *************** function ___ftpack *****************
;; Defined at:
;;		line 62 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\float.c"
;; Parameters:    Size  Location     Type
;;  arg             3    2[COMMON] unsigned um
;;  exp             1    5[COMMON] unsigned char 
;;  sign            1    6[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  3    2[COMMON] float 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         5       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          3       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___ftdiv
;;		___lwtoft
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\float.c"
	line	62
global __ptext13
__ptext13:	;psect for function ___ftpack
psect	text13
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\float.c"
	line	62
	global	__size_of___ftpack
	__size_of___ftpack	equ	__end_of___ftpack-___ftpack
	
___ftpack:	
;incstack = 0
	opt	stack 5
; Regs used in ___ftpack: [wreg+status,2+status,0]
	line	64
	
l1343:	
	movf	((___ftpack@exp)),w
	btfsc	status,2
	goto	u941
	goto	u940
u941:
	goto	l517
u940:
	
l1345:	
	movf	(___ftpack@arg+2),w
	iorwf	(___ftpack@arg+1),w
	iorwf	(___ftpack@arg),w
	skipz
	goto	u951
	goto	u950
u951:
	goto	l1349
u950:
	
l517:	
	line	65
	clrf	(?___ftpack)
	clrf	(?___ftpack+1)
	clrf	(?___ftpack+2)
	goto	l518
	line	67
	
l1347:	
	incf	(___ftpack@exp),f
	line	68
	clrc
	rrf	(___ftpack@arg+2),f
	rrf	(___ftpack@arg+1),f
	rrf	(___ftpack@arg),f
	line	66
	
l1349:	
	movlw	low highword(0FE0000h)
	andwf	(___ftpack@arg+2),w
	btfss	status,2
	goto	u961
	goto	u960
u961:
	goto	l1347
u960:
	goto	l1353
	line	71
	
l1351:	
	incf	(___ftpack@exp),f
	line	72
	incf	(___ftpack@arg),f
	skipnz
	incf	(___ftpack@arg+1),f
	skipnz
	incf	(___ftpack@arg+2),f
	line	73
	clrc
	rrf	(___ftpack@arg+2),f
	rrf	(___ftpack@arg+1),f
	rrf	(___ftpack@arg),f
	line	70
	
l1353:	
	movlw	low highword(0FF0000h)
	andwf	(___ftpack@arg+2),w
	btfss	status,2
	goto	u971
	goto	u970
u971:
	goto	l1351
u970:
	goto	l1357
	line	76
	
l1355:	
	decf	(___ftpack@exp),f
	line	77
	clrc
	rlf	(___ftpack@arg),f
	rlf	(___ftpack@arg+1),f
	rlf	(___ftpack@arg+2),f
	line	75
	
l1357:	
	btfsc	(___ftpack@arg+1),(15)&7
	goto	u981
	goto	u980
u981:
	goto	l529
u980:
	
l1359:	
	movlw	low(02h)
	subwf	(___ftpack@exp),w
	skipnc
	goto	u991
	goto	u990
u991:
	goto	l1355
u990:
	
l529:	
	line	79
	btfsc	(___ftpack@exp),(0)&7
	goto	u1001
	goto	u1000
u1001:
	goto	l530
u1000:
	line	80
	
l1361:	
	bcf	(___ftpack@arg)+(15/8),(15)&7
	
l530:	
	line	81
	clrc
	rrf	(___ftpack@exp),f
	line	82
	
l1363:	
	movf	(___ftpack@exp),w
	movwf	((??___ftpack+0)+0+2)
	clrf	((??___ftpack+0)+0+1)
	clrf	((??___ftpack+0)+0+0)
	movf	0+(??___ftpack+0)+0,w
	iorwf	(___ftpack@arg),f
	movf	1+(??___ftpack+0)+0,w
	iorwf	(___ftpack@arg+1),f
	movf	2+(??___ftpack+0)+0,w
	iorwf	(___ftpack@arg+2),f
	line	83
	movf	((___ftpack@sign)),w
	btfsc	status,2
	goto	u1011
	goto	u1010
u1011:
	goto	l531
u1010:
	line	84
	
l1365:	
	bsf	(___ftpack@arg)+(23/8),(23)&7
	
l531:	
	line	85
	line	86
	
l518:	
	return
	opt stack 0
GLOBAL	__end_of___ftpack
	__end_of___ftpack:
	signat	___ftpack,12411
	global	_Init_System

;; *************** function _Init_System *****************
;; Defined at:
;;		line 425 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	425
global __ptext14
__ptext14:	;psect for function _Init_System
psect	text14
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	425
	global	__size_of_Init_System
	__size_of_Init_System	equ	__end_of_Init_System-_Init_System
	
_Init_System:	
;incstack = 0
	opt	stack 6
; Regs used in _Init_System: [wreg+status,2]
	line	427
	
l1617:	
# 427 "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
nop ;# 
	line	428
# 428 "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
clrwdt ;# 
psect	text14
	line	429
	
l1619:	
;SC8F096_ADC.c: 429: OPTION_REG = 0x0F;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(1)	;volatile
	line	430
# 430 "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
clrwdt ;# 
psect	text14
	line	431
;SC8F096_ADC.c: 431: OSCCON = 0X70;
	movlw	low(070h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	433
	
l1621:	
;SC8F096_ADC.c: 433: WPUA = 0B00000000;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(136)^080h	;volatile
	line	434
	
l1623:	
;SC8F096_ADC.c: 434: WPUB = 0B00000000;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	line	435
	
l1625:	
;SC8F096_ADC.c: 435: WPUC = 0B00000000;
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	436
	
l1627:	
;SC8F096_ADC.c: 436: WPUD = 0B00000000;
	clrf	(277)^0100h	;volatile
	line	441
;SC8F096_ADC.c: 441: TRISA = 0xF0; PORTA = 0x0F;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	442
;SC8F096_ADC.c: 442: TRISB = 0x30; PORTB = 0x4F;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	443
;SC8F096_ADC.c: 443: TRISC = 0x03; PORTC = 0x00;
	movlw	low(03h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l1629:	
	clrf	(262)^0100h	;volatile
	line	445
	
l1631:	
;SC8F096_ADC.c: 445: TRISD = 0xF0; PORTD = 0x0F;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l1633:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	447
	
l1635:	
;SC8F096_ADC.c: 447: CC0CON = 0;
	bsf	status, 5	;RP0=1, select bank3
	clrf	(405)^0180h	;volatile
	line	448
	
l1637:	
;SC8F096_ADC.c: 448: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	452
	
l1639:	
;SC8F096_ADC.c: 452: PR2 = 249;
	movlw	low(0F9h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(17)	;volatile
	line	453
	
l1641:	
;SC8F096_ADC.c: 453: TMR2IF = 0;
	bcf	(105/8),(105)&7	;volatile
	line	454
	
l1643:	
;SC8F096_ADC.c: 454: TMR2IE = 1;
	bsf	(113/8),(113)&7	;volatile
	line	456
	
l1645:	
;SC8F096_ADC.c: 456: T2CON = 0B00000100;
	movlw	low(04h)
	movwf	(19)	;volatile
	line	457
	
l1647:	
;SC8F096_ADC.c: 457: INTCON = 0XC0;
	movlw	low(0C0h)
	movwf	(11)	;volatile
	line	458
	
l348:	
	return
	opt stack 0
GLOBAL	__end_of_Init_System
	__end_of_Init_System:
	signat	_Init_System,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 488 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=0
	line	488
global __ptext15
__ptext15:	;psect for function _AD_Init
psect	text15
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	488
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 6
; Regs used in _AD_Init: [wreg+status,2]
	line	490
	
l1649:	
;SC8F096_ADC.c: 490: ADCON0 = 0X41;
	movlw	low(041h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	491
	
l1651:	
;SC8F096_ADC.c: 491: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	492
	
l357:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 55 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    2[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    2[BANK0 ] unsigned char 
;;  j               1    0[BANK0 ] unsigned char 
;;  adsum           4    4[BANK0 ] volatile unsigned long 
;;  ad_temp         2   12[BANK0 ] volatile unsigned int 
;;  admax           2   10[BANK0 ] volatile unsigned int 
;;  admin           2    8[BANK0 ] volatile unsigned int 
;;  i               1    3[BANK0 ] unsigned char 
;;  ldo_was_off     1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      14       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      14       0       0       0
;;Total ram usage:       19 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=0
	line	55
global __ptext16
__ptext16:	;psect for function _ADC_Sample
psect	text16
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	55
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 6
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(ADC_Sample@adch)
	line	57
	
l1439:	
;SC8F096_ADC.c: 57: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	58
	
l1441:	
;SC8F096_ADC.c: 58: volatile unsigned int admin = 0, admax = 0;
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	59
;SC8F096_ADC.c: 59: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	63
	
l1443:	
;SC8F096_ADC.c: 63: ldo_was_off = ((ADCON1 & 0x04) == 0);
	bsf	status, 5	;RP0=1, select bank1
	btfss	(150)^080h,(2)&7	;volatile
	goto	u1141
	goto	u1140
u1141:
	movlw	1
	goto	u1150
u1140:
	movlw	0
u1150:
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ldo_was_off)
	line	67
	
l1445:	
;SC8F096_ADC.c: 67: if(adch & 0x10)
	btfss	(ADC_Sample@adch),(4)&7
	goto	u1161
	goto	u1160
u1161:
	goto	l1451
u1160:
	line	69
	
l1447:	
;SC8F096_ADC.c: 68: {
;SC8F096_ADC.c: 69: ADCON1 = adldo | 0x40;
	movf	(ADC_Sample@adldo),w
	iorlw	040h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	70
	
l1449:	
;SC8F096_ADC.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(ADC_Sample@adch),f
	line	71
;SC8F096_ADC.c: 71: }
	goto	l1453
	line	74
	
l1451:	
;SC8F096_ADC.c: 72: else
;SC8F096_ADC.c: 73: {
;SC8F096_ADC.c: 74: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	78
	
l1453:	
;SC8F096_ADC.c: 75: }
;SC8F096_ADC.c: 78: if(ldo_was_off && (adldo & 0x04))
	bcf	status, 5	;RP0=0, select bank0
	movf	((ADC_Sample@ldo_was_off)),w
	btfsc	status,2
	goto	u1171
	goto	u1170
u1171:
	goto	l1459
u1170:
	
l1455:	
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u1181
	goto	u1180
u1181:
	goto	l1459
u1180:
	line	79
	
l1457:	
;SC8F096_ADC.c: 79: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??_ADC_Sample+0)+0),f
	u2117:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u2117
opt asmopt_pop

	line	81
	
l1459:	
	line	82
	
l1461:	
;SC8F096_ADC.c: 82: for (i = 0; i < 10; i++)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@i)
	line	84
	
l1465:	
;SC8F096_ADC.c: 83: {
;SC8F096_ADC.c: 84: ADCON0 = (unsigned char)(0X41 | (adch << 2));
	movf	(ADC_Sample@adch),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u1195:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u1195
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	041h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	87
	
l1467:	
;SC8F096_ADC.c: 87: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	6
movwf	((??_ADC_Sample+0)+0),f
	u2127:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u2127
	nop
opt asmopt_pop

	line	88
	
l1469:	
;SC8F096_ADC.c: 88: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	90
	
l1471:	
;SC8F096_ADC.c: 90: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	91
;SC8F096_ADC.c: 91: while (GODONE)
	goto	l250
	
l251:	
	line	93
;SC8F096_ADC.c: 92: {
;SC8F096_ADC.c: 93: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	95
;SC8F096_ADC.c: 95: if (0 == (--j))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u1201
	goto	u1200
u1201:
	goto	l250
u1200:
	line	96
	
l1473:	
;SC8F096_ADC.c: 96: return 0;
	movlw	low(0)
	goto	l253
	line	97
	
l250:	
	line	91
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u1211
	goto	u1210
u1211:
	goto	l251
u1210:
	line	99
	
l1477:	
;SC8F096_ADC.c: 97: }
;SC8F096_ADC.c: 99: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
l1479:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	101
	
l1481:	
;SC8F096_ADC.c: 101: if (0 == admax)
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u1221
	goto	u1220
u1221:
	goto	l1485
u1220:
	line	103
	
l1483:	
;SC8F096_ADC.c: 102: {
;SC8F096_ADC.c: 103: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	104
;SC8F096_ADC.c: 104: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	105
;SC8F096_ADC.c: 105: }
	goto	l256
	line	106
	
l1485:	
;SC8F096_ADC.c: 106: else if (ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u1235
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u1235:
	skipnc
	goto	u1231
	goto	u1230
u1231:
	goto	l1489
u1230:
	line	107
	
l1487:	
;SC8F096_ADC.c: 107: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	l256
	line	108
	
l1489:	
;SC8F096_ADC.c: 108: else if (ad_temp < admin)
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u1245
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u1245:
	skipnc
	goto	u1241
	goto	u1240
u1241:
	goto	l256
u1240:
	line	109
	
l1491:	
;SC8F096_ADC.c: 109: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	111
	
l256:	
;SC8F096_ADC.c: 111: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u1251
	addwf	(ADC_Sample@adsum+1),f	;volatile
u1251:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u1252
	addwf	(ADC_Sample@adsum+2),f	;volatile
u1252:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u1253
	addwf	(ADC_Sample@adsum+3),f	;volatile
u1253:

	line	82
	
l1493:	
	incf	(ADC_Sample@i),f
	
l1495:	
	movlw	low(0Ah)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u1261
	goto	u1260
u1261:
	goto	l1465
u1260:
	line	113
	
l1497:	
;SC8F096_ADC.c: 112: }
;SC8F096_ADC.c: 113: adsum -= admax;
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u1275
	goto	u1276
u1275:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u1276:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u1277
	goto	u1278
u1277:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u1278:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u1279
	goto	u1270
u1279:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u1270:

	line	114
;SC8F096_ADC.c: 114: if (adsum >= admin)
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u1285
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u1285
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u1285
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u1285:
	skipc
	goto	u1281
	goto	u1280
u1281:
	goto	l260
u1280:
	line	115
	
l1499:	
;SC8F096_ADC.c: 115: adsum -= admin;
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u1295
	goto	u1296
u1295:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u1296:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u1297
	goto	u1298
u1297:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u1298:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u1299
	goto	u1290
u1299:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u1290:

	goto	l1501
	line	116
	
l260:	
	line	117
;SC8F096_ADC.c: 116: else
;SC8F096_ADC.c: 117: adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	119
	
l1501:	
;SC8F096_ADC.c: 119: adresult = adsum >> 3;
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	03h
u1305:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u1300:
	addlw	-1
	skipz
	goto	u1305
	movf	1+(??_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	121
	
l1503:	
;SC8F096_ADC.c: 121: adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	122
	
l1505:	
;SC8F096_ADC.c: 122: admin = 0;
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	123
	
l1507:	
;SC8F096_ADC.c: 123: admax = 0;
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	124
	
l1509:	
;SC8F096_ADC.c: 124: return 0xA5;
	movlw	low(0A5h)
	line	126
	
l253:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 469 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=0
	line	469
global __ptext17
__ptext17:	;psect for function _Isr_Timer
psect	text17
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\09-test\SC8F096_ADC_Demo\SC8F096_ADC.c"
	line	469
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 5
; Regs used in _Isr_Timer: []
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Isr_Timer+0)
	movf	pclath,w
	movwf	(??_Isr_Timer+1)
	ljmp	_Isr_Timer
psect	text17
	line	471
	
i1l1303:	
;SC8F096_ADC.c: 471: if (TMR2IF)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(105/8),(105)&7	;volatile
	goto	u88_21
	goto	u88_20
u88_21:
	goto	i1l354
u88_20:
	line	473
	
i1l1305:	
;SC8F096_ADC.c: 472: {
;SC8F096_ADC.c: 473: TMR2IF = 0;
	bcf	(105/8),(105)&7	;volatile
	line	477
	
i1l354:	
	movf	(??_Isr_Timer+1),w
	movwf	pclath
	swapf	(??_Isr_Timer+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
