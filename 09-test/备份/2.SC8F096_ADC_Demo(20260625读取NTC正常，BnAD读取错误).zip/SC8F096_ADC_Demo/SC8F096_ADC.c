/**********************************************************
AD检测范例程序 - B1AD(AN17) + 软件UART打印
TX=RC4(J1-CLK), 9600bps软件模拟, 每2秒打印一次
接线: J1-CLK(RC4) → USB-TTL模块RX, J1-GND → 模块GND
注意: 烧录完必须拔掉烧录器, 再接串口模块
**********************************************************/
#pragma warning disable 752
#pragma warning disable 373			//未经使用的变量1个以上
#include <sc.h>

#ifndef _XTAL_FREQ
#define _XTAL_FREQ 16000000			//16MHz,使用内部时钟时需定义时钟频率
#endif

#define     POWER_RATIO  	(4096UL*1.2*1000)
#define     SW_TX           RC4     /* J1-CLK(RC4) 用作软件UART TX */
#define     BIT_TIME        104     /* 9600bps位宽: 1/9600≈104us */

volatile unsigned int adresult;
volatile unsigned int result;
volatile unsigned char test_adc;
volatile unsigned int power_ad;

unsigned char ADC_Sample(unsigned char adch, unsigned char adldo);
void Init_System();
void AD_Init();

/* --- 软件UART函数声明 --- */
void sw_uart_init(void);
void uart_send_char(unsigned char c);
void uart_send_string(const unsigned char *str);
void uart_send_number(unsigned int num);
unsigned char ntc_to_temp(unsigned int adc_val);

#define _DEBUG			//测试程序开关

/**********************************************************
函数名称：ADC_Sample
函数功能：AD采样
入口参数：adch - 采样通道
出口参数：无
    注：采样通道必须设置为输入口
	      采样10次,取中间八次的平均值为采样结果存于adresult。

	      adch 为普通AD通道 0-15，31
              31  为内部1.2V
	
 		  adldo =5,开启内部LDO 2V 作为ADC 参考
 		  adldo =6,开启内部LDO 2.4V 作为ADC 参考
		  adldo =7,开启内部LDO 3V 作为ADC 参考
 		  adldo =0,VDD 作为ADC 参考
 		  AD转换结束后返回
 		  ADC参考电压由VDD切换到LDO时，需延时100us以上，才能进行AD转换
**********************************************************/
unsigned char ADC_Sample(unsigned char adch, unsigned char adldo) 
{
	volatile unsigned long adsum = 0;
	volatile unsigned int admin = 0, admax = 0;
	volatile unsigned int ad_temp = 0;
	unsigned char ldo_was_off = 0;

	/* 保存LDO旧状态(必须在写ADCON1之前读取) */
	ldo_was_off = ((ADCON1 & 0x04) == 0);

	/* 关键修复: 直接将CHS4写入ADCON1, 避免CHS4=1的RMW操作
	   CHS4是ADCON1 bit6, 若用CHS4=1位操作可能因不可读而失效 */
	if(adch & 0x10)
	{
		ADCON1 = adldo | 0x40;  /* 高位通道: CHS4=1 + LDO配置 */
		adch &= 0x0f;
	}
	else
	{
		ADCON1 = adldo;         /* 低位通道: CHS4=0 */
	}

	/* LDO从关到开: 等待LDO稳定(100us) */
	if(ldo_was_off && (adldo & 0x04))
		__delay_us(100);

	unsigned char i = 0;
	for (i = 0; i < 10; i++) 
	{
		ADCON0 = (unsigned char)(0X41 | (adch << 2));	//16分频,系统时钟为16M,建议选16分频,采样时间1us
		/* 采集时间: BxAD经10K电阻到ADC, τ=10K×15pF≈150ns
		   12bit精度需9τ≈1.35μs, 这里给5μs足够裕量 */
		__delay_us(5);
		GODONE = 1;				//开始转换

		unsigned char j = 0;
		while (GODONE) 
		{
			__delay_us(2);		//延时2us(根据实际情况调整函数)

			if (0 == (--j))		//延时0.5ms若没有AD转换结束,则转换失败
			return 0;
		}

		ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));	//读取12位AD值

		if (0 == admax) 
		{
			admax = ad_temp;
			admin = ad_temp;
		} 
		else if (ad_temp > admax)
			admax = ad_temp;				//AD采样最大值
		else if (ad_temp < admin)
			admin = ad_temp;				//AD采样最小值

		adsum += ad_temp;
	}
		adsum -= admax;
		if (adsum >= admin)
			adsum -= admin;
		else
			adsum = 0;

		adresult = adsum >> 3;		//8次平均值作为最终结果

		adsum = 0;
		admin = 0;
		admax = 0;
		return 0xA5;
		
}

/*========================================================================
  软件UART初始化: TX=RC4(J1-CLK), 9600bps
  只需把RC4设为数字输出,空闲高电平
========================================================================*/
void sw_uart_init(void)
{
	TRISC &= ~0x10;             /* RC4 = 输出 */
	ANSEL2 &= ~0x10;            /* RC4/AN20 → 数字模式(关闭模拟) */
	SW_TX = 1;                  /* 空闲状态: 高电平 */
}

/*========================================================================
  函数: uart_send_char
  功能: 软件模拟发送单个字节(9600bps, 8N1)
  参数: c - 要发送的字符
  时序: START(低104us) + 8bit LSB-first(各104us) + STOP(高104us)
  注意: 阻塞发送, 发送期间中断可能增加少许抖动但在容忍范围内
========================================================================*/
void uart_send_char(unsigned char c)
{
	unsigned char i;

	GIE = 0;  /* 关闭全局中断, 避免TMR2(62.5us)干扰时序 */

	/* START bit: 拉低 BIT_TIME us */
	SW_TX = 0;
	__delay_us(BIT_TIME);

	/* 8 data bits, LSB first */
	for(i = 0; i < 8; i++)
	{
		if(c & 0x01)
			SW_TX = 1;
		else
			SW_TX = 0;
		__delay_us(BIT_TIME);
		c >>= 1;
	}

	/* STOP bit: 拉高 BIT_TIME us */
	SW_TX = 1;
	__delay_us(BIT_TIME);

	GIE = 1;  /* 恢复全局中断 */
}

/*========================================================================
  函数: uart_send_string
  功能: 发送字符串(以'\0'结尾)
  参数: str - 字符串指针
========================================================================*/
void uart_send_string(const unsigned char *str)
{
	while(*str != '\0')
		uart_send_char(*str++);
}

/*========================================================================
  函数: uart_send_number
  功能: 发送无符号整数的十进制字符串
  参数: num - 要发送的数字
========================================================================*/
void uart_send_number(unsigned int num)
{
	unsigned char buf[6];           /* 最大65535, 5位+1 */
	unsigned char i = 0;
	unsigned char j;

	if(num == 0)
	{
		uart_send_char('0');
		return;
	}

	while(num > 0)
	{
		buf[i++] = '0' + (num % 10);
		num /= 10;
	}

	for(j = i; j > 0; j--)
		uart_send_char(buf[j-1]);
}

/*========================================================================
  函数: ntc_to_temp
  功能: NTC ADC值转换为温度(摄氏度)
  参数: adc_val - NTC ADC原始值(VDD参考, 分压公式求出Rntc)
  返回: 温度(10~75度), 异常返回25度
  NTC型号: 10K@25C, B=3950 (实测电压VDD/2≈2.5V确认10K)
  电路: VDD → R48(10K) → RC2/AN18 → NTC → GND
  公式: Rntc = ADC * 10K / (4096 - ADC)  (VDD参考, 比例法消去VDD)
  注意: 25C时ADC≈2048, Rntc≈10K; 温度越低Rntc越大ADC越小
========================================================================*/
unsigned char ntc_to_temp(unsigned int adc_val)
{
	unsigned long ntc_r;
	unsigned char temp;

	/* ADC异常: 开路或短路, 返回默认25度 */
	if(adc_val == 0 || adc_val >= 4095)
		return 25;

	/* 分压公式: Rntc = adc_val * 10000 / (4096 - adc_val) */
	ntc_r = (unsigned long)adc_val * 10000UL / (4096UL - adc_val);

	/* 查表: 10K B=3950 NTC */
	     if(ntc_r > 22000) temp = 10;
	else if(ntc_r > 15800) temp = 15;
	else if(ntc_r > 12500) temp = 20;
	else if(ntc_r > 10000) temp = 25;
	else if(ntc_r > 8050)  temp = 30;
	else if(ntc_r > 6590)  temp = 35;
	else if(ntc_r > 5460)  temp = 40;
	else if(ntc_r > 4570)  temp = 45;
	else if(ntc_r > 3870)  temp = 50;
	else if(ntc_r > 3300)  temp = 55;
	else if(ntc_r > 2840)  temp = 60;
	else if(ntc_r > 2460)  temp = 65;
	else if(ntc_r > 2140)  temp = 70;
	else                   temp = 75;

	return temp;
}


/* B1~B12 AD通道号: B7~B10为高通道(CHS4=1), 对应AN28/29/27/26 */
const unsigned char bx_ch[12] = {17, 16, 12, 13, 5, 4, 28, 29, 27, 26, 7, 6};


/***********************************************************
main主函数
***********************************************************/
void main() 
{
	Init_System();
	AD_Init();
	sw_uart_init();

	/* NTC引脚初始化: RC2/AN18
	   切换RC2从输出→模拟输入, 22uF电容需充电建立≈550ms
	   配合下面2秒等待, 首次读数时电容已充满 */
	TRISC2 = 1;             /* RC2 = 输入 */
	ANSEL2 |= 0x04;         /* RC2/AN18 → 模拟模式 */

	/* BxAD ADC引脚全部初始化为模拟输入
	   注意: RD2(AN26=B10AD)和RD3(AN27=B9AD)与B11/B8 MOSFET栅极共用,
	   为保持MOSFET关闭, 保持RD2-3为输出HIGH, B9AD/B10AD暂不可读 */
	ANSEL0 |= 0xF0;         /* AN4~7: B6AD/B5AD/B12AD/B11AD */
	ANSEL1 |= 0x30;         /* AN12~13: B3AD/B4AD */
	ANSEL2 |= 0x03;         /* AN16~17: B2AD/B1AD, RC2已单独配置 */
	ANSEL3 |= 0x30;         /* AN28~29: B7AD/B8AD(RD4-5), RD2-3保持数字输出 */

	uart_send_string("B1-B12 ADC Test RC4\r\n");

	unsigned int tick = 0;

	while (1) 
	{
		asm("clrwdt");
		__delay_ms(10);             /* 10ms间隔, 用于2秒计时 */

		tick++;
		if(tick < 200) continue;    /* 200*10ms = 2秒 */
		tick = 0;

#ifdef _DEBUG
		/* --- 先读VCC电压(VREF/AN31, VDD参考) --- */
		{
			volatile unsigned long power_temp;
			unsigned int vcc_mv = 5000;  /* 默认5V */

			test_adc = ADC_Sample(31, 0);
			if(0xA5 == test_adc)
			{
				power_temp = (unsigned long)((POWER_RATIO) / adresult);
				vcc_mv = (unsigned int)(power_temp);
			}

			uart_send_string("VCC=");
			uart_send_number(vcc_mv);
			uart_send_string("mV\r\n");

			/* --- 循环读B1~B12 AD --- */
			/*
			   分压电路: VCC--[R2=100K]--Bx--[R4=10K]--BxAD(MCU)
			   
			   [无电池]: Bx浮空→100K上拉到VCC→BxAD≈5V→LDO=3V参考饱和(4095)
			             → 用VDD参考重读一次确认实际电压→显示电压
			   
			   [有电池]: Bx=V_BAT, 叠加定理: V_BxAD = VCC/11 + V_BAT×10/11
			             → V_BAT = (11×V_BxAD - VCC) / 10
			             → V_BAT_mV = (11×ADC×Vref/4096 - VCC_mV) / 10
			*/
			{
				unsigned char i;
				for(i = 0; i < 12; i++)
				{
					unsigned int adc_raw;
					unsigned long bat_mv;

					/* 打印标签 "Bx=" */
					uart_send_char('B');
					if(i < 9) {
						uart_send_char('1' + i);
					} else {
						uart_send_char('1');
						uart_send_char('0' + (i - 9));
					}
					uart_send_char('=');

					/* 先用LDO=3V参考采样 */
					test_adc = ADC_Sample(bx_ch[i], 7);
					if(0xA5 != test_adc) {
						uart_send_string("FAIL ");
						ADCON0 = 0; ADCON1 = 0; __delay_us(100);
						continue;
					}
					adc_raw = adresult;

					/* 饱和(>=4090) = 无电池或电压>3V, 用VDD参考重读看实际电压 */
					if(adc_raw >= 4090)
					{
						test_adc = ADC_Sample(bx_ch[i], 0);  /* VDD参考 */
						if(0xA5 == test_adc)
						{
							bat_mv = (unsigned long)adresult * vcc_mv / 4096UL;
							uart_send_number(adc_raw);
							uart_send_string(" OPEN(");
							uart_send_number((unsigned int)bat_mv);
							uart_send_string("mV)");
						}
						else
							uart_send_string("FAIL2");
					}
					else
					{
						/* 有电池: 叠加定理修正 V_BxAD = VCC/11 + V_BAT×10/11
						   反推: V_BAT_mV = (11×V_BxAD_mV - VCC_mV) / 10
						   V_BxAD_mV = ADC × 3000 / 4096 (LDO=3V) */
						unsigned long vx_mv;
						vx_mv = (unsigned long)adc_raw * 3000UL / 4096UL;   /* V_BxAD_mV */

						/* 防下溢: 若11×V_BxAD < VCC意味着ADC值异常偏低(触点抖动/短路) */
						if((11UL * vx_mv) < (unsigned long)vcc_mv)
						{
							uart_send_number(adc_raw);
							uart_send_string(" ???(");
							uart_send_number((unsigned int)vx_mv);
							uart_send_string("mV)");
						}
						else
						{
							bat_mv = (11UL * vx_mv - (unsigned long)vcc_mv) / 10UL;
							uart_send_number(adc_raw);
							uart_send_string(" BAT(");
							uart_send_number((unsigned int)bat_mv);
							uart_send_string("mV)");
						}
					}
					uart_send_char(' ');

					/* B6后换行 */
					if(i == 5) uart_send_string("\r\n");
				}
			}

			/* 读NTC(AN18), VDD参考(比例法消去VDD误差) */
			uart_send_string("NTC=");
			test_adc = ADC_Sample(18, 0);       /* AN18, VDD参考 */
			if(0xA5 == test_adc)
			{
				uart_send_number(adresult);
				uart_send_string(" T=");
				uart_send_number(ntc_to_temp(adresult));
				uart_send_string("C");
			}
			else
			{
				uart_send_string("FAIL");
				ADCON0 = 0;
				ADCON1 = 0;
				__delay_us(100);
			}
		}

		uart_send_string("\r\n");
#endif
	}
}

/**********************************************************
函数名称：Init_System
函数功能：系统初始化
入口参数：无
出口参数：无
**********************************************************/
void Init_System() 
{
	asm("nop");
	asm("clrwdt");
	OPTION_REG = 0x0F;				//PSA=1分频器给WDT(1:128), WDT超时≈2.3s足够覆盖10ms delay
	asm("clrwdt");
	OSCCON = 0X70;					//内部晶振8M

	WPUA = 0B00000000;				//关闭全部弱上拉, 避免干扰ADC分压读数
	WPUB = 0B00000000;
	WPUC = 0B00000000;
	WPUD = 0B00000000;

	/* GPIO初始化: MOSFET栅极输出HIGH(关闭), ADC引脚输入(模拟)
	   P沟道AO3401: Gate=High→OFF, Gate=Low→ON
	   浮空栅极会随机导通, 严重干扰BxAD电压采样 */
	TRISA = 0xF0;  PORTA = 0x0F;   /* RA4-7=ADC输入, RA0-3=HIGH(B1/B2/B5/B6 MOSFET关) */
	TRISB = 0x30;  PORTB = 0x4F;   /* RB4-5=ADC输入, RB6(EN)=1, RB7(PWM)=0, RB0-3=HIGH(B9/B10/B3/B4关) */
	TRISC = 0x03;  PORTC = 0x00;   /* RC0-1=ADC输入(B2AD/B1AD), RC2-5=输出低(CD/LED全关),
	                                  注: RC2=输出低→NTC引脚需在main()中切换为模拟输入 */
	TRISD = 0xF0;  PORTD = 0x0F;   /* RD4-7=ADC输入, RD0-3=HIGH(B12/B7/B11/B8 MOSFET关) */
	
	CC0CON = 0;					//关闭 CC0，CC1 比较输出
	CC1CON = 0;

//---------------------------------------
//125us中断初始化
	PR2 = 249;					//设定Timer初始值，定时器频率250*4/8M=125uS
	TMR2IF = 0;
	TMR2IE = 1;					//使能Timer2中断

	T2CON = 0B00000100;			//启动Timer2,设定TMR2的分频器为1:1
	INTCON = 0XC0;				//开启全局中断
}

/***********************************************************
中断服务函数
函数名称：Isr_Timer()
函数功能：中断处理函数
入口参数：无
出口参数：无
    注：125US定时2中断
			任意中断都进入此函数进行处理
***********************************************************/
void interrupt Isr_Timer() 
{
	if (TMR2IF) 
	{			//由于只使用了一个中断源,所以不用判断中断
		TMR2IF = 0;

	}

}

/***********************************************************
中断服务函数
函数名称：AD_Init()
函数功能：AD初始化,其它说明
入口参数：无
出口参数：无
    注：第一次打开AD模块并置位ADON会延时20uS以上才能进行AD采样
			本程序不关闭ADON所以不需要延时
***********************************************************/
void AD_Init() 
{
	ADCON0 = 0X41;		//ADON使能,AD转换时钟选为FSYS/32
	ADCON1 = 0;
}
