opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ChargeProcess_Slot
	FNCALL	_main,_Do_AdcSample
	FNCALL	_main,_Do_NtcRead
	FNCALL	_main,_Print_DetectLog
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_System_Init
	FNCALL	_main,_uart_send_number
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_Print_DetectLog,_uart_send_char
	FNCALL	_Print_DetectLog,_uart_send_number
	FNCALL	_Print_DetectLog,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_Do_NtcRead,_Read_Temperature
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Do_AdcSample,_ADC_Sample
	FNCALL	_Do_AdcSample,___bmul
	FNCALL	_ChargeProcess_Slot,_Detect_BatteryType
	FNCALL	_ChargeProcess_Slot,___bmul
	FNCALL	_ChargeProcess_Slot,___lldiv
	FNCALL	_ChargeProcess_Slot,___lmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_CCCV_Control
	FNCALL	_Isr_Timer,_Charging_Control
	FNCALL	_Isr_Timer,_Led_BlinkProcess
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Update_LED_Slot
	FNCALL	_Update_LED_Slot,i1___bmul
	FNCALL	_Charging_Control,i1___bmul
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,i1___bmul
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_temperature
	global	_g_vcc_mv
psect	idataBANK0,class=CODE,space=0,delta=2,noexec
global __pidataBANK0
__pidataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	9

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	15

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	47
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_powerOnTimer
	global	_g_vccProtect
	global	_g_tempProtect
	global	_g_dbgNewType
	global	_g_dbgNewState
	global	_g_dbgOldState
	global	_g_dbgSlot
	global	_g_tempPhase
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_scanPhase
	global	_g_scanIndex
	global	_g_detectLogType
	global	_g_detectLogSlot
	global	_test_adc
	global	_adresult
	global	_g_dbgDetectFlag
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_adcBusy
	global	_g_doAdcSample
	global	_g_detectLogFlag
	global	_g_detectLowCnt
	global	_g_ovCnt
	global	_g_dbgVoltage
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_cvIntegral
	global	_g_slot
	global	_g_impRefV
	global	_g_blinkTimer
	global	_g_blinkPhase
	global	_g_ledState
	global	_g_ccBlocks
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_GIE
_GIE	set	0x5F
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RC4
_RC4	set	0x834
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC5
_RC5	set	0x835
	global	_RC3
_RC3	set	0x833
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_27:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	45	;'-'
	retlw	105	;'i'
	retlw	111	;'o'
	retlw	110	;'n'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_30:	
	retlw	68	;'D'
	retlw	66	;'B'
	retlw	71	;'G'
	retlw	58	;':'
	retlw	32	;' '
	retlw	115	;'s'
	retlw	108	;'l'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_29:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_31:	
	retlw	32	;' '
	retlw	111	;'o'
	retlw	108	;'l'
	retlw	100	;'d'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_32:	
	retlw	32	;' '
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	119	;'w'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_9:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_23:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_33:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_11:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_34:	
	retlw	32	;' '
	retlw	86	;'V'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
STR_7	equ	STR_2+0
STR_8	equ	STR_3+0
STR_24	equ	STR_29+7
STR_25	equ	STR_29+7
STR_35	equ	STR_29+7
; #config settings
	file	"SC8P096_timer_C.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssBANK0,class=BANK0,bit,space=1,noexec
global __pbitbssBANK0
__pbitbssBANK0:
_g_dbgDetectFlag:
       ds      1

_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

_g_adcBusy:
       ds      1

_g_doAdcSample:
       ds      1

_g_detectLogFlag:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_powerOnTimer:
       ds      2

_g_vccProtect:
       ds      1

_g_tempProtect:
       ds      1

_g_dbgNewType:
       ds      1

_g_dbgNewState:
       ds      1

_g_dbgOldState:
       ds      1

_g_dbgSlot:
       ds      1

_g_tempPhase:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_scanPhase:
       ds      1

_g_scanIndex:
       ds      1

_g_detectLogType:
       ds      1

_g_detectLogSlot:
       ds      1

_test_adc:
       ds      1

_adresult:
       ds      2

psect	dataBANK0,class=BANK0,space=1,noexec
global __pdataBANK0
__pdataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	9
_g_temperature:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_detectLowCnt:
       ds      12

_g_ovCnt:
       ds      12

_g_dbgVoltage:
       ds      2

_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_cvIntegral:
       ds      2

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	15
_g_vcc_mv:
       ds      2

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_impRefV:
       ds      24

_g_blinkTimer:
       ds      12

_g_blinkPhase:
       ds      12

_g_ledState:
       ds      12

_g_ccBlocks:
       ds      12

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"SC8P096_timer_C.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
; Initialize objects allocated to BANK0
	global __pidataBANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	fcall	__pidataBANK0+0		;fetch initializer
	movwf	__pdataBANK0+0&07fh		
	fcall	__pidataBANK0+1		;fetch initializer
	movwf	__pdataBANK0+1&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+022h)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+013h)
	fcall	clear_ram0
; Clear objects allocated to BITBANK0
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssBANK0/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK3,class=BANK3,space=1,noexec
global __pcstackBANK3
__pcstackBANK3:
??_main:	; 1 bytes @ 0x0
	ds	2
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x0
	ds	4
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x4
	ds	1
??_Read_Temperature:	; 1 bytes @ 0x5
??_ChargeProcess_Slot:	; 1 bytes @ 0x5
??_Print_SystemStatus:	; 1 bytes @ 0x5
	ds	4
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x9
	global	ChargeProcess_Slot@vx_mv
ChargeProcess_Slot@vx_mv:	; 4 bytes @ 0x9
	ds	4
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0xD
	global	_Print_SystemStatus$729
_Print_SystemStatus$729:	; 2 bytes @ 0xD
	global	ChargeProcess_Slot@bat_mv_long
ChargeProcess_Slot@bat_mv_long:	; 4 bytes @ 0xD
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0xF
	global	_Print_SystemStatus$730
_Print_SystemStatus$730:	; 2 bytes @ 0xF
	ds	2
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x11
	global	ChargeProcess_Slot@vx_mv_383
ChargeProcess_Slot@vx_mv_383:	; 4 bytes @ 0x11
	ds	4
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x15
	global	ChargeProcess_Slot@bat_mv_long_384
ChargeProcess_Slot@bat_mv_long_384:	; 4 bytes @ 0x15
	ds	1
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x16
	ds	2
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0x18
	ds	1
	global	ChargeProcess_Slot@v_ref
ChargeProcess_Slot@v_ref:	; 2 bytes @ 0x19
	ds	2
	global	ChargeProcess_Slot@v_before
ChargeProcess_Slot@v_before:	; 2 bytes @ 0x1B
	ds	1
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0x1C
	ds	1
	global	ChargeProcess_Slot@old_st
ChargeProcess_Slot@old_st:	; 1 bytes @ 0x1D
	ds	1
	global	ChargeProcess_Slot@bat_mv
ChargeProcess_Slot@bat_mv:	; 2 bytes @ 0x1E
	ds	2
	global	Print_SystemStatus@t
Print_SystemStatus@t:	; 1 bytes @ 0x20
	global	ChargeProcess_Slot@bat_mv_385
ChargeProcess_Slot@bat_mv_385:	; 2 bytes @ 0x20
	ds	1
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x21
	ds	2
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x23
	ds	1
	global	ChargeProcess_Slot@ty
ChargeProcess_Slot@ty:	; 1 bytes @ 0x24
	ds	1
	global	ChargeProcess_Slot@st
ChargeProcess_Slot@st:	; 1 bytes @ 0x25
	ds	1
	global	ChargeProcess_Slot@ct
ChargeProcess_Slot@ct:	; 2 bytes @ 0x26
	ds	2
	global	ChargeProcess_Slot@v
ChargeProcess_Slot@v:	; 2 bytes @ 0x28
	ds	2
	global	ChargeProcess_Slot@idx
ChargeProcess_Slot@idx:	; 1 bytes @ 0x2A
	ds	1
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Update_LED_Slot:	; 1 bytes @ 0x0
?_Charging_Control:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Led_BlinkProcess:	; 1 bytes @ 0x0
??_Led_BlinkProcess:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_ChargeProcess_Slot:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Do_AdcSample:	; 1 bytes @ 0x0
?_Do_NtcRead:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_Print_DetectLog:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?i1___bmul:	; 1 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	Led_BlinkProcess@i
Led_BlinkProcess@i:	; 1 bytes @ 0x0
	global	i1___bmul@multiplicand
i1___bmul@multiplicand:	; 1 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	ds	1
??i1___bmul:	; 1 bytes @ 0x1
	global	i1___bmul@multiplier
i1___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
	global	i1___bmul@product
i1___bmul@product:	; 1 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_Update_LED_Slot:	; 1 bytes @ 0x3
??_Charging_Control:	; 1 bytes @ 0x3
	global	Charging_Control@chargeB1_6
Charging_Control@chargeB1_6:	; 1 bytes @ 0x3
	global	Update_LED_Slot@s
Update_LED_Slot@s:	; 1 bytes @ 0x3
	ds	1
??___awdiv:	; 1 bytes @ 0x4
	global	Charging_Control@chargeB7_12
Charging_Control@chargeB7_12:	; 1 bytes @ 0x4
	global	Update_LED_Slot@idx
Update_LED_Slot@idx:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	ds	1
	global	Charging_Control@s
Charging_Control@s:	; 1 bytes @ 0x5
	global	Update_LED_Slot@led
Update_LED_Slot@led:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	ds	1
	global	Charging_Control@i
Charging_Control@i:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	2
??_CCCV_Control:	; 1 bytes @ 0x8
	ds	2
??_Isr_Timer:	; 1 bytes @ 0xA
	ds	4
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x0
	ds	2
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x2
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x3
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0x4
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0x5
	ds	1
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x6
	ds	2
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x8
	ds	2
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xA
	ds	2
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0xC
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0xD
	ds	1
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0xE
	ds	2
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x10
	ds	1
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x11
	ds	1
??_AD_Init:	; 1 bytes @ 0x12
??_uart_init:	; 1 bytes @ 0x12
?_ADC_Sample:	; 1 bytes @ 0x12
??_uart_send_char:	; 1 bytes @ 0x12
?_Detect_BatteryType:	; 1 bytes @ 0x12
?___bmul:	; 1 bytes @ 0x12
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x12
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x12
	global	?___lmul
?___lmul:	; 4 bytes @ 0x12
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x12
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x12
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x12
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x12
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x12
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x12
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x13
??___bmul:	; 1 bytes @ 0x13
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x13
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x13
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x14
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x14
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x14
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x14
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x14
	ds	1
?_uart_send_string:	; 1 bytes @ 0x15
??_System_Init:	; 1 bytes @ 0x15
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x15
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x15
	ds	1
??___lwdiv:	; 1 bytes @ 0x16
??___lwmod:	; 1 bytes @ 0x16
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x16
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x16
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x16
	ds	1
??_uart_send_string:	; 1 bytes @ 0x17
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x17
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x17
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x18
	ds	1
?_uart_send_number:	; 1 bytes @ 0x19
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x19
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x19
	ds	1
??___lmul:	; 1 bytes @ 0x1A
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x1A
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x1A
	ds	1
??_uart_send_number:	; 1 bytes @ 0x1B
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x1B
	ds	3
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x1E
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x1E
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x1E
	ds	2
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x20
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0x21
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x22
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0x22
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x22
	ds	1
??_Print_NtcTemp:	; 1 bytes @ 0x23
??_Print_DetectLog:	; 1 bytes @ 0x23
	global	_Print_NtcTemp$727
_Print_NtcTemp$727:	; 2 bytes @ 0x23
	ds	1
??_Do_AdcSample:	; 1 bytes @ 0x24
	ds	1
	global	Do_AdcSample@ch
Do_AdcSample@ch:	; 1 bytes @ 0x25
	global	_Print_NtcTemp$728
_Print_NtcTemp$728:	; 2 bytes @ 0x25
	ds	1
??_Do_NtcRead:	; 1 bytes @ 0x26
??___lldiv:	; 1 bytes @ 0x26
	ds	1
;!
;!Data Sizes:
;!    Strings     288
;!    Constant    12
;!    Data        4
;!    BSS         197
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     14      14
;!    BANK0            80     39      61
;!    BANK1            80     43      79
;!    BANK3            80      2      74
;!    BANK2            80      0      72

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 37
;!		 -> STR_35(CODE[3]), STR_34(CODE[4]), STR_33(CODE[5]), STR_32(CODE[6]), 
;!		 -> STR_31(CODE[6]), STR_30(CODE[11]), STR_29(CODE[10]), STR_28(CODE[21]), 
;!		 -> STR_27(CODE[37]), STR_26(CODE[33]), STR_25(CODE[3]), STR_24(CODE[3]), 
;!		 -> STR_23(CODE[6]), STR_22(CODE[6]), STR_21(CODE[6]), STR_20(CODE[13]), 
;!		 -> STR_19(CODE[15]), STR_18(CODE[7]), STR_17(CODE[5]), STR_16(CODE[5]), 
;!		 -> STR_15(CODE[6]), STR_14(CODE[6]), STR_13(CODE[6]), STR_12(CODE[7]), 
;!		 -> STR_11(CODE[4]), STR_10(CODE[6]), STR_9(CODE[6]), STR_8(CODE[4]), 
;!		 -> STR_7(CODE[2]), STR_6(CODE[6]), STR_5(CODE[5]), STR_4(CODE[29]), 
;!		 -> STR_3(CODE[4]), STR_2(CODE[2]), STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->_CCCV_Control
;!    _Update_LED_Slot->i1___bmul
;!    _Charging_Control->i1___bmul
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Print_NtcTemp
;!    _System_Init->___bmul
;!    _Print_SystemStatus->___lldiv
;!    _Print_NtcTemp->_uart_send_number
;!    _Print_DetectLog->_uart_send_number
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _Read_Temperature->___lldiv
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->___lldiv
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    _Isr_Timer->_CCCV_Control
;!
;!Critical Paths under _main in BANK1
;!
;!    _main->_ChargeProcess_Slot
;!    _Print_SystemStatus->___lldiv
;!    _Do_NtcRead->_Read_Temperature
;!    _Read_Temperature->___lldiv
;!    _ChargeProcess_Slot->___lldiv
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 2     2      0   44451
;!                                              0 BANK3      2     2      0
;!                 _ChargeProcess_Slot
;!                       _Do_AdcSample
;!                         _Do_NtcRead
;!                    _Print_DetectLog
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                        _System_Init
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1178
;!                                             21 BANK0      1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  31    31      0   11468
;!                                              5 BANK1     31    31      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    5941
;!                                             35 BANK0      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_DetectLog                                      0     0      0    5008
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    2442
;!                                             21 BANK0      2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_number                                    10     8      2    2464
;!                                             25 BANK0     10     8      2
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     102
;!                                             18 BANK0      3     3      0
;! ---------------------------------------------------------------------------------
;! (2) ___lwmod                                              5     1      4     378
;!                                             18 BANK0      5     1      4
;! ---------------------------------------------------------------------------------
;! (1) _Do_NtcRead                                           0     0      0    4932
;!                   _Read_Temperature
;! ---------------------------------------------------------------------------------
;! (2) _Read_Temperature                                    12    12      0    4932
;!                                              5 BANK1     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (2) ___lwdiv                                              7     3      4     647
;!                                             18 BANK0      7     3      4
;! ---------------------------------------------------------------------------------
;! (1) _Do_AdcSample                                         2     2      0    1762
;!                                             36 BANK0      2     2      0
;!                         _ADC_Sample
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) _ADC_Sample                                          18    17      1     965
;!                                             18 BANK0     18    17      1
;! ---------------------------------------------------------------------------------
;! (1) _ChargeProcess_Slot                                  38    38      0    9256
;!                                              5 BANK1     38    38      0
;!                 _Detect_BatteryType
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8    1857
;!                                             18 BANK0     12     4      8
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1060
;!                                             30 BANK0      8     0      8
;!                                              0 BANK1      5     5      0
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1     763
;!                                             18 BANK0      3     2      1
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     317
;!                                             18 BANK0      2     0      2
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 2
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            4     4      0    2686
;!                                             10 COMMON     4     4      0
;!                       _CCCV_Control
;!                   _Charging_Control
;!                   _Led_BlinkProcess
;!                 _PowerOnLedSequence
;!                    _Update_LED_Slot
;! ---------------------------------------------------------------------------------
;! (5) _Update_LED_Slot                                      3     3      0     286
;!                                              3 COMMON     3     3      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Led_BlinkProcess                                     1     1      0     156
;!                                              0 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (5) _Charging_Control                                     4     4      0     568
;!                                              3 COMMON     4     4      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _CCCV_Control                                        20    20      0    1676
;!                                              8 COMMON     2     2      0
;!                                              0 BANK0     18    18      0
;!                            ___awdiv
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (6) i1___bmul                                             3     2      1     144
;!                                              0 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (6) ___awdiv                                              8     4      4     428
;!                                              0 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ChargeProcess_Slot
;!     _Detect_BatteryType
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!   _Do_AdcSample
;!     _ADC_Sample
;!     ___bmul
;!   _Do_NtcRead
;!     _Read_Temperature
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!       ___lwdiv
;!   _Print_DetectLog
;!     _uart_send_char
;!     _uart_send_number
;!       ___lwdiv
;!       ___lwmod
;!       _uart_send_char
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___lwdiv
;!       ___lwmod
;!       _uart_send_char
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___lwdiv
;!       ___lwmod
;!       _uart_send_char
;!     _uart_send_string
;!       _uart_send_char
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _uart_send_number
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     i1___bmul
;!   _Charging_Control
;!     i1___bmul
;!   _Led_BlinkProcess
;!   _PowerOnLedSequence
;!   _Update_LED_Slot
;!     i1___bmul
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50      2      4A       8       92.5%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      0      48      10       90.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50     2B      4F       6       98.8%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     27      3D       4       76.3%
;!BITBANK0            50      0       1       3        1.3%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      E       E       1      100.0%
;!BITCOMMON            E      0       0       0        0.0%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     12C      12        0.0%
;!ABS                  0      0     12C      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 452 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       2       0
;;      Totals:         0       0       0       2       0
;;Total ram usage:        2 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ChargeProcess_Slot
;;		_Do_AdcSample
;;		_Do_NtcRead
;;		_Print_DetectLog
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_System_Init
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	452
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	452
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	455
	
l4915:	
;main.c: 455: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
movwf	((??_main+0)^0180h+0+1),f
	movlw	241
movwf	((??_main+0)^0180h+0),f
	u5877:
decfsz	((??_main+0)^0180h+0),f
	goto	u5877
	decfsz	((??_main+0)^0180h+0+1),f
	goto	u5877
opt asmopt_pop

	line	456
# 456 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	459
	
l4917:	
;main.c: 459: System_Init();
	fcall	_System_Init
	line	462
	
l4919:	
;main.c: 462: uart_send_string("L1211 Charger V2.1\r\n");
	movlw	low(((STR_28)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	463
	
l4921:	
;main.c: 463: uart_send_string("Init...\r\n");
	movlw	low(((STR_29)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	466
;main.c: 466: while(1)
	
l455:	
	line	468
# 468 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	471
	
l4923:	
;main.c: 471: if(g_doAdcSample)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u5821
	goto	u5820
u5821:
	goto	l4953
u5820:
	line	473
	
l4925:	
;main.c: 472: {
;main.c: 473: g_doAdcSample = 0;
	bcf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	line	474
;main.c: 474: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	475
	
l4927:	
;main.c: 475: Do_AdcSample();
	fcall	_Do_AdcSample
	line	476
	
l4929:	
;main.c: 476: ChargeProcess_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_ChargeProcess_Slot
	line	479
	
l4931:	
;main.c: 479: if(g_dbgDetectFlag)
	bcf	status, 5	;RP0=0, select bank0
	btfss	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	goto	u5831
	goto	u5830
u5831:
	goto	l4951
u5830:
	line	481
	
l4933:	
;main.c: 480: {
;main.c: 481: g_dbgDetectFlag = 0;
	bcf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	482
	
l4935:	
;main.c: 482: uart_send_string("DBG: slot=");
	movlw	low(((STR_30)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	483
	
l4937:	
;main.c: 483: uart_send_number(g_dbgSlot);
	movf	(_g_dbgSlot),w	;volatile
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	484
	
l4939:	
;main.c: 484: uart_send_string(" old=");
	movlw	low(((STR_31)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	485
;main.c: 485: uart_send_number(g_dbgOldState);
	movf	(_g_dbgOldState),w	;volatile
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	486
	
l4941:	
;main.c: 486: uart_send_string(" new=");
	movlw	low(((STR_32)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	487
	
l4943:	
;main.c: 487: uart_send_number(g_dbgNewState);
	movf	(_g_dbgNewState),w	;volatile
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	488
;main.c: 488: uart_send_string(" ty=");
	movlw	low(((STR_33)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	489
	
l4945:	
;main.c: 489: uart_send_number(g_dbgNewType);
	movf	(_g_dbgNewType),w	;volatile
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	490
	
l4947:	
;main.c: 490: uart_send_string(" V=");
	movlw	low(((STR_34)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_34)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	491
;main.c: 491: uart_send_number(g_dbgVoltage);
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_dbgVoltage+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_dbgVoltage)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	492
	
l4949:	
;main.c: 492: uart_send_string("\r\n");
	movlw	low(((STR_35)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_35)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	495
	
l4951:	
;main.c: 493: }
;main.c: 495: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	499
	
l4953:	
;main.c: 496: }
;main.c: 499: if(g_doNtcRead)
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u5841
	goto	u5840
u5841:
	goto	l4961
u5840:
	line	501
	
l4955:	
;main.c: 500: {
;main.c: 501: g_doNtcRead = 0;
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	502
;main.c: 502: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	503
	
l4957:	
;main.c: 503: Do_NtcRead();
	fcall	_Do_NtcRead
	line	504
	
l4959:	
;main.c: 504: g_adcBusy = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	508
	
l4961:	
;main.c: 505: }
;main.c: 508: if(g_printFlag)
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u5851
	goto	u5850
u5851:
	goto	l4967
u5850:
	line	510
	
l4963:	
;main.c: 509: {
;main.c: 510: g_printFlag = 0;
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	511
	
l4965:	
;main.c: 511: Print_SystemStatus();
	fcall	_Print_SystemStatus
	line	512
;main.c: 512: Print_NtcTemp();
	fcall	_Print_NtcTemp
	line	516
	
l4967:	
;main.c: 513: }
;main.c: 516: if(g_detectLogFlag)
	btfss	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	goto	u5861
	goto	u5860
u5861:
	goto	l455
u5860:
	line	518
	
l4969:	
;main.c: 517: {
;main.c: 518: g_detectLogFlag = 0;
	bcf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	line	519
	
l4971:	
;main.c: 519: Print_DetectLog();
	fcall	_Print_DetectLog
	goto	l455
	global	start
	ljmp	start
	opt stack 0
	line	522
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 68 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   21[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	68
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	68
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	73
	
l4063:	
# 73 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	74
# 74 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text1
	line	75
	
l4065:	
;main.c: 75: OSCCON = 0x72;
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	79
;main.c: 79: TRISA = 0xF0; PORTA = 0x0F;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	80
;main.c: 80: TRISB = 0x30; PORTB = 0x4F;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	81
;main.c: 81: TRISC = 0x07; PORTC = 0x00;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l4067:	
	clrf	(262)^0100h	;volatile
	line	82
	
l4069:	
;main.c: 82: TRISD = 0xF0; PORTD = 0x0F;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l4071:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	85
	
l4073:	
;main.c: 85: WPUA = 0x00; WPDA = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l4075:	
	clrf	(135)^080h	;volatile
	line	86
	
l4077:	
;main.c: 86: WPUB = 0x00; WPDB = 0x00;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l4079:	
	clrf	(7)	;volatile
	line	87
	
l4081:	
;main.c: 87: WPUC = 0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	88
	
l4083:	
;main.c: 88: WPUD = 0x00;
	clrf	(277)^0100h	;volatile
	line	91
	
l4085:	
;main.c: 91: IOCA = 0x00; IOCB = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l4087:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	94
	
l4089:	
;main.c: 94: CC0CON = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	95
	
l4091:	
;main.c: 95: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	102
	
l4093:	
;main.c: 102: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	103
	
l4095:	
;main.c: 103: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	104
	
l4097:	
;main.c: 104: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	105
	
l4099:	
;main.c: 105: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	108
	
l4101:	
;main.c: 108: AD_Init();
	fcall	_AD_Init
	line	111
	
l4103:	
;main.c: 111: uart_init();
	fcall	_uart_init
	line	118
;main.c: 118: OPTION_REG = 0x00;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	119
	
l4105:	
;main.c: 119: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	120
	
l4107:	
;main.c: 120: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	121
	
l4109:	
;main.c: 121: INTCON = 0xE0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	124
;main.c: 124: g_pwmDuty = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	125
;main.c: 125: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	126
	
l4111:	
;main.c: 126: RC3 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	127
	
l4113:	
;main.c: 127: RC5 = 0;
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	128
	
l4115:	
;main.c: 128: RB6 = 1;
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	129
	
l4117:	
;main.c: 129: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	132
;main.c: 132: for(i = 0; i < 12; i++)
	clrf	(System_Init@i)
	line	134
	
l4123:	
;main.c: 133: {
;main.c: 134: g_slot[i].state = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	135
;main.c: 135: g_slot[i].type = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	136
;main.c: 136: g_slot[i].voltage = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	137
;main.c: 137: g_slot[i].chargeTimer = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	138
	
l4125:	
;main.c: 138: g_ccBlocks[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	139
	
l4127:	
;main.c: 139: g_ovCnt[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	132
	
l4129:	
	incf	(System_Init@i),f
	
l4131:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u4571
	goto	u4570
u4571:
	goto	l4123
u4570:
	line	141
	
l4133:	
;main.c: 140: }
;main.c: 141: for(i = 0; i < 12; i++)
	clrf	(System_Init@i)
	line	143
	
l4139:	
;main.c: 142: {
;main.c: 143: g_ledState[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ledState|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	144
;main.c: 144: g_blinkPhase[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_blinkPhase|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	145
;main.c: 145: g_blinkTimer[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_blinkTimer|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	141
	
l4141:	
	incf	(System_Init@i),f
	
l4143:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u4581
	goto	u4580
u4581:
	goto	l4139
u4580:
	line	149
	
l365:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
global __ptext2
__ptext2:	;psect for function _uart_init
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_init: []
	line	23
	
l2653:	
;uart_dbg.c: 23: TRISC &= (unsigned char)~0x10;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
;uart_dbg.c: 24: ANSEL2 &= (unsigned char)~0x10;
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
;uart_dbg.c: 25: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l493:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
global __ptext3
__ptext3:	;psect for function _AD_Init
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l2647:	
;adc_drv.c: 25: CC0CON = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
;adc_drv.c: 26: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	27
	
l2649:	
;adc_drv.c: 27: ADCON0 = 0X81;
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l2651:	
;adc_drv.c: 28: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	29
	
l470:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 319 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  t               1   32[BANK1 ] unsigned char 
;;  bat_mv_long     4   28[BANK1 ] unsigned long 
;;  vx_mv           4   24[BANK1 ] unsigned long 
;;  v               2   22[BANK1 ] unsigned int 
;;  s               1   21[BANK1 ] unsigned char 
;;  pt              4   17[BANK1 ] unsigned long 
;;  vcc_mv          2   33[BANK1 ] unsigned int 
;;  i               1   35[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      23       0       0
;;      Temps:          0       0       8       0       0
;;      Totals:         0       0      31       0       0
;;Total ram usage:       31 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	319
global __ptext4
__ptext4:	;psect for function _Print_SystemStatus
psect	text4
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	319
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	324
	
l4347:	
;main.c: 321: unsigned char i;
;main.c: 322: unsigned int vcc_mv;
;main.c: 324: uart_send_string("\r\n== L1211 12CH CHARGER ==\r\n");
	movlw	low(((STR_4)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	327
	
l4349:	
;main.c: 327: test_adc = ADC_Sample(31, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	328
	
l4351:	
;main.c: 328: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u4961
	goto	u4960
u4961:
	goto	l4357
u4960:
	line	330
	
l4353:	
;main.c: 329: {
;main.c: 330: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult),w	;volatile
	movwf	(___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@pt+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@pt+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@pt+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@pt)^080h

	line	331
	
l4355:	
;main.c: 331: vcc_mv = (unsigned int)pt;
	movf	(Print_SystemStatus@pt+1)^080h,w
	movwf	(Print_SystemStatus@vcc_mv+1)^080h
	movf	(Print_SystemStatus@pt)^080h,w
	movwf	(Print_SystemStatus@vcc_mv)^080h
	line	332
;main.c: 332: }
	goto	l420
	line	334
	
l4357:	
;main.c: 333: else
;main.c: 334: vcc_mv = 5000;
	movlw	088h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vcc_mv)^080h
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv)^080h)+1
	
l420:	
	line	336
;main.c: 336: g_vcc_mv = vcc_mv;
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	line	338
	
l4359:	
;main.c: 338: uart_send_string("VCC=");
	movlw	low(((STR_5)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	339
	
l4361:	
;main.c: 339: uart_send_number(vcc_mv);
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	340
	
l4363:	
;main.c: 340: uart_send_string("mV T=");
	movlw	low(((STR_6)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	341
	
l4365:	
;main.c: 341: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$729+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$729)^080h
	
l4367:	
;main.c: 341: uart_send_number(g_temperature / 10U);
	movf	(_Print_SystemStatus$729+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_Print_SystemStatus$729)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	342
	
l4369:	
;main.c: 342: uart_send_string(".");
	movlw	low(((STR_7)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	343
	
l4371:	
;main.c: 343: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$730+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$730)^080h
	
l4373:	
;main.c: 343: uart_send_number(g_temperature % 10U);
	movf	(_Print_SystemStatus$730+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_Print_SystemStatus$730)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	344
	
l4375:	
;main.c: 344: uart_send_string("C\r\n");
	movlw	low(((STR_8)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	348
	
l4377:	
;main.c: 348: for(i = 0; i < 6; i++)
	bsf	status, 5	;RP0=1, select bank1
	clrf	(Print_SystemStatus@i)^080h
	line	357
	
l4383:	
;main.c: 356: {
;main.c: 357: unsigned int v = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@v)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)^080h
	line	358
;main.c: 358: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@s)^080h
	line	365
	
l4385:	
;main.c: 365: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	366
	
l4387:	
;main.c: 366: uart_send_number((unsigned int)i + 1U);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	367
;main.c: 367: uart_send_char('=');
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	368
	
l4389:	
;main.c: 368: uart_send_number(v);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	374
	
l4391:	
;main.c: 373: {
;main.c: 374: unsigned long vx_mv = (unsigned long)v * (unsigned long)vcc_mv / 4096UL;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vx_mv+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vx_mv+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vx_mv+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vx_mv)^080h

	
l4393:	
	movlw	0Ch
u4975:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3)^080h,f
	rrf	(Print_SystemStatus@vx_mv+2)^080h,f
	rrf	(Print_SystemStatus@vx_mv+1)^080h,f
	rrf	(Print_SystemStatus@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u4975

	line	375
	
l4395:	
;main.c: 375: if(vx_mv + 200U >= (unsigned long)vcc_mv)
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	clrf	((??_Print_SystemStatus+0)^080h+0+2)
	clrf	((??_Print_SystemStatus+0)^080h+0+3)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+4)^080h+0)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	(Print_SystemStatus@vx_mv)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+0,f
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1)^080h,w
	goto	u4980
	goto	u4981
u4980:
	addwf	(??_Print_SystemStatus+4)^080h+1,f
u4981:
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2)^080h,w
	goto	u4982
	goto	u4983
u4982:
	addwf	(??_Print_SystemStatus+4)^080h+2,f
u4983:
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	subwf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u4995
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	subwf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u4995
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	subwf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u4995
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	subwf	0+(??_Print_SystemStatus+4)^080h+0,w
u4995:
	skipc
	goto	u4991
	goto	u4990
u4991:
	goto	l4399
u4990:
	line	377
	
l4397:	
;main.c: 376: {
;main.c: 377: uart_send_string(" OPEN");
	movlw	low(((STR_9)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	378
;main.c: 378: }
	goto	l4409
	line	381
	
l4399:	
;main.c: 379: else
;main.c: 380: {
;main.c: 381: unsigned long bat_mv_long = 124UL * vx_mv;
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vx_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long)^080h

	line	382
;main.c: 382: if(bat_mv_long > (206UL * (unsigned long)vcc_mv))
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0CEh
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(3+(?___lmul)),w
	skipz
	goto	u5005
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long+2)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(2+(?___lmul)),w
	skipz
	goto	u5005
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(1+(?___lmul)),w
	skipz
	goto	u5005
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(0+(?___lmul)),w
u5005:
	skipnc
	goto	u5001
	goto	u5000
u5001:
	goto	l4409
u5000:
	line	384
	
l4401:	
;main.c: 383: {
;main.c: 384: bat_mv_long = (bat_mv_long - 206UL * (unsigned long)vcc_mv + 1000UL/2UL) / 1000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	bsf	status, 5	;RP0=1, select bank1
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+3)
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)
	movlw	0FFh
	movwf	(___lmul@multiplicand+1)
	movlw	032h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(0+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(Print_SystemStatus@bat_mv_long)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+0)
	movlw	0
	skipnc
	movlw	1
	bcf	status, 5	;RP0=0, select bank0
	addwf	(1+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	clrf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	addwf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	((??_Print_SystemStatus+4)^080h+0+2),w
	clrf	((??_Print_SystemStatus+4)^080h+0+3)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	addwf	(Print_SystemStatus@bat_mv_long+2)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	bcf	status, 5	;RP0=0, select bank0
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	((??_Print_SystemStatus+4)^080h+0+3),w
	addwf	(Print_SystemStatus@bat_mv_long+3)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	0+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+0,f
	movf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	1+(??_Print_SystemStatus+4)^080h+0,w
	goto	u5010
	goto	u5011
u5010:
	addwf	(??_Print_SystemStatus+0)^080h+1,f
u5011:
	movf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	2+(??_Print_SystemStatus+4)^080h+0,w
	goto	u5012
	goto	u5013
u5012:
	addwf	(??_Print_SystemStatus+0)^080h+2,f
u5013:
	movf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incf	3+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long)^080h

	line	385
	
l4403:	
;main.c: 385: uart_send_string(" BAT(");
	movlw	low(((STR_10)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	386
	
l4405:	
;main.c: 386: uart_send_number((unsigned int)bat_mv_long);
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	387
	
l4407:	
;main.c: 387: uart_send_string("mV)");
	movlw	low(((STR_11)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	394
	
l4409:	
;main.c: 388: }
;main.c: 390: }
;main.c: 391: }
;main.c: 394: uart_send_char(' ');
	movlw	low(020h)
	fcall	_uart_send_char
	line	395
;main.c: 395: switch(s)
	goto	l4445
	line	397
	
l4411:	
	movlw	low(((STR_12)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4447
	line	398
	
l4413:	
	movlw	low(((STR_13)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4447
	line	399
	
l4415:	
	movlw	low(((STR_14)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4447
	line	400
	
l4417:	
	movlw	low(((STR_15)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4447
	line	401
	
l4419:	
	movlw	low(((STR_16)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4447
	line	402
	
l4421:	
	movlw	low(((STR_17)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4447
	line	403
	
l4423:	
	movlw	low(((STR_18)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4447
	line	406
	
l4425:	
;main.c: 405: {
;main.c: 406: unsigned char t = g_slot[(unsigned char)(i)].type;
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@t)^080h
	line	407
	
l4427:	
;main.c: 407: if(t == 2 || t == 3)
		movlw	2
	xorwf	((Print_SystemStatus@t)^080h),w
	btfsc	status,2
	goto	u5021
	goto	u5020
u5021:
	goto	l4431
u5020:
	
l4429:	
		movlw	3
	xorwf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u5031
	goto	u5030
u5031:
	goto	l4433
u5030:
	line	408
	
l4431:	
;main.c: 408: uart_send_string("[Dry/NiMH ERR]");
	movlw	low(((STR_19)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4447
	line	409
	
l4433:	
;main.c: 409: else if(t == 1)
		decf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u5041
	goto	u5040
u5041:
	goto	l4437
u5040:
	line	410
	
l4435:	
;main.c: 410: uart_send_string("[Li-ion ERR]");
	movlw	low(((STR_20)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4447
	line	412
	
l4437:	
;main.c: 411: else
;main.c: 412: uart_send_string("[ERR]");
	movlw	low(((STR_21)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4447
	line	415
	
l4439:	
	movlw	low(((STR_22)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4447
	line	416
	
l4441:	
	movlw	low(((STR_23)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4447
	line	395
	
l4445:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@s)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 9, Range of values is 0 to 8
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           28    15 (average)
; direct_byte           35     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l4411
	xorlw	1^0	; case 1
	skipnz
	goto	l4413
	xorlw	2^1	; case 2
	skipnz
	goto	l4415
	xorlw	3^2	; case 3
	skipnz
	goto	l4417
	xorlw	4^3	; case 4
	skipnz
	goto	l4419
	xorlw	5^4	; case 5
	skipnz
	goto	l4421
	xorlw	6^5	; case 6
	skipnz
	goto	l4423
	xorlw	7^6	; case 7
	skipnz
	goto	l4425
	xorlw	8^7	; case 8
	skipnz
	goto	l4439
	goto	l4441
	opt asmopt_pop

	line	420
	
l4447:	
;main.c: 420: uart_send_string("\r\n");
	movlw	low(((STR_24)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	348
	
l4449:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(Print_SystemStatus@i)^080h,f
	
l4451:	
	movlw	low(06h)
	subwf	(Print_SystemStatus@i)^080h,w
	skipc
	goto	u5051
	goto	u5050
u5051:
	goto	l4383
u5050:
	line	423
	
l4453:	
;main.c: 422: }
;main.c: 423: uart_send_string("\r\n");
	movlw	low(((STR_25)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	424
	
l444:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 299 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	299
global __ptext5
__ptext5:	;psect for function _Print_NtcTemp
psect	text5
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	299
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	301
	
l4335:	
;main.c: 301: uart_send_string("NTC=");
	movlw	low(((STR_1)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	302
	
l4337:	
;main.c: 302: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$727+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$727)
	
l4339:	
;main.c: 302: uart_send_number(g_temperature / 10U);
	movf	(_Print_NtcTemp$727+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$727),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	303
	
l4341:	
;main.c: 303: uart_send_string(".");
	movlw	low(((STR_2)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	304
	
l4343:	
;main.c: 304: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	movwf	(_Print_NtcTemp$728+1)
	movf	(0+(?___lwmod)),w
	movwf	(_Print_NtcTemp$728)
;main.c: 304: uart_send_number(g_temperature % 10U);
	movf	(_Print_NtcTemp$728+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$728),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	305
	
l4345:	
;main.c: 305: uart_send_string("C\r\n");
	movlw	low(((STR_3)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	306
	
l416:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_Print_DetectLog

;; *************** function _Print_DetectLog *****************
;; Defined at:
;;		line 430 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	line	430
global __ptext6
__ptext6:	;psect for function _Print_DetectLog
psect	text6
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	430
	global	__size_of_Print_DetectLog
	__size_of_Print_DetectLog	equ	__end_of_Print_DetectLog-_Print_DetectLog
	
_Print_DetectLog:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_DetectLog: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	432
	
l4455:	
;main.c: 432: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	433
	
l4457:	
;main.c: 433: uart_send_number((unsigned int)g_detectLogSlot + 1U);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_detectLogSlot),w	;volatile
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	435
	
l4459:	
;main.c: 435: if(g_detectLogType == 2)
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u5061
	goto	u5060
u5061:
	goto	l4463
u5060:
	line	436
	
l4461:	
;main.c: 436: uart_send_string(": NiMH detected! Not charging.\r\n");
	movlw	low(((STR_26)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l450
	line	437
	
l4463:	
;main.c: 437: else if(g_detectLogType == 3)
		movlw	3
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u5071
	goto	u5070
u5071:
	goto	l450
u5070:
	line	438
	
l4465:	
;main.c: 438: uart_send_string(": Dry/NiMH detected! Not charging.\r\n");
	movlw	low(((STR_27)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	439
	
l450:	
	return
	opt stack 0
GLOBAL	__end_of_Print_DetectLog
	__end_of_Print_DetectLog:
	signat	_Print_DetectLog,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2   21[BANK0 ] PTR const unsigned char 
;;		 -> STR_35(3), STR_34(4), STR_33(5), STR_32(6), 
;;		 -> STR_31(6), STR_30(11), STR_29(10), STR_28(21), 
;;		 -> STR_27(37), STR_26(33), STR_25(3), STR_24(3), 
;;		 -> STR_23(6), STR_22(6), STR_21(6), STR_20(13), 
;;		 -> STR_19(15), STR_18(7), STR_17(5), STR_16(5), 
;;		 -> STR_15(6), STR_14(6), STR_13(6), STR_12(7), 
;;		 -> STR_11(4), STR_10(6), STR_9(6), STR_8(4), 
;;		 -> STR_7(2), STR_6(6), STR_5(5), STR_4(29), 
;;		 -> STR_3(4), STR_2(2), STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
global __ptext7
__ptext7:	;psect for function _uart_send_string
psect	text7
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l4013:	
;uart_dbg.c: 63: while(*str != '\0')
	goto	l4019
	line	65
	
l4015:	
;uart_dbg.c: 64: {
;uart_dbg.c: 65: uart_send_char(*str++);
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	fcall	_uart_send_char
	
l4017:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(uart_send_string@str),f
	skipnz
	incf	(uart_send_string@str+1),f
	line	66
# 66 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
clrwdt ;# 
psect	text7
	line	63
	
l4019:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u4511
	goto	u4510
u4511:
	goto	l4015
u4510:
	line	68
	
l506:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2   25[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6   27[BANK0 ] unsigned char [6]
;;  j               1   34[BANK0 ] unsigned char 
;;  i               1   33[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      10       0       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext8
__ptext8:	;psect for function _uart_send_number
psect	text8
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l4021:	
;uart_dbg.c: 79: unsigned char buf[6];
;uart_dbg.c: 80: unsigned char i = 0;
	clrf	(uart_send_number@i)
	line	84
	
l4023:	
;uart_dbg.c: 81: unsigned char j;
;uart_dbg.c: 84: if(num == 0)
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u4521
	goto	u4520
u4521:
	goto	l4035
u4520:
	line	86
	
l4025:	
;uart_dbg.c: 85: {
;uart_dbg.c: 86: uart_send_char('0');
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l510
	line	93
	
l4029:	
;uart_dbg.c: 92: {
;uart_dbg.c: 93: buf[i++] = '0' + (num % 10);
	movf	(uart_send_number@i),w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwmod@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank0
	movwf	indf
	
l4031:	
	incf	(uart_send_number@i),f
	line	94
	
l4033:	
;uart_dbg.c: 94: num /= 10;
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(uart_send_number@num+1)
	movf	(0+(?___lwdiv)),w
	movwf	(uart_send_number@num)
	line	91
	
l4035:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u4531
	goto	u4530
u4531:
	goto	l4029
u4530:
	line	98
	
l4037:	
;uart_dbg.c: 95: }
;uart_dbg.c: 98: for(j = i; j > 0; j--)
	movf	(uart_send_number@i),w
	movwf	(uart_send_number@j)
	
l4039:	
	movf	((uart_send_number@j)),w
	btfss	status,2
	goto	u4541
	goto	u4540
u4541:
	goto	l4043
u4540:
	goto	l510
	line	99
	
l4043:	
;uart_dbg.c: 99: uart_send_char(buf[(unsigned char)(j - 1)]);
	movf	(uart_send_number@j),w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l4045:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decf	(uart_send_number@j),f
	goto	l4039
	line	100
	
l510:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1   19[BANK0 ] unsigned char 
;;  i               1   20[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext9
__ptext9:	;psect for function _uart_send_char
psect	text9
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_char: [wreg+status,2+status,0]
;uart_send_char@c stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_char@c)
	line	38
	
l3867:	
;uart_dbg.c: 37: unsigned char i;
;uart_dbg.c: 38: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	39
;uart_dbg.c: 39: RC4 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l3869:	
;uart_dbg.c: 40: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u5887:
decfsz	(??_uart_send_char+0)+0,f
	goto	u5887
	nop2
opt asmopt_pop

	line	41
	
l3871:	
;uart_dbg.c: 41: for(i = 0; i < 8; i++)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(uart_send_char@i)
	line	42
	
l496:	
	line	43
;uart_dbg.c: 42: {
;uart_dbg.c: 43: if(c & 0x01)
	btfss	(uart_send_char@c),(0)&7
	goto	u4231
	goto	u4230
u4231:
	goto	l498
u4230:
	line	44
	
l3877:	
;uart_dbg.c: 44: RC4 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l3879
	line	45
	
l498:	
	line	46
;uart_dbg.c: 45: else
;uart_dbg.c: 46: RC4 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l3879:	
;uart_dbg.c: 47: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u5897:
decfsz	(??_uart_send_char+0)+0,f
	goto	u5897
	nop2
opt asmopt_pop

	line	48
	
l3881:	
;uart_dbg.c: 48: c >>= 1;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rrf	(uart_send_char@c),f
	line	41
	
l3883:	
	incf	(uart_send_char@i),f
	
l3885:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u4241
	goto	u4240
u4241:
	goto	l496
u4240:
	
l497:	
	line	50
;uart_dbg.c: 49: }
;uart_dbg.c: 50: RC4 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l3887:	
;uart_dbg.c: 51: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u5907:
decfsz	(??_uart_send_char+0)+0,f
	goto	u5907
	nop2
opt asmopt_pop

	line	52
	
l3889:	
;uart_dbg.c: 52: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l500:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   18[BANK0 ] unsigned int 
;;  dividend        2   20[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1   22[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   18[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       5       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext10
__ptext10:	;psect for function ___lwmod
psect	text10
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l3955:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u4361
	goto	u4360
u4361:
	goto	l3971
u4360:
	line	14
	
l3957:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l3961
	line	16
	
l3959:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l3961:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u4371
	goto	u4370
u4371:
	goto	l3959
u4370:
	line	20
	
l3963:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u4385
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u4385:
	skipc
	goto	u4381
	goto	u4380
u4381:
	goto	l3967
u4380:
	line	21
	
l3965:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l3967:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l3969:	
	decfsz	(___lwmod@counter),f
	goto	u4391
	goto	u4390
u4391:
	goto	l3963
u4390:
	line	25
	
l3971:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1124:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	_Do_NtcRead

;; *************** function _Do_NtcRead *****************
;; Defined at:
;;		line 290 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Read_Temperature
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	290
global __ptext11
__ptext11:	;psect for function _Do_NtcRead
psect	text11
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	290
	global	__size_of_Do_NtcRead
	__size_of_Do_NtcRead	equ	__end_of_Do_NtcRead-_Do_NtcRead
	
_Do_NtcRead:	
;incstack = 0
	opt	stack 2
; Regs used in _Do_NtcRead: [wreg+status,2+status,0+pclath+cstack]
	line	292
	
l4333:	
;main.c: 292: Read_Temperature();
	fcall	_Read_Temperature
	line	293
	
l413:	
	return
	opt stack 0
GLOBAL	__end_of_Do_NtcRead
	__end_of_Do_NtcRead:
	signat	_Do_NtcRead,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 27 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4    9[BANK1 ] unsigned long 
;;  temp_x10        2   15[BANK1 ] unsigned int 
;;  ntcVal          2   13[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   70[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Do_NtcRead
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	27
global __ptext12
__ptext12:	;psect for function _Read_Temperature
psect	text12
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	27
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 2
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	32
	
l3975:	
;charge_mgr.c: 29: unsigned int ntcVal;
;charge_mgr.c: 30: unsigned int temp_x10;
;charge_mgr.c: 32: test_adc = ADC_Sample(18, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	33
	
l3977:	
;charge_mgr.c: 33: if(0xA5 != test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u4401
	goto	u4400
u4401:
	goto	l3981
u4400:
	goto	l545
	line	36
	
l3981:	
;charge_mgr.c: 36: ntcVal = adresult;
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal)^080h
	line	37
;charge_mgr.c: 37: if(ntcVal < 100 || ntcVal > 3996)
	movlw	0
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u4411
	goto	u4410
u4411:
	goto	l545
u4410:
	
l3983:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u4421
	goto	u4420
u4421:
	goto	l3985
u4420:
	goto	l545
	line	42
	
l3985:	
;charge_mgr.c: 40: {
;charge_mgr.c: 41: unsigned long rt;
;charge_mgr.c: 42: rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	010h
	movwf	(___lldiv@divisor+1)
	movlw	0
	movwf	(___lldiv@divisor)

	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0)
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0+1)
	clrf	((??_Read_Temperature+0)^080h+0+2)
	clrf	((??_Read_Temperature+0)^080h+0+3)
	movf	0+(??_Read_Temperature+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lldiv@divisor),f
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)^080h+0,w
	goto	u4435
	goto	u4436
u4435:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lldiv@divisor+1),f
u4436:
	bsf	status, 5	;RP0=1, select bank1
	movf	2+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)^080h+0,w
	goto	u4437
	goto	u4438
u4437:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lldiv@divisor+2),f
u4438:
	bsf	status, 5	;RP0=1, select bank1
	movf	3+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)^080h+0,w
	goto	u4439
	goto	u4430
u4439:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lldiv@divisor+3),f
u4430:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 5	;RP0=0, select bank0

	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@ntcVal)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@ntcVal+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	027h
	movwf	(___lmul@multiplicand+1)
	movlw	010h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@rt+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@rt+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@rt+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@rt)^080h

	line	43
	
l3987:	
;charge_mgr.c: 43: if(rt >= 10000UL)
		movf	(Read_Temperature@rt+3)^080h,w
	btfss	status,2
	goto	u4440
	movf	(Read_Temperature@rt+2)^080h,w
	btfss	status,2
	goto	u4440
	movlw	39
	subwf	(Read_Temperature@rt+1)^080h,w
	skipz
	goto	u4443
	movlw	16
	subwf	(Read_Temperature@rt)^080h,w
	skipz
	goto	u4443
u4443:
	btfss	status,0
	goto	u4441
	goto	u4440

u4441:
	goto	l3993
u4440:
	line	44
	
l3989:	
;charge_mgr.c: 44: temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l3991:	
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0F0h
	bsf	status, 5	;RP0=1, select bank1
	movwf	((??_Read_Temperature+0)^080h+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)^080h+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+3)
	movf	(Read_Temperature@rt)^080h,w
	addwf	(??_Read_Temperature+0)^080h+0,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+1)^080h,w
	goto	u4450
	goto	u4451
u4450:
	addwf	(??_Read_Temperature+0)^080h+1,f
u4451:
	movf	(Read_Temperature@rt+2)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+2)^080h,w
	goto	u4452
	goto	u4453
u4452:
	addwf	(??_Read_Temperature+0)^080h+2,f
u4453:
	movf	(Read_Temperature@rt+3)^080h,w
	skipnc
	incf	(Read_Temperature@rt+3)^080h,w
	addwf	(??_Read_Temperature+0)^080h+3,f
	movf	3+(??_Read_Temperature+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	2+(??_Read_Temperature+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(??_Read_Temperature+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(??_Read_Temperature+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Read_Temperature@temp_x10)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	skipc
	decf	(Read_Temperature@temp_x10+1)^080h,f
	subwf	(Read_Temperature@temp_x10+1)^080h,f
	goto	l3997
	line	46
	
l3993:	
;charge_mgr.c: 45: else
;charge_mgr.c: 46: temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0
	movwf	(___lmul@multiplier+3)
	movlw	0
	movwf	(___lmul@multiplier+2)
	movlw	027h
	movwf	(___lmul@multiplier+1)
	movlw	010h
	movwf	(___lmul@multiplier)

	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@rt)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lmul@multiplier),f
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@rt+1)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+1)^080h,w
	goto	u4465
	goto	u4466
u4465:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lmul@multiplier+1),f
u4466:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@rt+2)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+2)^080h,w
	goto	u4467
	goto	u4468
u4467:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lmul@multiplier+2),f
u4468:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@rt+3)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+3)^080h,w
	goto	u4469
	goto	u4460
u4469:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lmul@multiplier+3),f
u4460:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 5	;RP0=0, select bank0

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@temp_x10+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@temp_x10)^080h
	
l3995:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10)^080h,f
	skipnc
	incf	(Read_Temperature@temp_x10+1)^080h,f
	line	47
	
l3997:	
;charge_mgr.c: 47: if(temp_x10 < 100U) temp_x10 = 100U;
	movlw	0
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipnc
	goto	u4471
	goto	u4470
u4471:
	goto	l551
u4470:
	
l3999:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l551:	
	line	48
;charge_mgr.c: 48: if(temp_x10 > 750U) temp_x10 = 750U;
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipc
	goto	u4481
	goto	u4480
u4481:
	goto	l552
u4480:
	
l4001:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)^080h
	movlw	02h
	movwf	((Read_Temperature@temp_x10)^080h)+1
	
l552:	
	line	51
;charge_mgr.c: 49: }
;charge_mgr.c: 51: g_temperature = temp_x10;
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature)
	line	52
	
l4003:	
;charge_mgr.c: 52: if((temp_x10 / 10U) >= 60)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u4491
	goto	u4490
u4491:
	goto	l4007
u4490:
	line	53
	
l4005:	
;charge_mgr.c: 53: g_tempProtect = 1;
	clrf	(_g_tempProtect)
	incf	(_g_tempProtect),f
	goto	l545
	line	54
	
l4007:	
;charge_mgr.c: 54: else if((temp_x10 / 10U) <= 50)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u4501
	goto	u4500
u4501:
	goto	l545
u4500:
	line	55
	
l4009:	
;charge_mgr.c: 55: g_tempProtect = 0;
	clrf	(_g_tempProtect)
	line	58
	
l545:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   18[BANK0 ] unsigned int 
;;  dividend        2   20[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2   23[BANK0 ] unsigned int 
;;  counter         1   22[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   18[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       7       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext13
__ptext13:	;psect for function ___lwdiv
psect	text13
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l3929:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l3931:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u4321
	goto	u4320
u4321:
	goto	l3951
u4320:
	line	16
	
l3933:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l3937
	line	18
	
l3935:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l3937:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u4331
	goto	u4330
u4331:
	goto	l3935
u4330:
	line	22
	
l3939:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l3941:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u4345
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u4345:
	skipc
	goto	u4341
	goto	u4340
u4341:
	goto	l3947
u4340:
	line	24
	
l3943:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l3945:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l3947:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l3949:	
	decfsz	(___lwdiv@counter),f
	goto	u4351
	goto	u4350
u4351:
	goto	l3939
u4350:
	line	30
	
l3951:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l1114:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	_Do_AdcSample

;; *************** function _Do_AdcSample *****************
;; Defined at:
;;		line 265 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  ch              1   37[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	265
global __ptext14
__ptext14:	;psect for function _Do_AdcSample
psect	text14
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	265
	global	__size_of_Do_AdcSample
	__size_of_Do_AdcSample	equ	__end_of_Do_AdcSample-_Do_AdcSample
	
_Do_AdcSample:	
;incstack = 0
	opt	stack 3
; Regs used in _Do_AdcSample: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	267
	
l4319:	
;main.c: 267: unsigned char ch = s_adcChannels[g_scanIndex];
	movf	(_g_scanIndex),w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(Do_AdcSample@ch)
	line	272
	
l4321:	
;main.c: 272: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Do_AdcSample+0)+0),f
	u5917:
decfsz	(??_Do_AdcSample+0)+0,f
	goto	u5917
	nop
opt asmopt_pop

	line	274
	
l4323:	
;main.c: 274: test_adc = ADC_Sample(ch, 0);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@adldo)
	movf	(Do_AdcSample@ch),w
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	276
	
l4325:	
;main.c: 276: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u4951
	goto	u4950
u4951:
	goto	l4329
u4950:
	line	277
	
l4327:	
;main.c: 277: g_slot[g_scanIndex].voltage = adresult;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	movf	(_adresult),w	;volatile
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_adresult+1),w	;volatile
	movwf	indf
	goto	l4331
	line	279
	
l4329:	
;main.c: 278: else
;main.c: 279: g_slot[g_scanIndex].voltage = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	281
	
l4331:	
;main.c: 281: g_scanPhase = 1;
	movlw	low(01h)
	movwf	(_g_scanPhase)	;volatile
	line	282
	
l410:	
	return
	opt stack 0
GLOBAL	__end_of_Do_AdcSample
	__end_of_Do_AdcSample:
	signat	_Do_AdcSample,89
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1   18[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1   24[BANK0 ] unsigned char 
;;  j               1   23[BANK0 ] unsigned char 
;;  adsum           4   26[BANK0 ] volatile unsigned long 
;;  ad_temp         2   34[BANK0 ] volatile unsigned int 
;;  admax           2   32[BANK0 ] volatile unsigned int 
;;  admin           2   30[BANK0 ] volatile unsigned int 
;;  i               1   25[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      18       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext15
__ptext15:	;psect for function _ADC_Sample
psect	text15
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	movwf	(ADC_Sample@adch)
	line	51
	
l3801:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	52
	
l3803:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	58
	
l3805:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u4081
	goto	u4080
u4081:
	goto	l3811
u4080:
	
l3807:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u4091
	goto	u4090
u4091:
	goto	l3811
u4090:
	line	60
	
l3809:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u5927:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u5927
	nop
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	l3813
	line	64
	
l3811:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	bcf	status, 5	;RP0=0, select bank0
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	67
	
l3813:	
;adc_drv.c: 67: if(adch & 0x10)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(ADC_Sample@adch),(4)&7
	goto	u4101
	goto	u4100
u4101:
	goto	l475
u4100:
	line	69
	
l3815:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l3817:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(ADC_Sample@adch),f
	line	71
;adc_drv.c: 71: }
	goto	l3819
	line	72
	
l475:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l3819:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@i)
	line	79
	
l3825:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(ADC_Sample@adch),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u4115:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u4115
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l3827:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	5
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u5937:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u5937
	nop2
opt asmopt_pop

	line	81
	
l3829:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l3831:	
;adc_drv.c: 84: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	l479
	
l480:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u4121
	goto	u4120
u4121:
	goto	l479
u4120:
	line	89
	
l3833:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	l482
	line	90
	
l479:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u4131
	goto	u4130
u4131:
	goto	l480
u4130:
	line	93
	
l3837:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
l3839:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
l3841:	
;adc_drv.c: 96: if(0 == admax)
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u4141
	goto	u4140
u4141:
	goto	l3845
u4140:
	line	98
	
l3843:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	100
;adc_drv.c: 100: }
	goto	l485
	line	102
	
l3845:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u4155
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u4155:
	skipnc
	goto	u4151
	goto	u4150
u4151:
	goto	l3849
u4150:
	line	103
	
l3847:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	l485
	line	105
	
l3849:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u4165
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u4165:
	skipnc
	goto	u4161
	goto	u4160
u4161:
	goto	l485
u4160:
	line	106
	
l3851:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	108
	
l485:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u4171
	addwf	(ADC_Sample@adsum+1),f	;volatile
u4171:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u4172
	addwf	(ADC_Sample@adsum+2),f	;volatile
u4172:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u4173
	addwf	(ADC_Sample@adsum+3),f	;volatile
u4173:

	line	76
	
l3853:	
	incf	(ADC_Sample@i),f
	
l3855:	
	movlw	low(022h)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u4181
	goto	u4180
u4181:
	goto	l3825
u4180:
	line	112
	
l3857:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u4195
	goto	u4196
u4195:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u4196:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u4197
	goto	u4198
u4197:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u4198:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u4199
	goto	u4190
u4199:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u4190:

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u4205
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u4205
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u4205
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u4205:
	skipc
	goto	u4201
	goto	u4200
u4201:
	goto	l489
u4200:
	line	114
	
l3859:	
;adc_drv.c: 114: adsum -= admin;
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u4215
	goto	u4216
u4215:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u4216:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u4217
	goto	u4218
u4217:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u4218:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u4219
	goto	u4210
u4219:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u4210:

	goto	l3861
	line	115
	
l489:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	118
	
l3861:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u4225:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u4220:
	addlw	-1
	skipz
	goto	u4225
	movf	1+(??_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
l3863:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
l482:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_ChargeProcess_Slot

;; *************** function _ChargeProcess_Slot *****************
;; Defined at:
;;		line 97 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   42[BANK1 ] unsigned char 
;;  bat_mv_long     4   21[BANK1 ] unsigned long 
;;  vx_mv           4   17[BANK1 ] unsigned long 
;;  bat_mv          2   32[BANK1 ] unsigned int 
;;  bat_mv_long     4   13[BANK1 ] unsigned long 
;;  vx_mv           4    9[BANK1 ] unsigned long 
;;  bat_mv          2   30[BANK1 ] unsigned int 
;;  v_before        2   27[BANK1 ] unsigned int 
;;  v_ref           2   25[BANK1 ] unsigned int 
;;  v               2   40[BANK1 ] unsigned int 
;;  ct              2   38[BANK1 ] unsigned int 
;;  tick            2    0        unsigned int 
;;  st              1   37[BANK1 ] unsigned char 
;;  ty              1   36[BANK1 ] unsigned char 
;;  old_st          1   29[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : A00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      34       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       0      38       0       0
;;Total ram usage:       38 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Detect_BatteryType
;;		___bmul
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	97
global __ptext16
__ptext16:	;psect for function _ChargeProcess_Slot
psect	text16
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	97
	global	__size_of_ChargeProcess_Slot
	__size_of_ChargeProcess_Slot	equ	__end_of_ChargeProcess_Slot-_ChargeProcess_Slot
	
_ChargeProcess_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _ChargeProcess_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;ChargeProcess_Slot@idx stored from wreg
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@idx)^080h
	line	101
	
l4467:	
	line	104
	
l4469:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l4471:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@ty)^080h
	
l4473:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@v)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v+1)^080h
	
l4475:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@ct)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@ct+1)^080h
	line	105
	
l4477:	
;charge_mgr.c: 105: old_st = st;
	movf	(ChargeProcess_Slot@st)^080h,w
	movwf	(ChargeProcess_Slot@old_st)^080h
	line	107
;charge_mgr.c: 107: switch(st)
	goto	l4825
	line	110
	
l4479:	
;charge_mgr.c: 110: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^080h
	clrf	(ChargeProcess_Slot@ct+1)^080h
	line	111
	
l4481:	
;charge_mgr.c: 111: st = 1;
	clrf	(ChargeProcess_Slot@st)^080h
	incf	(ChargeProcess_Slot@st)^080h,f
	line	112
;charge_mgr.c: 112: break;
	goto	l4827
	line	115
	
l4483:	
;charge_mgr.c: 115: ct += tick;
	incf	(ChargeProcess_Slot@ct)^080h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^080h,f
	line	116
;charge_mgr.c: 116: if(ct < (2 * 100))
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1)^080h,w
	movlw	0C8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^080h,w
	skipnc
	goto	u5081
	goto	u5080
u5081:
	goto	l4487
u5080:
	goto	l4827
	line	117
	
l4485:	
;charge_mgr.c: 117: break;
	goto	l4827
	line	124
	
l4487:	
;charge_mgr.c: 124: if(ct == (2 * 100))
		movlw	200
	xorwf	((ChargeProcess_Slot@ct)^080h),w
iorwf	((ChargeProcess_Slot@ct+1)^080h),w
	btfss	status,2
	goto	u5091
	goto	u5090
u5091:
	goto	l4491
u5090:
	line	126
	
l4489:	
;charge_mgr.c: 125: {
;charge_mgr.c: 126: g_impRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^080h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^080h,w
	movwf	indf
	line	127
;charge_mgr.c: 127: break;
	goto	l4827
	line	129
	
l4491:	
;charge_mgr.c: 128: }
;charge_mgr.c: 129: if(ct < (2 * 100) + (8 * 100) && v < 3990)
	movlw	03h
	subwf	(ChargeProcess_Slot@ct+1)^080h,w
	movlw	0E8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^080h,w
	skipnc
	goto	u5101
	goto	u5100
u5101:
	goto	l4503
u5100:
	
l4493:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipnc
	goto	u5111
	goto	u5110
u5111:
	goto	l4503
u5110:
	line	131
	
l4495:	
;charge_mgr.c: 130: {
;charge_mgr.c: 131: unsigned int v_ref = g_impRefV[idx];
	clrc
	rlf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_ref)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_ref+1)^080h
	line	132
	
l4497:	
;charge_mgr.c: 132: if(v_ref < 3990 && v + 50 < v_ref)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v_ref+1)^080h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v_ref)^080h,w
	skipnc
	goto	u5121
	goto	u5120
u5121:
	goto	l4503
u5120:
	
l4499:	
	movf	(ChargeProcess_Slot@v)^080h,w
	addlw	low(032h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(ChargeProcess_Slot@v+1)^080h,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(ChargeProcess_Slot@v_ref+1)^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u5135
	movf	(ChargeProcess_Slot@v_ref)^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u5135:
	skipnc
	goto	u5131
	goto	u5130
u5131:
	goto	l4503
u5130:
	goto	l4489
	line	139
	
l4503:	
;charge_mgr.c: 136: }
;charge_mgr.c: 137: }
;charge_mgr.c: 139: ty = Detect_BatteryType(v);
	movf	(ChargeProcess_Slot@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Detect_BatteryType@voltage+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@ty)^080h
	line	144
	
l4505:	
;charge_mgr.c: 144: if(v < 500)
	movlw	01h
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	0F4h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipnc
	goto	u5141
	goto	u5140
u5141:
	goto	l4511
u5140:
	line	146
	
l4507:	
;charge_mgr.c: 145: {
;charge_mgr.c: 146: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	147
;charge_mgr.c: 147: if(g_detectLowCnt[idx] < 5)
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u5151
	goto	u5150
u5151:
	goto	l4515
u5150:
	goto	l4827
	line	150
	
l4511:	
;charge_mgr.c: 150: else if(ty != 5)
		movlw	5
	xorwf	((ChargeProcess_Slot@ty)^080h),w
	btfsc	status,2
	goto	u5161
	goto	u5160
u5161:
	goto	l4515
u5160:
	line	152
	
l4513:	
;charge_mgr.c: 151: {
;charge_mgr.c: 152: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	155
	
l4515:	
;charge_mgr.c: 153: }
;charge_mgr.c: 155: if(ty == 5)
		movlw	5
	xorwf	((ChargeProcess_Slot@ty)^080h),w
	btfss	status,2
	goto	u5171
	goto	u5170
u5171:
	goto	l4529
u5170:
	line	162
	
l4517:	
;charge_mgr.c: 156: {
;charge_mgr.c: 162: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	163
;charge_mgr.c: 163: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u5181
	goto	u5180
u5181:
	goto	l4521
u5180:
	goto	l4827
	line	165
	
l4521:	
;charge_mgr.c: 165: g_impRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^080h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^080h,w
	movwf	indf
	line	166
	
l4523:	
;charge_mgr.c: 166: st = 8;
	movlw	low(08h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	167
	
l4525:	
;charge_mgr.c: 167: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^080h
	clrf	(ChargeProcess_Slot@ct+1)^080h
	line	168
	
l4527:	
;charge_mgr.c: 168: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	169
;charge_mgr.c: 169: }
	goto	l4827
	line	170
	
l4529:	
;charge_mgr.c: 170: else if(ty == 0)
	movf	((ChargeProcess_Slot@ty)^080h),w
	btfss	status,2
	goto	u5191
	goto	u5190
u5191:
	goto	l4539
u5190:
	line	173
	
l4531:	
;charge_mgr.c: 171: {
;charge_mgr.c: 173: if(v >= 3990)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5201
	goto	u5200
u5201:
	goto	l4535
u5200:
	line	175
	
l4533:	
;charge_mgr.c: 174: {
;charge_mgr.c: 175: st = 0;
	clrf	(ChargeProcess_Slot@st)^080h
	line	176
;charge_mgr.c: 176: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^080h
	clrf	(ChargeProcess_Slot@ct+1)^080h
	line	177
;charge_mgr.c: 177: }
	goto	l4527
	line	180
	
l4535:	
;charge_mgr.c: 178: else
;charge_mgr.c: 179: {
;charge_mgr.c: 180: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l4527
	line	184
	
l4539:	
;charge_mgr.c: 184: else if(ty == 2 || ty == 3)
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)^080h),w
	btfsc	status,2
	goto	u5211
	goto	u5210
u5211:
	goto	l4543
u5210:
	
l4541:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^080h),w
	btfss	status,2
	goto	u5221
	goto	u5220
u5221:
	goto	l4553
u5220:
	line	186
	
l4543:	
;charge_mgr.c: 185: {
;charge_mgr.c: 186: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	187
	
l4545:	
;charge_mgr.c: 187: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	188
	
l4547:	
;charge_mgr.c: 188: g_detectLogSlot = idx;
	movf	(ChargeProcess_Slot@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	189
	
l4549:	
;charge_mgr.c: 189: g_detectLogType = ty;
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@ty)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_detectLogType)	;volatile
	line	190
	
l4551:	
;charge_mgr.c: 190: g_detectLogFlag = 1;
	bsf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	line	191
;charge_mgr.c: 191: }
	goto	l4827
	line	198
	
l4553:	
;charge_mgr.c: 192: else
;charge_mgr.c: 193: {
;charge_mgr.c: 197: {
;charge_mgr.c: 198: unsigned long vx_mv = (unsigned long)v * (unsigned long)g_vcc_mv / 4096UL;
	movf	(ChargeProcess_Slot@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@vx_mv+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@vx_mv+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@vx_mv+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@vx_mv)^080h

	
l4555:	
	movlw	0Ch
u5235:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u5235

	line	199
	
l4557:	
;charge_mgr.c: 199: unsigned long bat_mv_long = 124UL * vx_mv + 206UL * (unsigned long)g_vcc_mv;
	movf	(_g_vcc_mv)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0CEh
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@bat_mv_long+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@bat_mv_long+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@bat_mv_long+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@bat_mv_long)^080h

	
l4559:	
	movf	(ChargeProcess_Slot@vx_mv+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@vx_mv+2)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@vx_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@vx_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(0+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ChargeProcess_Slot@bat_mv_long)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lmul)),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u5241
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ChargeProcess_Slot@bat_mv_long+1)^080h,f
u5241:
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lmul)),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u5242
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ChargeProcess_Slot@bat_mv_long+2)^080h,f
u5242:
	bcf	status, 5	;RP0=0, select bank0
	movf	(3+(?___lmul)),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u5243
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ChargeProcess_Slot@bat_mv_long+3)^080h,f
u5243:
	bcf	status, 5	;RP0=0, select bank0
	bsf	status, 5	;RP0=1, select bank1

	line	200
	
l4561:	
;charge_mgr.c: 200: unsigned int bat_mv = (unsigned int)((bat_mv_long + 1000UL/2UL) / 1000UL);
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	bsf	status, 5	;RP0=1, select bank1
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	goto	u5250
	goto	u5251
u5250:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u5251:
	movf	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	goto	u5252
	goto	u5253
u5252:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u5253:
	movf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@bat_mv+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@bat_mv)^080h
	line	202
	
l4563:	
;charge_mgr.c: 202: if(bat_mv <= 100)
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv+1)^080h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^080h,w
	skipnc
	goto	u5261
	goto	u5260
u5261:
	goto	l4573
u5260:
	line	204
	
l4565:	
;charge_mgr.c: 203: {
;charge_mgr.c: 204: st = 2;
	movlw	low(02h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	205
	
l4567:	
;charge_mgr.c: 205: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^080h
	clrf	(ChargeProcess_Slot@ct+1)^080h
	line	206
	
l4569:	
;charge_mgr.c: 206: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l4527
	line	209
	
l4573:	
;charge_mgr.c: 209: else if(bat_mv < 900)
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv+1)^080h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^080h,w
	skipnc
	goto	u5271
	goto	u5270
u5271:
	goto	l4583
u5270:
	line	211
	
l4575:	
;charge_mgr.c: 210: {
;charge_mgr.c: 211: st = 3;
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l4567
	line	216
	
l4583:	
;charge_mgr.c: 216: else if(bat_mv >= 1520)
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^080h,w
	skipc
	goto	u5281
	goto	u5280
u5281:
	goto	l4595
u5280:
	line	218
	
l4585:	
;charge_mgr.c: 217: {
;charge_mgr.c: 218: st = 5;
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	219
	
l4587:	
;charge_mgr.c: 219: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^080h
	clrf	(ChargeProcess_Slot@ct+1)^080h
	line	220
	
l4589:	
;charge_mgr.c: 220: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	221
	
l4591:	
;charge_mgr.c: 221: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l4489
	line	226
	
l4595:	
;charge_mgr.c: 224: else
;charge_mgr.c: 225: {
;charge_mgr.c: 226: st = 4;
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	227
	
l4597:	
;charge_mgr.c: 227: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^080h
	clrf	(ChargeProcess_Slot@ct+1)^080h
	line	228
	
l4599:	
;charge_mgr.c: 228: g_ccBlocks[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l4589
	line	238
	
l4607:	
;charge_mgr.c: 238: ct += tick;
	incf	(ChargeProcess_Slot@ct)^080h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^080h,f
	line	239
	
l4609:	
;charge_mgr.c: 239: if(ct < 1)
	movf	((ChargeProcess_Slot@ct)^080h),w
iorwf	((ChargeProcess_Slot@ct+1)^080h),w
	btfss	status,2
	goto	u5291
	goto	u5290
u5291:
	goto	l4613
u5290:
	goto	l4827
	line	243
	
l4613:	
;charge_mgr.c: 242: {
;charge_mgr.c: 243: unsigned int v_before = g_impRefV[idx];
	clrc
	rlf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_before)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_before+1)^080h
	line	250
	
l4615:	
;charge_mgr.c: 250: if(v >= 3990 && v_before < 3990)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5301
	goto	u5300
u5301:
	goto	l4623
u5300:
	
l4617:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v_before+1)^080h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v_before)^080h,w
	skipnc
	goto	u5311
	goto	u5310
u5311:
	goto	l4623
u5310:
	line	252
	
l4619:	
;charge_mgr.c: 251: {
;charge_mgr.c: 252: ty = 2;
	movlw	low(02h)
	movwf	(ChargeProcess_Slot@ty)^080h
	line	253
;charge_mgr.c: 253: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	254
;charge_mgr.c: 254: g_detectLogSlot = idx;
	movf	(ChargeProcess_Slot@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	255
;charge_mgr.c: 255: g_detectLogType = 2;
	movlw	low(02h)
	movwf	(_g_detectLogType)	;volatile
	goto	l4551
	line	260
	
l4623:	
;charge_mgr.c: 258: }
;charge_mgr.c: 260: if(v >= 3990)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5321
	goto	u5320
u5321:
	goto	l4627
u5320:
	line	263
	
l4625:	
;charge_mgr.c: 261: {
;charge_mgr.c: 263: ty = 0;
	clrf	(ChargeProcess_Slot@ty)^080h
	line	264
;charge_mgr.c: 264: st = 0;
	clrf	(ChargeProcess_Slot@st)^080h
	line	265
;charge_mgr.c: 265: break;
	goto	l4827
	line	270
	
l4627:	
;charge_mgr.c: 266: }
;charge_mgr.c: 270: if(v > v_before + 10)
	movf	(ChargeProcess_Slot@v_before)^080h,w
	addlw	low(0Ah)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(ChargeProcess_Slot@v_before+1)^080h,w
	skipnc
	addlw	1
	addlw	high(0Ah)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(ChargeProcess_Slot@v+1)^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u5335
	movf	(ChargeProcess_Slot@v)^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u5335:
	skipnc
	goto	u5331
	goto	u5330
u5331:
	goto	l4665
u5330:
	line	272
	
l4629:	
;charge_mgr.c: 271: {
;charge_mgr.c: 272: ty = 1;
	clrf	(ChargeProcess_Slot@ty)^080h
	incf	(ChargeProcess_Slot@ty)^080h,f
	line	274
	
l4631:	
;charge_mgr.c: 273: {
;charge_mgr.c: 274: unsigned long vx_mv = (unsigned long)v * (unsigned long)g_vcc_mv / 4096UL;
	movf	(ChargeProcess_Slot@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@vx_mv_383+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@vx_mv_383+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@vx_mv_383+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@vx_mv_383)^080h

	
l4633:	
	movlw	0Ch
u5345:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_383+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_383+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_383+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_383)^080h,f
	addlw	-1
	skipz
	goto	u5345

	line	275
	
l4635:	
;charge_mgr.c: 275: unsigned long bat_mv_long = 124UL * vx_mv + 206UL * (unsigned long)g_vcc_mv;
	movf	(_g_vcc_mv)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0CEh
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@bat_mv_long_384+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@bat_mv_long_384+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@bat_mv_long_384+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@bat_mv_long_384)^080h

	
l4637:	
	movf	(ChargeProcess_Slot@vx_mv_383+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@vx_mv_383+2)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@vx_mv_383+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@vx_mv_383)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(0+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ChargeProcess_Slot@bat_mv_long_384)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lmul)),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u5351
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ChargeProcess_Slot@bat_mv_long_384+1)^080h,f
u5351:
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lmul)),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u5352
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ChargeProcess_Slot@bat_mv_long_384+2)^080h,f
u5352:
	bcf	status, 5	;RP0=0, select bank0
	movf	(3+(?___lmul)),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u5353
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ChargeProcess_Slot@bat_mv_long_384+3)^080h,f
u5353:
	bcf	status, 5	;RP0=0, select bank0
	bsf	status, 5	;RP0=1, select bank1

	line	276
	
l4639:	
;charge_mgr.c: 276: unsigned int bat_mv = (unsigned int)((bat_mv_long + 1000UL/2UL) / 1000UL);
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	bsf	status, 5	;RP0=1, select bank1
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long_384)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long_384+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_384+1)^080h,w
	goto	u5360
	goto	u5361
u5360:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u5361:
	movf	(ChargeProcess_Slot@bat_mv_long_384+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_384+2)^080h,w
	goto	u5362
	goto	u5363
u5362:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u5363:
	movf	(ChargeProcess_Slot@bat_mv_long_384+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_384+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@bat_mv_385+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@bat_mv_385)^080h
	line	278
	
l4641:	
;charge_mgr.c: 278: if(bat_mv <= 100)
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_385+1)^080h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_385)^080h,w
	skipnc
	goto	u5371
	goto	u5370
u5371:
	goto	l4645
u5370:
	line	280
	
l4643:	
;charge_mgr.c: 279: {
;charge_mgr.c: 280: st = 2;
	movlw	low(02h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	281
;charge_mgr.c: 281: }
	goto	l4661
	line	282
	
l4645:	
;charge_mgr.c: 282: else if(bat_mv < 900)
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_385+1)^080h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_385)^080h,w
	skipnc
	goto	u5381
	goto	u5380
u5381:
	goto	l4649
u5380:
	line	284
	
l4647:	
;charge_mgr.c: 283: {
;charge_mgr.c: 284: st = 3;
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	285
;charge_mgr.c: 285: }
	goto	l4661
	line	286
	
l4649:	
;charge_mgr.c: 286: else if(bat_mv >= 1520)
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_385+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_385)^080h,w
	skipc
	goto	u5391
	goto	u5390
u5391:
	goto	l4655
u5390:
	line	288
	
l4651:	
;charge_mgr.c: 287: {
;charge_mgr.c: 288: st = 5;
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	289
	
l4653:	
;charge_mgr.c: 289: g_impRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^080h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^080h,w
	movwf	indf
	line	290
;charge_mgr.c: 290: }
	goto	l4661
	line	293
	
l4655:	
;charge_mgr.c: 291: else
;charge_mgr.c: 292: {
;charge_mgr.c: 293: st = 4;
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	294
	
l4657:	
;charge_mgr.c: 294: g_ccBlocks[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l4653
	line	297
	
l4661:	
;charge_mgr.c: 296: }
;charge_mgr.c: 297: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^080h
	clrf	(ChargeProcess_Slot@ct+1)^080h
	line	298
	
l4663:	
;charge_mgr.c: 298: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	300
;charge_mgr.c: 299: }
;charge_mgr.c: 300: }
	goto	l4827
	line	304
	
l4665:	
;charge_mgr.c: 301: else
;charge_mgr.c: 302: {
;charge_mgr.c: 304: ty = 3;
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@ty)^080h
	line	305
;charge_mgr.c: 305: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	306
;charge_mgr.c: 306: g_detectLogSlot = idx;
	movf	(ChargeProcess_Slot@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	307
;charge_mgr.c: 307: g_detectLogType = 3;
	movlw	low(03h)
	movwf	(_g_detectLogType)	;volatile
	goto	l4551
	line	316
	
l4669:	
;charge_mgr.c: 316: ct += tick;
	incf	(ChargeProcess_Slot@ct)^080h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^080h,f
	line	317
;charge_mgr.c: 317: if(ct > (60 * 100))
	movlw	017h
	subwf	(ChargeProcess_Slot@ct+1)^080h,w
	movlw	071h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^080h,w
	skipc
	goto	u5401
	goto	u5400
u5401:
	goto	l4673
u5400:
	line	319
	
l4671:	
;charge_mgr.c: 318: {
;charge_mgr.c: 319: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	320
;charge_mgr.c: 320: break;
	goto	l4827
	line	322
	
l4673:	
;charge_mgr.c: 321: }
;charge_mgr.c: 322: if(v > 750)
	movlw	02h
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5411
	goto	u5410
u5411:
	goto	l4679
u5410:
	line	324
	
l4675:	
;charge_mgr.c: 323: {
;charge_mgr.c: 324: st = 3;
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	325
	
l4677:	
;charge_mgr.c: 325: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^080h
	clrf	(ChargeProcess_Slot@ct+1)^080h
	line	326
;charge_mgr.c: 326: break;
	goto	l4827
	line	328
	
l4679:	
;charge_mgr.c: 327: }
;charge_mgr.c: 328: if(v >= 3620)
	movlw	0Eh
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	024h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5421
	goto	u5420
u5421:
	goto	l4827
u5420:
	goto	l4671
	line	336
	
l4683:	
;charge_mgr.c: 336: ct += tick;
	incf	(ChargeProcess_Slot@ct)^080h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^080h,f
	line	337
;charge_mgr.c: 337: if(ct > (300 * 100))
	movlw	075h
	subwf	(ChargeProcess_Slot@ct+1)^080h,w
	movlw	031h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^080h,w
	skipc
	goto	u5431
	goto	u5430
u5431:
	goto	l4687
u5430:
	goto	l4671
	line	342
	
l4687:	
;charge_mgr.c: 341: }
;charge_mgr.c: 342: if(v >= 3620)
	movlw	0Eh
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	024h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5441
	goto	u5440
u5441:
	goto	l4693
u5440:
	line	344
	
l4689:	
;charge_mgr.c: 343: {
;charge_mgr.c: 344: g_ovCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	345
;charge_mgr.c: 345: if(g_ovCnt[idx] >= 5)
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u5451
	goto	u5450
u5451:
	goto	l4695
u5450:
	goto	l4671
	line	353
	
l4693:	
;charge_mgr.c: 351: else
;charge_mgr.c: 352: {
;charge_mgr.c: 353: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	355
	
l4695:	
;charge_mgr.c: 354: }
;charge_mgr.c: 355: if(v >= 2700)
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	08Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5461
	goto	u5460
u5461:
	goto	l4827
u5460:
	line	357
	
l4697:	
;charge_mgr.c: 356: {
;charge_mgr.c: 357: st = 4;
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	358
	
l4699:	
;charge_mgr.c: 358: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^080h
	clrf	(ChargeProcess_Slot@ct+1)^080h
	line	359
	
l4701:	
;charge_mgr.c: 359: g_ccBlocks[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	360
	
l4703:	
;charge_mgr.c: 360: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l4489
	line	366
	
l4707:	
;charge_mgr.c: 366: ct += tick;
	incf	(ChargeProcess_Slot@ct)^080h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^080h,f
	line	367
;charge_mgr.c: 367: if(ct >= (600 * 100))
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^080h,w
	movlw	060h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^080h,w
	skipc
	goto	u5471
	goto	u5470
u5471:
	goto	l4713
u5470:
	line	369
	
l4709:	
;charge_mgr.c: 368: {
;charge_mgr.c: 369: ct -= (600 * 100);
	movlw	060h
	subwf	(ChargeProcess_Slot@ct)^080h,f
	movlw	0EAh
	skipc
	decf	(ChargeProcess_Slot@ct+1)^080h,f
	subwf	(ChargeProcess_Slot@ct+1)^080h,f
	line	370
	
l4711:	
;charge_mgr.c: 370: g_ccBlocks[idx]++;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	372
	
l4713:	
;charge_mgr.c: 371: }
;charge_mgr.c: 372: if(g_ccBlocks[idx] >= 18)
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(012h)
	subwf	indf,w
	skipc
	goto	u5481
	goto	u5480
u5481:
	goto	l4717
u5480:
	goto	l4671
	line	382
	
l4717:	
;charge_mgr.c: 376: }
;charge_mgr.c: 382: if(v > g_impRefV[idx]) g_impRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	(ChargeProcess_Slot@v+1)^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u5495
	movf	(ChargeProcess_Slot@v)^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u5495:
	skipnc
	goto	u5491
	goto	u5490
u5491:
	goto	l626
u5490:
	
l4719:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^080h,w
	movwf	indf
	
l626:	
	line	383
;charge_mgr.c: 383: if(g_impRefV[idx] - v > 500)
	clrc
	rlf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	(ChargeProcess_Slot@v)^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	(ChargeProcess_Slot@v+1)^080h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u5501
	goto	u5500
u5501:
	goto	l4733
u5500:
	line	385
	
l4721:	
;charge_mgr.c: 384: {
;charge_mgr.c: 385: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	386
;charge_mgr.c: 386: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u5511
	goto	u5510
u5511:
	goto	l4725
u5510:
	goto	l4827
	line	388
	
l4725:	
;charge_mgr.c: 388: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	389
	
l4727:	
;charge_mgr.c: 389: st = 1;
	clrf	(ChargeProcess_Slot@st)^080h
	incf	(ChargeProcess_Slot@st)^080h,f
	goto	l4677
	line	395
	
l4733:	
;charge_mgr.c: 393: else
;charge_mgr.c: 394: {
;charge_mgr.c: 395: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	398
	
l4735:	
;charge_mgr.c: 396: }
;charge_mgr.c: 398: if(v >= 3620)
	movlw	0Eh
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	024h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5521
	goto	u5520
u5521:
	goto	l4741
u5520:
	line	400
	
l4737:	
;charge_mgr.c: 399: {
;charge_mgr.c: 400: g_ovCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	401
;charge_mgr.c: 401: if(g_ovCnt[idx] >= 5)
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u5531
	goto	u5530
u5531:
	goto	l4485
u5530:
	goto	l4671
	line	409
	
l4741:	
;charge_mgr.c: 407: else
;charge_mgr.c: 408: {
;charge_mgr.c: 409: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	410
	
l4743:	
;charge_mgr.c: 410: if(v >= 3100)
	movlw	0Ch
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	01Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5541
	goto	u5540
u5541:
	goto	l4485
u5540:
	line	412
	
l4745:	
;charge_mgr.c: 411: {
;charge_mgr.c: 412: st = 5;
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l4677
	line	419
	
l4749:	
;charge_mgr.c: 419: ct += tick;
	incf	(ChargeProcess_Slot@ct)^080h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^080h,f
	line	420
;charge_mgr.c: 420: if(ct > (600 * 100))
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^080h,w
	movlw	061h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^080h,w
	skipc
	goto	u5551
	goto	u5550
u5551:
	goto	l4753
u5550:
	line	421
	
l4751:	
;charge_mgr.c: 421: st = 6;
	movlw	low(06h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	425
	
l4753:	
;charge_mgr.c: 425: if(v > g_impRefV[idx]) g_impRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	(ChargeProcess_Slot@v+1)^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u5565
	movf	(ChargeProcess_Slot@v)^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u5565:
	skipnc
	goto	u5561
	goto	u5560
u5561:
	goto	l636
u5560:
	
l4755:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^080h,w
	movwf	indf
	
l636:	
	line	426
;charge_mgr.c: 426: if(g_impRefV[idx] - v > 500)
	clrc
	rlf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	(ChargeProcess_Slot@v)^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	(ChargeProcess_Slot@v+1)^080h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u5571
	goto	u5570
u5571:
	goto	l4527
u5570:
	line	428
	
l4757:	
;charge_mgr.c: 427: {
;charge_mgr.c: 428: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	429
;charge_mgr.c: 429: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u5581
	goto	u5580
u5581:
	goto	l4725
u5580:
	goto	l4827
	line	443
	
l4769:	
;charge_mgr.c: 443: if(v < (3100 - 10))
	movlw	0Ch
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	012h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipnc
	goto	u5591
	goto	u5590
u5591:
	goto	l4527
u5590:
	line	445
	
l4771:	
;charge_mgr.c: 444: {
;charge_mgr.c: 445: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	446
;charge_mgr.c: 446: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u5601
	goto	u5600
u5601:
	goto	l4775
u5600:
	goto	l4827
	line	448
	
l4775:	
;charge_mgr.c: 448: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	449
	
l4777:	
;charge_mgr.c: 449: st = 4;
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	450
	
l4779:	
;charge_mgr.c: 450: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^080h
	clrf	(ChargeProcess_Slot@ct+1)^080h
	goto	l4703
	line	463
	
l4787:	
;charge_mgr.c: 463: if(ty == 2 || ty == 3)
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)^080h),w
	btfsc	status,2
	goto	u5611
	goto	u5610
u5611:
	goto	l4527
u5610:
	
l4789:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^080h),w
	btfss	status,2
	goto	u5621
	goto	u5620
u5621:
	goto	l4793
u5620:
	goto	l4527
	line	469
	
l4793:	
;charge_mgr.c: 467: }
;charge_mgr.c: 469: if(v >= 3990)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5631
	goto	u5630
u5631:
	goto	l4807
u5630:
	line	471
	
l4795:	
;charge_mgr.c: 470: {
;charge_mgr.c: 471: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	472
;charge_mgr.c: 472: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u5641
	goto	u5640
u5641:
	goto	l4799
u5640:
	goto	l4827
	line	474
	
l4799:	
;charge_mgr.c: 474: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	475
	
l4801:	
;charge_mgr.c: 475: ty = 0;
	clrf	(ChargeProcess_Slot@ty)^080h
	line	476
	
l4803:	
;charge_mgr.c: 476: st = 0;
	clrf	(ChargeProcess_Slot@st)^080h
	goto	l4677
	line	481
	
l4807:	
;charge_mgr.c: 479: }
;charge_mgr.c: 481: if(v > 750)
	movlw	02h
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5651
	goto	u5650
u5651:
	goto	l4527
u5650:
	line	483
	
l4809:	
;charge_mgr.c: 482: {
;charge_mgr.c: 483: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	484
;charge_mgr.c: 484: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u5661
	goto	u5660
u5661:
	goto	l4725
u5660:
	goto	l4827
	line	497
	
l4821:	
;charge_mgr.c: 497: st = 0;
	clrf	(ChargeProcess_Slot@st)^080h
	line	498
;charge_mgr.c: 498: break;
	goto	l4827
	line	107
	
l4825:	
	movf	(ChargeProcess_Slot@st)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 9, Range of values is 0 to 8
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           28    15 (average)
; direct_byte           35     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l4479
	xorlw	1^0	; case 1
	skipnz
	goto	l4483
	xorlw	2^1	; case 2
	skipnz
	goto	l4669
	xorlw	3^2	; case 3
	skipnz
	goto	l4683
	xorlw	4^3	; case 4
	skipnz
	goto	l4707
	xorlw	5^4	; case 5
	skipnz
	goto	l4749
	xorlw	6^5	; case 6
	skipnz
	goto	l4769
	xorlw	7^6	; case 7
	skipnz
	goto	l4787
	xorlw	8^7	; case 8
	skipnz
	goto	l4607
	goto	l4821
	opt asmopt_pop

	line	501
	
l4827:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@st)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@ty)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@v)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^080h,w
	movwf	indf
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@ct)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@ct+1)^080h,w
	movwf	indf
	line	504
	
l4829:	
;charge_mgr.c: 504: if(idx == 0 && st != old_st)
	movf	((ChargeProcess_Slot@idx)^080h),w
	btfss	status,2
	goto	u5671
	goto	u5670
u5671:
	goto	l657
u5670:
	
l4831:	
	movf	(ChargeProcess_Slot@st)^080h,w
	xorwf	(ChargeProcess_Slot@old_st)^080h,w
	skipnz
	goto	u5681
	goto	u5680
u5681:
	goto	l657
u5680:
	line	506
	
l4833:	
;charge_mgr.c: 505: {
;charge_mgr.c: 506: g_dbgSlot = idx;
	movf	(ChargeProcess_Slot@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_dbgSlot)	;volatile
	line	507
;charge_mgr.c: 507: g_dbgOldState = old_st;
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@old_st)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_dbgOldState)	;volatile
	line	508
;charge_mgr.c: 508: g_dbgNewState = st;
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@st)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_dbgNewState)	;volatile
	line	509
;charge_mgr.c: 509: g_dbgNewType = ty;
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@ty)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_dbgNewType)	;volatile
	line	510
;charge_mgr.c: 510: g_dbgVoltage = v;
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@v+1)^080h,w
	movwf	(_g_dbgVoltage+1)^080h	;volatile
	movf	(ChargeProcess_Slot@v)^080h,w
	movwf	(_g_dbgVoltage)^080h	;volatile
	line	511
	
l4835:	
;charge_mgr.c: 511: g_dbgDetectFlag = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	513
	
l657:	
	return
	opt stack 0
GLOBAL	__end_of_ChargeProcess_Slot
	__end_of_ChargeProcess_Slot:
	signat	_ChargeProcess_Slot,4217
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4   18[BANK0 ] unsigned long 
;;  multiplicand    4   22[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4   26[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4   18[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext17
__ptext17:	;psect for function ___lmul
psect	text17
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l3891:	
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l786:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u4251
	goto	u4250
u4251:
	goto	l3895
u4250:
	line	122
	
l3893:	
	movf	(___lmul@multiplicand),w
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u4261
	addwf	(___lmul@product+1),f
u4261:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u4262
	addwf	(___lmul@product+2),f
u4262:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u4263
	addwf	(___lmul@product+3),f
u4263:

	line	123
	
l3895:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l3897:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u4271
	goto	u4270
u4271:
	goto	l786
u4270:
	line	128
	
l3899:	
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l789:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4   30[BANK0 ] unsigned long 
;;  dividend        4   34[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4    0[BANK1 ] unsigned long 
;;  counter         1    4[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4   30[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       0       5       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       8       5       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext18
__ptext18:	;psect for function ___lldiv
psect	text18
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l3903:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___lldiv@quotient)^080h
	clrf	(___lldiv@quotient+1)^080h
	clrf	(___lldiv@quotient+2)^080h
	clrf	(___lldiv@quotient+3)^080h
	line	15
	
l3905:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u4281
	goto	u4280
u4281:
	goto	l3925
u4280:
	line	16
	
l3907:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___lldiv@counter)^080h
	incf	(___lldiv@counter)^080h,f
	line	17
	goto	l3911
	line	18
	
l3909:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	bsf	status, 5	;RP0=1, select bank1
	incf	(___lldiv@counter)^080h,f
	line	17
	
l3911:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u4291
	goto	u4290
u4291:
	goto	l3909
u4290:
	line	22
	
l3913:	
	clrc
	bsf	status, 5	;RP0=1, select bank1
	rlf	(___lldiv@quotient)^080h,f
	rlf	(___lldiv@quotient+1)^080h,f
	rlf	(___lldiv@quotient+2)^080h,f
	rlf	(___lldiv@quotient+3)^080h,f
	line	23
	
l3915:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u4305
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u4305
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u4305
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u4305:
	skipc
	goto	u4301
	goto	u4300
u4301:
	goto	l3921
u4300:
	line	24
	
l3917:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l3919:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(___lldiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l3921:	
	clrc
	bcf	status, 5	;RP0=0, select bank0
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l3923:	
	bsf	status, 5	;RP0=1, select bank1
	decfsz	(___lldiv@counter)^080h,f
	goto	u4311
	goto	u4310
u4311:
	goto	l3913
u4310:
	line	30
	
l3925:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lldiv@quotient+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lldiv+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lldiv@quotient+2)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lldiv+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lldiv@quotient+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lldiv+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lldiv@quotient)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lldiv)

	line	31
	
l1061:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1   18[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1   20[BANK0 ] unsigned char 
;;  product         1   19[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext19
__ptext19:	;psect for function ___bmul
psect	text19
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplier)
	line	6
	
l4049:	
	clrf	(___bmul@product)
	line	43
	
l4051:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u4551
	goto	u4550
u4551:
	goto	l4055
u4550:
	line	44
	
l4053:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l4055:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l4057:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u4561
	goto	u4560
u4561:
	goto	l4051
u4560:
	line	50
	
l4059:	
	movf	(___bmul@product),w
	line	51
	
l795:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 60 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2   18[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	60
global __ptext20
__ptext20:	;psect for function _Detect_BatteryType
psect	text20
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	60
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	62
	
l2729:	
;charge_mgr.c: 62: if(voltage >= 3990)
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2481
	goto	u2480
u2481:
	goto	l2735
u2480:
	line	63
	
l2731:	
;charge_mgr.c: 63: return 0;
	movlw	low(0)
	goto	l559
	line	64
	
l2735:	
;charge_mgr.c: 64: if(voltage < 500)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2491
	goto	u2490
u2491:
	goto	l2741
u2490:
	goto	l2731
	line	68
	
l2741:	
;charge_mgr.c: 68: if(voltage >= 1015 && voltage <= 2320)
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2501
	goto	u2500
u2501:
	goto	l2749
u2500:
	
l2743:	
	movlw	09h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	011h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2511
	goto	u2510
u2511:
	goto	l2749
u2510:
	line	69
	
l2745:	
;charge_mgr.c: 69: return 5;
	movlw	low(05h)
	goto	l559
	line	72
	
l2749:	
;charge_mgr.c: 72: if(voltage >= 1200 && voltage <= 3100)
	movlw	04h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0B0h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2521
	goto	u2520
u2521:
	goto	l2757
u2520:
	
l2751:	
	movlw	0Ch
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	01Dh
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2531
	goto	u2530
u2531:
	goto	l2757
u2530:
	line	73
	
l2753:	
;charge_mgr.c: 73: return 1;
	movlw	low(01h)
	goto	l559
	line	74
	
l2757:	
;charge_mgr.c: 74: if(voltage > 3100 && voltage < 3620)
	movlw	0Ch
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	01Dh
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2541
	goto	u2540
u2541:
	goto	l2765
u2540:
	
l2759:	
	movlw	0Eh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	024h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2551
	goto	u2550
u2551:
	goto	l2765
u2550:
	goto	l2753
	line	76
	
l2765:	
;charge_mgr.c: 76: if(voltage >= 3620 && voltage < 3990)
	movlw	0Eh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	024h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2561
	goto	u2560
u2561:
	goto	l2773
u2560:
	
l2767:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2571
	goto	u2570
u2571:
	goto	l2773
u2570:
	goto	l2753
	line	78
	
l2773:	
;charge_mgr.c: 78: if(voltage >= 500 && voltage < 1200)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2581
	goto	u2580
u2581:
	goto	l2731
u2580:
	
l2775:	
	movlw	04h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0B0h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2591
	goto	u2590
u2591:
	goto	l2731
u2590:
	goto	l2753
	line	82
	
l559:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 161 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_CCCV_Control
;;		_Charging_Control
;;		_Led_BlinkProcess
;;		_PowerOnLedSequence
;;		_Update_LED_Slot
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	161
global __ptext21
__ptext21:	;psect for function _Isr_Timer
psect	text21
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	161
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 2
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	btemp+1,w
	movwf	(??_Isr_Timer+3)
	ljmp	_Isr_Timer
psect	text21
	line	164
	
i1l4837:	
;main.c: 164: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u569_21
	goto	u569_20
u569_21:
	goto	i1l375
u569_20:
	line	166
	
i1l4839:	
;main.c: 165: {
;main.c: 166: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	167
	
i1l4841:	
;main.c: 167: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	168
# 168 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text21
	line	171
	
i1l4843:	
;main.c: 171: g_pwmCounter++;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	172
	
i1l4845:	
;main.c: 172: if(g_pwmCounter >= 32)
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u570_21
	goto	u570_20
u570_21:
	goto	i1l4849
u570_20:
	line	173
	
i1l4847:	
;main.c: 173: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	176
	
i1l4849:	
;main.c: 176: if(g_pwmDuty > 0 && g_pwmCounter < g_pwmDuty)
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u571_21
	goto	u571_20
u571_21:
	goto	i1l372
u571_20:
	
i1l4851:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u572_21
	goto	u572_20
u572_21:
	goto	i1l372
u572_20:
	line	177
	
i1l4853:	
;main.c: 177: RB7 = 1;
	bsf	(55/8),(55)&7	;volatile
	goto	i1l4855
	line	178
	
i1l372:	
	line	179
;main.c: 178: else
;main.c: 179: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	182
	
i1l4855:	
;main.c: 182: if(g_powerOnPhase < 2)
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u573_21
	goto	u573_20
u573_21:
	goto	i1l4913
u573_20:
	line	184
	
i1l4857:	
;main.c: 183: {
;main.c: 184: PowerOnLedSequence();
	fcall	_PowerOnLedSequence
	goto	i1l375
	line	191
;main.c: 190: {
;main.c: 191: case 0:
	
i1l377:	
	line	193
;main.c: 193: if(!g_adcBusy && !g_doAdcSample)
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u574_21
	goto	u574_20
u574_21:
	goto	i1l375
u574_20:
	
i1l4861:	
	btfsc	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u575_21
	goto	u575_20
u575_21:
	goto	i1l375
u575_20:
	goto	i1l4865
	line	195
	
i1l381:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l394
	
i1l383:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l394
	
i1l384:	
	bsf	(51/8),(51)&7	;volatile
	goto	i1l394
	
i1l385:	
	bsf	(50/8),(50)&7	;volatile
	goto	i1l394
	
i1l386:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l394
	
i1l387:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l394
	
i1l388:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l394
	
i1l389:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l394
	
i1l390:	
	bsf	(48/8),(48)&7	;volatile
	goto	i1l394
	
i1l391:	
	bsf	(49/8),(49)&7	;volatile
	goto	i1l394
	
i1l392:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l394
	
i1l393:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l394
	
i1l4865:	
	movf	(_g_scanIndex),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l381
	xorlw	1^0	; case 1
	skipnz
	goto	i1l383
	xorlw	2^1	; case 2
	skipnz
	goto	i1l384
	xorlw	3^2	; case 3
	skipnz
	goto	i1l385
	xorlw	4^3	; case 4
	skipnz
	goto	i1l386
	xorlw	5^4	; case 5
	skipnz
	goto	i1l387
	xorlw	6^5	; case 6
	skipnz
	goto	i1l388
	xorlw	7^6	; case 7
	skipnz
	goto	i1l389
	xorlw	8^7	; case 8
	skipnz
	goto	i1l390
	xorlw	9^8	; case 9
	skipnz
	goto	i1l391
	xorlw	10^9	; case 10
	skipnz
	goto	i1l392
	xorlw	11^10	; case 11
	skipnz
	goto	i1l393
	goto	i1l394
	opt asmopt_pop

	
i1l394:	
	line	196
;main.c: 196: g_doAdcSample = 1;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	i1l375
	line	202
	
i1l4867:	
;main.c: 202: Update_LED_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_Update_LED_Slot
	line	204
	
i1l4869:	
;main.c: 204: g_scanPhase = 2;
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_scanPhase)	;volatile
	line	205
;main.c: 205: break;
	goto	i1l375
	line	208
	
i1l4871:	
;main.c: 208: if(g_scanIndex == 0)
	movf	((_g_scanIndex)),w	;volatile
	btfss	status,2
	goto	u576_21
	goto	u576_20
u576_21:
	goto	i1l4905
u576_20:
	line	210
	
i1l4873:	
;main.c: 209: {
;main.c: 210: Charging_Control();
	fcall	_Charging_Control
	line	211
	
i1l4875:	
;main.c: 211: CCCV_Control();
	fcall	_CCCV_Control
	line	212
	
i1l4877:	
;main.c: 212: Led_BlinkProcess();
	fcall	_Led_BlinkProcess
	line	216
	
i1l4879:	
;main.c: 215: {
;main.c: 216: if(g_tempPhase == 0)
	bcf	status, 5	;RP0=0, select bank0
	movf	((_g_tempPhase)),w	;volatile
	btfss	status,2
	goto	u577_21
	goto	u577_20
u577_21:
	goto	i1l4891
u577_20:
	line	218
	
i1l4881:	
;main.c: 217: {
;main.c: 218: g_tempReadRoundCnt++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_tempReadRoundCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1)^080h,f	;volatile
	line	219
	
i1l4883:	
;main.c: 219: if(g_tempReadRoundCnt >= 200)
	movlw	0
	subwf	(_g_tempReadRoundCnt+1)^080h,w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt)^080h,w	;volatile
	skipc
	goto	u578_21
	goto	u578_20
u578_21:
	goto	i1l4899
u578_20:
	line	221
	
i1l4885:	
;main.c: 220: {
;main.c: 221: g_tempReadRoundCnt = 0;
	clrf	(_g_tempReadRoundCnt)^080h	;volatile
	clrf	(_g_tempReadRoundCnt+1)^080h	;volatile
	line	222
	
i1l4887:	
;main.c: 222: g_tempPhase = 1;
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_tempPhase)	;volatile
	line	223
	
i1l4889:	
;main.c: 223: g_tempSettleCnt = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	goto	i1l4899
	line	228
	
i1l4891:	
;main.c: 226: else
;main.c: 227: {
;main.c: 228: g_tempSettleCnt++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_tempSettleCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1)^080h,f	;volatile
	line	229
	
i1l4893:	
;main.c: 229: if(g_tempSettleCnt >= 60)
	movlw	0
	subwf	(_g_tempSettleCnt+1)^080h,w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt)^080h,w	;volatile
	skipc
	goto	u579_21
	goto	u579_20
u579_21:
	goto	i1l4899
u579_20:
	line	231
	
i1l4895:	
;main.c: 230: {
;main.c: 231: g_doNtcRead = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	232
	
i1l4897:	
;main.c: 232: g_tempSettleCnt = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	line	233
;main.c: 233: g_tempPhase = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_tempPhase)	;volatile
	line	239
	
i1l4899:	
;main.c: 234: }
;main.c: 235: }
;main.c: 236: }
;main.c: 239: if(++g_printTick >= 100)
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_printTick)^080h,f	;volatile
	skipnz
	incf	(_g_printTick+1)^080h,f	;volatile
	movlw	0
	subwf	((_g_printTick+1)^080h),w	;volatile
	movlw	064h
	skipnz
	subwf	((_g_printTick)^080h),w	;volatile
	skipc
	goto	u580_21
	goto	u580_20
u580_21:
	goto	i1l4905
u580_20:
	line	241
	
i1l4901:	
;main.c: 240: {
;main.c: 241: g_printTick = 0;
	clrf	(_g_printTick)^080h	;volatile
	clrf	(_g_printTick+1)^080h	;volatile
	line	242
	
i1l4903:	
;main.c: 242: g_printFlag = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	247
	
i1l4905:	
;main.c: 243: }
;main.c: 244: }
;main.c: 247: if(++g_scanIndex >= 12)
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	incf	(_g_scanIndex),f	;volatile
	subwf	((_g_scanIndex)),w	;volatile
	skipc
	goto	u581_21
	goto	u581_20
u581_21:
	goto	i1l404
u581_20:
	line	248
	
i1l4907:	
;main.c: 248: g_scanIndex = 0;
	clrf	(_g_scanIndex)	;volatile
	
i1l404:	
	line	249
;main.c: 249: g_scanPhase = 0;
	clrf	(_g_scanPhase)	;volatile
	line	250
;main.c: 250: break;
	goto	i1l375
	line	189
	
i1l4913:	
	movf	(_g_scanPhase),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 2
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           17     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l377
	xorlw	1^0	; case 1
	skipnz
	goto	i1l4867
	xorlw	2^1	; case 2
	skipnz
	goto	i1l4871
	goto	i1l404
	opt asmopt_pop

	line	257
	
i1l375:	
	movf	(??_Isr_Timer+3),w
	movwf	btemp+1
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	_Update_LED_Slot

;; *************** function _Update_LED_Slot *****************
;; Defined at:
;;		line 30 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    4[COMMON] unsigned char 
;;  led             1    5[COMMON] unsigned char 
;;  s               1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         3       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	30
global __ptext22
__ptext22:	;psect for function _Update_LED_Slot
psect	text22
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	30
	global	__size_of_Update_LED_Slot
	__size_of_Update_LED_Slot	equ	__end_of_Update_LED_Slot-_Update_LED_Slot
	
_Update_LED_Slot:	
;incstack = 0
	opt	stack 2
; Regs used in _Update_LED_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Update_LED_Slot@idx stored from wreg
	movwf	(Update_LED_Slot@idx)
	line	32
	
i1l4145:	
;led.c: 32: unsigned char s = g_slot[idx].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Update_LED_Slot@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Slot@s)
	line	35
;led.c: 33: unsigned char led;
;led.c: 35: switch(s)
	goto	i1l4157
	line	38
	
i1l4147:	
;led.c: 38: led = 0;
	clrf	(Update_LED_Slot@led)
	line	39
;led.c: 39: break;
	goto	i1l4159
	line	43
	
i1l750:	
	line	45
	
i1l752:	
	line	46
;led.c: 41: case 2:
;led.c: 42: case 3:
;led.c: 43: case 4:
;led.c: 44: case 5:
;led.c: 45: case 8:
;led.c: 46: led = 1;
	clrf	(Update_LED_Slot@led)
	incf	(Update_LED_Slot@led),f
	line	47
;led.c: 47: break;
	goto	i1l4159
	line	49
	
i1l4149:	
;led.c: 49: led = 2;
	movlw	low(02h)
	movwf	(Update_LED_Slot@led)
	line	50
;led.c: 50: break;
	goto	i1l4159
	line	52
	
i1l4151:	
;led.c: 52: led = 3;
	movlw	low(03h)
	movwf	(Update_LED_Slot@led)
	line	53
;led.c: 53: break;
	goto	i1l4159
	line	35
	
i1l4157:	
	movf	(Update_LED_Slot@s),w
	; Switch size 1, requested type "space"
; Number of cases is 9, Range of values is 0 to 8
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           28    15 (average)
; direct_byte           35     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l4147
	xorlw	1^0	; case 1
	skipnz
	goto	i1l750
	xorlw	2^1	; case 2
	skipnz
	goto	i1l752
	xorlw	3^2	; case 3
	skipnz
	goto	i1l752
	xorlw	4^3	; case 4
	skipnz
	goto	i1l752
	xorlw	5^4	; case 5
	skipnz
	goto	i1l752
	xorlw	6^5	; case 6
	skipnz
	goto	i1l4149
	xorlw	7^6	; case 7
	skipnz
	goto	i1l4151
	xorlw	8^7	; case 8
	skipnz
	goto	i1l752
	goto	i1l4147
	opt asmopt_pop

	line	59
	
i1l4159:	
;led.c: 59: g_ledState[idx] = led;
	movf	(Update_LED_Slot@idx),w
	addlw	low(_g_ledState|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Update_LED_Slot@led),w
	movwf	indf
	line	60
	
i1l756:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Slot
	__end_of_Update_LED_Slot:
	signat	_Update_LED_Slot,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 96 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	line	96
global __ptext23
__ptext23:	;psect for function _PowerOnLedSequence
psect	text23
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	96
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	98
	
i1l2939:	
;led.c: 98: g_powerOnTimer++;
	incf	(_g_powerOnTimer),f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1),f	;volatile
	line	100
	
i1l2941:	
;led.c: 100: if(g_powerOnPhase == 0)
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u273_21
	goto	u273_20
u273_21:
	goto	i1l2949
u273_20:
	line	103
	
i1l2943:	
;led.c: 101: {
;led.c: 103: if(g_powerOnTimer >= 100)
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u274_21
	goto	u274_20
u274_21:
	goto	i1l771
u274_20:
	line	105
	
i1l2945:	
;led.c: 104: {
;led.c: 105: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	106
	
i1l2947:	
;led.c: 106: g_powerOnPhase = 1;
	movlw	low(01h)
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l771
	line	109
	
i1l2949:	
;led.c: 109: else if(g_powerOnPhase == 1)
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u275_21
	goto	u275_20
u275_21:
	goto	i1l771
u275_20:
	line	112
	
i1l2951:	
;led.c: 110: {
;led.c: 112: if(g_powerOnTimer >= 100)
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u276_21
	goto	u276_20
u276_21:
	goto	i1l771
u276_20:
	line	114
	
i1l2953:	
;led.c: 113: {
;led.c: 114: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	115
	
i1l2955:	
;led.c: 115: g_powerOnPhase = 2;
	movlw	low(02h)
	movwf	(_g_powerOnPhase)	;volatile
	line	119
	
i1l771:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
	global	_Led_BlinkProcess

;; *************** function _Led_BlinkProcess *****************
;; Defined at:
;;		line 70 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1    0[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : A00/800
;;		Unchanged: 200/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         1       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	line	70
global __ptext24
__ptext24:	;psect for function _Led_BlinkProcess
psect	text24
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	70
	global	__size_of_Led_BlinkProcess
	__size_of_Led_BlinkProcess	equ	__end_of_Led_BlinkProcess-_Led_BlinkProcess
	
_Led_BlinkProcess:	
;incstack = 0
	opt	stack 3
; Regs used in _Led_BlinkProcess: [wreg-fsr0h+status,2+status,0]
	line	74
	
i1l3131:	
;led.c: 72: unsigned char i;
;led.c: 74: for(i = 0; i < 12; i++)
	clrf	(Led_BlinkProcess@i)
	line	76
	
i1l3137:	
;led.c: 75: {
;led.c: 76: if(g_ledState[i] == 3)
	movf	(Led_BlinkProcess@i),w
	addlw	low(_g_ledState|((0x1)<<8))&0ffh
	movwf	fsr0
		movlw	3
	bsf	status, 7	;select IRP bank3
	xorwf	(indf),w
	btfss	status,2
	goto	u313_21
	goto	u313_20
u313_21:
	goto	i1l3143
u313_20:
	line	78
	
i1l3139:	
;led.c: 77: {
;led.c: 78: g_blinkTimer[i]++;
	movf	(Led_BlinkProcess@i),w
	addlw	low(_g_blinkTimer|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	79
;led.c: 79: if(g_blinkTimer[i] >= (100 / 2))
	movf	(Led_BlinkProcess@i),w
	addlw	low(_g_blinkTimer|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(032h)
	subwf	indf,w
	skipc
	goto	u314_21
	goto	u314_20
u314_21:
	goto	i1l3143
u314_20:
	line	81
	
i1l3141:	
;led.c: 80: {
;led.c: 81: g_blinkTimer[i] = 0;
	movf	(Led_BlinkProcess@i),w
	addlw	low(_g_blinkTimer|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	82
;led.c: 82: g_blinkPhase[i] ^= 1;
	movf	(Led_BlinkProcess@i),w
	addlw	low(_g_blinkPhase|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(01h)
	xorwf	indf,f
	line	74
	
i1l3143:	
	incf	(Led_BlinkProcess@i),f
	
i1l3145:	
	movlw	low(0Ch)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u315_21
	goto	u315_20
u315_21:
	goto	i1l3137
u315_20:
	line	86
	
i1l763:	
	return
	opt stack 0
GLOBAL	__end_of_Led_BlinkProcess
	__end_of_Led_BlinkProcess:
	signat	_Led_BlinkProcess,89
	global	_Charging_Control

;; *************** function _Charging_Control *****************
;; Defined at:
;;		line 527 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    5[COMMON] unsigned char 
;;  i               1    6[COMMON] unsigned char 
;;  chargeB7_12     1    4[COMMON] unsigned char 
;;  chargeB1_6      1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 100/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	527
global __ptext25
__ptext25:	;psect for function _Charging_Control
psect	text25
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	527
	global	__size_of_Charging_Control
	__size_of_Charging_Control	equ	__end_of_Charging_Control-_Charging_Control
	
_Charging_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _Charging_Control: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	530
	
i1l4161:	
;charge_mgr.c: 529: unsigned char i;
;charge_mgr.c: 530: unsigned char chargeB1_6 = 0;
	clrf	(Charging_Control@chargeB1_6)
	line	531
;charge_mgr.c: 531: unsigned char chargeB7_12 = 0;
	clrf	(Charging_Control@chargeB7_12)
	line	534
	
i1l4163:	
;charge_mgr.c: 534: if(g_tempProtect)
	movf	((_g_tempProtect)),w
	btfsc	status,2
	goto	u459_21
	goto	u459_20
u459_21:
	goto	i1l4169
u459_20:
	line	536
;charge_mgr.c: 535: {
;charge_mgr.c: 536: do { RA0=1; RA1=1; RB3=1; RB2=1; RA3=1; RA2=1; RD1=1; RD3=1; RB0=1; RB1=1; RD2=1; RD0=1; } while(0);
	
i1l661:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	bsf	(1073/8)^080h,(1073)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	bsf	(50/8),(50)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	bsf	(1074/8)^080h,(1074)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	bsf	(49/8),(49)&7	;volatile
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	
i1l662:	
	line	537
;charge_mgr.c: 537: RC3 = 0;
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	538
;charge_mgr.c: 538: RC5 = 0;
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	539
	
i1l4165:	
;charge_mgr.c: 539: g_pwmDuty = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	goto	i1l663
	line	546
	
i1l4169:	
;charge_mgr.c: 541: }
;charge_mgr.c: 546: if(g_vccProtect)
	movf	((_g_vccProtect)),w
	btfsc	status,2
	goto	u460_21
	goto	u460_20
u460_21:
	goto	i1l4179
u460_20:
	line	548
	
i1l4171:	
;charge_mgr.c: 547: {
;charge_mgr.c: 548: if(g_vcc_mv < 4600)
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u461_21
	goto	u461_20
u461_21:
	goto	i1l4177
u461_20:
	goto	i1l661
	line	556
	
i1l4177:	
;charge_mgr.c: 555: }
;charge_mgr.c: 556: g_vccProtect = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	line	557
;charge_mgr.c: 557: }
	goto	i1l4187
	line	560
	
i1l4179:	
;charge_mgr.c: 558: else
;charge_mgr.c: 559: {
;charge_mgr.c: 560: if(g_vcc_mv < 4400)
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u462_21
	goto	u462_20
u462_21:
	goto	i1l4187
u462_20:
	line	562
	
i1l4181:	
;charge_mgr.c: 561: {
;charge_mgr.c: 562: g_vccProtect = 1;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	incf	(_g_vccProtect),f
	goto	i1l661
	line	572
	
i1l4187:	
;charge_mgr.c: 568: }
;charge_mgr.c: 569: }
;charge_mgr.c: 572: for(i = 0; i < 12; i++)
	clrf	(Charging_Control@i)
	line	574
	
i1l4193:	
;charge_mgr.c: 573: {
;charge_mgr.c: 574: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Charging_Control@s)
	line	579
	
i1l4195:	
;charge_mgr.c: 577: if(s == 2 || s == 3 ||
;charge_mgr.c: 578: s == 4 || s == 5 ||
;charge_mgr.c: 579: s == 8)
		movlw	2
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u463_21
	goto	u463_20
u463_21:
	goto	i1l4207
u463_20:
	
i1l4197:	
		movlw	3
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u464_21
	goto	u464_20
u464_21:
	goto	i1l4207
u464_20:
	
i1l4199:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u465_21
	goto	u465_20
u465_21:
	goto	i1l4207
u465_20:
	
i1l4201:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u466_21
	goto	u466_20
u466_21:
	goto	i1l4207
u466_20:
	
i1l4203:	
		movlw	8
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u467_21
	goto	u467_20
u467_21:
	goto	i1l4215
u467_20:
	goto	i1l4207
	line	581
	
i1l679:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l4209
	
i1l681:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l4209
	
i1l682:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l4209
	
i1l683:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l4209
	
i1l684:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l4209
	
i1l685:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l4209
	
i1l686:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l4209
	
i1l687:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l4209
	
i1l688:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l4209
	
i1l689:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l4209
	
i1l690:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l4209
	
i1l691:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l4209
	
i1l4207:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l679
	xorlw	1^0	; case 1
	skipnz
	goto	i1l681
	xorlw	2^1	; case 2
	skipnz
	goto	i1l682
	xorlw	3^2	; case 3
	skipnz
	goto	i1l683
	xorlw	4^3	; case 4
	skipnz
	goto	i1l684
	xorlw	5^4	; case 5
	skipnz
	goto	i1l685
	xorlw	6^5	; case 6
	skipnz
	goto	i1l686
	xorlw	7^6	; case 7
	skipnz
	goto	i1l687
	xorlw	8^7	; case 8
	skipnz
	goto	i1l688
	xorlw	9^8	; case 9
	skipnz
	goto	i1l689
	xorlw	10^9	; case 10
	skipnz
	goto	i1l690
	xorlw	11^10	; case 11
	skipnz
	goto	i1l691
	goto	i1l4209
	opt asmopt_pop

	line	584
	
i1l4209:	
;charge_mgr.c: 584: if(i < 6)
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipnc
	goto	u468_21
	goto	u468_20
u468_21:
	goto	i1l693
u468_20:
	line	585
	
i1l4211:	
;charge_mgr.c: 585: chargeB1_6 = 1;
	clrf	(Charging_Control@chargeB1_6)
	incf	(Charging_Control@chargeB1_6),f
	goto	i1l4217
	line	586
	
i1l693:	
	line	587
;charge_mgr.c: 586: else
;charge_mgr.c: 587: chargeB7_12 = 1;
	clrf	(Charging_Control@chargeB7_12)
	incf	(Charging_Control@chargeB7_12),f
	goto	i1l4217
	line	591
	
i1l698:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l4217
	
i1l700:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l4217
	
i1l701:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	i1l4217
	
i1l702:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	i1l4217
	
i1l703:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l4217
	
i1l704:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l4217
	
i1l705:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l4217
	
i1l706:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l4217
	
i1l707:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	i1l4217
	
i1l708:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	i1l4217
	
i1l709:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l4217
	
i1l710:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l4217
	
i1l4215:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l698
	xorlw	1^0	; case 1
	skipnz
	goto	i1l700
	xorlw	2^1	; case 2
	skipnz
	goto	i1l701
	xorlw	3^2	; case 3
	skipnz
	goto	i1l702
	xorlw	4^3	; case 4
	skipnz
	goto	i1l703
	xorlw	5^4	; case 5
	skipnz
	goto	i1l704
	xorlw	6^5	; case 6
	skipnz
	goto	i1l705
	xorlw	7^6	; case 7
	skipnz
	goto	i1l706
	xorlw	8^7	; case 8
	skipnz
	goto	i1l707
	xorlw	9^8	; case 9
	skipnz
	goto	i1l708
	xorlw	10^9	; case 10
	skipnz
	goto	i1l709
	xorlw	11^10	; case 11
	skipnz
	goto	i1l710
	goto	i1l4217
	opt asmopt_pop

	line	572
	
i1l4217:	
	incf	(Charging_Control@i),f
	
i1l4219:	
	movlw	low(0Ch)
	subwf	(Charging_Control@i),w
	skipc
	goto	u469_21
	goto	u469_20
u469_21:
	goto	i1l4193
u469_20:
	
i1l673:	
	line	596
;charge_mgr.c: 592: }
;charge_mgr.c: 593: }
;charge_mgr.c: 596: RC3 = chargeB1_6;
	btfsc	(Charging_Control@chargeB1_6),0
	goto	u470_21
	goto	u470_20
	
u470_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2099/8)^0100h,(2099)&7	;volatile
	goto	u471_24
u470_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
u471_24:
	line	597
;charge_mgr.c: 597: RC5 = chargeB7_12;
	btfsc	(Charging_Control@chargeB7_12),0
	goto	u472_21
	goto	u472_20
	
u472_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u473_24
u472_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u473_24:
	line	600
	
i1l663:	
	return
	opt stack 0
GLOBAL	__end_of_Charging_Control
	__end_of_Charging_Control:
	signat	_Charging_Control,89
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 618 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    6[BANK0 ] unsigned int 
;;  s               1   17[BANK0 ] unsigned char 
;;  duty            2   14[BANK0 ] int 
;;  error           2   10[BANK0 ] int 
;;  adjust          2    0[BANK0 ] int 
;;  duty_initial    1   13[BANK0 ] unsigned char 
;;  duty_target     1   12[BANK0 ] unsigned char 
;;  maxV            2    8[BANK0 ] unsigned int 
;;  i               1   16[BANK0 ] unsigned char 
;;  preCount        1    5[BANK0 ] unsigned char 
;;  ccCount         1    4[BANK0 ] unsigned char 
;;  cvCount         1    3[BANK0 ] unsigned char 
;;  hasCharging     1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 100/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2      18       0       0       0
;;Total ram usage:       20 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___awdiv
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=0
	line	618
global __ptext26
__ptext26:	;psect for function _CCCV_Control
psect	text26
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	618
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	621
	
i1l4221:	
;charge_mgr.c: 620: unsigned char i;
;charge_mgr.c: 621: unsigned char hasCharging = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	622
;charge_mgr.c: 622: unsigned int maxV = 0;
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	623
;charge_mgr.c: 623: unsigned char cvCount = 0;
	clrf	(CCCV_Control@cvCount)
	line	624
;charge_mgr.c: 624: unsigned char ccCount = 0;
	clrf	(CCCV_Control@ccCount)
	line	625
;charge_mgr.c: 625: unsigned char preCount = 0;
	clrf	(CCCV_Control@preCount)
	line	628
;charge_mgr.c: 628: for(i = 0; i < 12; i++)
	clrf	(CCCV_Control@i)
	line	630
	
i1l4227:	
;charge_mgr.c: 629: {
;charge_mgr.c: 630: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	634
	
i1l4229:	
;charge_mgr.c: 632: if(s == 2 || s == 3 ||
;charge_mgr.c: 633: s == 4 || s == 5 ||
;charge_mgr.c: 634: s == 8)
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u474_21
	goto	u474_20
u474_21:
	goto	i1l718
u474_20:
	
i1l4231:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u475_21
	goto	u475_20
u475_21:
	goto	i1l718
u475_20:
	
i1l4233:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u476_21
	goto	u476_20
u476_21:
	goto	i1l718
u476_20:
	
i1l4235:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u477_21
	goto	u477_20
u477_21:
	goto	i1l718
u477_20:
	
i1l4237:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u478_21
	goto	u478_20
u478_21:
	goto	i1l716
u478_20:
	
i1l718:	
	line	636
;charge_mgr.c: 635: {
;charge_mgr.c: 636: hasCharging = 1;
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	638
	
i1l4239:	
;charge_mgr.c: 637: {
;charge_mgr.c: 638: unsigned int vt = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	639
	
i1l4241:	
;charge_mgr.c: 639: if(vt > maxV) maxV = vt;
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u479_25
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u479_25:
	skipnc
	goto	u479_21
	goto	u479_20
u479_21:
	goto	i1l4245
u479_20:
	
i1l4243:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	641
	
i1l4245:	
;charge_mgr.c: 640: }
;charge_mgr.c: 641: if(s == 5)
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u480_21
	goto	u480_20
u480_21:
	goto	i1l4249
u480_20:
	line	642
	
i1l4247:	
;charge_mgr.c: 642: cvCount++;
	incf	(CCCV_Control@cvCount),f
	line	643
	
i1l4249:	
;charge_mgr.c: 643: if(s == 4)
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u481_21
	goto	u481_20
u481_21:
	goto	i1l4253
u481_20:
	line	644
	
i1l4251:	
;charge_mgr.c: 644: ccCount++;
	incf	(CCCV_Control@ccCount),f
	line	645
	
i1l4253:	
;charge_mgr.c: 645: if(s == 3 || s == 2)
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u482_21
	goto	u482_20
u482_21:
	goto	i1l4257
u482_20:
	
i1l4255:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u483_21
	goto	u483_20
u483_21:
	goto	i1l716
u483_20:
	line	646
	
i1l4257:	
;charge_mgr.c: 646: preCount++;
	incf	(CCCV_Control@preCount),f
	line	647
	
i1l716:	
	line	628
	incf	(CCCV_Control@i),f
	
i1l4259:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u484_21
	goto	u484_20
u484_21:
	goto	i1l4227
u484_20:
	line	651
	
i1l4261:	
;charge_mgr.c: 647: }
;charge_mgr.c: 648: }
;charge_mgr.c: 651: if(!hasCharging)
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u485_21
	goto	u485_20
u485_21:
	goto	i1l4267
u485_20:
	line	653
	
i1l4263:	
;charge_mgr.c: 652: {
;charge_mgr.c: 653: g_pwmDuty = 0;
	clrf	(_g_pwmDuty)	;volatile
	line	654
;charge_mgr.c: 654: g_cvIntegral = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	i1l726
	line	662
	
i1l4267:	
;charge_mgr.c: 656: }
;charge_mgr.c: 662: if(cvCount == 0)
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u486_21
	goto	u486_20
u486_21:
	goto	i1l4293
u486_20:
	line	666
	
i1l4269:	
;charge_mgr.c: 663: {
;charge_mgr.c: 664: unsigned char duty_target, duty_initial;
;charge_mgr.c: 666: if(ccCount > 0)
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u487_21
	goto	u487_20
u487_21:
	goto	i1l4273
u487_20:
	line	669
	
i1l4271:	
;charge_mgr.c: 667: {
;charge_mgr.c: 669: duty_target = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	670
;charge_mgr.c: 670: duty_initial = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	671
;charge_mgr.c: 671: }
	goto	i1l729
	line	672
	
i1l4273:	
;charge_mgr.c: 672: else if(preCount > 0)
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u488_21
	goto	u488_20
u488_21:
	goto	i1l4271
u488_20:
	line	675
	
i1l4275:	
;charge_mgr.c: 673: {
;charge_mgr.c: 675: duty_target = 8;
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	676
;charge_mgr.c: 676: duty_initial = 5;
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	682
;charge_mgr.c: 677: }
	
i1l729:	
	line	684
;charge_mgr.c: 682: }
;charge_mgr.c: 684: if(g_pwmDuty < duty_initial)
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u489_21
	goto	u489_20
u489_21:
	goto	i1l4285
u489_20:
	line	687
	
i1l4279:	
;charge_mgr.c: 685: {
;charge_mgr.c: 687: g_pwmDuty += 3;
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	688
	
i1l4281:	
;charge_mgr.c: 688: if(g_pwmDuty > duty_initial)
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u490_21
	goto	u490_20
u490_21:
	goto	i1l726
u490_20:
	line	689
	
i1l4283:	
;charge_mgr.c: 689: g_pwmDuty = duty_initial;
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l726
	line	691
	
i1l4285:	
	line	694
	
i1l4287:	
;charge_mgr.c: 692: {
;charge_mgr.c: 694: g_pwmDuty = duty_target;
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	695
;charge_mgr.c: 695: }
	goto	i1l726
	line	710
	
i1l4293:	
;charge_mgr.c: 702: }
;charge_mgr.c: 709: {
;charge_mgr.c: 710: int error = (int)(3100) - (int)(maxV);
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	713
;charge_mgr.c: 713: g_cvIntegral += error * 1;
	movf	(CCCV_Control@error),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral)^080h,f
	skipnc
	incf	(_g_cvIntegral+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(CCCV_Control@error+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral+1)^080h,f
	line	714
	
i1l4295:	
;charge_mgr.c: 714: if(g_cvIntegral > 200)
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u491_25
	movlw	0C9h
	subwf	(_g_cvIntegral)^080h,w
u491_25:

	skipc
	goto	u491_21
	goto	u491_20
u491_21:
	goto	i1l4299
u491_20:
	line	715
	
i1l4297:	
;charge_mgr.c: 715: g_cvIntegral = 200;
	movlw	0C8h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	i1l4303
	line	716
	
i1l4299:	
;charge_mgr.c: 716: else if(g_cvIntegral < -200)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u492_25
	movlw	038h
	subwf	(_g_cvIntegral)^080h,w
u492_25:

	skipnc
	goto	u492_21
	goto	u492_20
u492_21:
	goto	i1l4303
u492_20:
	line	717
	
i1l4301:	
;charge_mgr.c: 717: g_cvIntegral = -200;
	movlw	038h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	movlw	0FFh
	movwf	((_g_cvIntegral)^080h)+1
	line	720
	
i1l4303:	
;charge_mgr.c: 720: int adjust = (error * 4 + g_cvIntegral) / 8;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_cvIntegral)^080h,w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1)^080h,w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	721
	
i1l4305:	
;charge_mgr.c: 721: int duty = (int)g_pwmDuty + adjust;
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
i1l4307:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	724
	
i1l4309:	
;charge_mgr.c: 724: if(duty > 32) duty = 32;
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u493_25
	movlw	021h
	subwf	(CCCV_Control@duty),w
u493_25:

	skipc
	goto	u493_21
	goto	u493_20
u493_21:
	goto	i1l4313
u493_20:
	
i1l4311:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	725
	
i1l4313:	
;charge_mgr.c: 725: if(duty < 0) duty = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u494_21
	goto	u494_20
u494_21:
	goto	i1l4317
u494_20:
	
i1l4315:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	727
	
i1l4317:	
;charge_mgr.c: 727: g_pwmDuty = (unsigned char)duty;
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	729
	
i1l726:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	i1___bmul

;; *************** function i1___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[COMMON] unsigned char 
;;  __bmul          1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext27
__ptext27:	;psect for function i1___bmul
psect	text27
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_ofi1___bmul
	__size_ofi1___bmul	equ	__end_ofi1___bmul-i1___bmul
	
i1___bmul:	
;incstack = 0
	opt	stack 2
; Regs used in i1___bmul: [wreg+status,2+status,0]
;i1___bmul@multiplier stored from wreg
	movwf	(i1___bmul@multiplier)
	line	6
	
i1l2843:	
	clrf	(i1___bmul@product)
	line	43
	
i1l2845:	
	btfss	(i1___bmul@multiplier),(0)&7
	goto	u269_21
	goto	u269_20
u269_21:
	goto	i1l2849
u269_20:
	line	44
	
i1l2847:	
	movf	(i1___bmul@multiplicand),w
	addwf	(i1___bmul@product),f
	line	45
	
i1l2849:	
	clrc
	rlf	(i1___bmul@multiplicand),f
	line	46
	
i1l2851:	
	clrc
	rrf	(i1___bmul@multiplier),f
	line	47
	movf	((i1___bmul@multiplier)),w
	btfss	status,2
	goto	u270_21
	goto	u270_20
u270_21:
	goto	i1l2845
u270_20:
	line	50
	
i1l2853:	
	movf	(i1___bmul@product),w
	line	51
	
i1l795:	
	return
	opt stack 0
GLOBAL	__end_ofi1___bmul
	__end_ofi1___bmul:
	signat	i1___bmul,89
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] int 
;;  dividend        2    2[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] int 
;;  sign            1    5[COMMON] unsigned char 
;;  counter         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext28
__ptext28:	;psect for function ___awdiv
psect	text28
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
i1l2799:	
	clrf	(___awdiv@sign)
	line	15
	
i1l2801:	
	btfss	(___awdiv@divisor+1),7
	goto	u262_21
	goto	u262_20
u262_21:
	goto	i1l2807
u262_20:
	line	16
	
i1l2803:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
i1l2805:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
i1l2807:	
	btfss	(___awdiv@dividend+1),7
	goto	u263_21
	goto	u263_20
u263_21:
	goto	i1l2813
u263_20:
	line	20
	
i1l2809:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
i1l2811:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
i1l2813:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
i1l2815:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u264_21
	goto	u264_20
u264_21:
	goto	i1l2835
u264_20:
	line	25
	
i1l2817:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	i1l2821
	line	27
	
i1l2819:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
i1l2821:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u265_21
	goto	u265_20
u265_21:
	goto	i1l2819
u265_20:
	line	31
	
i1l2823:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
i1l2825:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u266_25
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u266_25:
	skipc
	goto	u266_21
	goto	u266_20
u266_21:
	goto	i1l2831
u266_20:
	line	33
	
i1l2827:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
i1l2829:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
i1l2831:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
i1l2833:	
	decfsz	(___awdiv@counter),f
	goto	u267_21
	goto	u267_20
u267_21:
	goto	i1l2823
u267_20:
	line	39
	
i1l2835:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u268_21
	goto	u268_20
u268_21:
	goto	i1l2839
u268_20:
	line	40
	
i1l2837:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
i1l2839:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
i1l907:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
