/*-------------------------------------------
  L1211 12槽充电器 - UART调试输出模块
  功能: 串口发送、状态打印(每秒一次)
  配置: 软件UART, 9600bps, 8N1, TX=RC4(CLK, 仅TX)
  输出格式:
    T:温度C VDD:电源电压mV
    B1:V=ADC值 S=状态 T=类型 [ERR/FULL/CHG]
    B2:V=... ...
    ... (共12路)
  注: 调试输出可通过UART_PRINT_EN宏开关控制
-------------------------------------------*/
#include "config.h"

#if UART_PRINT_EN

/*========================================================================
  函数: uart_init
  功能: 软件UART引脚初始化
  配置: RC4=输出, 数字模式, 初始高电平(空闲态)
========================================================================*/
void uart_init(void)
{
	TRISC &= ~0x10;             /* RC4=输出 */
	ANSEL2 &= ~0x10;            /* RC4=数字模式(非模拟) */
	SW_TX = 1;                  /* 空闲态高电平 */
}

/*========================================================================
  函数: uart_send_char
  功能: 发送单个字符(软件模拟9600bps)
  参数: c - 要发送的字符
  时序: 起始位0 + 8数据位(LSB first) + 停止位1
  说明: 关全局中断保证时序准确, 发送完成后恢复
========================================================================*/
void uart_send_char(unsigned char c)
{
	unsigned char i;
	GIE = 0;                    /* 关中断保证时序 */
	SW_TX = 0;                  /* 起始位 */
	__delay_us(BIT_TIME);
	for(i = 0; i < 8; i++)
	{
		if(c & 0x01)
			SW_TX = 1;
		else
			SW_TX = 0;
		__delay_us(BIT_TIME);
		c >>= 1;
	}
	SW_TX = 1;                  /* 停止位 */
	__delay_us(BIT_TIME);
	GIE = 1;                    /* 恢复中断 */
}

/*========================================================================
  函数: uart_send_string
  功能: 发送字符串(以'\0'结尾)
  参数: str - 字符串指针
  说明: 逐个字符发送, 直到遇到'\0'
========================================================================*/
void uart_send_string(const unsigned char *str)
{
	while(*str != '\0')
		uart_send_char(*str++);     /* 逐字符发送 */
}

/*========================================================================
  函数: uart_send_number
  功能: 发送无符号整数的十进制字符串
  参数: num - 要发送的数字
  算法: 逐位取模转字符, 先存后逆序发送
  例如: num=123 -> buf=['3','2','1'] -> 发送"123"
========================================================================*/
void uart_send_number(unsigned int num)
{
	unsigned char buf[6];           /* 最大65535, 5位+1 */
	unsigned char i = 0;
	unsigned char j;

	/* 特殊处理: 0 */
	if(num == 0)
	{
		uart_send_char('0');
		return;
	}

	/* 逐位取模, 存入缓冲区(低位在前) */
	while(num > 0)
	{
		buf[i++] = '0' + (num % 10);  /* 数字转ASCII字符 */
		num /= 10;
	}

	/* 逆序发送(高位在前) */
	for(j = i; j > 0; j--)
		uart_send_char(buf[j-1]);
}

/*========================================================================
  函数: uart_send_hex
  功能: 发送无符号整数的十六进制字符串(0xXX格式)
  参数: val - 要发送的数值(0~255)
========================================================================*/
void uart_send_hex(unsigned char val)
{
	unsigned char nib;
	uart_send_string("0x");
	nib = (val >> 4) & 0x0F;
	uart_send_char((nib < 10) ? ('0' + nib) : ('A' + nib - 10));
	nib = val & 0x0F;
	uart_send_char((nib < 10) ? ('0' + nib) : ('A' + nib - 10));
}

/*========================================================================
  函数: Print_Status
  功能: B1诊断模式 v4 - 双参考对比 + 寄存器转储
  输出格式: 
    RAW=raw CON1=adcon1 CON0=adcon0
    B1-LDO=curr[min~max] B1-VDD=curr B2=curr VREF=curr[min~max] sat=N
  含义:
    RAW  =单次原始ADC值(无平均, ADCON1=0x47手写CHS4)
    CON1 =ADCON1快照(转换时刻), 验证CHS4/LDO是否实际生效
    CON0 =ADCON0快照(转换时刻), 验证通道选择
    B1-LDO/B1-VDD/B2/VREF = v3诊断同
========================================================================*/
void Print_Status(void)
{
	uart_send_string("RAW=");
	uart_send_number(g_dbg_raw_adc);
	uart_send_string(" CON1=");
	uart_send_hex(g_dbg_adcon1);
	uart_send_string(" CON0=");
	uart_send_hex(g_dbg_adcon0);
	uart_send_string(" B1-LDO=");
	uart_send_number(g_ntcDiagAdc);
	uart_send_string("[");
	uart_send_number(g_b1Min);
	uart_send_string("~");
	uart_send_number(g_b1Max);
	uart_send_string("] B1-VDD=");
	uart_send_number(g_ntcDiagVdd);
	uart_send_string(" B2=");
	uart_send_number(g_ntcDebugAdc);
	uart_send_string(" VREF=");
	uart_send_number(g_ntcDiagChk);
	uart_send_string("[");
	uart_send_number(g_vrefMin);
	uart_send_string("~");
	uart_send_number(g_vrefMax);
	uart_send_string("] sat=");
	uart_send_number(g_satSaved);
	uart_send_string("\r\n");
}
#endif
