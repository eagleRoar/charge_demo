opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ChargeProcess_Slot
	FNCALL	_main,_Do_AdcSample
	FNCALL	_main,_Do_NtcRead
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_System_Init
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_Do_AdcSample,_ADC_Sample
	FNCALL	_Do_AdcSample,___bmul
	FNCALL	_ChargeProcess_Slot,_Detect_BatteryType
	FNCALL	_ChargeProcess_Slot,___bmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_CCCV_Control
	FNCALL	_Isr_Timer,_Charging_Control
	FNCALL	_Isr_Timer,_Led_BlinkProcess
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Update_LED_Slot
	FNCALL	_Update_LED_Slot,i1___bmul
	FNCALL	_Led_BlinkProcess,i1___bmul
	FNCALL	_Charging_Control,i1___bmul
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,i1___bmul
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_s_adcChannels
psect	strings,class=STRING,delta=2,noexec
global __pstrings
__pstrings:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 1 byte each
stringcode:stringdir:
movlw high(stringdir)
movwf pclath
movf fsr,w
incf fsr
	addwf pc
	global __stringbase
__stringbase:
	retlw	0
psect	strings
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	40
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_scanIndex
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_adcBusy
	global	_g_doAdcSample
	global	_power_ad
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_powerOnTimer
	global	_g_cvIntegral
	global	_g_tempProtect
	global	_g_tempPhase
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_scanPhase
	global	_test_adc
	global	_adresult
	global	_g_slot0
	global	_g_slot1
	global	_OSCCON
_OSCCON	set	20
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_GIE
_GIE	set	0x5F
	global	_PEIE
_PEIE	set	0x5E
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IE
_T0IE	set	0x5D
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RC4
_RC4	set	0x834
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC5
_RC5	set	0x835
	global	_RC3
_RC3	set	0x833
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_1:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	strings
	
STR_16:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	strings
	
STR_17:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	strings
	
STR_25:	
	retlw	93	;']'
	retlw	32	;' '
	retlw	66	;'B'
	retlw	49	;'1'
	retlw	45	;'-'
	retlw	86	;'V'
	retlw	68	;'D'
	retlw	68	;'D'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_22:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	49	;'1'
	retlw	45	;'-'
	retlw	76	;'L'
	retlw	68	;'D'
	retlw	79	;'O'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_6:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	32	;' '
	retlw	0
psect	strings
	
STR_12:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	32	;' '
	retlw	0
psect	strings
	
STR_14:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	32	;' '
	retlw	0
psect	strings
	
STR_9:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	32	;' '
	retlw	0
psect	strings
	
STR_13:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	32	;' '
	retlw	0
psect	strings
	
STR_8:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	32	;' '
	retlw	0
psect	strings
	
STR_7:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	32	;' '
	retlw	0
psect	strings
	
STR_21:	
	retlw	32	;' '
	retlw	67	;'C'
	retlw	79	;'O'
	retlw	78	;'N'
	retlw	48	;'0'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_20:	
	retlw	32	;' '
	retlw	67	;'C'
	retlw	79	;'O'
	retlw	78	;'N'
	retlw	49	;'1'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_27:	
	retlw	32	;' '
	retlw	86	;'V'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	70	;'F'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_30:	
	retlw	93	;']'
	retlw	32	;' '
	retlw	115	;'s'
	retlw	97	;'a'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_10:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	32	;' '
	retlw	0
psect	strings
	
STR_11:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	32	;' '
	retlw	0
psect	strings
	
STR_3:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_26:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	50	;'2'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_2:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_19:	
	retlw	82	;'R'
	retlw	65	;'A'
	retlw	87	;'W'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_4:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	strings
	
STR_18:	
	retlw	48	;'0'
	retlw	120	;'x'
	retlw	0
psect	strings
	
STR_23:	
	retlw	91	;'['
	retlw	0
psect	strings
	
STR_24:	
	retlw	126	;'~'
	retlw	0
psect	strings
STR_29	equ	STR_24+0
STR_28	equ	STR_23+0
STR_5	equ	STR_17+7
STR_15	equ	STR_17+7
STR_31	equ	STR_17+7
; #config settings
	file	"SC8P096_timer_C.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

_g_adcBusy:
       ds      1

_g_doAdcSample:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_g_scanIndex:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_power_ad:
       ds      2

_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_powerOnTimer:
       ds      2

_g_cvIntegral:
       ds      2

_g_tempProtect:
       ds      1

_g_tempPhase:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_scanPhase:
       ds      1

_test_adc:
       ds      1

_adresult:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_slot0:
       ds      72

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slot1:
       ds      72

	file	"SC8P096_timer_C.as"
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+015h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+048h)
	fcall	clear_ram0
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK3,class=BANK3,space=1,noexec
global __pcstackBANK3
__pcstackBANK3:
??_main:	; 1 bytes @ 0x0
	ds	2
psect	cstackBANK2,class=BANK2,space=1,noexec
global __pcstackBANK2
__pcstackBANK2:
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x0
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x1
	ds	1
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x2
	ds	1
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	4
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	2
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	2
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	2
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0xD
	ds	4
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x11
	ds	2
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x13
	ds	1
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x14
	ds	2
	global	_Print_SystemStatus$331
_Print_SystemStatus$331:	; 2 bytes @ 0x16
	ds	2
	global	_Print_SystemStatus$343
_Print_SystemStatus$343:	; 2 bytes @ 0x18
	ds	2
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x1A
	ds	1
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x0
	ds	6
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0x6
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x7
	ds	1
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Update_LED_Slot:	; 1 bytes @ 0x0
?_Charging_Control:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Led_BlinkProcess:	; 1 bytes @ 0x0
?_uart_send_string:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_ChargeProcess_Slot:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Do_AdcSample:	; 1 bytes @ 0x0
?_Do_NtcRead:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?i1___bmul:	; 1 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	i1___bmul@multiplicand
i1___bmul@multiplicand:	; 1 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	ds	1
??i1___bmul:	; 1 bytes @ 0x1
	global	i1___bmul@multiplier
i1___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
	global	i1___bmul@product
i1___bmul@product:	; 1 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_Update_LED_Slot:	; 1 bytes @ 0x3
??_Charging_Control:	; 1 bytes @ 0x3
??_Led_BlinkProcess:	; 1 bytes @ 0x3
	ds	1
??___awdiv:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	ds	1
	global	Update_LED_Slot@idx
Update_LED_Slot@idx:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	global	_Charging_Control$452
_Charging_Control$452:	; 2 bytes @ 0x5
	ds	1
	global	Update_LED_Slot@p
Update_LED_Slot@p:	; 2 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	1
	global	Charging_Control@chargeB1_6
Charging_Control@chargeB1_6:	; 1 bytes @ 0x7
	ds	1
??_CCCV_Control:	; 1 bytes @ 0x8
	global	Charging_Control@chargeB7_12
Charging_Control@chargeB7_12:	; 1 bytes @ 0x8
	ds	1
	global	Charging_Control@s
Charging_Control@s:	; 1 bytes @ 0x9
	ds	1
	global	Charging_Control@i
Charging_Control@i:	; 1 bytes @ 0xA
	ds	2
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x0
	global	_Led_BlinkProcess$520
_Led_BlinkProcess$520:	; 2 bytes @ 0x0
	ds	2
	global	_CCCV_Control$469
_CCCV_Control$469:	; 2 bytes @ 0x2
	global	_Led_BlinkProcess$531
_Led_BlinkProcess$531:	; 2 bytes @ 0x2
	ds	2
	global	_CCCV_Control$480
_CCCV_Control$480:	; 2 bytes @ 0x4
	global	_Led_BlinkProcess$542
_Led_BlinkProcess$542:	; 2 bytes @ 0x4
	ds	2
	global	_CCCV_Control$491
_CCCV_Control$491:	; 2 bytes @ 0x6
	global	_Led_BlinkProcess$553
_Led_BlinkProcess$553:	; 2 bytes @ 0x6
	ds	2
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x8
	global	_Led_BlinkProcess$564
_Led_BlinkProcess$564:	; 2 bytes @ 0x8
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x9
	ds	1
	global	Led_BlinkProcess@i
Led_BlinkProcess@i:	; 1 bytes @ 0xA
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0xA
	ds	2
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xC
	ds	2
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0xE
	ds	2
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x10
	ds	1
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x11
	ds	1
??_Isr_Timer:	; 1 bytes @ 0x12
	ds	4
??_AD_Init:	; 1 bytes @ 0x16
??_uart_init:	; 1 bytes @ 0x16
?_ADC_Sample:	; 1 bytes @ 0x16
??_uart_send_char:	; 1 bytes @ 0x16
??_Do_NtcRead:	; 1 bytes @ 0x16
?_Detect_BatteryType:	; 1 bytes @ 0x16
?___bmul:	; 1 bytes @ 0x16
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x16
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x16
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x16
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x16
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x16
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x16
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x16
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x16
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x16
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x17
??___bmul:	; 1 bytes @ 0x17
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x17
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x17
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x18
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x18
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x18
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x18
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x18
	ds	1
??_uart_send_string:	; 1 bytes @ 0x19
??_ChargeProcess_Slot:	; 1 bytes @ 0x19
??_System_Init:	; 1 bytes @ 0x19
	global	uart_send_string@str
uart_send_string@str:	; 1 bytes @ 0x19
	ds	1
??___lwdiv:	; 1 bytes @ 0x1A
??___lwmod:	; 1 bytes @ 0x1A
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x1A
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x1A
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x1A
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x1A
	ds	1
??_Do_AdcSample:	; 1 bytes @ 0x1B
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x1B
	ds	2
?_uart_send_number:	; 1 bytes @ 0x1D
	global	Do_AdcSample@ch
Do_AdcSample@ch:	; 1 bytes @ 0x1D
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x1D
	ds	1
??___lldiv:	; 1 bytes @ 0x1E
	global	_Do_AdcSample$299
_Do_AdcSample$299:	; 2 bytes @ 0x1E
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x1E
	ds	1
??_uart_send_number:	; 1 bytes @ 0x1F
	global	ChargeProcess_Slot@idx
ChargeProcess_Slot@idx:	; 1 bytes @ 0x1F
	ds	1
	global	_Do_AdcSample$310
_Do_AdcSample$310:	; 2 bytes @ 0x20
	global	ChargeProcess_Slot@v
ChargeProcess_Slot@v:	; 2 bytes @ 0x20
	ds	2
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x22
	global	ChargeProcess_Slot@p
ChargeProcess_Slot@p:	; 2 bytes @ 0x22
	ds	1
??_Print_SystemStatus:	; 1 bytes @ 0x23
	ds	2
;!
;!Data Sizes:
;!    Strings     202
;!    Constant    12
;!    Data        0
;!    BSS         166
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     12      14
;!    BANK0            80     37      58
;!    BANK1            80      8      80
;!    BANK3            80      2      74
;!    BANK2            80     27      27

;!
;!Pointer List with Targets:
;!
;!    Led_BlinkProcess$564	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    Led_BlinkProcess$553	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    Led_BlinkProcess$542	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    Led_BlinkProcess$531	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    Led_BlinkProcess$520	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    Update_LED_Slot@p	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    CCCV_Control$491	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    CCCV_Control$480	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    CCCV_Control$469	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    Charging_Control$452	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    ChargeProcess_Slot@p	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    uart_send_string@str	PTR const unsigned char  size(1) Largest target is 29
;!		 -> STR_31(CODE[3]), STR_30(CODE[7]), STR_29(CODE[2]), STR_28(CODE[2]), 
;!		 -> STR_27(CODE[7]), STR_26(CODE[5]), STR_25(CODE[10]), STR_24(CODE[2]), 
;!		 -> STR_23(CODE[2]), STR_22(CODE[9]), STR_21(CODE[7]), STR_20(CODE[7]), 
;!		 -> STR_19(CODE[5]), STR_18(CODE[3]), STR_17(CODE[10]), STR_16(CODE[21]), 
;!		 -> STR_15(CODE[3]), STR_14(CODE[7]), STR_13(CODE[7]), STR_12(CODE[8]), 
;!		 -> STR_11(CODE[6]), STR_10(CODE[6]), STR_9(CODE[7]), STR_8(CODE[7]), 
;!		 -> STR_7(CODE[7]), STR_6(CODE[8]), STR_5(CODE[3]), STR_4(CODE[4]), 
;!		 -> STR_3(CODE[6]), STR_2(CODE[5]), STR_1(CODE[29]), 
;!
;!    Print_SystemStatus$343	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    Print_SystemStatus$331	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    Do_AdcSample$310	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    Do_AdcSample$299	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->_CCCV_Control
;!    _Update_LED_Slot->i1___bmul
;!    _Led_BlinkProcess->i1___bmul
;!    _Charging_Control->i1___bmul
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Print_SystemStatus
;!    _System_Init->___bmul
;!    _Print_SystemStatus->___lldiv
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->___bmul
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    _Isr_Timer->_CCCV_Control
;!
;!Critical Paths under _main in BANK1
;!
;!    _Print_SystemStatus->_uart_send_number
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    _main->_Print_SystemStatus
;!    _Print_SystemStatus->_ADC_Sample
;!    _Do_AdcSample->_ADC_Sample
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 2     2      0   15402
;!                                              0 BANK3      2     2      0
;!                 _ChargeProcess_Slot
;!                       _Do_AdcSample
;!                         _Do_NtcRead
;!                 _Print_SystemStatus
;!                        _System_Init
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          2     2      0    1902
;!                                             25 BANK0      2     2      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  16    16      0    6163
;!                                             35 BANK0      2     2      0
;!                                             13 BANK2     14    14      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     1     1      0    1097
;!                                             25 BANK0      1     1      0
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_number                                    10     8      2    1941
;!                                             29 BANK0      2     0      2
;!                                              0 BANK1      8     8      0
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     102
;!                                             22 BANK0      3     3      0
;! ---------------------------------------------------------------------------------
;! (3) ___lwmod                                              5     1      4     362
;!                                             22 BANK0      5     1      4
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4     371
;!                                             22 BANK0      7     3      4
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8      52
;!                                             22 BANK0     13     5      8
;! ---------------------------------------------------------------------------------
;! (1) _Do_NtcRead                                           0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Do_AdcSample                                         7     7      0    2337
;!                                             27 BANK0      7     7      0
;!                         _ADC_Sample
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) _ADC_Sample                                          18    17      1     945
;!                                             22 BANK0      5     4      1
;!                                              0 BANK2     13    13      0
;! ---------------------------------------------------------------------------------
;! (1) _ChargeProcess_Slot                                  11    11      0    3903
;!                                             25 BANK0     11    11      0
;!                 _Detect_BatteryType
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1    1276
;!                                             22 BANK0      3     2      1
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     273
;!                                             22 BANK0      2     0      2
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 3
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            4     4      0    4720
;!                                             18 BANK0      4     4      0
;!                       _CCCV_Control
;!                   _Charging_Control
;!                   _Led_BlinkProcess
;!                 _PowerOnLedSequence
;!                    _Update_LED_Slot
;! ---------------------------------------------------------------------------------
;! (5) _Update_LED_Slot                                      5     5      0     737
;!                                              3 COMMON     5     5      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Led_BlinkProcess                                    15    15      0    1186
;!                                              3 COMMON     4     4      0
;!                                              0 BANK0     11    11      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _Charging_Control                                     8     8      0     944
;!                                              3 COMMON     8     8      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _CCCV_Control                                        22    22      0    1853
;!                                              8 COMMON     4     4      0
;!                                              0 BANK0     18    18      0
;!                            ___awdiv
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (6) i1___bmul                                             3     2      1     448
;!                                              0 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (6) ___awdiv                                              8     4      4     428
;!                                              0 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ChargeProcess_Slot
;!     _Detect_BatteryType
;!     ___bmul
;!   _Do_AdcSample
;!     _ADC_Sample
;!     ___bmul
;!   _Do_NtcRead
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!     _uart_send_char
;!     _uart_send_number
;!       ___lwdiv
;!       ___lwmod
;!       _uart_send_char
;!     _uart_send_string
;!       _uart_send_char
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     i1___bmul
;!   _Charging_Control
;!     i1___bmul
;!   _Led_BlinkProcess
;!     i1___bmul
;!   _PowerOnLedSequence
;!   _Update_LED_Slot
;!     i1___bmul
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BITCOMMON            E      0       1       0        7.1%
;!NULL                 0      0       0       0        0.0%
;!CODE                 0      0       0       0        0.0%
;!COMMON               E      C       E       1      100.0%
;!BITSFR0              0      0       0       1        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!SFR1                 0      0       0       2        0.0%
;!STACK                0      0       0       2        0.0%
;!BITBANK0            50      0       0       3        0.0%
;!BANK0               50     25      3A       4       72.5%
;!BITSFR3              0      0       0       4        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITBANK1            50      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BANK1               50      8      50       6      100.0%
;!BITBANK3            50      0       0       7        0.0%
;!BANK3               50      2      4A       8       92.5%
;!BITBANK2            50      0       0       9        0.0%
;!BANK2               50     1B      1B      10       33.8%
;!ABS                  0      0      FD      11        0.0%
;!DATA                 0      0      FD      12        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 384 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       2       0
;;      Totals:         0       0       0       2       0
;;Total ram usage:        2 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ChargeProcess_Slot
;;		_Do_AdcSample
;;		_Do_NtcRead
;;		_Print_SystemStatus
;;		_System_Init
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	384
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	384
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	387
	
l4005:	
;main.c: 387: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
movwf	((??_main+0)^0180h+0+1),f
	movlw	241
movwf	((??_main+0)^0180h+0),f
	u4037:
decfsz	((??_main+0)^0180h+0),f
	goto	u4037
	decfsz	((??_main+0)^0180h+0+1),f
	goto	u4037
opt asmopt_pop

	line	388
# 388 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	391
	
l4007:	
;main.c: 391: System_Init();
	fcall	_System_Init
	line	394
	
l4009:	
;main.c: 394: uart_send_string("L1211 Charger V2.1\r\n");
	movlw	(low((((STR_16)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	395
	
l4011:	
;main.c: 395: uart_send_string("Init...\r\n");
	movlw	(low((((STR_17)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	398
;main.c: 398: while(1)
	
l462:	
	line	400
# 400 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	403
	
l4013:	
;main.c: 403: if(g_doAdcSample)
	btfss	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u4001
	goto	u4000
u4001:
	goto	l4021
u4000:
	line	405
	
l4015:	
;main.c: 404: {
;main.c: 405: g_doAdcSample = 0;
	bcf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	line	406
;main.c: 406: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	407
	
l4017:	
;main.c: 407: Do_AdcSample();
	fcall	_Do_AdcSample
	line	411
;main.c: 411: ChargeProcess_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_ChargeProcess_Slot
	line	412
	
l4019:	
;main.c: 412: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	416
	
l4021:	
;main.c: 413: }
;main.c: 416: if(g_doNtcRead)
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u4011
	goto	u4010
u4011:
	goto	l4029
u4010:
	line	418
	
l4023:	
;main.c: 417: {
;main.c: 418: g_doNtcRead = 0;
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	419
;main.c: 419: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	420
	
l4025:	
;main.c: 420: Do_NtcRead();
	fcall	_Do_NtcRead
	line	421
	
l4027:	
;main.c: 421: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	425
	
l4029:	
;main.c: 422: }
;main.c: 425: if(g_printFlag)
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u4021
	goto	u4020
u4021:
	goto	l462
u4020:
	line	427
	
l4031:	
;main.c: 426: {
;main.c: 427: g_printFlag = 0;
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	428
	
l4033:	
;main.c: 428: Print_SystemStatus();
	fcall	_Print_SystemStatus
	goto	l462
	global	start
	ljmp	start
	opt stack 0
	line	431
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 76 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   26[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	76
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	76
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	81
	
l3275:	
# 81 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	82
# 82 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text1
	line	83
	
l3277:	
;main.c: 83: OSCCON = 0x72;
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	87
;main.c: 87: TRISA = 0xF0; PORTA = 0x0F;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	88
;main.c: 88: TRISB = 0x30; PORTB = 0x4F;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	89
;main.c: 89: TRISC = 0x07; PORTC = 0x00;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l3279:	
	clrf	(262)^0100h	;volatile
	line	90
	
l3281:	
;main.c: 90: TRISD = 0xF0; PORTD = 0x0F;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l3283:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	93
	
l3285:	
;main.c: 93: WPUA = 0x00; WPDA = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l3287:	
	clrf	(135)^080h	;volatile
	line	94
	
l3289:	
;main.c: 94: WPUB = 0x00; WPDB = 0x00;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l3291:	
	clrf	(7)	;volatile
	line	95
	
l3293:	
;main.c: 95: WPUC = 0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	96
	
l3295:	
;main.c: 96: WPUD = 0x00;
	clrf	(277)^0100h	;volatile
	line	99
	
l3297:	
;main.c: 99: IOCA = 0x00; IOCB = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l3299:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	102
	
l3301:	
;main.c: 102: CC0CON = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	103
	
l3303:	
;main.c: 103: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	110
	
l3305:	
;main.c: 110: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	111
	
l3307:	
;main.c: 111: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	112
	
l3309:	
;main.c: 112: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	113
	
l3311:	
;main.c: 113: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	116
	
l3313:	
;main.c: 116: AD_Init();
	fcall	_AD_Init
	line	119
	
l3315:	
;main.c: 119: uart_init();
	fcall	_uart_init
	line	126
	
l3317:	
;main.c: 126: OPTION_REG = 0x80;
	movlw	low(080h)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(1)	;volatile
	line	127
	
l3319:	
;main.c: 127: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	128
	
l3321:	
;main.c: 128: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	129
	
l3323:	
;main.c: 129: T0IE = 1;
	bsf	(93/8),(93)&7	;volatile
	line	132
;main.c: 132: g_pwmDuty = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	133
;main.c: 133: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	134
	
l3325:	
;main.c: 134: RC3 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	135
	
l3327:	
;main.c: 135: RC5 = 0;
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	136
	
l3329:	
;main.c: 136: RB6 = 1;
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	137
	
l3331:	
;main.c: 137: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	140
;main.c: 140: for(i = 0; i < 6; i++)
	clrf	(System_Init@i)
	line	142
	
l3337:	
;main.c: 141: {
;main.c: 142: g_slot0[i].state = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	143
;main.c: 143: g_slot0[i].type = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	144
;main.c: 144: g_slot0[i].voltage = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8)+03h)&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	145
;main.c: 145: g_slot0[i].chargeTimer = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8)+05h)&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	146
;main.c: 146: g_slot0[i].blinkTimer = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8)+07h)&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	147
;main.c: 147: g_slot0[i].blinkPhase = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8)+09h)&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	148
;main.c: 148: g_slot0[i].ledState = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8)+02h)&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	149
;main.c: 149: g_slot0[i].stableCnt = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8)+0Ah)&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	150
;main.c: 150: g_slot0[i].activatePulseCnt = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8)+0Bh)&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	152
;main.c: 152: g_slot1[i].state = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	153
;main.c: 153: g_slot1[i].type = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	154
;main.c: 154: g_slot1[i].voltage = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	155
;main.c: 155: g_slot1[i].chargeTimer = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+05h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	156
;main.c: 156: g_slot1[i].blinkTimer = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+07h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	157
;main.c: 157: g_slot1[i].blinkPhase = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+09h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	158
;main.c: 158: g_slot1[i].ledState = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	159
;main.c: 159: g_slot1[i].stableCnt = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0Ah)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	160
;main.c: 160: g_slot1[i].activatePulseCnt = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0Bh)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	140
	
l3339:	
	incf	(System_Init@i),f
	
l3341:	
	movlw	low(06h)
	subwf	(System_Init@i),w
	skipc
	goto	u3081
	goto	u3080
u3081:
	goto	l3337
u3080:
	line	164
	
l3343:	
;main.c: 161: }
;main.c: 164: _delay((unsigned long)((50)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	65
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_System_Init+0)+0),f
	u4047:
decfsz	(??_System_Init+0)+0,f
	goto	u4047
	nop2
opt asmopt_pop

	line	165
	
l3345:	
;main.c: 165: PEIE = 1;
	bsf	(94/8),(94)&7	;volatile
	line	166
	
l3347:	
;main.c: 166: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	167
	
l373:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
global __ptext2
__ptext2:	;psect for function _uart_init
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_init: []
	line	23
	
l2199:	
;uart_dbg.c: 23: TRISC &= ~0x10;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
;uart_dbg.c: 24: ANSEL2 &= ~0x10;
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
;uart_dbg.c: 25: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l502:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
global __ptext3
__ptext3:	;psect for function _AD_Init
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l2193:	
;adc_drv.c: 25: CC0CON = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
;adc_drv.c: 26: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	27
	
l2195:	
;adc_drv.c: 27: ADCON0 = 0X81;
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l2197:	
;adc_drv.c: 28: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	29
	
l475:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 319 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  v               2   17[BANK2 ] unsigned int 
;;  s               1   19[BANK2 ] unsigned char 
;;  pt              4   13[BANK2 ] unsigned long 
;;  vcc_mv          2   20[BANK2 ] unsigned int 
;;  i               1   26[BANK2 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0      14
;;      Temps:          0       2       0       0       0
;;      Totals:         0       2       0       0      14
;;Total ram usage:       16 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	319
global __ptext4
__ptext4:	;psect for function _Print_SystemStatus
psect	text4
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	319
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	324
	
l3923:	
;main.c: 321: unsigned char i;
;main.c: 322: unsigned int vcc_mv;
;main.c: 324: uart_send_string("\r\n== L1211 12CH CHARGER ==\r\n");
	movlw	(low((((STR_1)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	327
	
l3925:	
;main.c: 327: test_adc = ADC_Sample(31, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_test_adc)	;volatile
	line	328
	
l3927:	
;main.c: 328: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u3951
	goto	u3950
u3951:
	goto	l3933
u3950:
	line	330
	
l3929:	
;main.c: 329: {
;main.c: 330: unsigned long pt = (unsigned long)(4096UL*1.2*1000) / adresult;
	movf	(_adresult),w	;volatile
	movwf	(___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@pt+3)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(2+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@pt+2)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@pt+1)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@pt)^0100h

	line	331
	
l3931:	
;main.c: 331: vcc_mv = (unsigned int)pt;
	movf	(Print_SystemStatus@pt+1)^0100h,w
	movwf	(Print_SystemStatus@vcc_mv+1)^0100h
	movf	(Print_SystemStatus@pt)^0100h,w
	movwf	(Print_SystemStatus@vcc_mv)^0100h
	line	332
;main.c: 332: }
	goto	l3935
	line	334
	
l3933:	
;main.c: 333: else
;main.c: 334: vcc_mv = 5000;
	movlw	088h
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@vcc_mv)^0100h
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv)^0100h)+1
	line	336
	
l3935:	
;main.c: 336: uart_send_string("VCC=");
	movlw	(low((((STR_2)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	337
	
l3937:	
;main.c: 337: uart_send_number(vcc_mv);
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	338
	
l3939:	
;main.c: 338: uart_send_string("mV T=");
	movlw	(low((((STR_3)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	339
	
l3941:	
	movlw	019h
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	340
	
l3943:	
;main.c: 340: uart_send_string("C\r\n");
	movlw	(low((((STR_4)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	343
	
l3945:	
;main.c: 343: for(i = 0; i < 12; i++)
	bsf	status, 6	;RP1=1, select bank2
	clrf	(Print_SystemStatus@i)^0100h
	line	345
	
l3951:	
;main.c: 344: {
;main.c: 345: unsigned int v = (((i) < 6U) ? &g_slot0[(i)] : &g_slot1[(i)-6U])->voltage;
	movlw	low(06h)
	subwf	(Print_SystemStatus@i)^0100h,w
	skipc
	goto	u3961
	goto	u3960
u3961:
	goto	l3955
u3960:
	
l3953:	
	movlw	low(0Ch)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@i)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bsf	status, 6	;RP1=1, select bank2
	movwf	(_Print_SystemStatus$331)^0100h
	movlw	(0x1)
	movwf	(_Print_SystemStatus$331+1)^0100h
	goto	l3957
	
l3955:	
	movlw	low(0Ch)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@i)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	bsf	status, 6	;RP1=1, select bank2
	movwf	(_Print_SystemStatus$331)^0100h
	movlw	(0x0)
	movwf	(_Print_SystemStatus$331+1)^0100h
	
l3957:	
	movlw	low(03h)
	addwf	(_Print_SystemStatus$331)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Print_SystemStatus+0)+0
	bsf	status, 6	;RP1=1, select bank2
	movf	(_Print_SystemStatus$331+1)^0100h,w
	skipnc
	addlw	1
	bcf	status, 6	;RP1=0, select bank0
	movwf	1+((??_Print_SystemStatus+0)+0)
	movf	0+(??_Print_SystemStatus+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_Print_SystemStatus+0)+0,0
	bcf	status,7
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@v)^0100h
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)^0100h
	line	346
	
l3959:	
;main.c: 346: unsigned char s = (((i) < 6U) ? &g_slot0[(i)] : &g_slot1[(i)-6U])->state;
	movlw	low(06h)
	subwf	(Print_SystemStatus@i)^0100h,w
	skipc
	goto	u3971
	goto	u3970
u3971:
	goto	l3963
u3970:
	
l3961:	
	movlw	low(0Ch)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@i)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bsf	status, 6	;RP1=1, select bank2
	movwf	(_Print_SystemStatus$343)^0100h
	movlw	(0x1)
	movwf	(_Print_SystemStatus$343+1)^0100h
	goto	l3965
	
l3963:	
	movlw	low(0Ch)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@i)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	bsf	status, 6	;RP1=1, select bank2
	movwf	(_Print_SystemStatus$343)^0100h
	movlw	(0x0)
	movwf	(_Print_SystemStatus$343+1)^0100h
	
l3965:	
	movlw	low(01h)
	addwf	(_Print_SystemStatus$343)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Print_SystemStatus+0)+0
	bsf	status, 6	;RP1=1, select bank2
	movf	(_Print_SystemStatus$343+1)^0100h,w
	skipnc
	addlw	1
	bcf	status, 6	;RP1=0, select bank0
	movwf	1+((??_Print_SystemStatus+0)+0)
	movf	0+(??_Print_SystemStatus+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_Print_SystemStatus+0)+0,0
	bcf	status,7
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@s)^0100h
	line	349
	
l3967:	
;main.c: 349: if(i == 6) uart_send_string("\r\n");
		movlw	6
	xorwf	((Print_SystemStatus@i)^0100h),w
	btfss	status,2
	goto	u3981
	goto	u3980
u3981:
	goto	l3971
u3980:
	
l3969:	
	movlw	(low((((STR_5)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	351
	
l3971:	
;main.c: 351: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	352
	
l3973:	
;main.c: 352: uart_send_number((unsigned int)i + 1U);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@i)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	353
;main.c: 353: uart_send_char('=');
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	354
	
l3975:	
;main.c: 354: uart_send_number(v);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@v+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@v)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	357
;main.c: 357: switch(s)
	goto	l3997
	line	359
	
l3977:	
	movlw	(low((((STR_6)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3999
	line	360
	
l3979:	
	movlw	(low((((STR_7)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3999
	line	361
	
l3981:	
	movlw	(low((((STR_8)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3999
	line	362
	
l3983:	
	movlw	(low((((STR_9)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3999
	line	363
	
l3985:	
	movlw	(low((((STR_10)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3999
	line	364
	
l3987:	
	movlw	(low((((STR_11)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3999
	line	365
	
l3989:	
	movlw	(low((((STR_12)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3999
	line	366
	
l3991:	
	movlw	(low((((STR_13)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3999
	line	367
	
l3993:	
	movlw	(low((((STR_14)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3999
	line	357
	
l3997:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@s)^0100h,w
	; Switch size 1, requested type "space"
; Number of cases is 8, Range of values is 0 to 7
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           25    13 (average)
; direct_byte           32     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l3977
	xorlw	1^0	; case 1
	skipnz
	goto	l3979
	xorlw	2^1	; case 2
	skipnz
	goto	l3981
	xorlw	3^2	; case 3
	skipnz
	goto	l3983
	xorlw	4^3	; case 4
	skipnz
	goto	l3985
	xorlw	5^4	; case 5
	skipnz
	goto	l3987
	xorlw	6^5	; case 6
	skipnz
	goto	l3989
	xorlw	7^6	; case 7
	skipnz
	goto	l3991
	goto	l3993
	opt asmopt_pop

	line	343
	
l3999:	
	bsf	status, 6	;RP1=1, select bank2
	incf	(Print_SystemStatus@i)^0100h,f
	
l4001:	
	movlw	low(0Ch)
	subwf	(Print_SystemStatus@i)^0100h,w
	skipc
	goto	u3991
	goto	u3990
u3991:
	goto	l3951
u3990:
	line	370
	
l4003:	
;main.c: 369: }
;main.c: 370: uart_send_string("\r\n");
	movlw	(low((((STR_15)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	371
	
l457:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             1    wreg     PTR const unsigned char 
;;		 -> STR_31(3), STR_30(7), STR_29(2), STR_28(2), 
;;		 -> STR_27(7), STR_26(5), STR_25(10), STR_24(2), 
;;		 -> STR_23(2), STR_22(9), STR_21(7), STR_20(7), 
;;		 -> STR_19(5), STR_18(3), STR_17(10), STR_16(21), 
;;		 -> STR_15(3), STR_14(7), STR_13(7), STR_12(8), 
;;		 -> STR_11(6), STR_10(6), STR_9(7), STR_8(7), 
;;		 -> STR_7(7), STR_6(8), STR_5(3), STR_4(4), 
;;		 -> STR_3(6), STR_2(5), STR_1(29), 
;; Auto vars:     Size  Location     Type
;;  str             1   25[BANK0 ] PTR const unsigned char 
;;		 -> STR_31(3), STR_30(7), STR_29(2), STR_28(2), 
;;		 -> STR_27(7), STR_26(5), STR_25(10), STR_24(2), 
;;		 -> STR_23(2), STR_22(9), STR_21(7), STR_20(7), 
;;		 -> STR_19(5), STR_18(3), STR_17(10), STR_16(21), 
;;		 -> STR_15(3), STR_14(7), STR_13(7), STR_12(8), 
;;		 -> STR_11(6), STR_10(6), STR_9(7), STR_8(7), 
;;		 -> STR_7(7), STR_6(8), STR_5(3), STR_4(4), 
;;		 -> STR_3(6), STR_2(5), STR_1(29), 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_SystemStatus
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
global __ptext5
__ptext5:	;psect for function _uart_send_string
psect	text5
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;uart_send_string@str stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	line	63
	
l3199:	
;uart_dbg.c: 63: while(*str != '\0')
	goto	l3205
	line	64
	
l3201:	
;uart_dbg.c: 64: uart_send_char(*str++);
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringdir
	fcall	_uart_send_char
	
l3203:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(uart_send_string@str),f
	line	63
	
l3205:	
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringdir
	xorlw	0
	skipz
	goto	u2981
	goto	u2980
u2981:
	goto	l3201
u2980:
	line	65
	
l515:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 74 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2   29[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    0[BANK1 ] unsigned char [6]
;;  j               1    7[BANK1 ] unsigned char 
;;  i               1    6[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       8       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	line	74
global __ptext6
__ptext6:	;psect for function _uart_send_number
psect	text6
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	74
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 2
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	77
	
l3207:	
;uart_dbg.c: 76: unsigned char buf[6];
;uart_dbg.c: 77: unsigned char i = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(uart_send_number@i)^080h
	line	81
	
l3209:	
;uart_dbg.c: 78: unsigned char j;
;uart_dbg.c: 81: if(num == 0)
	bcf	status, 5	;RP0=0, select bank0
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u2991
	goto	u2990
u2991:
	goto	l3221
u2990:
	line	83
	
l3211:	
;uart_dbg.c: 82: {
;uart_dbg.c: 83: uart_send_char('0');
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l519
	line	90
	
l3215:	
;uart_dbg.c: 89: {
;uart_dbg.c: 90: buf[i++] = '0' + (num % 10);
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@i)^080h,w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwmod@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank1
	movwf	indf
	
l3217:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(uart_send_number@i)^080h,f
	line	91
	
l3219:	
;uart_dbg.c: 91: num /= 10;
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(uart_send_number@num+1)
	movf	(0+(?___lwdiv)),w
	movwf	(uart_send_number@num)
	line	88
	
l3221:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u3001
	goto	u3000
u3001:
	goto	l3215
u3000:
	line	95
	
l3223:	
;uart_dbg.c: 92: }
;uart_dbg.c: 95: for(j = i; j > 0; j--)
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@i)^080h,w
	movwf	(uart_send_number@j)^080h
	
l3225:	
	movf	((uart_send_number@j)^080h),w
	btfss	status,2
	goto	u3011
	goto	u3010
u3011:
	goto	l3229
u3010:
	goto	l519
	line	96
	
l3229:	
;uart_dbg.c: 96: uart_send_char(buf[j-1]);
	movf	(uart_send_number@j)^080h,w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	fcall	_uart_send_char
	line	95
	
l3231:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decf	(uart_send_number@j)^080h,f
	goto	l3225
	line	97
	
l519:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1   23[BANK0 ] unsigned char 
;;  i               1   24[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/200
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext7
__ptext7:	;psect for function _uart_send_char
psect	text7
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_char: [wreg+status,2+status,0]
;uart_send_char@c stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_char@c)
	line	38
	
l3063:	
;uart_dbg.c: 37: unsigned char i;
;uart_dbg.c: 38: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	39
;uart_dbg.c: 39: RC4 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l3065:	
;uart_dbg.c: 40: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u4057:
decfsz	(??_uart_send_char+0)+0,f
	goto	u4057
	nop2
opt asmopt_pop

	line	41
	
l3067:	
;uart_dbg.c: 41: for(i = 0; i < 8; i++)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(uart_send_char@i)
	line	42
	
l505:	
	line	43
;uart_dbg.c: 42: {
;uart_dbg.c: 43: if(c & 0x01)
	btfss	(uart_send_char@c),(0)&7
	goto	u2731
	goto	u2730
u2731:
	goto	l507
u2730:
	line	44
	
l3073:	
;uart_dbg.c: 44: RC4 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l3075
	line	45
	
l507:	
	line	46
;uart_dbg.c: 45: else
;uart_dbg.c: 46: RC4 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l3075:	
;uart_dbg.c: 47: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u4067:
decfsz	(??_uart_send_char+0)+0,f
	goto	u4067
	nop2
opt asmopt_pop

	line	48
	
l3077:	
;uart_dbg.c: 48: c >>= 1;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rrf	(uart_send_char@c),f
	line	41
	
l3079:	
	incf	(uart_send_char@i),f
	
l3081:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u2741
	goto	u2740
u2741:
	goto	l505
u2740:
	
l506:	
	line	50
;uart_dbg.c: 49: }
;uart_dbg.c: 50: RC4 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l3083:	
;uart_dbg.c: 51: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u4077:
decfsz	(??_uart_send_char+0)+0,f
	goto	u4077
	nop2
opt asmopt_pop

	line	52
	
l3085:	
;uart_dbg.c: 52: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l509:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   22[BANK0 ] unsigned int 
;;  dividend        2   24[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1   26[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   22[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       5       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext8
__ptext8:	;psect for function ___lwmod
psect	text8
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l3113:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u2791
	goto	u2790
u2791:
	goto	l3129
u2790:
	line	14
	
l3115:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l3119
	line	16
	
l3117:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l3119:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u2801
	goto	u2800
u2801:
	goto	l3117
u2800:
	line	20
	
l3121:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u2815
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u2815:
	skipc
	goto	u2811
	goto	u2810
u2811:
	goto	l3125
u2810:
	line	21
	
l3123:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l3125:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l3127:	
	decfsz	(___lwmod@counter),f
	goto	u2821
	goto	u2820
u2821:
	goto	l3121
u2820:
	line	25
	
l3129:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1098:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   22[BANK0 ] unsigned int 
;;  dividend        2   24[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2   27[BANK0 ] unsigned int 
;;  counter         1   26[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   22[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : B00/0
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       7       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext9
__ptext9:	;psect for function ___lwdiv
psect	text9
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l3087:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l3089:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u2751
	goto	u2750
u2751:
	goto	l3109
u2750:
	line	16
	
l3091:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l3095
	line	18
	
l3093:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l3095:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u2761
	goto	u2760
u2761:
	goto	l3093
u2760:
	line	22
	
l3097:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l3099:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u2775
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u2775:
	skipc
	goto	u2771
	goto	u2770
u2771:
	goto	l3105
u2770:
	line	24
	
l3101:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l3103:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l3105:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l3107:	
	decfsz	(___lwdiv@counter),f
	goto	u2781
	goto	u2780
u2781:
	goto	l3097
u2780:
	line	30
	
l3109:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l1088:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4   22[BANK0 ] unsigned long 
;;  dividend        4   26[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   30[BANK0 ] unsigned long 
;;  counter         1   34[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4   22[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      13       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext10
__ptext10:	;psect for function ___lldiv
psect	text10
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l3897:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l3899:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u3911
	goto	u3910
u3911:
	goto	l3919
u3910:
	line	16
	
l3901:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l3905
	line	18
	
l3903:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l3905:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u3921
	goto	u3920
u3921:
	goto	l3903
u3920:
	line	22
	
l3907:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l3909:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u3935
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u3935
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u3935
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u3935:
	skipc
	goto	u3931
	goto	u3930
u3931:
	goto	l3915
u3930:
	line	24
	
l3911:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l3913:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l3915:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l3917:	
	decfsz	(___lldiv@counter),f
	goto	u3941
	goto	u3940
u3941:
	goto	l3907
u3940:
	line	30
	
l3919:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l1035:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_Do_NtcRead

;; *************** function _Do_NtcRead *****************
;; Defined at:
;;		line 306 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	306
global __ptext11
__ptext11:	;psect for function _Do_NtcRead
psect	text11
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	306
	global	__size_of_Do_NtcRead
	__size_of_Do_NtcRead	equ	__end_of_Do_NtcRead-_Do_NtcRead
	
_Do_NtcRead:	
;incstack = 0
	opt	stack 4
; Regs used in _Do_NtcRead: []
	line	312
	
l430:	
	return
	opt stack 0
GLOBAL	__end_of_Do_NtcRead
	__end_of_Do_NtcRead:
	signat	_Do_NtcRead,89
	global	_Do_AdcSample

;; *************** function _Do_AdcSample *****************
;; Defined at:
;;		line 288 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  ch              1   29[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       2       0       0       0
;;      Totals:         0       7       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	line	288
global __ptext12
__ptext12:	;psect for function _Do_AdcSample
psect	text12
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	288
	global	__size_of_Do_AdcSample
	__size_of_Do_AdcSample	equ	__end_of_Do_AdcSample-_Do_AdcSample
	
_Do_AdcSample:	
;incstack = 0
	opt	stack 3
; Regs used in _Do_AdcSample: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	290
	
l3559:	
;main.c: 290: unsigned char ch = s_adcChannels[g_scanIndex];
	movf	(_g_scanIndex),w
	addlw	low((((_s_adcChannels)-__stringbase)|8000h))
	movwf	fsr0
	fcall	stringdir
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Do_AdcSample@ch)
	line	291
	
l3561:	
;main.c: 291: test_adc = ADC_Sample(ch, 7);
	movlw	low(07h)
	movwf	(ADC_Sample@adldo)
	movf	(Do_AdcSample@ch),w
	fcall	_ADC_Sample
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_test_adc)	;volatile
	line	292
	
l3563:	
;main.c: 292: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u3481
	goto	u3480
u3481:
	goto	l3573
u3480:
	line	293
	
l3565:	
;main.c: 293: (((g_scanIndex) < 6U) ? &g_slot0[(g_scanIndex)] : &g_slot1[(g_scanIndex)-6U])->voltage = adresult;
	movlw	low(06h)
	subwf	(_g_scanIndex),w
	skipc
	goto	u3491
	goto	u3490
u3491:
	goto	l3569
u3490:
	
l3567:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Do_AdcSample$299)
	movlw	(0x1)
	movwf	(_Do_AdcSample$299+1)
	goto	l3571
	
l3569:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	movwf	(_Do_AdcSample$299)
	movlw	(0x0)
	movwf	(_Do_AdcSample$299+1)
	
l3571:	
	movlw	low(03h)
	addwf	(_Do_AdcSample$299),w
	movwf	(??_Do_AdcSample+0)+0
	movf	(_Do_AdcSample$299+1),w
	skipnc
	addlw	1
	movwf	1+((??_Do_AdcSample+0)+0)
	movf	0+(??_Do_AdcSample+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_Do_AdcSample+0)+0,0
	bcf	status,7
	movf	(_adresult),w	;volatile
	movwf	indf
	incf	fsr0,f
	movf	(_adresult+1),w	;volatile
	movwf	indf
	goto	l3581
	line	295
	
l3573:	
;main.c: 294: else
;main.c: 295: (((g_scanIndex) < 6U) ? &g_slot0[(g_scanIndex)] : &g_slot1[(g_scanIndex)-6U])->voltage = 0;
	movlw	low(06h)
	subwf	(_g_scanIndex),w
	skipc
	goto	u3501
	goto	u3500
u3501:
	goto	l3577
u3500:
	
l3575:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Do_AdcSample$310)
	movlw	(0x1)
	movwf	(_Do_AdcSample$310+1)
	goto	l3579
	
l3577:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	movwf	(_Do_AdcSample$310)
	movlw	(0x0)
	movwf	(_Do_AdcSample$310+1)
	
l3579:	
	movlw	low(03h)
	addwf	(_Do_AdcSample$310),w
	movwf	(??_Do_AdcSample+0)+0
	movf	(_Do_AdcSample$310+1),w
	skipnc
	addlw	1
	movwf	1+((??_Do_AdcSample+0)+0)
	movf	0+(??_Do_AdcSample+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_Do_AdcSample+0)+0,0
	bcf	status,7
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	297
	
l3581:	
;main.c: 297: g_scanPhase = 1;
	movlw	low(01h)
	movwf	(_g_scanPhase)	;volatile
	line	298
	
l427:	
	return
	opt stack 0
GLOBAL	__end_of_Do_AdcSample
	__end_of_Do_AdcSample:
	signat	_Do_AdcSample,89
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1   22[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    1[BANK2 ] unsigned char 
;;  j               1    0[BANK2 ] unsigned char 
;;  adsum           4    3[BANK2 ] volatile unsigned long 
;;  ad_temp         2   11[BANK2 ] volatile unsigned int 
;;  admax           2    9[BANK2 ] volatile unsigned int 
;;  admin           2    7[BANK2 ] volatile unsigned int 
;;  i               1    2[BANK2 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 100/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       0       0       0      13
;;      Temps:          0       4       0       0       0
;;      Totals:         0       5       0       0      13
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Do_AdcSample
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext13
__ptext13:	;psect for function _ADC_Sample
psect	text13
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	bsf	status, 6	;RP1=1, select bank2
	movwf	(ADC_Sample@adch)^0100h
	line	51
	
l3133:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)^0100h	;volatile
	clrf	(ADC_Sample@adsum+1)^0100h	;volatile
	clrf	(ADC_Sample@adsum+2)^0100h	;volatile
	clrf	(ADC_Sample@adsum+3)^0100h	;volatile
	line	52
	
l3135:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(ADC_Sample@admin)^0100h	;volatile
	clrf	(ADC_Sample@admin+1)^0100h	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(ADC_Sample@admax)^0100h	;volatile
	clrf	(ADC_Sample@admax+1)^0100h	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)^0100h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^0100h	;volatile
	line	58
	
l3137:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u2831
	goto	u2830
u2831:
	goto	l3143
u2830:
	
l3139:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u2841
	goto	u2840
u2841:
	goto	l3143
u2840:
	line	60
	
l3141:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u4087:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u4087
	nop
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	l3145
	line	64
	
l3143:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	bcf	status, 5	;RP0=0, select bank0
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	67
	
l3145:	
;adc_drv.c: 67: if(adch & 0x10)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	btfss	(ADC_Sample@adch)^0100h,(4)&7
	goto	u2851
	goto	u2850
u2851:
	goto	l480
u2850:
	line	69
	
l3147:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l3149:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	andwf	(ADC_Sample@adch)^0100h,f
	line	71
;adc_drv.c: 71: }
	goto	l3151
	line	72
	
l480:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l3151:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrf	(ADC_Sample@i)^0100h
	line	79
	
l3157:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81 | (adch << 2));
	movf	(ADC_Sample@adch)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u2865:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u2865
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l3159:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	5
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u4097:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u4097
	nop2
opt asmopt_pop

	line	81
	
l3161:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l3163:	
;adc_drv.c: 84: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrf	(ADC_Sample@j)^0100h
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	l484
	
l485:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	decfsz	(ADC_Sample@j)^0100h,f
	goto	u2871
	goto	u2870
u2871:
	goto	l484
u2870:
	line	89
	
l3165:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	l487
	line	90
	
l484:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u2881
	goto	u2880
u2881:
	goto	l485
u2880:
	line	93
	
l3169:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(ADC_Sample@ad_temp)^0100h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^0100h	;volatile
	swapf	(ADC_Sample@ad_temp)^0100h,f	;volatile
	swapf	(ADC_Sample@ad_temp+1)^0100h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1)^0100h,f	;volatile
	movf	(ADC_Sample@ad_temp)^0100h,w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1)^0100h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp)^0100h,f	;volatile
	
l3171:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	addwf	(ADC_Sample@ad_temp)^0100h,f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1)^0100h,f	;volatile
	line	96
	
l3173:	
;adc_drv.c: 96: if(0 == admax)
	movf	((ADC_Sample@admax)^0100h),w	;volatile
iorwf	((ADC_Sample@admax+1)^0100h),w	;volatile
	btfss	status,2
	goto	u2891
	goto	u2890
u2891:
	goto	l3177
u2890:
	line	98
	
l3175:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^0100h,w	;volatile
	movwf	(ADC_Sample@admax+1)^0100h	;volatile
	movf	(ADC_Sample@ad_temp)^0100h,w	;volatile
	movwf	(ADC_Sample@admax)^0100h	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^0100h,w	;volatile
	movwf	(ADC_Sample@admin+1)^0100h	;volatile
	movf	(ADC_Sample@ad_temp)^0100h,w	;volatile
	movwf	(ADC_Sample@admin)^0100h	;volatile
	line	100
;adc_drv.c: 100: }
	goto	l490
	line	102
	
l3177:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1)^0100h,w	;volatile
	subwf	(ADC_Sample@admax+1)^0100h,w	;volatile
	skipz
	goto	u2905
	movf	(ADC_Sample@ad_temp)^0100h,w	;volatile
	subwf	(ADC_Sample@admax)^0100h,w	;volatile
u2905:
	skipnc
	goto	u2901
	goto	u2900
u2901:
	goto	l3181
u2900:
	line	103
	
l3179:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^0100h,w	;volatile
	movwf	(ADC_Sample@admax+1)^0100h	;volatile
	movf	(ADC_Sample@ad_temp)^0100h,w	;volatile
	movwf	(ADC_Sample@admax)^0100h	;volatile
	goto	l490
	line	105
	
l3181:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(ADC_Sample@admin+1)^0100h,w	;volatile
	subwf	(ADC_Sample@ad_temp+1)^0100h,w	;volatile
	skipz
	goto	u2915
	movf	(ADC_Sample@admin)^0100h,w	;volatile
	subwf	(ADC_Sample@ad_temp)^0100h,w	;volatile
u2915:
	skipnc
	goto	u2911
	goto	u2910
u2911:
	goto	l490
u2910:
	line	106
	
l3183:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^0100h,w	;volatile
	movwf	(ADC_Sample@admin+1)^0100h	;volatile
	movf	(ADC_Sample@ad_temp)^0100h,w	;volatile
	movwf	(ADC_Sample@admin)^0100h	;volatile
	line	108
	
l490:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp)^0100h,w	;volatile
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ADC_Sample@ad_temp+1)^0100h,w	;volatile
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 6	;RP1=1, select bank2
	addwf	(ADC_Sample@adsum)^0100h,f	;volatile
	bcf	status, 6	;RP1=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u2921
	bsf	status, 6	;RP1=1, select bank2
	addwf	(ADC_Sample@adsum+1)^0100h,f	;volatile
u2921:
	bcf	status, 6	;RP1=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u2922
	bsf	status, 6	;RP1=1, select bank2
	addwf	(ADC_Sample@adsum+2)^0100h,f	;volatile
u2922:
	bcf	status, 6	;RP1=0, select bank0
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u2923
	bsf	status, 6	;RP1=1, select bank2
	addwf	(ADC_Sample@adsum+3)^0100h,f	;volatile
u2923:
	bcf	status, 6	;RP1=0, select bank0
	bsf	status, 6	;RP1=1, select bank2

	line	76
	
l3185:	
	incf	(ADC_Sample@i)^0100h,f
	
l3187:	
	movlw	low(022h)
	subwf	(ADC_Sample@i)^0100h,w
	skipc
	goto	u2931
	goto	u2930
u2931:
	goto	l3157
u2930:
	line	112
	
l3189:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(ADC_Sample@admax)^0100h,w	;volatile
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ADC_Sample@admax+1)^0100h,w	;volatile
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ADC_Sample@adsum)^0100h,f	;volatile
	bcf	status, 6	;RP1=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u2945
	goto	u2946
u2945:
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ADC_Sample@adsum+1)^0100h,f	;volatile
u2946:
	bcf	status, 6	;RP1=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u2947
	goto	u2948
u2947:
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ADC_Sample@adsum+2)^0100h,f	;volatile
u2948:
	bcf	status, 6	;RP1=0, select bank0
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u2949
	goto	u2940
u2949:
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ADC_Sample@adsum+3)^0100h,f	;volatile
u2940:
	bcf	status, 6	;RP1=0, select bank0
	bsf	status, 6	;RP1=1, select bank2

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(ADC_Sample@admin)^0100h,w	;volatile
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ADC_Sample@admin+1)^0100h,w	;volatile
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ADC_Sample@adsum+3)^0100h,w	;volatile
	skipz
	goto	u2955
	bcf	status, 6	;RP1=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ADC_Sample@adsum+2)^0100h,w	;volatile
	skipz
	goto	u2955
	bcf	status, 6	;RP1=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ADC_Sample@adsum+1)^0100h,w	;volatile
	skipz
	goto	u2955
	bcf	status, 6	;RP1=0, select bank0
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ADC_Sample@adsum)^0100h,w	;volatile
u2955:
	skipc
	goto	u2951
	goto	u2950
u2951:
	goto	l494
u2950:
	line	114
	
l3191:	
;adc_drv.c: 114: adsum -= admin;
	movf	(ADC_Sample@admin)^0100h,w	;volatile
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ADC_Sample@admin+1)^0100h,w	;volatile
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ADC_Sample@adsum)^0100h,f	;volatile
	bcf	status, 6	;RP1=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u2965
	goto	u2966
u2965:
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ADC_Sample@adsum+1)^0100h,f	;volatile
u2966:
	bcf	status, 6	;RP1=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u2967
	goto	u2968
u2967:
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ADC_Sample@adsum+2)^0100h,f	;volatile
u2968:
	bcf	status, 6	;RP1=0, select bank0
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u2969
	goto	u2960
u2969:
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ADC_Sample@adsum+3)^0100h,f	;volatile
u2960:
	bcf	status, 6	;RP1=0, select bank0
	bsf	status, 6	;RP1=1, select bank2

	goto	l3193
	line	115
	
l494:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(ADC_Sample@adsum)^0100h	;volatile
	clrf	(ADC_Sample@adsum+1)^0100h	;volatile
	clrf	(ADC_Sample@adsum+2)^0100h	;volatile
	clrf	(ADC_Sample@adsum+3)^0100h	;volatile
	line	118
	
l3193:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(ADC_Sample@adsum)^0100h,w	;volatile
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_ADC_Sample+0)+0
	bsf	status, 6	;RP1=1, select bank2
	movf	(ADC_Sample@adsum+1)^0100h,w	;volatile
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ADC_Sample@adsum+2)^0100h,w	;volatile
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_ADC_Sample+0)+0+2)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ADC_Sample@adsum+3)^0100h,w	;volatile
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u2975:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u2970:
	addlw	-1
	skipz
	goto	u2975
	movf	1+(??_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
l3195:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
l487:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_ChargeProcess_Slot

;; *************** function _ChargeProcess_Slot *****************
;; Defined at:
;;		line 160 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   31[BANK0 ] unsigned char 
;;  p               2   34[BANK0 ] PTR struct .
;;		 -> g_slot1(72), g_slot0(72), 
;;  v               2   32[BANK0 ] unsigned int 
;;  tick            2    0        unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       7       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      11       0       0       0
;;Total ram usage:       11 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Detect_BatteryType
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	160
global __ptext14
__ptext14:	;psect for function _ChargeProcess_Slot
psect	text14
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	160
	global	__size_of_ChargeProcess_Slot
	__size_of_ChargeProcess_Slot	equ	__end_of_ChargeProcess_Slot-_ChargeProcess_Slot
	
_ChargeProcess_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _ChargeProcess_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;ChargeProcess_Slot@idx stored from wreg
	movwf	(ChargeProcess_Slot@idx)
	line	162
	
l3665:	
;charge_mgr.c: 162: BatterySlot_t *p = (((idx) < 6U) ? &g_slot0[(idx)] : &g_slot1[(idx)-6U]);
	movlw	low(06h)
	subwf	(ChargeProcess_Slot@idx),w
	skipc
	goto	u3561
	goto	u3560
u3561:
	goto	l3669
u3560:
	
l3667:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(ChargeProcess_Slot@p)
	movlw	(0x1)
	movwf	(ChargeProcess_Slot@p+1)
	goto	l3671
	
l3669:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	movwf	(ChargeProcess_Slot@p)
	movlw	(0x0)
	movwf	(ChargeProcess_Slot@p+1)
	line	164
	
l3671:	
;charge_mgr.c: 164: unsigned int v = p->voltage;
	movlw	low(03h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movf	indf,w
	movwf	(ChargeProcess_Slot@v)
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v+1)
	line	165
	
l3673:	
	line	167
;charge_mgr.c: 167: switch(p->state)
	goto	l3785
	line	171
	
l3675:	
;charge_mgr.c: 171: p->chargeTimer = 0;
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	172
;charge_mgr.c: 172: p->stableCnt = 0;
	movlw	low(0Ah)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	clrf	indf
	line	173
;charge_mgr.c: 173: p->state = 1;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	clrf	indf
	incf	indf,f
	line	174
;charge_mgr.c: 174: break;
	goto	l608
	line	178
	
l3677:	
;charge_mgr.c: 178: p->chargeTimer += tick;
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	179
	
l3679:	
;charge_mgr.c: 179: if(p->chargeTimer < (2 * 100))
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+2)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+2)+0+1
	movlw	0
	subwf	1+(??_ChargeProcess_Slot+2)+0,w
	movlw	0C8h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)+0,w
	skipnc
	goto	u3571
	goto	u3570
u3571:
	goto	l3683
u3570:
	goto	l608
	line	183
	
l3683:	
;charge_mgr.c: 183: p->type = Detect_BatteryType(v);
	movf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	bsf	status,7
	btfss	(ChargeProcess_Slot@p+1),0
	bcf	status,7
	movf	(ChargeProcess_Slot@v+1),w
	movwf	(Detect_BatteryType@voltage+1)
	movf	(ChargeProcess_Slot@v),w
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	movwf	indf
	line	188
	
l3685:	
;charge_mgr.c: 186: if(p->type == 4 ||
;charge_mgr.c: 187: p->type == 2 ||
;charge_mgr.c: 188: p->type == 0)
	movf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	bsf	status,7
	btfss	(ChargeProcess_Slot@p+1),0
	bcf	status,7
		movlw	4
	xorwf	(indf),w
	btfsc	status,2
	goto	u3581
	goto	u3580
u3581:
	goto	l3691
u3580:
	
l3687:	
	movf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	bsf	status,7
	btfss	(ChargeProcess_Slot@p+1),0
	bcf	status,7
		movlw	2
	xorwf	(indf),w
	btfsc	status,2
	goto	u3591
	goto	u3590
u3591:
	goto	l3691
u3590:
	
l3689:	
	movf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	bsf	status,7
	btfss	(ChargeProcess_Slot@p+1),0
	bcf	status,7
	movf	(indf),w
	btfss	status,2
	goto	u3601
	goto	u3600
u3601:
	goto	l3695
u3600:
	line	190
	
l3691:	
;charge_mgr.c: 189: {
;charge_mgr.c: 190: p->state = 7;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	low(07h)
	movwf	indf
	goto	l608
	line	199
	
l3695:	
;charge_mgr.c: 196: }
;charge_mgr.c: 199: if(v <= 228)
	movlw	0
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	0E5h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u3611
	goto	u3610
u3611:
	goto	l3699
u3610:
	line	201
	
l3697:	
;charge_mgr.c: 200: {
;charge_mgr.c: 201: p->state = 2;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	low(02h)
	movwf	indf
	line	202
;charge_mgr.c: 202: p->chargeTimer = 0;
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	203
;charge_mgr.c: 203: p->activatePulseCnt = 0;
	movlw	low(0Bh)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	clrf	indf
	line	204
;charge_mgr.c: 204: }
	goto	l608
	line	206
	
l3699:	
;charge_mgr.c: 206: else if(v < 1138)
	movlw	04h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	072h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u3621
	goto	u3620
u3621:
	goto	l3703
u3620:
	line	208
	
l3701:	
;charge_mgr.c: 207: {
;charge_mgr.c: 208: p->state = 3;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	low(03h)
	movwf	indf
	line	209
;charge_mgr.c: 209: p->chargeTimer = 0;
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	210
;charge_mgr.c: 210: }
	goto	l608
	line	214
	
l3703:	
;charge_mgr.c: 212: else
;charge_mgr.c: 213: {
;charge_mgr.c: 214: p->state = 4;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	low(04h)
	movwf	indf
	line	215
;charge_mgr.c: 215: p->chargeTimer = 0;
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l608
	line	222
	
l3705:	
;charge_mgr.c: 222: p->chargeTimer += tick;
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	224
	
l3707:	
;charge_mgr.c: 224: if(p->chargeTimer > (60 * 100))
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+2)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+2)+0+1
	movlw	017h
	subwf	1+(??_ChargeProcess_Slot+2)+0,w
	movlw	071h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)+0,w
	skipc
	goto	u3631
	goto	u3630
u3631:
	goto	l3713
u3630:
	line	226
	
l3709:	
;charge_mgr.c: 225: {
;charge_mgr.c: 226: p->state = 7;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	low(07h)
	movwf	indf
	goto	l608
	line	234
	
l3713:	
;charge_mgr.c: 232: }
;charge_mgr.c: 234: if(v > 228)
	movlw	0
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	0E5h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u3641
	goto	u3640
u3641:
	goto	l3717
u3640:
	line	236
	
l3715:	
;charge_mgr.c: 235: {
;charge_mgr.c: 236: p->state = 3;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	low(03h)
	movwf	indf
	line	237
;charge_mgr.c: 237: p->chargeTimer = 0;
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	238
;charge_mgr.c: 238: break;
	goto	l608
	line	241
	
l3717:	
;charge_mgr.c: 239: }
;charge_mgr.c: 241: if(v >= 3641)
	movlw	0Eh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	039h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u3651
	goto	u3650
u3651:
	goto	l608
u3650:
	line	243
	
l3719:	
;charge_mgr.c: 242: {
;charge_mgr.c: 243: p->state = 7;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	low(07h)
	movwf	indf
	goto	l608
	line	254
	
l3723:	
;charge_mgr.c: 254: p->chargeTimer += tick;
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	256
	
l3725:	
;charge_mgr.c: 256: if(p->chargeTimer > (300 * 100))
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+2)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+2)+0+1
	movlw	075h
	subwf	1+(??_ChargeProcess_Slot+2)+0,w
	movlw	031h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)+0,w
	skipc
	goto	u3661
	goto	u3660
u3661:
	goto	l3729
u3660:
	line	258
	
l3727:	
;charge_mgr.c: 257: {
;charge_mgr.c: 258: p->state = 7;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	low(07h)
	movwf	indf
	line	259
;charge_mgr.c: 259: break;
	goto	l608
	line	262
	
l3729:	
;charge_mgr.c: 260: }
;charge_mgr.c: 262: if(v >= 3641)
	movlw	0Eh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	039h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u3671
	goto	u3670
u3671:
	goto	l3735
u3670:
	line	264
	
l3731:	
;charge_mgr.c: 263: {
;charge_mgr.c: 264: p->state = 7;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	low(07h)
	movwf	indf
	goto	l608
	line	272
	
l3735:	
;charge_mgr.c: 270: }
;charge_mgr.c: 272: if(v >= 2276)
	movlw	08h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	0E4h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u3681
	goto	u3680
u3681:
	goto	l608
u3680:
	line	274
	
l3737:	
;charge_mgr.c: 273: {
;charge_mgr.c: 274: p->state = 4;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	low(04h)
	movwf	indf
	line	275
;charge_mgr.c: 275: p->chargeTimer = 0;
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l608
	line	281
	
l3739:	
;charge_mgr.c: 281: p->chargeTimer += tick;
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	283
	
l3741:	
;charge_mgr.c: 283: if(p->chargeTimer > (10800 * 100))
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+2)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+2)+0+1
	movlw	07Ah
	subwf	1+(??_ChargeProcess_Slot+2)+0,w
	movlw	0C1h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)+0,w
	skipc
	goto	u3691
	goto	u3690
u3691:
	goto	l3747
u3690:
	line	285
	
l3743:	
;charge_mgr.c: 284: {
;charge_mgr.c: 285: p->state = 7;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	low(07h)
	movwf	indf
	goto	l608
	line	293
	
l3747:	
;charge_mgr.c: 291: }
;charge_mgr.c: 293: if(v >= 3641)
	movlw	0Eh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	039h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u3701
	goto	u3700
u3701:
	goto	l3753
u3700:
	line	295
	
l3749:	
;charge_mgr.c: 294: {
;charge_mgr.c: 295: p->state = 7;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	low(07h)
	movwf	indf
	goto	l608
	line	303
	
l3753:	
;charge_mgr.c: 301: }
;charge_mgr.c: 303: if(v >= 3459)
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	083h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u3711
	goto	u3710
u3711:
	goto	l608
u3710:
	line	305
	
l3755:	
;charge_mgr.c: 304: {
;charge_mgr.c: 305: p->state = 5;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	low(05h)
	movwf	indf
	line	306
;charge_mgr.c: 306: p->chargeTimer = 0;
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l608
	line	312
	
l3757:	
;charge_mgr.c: 312: p->chargeTimer += tick;
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	314
	
l3759:	
;charge_mgr.c: 314: if(v >= 3641)
	movlw	0Eh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	039h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u3721
	goto	u3720
u3721:
	goto	l3765
u3720:
	line	316
	
l3761:	
;charge_mgr.c: 315: {
;charge_mgr.c: 316: p->state = 7;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	low(07h)
	movwf	indf
	goto	l608
	line	325
	
l3765:	
;charge_mgr.c: 323: }
;charge_mgr.c: 325: if(p->chargeTimer > (600 * 100))
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+2)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+2)+0+1
	movlw	0EAh
	subwf	1+(??_ChargeProcess_Slot+2)+0,w
	movlw	061h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)+0,w
	skipc
	goto	u3731
	goto	u3730
u3731:
	goto	l608
u3730:
	line	327
	
l3767:	
;charge_mgr.c: 326: {
;charge_mgr.c: 327: p->state = 6;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	low(06h)
	movwf	indf
	goto	l608
	line	334
	
l3769:	
;charge_mgr.c: 334: if(v < (3459 - 10))
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	079h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u3741
	goto	u3740
u3741:
	goto	l608
u3740:
	line	336
	
l3771:	
;charge_mgr.c: 335: {
;charge_mgr.c: 336: p->state = 4;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movlw	low(04h)
	movwf	indf
	line	337
;charge_mgr.c: 337: p->chargeTimer = 0;
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l608
	line	345
	
l3773:	
;charge_mgr.c: 344: if(v > 228 && v < 3641 &&
;charge_mgr.c: 345: p->type == 1)
	movlw	0
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	0E5h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u3751
	goto	u3750
u3751:
	goto	l608
u3750:
	
l3775:	
	movlw	0Eh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	039h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u3761
	goto	u3760
u3761:
	goto	l608
u3760:
	
l3777:	
	movf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	bsf	status,7
	btfss	(ChargeProcess_Slot@p+1),0
	bcf	status,7
		decf	(indf),w
	btfss	status,2
	goto	u3771
	goto	u3770
u3771:
	goto	l608
u3770:
	line	347
	
l3779:	
;charge_mgr.c: 346: {
;charge_mgr.c: 347: p->state = 1;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	clrf	indf
	incf	indf,f
	line	348
;charge_mgr.c: 348: p->chargeTimer = 0;
	movlw	low(05h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l608
	line	353
	
l3781:	
;charge_mgr.c: 353: p->state = 0;
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	clrf	indf
	line	354
;charge_mgr.c: 354: break;
	goto	l608
	line	167
	
l3785:	
	movlw	low(01h)
	addwf	(ChargeProcess_Slot@p),w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	(ChargeProcess_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_ChargeProcess_Slot+0)+0)
	movf	0+(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_ChargeProcess_Slot+0)+0,0
	bcf	status,7
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 8, Range of values is 0 to 7
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           25    13 (average)
; direct_byte           32     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l3675
	xorlw	1^0	; case 1
	skipnz
	goto	l3677
	xorlw	2^1	; case 2
	skipnz
	goto	l3705
	xorlw	3^2	; case 3
	skipnz
	goto	l3723
	xorlw	4^3	; case 4
	skipnz
	goto	l3739
	xorlw	5^4	; case 5
	skipnz
	goto	l3757
	xorlw	6^5	; case 6
	skipnz
	goto	l3769
	xorlw	7^6	; case 7
	skipnz
	goto	l3773
	goto	l3781
	opt asmopt_pop

	line	356
	
l608:	
	return
	opt stack 0
GLOBAL	__end_of_ChargeProcess_Slot
	__end_of_ChargeProcess_Slot:
	signat	_ChargeProcess_Slot,4217
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1   22[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1   24[BANK0 ] unsigned char 
;;  product         1   23[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 100/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;;		_Led_BlinkProcess
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext15
__ptext15:	;psect for function ___bmul
psect	text15
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplier)
	line	6
	
l3235:	
	clrf	(___bmul@product)
	line	43
	
l3237:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u3021
	goto	u3020
u3021:
	goto	l3241
u3020:
	line	44
	
l3239:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l3241:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l3243:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u3031
	goto	u3030
u3031:
	goto	l3237
u3030:
	line	50
	
l3245:	
	movf	(___bmul@product),w
	line	51
	
l769:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 99 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2   22[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	99
global __ptext16
__ptext16:	;psect for function _Detect_BatteryType
psect	text16
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	99
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	102
	
l2303:	
;charge_mgr.c: 102: if(voltage <= 91)
	movlw	0
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	05Ch
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u1651
	goto	u1650
u1651:
	goto	l2309
u1650:
	line	103
	
l2305:	
;charge_mgr.c: 103: return 4;
	movlw	low(04h)
	goto	l551
	line	106
	
l2309:	
;charge_mgr.c: 106: if(voltage <= 228)
	movlw	0
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0E5h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u1661
	goto	u1660
u1661:
	goto	l2315
u1660:
	line	107
	
l2311:	
;charge_mgr.c: 107: return 1;
	movlw	low(01h)
	goto	l551
	line	110
	
l2315:	
;charge_mgr.c: 110: if(voltage >= 2503 && voltage <= 2958)
	movlw	09h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0C7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u1671
	goto	u1670
u1671:
	goto	l2323
u1670:
	
l2317:	
	movlw	0Bh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	08Fh
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u1681
	goto	u1680
u1681:
	goto	l2323
u1680:
	line	111
	
l2319:	
;charge_mgr.c: 111: return 2;
	movlw	low(02h)
	goto	l551
	line	114
	
l2323:	
;charge_mgr.c: 114: if(voltage >= 1138 && voltage <= 3459)
	movlw	04h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	072h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u1691
	goto	u1690
u1691:
	goto	l2331
u1690:
	
l2325:	
	movlw	0Dh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	084h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u1701
	goto	u1700
u1701:
	goto	l2331
u1700:
	goto	l2311
	line	118
	
l2331:	
;charge_mgr.c: 118: if(voltage > 3459 && voltage < 3641)
	movlw	0Dh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	084h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u1711
	goto	u1710
u1711:
	goto	l2339
u1710:
	
l2333:	
	movlw	0Eh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	039h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u1721
	goto	u1720
u1721:
	goto	l2339
u1720:
	goto	l2311
	line	123
	
l2339:	
;charge_mgr.c: 123: if(voltage >= 3641 && voltage < 4095)
	movlw	0Eh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	039h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u1731
	goto	u1730
u1731:
	goto	l2347
u1730:
	
l2341:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0FFh
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u1741
	goto	u1740
u1741:
	goto	l2347
u1740:
	goto	l2311
	line	127
	
l2347:	
;charge_mgr.c: 127: return 0;
	movlw	low(0)
	line	128
	
l551:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 179 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_CCCV_Control
;;		_Charging_Control
;;		_Led_BlinkProcess
;;		_PowerOnLedSequence
;;		_Update_LED_Slot
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	179
global __ptext17
__ptext17:	;psect for function _Isr_Timer
psect	text17
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	179
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 2
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	movf	btemp+1,w
	movwf	(??_Isr_Timer+3)
	ljmp	_Isr_Timer
psect	text17
	line	182
	
i1l3787:	
;main.c: 182: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u378_21
	goto	u378_20
u378_21:
	goto	i1l383
u378_20:
	line	184
	
i1l3789:	
;main.c: 183: {
;main.c: 184: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	185
	
i1l3791:	
;main.c: 185: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	186
# 186 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text17
	line	189
	
i1l3793:	
;main.c: 189: g_pwmCounter++;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	190
	
i1l3795:	
;main.c: 190: if(g_pwmCounter >= 32)
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u379_21
	goto	u379_20
u379_21:
	goto	i1l3799
u379_20:
	line	191
	
i1l3797:	
;main.c: 191: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	194
	
i1l3799:	
;main.c: 194: if(g_pwmDuty > 0 && g_pwmCounter < g_pwmDuty)
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u380_21
	goto	u380_20
u380_21:
	goto	i1l380
u380_20:
	
i1l3801:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u381_21
	goto	u381_20
u381_21:
	goto	i1l380
u381_20:
	line	195
	
i1l3803:	
;main.c: 195: RB7 = 1;
	bsf	(55/8),(55)&7	;volatile
	goto	i1l3805
	line	196
	
i1l380:	
	line	197
;main.c: 196: else
;main.c: 197: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	200
	
i1l3805:	
;main.c: 200: if(g_powerOnPhase < 2)
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u382_21
	goto	u382_20
u382_21:
	goto	i1l3865
u382_20:
	line	202
	
i1l3807:	
;main.c: 201: {
;main.c: 202: PowerOnLedSequence();
	fcall	_PowerOnLedSequence
	goto	i1l383
	line	209
;main.c: 208: {
;main.c: 209: case 0:
	
i1l385:	
	line	211
;main.c: 211: if(!g_adcBusy && !g_doAdcSample)
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u383_21
	goto	u383_20
u383_21:
	goto	i1l383
u383_20:
	
i1l3811:	
	btfsc	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u384_21
	goto	u384_20
u384_21:
	goto	i1l383
u384_20:
	goto	i1l3815
	line	213
	
i1l389:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l402
	
i1l391:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l402
	
i1l392:	
	bsf	(51/8),(51)&7	;volatile
	goto	i1l402
	
i1l393:	
	bsf	(50/8),(50)&7	;volatile
	goto	i1l402
	
i1l394:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l402
	
i1l395:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l402
	
i1l396:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l402
	
i1l397:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l402
	
i1l398:	
	bsf	(48/8),(48)&7	;volatile
	goto	i1l402
	
i1l399:	
	bsf	(49/8),(49)&7	;volatile
	goto	i1l402
	
i1l400:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l402
	
i1l401:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l402
	
i1l3815:	
	movf	(_g_scanIndex),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l389
	xorlw	1^0	; case 1
	skipnz
	goto	i1l391
	xorlw	2^1	; case 2
	skipnz
	goto	i1l392
	xorlw	3^2	; case 3
	skipnz
	goto	i1l393
	xorlw	4^3	; case 4
	skipnz
	goto	i1l394
	xorlw	5^4	; case 5
	skipnz
	goto	i1l395
	xorlw	6^5	; case 6
	skipnz
	goto	i1l396
	xorlw	7^6	; case 7
	skipnz
	goto	i1l397
	xorlw	8^7	; case 8
	skipnz
	goto	i1l398
	xorlw	9^8	; case 9
	skipnz
	goto	i1l399
	xorlw	10^9	; case 10
	skipnz
	goto	i1l400
	xorlw	11^10	; case 11
	skipnz
	goto	i1l401
	goto	i1l402
	opt asmopt_pop

	
i1l402:	
	line	214
;main.c: 214: g_doAdcSample = 1;
	bsf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	i1l383
	line	220
	
i1l3817:	
;main.c: 220: Update_LED_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_Update_LED_Slot
	line	222
	
i1l3819:	
;main.c: 222: g_scanPhase = 2;
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_scanPhase)	;volatile
	line	223
;main.c: 223: break;
	goto	i1l383
	line	226
	
i1l3821:	
;main.c: 226: if(g_scanIndex == 0)
	movf	((_g_scanIndex)),w	;volatile
	btfss	status,2
	goto	u385_21
	goto	u385_20
u385_21:
	goto	i1l3857
u385_20:
	line	228
	
i1l3823:	
;main.c: 227: {
;main.c: 228: Charging_Control();
	fcall	_Charging_Control
	line	229
	
i1l3825:	
;main.c: 229: CCCV_Control();
	fcall	_CCCV_Control
	line	230
	
i1l3827:	
;main.c: 230: Led_BlinkProcess();
	fcall	_Led_BlinkProcess
	line	261
;main.c: 234: if(!1)
	
i1l3849:	
;main.c: 256: }
;main.c: 257: }
;main.c: 258: }
;main.c: 261: g_printTick++;
	incf	(_g_printTick),f	;volatile
	skipnz
	incf	(_g_printTick+1),f	;volatile
	line	262
	
i1l3851:	
;main.c: 262: if(g_printTick >= 100)
	movlw	0
	subwf	(_g_printTick+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_printTick),w	;volatile
	skipc
	goto	u386_21
	goto	u386_20
u386_21:
	goto	i1l3857
u386_20:
	line	264
	
i1l3853:	
;main.c: 263: {
;main.c: 264: g_printTick = 0;
	clrf	(_g_printTick)	;volatile
	clrf	(_g_printTick+1)	;volatile
	line	265
	
i1l3855:	
;main.c: 265: g_printFlag = 1;
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	270
	
i1l3857:	
;main.c: 266: }
;main.c: 267: }
;main.c: 270: if(++g_scanIndex >= 12)
	movlw	low(0Ch)
	incf	(_g_scanIndex),f	;volatile
	subwf	((_g_scanIndex)),w	;volatile
	skipc
	goto	u387_21
	goto	u387_20
u387_21:
	goto	i1l413
u387_20:
	line	271
	
i1l3859:	
;main.c: 271: g_scanIndex = 0;
	clrf	(_g_scanIndex)	;volatile
	
i1l413:	
	line	272
;main.c: 272: g_scanPhase = 0;
	clrf	(_g_scanPhase)	;volatile
	line	273
;main.c: 273: break;
	goto	i1l383
	line	207
	
i1l3865:	
	movf	(_g_scanPhase),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 2
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           17     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l385
	xorlw	1^0	; case 1
	skipnz
	goto	i1l3817
	xorlw	2^1	; case 2
	skipnz
	goto	i1l3821
	goto	i1l413
	opt asmopt_pop

	line	280
	
i1l383:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(??_Isr_Timer+3),w
	movwf	btemp+1
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^00h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	_Update_LED_Slot

;; *************** function _Update_LED_Slot *****************
;; Defined at:
;;		line 30 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    5[COMMON] unsigned char 
;;  p               2    6[COMMON] PTR struct .
;;		 -> g_slot1(72), g_slot0(72), 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         3       0       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	30
global __ptext18
__ptext18:	;psect for function _Update_LED_Slot
psect	text18
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	30
	global	__size_of_Update_LED_Slot
	__size_of_Update_LED_Slot	equ	__end_of_Update_LED_Slot-_Update_LED_Slot
	
_Update_LED_Slot:	
;incstack = 0
	opt	stack 2
; Regs used in _Update_LED_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Update_LED_Slot@idx stored from wreg
	movwf	(Update_LED_Slot@idx)
	line	32
	
i1l3349:	
;led.c: 32: BatterySlot_t *p = (((idx) < 6U) ? &g_slot0[(idx)] : &g_slot1[(idx)-6U]);
	movlw	low(06h)
	subwf	(Update_LED_Slot@idx),w
	skipc
	goto	u309_21
	goto	u309_20
u309_21:
	goto	i1l3353
u309_20:
	
i1l3351:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Update_LED_Slot@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(Update_LED_Slot@p)
	movlw	(0x1)
	movwf	(Update_LED_Slot@p+1)
	goto	i1l3367
	
i1l3353:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Update_LED_Slot@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	movwf	(Update_LED_Slot@p)
	movlw	(0x0)
	movwf	(Update_LED_Slot@p+1)
	goto	i1l3367
	line	37
	
i1l3355:	
;led.c: 37: p->ledState = 0;
	movlw	low(02h)
	addwf	(Update_LED_Slot@p),w
	movwf	(??_Update_LED_Slot+0)+0
	movf	(Update_LED_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_Update_LED_Slot+0)+0)
	movf	0+(??_Update_LED_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_Update_LED_Slot+0)+0,0
	bcf	status,7
	clrf	indf
	line	38
;led.c: 38: break;
	goto	i1l710
	line	42
	
i1l705:	
	line	44
	
i1l3357:	
;led.c: 40: case 2:
;led.c: 41: case 3:
;led.c: 42: case 4:
;led.c: 43: case 5:
;led.c: 44: p->ledState = 1;
	movlw	low(02h)
	addwf	(Update_LED_Slot@p),w
	movwf	(??_Update_LED_Slot+0)+0
	movf	(Update_LED_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_Update_LED_Slot+0)+0)
	movf	0+(??_Update_LED_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_Update_LED_Slot+0)+0,0
	bcf	status,7
	clrf	indf
	incf	indf,f
	line	45
;led.c: 45: break;
	goto	i1l710
	line	47
	
i1l3359:	
;led.c: 47: p->ledState = 2;
	movlw	low(02h)
	addwf	(Update_LED_Slot@p),w
	movwf	(??_Update_LED_Slot+0)+0
	movf	(Update_LED_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_Update_LED_Slot+0)+0)
	movf	0+(??_Update_LED_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_Update_LED_Slot+0)+0,0
	bcf	status,7
	movlw	low(02h)
	movwf	indf
	line	48
;led.c: 48: break;
	goto	i1l710
	line	50
	
i1l3361:	
;led.c: 50: p->ledState = 3;
	movlw	low(02h)
	addwf	(Update_LED_Slot@p),w
	movwf	(??_Update_LED_Slot+0)+0
	movf	(Update_LED_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_Update_LED_Slot+0)+0)
	movf	0+(??_Update_LED_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_Update_LED_Slot+0)+0,0
	bcf	status,7
	movlw	low(03h)
	movwf	indf
	line	51
;led.c: 51: break;
	goto	i1l710
	line	53
	
i1l3363:	
;led.c: 53: p->ledState = 0;
	movlw	low(02h)
	addwf	(Update_LED_Slot@p),w
	movwf	(??_Update_LED_Slot+0)+0
	movf	(Update_LED_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_Update_LED_Slot+0)+0)
	movf	0+(??_Update_LED_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_Update_LED_Slot+0)+0,0
	bcf	status,7
	clrf	indf
	line	54
;led.c: 54: break;
	goto	i1l710
	line	34
	
i1l3367:	
	movlw	low(01h)
	addwf	(Update_LED_Slot@p),w
	movwf	(??_Update_LED_Slot+0)+0
	movf	(Update_LED_Slot@p+1),w
	skipnc
	addlw	1
	movwf	1+((??_Update_LED_Slot+0)+0)
	movf	0+(??_Update_LED_Slot+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_Update_LED_Slot+0)+0,0
	bcf	status,7
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 8, Range of values is 0 to 7
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           25    13 (average)
; direct_byte           32     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l3355
	xorlw	1^0	; case 1
	skipnz
	goto	i1l705
	xorlw	2^1	; case 2
	skipnz
	goto	i1l3357
	xorlw	3^2	; case 3
	skipnz
	goto	i1l3357
	xorlw	4^3	; case 4
	skipnz
	goto	i1l3357
	xorlw	5^4	; case 5
	skipnz
	goto	i1l3357
	xorlw	6^5	; case 6
	skipnz
	goto	i1l3359
	xorlw	7^6	; case 7
	skipnz
	goto	i1l3361
	goto	i1l3363
	opt asmopt_pop

	line	56
	
i1l710:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Slot
	__end_of_Update_LED_Slot:
	signat	_Update_LED_Slot,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 93 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=0
	line	93
global __ptext19
__ptext19:	;psect for function _PowerOnLedSequence
psect	text19
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	93
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	95
	
i1l2497:	
;led.c: 95: g_powerOnTimer++;
	incf	(_g_powerOnTimer),f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1),f	;volatile
	line	97
	
i1l2499:	
;led.c: 97: if(g_powerOnPhase == 0)
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u187_21
	goto	u187_20
u187_21:
	goto	i1l2507
u187_20:
	line	100
	
i1l2501:	
;led.c: 98: {
;led.c: 100: if(g_powerOnTimer >= 100)
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u188_21
	goto	u188_20
u188_21:
	goto	i1l745
u188_20:
	line	102
	
i1l2503:	
;led.c: 101: {
;led.c: 102: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	103
	
i1l2505:	
;led.c: 103: g_powerOnPhase = 1;
	movlw	low(01h)
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l745
	line	106
	
i1l2507:	
;led.c: 106: else if(g_powerOnPhase == 1)
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u189_21
	goto	u189_20
u189_21:
	goto	i1l745
u189_20:
	line	109
	
i1l2509:	
;led.c: 107: {
;led.c: 109: if(g_powerOnTimer >= 100)
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u190_21
	goto	u190_20
u190_21:
	goto	i1l745
u190_20:
	line	111
	
i1l2511:	
;led.c: 110: {
;led.c: 111: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	112
	
i1l2513:	
;led.c: 112: g_powerOnPhase = 2;
	movlw	low(02h)
	movwf	(_g_powerOnPhase)	;volatile
	line	116
	
i1l745:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
	global	_Led_BlinkProcess

;; *************** function _Led_BlinkProcess *****************
;; Defined at:
;;		line 66 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   10[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      11       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         4      11       0       0       0
;;Total ram usage:       15 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	line	66
global __ptext20
__ptext20:	;psect for function _Led_BlinkProcess
psect	text20
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	66
	global	__size_of_Led_BlinkProcess
	__size_of_Led_BlinkProcess	equ	__end_of_Led_BlinkProcess-_Led_BlinkProcess
	
_Led_BlinkProcess:	
;incstack = 0
	opt	stack 2
; Regs used in _Led_BlinkProcess: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	69
	
i1l3509:	
;led.c: 68: unsigned char i;
;led.c: 69: for(i = 0; i < 12; i++)
	clrf	(Led_BlinkProcess@i)
	line	72
	
i1l3515:	
;led.c: 70: {
;led.c: 72: if((((i) < 6U) ? &g_slot0[(i)] : &g_slot1[(i)-6U])->ledState == 3)
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u340_21
	goto	u340_20
u340_21:
	goto	i1l3519
u340_20:
	
i1l3517:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Led_BlinkProcess$520)
	movlw	(0x1)
	movwf	(_Led_BlinkProcess$520+1)
	goto	i1l3521
	
i1l3519:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Led_BlinkProcess$520)
	movlw	(0x0)
	movwf	(_Led_BlinkProcess$520+1)
	
i1l3521:	
	movlw	low(02h)
	addwf	(_Led_BlinkProcess$520),w
	movwf	(??_Led_BlinkProcess+0)+0
	movf	(_Led_BlinkProcess$520+1),w
	skipnc
	addlw	1
	movwf	1+((??_Led_BlinkProcess+0)+0)
	movf	0+(??_Led_BlinkProcess+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_Led_BlinkProcess+0)+0,0
	bcf	status,7
		movlw	3
	xorwf	(indf),w
	btfss	status,2
	goto	u341_21
	goto	u341_20
u341_21:
	goto	i1l3555
u341_20:
	line	74
	
i1l3523:	
;led.c: 73: {
;led.c: 74: (((i) < 6U) ? &g_slot0[(i)] : &g_slot1[(i)-6U])->blinkTimer++;
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u342_21
	goto	u342_20
u342_21:
	goto	i1l3527
u342_20:
	
i1l3525:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Led_BlinkProcess$531)
	movlw	(0x1)
	movwf	(_Led_BlinkProcess$531+1)
	goto	i1l3529
	
i1l3527:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Led_BlinkProcess$531)
	movlw	(0x0)
	movwf	(_Led_BlinkProcess$531+1)
	
i1l3529:	
	movlw	low(07h)
	addwf	(_Led_BlinkProcess$531),w
	movwf	(??_Led_BlinkProcess+0)+0
	movf	(_Led_BlinkProcess$531+1),w
	skipnc
	addlw	1
	movwf	1+((??_Led_BlinkProcess+0)+0)
	movf	0+(??_Led_BlinkProcess+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_Led_BlinkProcess+0)+0,0
	bcf	status,7
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	76
	
i1l3531:	
;led.c: 76: if((((i) < 6U) ? &g_slot0[(i)] : &g_slot1[(i)-6U])->blinkTimer >= (100 / 2))
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u343_21
	goto	u343_20
u343_21:
	goto	i1l3535
u343_20:
	
i1l3533:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Led_BlinkProcess$542)
	movlw	(0x1)
	movwf	(_Led_BlinkProcess$542+1)
	goto	i1l3537
	
i1l3535:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Led_BlinkProcess$542)
	movlw	(0x0)
	movwf	(_Led_BlinkProcess$542+1)
	
i1l3537:	
	movlw	low(07h)
	addwf	(_Led_BlinkProcess$542),w
	movwf	(??_Led_BlinkProcess+0)+0
	movf	(_Led_BlinkProcess$542+1),w
	skipnc
	addlw	1
	movwf	1+((??_Led_BlinkProcess+0)+0)
	movf	0+(??_Led_BlinkProcess+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_Led_BlinkProcess+0)+0,0
	bcf	status,7
	movf	indf,w
	movwf	(??_Led_BlinkProcess+2)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_BlinkProcess+2)+0+1
	movlw	0
	subwf	1+(??_Led_BlinkProcess+2)+0,w
	movlw	032h
	skipnz
	subwf	0+(??_Led_BlinkProcess+2)+0,w
	skipc
	goto	u344_21
	goto	u344_20
u344_21:
	goto	i1l3555
u344_20:
	line	78
	
i1l3539:	
;led.c: 77: {
;led.c: 78: (((i) < 6U) ? &g_slot0[(i)] : &g_slot1[(i)-6U])->blinkTimer = 0;
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u345_21
	goto	u345_20
u345_21:
	goto	i1l3543
u345_20:
	
i1l3541:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Led_BlinkProcess$553)
	movlw	(0x1)
	movwf	(_Led_BlinkProcess$553+1)
	goto	i1l3545
	
i1l3543:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Led_BlinkProcess$553)
	movlw	(0x0)
	movwf	(_Led_BlinkProcess$553+1)
	
i1l3545:	
	movlw	low(07h)
	addwf	(_Led_BlinkProcess$553),w
	movwf	(??_Led_BlinkProcess+0)+0
	movf	(_Led_BlinkProcess$553+1),w
	skipnc
	addlw	1
	movwf	1+((??_Led_BlinkProcess+0)+0)
	movf	0+(??_Led_BlinkProcess+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_Led_BlinkProcess+0)+0,0
	bcf	status,7
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	79
	
i1l3547:	
;led.c: 79: (((i) < 6U) ? &g_slot0[(i)] : &g_slot1[(i)-6U])->blinkPhase ^= 1;
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u346_21
	goto	u346_20
u346_21:
	goto	i1l3551
u346_20:
	
i1l3549:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Led_BlinkProcess$564)
	movlw	(0x1)
	movwf	(_Led_BlinkProcess$564+1)
	goto	i1l3553
	
i1l3551:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Led_BlinkProcess$564)
	movlw	(0x0)
	movwf	(_Led_BlinkProcess$564+1)
	
i1l3553:	
	movlw	low(09h)
	addwf	(_Led_BlinkProcess$564),w
	movwf	(??_Led_BlinkProcess+0)+0
	movf	(_Led_BlinkProcess$564+1),w
	skipnc
	addlw	1
	movwf	1+((??_Led_BlinkProcess+0)+0)
	movf	0+(??_Led_BlinkProcess+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_Led_BlinkProcess+0)+0,0
	bcf	status,7
	movlw	low(01h)
	xorwf	indf,f
	line	69
	
i1l3555:	
	incf	(Led_BlinkProcess@i),f
	
i1l3557:	
	movlw	low(0Ch)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u347_21
	goto	u347_20
u347_21:
	goto	i1l3515
u347_20:
	line	83
	
i1l737:	
	return
	opt stack 0
GLOBAL	__end_of_Led_BlinkProcess
	__end_of_Led_BlinkProcess:
	signat	_Led_BlinkProcess,89
	global	_Charging_Control

;; *************** function _Charging_Control *****************
;; Defined at:
;;		line 370 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    9[COMMON] unsigned char 
;;  i               1   10[COMMON] unsigned char 
;;  chargeB7_12     1    8[COMMON] unsigned char 
;;  chargeB1_6      1    7[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 100/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         6       0       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	370
global __ptext21
__ptext21:	;psect for function _Charging_Control
psect	text21
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	370
	global	__size_of_Charging_Control
	__size_of_Charging_Control	equ	__end_of_Charging_Control-_Charging_Control
	
_Charging_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _Charging_Control: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	373
	
i1l3369:	
;charge_mgr.c: 372: unsigned char i;
;charge_mgr.c: 373: unsigned char chargeB1_6 = 0;
	clrf	(Charging_Control@chargeB1_6)
	line	374
;charge_mgr.c: 374: unsigned char chargeB7_12 = 0;
	clrf	(Charging_Control@chargeB7_12)
	line	377
	
i1l3371:	
;charge_mgr.c: 377: if(g_tempProtect)
	movf	((_g_tempProtect)),w
	btfsc	status,2
	goto	u310_21
	goto	u310_20
u310_21:
	goto	i1l3377
u310_20:
	line	379
;charge_mgr.c: 378: {
;charge_mgr.c: 379: do { RA0=1; RA1=1; RB3=1; RB2=1; RA3=1; RA2=1; RD1=1; RD3=1; RB0=1; RB1=1; RD2=1; RD0=1; } while(0);
	
i1l612:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	bsf	(1073/8)^080h,(1073)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	bsf	(50/8),(50)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	bsf	(1074/8)^080h,(1074)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	bsf	(49/8),(49)&7	;volatile
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	
i1l613:	
	line	380
;charge_mgr.c: 380: RC3 = 0;
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	381
;charge_mgr.c: 381: RC5 = 0;
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	382
	
i1l3373:	
;charge_mgr.c: 382: g_pwmDuty = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	goto	i1l614
	line	387
	
i1l3377:	
;charge_mgr.c: 384: }
;charge_mgr.c: 387: for(i = 0; i < 12; i++)
	clrf	(Charging_Control@i)
	line	389
	
i1l3383:	
;charge_mgr.c: 388: {
;charge_mgr.c: 389: unsigned char s = (((i) < 6U) ? &g_slot0[(i)] : &g_slot1[(i)-6U])->state;
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipc
	goto	u311_21
	goto	u311_20
u311_21:
	goto	i1l3387
u311_20:
	
i1l3385:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Charging_Control$452)
	movlw	(0x1)
	movwf	(_Charging_Control$452+1)
	goto	i1l3389
	
i1l3387:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	movwf	(_Charging_Control$452)
	movlw	(0x0)
	movwf	(_Charging_Control$452+1)
	
i1l3389:	
	movlw	low(01h)
	addwf	(_Charging_Control$452),w
	movwf	(??_Charging_Control+0)+0
	movf	(_Charging_Control$452+1),w
	skipnc
	addlw	1
	movwf	1+((??_Charging_Control+0)+0)
	movf	0+(??_Charging_Control+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_Charging_Control+0)+0,0
	bcf	status,7
	movf	indf,w
	movwf	(Charging_Control@s)
	line	393
	
i1l3391:	
;charge_mgr.c: 392: if(s == 2 || s == 3 ||
;charge_mgr.c: 393: s == 4 || s == 5)
		movlw	2
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u312_21
	goto	u312_20
u312_21:
	goto	i1l3401
u312_20:
	
i1l3393:	
		movlw	3
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u313_21
	goto	u313_20
u313_21:
	goto	i1l3401
u313_20:
	
i1l3395:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u314_21
	goto	u314_20
u314_21:
	goto	i1l3401
u314_20:
	
i1l3397:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u315_21
	goto	u315_20
u315_21:
	goto	i1l3409
u315_20:
	goto	i1l3401
	line	395
	
i1l626:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l3403
	
i1l628:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l3403
	
i1l629:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l3403
	
i1l630:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l3403
	
i1l631:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l3403
	
i1l632:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l3403
	
i1l633:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l3403
	
i1l634:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l3403
	
i1l635:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l3403
	
i1l636:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l3403
	
i1l637:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l3403
	
i1l638:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l3403
	
i1l3401:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l626
	xorlw	1^0	; case 1
	skipnz
	goto	i1l628
	xorlw	2^1	; case 2
	skipnz
	goto	i1l629
	xorlw	3^2	; case 3
	skipnz
	goto	i1l630
	xorlw	4^3	; case 4
	skipnz
	goto	i1l631
	xorlw	5^4	; case 5
	skipnz
	goto	i1l632
	xorlw	6^5	; case 6
	skipnz
	goto	i1l633
	xorlw	7^6	; case 7
	skipnz
	goto	i1l634
	xorlw	8^7	; case 8
	skipnz
	goto	i1l635
	xorlw	9^8	; case 9
	skipnz
	goto	i1l636
	xorlw	10^9	; case 10
	skipnz
	goto	i1l637
	xorlw	11^10	; case 11
	skipnz
	goto	i1l638
	goto	i1l3403
	opt asmopt_pop

	line	398
	
i1l3403:	
;charge_mgr.c: 398: if(i < 6)
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipnc
	goto	u316_21
	goto	u316_20
u316_21:
	goto	i1l640
u316_20:
	line	399
	
i1l3405:	
;charge_mgr.c: 399: chargeB1_6 = 1;
	clrf	(Charging_Control@chargeB1_6)
	incf	(Charging_Control@chargeB1_6),f
	goto	i1l3411
	line	400
	
i1l640:	
	line	401
;charge_mgr.c: 400: else
;charge_mgr.c: 401: chargeB7_12 = 1;
	clrf	(Charging_Control@chargeB7_12)
	incf	(Charging_Control@chargeB7_12),f
	goto	i1l3411
	line	405
	
i1l645:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l3411
	
i1l647:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l3411
	
i1l648:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	i1l3411
	
i1l649:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	i1l3411
	
i1l650:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l3411
	
i1l651:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l3411
	
i1l652:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l3411
	
i1l653:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l3411
	
i1l654:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	i1l3411
	
i1l655:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	i1l3411
	
i1l656:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l3411
	
i1l657:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l3411
	
i1l3409:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l645
	xorlw	1^0	; case 1
	skipnz
	goto	i1l647
	xorlw	2^1	; case 2
	skipnz
	goto	i1l648
	xorlw	3^2	; case 3
	skipnz
	goto	i1l649
	xorlw	4^3	; case 4
	skipnz
	goto	i1l650
	xorlw	5^4	; case 5
	skipnz
	goto	i1l651
	xorlw	6^5	; case 6
	skipnz
	goto	i1l652
	xorlw	7^6	; case 7
	skipnz
	goto	i1l653
	xorlw	8^7	; case 8
	skipnz
	goto	i1l654
	xorlw	9^8	; case 9
	skipnz
	goto	i1l655
	xorlw	10^9	; case 10
	skipnz
	goto	i1l656
	xorlw	11^10	; case 11
	skipnz
	goto	i1l657
	goto	i1l3411
	opt asmopt_pop

	line	387
	
i1l3411:	
	incf	(Charging_Control@i),f
	
i1l3413:	
	movlw	low(0Ch)
	subwf	(Charging_Control@i),w
	skipc
	goto	u317_21
	goto	u317_20
u317_21:
	goto	i1l3383
u317_20:
	
i1l616:	
	line	410
;charge_mgr.c: 406: }
;charge_mgr.c: 407: }
;charge_mgr.c: 410: RC3 = chargeB1_6;
	btfsc	(Charging_Control@chargeB1_6),0
	goto	u318_21
	goto	u318_20
	
u318_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2099/8)^0100h,(2099)&7	;volatile
	goto	u319_24
u318_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
u319_24:
	line	411
;charge_mgr.c: 411: RC5 = chargeB7_12;
	btfsc	(Charging_Control@chargeB7_12),0
	goto	u320_21
	goto	u320_20
	
u320_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u321_24
u320_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u321_24:
	line	414
	
i1l614:	
	return
	opt stack 0
GLOBAL	__end_of_Charging_Control
	__end_of_Charging_Control:
	signat	_Charging_Control,89
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 432 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1   16[BANK0 ] unsigned char 
;;  duty            2   14[BANK0 ] int 
;;  error           2   12[BANK0 ] int 
;;  adjust          2    0[BANK0 ] int 
;;  maxV            2   10[BANK0 ] unsigned int 
;;  i               1   17[BANK0 ] unsigned char 
;;  cvCount         1    9[BANK0 ] unsigned char 
;;  hasCharging     1    8[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 100/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         4      18       0       0       0
;;Total ram usage:       22 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___awdiv
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	line	432
global __ptext22
__ptext22:	;psect for function _CCCV_Control
psect	text22
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	432
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	435
	
i1l3415:	
;charge_mgr.c: 434: unsigned char i;
;charge_mgr.c: 435: unsigned char hasCharging = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	436
;charge_mgr.c: 436: unsigned int maxV = 0;
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	437
;charge_mgr.c: 437: unsigned char cvCount = 0;
	clrf	(CCCV_Control@cvCount)
	line	440
;charge_mgr.c: 440: for(i = 0; i < 12; i++)
	clrf	(CCCV_Control@i)
	line	442
	
i1l3421:	
;charge_mgr.c: 441: {
;charge_mgr.c: 442: unsigned char s = (((i) < 6U) ? &g_slot0[(i)] : &g_slot1[(i)-6U])->state;
	movlw	low(06h)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u322_21
	goto	u322_20
u322_21:
	goto	i1l3425
u322_20:
	
i1l3423:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$469)
	movlw	(0x1)
	movwf	(_CCCV_Control$469+1)
	goto	i1l3427
	
i1l3425:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$469)
	movlw	(0x0)
	movwf	(_CCCV_Control$469+1)
	
i1l3427:	
	movlw	low(01h)
	addwf	(_CCCV_Control$469),w
	movwf	(??_CCCV_Control+0)+0
	movf	(_CCCV_Control$469+1),w
	skipnc
	addlw	1
	movwf	1+((??_CCCV_Control+0)+0)
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_CCCV_Control+0)+0,0
	bcf	status,7
	movf	indf,w
	movwf	(CCCV_Control@s)
	line	445
	
i1l3429:	
;charge_mgr.c: 444: if(s == 2 || s == 3 ||
;charge_mgr.c: 445: s == 4 || s == 5)
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u323_21
	goto	u323_20
u323_21:
	goto	i1l669
u323_20:
	
i1l3431:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u324_21
	goto	u324_20
u324_21:
	goto	i1l669
u324_20:
	
i1l3433:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u325_21
	goto	u325_20
u325_21:
	goto	i1l669
u325_20:
	
i1l3435:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u326_21
	goto	u326_20
u326_21:
	goto	i1l667
u326_20:
	
i1l669:	
	line	447
;charge_mgr.c: 446: {
;charge_mgr.c: 447: hasCharging = 1;
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	448
	
i1l3437:	
;charge_mgr.c: 448: if((((i) < 6U) ? &g_slot0[(i)] : &g_slot1[(i)-6U])->voltage > maxV)
	movlw	low(06h)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u327_21
	goto	u327_20
u327_21:
	goto	i1l3441
u327_20:
	
i1l3439:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$480)
	movlw	(0x1)
	movwf	(_CCCV_Control$480+1)
	goto	i1l3443
	
i1l3441:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$480)
	movlw	(0x0)
	movwf	(_CCCV_Control$480+1)
	
i1l3443:	
	movlw	low(03h)
	addwf	(_CCCV_Control$480),w
	movwf	(??_CCCV_Control+0)+0
	movf	(_CCCV_Control$480+1),w
	skipnc
	addlw	1
	movwf	1+((??_CCCV_Control+0)+0)
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_CCCV_Control+0)+0,0
	bcf	status,7
	movf	indf,w
	movwf	(??_CCCV_Control+2)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_CCCV_Control+2)+0+1
	movf	1+(??_CCCV_Control+2)+0,w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u328_25
	movf	0+(??_CCCV_Control+2)+0,w
	subwf	(CCCV_Control@maxV),w
u328_25:
	skipnc
	goto	u328_21
	goto	u328_20
u328_21:
	goto	i1l3453
u328_20:
	line	449
	
i1l3445:	
;charge_mgr.c: 449: maxV = (((i) < 6U) ? &g_slot0[(i)] : &g_slot1[(i)-6U])->voltage;
	movlw	low(06h)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u329_21
	goto	u329_20
u329_21:
	goto	i1l3449
u329_20:
	
i1l3447:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$491)
	movlw	(0x1)
	movwf	(_CCCV_Control$491+1)
	goto	i1l3451
	
i1l3449:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$491)
	movlw	(0x0)
	movwf	(_CCCV_Control$491+1)
	
i1l3451:	
	movlw	low(03h)
	addwf	(_CCCV_Control$491),w
	movwf	(??_CCCV_Control+0)+0
	movf	(_CCCV_Control$491+1),w
	skipnc
	addlw	1
	movwf	1+((??_CCCV_Control+0)+0)
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_CCCV_Control+0)+0,0
	bcf	status,7
	movf	indf,w
	movwf	(CCCV_Control@maxV)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@maxV+1)
	line	450
	
i1l3453:	
;charge_mgr.c: 450: if(s == 5)
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u330_21
	goto	u330_20
u330_21:
	goto	i1l667
u330_20:
	line	451
	
i1l3455:	
;charge_mgr.c: 451: cvCount++;
	incf	(CCCV_Control@cvCount),f
	line	452
	
i1l667:	
	line	440
	incf	(CCCV_Control@i),f
	
i1l3457:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u331_21
	goto	u331_20
u331_21:
	goto	i1l3421
u331_20:
	line	456
	
i1l3459:	
;charge_mgr.c: 452: }
;charge_mgr.c: 453: }
;charge_mgr.c: 456: if(!hasCharging)
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u332_21
	goto	u332_20
u332_21:
	goto	i1l3465
u332_20:
	line	458
	
i1l3461:	
;charge_mgr.c: 457: {
;charge_mgr.c: 458: g_pwmDuty = 0;
	clrf	(_g_pwmDuty)	;volatile
	line	459
;charge_mgr.c: 459: g_cvIntegral = 0;
	clrf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l681
	line	466
	
i1l3465:	
;charge_mgr.c: 461: }
;charge_mgr.c: 466: if(cvCount == 0)
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u333_21
	goto	u333_20
u333_21:
	goto	i1l3483
u333_20:
	line	468
	
i1l3467:	
;charge_mgr.c: 467: {
;charge_mgr.c: 468: if(g_pwmDuty < 25)
	movlw	low(019h)
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u334_21
	goto	u334_20
u334_21:
	goto	i1l3475
u334_20:
	line	471
	
i1l3469:	
;charge_mgr.c: 469: {
;charge_mgr.c: 471: g_pwmDuty += 3;
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	472
	
i1l3471:	
;charge_mgr.c: 472: if(g_pwmDuty > 25)
	movlw	low(01Ah)
	subwf	(_g_pwmDuty),w	;volatile
	skipc
	goto	u335_21
	goto	u335_20
u335_21:
	goto	i1l681
u335_20:
	line	473
	
i1l3473:	
;charge_mgr.c: 473: g_pwmDuty = 25;
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l681
	line	475
	
i1l3475:	
	goto	i1l3473
	line	494
	
i1l3483:	
;charge_mgr.c: 486: }
;charge_mgr.c: 493: {
;charge_mgr.c: 494: int error = (int)(3459) - (int)(maxV);
	movlw	083h
	movwf	(CCCV_Control@error)
	movlw	0Dh
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	497
;charge_mgr.c: 497: g_cvIntegral += error * 1;
	movf	(CCCV_Control@error),w
	addwf	(_g_cvIntegral),f
	skipnc
	incf	(_g_cvIntegral+1),f
	movf	(CCCV_Control@error+1),w
	addwf	(_g_cvIntegral+1),f
	line	498
	
i1l3485:	
;charge_mgr.c: 498: if(g_cvIntegral > 200)
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u336_25
	movlw	0C9h
	subwf	(_g_cvIntegral),w
u336_25:

	skipc
	goto	u336_21
	goto	u336_20
u336_21:
	goto	i1l3489
u336_20:
	line	499
	
i1l3487:	
;charge_mgr.c: 499: g_cvIntegral = 200;
	movlw	0C8h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l3493
	line	500
	
i1l3489:	
;charge_mgr.c: 500: else if(g_cvIntegral < -200)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u337_25
	movlw	038h
	subwf	(_g_cvIntegral),w
u337_25:

	skipnc
	goto	u337_21
	goto	u337_20
u337_21:
	goto	i1l3493
u337_20:
	line	501
	
i1l3491:	
;charge_mgr.c: 501: g_cvIntegral = -200;
	movlw	038h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	movlw	0FFh
	movwf	((_g_cvIntegral))+1
	line	504
	
i1l3493:	
;charge_mgr.c: 504: int adjust = (error * 4 + g_cvIntegral) / 8;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	movf	(_g_cvIntegral),w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1),w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	505
	
i1l3495:	
;charge_mgr.c: 505: int duty = (int)g_pwmDuty + adjust;
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
i1l3497:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	508
	
i1l3499:	
;charge_mgr.c: 508: if(duty > 32) duty = 32;
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u338_25
	movlw	021h
	subwf	(CCCV_Control@duty),w
u338_25:

	skipc
	goto	u338_21
	goto	u338_20
u338_21:
	goto	i1l3503
u338_20:
	
i1l3501:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	509
	
i1l3503:	
;charge_mgr.c: 509: if(duty < 0) duty = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u339_21
	goto	u339_20
u339_21:
	goto	i1l3507
u339_20:
	
i1l3505:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	511
	
i1l3507:	
;charge_mgr.c: 511: g_pwmDuty = (unsigned char)duty;
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	513
	
i1l681:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	i1___bmul

;; *************** function i1___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[COMMON] unsigned char 
;;  __bmul          1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;;		_Led_BlinkProcess
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext23
__ptext23:	;psect for function i1___bmul
psect	text23
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_ofi1___bmul
	__size_ofi1___bmul	equ	__end_ofi1___bmul-i1___bmul
	
i1___bmul:	
;incstack = 0
	opt	stack 2
; Regs used in i1___bmul: [wreg+status,2+status,0]
;i1___bmul@multiplier stored from wreg
	movwf	(i1___bmul@multiplier)
	line	6
	
i1l2409:	
	clrf	(i1___bmul@product)
	line	43
	
i1l2411:	
	btfss	(i1___bmul@multiplier),(0)&7
	goto	u184_21
	goto	u184_20
u184_21:
	goto	i1l2415
u184_20:
	line	44
	
i1l2413:	
	movf	(i1___bmul@multiplicand),w
	addwf	(i1___bmul@product),f
	line	45
	
i1l2415:	
	clrc
	rlf	(i1___bmul@multiplicand),f
	line	46
	
i1l2417:	
	clrc
	rrf	(i1___bmul@multiplier),f
	line	47
	movf	((i1___bmul@multiplier)),w
	btfss	status,2
	goto	u185_21
	goto	u185_20
u185_21:
	goto	i1l2411
u185_20:
	line	50
	
i1l2419:	
	movf	(i1___bmul@product),w
	line	51
	
i1l769:	
	return
	opt stack 0
GLOBAL	__end_ofi1___bmul
	__end_ofi1___bmul:
	signat	i1___bmul,89
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] int 
;;  dividend        2    2[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] int 
;;  sign            1    5[COMMON] unsigned char 
;;  counter         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext24
__ptext24:	;psect for function ___awdiv
psect	text24
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
i1l2365:	
	clrf	(___awdiv@sign)
	line	15
	
i1l2367:	
	btfss	(___awdiv@divisor+1),7
	goto	u177_21
	goto	u177_20
u177_21:
	goto	i1l2373
u177_20:
	line	16
	
i1l2369:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
i1l2371:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
i1l2373:	
	btfss	(___awdiv@dividend+1),7
	goto	u178_21
	goto	u178_20
u178_21:
	goto	i1l2379
u178_20:
	line	20
	
i1l2375:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
i1l2377:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
i1l2379:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
i1l2381:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u179_21
	goto	u179_20
u179_21:
	goto	i1l2401
u179_20:
	line	25
	
i1l2383:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	i1l2387
	line	27
	
i1l2385:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
i1l2387:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u180_21
	goto	u180_20
u180_21:
	goto	i1l2385
u180_20:
	line	31
	
i1l2389:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
i1l2391:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u181_25
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u181_25:
	skipc
	goto	u181_21
	goto	u181_20
u181_21:
	goto	i1l2397
u181_20:
	line	33
	
i1l2393:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
i1l2395:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
i1l2397:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
i1l2399:	
	decfsz	(___awdiv@counter),f
	goto	u182_21
	goto	u182_20
u182_21:
	goto	i1l2389
u182_20:
	line	39
	
i1l2401:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u183_21
	goto	u183_20
u183_21:
	goto	i1l2405
u183_20:
	line	40
	
i1l2403:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
i1l2405:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
i1l881:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
