opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ChargeProcess_Slot
	FNCALL	_main,_Do_AdcSample
	FNCALL	_main,_Do_NtcRead
	FNCALL	_main,_Print_DetectLog
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_System_Init
	FNCALL	_main,_uart_send_number
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_Print_DetectLog,_uart_send_char
	FNCALL	_Print_DetectLog,_uart_send_number
	FNCALL	_Print_DetectLog,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_Do_NtcRead,_Read_Temperature
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Do_AdcSample,_ADC_Sample
	FNCALL	_Do_AdcSample,___bmul
	FNCALL	_ChargeProcess_Slot,_ADC_Sample
	FNCALL	_ChargeProcess_Slot,_Detect_BatteryType
	FNCALL	_ChargeProcess_Slot,___bmul
	FNCALL	_ChargeProcess_Slot,___lldiv
	FNCALL	_ChargeProcess_Slot,___lmul
	FNCALL	_ChargeProcess_Slot,___lwdiv
	FNCALL	_ChargeProcess_Slot,___wmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_CCCV_Control
	FNCALL	_Isr_Timer,_Charging_Control
	FNCALL	_Isr_Timer,_Led_BlinkProcess
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Update_LED_Slot
	FNCALL	_Isr_Timer,i1_ADC_Sample
	FNCALL	_Isr_Timer,i1___lldiv
	FNCALL	_Charging_Control,i1___bmul
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,i1___bmul
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_temperature
	global	_g_vcc_mv
	global	_g_impCheckSlot
psect	idataBANK0,class=CODE,space=0,delta=2,noexec
global __pidataBANK0
__pidataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	12

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	15

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	19

;initializer for _g_impCheckSlot
	retlw	0FFh
	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	47
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_powerOnTimer
	global	_g_vccProtect
	global	_g_tempProtect
	global	_g_dbgNewType
	global	_g_dbgNewState
	global	_g_dbgOldState
	global	_g_dbgSlot
	global	_g_tempPhase
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_scanPhase
	global	_g_scanIndex
	global	_g_detectLogType
	global	_g_detectLogSlot
	global	_test_adc
	global	_g_blinkTick
	global	_adresult
	global	_g_dbgDetectFlag
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_adcBusy
	global	_g_doAdcSample
	global	_g_detectLogFlag
	global	_g_detectLowCnt
	global	_g_ovCnt
	global	_g_dbgVoltage
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_cvIntegral
	global	_g_slot
	global	_g_impRefV
	global	_g_ccBlocks
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_GIE
_GIE	set	0x5F
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RC4
_RC4	set	0x834
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC5
_RC5	set	0x835
	global	_RC3
_RC3	set	0x833
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_28:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_29:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_27:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_30:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	45	;'-'
	retlw	105	;'i'
	retlw	111	;'o'
	retlw	110	;'n'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_32:	
	retlw	68	;'D'
	retlw	66	;'B'
	retlw	71	;'G'
	retlw	58	;':'
	retlw	32	;' '
	retlw	115	;'s'
	retlw	108	;'l'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_31:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_33:	
	retlw	32	;' '
	retlw	111	;'o'
	retlw	108	;'l'
	retlw	100	;'d'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_34:	
	retlw	32	;' '
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	119	;'w'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_9:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_23:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_35:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_11:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_36:	
	retlw	32	;' '
	retlw	86	;'V'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
STR_7	equ	STR_2+0
STR_8	equ	STR_3+0
STR_25	equ	STR_31+7
STR_26	equ	STR_31+7
STR_37	equ	STR_31+7
; #config settings
	file	"SC8P096_timer_C.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssBANK0,class=BANK0,bit,space=1,noexec
global __pbitbssBANK0
__pbitbssBANK0:
_g_dbgDetectFlag:
       ds      1

_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

_g_adcBusy:
       ds      1

_g_doAdcSample:
       ds      1

_g_detectLogFlag:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_powerOnTimer:
       ds      2

_g_vccProtect:
       ds      1

_g_tempProtect:
       ds      1

_g_dbgNewType:
       ds      1

_g_dbgNewState:
       ds      1

_g_dbgOldState:
       ds      1

_g_dbgSlot:
       ds      1

_g_tempPhase:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_scanPhase:
       ds      1

_g_scanIndex:
       ds      1

_g_detectLogType:
       ds      1

_g_detectLogSlot:
       ds      1

_test_adc:
       ds      1

_g_blinkTick:
       ds      1

_adresult:
       ds      2

psect	dataBANK0,class=BANK0,space=1,noexec
global __pdataBANK0
__pdataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	12
_g_temperature:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_detectLowCnt:
       ds      12

_g_ovCnt:
       ds      12

_g_dbgVoltage:
       ds      2

_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_cvIntegral:
       ds      2

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	15
_g_vcc_mv:
       ds      2

psect	dataBANK1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	19
_g_impCheckSlot:
       ds      1

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_impRefV:
       ds      24

_g_ccBlocks:
       ds      12

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"SC8P096_timer_C.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
	fcall	__pidataBANK1+2		;fetch initializer
	movwf	__pdataBANK1+2&07fh		
; Initialize objects allocated to BANK0
	global __pidataBANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	fcall	__pidataBANK0+0		;fetch initializer
	movwf	__pdataBANK0+0&07fh		
	fcall	__pidataBANK0+1		;fetch initializer
	movwf	__pdataBANK0+1&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+024h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+022h)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+014h)
	fcall	clear_ram0
; Clear objects allocated to BITBANK0
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssBANK0/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK3,class=BANK3,space=1,noexec
global __pcstackBANK3
__pcstackBANK3:
	global	_Print_SystemStatus$738
_Print_SystemStatus$738:	; 2 bytes @ 0x0
	global	ChargeProcess_Slot@vx_mv
ChargeProcess_Slot@vx_mv:	; 4 bytes @ 0x0
	ds	2
	global	_Print_SystemStatus$739
_Print_SystemStatus$739:	; 2 bytes @ 0x2
	ds	2
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x4
	global	ChargeProcess_Slot@bat_mv_long
ChargeProcess_Slot@bat_mv_long:	; 4 bytes @ 0x4
	ds	4
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x8
	global	ChargeProcess_Slot@vx_mv_383
ChargeProcess_Slot@vx_mv_383:	; 4 bytes @ 0x8
	ds	1
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x9
	ds	2
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0xB
	ds	1
	global	ChargeProcess_Slot@bat_mv_long_384
ChargeProcess_Slot@bat_mv_long_384:	; 4 bytes @ 0xC
	ds	3
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0xF
	ds	1
	global	ChargeProcess_Slot@v_init
ChargeProcess_Slot@v_init:	; 2 bytes @ 0x10
	ds	2
	global	ChargeProcess_Slot@old_st
ChargeProcess_Slot@old_st:	; 1 bytes @ 0x12
	ds	1
	global	Print_SystemStatus@t
Print_SystemStatus@t:	; 1 bytes @ 0x13
	global	ChargeProcess_Slot@v_ref
ChargeProcess_Slot@v_ref:	; 2 bytes @ 0x13
	ds	1
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x14
	ds	1
	global	ChargeProcess_Slot@bat_mv
ChargeProcess_Slot@bat_mv:	; 2 bytes @ 0x15
	ds	1
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x16
	ds	1
	global	ChargeProcess_Slot@bat_mv_385
ChargeProcess_Slot@bat_mv_385:	; 2 bytes @ 0x17
	ds	4
	global	ChargeProcess_Slot@st
ChargeProcess_Slot@st:	; 1 bytes @ 0x1B
	ds	1
	global	ChargeProcess_Slot@ty
ChargeProcess_Slot@ty:	; 1 bytes @ 0x1C
	ds	1
	global	ChargeProcess_Slot@ct
ChargeProcess_Slot@ct:	; 2 bytes @ 0x1D
	ds	2
	global	ChargeProcess_Slot@v
ChargeProcess_Slot@v:	; 2 bytes @ 0x1F
	ds	2
	global	ChargeProcess_Slot@idx
ChargeProcess_Slot@idx:	; 1 bytes @ 0x21
	ds	1
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
	global	?___lmul
?___lmul:	; 4 bytes @ 0x0
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x0
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x0
	global	___wmul@product
___wmul@product:	; 2 bytes @ 0x0
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x0
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x1
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x1
	ds	1
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x2
	ds	1
?_uart_send_number:	; 1 bytes @ 0x3
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x3
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x4
	ds	1
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x5
	ds	2
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x8
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x8
	ds	1
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	2
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0xB
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0xC
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0xC
	ds	1
??_Do_AdcSample:	; 1 bytes @ 0xD
	global	_Print_NtcTemp$736
_Print_NtcTemp$736:	; 2 bytes @ 0xD
	ds	1
	global	Do_AdcSample@ch
Do_AdcSample@ch:	; 1 bytes @ 0xE
	ds	1
	global	_Print_NtcTemp$737
_Print_NtcTemp$737:	; 2 bytes @ 0xF
	ds	1
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x10
	ds	4
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x14
	ds	1
??_Read_Temperature:	; 1 bytes @ 0x15
??_ChargeProcess_Slot:	; 1 bytes @ 0x15
??_Print_SystemStatus:	; 1 bytes @ 0x15
	ds	4
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x19
	ds	4
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x1D
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x1F
	ds	2
??_main:	; 1 bytes @ 0x21
	ds	2
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Update_LED_Slot:	; 1 bytes @ 0x0
??_Update_LED_Slot:	; 1 bytes @ 0x0
?_Charging_Control:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Led_BlinkProcess:	; 1 bytes @ 0x0
??_Led_BlinkProcess:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_ChargeProcess_Slot:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Do_AdcSample:	; 1 bytes @ 0x0
?_Do_NtcRead:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_Print_DetectLog:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?i1_ADC_Sample:	; 1 bytes @ 0x0
?i1___bmul:	; 1 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	?i1___lldiv
?i1___lldiv:	; 4 bytes @ 0x0
Update_LED_Slot@idx:	; 1 bytes @ 0x0
	global	i1ADC_Sample@adldo
i1ADC_Sample@adldo:	; 1 bytes @ 0x0
	global	i1___bmul@multiplicand
i1___bmul@multiplicand:	; 1 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	global	i1___lldiv@divisor
i1___lldiv@divisor:	; 4 bytes @ 0x0
	ds	1
??i1_ADC_Sample:	; 1 bytes @ 0x1
??i1___bmul:	; 1 bytes @ 0x1
	global	i1___bmul@multiplier
i1___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
	global	i1___bmul@product
i1___bmul@product:	; 1 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_Charging_Control:	; 1 bytes @ 0x3
	global	Charging_Control@chargeB1_6
Charging_Control@chargeB1_6:	; 1 bytes @ 0x3
	ds	1
??___awdiv:	; 1 bytes @ 0x4
	global	Charging_Control@chargeB7_12
Charging_Control@chargeB7_12:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	global	i1___lldiv@dividend
i1___lldiv@dividend:	; 4 bytes @ 0x4
	ds	1
	global	Charging_Control@s
Charging_Control@s:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	ds	1
	global	Charging_Control@i
Charging_Control@i:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	2
??_CCCV_Control:	; 1 bytes @ 0x8
??i1___lldiv:	; 1 bytes @ 0x8
	global	i1___lldiv@counter
i1___lldiv@counter:	; 1 bytes @ 0x8
	ds	1
	global	i1___lldiv@quotient
i1___lldiv@quotient:	; 4 bytes @ 0x9
	ds	4
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	i1ADC_Sample@adch
i1ADC_Sample@adch:	; 1 bytes @ 0x0
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x0
	ds	1
	global	i1ADC_Sample@j
i1ADC_Sample@j:	; 1 bytes @ 0x1
	ds	1
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x2
	global	i1ADC_Sample@i
i1ADC_Sample@i:	; 1 bytes @ 0x2
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x3
	global	i1ADC_Sample@adsum
i1ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0x4
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0x5
	ds	1
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x6
	ds	1
	global	i1ADC_Sample@admin
i1ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x8
	ds	1
	global	i1ADC_Sample@admax
i1ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	1
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xA
	ds	1
	global	i1ADC_Sample@ad_temp
i1ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0xC
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0xD
	ds	1
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0xE
	ds	2
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x10
	ds	1
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x11
	ds	1
??_Isr_Timer:	; 1 bytes @ 0x12
	ds	4
	global	Isr_Timer@pt
Isr_Timer@pt:	; 4 bytes @ 0x16
	ds	4
??_AD_Init:	; 1 bytes @ 0x1A
??_uart_init:	; 1 bytes @ 0x1A
?_ADC_Sample:	; 1 bytes @ 0x1A
??_uart_send_char:	; 1 bytes @ 0x1A
?_Detect_BatteryType:	; 1 bytes @ 0x1A
??___lmul:	; 1 bytes @ 0x1A
?___bmul:	; 1 bytes @ 0x1A
	global	?___wmul
?___wmul:	; 2 bytes @ 0x1A
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x1A
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x1A
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x1A
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x1A
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x1A
	global	___wmul@multiplier
___wmul@multiplier:	; 2 bytes @ 0x1A
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x1A
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x1A
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x1A
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x1B
??___bmul:	; 1 bytes @ 0x1B
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x1B
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x1B
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x1C
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x1C
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x1C
	global	___wmul@multiplicand
___wmul@multiplicand:	; 2 bytes @ 0x1C
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x1C
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x1C
	ds	1
?_uart_send_string:	; 1 bytes @ 0x1D
??_System_Init:	; 1 bytes @ 0x1D
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x1D
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x1D
	ds	1
??___wmul:	; 1 bytes @ 0x1E
??___lldiv:	; 1 bytes @ 0x1E
??___lwdiv:	; 1 bytes @ 0x1E
??___lwmod:	; 1 bytes @ 0x1E
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x1E
	ds	1
??_uart_send_string:	; 1 bytes @ 0x1F
??_uart_send_number:	; 1 bytes @ 0x1F
??_Do_NtcRead:	; 1 bytes @ 0x1F
??_Print_NtcTemp:	; 1 bytes @ 0x1F
??_Print_DetectLog:	; 1 bytes @ 0x1F
;!
;!Data Sizes:
;!    Strings     338
;!    Constant    12
;!    Data        5
;!    BSS         162
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     13      13
;!    BANK0            80     31      54
;!    BANK1            80     35      72
;!    BANK3            80     34      70
;!    BANK2            80      0      72

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 37
;!		 -> STR_37(CODE[3]), STR_36(CODE[4]), STR_35(CODE[5]), STR_34(CODE[6]), 
;!		 -> STR_33(CODE[6]), STR_32(CODE[11]), STR_31(CODE[10]), STR_30(CODE[21]), 
;!		 -> STR_29(CODE[34]), STR_28(CODE[37]), STR_27(CODE[33]), STR_26(CODE[3]), 
;!		 -> STR_25(CODE[3]), STR_24(CODE[6]), STR_23(CODE[6]), STR_22(CODE[6]), 
;!		 -> STR_21(CODE[16]), STR_20(CODE[13]), STR_19(CODE[15]), STR_18(CODE[7]), 
;!		 -> STR_17(CODE[5]), STR_16(CODE[5]), STR_15(CODE[6]), STR_14(CODE[6]), 
;!		 -> STR_13(CODE[6]), STR_12(CODE[7]), STR_11(CODE[4]), STR_10(CODE[6]), 
;!		 -> STR_9(CODE[6]), STR_8(CODE[4]), STR_7(CODE[2]), STR_6(CODE[6]), 
;!		 -> STR_5(CODE[5]), STR_4(CODE[29]), STR_3(CODE[4]), STR_2(CODE[2]), 
;!		 -> STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->i1___lldiv
;!    _Charging_Control->i1___bmul
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_uart_send_string
;!    _System_Init->___bmul
;!    _Print_SystemStatus->_ADC_Sample
;!    _Print_SystemStatus->___lwmod
;!    _Print_SystemStatus->_uart_send_string
;!    _Print_NtcTemp->___lwmod
;!    _Print_NtcTemp->_uart_send_string
;!    _Print_DetectLog->_uart_send_string
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwmod
;!    _Read_Temperature->_ADC_Sample
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->_ADC_Sample
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    _Isr_Timer->_CCCV_Control
;!
;!Critical Paths under _main in BANK1
;!
;!    _Print_SystemStatus->___lldiv
;!    _Print_NtcTemp->_uart_send_number
;!    _Print_DetectLog->_uart_send_number
;!    _uart_send_number->___lwdiv
;!    _Do_NtcRead->_Read_Temperature
;!    _Read_Temperature->___lldiv
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->___lldiv
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    _main->_ChargeProcess_Slot
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 2     2      0   61375
;!                                             33 BANK1      2     2      0
;!                 _ChargeProcess_Slot
;!                       _Do_AdcSample
;!                         _Do_NtcRead
;!                    _Print_DetectLog
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                        _System_Init
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1349
;!                                             29 BANK0      1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  31    31      0   14277
;!                                             21 BANK1      8     8      0
;!                                              0 BANK3     23    23      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    7174
;!                                             13 BANK1      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_DetectLog                                      0     0      0    5864
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    2572
;!                                             29 BANK0      2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_number                                    10     8      2    3190
;!                                              3 BANK1     10     8      2
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     102
;!                                             26 BANK0      3     3      0
;! ---------------------------------------------------------------------------------
;! (2) ___lwmod                                              5     1      4     378
;!                                             26 BANK0      5     1      4
;! ---------------------------------------------------------------------------------
;! (1) _Do_NtcRead                                           0     0      0    6448
;!                   _Read_Temperature
;! ---------------------------------------------------------------------------------
;! (2) _Read_Temperature                                    12    12      0    6448
;!                                             21 BANK1     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (1) _Do_AdcSample                                         2     2      0    2557
;!                                             13 BANK1      2     2      0
;!                         _ADC_Sample
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _ChargeProcess_Slot                                  40    40      0   17944
;!                                             21 BANK1      6     6      0
;!                                              0 BANK3     34    34      0
;!                         _ADC_Sample
;!                 _Detect_BatteryType
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (2) ___wmul                                               6     2      4    2080
;!                                             26 BANK0      4     0      4
;!                                              0 BANK1      2     2      0
;! ---------------------------------------------------------------------------------
;! (2) ___lwdiv                                              7     3      4    1010
;!                                             26 BANK0      4     0      4
;!                                              0 BANK1      3     3      0
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8    2288
;!                                             26 BANK0      4     4      0
;!                                              0 BANK1      8     0      8
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1082
;!                                              8 BANK1     13     5      8
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1    1001
;!                                             26 BANK0      3     2      1
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     251
;!                                             26 BANK0      2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _ADC_Sample                                          18    17      1    1508
;!                                             26 BANK0      5     4      1
;!                                              0 BANK1     13    13      0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 2
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            8     8      0    3877
;!                                             18 BANK0      8     8      0
;!                       _CCCV_Control
;!                   _Charging_Control
;!                   _Led_BlinkProcess
;!                 _PowerOnLedSequence
;!                    _Update_LED_Slot
;!                       i1_ADC_Sample
;!                          i1___lldiv
;! ---------------------------------------------------------------------------------
;! (5) i1___lldiv                                           13     5      8      44
;!                                              0 COMMON    13     5      8
;! ---------------------------------------------------------------------------------
;! (5) i1_ADC_Sample                                        18    17      1     805
;!                                              0 COMMON     5     4      1
;!                                              0 BANK0     13    13      0
;! ---------------------------------------------------------------------------------
;! (5) _Update_LED_Slot                                      1     1      0       0
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Led_BlinkProcess                                     0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Charging_Control                                     4     4      0     713
;!                                              3 COMMON     4     4      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _CCCV_Control                                        20    20      0    2267
;!                                              8 COMMON     2     2      0
;!                                              0 BANK0     18    18      0
;!                            ___awdiv
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (6) i1___bmul                                             3     2      1     125
;!                                              0 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (6) ___awdiv                                              8     4      4     606
;!                                              0 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ChargeProcess_Slot
;!     _ADC_Sample
;!     _Detect_BatteryType
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___wmul
;!   _Do_AdcSample
;!     _ADC_Sample
;!     ___bmul
;!   _Do_NtcRead
;!     _Read_Temperature
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!       ___lwdiv
;!   _Print_DetectLog
;!     _uart_send_char
;!     _uart_send_number
;!       ___lwdiv
;!       ___lwmod
;!       _uart_send_char
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___lwdiv
;!       ___lwmod
;!       _uart_send_char
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___lwdiv
;!       ___lwmod
;!       _uart_send_char
;!     _uart_send_string
;!       _uart_send_char
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _uart_send_number
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     i1___bmul
;!   _Charging_Control
;!     i1___bmul
;!   _Led_BlinkProcess
;!   _PowerOnLedSequence
;!   _Update_LED_Slot
;!   i1_ADC_Sample
;!   i1___lldiv
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50     22      46       8       87.5%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      0      48      10       90.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50     23      48       6       90.0%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     1F      36       4       67.5%
;!BITBANK0            50      0       1       3        1.3%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      D       D       1       92.9%
;!BITCOMMON            E      0       0       0        0.0%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     119      12        0.0%
;!ABS                  0      0     119      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 464 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       2       0       0
;;      Totals:         0       0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ChargeProcess_Slot
;;		_Do_AdcSample
;;		_Do_NtcRead
;;		_Print_DetectLog
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_System_Init
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	464
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	464
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	467
	
l6773:	
;main.c: 467: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_main+0)^080h+0+1),f
	movlw	241
movwf	((??_main+0)^080h+0),f
	u9277:
decfsz	((??_main+0)^080h+0),f
	goto	u9277
	decfsz	((??_main+0)^080h+0+1),f
	goto	u9277
opt asmopt_pop

	line	468
# 468 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	471
	
l6775:	
;main.c: 471: System_Init();
	fcall	_System_Init
	line	474
	
l6777:	
;main.c: 474: uart_send_string("L1211 Charger V2.1\r\n");
	movlw	low(((STR_30)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	475
	
l6779:	
;main.c: 475: uart_send_string("Init...\r\n");
	movlw	low(((STR_31)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	478
;main.c: 478: while(1)
	
l455:	
	line	480
# 480 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	483
	
l6781:	
;main.c: 483: if(g_doAdcSample)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u9221
	goto	u9220
u9221:
	goto	l6811
u9220:
	line	485
	
l6783:	
;main.c: 484: {
;main.c: 485: g_doAdcSample = 0;
	bcf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	line	486
;main.c: 486: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	487
	
l6785:	
;main.c: 487: Do_AdcSample();
	fcall	_Do_AdcSample
	line	488
	
l6787:	
;main.c: 488: ChargeProcess_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_ChargeProcess_Slot
	line	491
	
l6789:	
;main.c: 491: if(g_dbgDetectFlag)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	goto	u9231
	goto	u9230
u9231:
	goto	l6809
u9230:
	line	493
	
l6791:	
;main.c: 492: {
;main.c: 493: g_dbgDetectFlag = 0;
	bcf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	494
	
l6793:	
;main.c: 494: uart_send_string("DBG: slot=");
	movlw	low(((STR_32)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	495
	
l6795:	
;main.c: 495: uart_send_number(g_dbgSlot);
	movf	(_g_dbgSlot),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	496
	
l6797:	
;main.c: 496: uart_send_string(" old=");
	movlw	low(((STR_33)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	497
;main.c: 497: uart_send_number(g_dbgOldState);
	movf	(_g_dbgOldState),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	498
	
l6799:	
;main.c: 498: uart_send_string(" new=");
	movlw	low(((STR_34)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_34)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	499
	
l6801:	
;main.c: 499: uart_send_number(g_dbgNewState);
	movf	(_g_dbgNewState),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	500
;main.c: 500: uart_send_string(" ty=");
	movlw	low(((STR_35)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_35)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	501
	
l6803:	
;main.c: 501: uart_send_number(g_dbgNewType);
	movf	(_g_dbgNewType),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	502
	
l6805:	
;main.c: 502: uart_send_string(" V=");
	movlw	low(((STR_36)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_36)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	503
;main.c: 503: uart_send_number(g_dbgVoltage);
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_dbgVoltage+1)^080h,w	;volatile
	movwf	(uart_send_number@num+1)^080h
	movf	(_g_dbgVoltage)^080h,w	;volatile
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	504
	
l6807:	
;main.c: 504: uart_send_string("\r\n");
	movlw	low(((STR_37)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_37)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	507
	
l6809:	
;main.c: 505: }
;main.c: 507: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	511
	
l6811:	
;main.c: 508: }
;main.c: 511: if(g_doNtcRead)
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u9241
	goto	u9240
u9241:
	goto	l6819
u9240:
	line	513
	
l6813:	
;main.c: 512: {
;main.c: 513: g_doNtcRead = 0;
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	514
;main.c: 514: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	515
	
l6815:	
;main.c: 515: Do_NtcRead();
	fcall	_Do_NtcRead
	line	516
	
l6817:	
;main.c: 516: g_adcBusy = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	520
	
l6819:	
;main.c: 517: }
;main.c: 520: if(g_printFlag)
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u9251
	goto	u9250
u9251:
	goto	l6825
u9250:
	line	522
	
l6821:	
;main.c: 521: {
;main.c: 522: g_printFlag = 0;
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	523
	
l6823:	
;main.c: 523: Print_SystemStatus();
	fcall	_Print_SystemStatus
	line	524
;main.c: 524: Print_NtcTemp();
	fcall	_Print_NtcTemp
	line	528
	
l6825:	
;main.c: 525: }
;main.c: 528: if(g_detectLogFlag)
	btfss	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	goto	u9261
	goto	u9260
u9261:
	goto	l455
u9260:
	line	530
	
l6827:	
;main.c: 529: {
;main.c: 530: g_detectLogFlag = 0;
	bcf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	line	531
	
l6829:	
;main.c: 531: Print_DetectLog();
	fcall	_Print_DetectLog
	goto	l455
	global	start
	ljmp	start
	opt stack 0
	line	534
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 68 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   29[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	68
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	68
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	73
	
l5787:	
# 73 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	74
# 74 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text1
	line	75
	
l5789:	
;main.c: 75: OSCCON = 0x72;
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	79
;main.c: 79: TRISA = 0xF0; PORTA = 0x0F;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	80
;main.c: 80: TRISB = 0x30; PORTB = 0x4F;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	81
;main.c: 81: TRISC = 0x07; PORTC = 0x00;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l5791:	
	clrf	(262)^0100h	;volatile
	line	82
	
l5793:	
;main.c: 82: TRISD = 0xF0; PORTD = 0x0F;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l5795:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	85
	
l5797:	
;main.c: 85: WPUA = 0x00; WPDA = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l5799:	
	clrf	(135)^080h	;volatile
	line	86
	
l5801:	
;main.c: 86: WPUB = 0x00; WPDB = 0x00;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l5803:	
	clrf	(7)	;volatile
	line	87
	
l5805:	
;main.c: 87: WPUC = 0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	88
	
l5807:	
;main.c: 88: WPUD = 0x00;
	clrf	(277)^0100h	;volatile
	line	91
	
l5809:	
;main.c: 91: IOCA = 0x00; IOCB = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l5811:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	94
	
l5813:	
;main.c: 94: CC0CON = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	95
	
l5815:	
;main.c: 95: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	102
	
l5817:	
;main.c: 102: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	103
	
l5819:	
;main.c: 103: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	104
	
l5821:	
;main.c: 104: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	105
	
l5823:	
;main.c: 105: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	108
	
l5825:	
;main.c: 108: AD_Init();
	fcall	_AD_Init
	line	111
	
l5827:	
;main.c: 111: uart_init();
	fcall	_uart_init
	line	118
;main.c: 118: OPTION_REG = 0x00;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	119
	
l5829:	
;main.c: 119: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	120
	
l5831:	
;main.c: 120: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	121
	
l5833:	
;main.c: 121: INTCON = 0xE0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	124
;main.c: 124: g_pwmDuty = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	125
;main.c: 125: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	126
	
l5835:	
;main.c: 126: RC3 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	127
	
l5837:	
;main.c: 127: RC5 = 0;
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	128
	
l5839:	
;main.c: 128: RB6 = 1;
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	129
	
l5841:	
;main.c: 129: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	132
;main.c: 132: for(i = 0; i < 12; i++)
	clrf	(System_Init@i)
	line	134
	
l5847:	
;main.c: 133: {
;main.c: 134: g_slot[i].state = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	135
;main.c: 135: g_slot[i].type = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	136
;main.c: 136: g_slot[i].voltage = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	137
;main.c: 137: g_slot[i].chargeTimer = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	138
	
l5849:	
;main.c: 138: g_ccBlocks[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	139
	
l5851:	
;main.c: 139: g_ovCnt[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	132
	
l5853:	
	incf	(System_Init@i),f
	
l5855:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u7651
	goto	u7650
u7651:
	goto	l5847
u7650:
	line	141
	
l5857:	
;main.c: 140: }
;main.c: 141: g_blinkTick = 0;
	clrf	(_g_blinkTick)
	line	144
	
l359:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
global __ptext2
__ptext2:	;psect for function _uart_init
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_init: []
	line	23
	
l2769:	
;uart_dbg.c: 23: TRISC &= (unsigned char)~0x10;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
;uart_dbg.c: 24: ANSEL2 &= (unsigned char)~0x10;
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
;uart_dbg.c: 25: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l493:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
global __ptext3
__ptext3:	;psect for function _AD_Init
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l2763:	
;adc_drv.c: 25: CC0CON = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
;adc_drv.c: 26: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	27
	
l2765:	
;adc_drv.c: 27: ADCON0 = 0X81;
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l2767:	
;adc_drv.c: 28: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	29
	
l470:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 327 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  t               1   19[BANK3 ] unsigned char 
;;  bat_mv_long     4   15[BANK3 ] unsigned long 
;;  vx_mv           4   11[BANK3 ] unsigned long 
;;  v               2    9[BANK3 ] unsigned int 
;;  s               1    8[BANK3 ] unsigned char 
;;  pt              4    4[BANK3 ] unsigned long 
;;  vcc_mv          2   20[BANK3 ] unsigned int 
;;  i               1   22[BANK3 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0      23       0
;;      Temps:          0       0       8       0       0
;;      Totals:         0       0       8      23       0
;;Total ram usage:       31 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	327
global __ptext4
__ptext4:	;psect for function _Print_SystemStatus
psect	text4
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	327
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	332
	
l6049:	
;main.c: 329: unsigned char i;
;main.c: 330: unsigned int vcc_mv;
;main.c: 332: uart_send_string("\r\n== L1211 12CH CHARGER ==\r\n");
	movlw	low(((STR_4)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	335
	
l6051:	
;main.c: 335: test_adc = ADC_Sample(31, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	336
	
l6053:	
;main.c: 336: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u8031
	goto	u8030
u8031:
	goto	l6059
u8030:
	line	338
	
l6055:	
;main.c: 337: {
;main.c: 338: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@pt+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@pt+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@pt+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@pt)^0180h

	line	339
	
l6057:	
;main.c: 339: vcc_mv = (unsigned int)pt;
	movf	(Print_SystemStatus@pt+1)^0180h,w
	movwf	(Print_SystemStatus@vcc_mv+1)^0180h
	movf	(Print_SystemStatus@pt)^0180h,w
	movwf	(Print_SystemStatus@vcc_mv)^0180h
	line	340
;main.c: 340: }
	goto	l416
	line	342
	
l6059:	
;main.c: 341: else
;main.c: 342: vcc_mv = 5000;
	movlw	088h
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@vcc_mv)^0180h
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv)^0180h)+1
	
l416:	
	line	344
;main.c: 344: g_vcc_mv = vcc_mv;
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_vcc_mv+1)^080h	;volatile
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_vcc_mv)^080h	;volatile
	line	346
	
l6061:	
;main.c: 346: uart_send_string("VCC=");
	movlw	low(((STR_5)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	347
	
l6063:	
;main.c: 347: uart_send_number(vcc_mv);
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	348
	
l6065:	
;main.c: 348: uart_send_string("mV T=");
	movlw	low(((STR_6)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	349
	
l6067:	
;main.c: 349: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(_Print_SystemStatus$738+1)^0180h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(_Print_SystemStatus$738)^0180h
	
l6069:	
;main.c: 349: uart_send_number(g_temperature / 10U);
	movf	(_Print_SystemStatus$738+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(_Print_SystemStatus$738)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	350
	
l6071:	
;main.c: 350: uart_send_string(".");
	movlw	low(((STR_7)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	351
	
l6073:	
;main.c: 351: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(_Print_SystemStatus$739+1)^0180h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(0+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(_Print_SystemStatus$739)^0180h
	
l6075:	
;main.c: 351: uart_send_number(g_temperature % 10U);
	movf	(_Print_SystemStatus$739+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(_Print_SystemStatus$739)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	352
	
l6077:	
;main.c: 352: uart_send_string("C\r\n");
	movlw	low(((STR_8)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	356
	
l6079:	
;main.c: 356: for(i = 0; i < 6; i++)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(Print_SystemStatus@i)^0180h
	line	365
	
l6085:	
;main.c: 364: {
;main.c: 365: unsigned int v = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@v)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)^0180h
	line	366
;main.c: 366: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@s)^0180h
	line	373
	
l6087:	
;main.c: 373: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	374
	
l6089:	
;main.c: 374: uart_send_number((unsigned int)i + 1U);
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	incf	(uart_send_number@num)^080h,f
	skipnz
	incf	(uart_send_number@num+1)^080h,f
	fcall	_uart_send_number
	line	375
;main.c: 375: uart_send_char('=');
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	376
	
l6091:	
;main.c: 376: uart_send_number(v);
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	382
	
l6093:	
;main.c: 381: {
;main.c: 382: unsigned long vx_mv = (unsigned long)v * (unsigned long)vcc_mv / 4096UL;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@vx_mv+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@vx_mv+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@vx_mv+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@vx_mv)^0180h

	
l6095:	
	movlw	0Ch
u8045:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3)^0180h,f
	rrf	(Print_SystemStatus@vx_mv+2)^0180h,f
	rrf	(Print_SystemStatus@vx_mv+1)^0180h,f
	rrf	(Print_SystemStatus@vx_mv)^0180h,f
	addlw	-1
	skipz
	goto	u8045

	line	383
	
l6097:	
;main.c: 383: if(vx_mv + 200U >= (unsigned long)vcc_mv)
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+0)^080h+0)
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	clrf	((??_Print_SystemStatus+0)^080h+0+2)
	clrf	((??_Print_SystemStatus+0)^080h+0+3)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+4)^080h+0)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vx_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_Print_SystemStatus+4)^080h+0,f
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vx_mv+1)^0180h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1)^0180h,w
	goto	u8050
	goto	u8051
u8050:
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_Print_SystemStatus+4)^080h+1,f
u8051:
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vx_mv+2)^0180h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2)^0180h,w
	goto	u8052
	goto	u8053
u8052:
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_Print_SystemStatus+4)^080h+2,f
u8053:
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vx_mv+3)^0180h,w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_Print_SystemStatus+4)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	subwf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u8065
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	subwf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u8065
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	subwf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u8065
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	subwf	0+(??_Print_SystemStatus+4)^080h+0,w
u8065:
	skipc
	goto	u8061
	goto	u8060
u8061:
	goto	l6101
u8060:
	line	385
	
l6099:	
;main.c: 384: {
;main.c: 385: uart_send_string(" OPEN");
	movlw	low(((STR_9)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	386
;main.c: 386: }
	goto	l6111
	line	389
	
l6101:	
;main.c: 387: else
;main.c: 388: {
;main.c: 389: unsigned long bat_mv_long = 124UL * vx_mv;
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vx_mv+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier+3)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vx_mv+2)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier+2)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vx_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vx_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long)^0180h

	line	390
;main.c: 390: if(bat_mv_long > (206UL * (unsigned long)vcc_mv))
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	(3+(?___lmul))^080h,w
	skipz
	goto	u8075
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long+2)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	(2+(?___lmul))^080h,w
	skipz
	goto	u8075
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	(1+(?___lmul))^080h,w
	skipz
	goto	u8075
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	(0+(?___lmul))^080h,w
u8075:
	skipnc
	goto	u8071
	goto	u8070
u8071:
	goto	l6111
u8070:
	line	392
	
l6103:	
;main.c: 391: {
;main.c: 392: bat_mv_long = (bat_mv_long - 206UL * (unsigned long)vcc_mv + 1000UL/2UL) / 1000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+3)
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+1)^080h
	movlw	032h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	addwf	(Print_SystemStatus@bat_mv_long)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+4)^080h+0+0)
	movlw	0
	skipnc
	movlw	1
	addwf	(1+(?___lmul))^080h,w
	clrf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	bsf	status, 6	;RP1=1, select bank3
	addwf	(Print_SystemStatus@bat_mv_long+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	movf	(2+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+2),w
	clrf	((??_Print_SystemStatus+4)^080h+0+3)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	bsf	status, 6	;RP1=1, select bank3
	addwf	(Print_SystemStatus@bat_mv_long+2)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	movf	(3+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+3),w
	bsf	status, 6	;RP1=1, select bank3
	addwf	(Print_SystemStatus@bat_mv_long+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	0+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+0,f
	movf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	1+(??_Print_SystemStatus+4)^080h+0,w
	goto	u8080
	goto	u8081
u8080:
	addwf	(??_Print_SystemStatus+0)^080h+1,f
u8081:
	movf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	2+(??_Print_SystemStatus+4)^080h+0,w
	goto	u8082
	goto	u8083
u8082:
	addwf	(??_Print_SystemStatus+0)^080h+2,f
u8083:
	movf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incf	3+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long)^0180h

	line	393
	
l6105:	
;main.c: 393: uart_send_string(" BAT(");
	movlw	low(((STR_10)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	394
	
l6107:	
;main.c: 394: uart_send_number((unsigned int)bat_mv_long);
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	395
	
l6109:	
;main.c: 395: uart_send_string("mV)");
	movlw	low(((STR_11)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	402
	
l6111:	
;main.c: 396: }
;main.c: 398: }
;main.c: 399: }
;main.c: 402: uart_send_char(' ');
	movlw	low(020h)
	fcall	_uart_send_char
	line	403
;main.c: 403: switch(s)
	goto	l6151
	line	405
	
l6113:	
	movlw	low(((STR_12)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6153
	line	406
	
l6115:	
	movlw	low(((STR_13)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6153
	line	407
	
l6117:	
	movlw	low(((STR_14)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6153
	line	408
	
l6119:	
	movlw	low(((STR_15)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6153
	line	409
	
l6121:	
	movlw	low(((STR_16)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6153
	line	410
	
l6123:	
	movlw	low(((STR_17)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6153
	line	411
	
l6125:	
	movlw	low(((STR_18)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6153
	line	414
	
l6127:	
;main.c: 413: {
;main.c: 414: unsigned char t = g_slot[(unsigned char)(i)].type;
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@t)^0180h
	line	415
	
l6129:	
;main.c: 415: if(t == 2 || t == 3)
		movlw	2
	xorwf	((Print_SystemStatus@t)^0180h),w
	btfsc	status,2
	goto	u8091
	goto	u8090
u8091:
	goto	l6133
u8090:
	
l6131:	
		movlw	3
	xorwf	((Print_SystemStatus@t)^0180h),w
	btfss	status,2
	goto	u8101
	goto	u8100
u8101:
	goto	l6135
u8100:
	line	416
	
l6133:	
;main.c: 416: uart_send_string("[Dry/NiMH ERR]");
	movlw	low(((STR_19)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6153
	line	417
	
l6135:	
;main.c: 417: else if(t == 1)
		decf	((Print_SystemStatus@t)^0180h),w
	btfss	status,2
	goto	u8111
	goto	u8110
u8111:
	goto	l6139
u8110:
	line	418
	
l6137:	
;main.c: 418: uart_send_string("[Li-ion ERR]");
	movlw	low(((STR_20)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6153
	line	419
	
l6139:	
;main.c: 419: else if(t == 6)
		movlw	6
	xorwf	((Print_SystemStatus@t)^0180h),w
	btfss	status,2
	goto	u8121
	goto	u8120
u8121:
	goto	l6143
u8120:
	line	420
	
l6141:	
;main.c: 420: uart_send_string("[Linear Li ERR]");
	movlw	low(((STR_21)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6153
	line	422
	
l6143:	
;main.c: 421: else
;main.c: 422: uart_send_string("[ERR]");
	movlw	low(((STR_22)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6153
	line	425
	
l6145:	
	movlw	low(((STR_23)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6153
	line	426
	
l6147:	
	movlw	low(((STR_24)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6153
	line	403
	
l6151:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@s)^0180h,w
	; Switch size 1, requested type "space"
; Number of cases is 9, Range of values is 0 to 8
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           28    15 (average)
; direct_byte           35     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l6113
	xorlw	1^0	; case 1
	skipnz
	goto	l6115
	xorlw	2^1	; case 2
	skipnz
	goto	l6117
	xorlw	3^2	; case 3
	skipnz
	goto	l6119
	xorlw	4^3	; case 4
	skipnz
	goto	l6121
	xorlw	5^4	; case 5
	skipnz
	goto	l6123
	xorlw	6^5	; case 6
	skipnz
	goto	l6125
	xorlw	7^6	; case 7
	skipnz
	goto	l6127
	xorlw	8^7	; case 8
	skipnz
	goto	l6145
	goto	l6147
	opt asmopt_pop

	line	430
	
l6153:	
;main.c: 430: uart_send_string("\r\n");
	movlw	low(((STR_25)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	356
	
l6155:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	incf	(Print_SystemStatus@i)^0180h,f
	
l6157:	
	movlw	low(06h)
	subwf	(Print_SystemStatus@i)^0180h,w
	skipc
	goto	u8131
	goto	u8130
u8131:
	goto	l6085
u8130:
	line	433
	
l6159:	
;main.c: 432: }
;main.c: 433: uart_send_string("\r\n");
	movlw	low(((STR_26)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	434
	
l442:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 307 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	307
global __ptext5
__ptext5:	;psect for function _Print_NtcTemp
psect	text5
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	307
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	309
	
l6037:	
;main.c: 309: uart_send_string("NTC=");
	movlw	low(((STR_1)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	310
	
l6039:	
;main.c: 310: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_NtcTemp$736+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_NtcTemp$736)^080h
	
l6041:	
;main.c: 310: uart_send_number(g_temperature / 10U);
	movf	(_Print_NtcTemp$736+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$736)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	311
	
l6043:	
;main.c: 311: uart_send_string(".");
	movlw	low(((STR_2)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	312
	
l6045:	
;main.c: 312: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_NtcTemp$737+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_NtcTemp$737)^080h
;main.c: 312: uart_send_number(g_temperature % 10U);
	movf	(_Print_NtcTemp$737+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$737)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	313
	
l6047:	
;main.c: 313: uart_send_string("C\r\n");
	movlw	low(((STR_3)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	314
	
l412:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_Print_DetectLog

;; *************** function _Print_DetectLog *****************
;; Defined at:
;;		line 440 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	line	440
global __ptext6
__ptext6:	;psect for function _Print_DetectLog
psect	text6
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	440
	global	__size_of_Print_DetectLog
	__size_of_Print_DetectLog	equ	__end_of_Print_DetectLog-_Print_DetectLog
	
_Print_DetectLog:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_DetectLog: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	442
	
l6161:	
;main.c: 442: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	443
	
l6163:	
;main.c: 443: uart_send_number((unsigned int)g_detectLogSlot + 1U);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_detectLogSlot),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	incf	(uart_send_number@num)^080h,f
	skipnz
	incf	(uart_send_number@num+1)^080h,f
	fcall	_uart_send_number
	line	445
	
l6165:	
;main.c: 445: if(g_detectLogType == 2)
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u8141
	goto	u8140
u8141:
	goto	l6169
u8140:
	line	446
	
l6167:	
;main.c: 446: uart_send_string(": NiMH detected! Not charging.\r\n");
	movlw	low(((STR_27)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l450
	line	447
	
l6169:	
;main.c: 447: else if(g_detectLogType == 3)
		movlw	3
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u8151
	goto	u8150
u8151:
	goto	l6173
u8150:
	line	448
	
l6171:	
;main.c: 448: uart_send_string(": Dry/NiMH detected! Not charging.\r\n");
	movlw	low(((STR_28)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l450
	line	449
	
l6173:	
;main.c: 449: else if(g_detectLogType == 6)
		movlw	6
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u8161
	goto	u8160
u8161:
	goto	l450
u8160:
	line	450
	
l6175:	
;main.c: 450: uart_send_string(": Linear Li detected! Charging.\r\n");
	movlw	low(((STR_29)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	451
	
l450:	
	return
	opt stack 0
GLOBAL	__end_of_Print_DetectLog
	__end_of_Print_DetectLog:
	signat	_Print_DetectLog,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2   29[BANK0 ] PTR const unsigned char 
;;		 -> STR_37(3), STR_36(4), STR_35(5), STR_34(6), 
;;		 -> STR_33(6), STR_32(11), STR_31(10), STR_30(21), 
;;		 -> STR_29(34), STR_28(37), STR_27(33), STR_26(3), 
;;		 -> STR_25(3), STR_24(6), STR_23(6), STR_22(6), 
;;		 -> STR_21(16), STR_20(13), STR_19(15), STR_18(7), 
;;		 -> STR_17(5), STR_16(5), STR_15(6), STR_14(6), 
;;		 -> STR_13(6), STR_12(7), STR_11(4), STR_10(6), 
;;		 -> STR_9(6), STR_8(4), STR_7(2), STR_6(6), 
;;		 -> STR_5(5), STR_4(29), STR_3(4), STR_2(2), 
;;		 -> STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
global __ptext7
__ptext7:	;psect for function _uart_send_string
psect	text7
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l4311:	
;uart_dbg.c: 63: while(*str != '\0')
	goto	l4317
	line	65
	
l4313:	
;uart_dbg.c: 64: {
;uart_dbg.c: 65: uart_send_char(*str++);
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	fcall	_uart_send_char
	
l4315:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(uart_send_string@str),f
	skipnz
	incf	(uart_send_string@str+1),f
	line	66
# 66 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
clrwdt ;# 
psect	text7
	line	63
	
l4317:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u5231
	goto	u5230
u5231:
	goto	l4313
u5230:
	line	68
	
l506:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2    3[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    5[BANK1 ] unsigned char [6]
;;  j               1   12[BANK1 ] unsigned char 
;;  i               1   11[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      10       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext8
__ptext8:	;psect for function _uart_send_number
psect	text8
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l5729:	
;uart_dbg.c: 79: unsigned char buf[6];
;uart_dbg.c: 80: unsigned char i = 0;
	clrf	(uart_send_number@i)^080h
	line	84
	
l5731:	
;uart_dbg.c: 81: unsigned char j;
;uart_dbg.c: 84: if(num == 0)
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u7581
	goto	u7580
u7581:
	goto	l5743
u7580:
	line	86
	
l5733:	
;uart_dbg.c: 85: {
;uart_dbg.c: 86: uart_send_char('0');
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l510
	line	93
	
l5737:	
;uart_dbg.c: 92: {
;uart_dbg.c: 93: buf[i++] = '0' + (num % 10);
	movf	(uart_send_number@i)^080h,w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@num+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@num)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank1
	movwf	indf
	
l5739:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(uart_send_number@i)^080h,f
	line	94
	
l5741:	
;uart_dbg.c: 94: num /= 10;
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@num+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@num)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	line	91
	
l5743:	
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u7591
	goto	u7590
u7591:
	goto	l5737
u7590:
	line	98
	
l5745:	
;uart_dbg.c: 95: }
;uart_dbg.c: 98: for(j = i; j > 0; j--)
	movf	(uart_send_number@i)^080h,w
	movwf	(uart_send_number@j)^080h
	
l5747:	
	movf	((uart_send_number@j)^080h),w
	btfss	status,2
	goto	u7601
	goto	u7600
u7601:
	goto	l5751
u7600:
	goto	l510
	line	99
	
l5751:	
;uart_dbg.c: 99: uart_send_char(buf[(unsigned char)(j - 1)]);
	movf	(uart_send_number@j)^080h,w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l5753:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decf	(uart_send_number@j)^080h,f
	goto	l5747
	line	100
	
l510:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1   27[BANK0 ] unsigned char 
;;  i               1   28[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/B00
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext9
__ptext9:	;psect for function _uart_send_char
psect	text9
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_char: [wreg+status,2+status,0]
;uart_send_char@c stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_char@c)
	line	38
	
l4165:	
;uart_dbg.c: 37: unsigned char i;
;uart_dbg.c: 38: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	39
;uart_dbg.c: 39: RC4 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l4167:	
;uart_dbg.c: 40: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u9287:
decfsz	(??_uart_send_char+0)+0,f
	goto	u9287
	nop2
opt asmopt_pop

	line	41
	
l4169:	
;uart_dbg.c: 41: for(i = 0; i < 8; i++)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(uart_send_char@i)
	line	42
	
l496:	
	line	43
;uart_dbg.c: 42: {
;uart_dbg.c: 43: if(c & 0x01)
	btfss	(uart_send_char@c),(0)&7
	goto	u4951
	goto	u4950
u4951:
	goto	l498
u4950:
	line	44
	
l4175:	
;uart_dbg.c: 44: RC4 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l4177
	line	45
	
l498:	
	line	46
;uart_dbg.c: 45: else
;uart_dbg.c: 46: RC4 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l4177:	
;uart_dbg.c: 47: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u9297:
decfsz	(??_uart_send_char+0)+0,f
	goto	u9297
	nop2
opt asmopt_pop

	line	48
	
l4179:	
;uart_dbg.c: 48: c >>= 1;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rrf	(uart_send_char@c),f
	line	41
	
l4181:	
	incf	(uart_send_char@i),f
	
l4183:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u4961
	goto	u4960
u4961:
	goto	l496
u4960:
	
l497:	
	line	50
;uart_dbg.c: 49: }
;uart_dbg.c: 50: RC4 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l4185:	
;uart_dbg.c: 51: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u9307:
decfsz	(??_uart_send_char+0)+0,f
	goto	u9307
	nop2
opt asmopt_pop

	line	52
	
l4187:	
;uart_dbg.c: 52: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l500:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   26[BANK0 ] unsigned int 
;;  dividend        2   28[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1   30[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   26[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       5       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext10
__ptext10:	;psect for function ___lwmod
psect	text10
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l4253:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u5081
	goto	u5080
u5081:
	goto	l4269
u5080:
	line	14
	
l4255:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l4259
	line	16
	
l4257:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l4259:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u5091
	goto	u5090
u5091:
	goto	l4257
u5090:
	line	20
	
l4261:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u5105
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u5105:
	skipc
	goto	u5101
	goto	u5100
u5101:
	goto	l4265
u5100:
	line	21
	
l4263:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l4265:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l4267:	
	decfsz	(___lwmod@counter),f
	goto	u5111
	goto	u5110
u5111:
	goto	l4261
u5110:
	line	25
	
l4269:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1126:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	_Do_NtcRead

;; *************** function _Do_NtcRead *****************
;; Defined at:
;;		line 298 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Read_Temperature
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	298
global __ptext11
__ptext11:	;psect for function _Do_NtcRead
psect	text11
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	298
	global	__size_of_Do_NtcRead
	__size_of_Do_NtcRead	equ	__end_of_Do_NtcRead-_Do_NtcRead
	
_Do_NtcRead:	
;incstack = 0
	opt	stack 2
; Regs used in _Do_NtcRead: [wreg+status,2+status,0+pclath+cstack]
	line	300
	
l6035:	
;main.c: 300: Read_Temperature();
	fcall	_Read_Temperature
	line	301
	
l409:	
	return
	opt stack 0
GLOBAL	__end_of_Do_NtcRead
	__end_of_Do_NtcRead:
	signat	_Do_NtcRead,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 31 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   25[BANK1 ] unsigned long 
;;  temp_x10        2   31[BANK1 ] unsigned int 
;;  ntcVal          2   29[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   66[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Do_NtcRead
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	31
global __ptext12
__ptext12:	;psect for function _Read_Temperature
psect	text12
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	31
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 2
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	36
	
l5691:	
;charge_mgr.c: 33: unsigned int ntcVal;
;charge_mgr.c: 34: unsigned int temp_x10;
;charge_mgr.c: 36: test_adc = ADC_Sample(18, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	37
	
l5693:	
;charge_mgr.c: 37: if(0xA5 != test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u7481
	goto	u7480
u7481:
	goto	l5697
u7480:
	goto	l543
	line	40
	
l5697:	
;charge_mgr.c: 40: ntcVal = adresult;
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal)^080h
	line	41
;charge_mgr.c: 41: if(ntcVal < 100 || ntcVal > 3996)
	movlw	0
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u7491
	goto	u7490
u7491:
	goto	l543
u7490:
	
l5699:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u7501
	goto	u7500
u7501:
	goto	l5701
u7500:
	goto	l543
	line	46
	
l5701:	
;charge_mgr.c: 44: {
;charge_mgr.c: 45: unsigned long rt;
;charge_mgr.c: 46: rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	010h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0
	movwf	(___lldiv@divisor)^080h

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0)
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0+1)
	clrf	((??_Read_Temperature+0)^080h+0+2)
	clrf	((??_Read_Temperature+0)^080h+0+3)
	movf	0+(??_Read_Temperature+0)^080h+0,w
	subwf	(___lldiv@divisor)^080h,f
	movf	1+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)^080h+0,w
	goto	u7515
	goto	u7516
u7515:
	subwf	(___lldiv@divisor+1)^080h,f
u7516:
	movf	2+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)^080h+0,w
	goto	u7517
	goto	u7518
u7517:
	subwf	(___lldiv@divisor+2)^080h,f
u7518:
	movf	3+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)^080h+0,w
	goto	u7519
	goto	u7510
u7519:
	subwf	(___lldiv@divisor+3)^080h,f
u7510:

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0
	movwf	(___lmul@multiplicand+2)^080h
	movlw	027h
	movwf	(___lmul@multiplicand+1)^080h
	movlw	010h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt)^080h

	line	47
	
l5703:	
;charge_mgr.c: 47: if(rt >= 10000UL)
		movf	(Read_Temperature@rt+3)^080h,w
	btfss	status,2
	goto	u7520
	movf	(Read_Temperature@rt+2)^080h,w
	btfss	status,2
	goto	u7520
	movlw	39
	subwf	(Read_Temperature@rt+1)^080h,w
	skipz
	goto	u7523
	movlw	16
	subwf	(Read_Temperature@rt)^080h,w
	skipz
	goto	u7523
u7523:
	btfss	status,0
	goto	u7521
	goto	u7520

u7521:
	goto	l5709
u7520:
	line	48
	
l5705:	
;charge_mgr.c: 48: temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l5707:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0F0h
	movwf	((??_Read_Temperature+0)^080h+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)^080h+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+3)
	movf	(Read_Temperature@rt)^080h,w
	addwf	(??_Read_Temperature+0)^080h+0,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+1)^080h,w
	goto	u7530
	goto	u7531
u7530:
	addwf	(??_Read_Temperature+0)^080h+1,f
u7531:
	movf	(Read_Temperature@rt+2)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+2)^080h,w
	goto	u7532
	goto	u7533
u7532:
	addwf	(??_Read_Temperature+0)^080h+2,f
u7533:
	movf	(Read_Temperature@rt+3)^080h,w
	skipnc
	incf	(Read_Temperature@rt+3)^080h,w
	addwf	(??_Read_Temperature+0)^080h+3,f
	movf	3+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+3)^080h
	movf	2+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+2)^080h
	movf	1+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+1)^080h
	movf	0+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier)^080h

	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(0+(?___lldiv))^080h,w
	subwf	(Read_Temperature@temp_x10)^080h,f
	movf	(1+(?___lldiv))^080h,w
	skipc
	decf	(Read_Temperature@temp_x10+1)^080h,f
	subwf	(Read_Temperature@temp_x10+1)^080h,f
	goto	l5713
	line	50
	
l5709:	
;charge_mgr.c: 49: else
;charge_mgr.c: 50: temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0
	movwf	(___lmul@multiplier+3)^080h
	movlw	0
	movwf	(___lmul@multiplier+2)^080h
	movlw	027h
	movwf	(___lmul@multiplier+1)^080h
	movlw	010h
	movwf	(___lmul@multiplier)^080h

	movf	(Read_Temperature@rt)^080h,w
	subwf	(___lmul@multiplier)^080h,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+1)^080h,w
	subwf	(___lmul@multiplier+1)^080h,f
	movf	(Read_Temperature@rt+2)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+2)^080h,w
	subwf	(___lmul@multiplier+2)^080h,f
	movf	(Read_Temperature@rt+3)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+3)^080h,w
	subwf	(___lmul@multiplier+3)^080h,f
	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10)^080h
	
l5711:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10)^080h,f
	skipnc
	incf	(Read_Temperature@temp_x10+1)^080h,f
	line	51
	
l5713:	
;charge_mgr.c: 51: if(temp_x10 < 100U) temp_x10 = 100U;
	movlw	0
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipnc
	goto	u7541
	goto	u7540
u7541:
	goto	l549
u7540:
	
l5715:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l549:	
	line	52
;charge_mgr.c: 52: if(temp_x10 > 750U) temp_x10 = 750U;
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipc
	goto	u7551
	goto	u7550
u7551:
	goto	l550
u7550:
	
l5717:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)^080h
	movlw	02h
	movwf	((Read_Temperature@temp_x10)^080h)+1
	
l550:	
	line	55
;charge_mgr.c: 53: }
;charge_mgr.c: 55: g_temperature = temp_x10;
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature)
	line	56
	
l5719:	
;charge_mgr.c: 56: if((temp_x10 / 10U) >= 60)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u7561
	goto	u7560
u7561:
	goto	l5723
u7560:
	line	57
	
l5721:	
;charge_mgr.c: 57: g_tempProtect = 1;
	clrf	(_g_tempProtect)
	incf	(_g_tempProtect),f
	goto	l543
	line	58
	
l5723:	
;charge_mgr.c: 58: else if((temp_x10 / 10U) <= 50)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u7571
	goto	u7570
u7571:
	goto	l543
u7570:
	line	59
	
l5725:	
;charge_mgr.c: 59: g_tempProtect = 0;
	clrf	(_g_tempProtect)
	line	62
	
l543:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	_Do_AdcSample

;; *************** function _Do_AdcSample *****************
;; Defined at:
;;		line 273 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  ch              1   14[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       1       0       0
;;      Temps:          0       0       1       0       0
;;      Totals:         0       0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	273
global __ptext13
__ptext13:	;psect for function _Do_AdcSample
psect	text13
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	273
	global	__size_of_Do_AdcSample
	__size_of_Do_AdcSample	equ	__end_of_Do_AdcSample-_Do_AdcSample
	
_Do_AdcSample:	
;incstack = 0
	opt	stack 3
; Regs used in _Do_AdcSample: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	275
	
l6021:	
;main.c: 275: unsigned char ch = s_adcChannels[g_scanIndex];
	movf	(_g_scanIndex),w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@ch)^080h
	line	280
	
l6023:	
;main.c: 280: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_Do_AdcSample+0)^080h+0),f
	u9317:
decfsz	(??_Do_AdcSample+0)^080h+0,f
	goto	u9317
	nop
opt asmopt_pop

	line	282
	
l6025:	
;main.c: 282: test_adc = ADC_Sample(ch, 0);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@adldo)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Do_AdcSample@ch)^080h,w
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	284
	
l6027:	
;main.c: 284: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u8021
	goto	u8020
u8021:
	goto	l6031
u8020:
	line	285
	
l6029:	
;main.c: 285: g_slot[g_scanIndex].voltage = adresult;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	movf	(_adresult),w	;volatile
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_adresult+1),w	;volatile
	movwf	indf
	goto	l6033
	line	287
	
l6031:	
;main.c: 286: else
;main.c: 287: g_slot[g_scanIndex].voltage = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	289
	
l6033:	
;main.c: 289: g_scanPhase = 1;
	movlw	low(01h)
	movwf	(_g_scanPhase)	;volatile
	line	290
	
l406:	
	return
	opt stack 0
GLOBAL	__end_of_Do_AdcSample
	__end_of_Do_AdcSample:
	signat	_Do_AdcSample,89
	global	_ChargeProcess_Slot

;; *************** function _ChargeProcess_Slot *****************
;; Defined at:
;;		line 102 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   33[BANK3 ] unsigned char 
;;  bat_mv_long     4   12[BANK3 ] unsigned long 
;;  vx_mv           4    8[BANK3 ] unsigned long 
;;  bat_mv          2   23[BANK3 ] unsigned int 
;;  bat_mv_long     4    4[BANK3 ] unsigned long 
;;  vx_mv           4    0[BANK3 ] unsigned long 
;;  bat_mv          2   21[BANK3 ] unsigned int 
;;  v_ref           2   19[BANK3 ] unsigned int 
;;  v_init          2   16[BANK3 ] unsigned int 
;;  v               2   31[BANK3 ] unsigned int 
;;  ct              2   29[BANK3 ] unsigned int 
;;  tick            2    0        unsigned int 
;;  ty              1   28[BANK3 ] unsigned char 
;;  st              1   27[BANK3 ] unsigned char 
;;  old_st          1   18[BANK3 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0      34       0
;;      Temps:          0       0       6       0       0
;;      Totals:         0       0       6      34       0
;;Total ram usage:       40 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		_Detect_BatteryType
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___wmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	102
global __ptext14
__ptext14:	;psect for function _ChargeProcess_Slot
psect	text14
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	102
	global	__size_of_ChargeProcess_Slot
	__size_of_ChargeProcess_Slot	equ	__end_of_ChargeProcess_Slot-_ChargeProcess_Slot
	
_ChargeProcess_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _ChargeProcess_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;ChargeProcess_Slot@idx stored from wreg
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@idx)^0180h
	line	106
	
l6177:	
	line	109
	
l6179:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	
l6181:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	
l6183:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@v)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v+1)^0180h
	
l6185:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ct)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@ct+1)^0180h
	line	110
	
l6187:	
;charge_mgr.c: 110: old_st = st;
	movf	(ChargeProcess_Slot@st)^0180h,w
	movwf	(ChargeProcess_Slot@old_st)^0180h
	line	112
;charge_mgr.c: 112: switch(st)
	goto	l6643
	line	115
	
l6189:	
;charge_mgr.c: 115: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	116
	
l6191:	
;charge_mgr.c: 116: st = 1;
	clrf	(ChargeProcess_Slot@st)^0180h
	incf	(ChargeProcess_Slot@st)^0180h,f
	line	117
;charge_mgr.c: 117: break;
	goto	l6645
	line	120
	
l6193:	
;charge_mgr.c: 120: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	121
;charge_mgr.c: 121: if(ct < (2 * 100))
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0C8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u8171
	goto	u8170
u8171:
	goto	l6197
u8170:
	goto	l6645
	line	122
	
l6195:	
;charge_mgr.c: 122: break;
	goto	l6645
	line	130
	
l6197:	
;charge_mgr.c: 130: if(ct == (2 * 100))
		movlw	200
	xorwf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u8181
	goto	u8180
u8181:
	goto	l6205
u8180:
	line	132
	
l6199:	
;charge_mgr.c: 131: {
;charge_mgr.c: 132: g_impRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	133
	
l6201:	
;charge_mgr.c: 133: if(v > 2900)
	movlw	0Bh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u8191
	goto	u8190
u8191:
	goto	l6645
u8190:
	line	134
	
l6203:	
;charge_mgr.c: 134: g_impRefV[idx] |= 0x8000;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	0
	iorwf	indf,f
	incf	fsr0,f
	movlw	080h
	iorwf	indf,f
	goto	l6645
	line	137
	
l6205:	
;charge_mgr.c: 136: }
;charge_mgr.c: 137: if(v > 2900 && v < 3990)
	movlw	0Bh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u8201
	goto	u8200
u8201:
	goto	l6223
u8200:
	
l6207:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u8211
	goto	u8210
u8211:
	goto	l6223
u8210:
	line	142
	
l6209:	
;charge_mgr.c: 138: {
;charge_mgr.c: 142: unsigned int v_init = g_impRefV[idx] & 0x0FFF;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_init)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_init+1)^0180h
	
l6211:	
	movlw	0FFh
	andwf	(ChargeProcess_Slot@v_init)^0180h,f
	movlw	0Fh
	andwf	(ChargeProcess_Slot@v_init+1)^0180h,f
	line	143
	
l6213:	
;charge_mgr.c: 143: if(v + 50 < v_init)
	movf	(ChargeProcess_Slot@v)^0180h,w
	addlw	low(032h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_init+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u8225
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_init)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u8225:
	skipnc
	goto	u8221
	goto	u8220
u8221:
	goto	l6217
u8220:
	line	145
	
l6215:	
;charge_mgr.c: 144: {
;charge_mgr.c: 145: g_impRefV[idx] = v | (g_impRefV[idx] & 0x8000);
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movlw	0
	andwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movlw	080h
	andwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	iorwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	movwf	(??_ChargeProcess_Slot+4)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	iorwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+4)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+4)^080h+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_ChargeProcess_Slot+4)^080h+0,w
	movwf	indf
	line	146
;charge_mgr.c: 146: g_detectLowCnt[idx] = 0;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	147
;charge_mgr.c: 147: }
	goto	l576
	line	150
	
l6217:	
;charge_mgr.c: 148: else
;charge_mgr.c: 149: {
;charge_mgr.c: 150: g_detectLowCnt[idx]++;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	151
	
l576:	
	line	152
;charge_mgr.c: 151: }
;charge_mgr.c: 152: if(g_detectLowCnt[idx] < 20)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u8231
	goto	u8230
u8231:
	goto	l6221
u8230:
	goto	l6645
	line	154
	
l6221:	
;charge_mgr.c: 154: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	155
;charge_mgr.c: 155: }
	goto	l6237
	line	156
	
l6223:	
;charge_mgr.c: 156: else if(ct < (2 * 100) + (8 * 100) && v < 3990)
	movlw	03h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0E8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u8241
	goto	u8240
u8241:
	goto	l6237
u8240:
	
l6225:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u8251
	goto	u8250
u8251:
	goto	l6237
u8250:
	line	158
	
l6227:	
;charge_mgr.c: 157: {
;charge_mgr.c: 158: unsigned int v_ref = g_impRefV[idx] & 0x0FFF;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_ref)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_ref+1)^0180h
	
l6229:	
	movlw	0FFh
	andwf	(ChargeProcess_Slot@v_ref)^0180h,f
	movlw	0Fh
	andwf	(ChargeProcess_Slot@v_ref+1)^0180h,f
	line	159
	
l6231:	
;charge_mgr.c: 159: if(v_ref < 3990 && v + 50 < v_ref)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v_ref+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v_ref)^0180h,w
	skipnc
	goto	u8261
	goto	u8260
u8261:
	goto	l6237
u8260:
	
l6233:	
	movf	(ChargeProcess_Slot@v)^0180h,w
	addlw	low(032h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_ref+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u8275
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_ref)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u8275:
	skipnc
	goto	u8271
	goto	u8270
u8271:
	goto	l6237
u8270:
	line	161
	
l6235:	
;charge_mgr.c: 160: {
;charge_mgr.c: 161: g_impRefV[idx] = v | (g_impRefV[idx] & 0x8000);
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movlw	0
	andwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movlw	080h
	andwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	iorwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	movwf	(??_ChargeProcess_Slot+4)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	iorwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+4)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+4)^080h+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_ChargeProcess_Slot+4)^080h+0,w
	movwf	indf
	line	162
;charge_mgr.c: 162: break;
	goto	l6645
	line	170
	
l6237:	
;charge_mgr.c: 163: }
;charge_mgr.c: 164: }
;charge_mgr.c: 170: if(v <= 2900 && (g_impRefV[idx] & 0x8000))
	movlw	0Bh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u8281
	goto	u8280
u8281:
	goto	l6245
u8280:
	
l6239:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	btfss	1+(??_ChargeProcess_Slot+0)^080h+0,(15)&7
	goto	u8291
	goto	u8290
u8291:
	goto	l6245
u8290:
	line	172
	
l6241:	
;charge_mgr.c: 171: {
;charge_mgr.c: 172: g_impRefV[idx] &= 0x0FFF;
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	0FFh
	andwf	indf,f
	incf	fsr0,f
	movlw	0Fh
	andwf	indf,f
	line	173
;charge_mgr.c: 173: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	174
	
l6243:	
;charge_mgr.c: 174: ty = 5;
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	175
;charge_mgr.c: 175: }
	goto	l6253
	line	178
	
l6245:	
;charge_mgr.c: 178: else if(v <= 2900 && v > 2200U)
	movlw	0Bh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u8301
	goto	u8300
u8301:
	goto	l6251
u8300:
	
l6247:	
	movlw	08h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	099h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u8311
	goto	u8310
u8311:
	goto	l6251
u8310:
	line	180
	
l6249:	
;charge_mgr.c: 179: {
;charge_mgr.c: 180: ty = 1;
	clrf	(ChargeProcess_Slot@ty)^0180h
	incf	(ChargeProcess_Slot@ty)^0180h,f
	line	181
;charge_mgr.c: 181: }
	goto	l6253
	line	184
	
l6251:	
;charge_mgr.c: 182: else
;charge_mgr.c: 183: {
;charge_mgr.c: 184: ty = Detect_BatteryType(v);
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Detect_BatteryType@voltage+1)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	189
	
l6253:	
;charge_mgr.c: 185: }
;charge_mgr.c: 189: if(v < 500)
	movlw	01h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0F4h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u8321
	goto	u8320
u8321:
	goto	l6259
u8320:
	line	191
	
l6255:	
;charge_mgr.c: 190: {
;charge_mgr.c: 191: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	192
;charge_mgr.c: 192: if(g_detectLowCnt[idx] < 5)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u8331
	goto	u8330
u8331:
	goto	l6265
u8330:
	goto	l6645
	line	196
	
l6259:	
;charge_mgr.c: 196: else if(ty != 5 && ty != 1)
		movlw	5
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u8341
	goto	u8340
u8341:
	goto	l6265
u8340:
	
l6261:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u8351
	goto	u8350
u8351:
	goto	l6265
u8350:
	line	198
	
l6263:	
;charge_mgr.c: 197: {
;charge_mgr.c: 198: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	201
	
l6265:	
;charge_mgr.c: 199: }
;charge_mgr.c: 201: if(ty == 5)
		movlw	5
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u8361
	goto	u8360
u8361:
	goto	l6291
u8360:
	line	208
	
l6267:	
;charge_mgr.c: 202: {
;charge_mgr.c: 208: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	209
;charge_mgr.c: 209: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8371
	goto	u8370
u8371:
	goto	l6271
u8370:
	goto	l6645
	line	213
	
l6271:	
;charge_mgr.c: 213: if(g_impCheckSlot != 0xFF && g_impCheckSlot != idx)
	bcf	status, 6	;RP1=0, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u8381
	goto	u8380
u8381:
	goto	l6277
u8380:
	
l6273:	
	movf	(_g_impCheckSlot)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	xorwf	(ChargeProcess_Slot@idx)^0180h,w
	skipnz
	goto	u8391
	goto	u8390
u8391:
	goto	l6277
u8390:
	goto	l6645
	line	215
	
l6277:	
;charge_mgr.c: 215: g_impCheckSlot = idx;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	219
	
l6279:	
;charge_mgr.c: 219: if(0xA5 == ADC_Sample(31, 0))
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u8401
	goto	u8400
u8401:
	goto	l6283
u8400:
	line	220
	
l6281:	
;charge_mgr.c: 220: g_vcc_mv = (unsigned int)((4096UL * 1200UL) / adresult);
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(0+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	line	223
	
l6283:	
;charge_mgr.c: 223: g_impRefV[idx] = v | ((unsigned int)(((g_vcc_mv + 50U) / 100U) - 38U) << 12);
	movlw	064h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(0+?___lwdiv),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+?___lwdiv),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	swapf	(??_ChargeProcess_Slot+0)^080h+0,w
	andlw	0f0h
	movwf	(??_ChargeProcess_Slot+0)^080h+1
	clrf	(??_ChargeProcess_Slot+0)^080h+0
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(0A000h)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(0A000h)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	iorwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	movwf	(??_ChargeProcess_Slot+4)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	iorwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+4)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+4)^080h+0,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	1+(??_ChargeProcess_Slot+4)^080h+0,w
	movwf	indf
	line	224
	
l6285:	
;charge_mgr.c: 224: st = 8;
	movlw	low(08h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	225
	
l6287:	
;charge_mgr.c: 225: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	226
	
l6289:	
;charge_mgr.c: 226: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	227
;charge_mgr.c: 227: }
	goto	l6645
	line	228
	
l6291:	
;charge_mgr.c: 228: else if(ty == 1)
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u8411
	goto	u8410
u8411:
	goto	l6351
u8410:
	line	231
	
l6293:	
;charge_mgr.c: 229: {
;charge_mgr.c: 231: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	232
;charge_mgr.c: 232: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8421
	goto	u8420
u8421:
	goto	l6297
u8420:
	goto	l6645
	line	239
	
l6297:	
;charge_mgr.c: 238: {
;charge_mgr.c: 239: unsigned long vx_mv = (unsigned long)v * (unsigned long)g_vcc_mv / 4096UL;
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@vx_mv+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@vx_mv+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@vx_mv+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@vx_mv)^0180h

	
l6299:	
	movlw	0Ch
u8435:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv+3)^0180h,f
	rrf	(ChargeProcess_Slot@vx_mv+2)^0180h,f
	rrf	(ChargeProcess_Slot@vx_mv+1)^0180h,f
	rrf	(ChargeProcess_Slot@vx_mv)^0180h,f
	addlw	-1
	skipz
	goto	u8435

	line	240
	
l6301:	
;charge_mgr.c: 240: unsigned long bat_mv_long = 124UL * vx_mv + 206UL * (unsigned long)g_vcc_mv;
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long)^0180h

	
l6303:	
	movf	(ChargeProcess_Slot@vx_mv+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier+3)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@vx_mv+2)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier+2)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@vx_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@vx_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long)^0180h,f
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8441
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long+1)^0180h,f
u8441:
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8442
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long+2)^0180h,f
u8442:
	bcf	status, 6	;RP1=0, select bank1
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8443
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long+3)^0180h,f
u8443:
	bcf	status, 6	;RP1=0, select bank1
	bsf	status, 6	;RP1=1, select bank3

	line	241
	
l6305:	
;charge_mgr.c: 241: unsigned int bat_mv = (unsigned int)((bat_mv_long + 1000UL/2UL) / 1000UL);
	movlw	0
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long+1)^0180h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+1)^0180h,w
	goto	u8450
	goto	u8451
u8450:
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u8451:
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long+2)^0180h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+2)^0180h,w
	goto	u8452
	goto	u8453
u8452:
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u8453:
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long+3)^0180h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv)^0180h
	line	243
	
l6307:	
;charge_mgr.c: 243: if(bat_mv <= 100)
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u8461
	goto	u8460
u8461:
	goto	l6317
u8460:
	line	245
	
l6309:	
;charge_mgr.c: 244: {
;charge_mgr.c: 245: st = 2;
	movlw	low(02h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	246
	
l6311:	
;charge_mgr.c: 246: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	247
	
l6313:	
;charge_mgr.c: 247: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l6289
	line	250
	
l6317:	
;charge_mgr.c: 250: else if(bat_mv < 900)
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u8471
	goto	u8470
u8471:
	goto	l6327
u8470:
	line	252
	
l6319:	
;charge_mgr.c: 251: {
;charge_mgr.c: 252: st = 3;
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l6311
	line	257
	
l6327:	
;charge_mgr.c: 257: else if(bat_mv >= 1520)
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipc
	goto	u8481
	goto	u8480
u8481:
	goto	l6339
u8480:
	line	259
	
l6329:	
;charge_mgr.c: 258: {
;charge_mgr.c: 259: st = 5;
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	260
	
l6331:	
;charge_mgr.c: 260: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	261
	
l6333:	
;charge_mgr.c: 261: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	262
	
l6335:	
;charge_mgr.c: 262: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	263
	
l6337:	
;charge_mgr.c: 263: g_impRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	264
;charge_mgr.c: 264: }
	goto	l6645
	line	267
	
l6339:	
;charge_mgr.c: 265: else
;charge_mgr.c: 266: {
;charge_mgr.c: 267: st = 4;
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	268
	
l6341:	
;charge_mgr.c: 268: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	269
	
l6343:	
;charge_mgr.c: 269: g_ccBlocks[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6333
	line	276
	
l6351:	
;charge_mgr.c: 276: else if(ty == 0)
	movf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u8491
	goto	u8490
u8491:
	goto	l6365
u8490:
	line	279
	
l6353:	
;charge_mgr.c: 277: {
;charge_mgr.c: 279: if(v >= 3990)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u8501
	goto	u8500
u8501:
	goto	l6361
u8500:
	line	283
	
l6355:	
;charge_mgr.c: 280: {
;charge_mgr.c: 283: if(ct < (2 * 100) + (8 * 100))
	movlw	03h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0E8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u8511
	goto	u8510
u8511:
	goto	l6359
u8510:
	goto	l6645
	line	285
	
l6359:	
;charge_mgr.c: 285: st = 0;
	clrf	(ChargeProcess_Slot@st)^0180h
	line	286
;charge_mgr.c: 286: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	287
;charge_mgr.c: 287: }
	goto	l6289
	line	290
	
l6361:	
;charge_mgr.c: 288: else
;charge_mgr.c: 289: {
;charge_mgr.c: 290: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l6289
	line	294
	
l6365:	
;charge_mgr.c: 294: else if(ty == 2 || ty == 3)
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u8521
	goto	u8520
u8521:
	goto	l6369
u8520:
	
l6367:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u8531
	goto	u8530
u8531:
	goto	l6195
u8530:
	line	296
	
l6369:	
;charge_mgr.c: 295: {
;charge_mgr.c: 296: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	297
	
l6371:	
;charge_mgr.c: 297: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	298
	
l6373:	
;charge_mgr.c: 298: g_detectLogSlot = idx;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	299
	
l6375:	
;charge_mgr.c: 299: g_detectLogType = ty;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ty)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogType)	;volatile
	line	300
	
l6377:	
;charge_mgr.c: 300: g_detectLogFlag = 1;
	bsf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	goto	l6645
	line	305
	
l6379:	
;charge_mgr.c: 305: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	306
	
l6381:	
;charge_mgr.c: 306: if(ct < 1)
	movf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u8541
	goto	u8540
u8541:
	goto	l6385
u8540:
	goto	l6645
	line	313
	
l6385:	
;charge_mgr.c: 309: {
;charge_mgr.c: 313: if(0xA5 == ADC_Sample(31, 0))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u8551
	goto	u8550
u8551:
	goto	l6389
u8550:
	line	314
	
l6387:	
;charge_mgr.c: 314: g_vcc_mv = (unsigned int)((4096UL * 1200UL) / adresult);
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(0+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	line	321
	
l6389:	
;charge_mgr.c: 321: if(((((g_impRefV[idx] >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 300U)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___wmul@multiplier)
	incf	fsr0,f
	movf	indf,w
	movwf	(___wmul@multiplier+1)
	movlw	0Ch
	
u8565:
	clrc
	rrf	(___wmul@multiplier+1),f
	rrf	(___wmul@multiplier),f
	addlw	-1
	skipz
	goto	u8565
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(012Ch)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(012Ch)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u8575
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u8575:
	skipnc
	goto	u8571
	goto	u8570
u8571:
	goto	l6395
u8570:
	line	323
	
l6391:	
;charge_mgr.c: 322: {
;charge_mgr.c: 323: ty = 2;
	movlw	low(02h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	324
;charge_mgr.c: 324: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	325
;charge_mgr.c: 325: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	326
;charge_mgr.c: 326: g_detectLogSlot = idx;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	327
;charge_mgr.c: 327: g_detectLogType = 2;
	movlw	low(02h)
	movwf	(_g_detectLogType)	;volatile
	goto	l6377
	line	336
	
l6395:	
;charge_mgr.c: 330: }
;charge_mgr.c: 336: if(v >= 3990)
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u8581
	goto	u8580
u8581:
	goto	l6401
u8580:
	line	338
	
l6397:	
;charge_mgr.c: 337: {
;charge_mgr.c: 338: ty = 0;
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	339
;charge_mgr.c: 339: st = 0;
	clrf	(ChargeProcess_Slot@st)^0180h
	line	340
	
l6399:	
;charge_mgr.c: 340: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	341
;charge_mgr.c: 341: break;
	goto	l6645
	line	349
	
l6401:	
;charge_mgr.c: 342: }
;charge_mgr.c: 349: if(((((g_impRefV[idx] >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 200U)
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___wmul@multiplier)
	incf	fsr0,f
	movf	indf,w
	movwf	(___wmul@multiplier+1)
	movlw	0Ch
	
u8595:
	clrc
	rrf	(___wmul@multiplier+1),f
	rrf	(___wmul@multiplier),f
	addlw	-1
	skipz
	goto	u8595
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(0C8h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u8605
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u8605:
	skipnc
	goto	u8601
	goto	u8600
u8601:
	goto	l6405
u8600:
	goto	l6419
	line	356
	
l6405:	
;charge_mgr.c: 356: if((g_impRefV[idx] & 0x0FFFU) > 2300U)
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movlw	0FFh
	andwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movlw	0Fh
	andwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	08h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u8611
	goto	u8610
u8611:
	goto	l6409
u8610:
	goto	l6419
	line	366
	
l6409:	
;charge_mgr.c: 366: ty = 3;
	movlw	low(03h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	367
;charge_mgr.c: 367: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	368
;charge_mgr.c: 368: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	369
	
l6411:	
;charge_mgr.c: 369: g_detectLowCnt[idx] = 0;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	370
	
l6413:	
;charge_mgr.c: 370: g_detectLogSlot = idx;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	371
	
l6415:	
;charge_mgr.c: 371: g_detectLogType = 3;
	movlw	low(03h)
	movwf	(_g_detectLogType)	;volatile
	goto	l6377
	line	379
	
l6419:	
;charge_mgr.c: 378: {
;charge_mgr.c: 379: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	line	380
	
l6421:	
;charge_mgr.c: 380: ty = 1;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	incf	(ChargeProcess_Slot@ty)^0180h,f
	line	382
	
l6423:	
;charge_mgr.c: 381: {
;charge_mgr.c: 382: unsigned long vx_mv = (unsigned long)v * (unsigned long)g_vcc_mv / 4096UL;
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@vx_mv_383+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@vx_mv_383+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@vx_mv_383+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@vx_mv_383)^0180h

	
l6425:	
	movlw	0Ch
u8625:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_383+3)^0180h,f
	rrf	(ChargeProcess_Slot@vx_mv_383+2)^0180h,f
	rrf	(ChargeProcess_Slot@vx_mv_383+1)^0180h,f
	rrf	(ChargeProcess_Slot@vx_mv_383)^0180h,f
	addlw	-1
	skipz
	goto	u8625

	line	383
	
l6427:	
;charge_mgr.c: 383: unsigned long bat_mv_long = 124UL * vx_mv + 206UL * (unsigned long)g_vcc_mv;
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long_384+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long_384+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long_384+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long_384)^0180h

	
l6429:	
	movf	(ChargeProcess_Slot@vx_mv_383+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier+3)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@vx_mv_383+2)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier+2)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@vx_mv_383+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@vx_mv_383)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long_384)^0180h,f
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8631
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long_384+1)^0180h,f
u8631:
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8632
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long_384+2)^0180h,f
u8632:
	bcf	status, 6	;RP1=0, select bank1
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8633
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long_384+3)^0180h,f
u8633:
	bcf	status, 6	;RP1=0, select bank1
	bsf	status, 6	;RP1=1, select bank3

	line	384
	
l6431:	
;charge_mgr.c: 384: unsigned int bat_mv = (unsigned int)((bat_mv_long + 1000UL/2UL) / 1000UL);
	movlw	0
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long_384)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long_384+1)^0180h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_384+1)^0180h,w
	goto	u8640
	goto	u8641
u8640:
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u8641:
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long_384+2)^0180h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_384+2)^0180h,w
	goto	u8642
	goto	u8643
u8642:
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u8643:
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long_384+3)^0180h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_384+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_385+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_385)^0180h
	line	386
	
l6433:	
;charge_mgr.c: 386: if(bat_mv <= 100)
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_385+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_385)^0180h,w
	skipnc
	goto	u8651
	goto	u8650
u8651:
	goto	l6437
u8650:
	line	387
	
l6435:	
;charge_mgr.c: 387: st = 2;
	movlw	low(02h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l6453
	line	388
	
l6437:	
;charge_mgr.c: 388: else if(bat_mv < 900)
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_385+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_385)^0180h,w
	skipnc
	goto	u8661
	goto	u8660
u8661:
	goto	l6441
u8660:
	line	389
	
l6439:	
;charge_mgr.c: 389: st = 3;
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l6453
	line	390
	
l6441:	
;charge_mgr.c: 390: else if(bat_mv >= 1520)
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_385+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_385)^0180h,w
	skipc
	goto	u8671
	goto	u8670
u8671:
	goto	l6447
u8670:
	line	392
	
l6443:	
;charge_mgr.c: 391: {
;charge_mgr.c: 392: st = 5;
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	393
	
l6445:	
;charge_mgr.c: 393: g_impRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	394
;charge_mgr.c: 394: }
	goto	l6453
	line	397
	
l6447:	
;charge_mgr.c: 395: else
;charge_mgr.c: 396: {
;charge_mgr.c: 397: st = 4;
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	398
	
l6449:	
;charge_mgr.c: 398: g_ccBlocks[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6445
	line	401
	
l6453:	
;charge_mgr.c: 400: }
;charge_mgr.c: 401: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	402
	
l6455:	
;charge_mgr.c: 402: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	405
;charge_mgr.c: 403: }
;charge_mgr.c: 404: }
;charge_mgr.c: 405: break;
	goto	l6645
	line	410
	
l6457:	
;charge_mgr.c: 410: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	411
;charge_mgr.c: 411: if(ct > (60 * 100))
	movlw	017h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	071h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u8681
	goto	u8680
u8681:
	goto	l6461
u8680:
	line	413
	
l6459:	
;charge_mgr.c: 412: {
;charge_mgr.c: 413: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	414
;charge_mgr.c: 414: break;
	goto	l6645
	line	416
	
l6461:	
;charge_mgr.c: 415: }
;charge_mgr.c: 416: if(v > 750)
	movlw	02h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u8691
	goto	u8690
u8691:
	goto	l6467
u8690:
	line	418
	
l6463:	
;charge_mgr.c: 417: {
;charge_mgr.c: 418: st = 3;
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	419
	
l6465:	
;charge_mgr.c: 419: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	420
;charge_mgr.c: 420: break;
	goto	l6645
	line	422
	
l6467:	
;charge_mgr.c: 421: }
;charge_mgr.c: 422: if(v >= 3850)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u8701
	goto	u8700
u8701:
	goto	l6645
u8700:
	goto	l6459
	line	430
	
l6471:	
;charge_mgr.c: 430: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	431
;charge_mgr.c: 431: if(ct > (300 * 100))
	movlw	075h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	031h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u8711
	goto	u8710
u8711:
	goto	l6475
u8710:
	goto	l6459
	line	436
	
l6475:	
;charge_mgr.c: 435: }
;charge_mgr.c: 436: if(v >= 3850)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u8721
	goto	u8720
u8721:
	goto	l6481
u8720:
	line	438
	
l6477:	
;charge_mgr.c: 437: {
;charge_mgr.c: 438: g_ovCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	439
;charge_mgr.c: 439: if(g_ovCnt[idx] >= 5)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u8731
	goto	u8730
u8731:
	goto	l6483
u8730:
	goto	l6459
	line	447
	
l6481:	
;charge_mgr.c: 445: else
;charge_mgr.c: 446: {
;charge_mgr.c: 447: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	449
	
l6483:	
;charge_mgr.c: 448: }
;charge_mgr.c: 449: if(v >= 2700)
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	08Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u8741
	goto	u8740
u8741:
	goto	l6645
u8740:
	line	451
	
l6485:	
;charge_mgr.c: 450: {
;charge_mgr.c: 451: st = 4;
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	452
	
l6487:	
;charge_mgr.c: 452: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	453
	
l6489:	
;charge_mgr.c: 453: g_ccBlocks[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	454
	
l6491:	
;charge_mgr.c: 454: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l6337
	line	460
	
l6495:	
;charge_mgr.c: 460: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	461
;charge_mgr.c: 461: if(ct >= (600 * 100))
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	060h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u8751
	goto	u8750
u8751:
	goto	l6501
u8750:
	line	463
	
l6497:	
;charge_mgr.c: 462: {
;charge_mgr.c: 463: ct -= (600 * 100);
	movlw	060h
	subwf	(ChargeProcess_Slot@ct)^0180h,f
	movlw	0EAh
	skipc
	decf	(ChargeProcess_Slot@ct+1)^0180h,f
	subwf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	464
	
l6499:	
;charge_mgr.c: 464: g_ccBlocks[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	466
	
l6501:	
;charge_mgr.c: 465: }
;charge_mgr.c: 466: if(g_ccBlocks[idx] >= 18)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(012h)
	subwf	indf,w
	skipc
	goto	u8761
	goto	u8760
u8761:
	goto	l6505
u8760:
	goto	l6459
	line	476
	
l6505:	
;charge_mgr.c: 470: }
;charge_mgr.c: 476: if(v > g_impRefV[idx]) g_impRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u8775
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u8775:
	skipnc
	goto	u8771
	goto	u8770
u8771:
	goto	l638
u8770:
	
l6507:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	
l638:	
	line	477
;charge_mgr.c: 477: if(g_impRefV[idx] - v > 500)
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u8781
	goto	u8780
u8781:
	goto	l6521
u8780:
	line	479
	
l6509:	
;charge_mgr.c: 478: {
;charge_mgr.c: 479: g_detectLowCnt[idx]++;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	480
;charge_mgr.c: 480: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8791
	goto	u8790
u8791:
	goto	l6513
u8790:
	goto	l6645
	line	482
	
l6513:	
;charge_mgr.c: 482: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	483
	
l6515:	
;charge_mgr.c: 483: st = 1;
	clrf	(ChargeProcess_Slot@st)^0180h
	incf	(ChargeProcess_Slot@st)^0180h,f
	goto	l6465
	line	489
	
l6521:	
;charge_mgr.c: 487: else
;charge_mgr.c: 488: {
;charge_mgr.c: 489: g_detectLowCnt[idx] = 0;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	496
	
l6523:	
;charge_mgr.c: 490: }
;charge_mgr.c: 496: if(v >= 3990 && ty == 1)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u8801
	goto	u8800
u8801:
	goto	l6531
u8800:
	
l6525:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u8811
	goto	u8810
u8811:
	goto	l6531
u8810:
	line	498
	
l6527:	
;charge_mgr.c: 497: {
;charge_mgr.c: 498: st = 6;
	movlw	low(06h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l6465
	line	503
	
l6531:	
;charge_mgr.c: 501: }
;charge_mgr.c: 503: if(v >= 3850)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u8821
	goto	u8820
u8821:
	goto	l6537
u8820:
	line	505
	
l6533:	
;charge_mgr.c: 504: {
;charge_mgr.c: 505: g_ovCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	506
;charge_mgr.c: 506: if(g_ovCnt[idx] >= 5)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u8831
	goto	u8830
u8831:
	goto	l6195
u8830:
	goto	l6459
	line	514
	
l6537:	
;charge_mgr.c: 512: else
;charge_mgr.c: 513: {
;charge_mgr.c: 514: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	515
	
l6539:	
;charge_mgr.c: 515: if(v >= 3100)
	movlw	0Ch
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	01Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u8841
	goto	u8840
u8841:
	goto	l6195
u8840:
	line	517
	
l6541:	
;charge_mgr.c: 516: {
;charge_mgr.c: 517: st = 5;
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l6465
	line	524
	
l6545:	
;charge_mgr.c: 524: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	525
;charge_mgr.c: 525: if(ct > (600 * 100))
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	061h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u8851
	goto	u8850
u8851:
	goto	l648
u8850:
	line	526
	
l6547:	
;charge_mgr.c: 526: st = 6;
	movlw	low(06h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l648:	
	line	534
;charge_mgr.c: 534: if(v >= 3990)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u8861
	goto	u8860
u8861:
	goto	l6573
u8860:
	line	536
	
l6549:	
;charge_mgr.c: 535: {
;charge_mgr.c: 536: if(ty == 1)
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u8871
	goto	u8870
u8871:
	goto	l6561
u8870:
	line	538
	
l6551:	
;charge_mgr.c: 537: {
;charge_mgr.c: 538: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	539
;charge_mgr.c: 539: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8881
	goto	u8880
u8881:
	goto	l6555
u8880:
	goto	l6645
	line	541
	
l6555:	
;charge_mgr.c: 541: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6527
	line	546
	
l6561:	
;charge_mgr.c: 545: }
;charge_mgr.c: 546: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	547
;charge_mgr.c: 547: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8891
	goto	u8890
u8891:
	goto	l6565
u8890:
	goto	l6645
	line	549
	
l6565:	
;charge_mgr.c: 549: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	550
	
l6567:	
;charge_mgr.c: 550: ty = 0;
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	551
	
l6569:	
;charge_mgr.c: 551: st = 0;
	clrf	(ChargeProcess_Slot@st)^0180h
	goto	l6465
	line	555
	
l6573:	
;charge_mgr.c: 554: }
;charge_mgr.c: 555: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	558
	
l6575:	
;charge_mgr.c: 558: if(v >= 3850)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u8901
	goto	u8900
u8901:
	goto	l6455
u8900:
	line	560
	
l6577:	
;charge_mgr.c: 559: {
;charge_mgr.c: 560: g_ovCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	561
;charge_mgr.c: 561: if(g_ovCnt[idx] >= 5)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u8911
	goto	u8910
u8911:
	goto	l6195
u8910:
	goto	l6459
	line	580
	
l6583:	
;charge_mgr.c: 580: if(ty == 1)
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u8921
	goto	u8920
u8921:
	goto	l6587
u8920:
	goto	l6645
	line	583
	
l6587:	
;charge_mgr.c: 583: if(v < (3100 - 10))
	movlw	0Ch
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	012h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u8931
	goto	u8930
u8931:
	goto	l6289
u8930:
	line	585
	
l6589:	
;charge_mgr.c: 584: {
;charge_mgr.c: 585: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	586
;charge_mgr.c: 586: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8941
	goto	u8940
u8941:
	goto	l6593
u8940:
	goto	l6645
	line	588
	
l6593:	
;charge_mgr.c: 588: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	589
	
l6595:	
;charge_mgr.c: 589: st = 4;
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	590
	
l6597:	
;charge_mgr.c: 590: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	goto	l6491
	line	602
	
l6605:	
;charge_mgr.c: 602: if(v >= 3990)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u8951
	goto	u8950
u8951:
	goto	l6619
u8950:
	line	604
	
l6607:	
;charge_mgr.c: 603: {
;charge_mgr.c: 604: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	605
;charge_mgr.c: 605: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8961
	goto	u8960
u8961:
	goto	l6565
u8960:
	goto	l6645
	line	616
	
l6619:	
;charge_mgr.c: 612: }
;charge_mgr.c: 616: if(ty == 2 || ty == 3)
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u8971
	goto	u8970
u8971:
	goto	l6289
u8970:
	
l6621:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u8981
	goto	u8980
u8981:
	goto	l6625
u8980:
	goto	l6289
	line	622
	
l6625:	
;charge_mgr.c: 620: }
;charge_mgr.c: 622: if(v > 750)
	movlw	02h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u8991
	goto	u8990
u8991:
	goto	l6289
u8990:
	line	624
	
l6627:	
;charge_mgr.c: 623: {
;charge_mgr.c: 624: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	625
;charge_mgr.c: 625: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9001
	goto	u9000
u9001:
	goto	l6513
u9000:
	goto	l6645
	line	638
	
l6639:	
;charge_mgr.c: 638: st = 0;
	clrf	(ChargeProcess_Slot@st)^0180h
	line	639
;charge_mgr.c: 639: break;
	goto	l6645
	line	112
	
l6643:	
	movf	(ChargeProcess_Slot@st)^0180h,w
	; Switch size 1, requested type "space"
; Number of cases is 9, Range of values is 0 to 8
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           28    15 (average)
; direct_byte           35     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l6189
	xorlw	1^0	; case 1
	skipnz
	goto	l6193
	xorlw	2^1	; case 2
	skipnz
	goto	l6457
	xorlw	3^2	; case 3
	skipnz
	goto	l6471
	xorlw	4^3	; case 4
	skipnz
	goto	l6495
	xorlw	5^4	; case 5
	skipnz
	goto	l6545
	xorlw	6^5	; case 6
	skipnz
	goto	l6583
	xorlw	7^6	; case 7
	skipnz
	goto	l6605
	xorlw	8^7	; case 8
	skipnz
	goto	l6379
	goto	l6639
	opt asmopt_pop

	line	642
	
l6645:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@st)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ty)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ct)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@ct+1)^0180h,w
	movwf	indf
	line	645
	
l6647:	
;charge_mgr.c: 645: if(idx <= 4 && st != old_st)
	movlw	low(05h)
	subwf	(ChargeProcess_Slot@idx)^0180h,w
	skipnc
	goto	u9011
	goto	u9010
u9011:
	goto	l674
u9010:
	
l6649:	
	movf	(ChargeProcess_Slot@st)^0180h,w
	xorwf	(ChargeProcess_Slot@old_st)^0180h,w
	skipnz
	goto	u9021
	goto	u9020
u9021:
	goto	l674
u9020:
	line	647
	
l6651:	
;charge_mgr.c: 646: {
;charge_mgr.c: 647: g_dbgSlot = idx;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_dbgSlot)	;volatile
	line	648
;charge_mgr.c: 648: g_dbgOldState = old_st;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@old_st)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_dbgOldState)	;volatile
	line	649
;charge_mgr.c: 649: g_dbgNewState = st;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@st)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_dbgNewState)	;volatile
	line	650
;charge_mgr.c: 650: g_dbgNewType = ty;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ty)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_dbgNewType)	;volatile
	line	651
;charge_mgr.c: 651: g_dbgVoltage = v;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_dbgVoltage+1)^080h	;volatile
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_dbgVoltage)^080h	;volatile
	line	652
	
l6653:	
;charge_mgr.c: 652: g_dbgDetectFlag = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	654
	
l674:	
	return
	opt stack 0
GLOBAL	__end_of_ChargeProcess_Slot
	__end_of_ChargeProcess_Slot:
	signat	_ChargeProcess_Slot,4217
	global	___wmul

;; *************** function ___wmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
;; Parameters:    Size  Location     Type
;;  multiplier      2   26[BANK0 ] unsigned int 
;;  multiplicand    2   28[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  product         2    0[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   26[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       0       2       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       2       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
global __ptext15
__ptext15:	;psect for function ___wmul
psect	text15
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
	global	__size_of___wmul
	__size_of___wmul	equ	__end_of___wmul-___wmul
	
___wmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___wmul: [wreg+status,2+status,0]
	line	43
	
l5757:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___wmul@product)^080h
	clrf	(___wmul@product+1)^080h
	line	45
	
l5759:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(___wmul@multiplier),(0)&7
	goto	u7611
	goto	u7610
u7611:
	goto	l5763
u7610:
	line	46
	
l5761:	
	movf	(___wmul@multiplicand),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(___wmul@product)^080h,f
	skipnc
	incf	(___wmul@product+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(___wmul@multiplicand+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(___wmul@product+1)^080h,f
	line	47
	
l5763:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(___wmul@multiplicand),f
	rlf	(___wmul@multiplicand+1),f
	line	48
	
l5765:	
	clrc
	rrf	(___wmul@multiplier+1),f
	rrf	(___wmul@multiplier),f
	line	49
	
l5767:	
	movf	((___wmul@multiplier)),w
iorwf	((___wmul@multiplier+1)),w
	btfss	status,2
	goto	u7621
	goto	u7620
u7621:
	goto	l5759
u7620:
	line	52
	
l5769:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___wmul@product+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___wmul+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(___wmul@product)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___wmul)
	line	53
	
l779:	
	return
	opt stack 0
GLOBAL	__end_of___wmul
	__end_of___wmul:
	signat	___wmul,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   26[BANK0 ] unsigned int 
;;  dividend        2   28[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    1[BANK1 ] unsigned int 
;;  counter         1    0[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   26[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       0       3       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       3       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext16
__ptext16:	;psect for function ___lwdiv
psect	text16
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l5665:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___lwdiv@quotient)^080h
	clrf	(___lwdiv@quotient+1)^080h
	line	15
	
l5667:	
	bcf	status, 5	;RP0=0, select bank0
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u7441
	goto	u7440
u7441:
	goto	l5687
u7440:
	line	16
	
l5669:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___lwdiv@counter)^080h
	incf	(___lwdiv@counter)^080h,f
	line	17
	goto	l5673
	line	18
	
l5671:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	bsf	status, 5	;RP0=1, select bank1
	incf	(___lwdiv@counter)^080h,f
	line	17
	
l5673:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u7451
	goto	u7450
u7451:
	goto	l5671
u7450:
	line	22
	
l5675:	
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(___lwdiv@quotient)^080h,f
	rlf	(___lwdiv@quotient+1)^080h,f
	line	23
	
l5677:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u7465
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u7465:
	skipc
	goto	u7461
	goto	u7460
u7461:
	goto	l5683
u7460:
	line	24
	
l5679:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l5681:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(___lwdiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l5683:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l5685:	
	bsf	status, 5	;RP0=1, select bank1
	decfsz	(___lwdiv@counter)^080h,f
	goto	u7471
	goto	u7470
u7471:
	goto	l5675
u7470:
	line	30
	
l5687:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lwdiv@quotient+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lwdiv+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lwdiv@quotient)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lwdiv)
	line	31
	
l1116:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    0[BANK1 ] unsigned long 
;;  multiplicand    4    4[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4   26[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    0[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       8       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext17
__ptext17:	;psect for function ___lmul
psect	text17
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l5653:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l788:	
	line	121
	bsf	status, 5	;RP0=1, select bank1
	btfss	(___lmul@multiplier)^080h,(0)&7
	goto	u7411
	goto	u7410
u7411:
	goto	l5657
u7410:
	line	122
	
l5655:	
	movf	(___lmul@multiplicand)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product),f
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lmul@multiplicand+1)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7421
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product+1),f
u7421:
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lmul@multiplicand+2)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7422
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product+2),f
u7422:
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lmul@multiplicand+3)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7423
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product+3),f
u7423:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 5	;RP0=0, select bank0

	line	123
	
l5657:	
	clrc
	bsf	status, 5	;RP0=1, select bank1
	rlf	(___lmul@multiplicand)^080h,f
	rlf	(___lmul@multiplicand+1)^080h,f
	rlf	(___lmul@multiplicand+2)^080h,f
	rlf	(___lmul@multiplicand+3)^080h,f
	line	124
	
l5659:	
	clrc
	rrf	(___lmul@multiplier+3)^080h,f
	rrf	(___lmul@multiplier+2)^080h,f
	rrf	(___lmul@multiplier+1)^080h,f
	rrf	(___lmul@multiplier)^080h,f
	line	125
	movf	(___lmul@multiplier+3)^080h,w
	iorwf	(___lmul@multiplier+2)^080h,w
	iorwf	(___lmul@multiplier+1)^080h,w
	iorwf	(___lmul@multiplier)^080h,w
	skipz
	goto	u7431
	goto	u7430
u7431:
	goto	l788
u7430:
	line	128
	
l5661:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+3),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+2),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul)^080h

	line	129
	
l791:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    8[BANK1 ] unsigned long 
;;  dividend        4   12[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   16[BANK1 ] unsigned long 
;;  counter         1   20[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    8[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       0       5       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext18
__ptext18:	;psect for function ___lldiv
psect	text18
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l4201:	
	clrf	(___lldiv@quotient)^080h
	clrf	(___lldiv@quotient+1)^080h
	clrf	(___lldiv@quotient+2)^080h
	clrf	(___lldiv@quotient+3)^080h
	line	15
	
l4203:	
	movf	(___lldiv@divisor+3)^080h,w
	iorwf	(___lldiv@divisor+2)^080h,w
	iorwf	(___lldiv@divisor+1)^080h,w
	iorwf	(___lldiv@divisor)^080h,w
	skipnz
	goto	u5001
	goto	u5000
u5001:
	goto	l4223
u5000:
	line	16
	
l4205:	
	clrf	(___lldiv@counter)^080h
	incf	(___lldiv@counter)^080h,f
	line	17
	goto	l4209
	line	18
	
l4207:	
	clrc
	rlf	(___lldiv@divisor)^080h,f
	rlf	(___lldiv@divisor+1)^080h,f
	rlf	(___lldiv@divisor+2)^080h,f
	rlf	(___lldiv@divisor+3)^080h,f
	line	19
	incf	(___lldiv@counter)^080h,f
	line	17
	
l4209:	
	btfss	(___lldiv@divisor+3)^080h,(31)&7
	goto	u5011
	goto	u5010
u5011:
	goto	l4207
u5010:
	line	22
	
l4211:	
	clrc
	rlf	(___lldiv@quotient)^080h,f
	rlf	(___lldiv@quotient+1)^080h,f
	rlf	(___lldiv@quotient+2)^080h,f
	rlf	(___lldiv@quotient+3)^080h,f
	line	23
	
l4213:	
	movf	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,w
	skipz
	goto	u5025
	movf	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,w
	skipz
	goto	u5025
	movf	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,w
	skipz
	goto	u5025
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,w
u5025:
	skipc
	goto	u5021
	goto	u5020
u5021:
	goto	l4219
u5020:
	line	24
	
l4215:	
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,f
	movf	(___lldiv@divisor+1)^080h,w
	skipc
	incfsz	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,f
	movf	(___lldiv@divisor+2)^080h,w
	skipc
	incfsz	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,f
	movf	(___lldiv@divisor+3)^080h,w
	skipc
	incfsz	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,f
	line	25
	
l4217:	
	bsf	(___lldiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l4219:	
	clrc
	rrf	(___lldiv@divisor+3)^080h,f
	rrf	(___lldiv@divisor+2)^080h,f
	rrf	(___lldiv@divisor+1)^080h,f
	rrf	(___lldiv@divisor)^080h,f
	line	28
	
l4221:	
	decfsz	(___lldiv@counter)^080h,f
	goto	u5031
	goto	u5030
u5031:
	goto	l4211
u5030:
	line	30
	
l4223:	
	movf	(___lldiv@quotient+3)^080h,w
	movwf	(?___lldiv+3)^080h
	movf	(___lldiv@quotient+2)^080h,w
	movwf	(?___lldiv+2)^080h
	movf	(___lldiv@quotient+1)^080h,w
	movwf	(?___lldiv+1)^080h
	movf	(___lldiv@quotient)^080h,w
	movwf	(?___lldiv)^080h

	line	31
	
l1063:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1   26[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1   28[BANK0 ] unsigned char 
;;  product         1   27[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext19
__ptext19:	;psect for function ___bmul
psect	text19
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplier)
	line	6
	
l5773:	
	clrf	(___bmul@product)
	line	43
	
l5775:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u7631
	goto	u7630
u7631:
	goto	l5779
u7630:
	line	44
	
l5777:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l5779:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l5781:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u7641
	goto	u7640
u7641:
	goto	l5775
u7640:
	line	50
	
l5783:	
	movf	(___bmul@product),w
	line	51
	
l797:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 64 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2   26[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	64
global __ptext20
__ptext20:	;psect for function _Detect_BatteryType
psect	text20
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	64
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	66
	
l4347:	
;charge_mgr.c: 66: if(voltage >= 3990)
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u5271
	goto	u5270
u5271:
	goto	l4353
u5270:
	line	67
	
l4349:	
;charge_mgr.c: 67: return 0;
	movlw	low(0)
	goto	l557
	line	68
	
l4353:	
;charge_mgr.c: 68: if(voltage < 500)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u5281
	goto	u5280
u5281:
	goto	l4359
u5280:
	goto	l4349
	line	76
	
l4359:	
;charge_mgr.c: 76: if(voltage >= 1015 && voltage <= 2900)
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u5291
	goto	u5290
u5291:
	goto	l4367
u5290:
	
l4361:	
	movlw	0Bh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	055h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u5301
	goto	u5300
u5301:
	goto	l4367
u5300:
	line	77
	
l4363:	
;charge_mgr.c: 77: return 5;
	movlw	low(05h)
	goto	l557
	line	83
	
l4367:	
;charge_mgr.c: 83: if(voltage >= 500 && voltage < 3990)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u5311
	goto	u5310
u5311:
	goto	l4349
u5310:
	
l4369:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u5321
	goto	u5320
u5321:
	goto	l4349
u5320:
	line	84
	
l4371:	
;charge_mgr.c: 84: return 1;
	movlw	low(01h)
	line	87
	
l557:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1   26[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    1[BANK1 ] unsigned char 
;;  j               1    0[BANK1 ] unsigned char 
;;  adsum           4    3[BANK1 ] volatile unsigned long 
;;  ad_temp         2   11[BANK1 ] volatile unsigned int 
;;  admax           2    9[BANK1 ] volatile unsigned int 
;;  admin           2    7[BANK1 ] volatile unsigned int 
;;  i               1    2[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       0      13       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0       5      13       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext21
__ptext21:	;psect for function _ADC_Sample
psect	text21
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ADC_Sample@adch)^080h
	line	51
	
l5587:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	52
	
l5589:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(ADC_Sample@admin)^080h	;volatile
	clrf	(ADC_Sample@admin+1)^080h	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(ADC_Sample@admax)^080h	;volatile
	clrf	(ADC_Sample@admax+1)^080h	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	line	58
	
l5591:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u7261
	goto	u7260
u7261:
	goto	l5597
u7260:
	
l5593:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u7271
	goto	u7270
u7271:
	goto	l5597
u7270:
	line	60
	
l5595:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u9327:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u9327
	nop
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	l5599
	line	64
	
l5597:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	bcf	status, 5	;RP0=0, select bank0
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	67
	
l5599:	
;adc_drv.c: 67: if(adch & 0x10)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	btfss	(ADC_Sample@adch)^080h,(4)&7
	goto	u7281
	goto	u7280
u7281:
	goto	l475
u7280:
	line	69
	
l5601:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l5603:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	andwf	(ADC_Sample@adch)^080h,f
	line	71
;adc_drv.c: 71: }
	goto	l5605
	line	72
	
l475:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l5605:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	clrf	(ADC_Sample@i)^080h
	line	79
	
l5611:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(ADC_Sample@adch)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u7295:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u7295
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l5613:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	5
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u9337:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u9337
	nop2
opt asmopt_pop

	line	81
	
l5615:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l5617:	
;adc_drv.c: 84: unsigned char j = 0;
	clrf	(ADC_Sample@j)^080h
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	l479
	
l480:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decfsz	(ADC_Sample@j)^080h,f
	goto	u7301
	goto	u7300
u7301:
	goto	l479
u7300:
	line	89
	
l5619:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	l482
	line	90
	
l479:	
	line	85
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u7311
	goto	u7310
u7311:
	goto	l480
u7310:
	line	93
	
l5623:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	movwf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	swapf	(ADC_Sample@ad_temp)^080h,f	;volatile
	swapf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	
l5625:	
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	addwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	line	96
	
l5627:	
;adc_drv.c: 96: if(0 == admax)
	movf	((ADC_Sample@admax)^080h),w	;volatile
iorwf	((ADC_Sample@admax+1)^080h),w	;volatile
	btfss	status,2
	goto	u7321
	goto	u7320
u7321:
	goto	l5631
u7320:
	line	98
	
l5629:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	100
;adc_drv.c: 100: }
	goto	l485
	line	102
	
l5631:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	subwf	(ADC_Sample@admax+1)^080h,w	;volatile
	skipz
	goto	u7335
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	subwf	(ADC_Sample@admax)^080h,w	;volatile
u7335:
	skipnc
	goto	u7331
	goto	u7330
u7331:
	goto	l5635
u7330:
	line	103
	
l5633:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	goto	l485
	line	105
	
l5635:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	skipz
	goto	u7345
	movf	(ADC_Sample@admin)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp)^080h,w	;volatile
u7345:
	skipnc
	goto	u7341
	goto	u7340
u7341:
	goto	l485
u7340:
	line	106
	
l5637:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	108
	
l485:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ADC_Sample@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7351
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u7351:
	bcf	status, 5	;RP0=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7352
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u7352:
	bcf	status, 5	;RP0=0, select bank0
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7353
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u7353:
	bcf	status, 5	;RP0=0, select bank0
	bsf	status, 5	;RP0=1, select bank1

	line	76
	
l5639:	
	incf	(ADC_Sample@i)^080h,f
	
l5641:	
	movlw	low(022h)
	subwf	(ADC_Sample@i)^080h,w
	skipc
	goto	u7361
	goto	u7360
u7361:
	goto	l5611
u7360:
	line	112
	
l5643:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(ADC_Sample@admax)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@admax+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u7375
	goto	u7376
u7375:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u7376:
	bcf	status, 5	;RP0=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u7377
	goto	u7378
u7377:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u7378:
	bcf	status, 5	;RP0=0, select bank0
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u7379
	goto	u7370
u7379:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u7370:
	bcf	status, 5	;RP0=0, select bank0
	bsf	status, 5	;RP0=1, select bank1

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(ADC_Sample@admin)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+3)^080h,w	;volatile
	skipz
	goto	u7385
	bcf	status, 5	;RP0=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+2)^080h,w	;volatile
	skipz
	goto	u7385
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+1)^080h,w	;volatile
	skipz
	goto	u7385
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum)^080h,w	;volatile
u7385:
	skipc
	goto	u7381
	goto	u7380
u7381:
	goto	l489
u7380:
	line	114
	
l5645:	
;adc_drv.c: 114: adsum -= admin;
	movf	(ADC_Sample@admin)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u7395
	goto	u7396
u7395:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u7396:
	bcf	status, 5	;RP0=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u7397
	goto	u7398
u7397:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u7398:
	bcf	status, 5	;RP0=0, select bank0
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u7399
	goto	u7390
u7399:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u7390:
	bcf	status, 5	;RP0=0, select bank0
	bsf	status, 5	;RP0=1, select bank1

	goto	l5647
	line	115
	
l489:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	118
	
l5647:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(ADC_Sample@adsum)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_ADC_Sample+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@adsum+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@adsum+2)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@adsum+3)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u7405:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u7400:
	addlw	-1
	skipz
	goto	u7405
	movf	1+(??_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
l5649:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
l482:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 156 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   22[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0       8       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_CCCV_Control
;;		_Charging_Control
;;		_Led_BlinkProcess
;;		_PowerOnLedSequence
;;		_Update_LED_Slot
;;		i1_ADC_Sample
;;		i1___lldiv
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	156
global __ptext22
__ptext22:	;psect for function _Isr_Timer
psect	text22
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	156
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 2
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	movf	btemp+1,w
	movwf	(??_Isr_Timer+3)
	ljmp	_Isr_Timer
psect	text22
	line	159
	
i1l6681:	
;main.c: 159: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u907_21
	goto	u907_20
u907_21:
	goto	i1l369
u907_20:
	line	161
	
i1l6683:	
;main.c: 160: {
;main.c: 161: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	162
	
i1l6685:	
;main.c: 162: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	163
# 163 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text22
	line	166
	
i1l6687:	
;main.c: 166: g_pwmCounter++;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	167
	
i1l6689:	
;main.c: 167: if(g_pwmCounter >= 32)
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u908_21
	goto	u908_20
u908_21:
	goto	i1l6693
u908_20:
	line	168
	
i1l6691:	
;main.c: 168: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	171
	
i1l6693:	
;main.c: 171: if(g_pwmDuty > 0 && g_pwmCounter < g_pwmDuty)
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u909_21
	goto	u909_20
u909_21:
	goto	i1l366
u909_20:
	
i1l6695:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u910_21
	goto	u910_20
u910_21:
	goto	i1l366
u910_20:
	line	172
	
i1l6697:	
;main.c: 172: RB7 = 1;
	bsf	(55/8),(55)&7	;volatile
	goto	i1l6699
	line	173
	
i1l366:	
	line	174
;main.c: 173: else
;main.c: 174: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	177
	
i1l6699:	
;main.c: 177: if(g_powerOnPhase < 2)
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u911_21
	goto	u911_20
u911_21:
	goto	i1l6771
u911_20:
	line	179
	
i1l6701:	
;main.c: 178: {
;main.c: 179: PowerOnLedSequence();
	fcall	_PowerOnLedSequence
	goto	i1l369
	line	186
;main.c: 185: {
;main.c: 186: case 0:
	
i1l371:	
	line	188
;main.c: 188: if(!g_adcBusy && !g_doAdcSample)
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u912_21
	goto	u912_20
u912_21:
	goto	i1l369
u912_20:
	
i1l6705:	
	btfsc	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u913_21
	goto	u913_20
u913_21:
	goto	i1l369
u913_20:
	goto	i1l6709
	line	190
	
i1l375:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l388
	
i1l377:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l388
	
i1l378:	
	bsf	(51/8),(51)&7	;volatile
	goto	i1l388
	
i1l379:	
	bsf	(50/8),(50)&7	;volatile
	goto	i1l388
	
i1l380:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l388
	
i1l381:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l388
	
i1l382:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l388
	
i1l383:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l388
	
i1l384:	
	bsf	(48/8),(48)&7	;volatile
	goto	i1l388
	
i1l385:	
	bsf	(49/8),(49)&7	;volatile
	goto	i1l388
	
i1l386:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l388
	
i1l387:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l388
	
i1l6709:	
	movf	(_g_scanIndex),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l375
	xorlw	1^0	; case 1
	skipnz
	goto	i1l377
	xorlw	2^1	; case 2
	skipnz
	goto	i1l378
	xorlw	3^2	; case 3
	skipnz
	goto	i1l379
	xorlw	4^3	; case 4
	skipnz
	goto	i1l380
	xorlw	5^4	; case 5
	skipnz
	goto	i1l381
	xorlw	6^5	; case 6
	skipnz
	goto	i1l382
	xorlw	7^6	; case 7
	skipnz
	goto	i1l383
	xorlw	8^7	; case 8
	skipnz
	goto	i1l384
	xorlw	9^8	; case 9
	skipnz
	goto	i1l385
	xorlw	10^9	; case 10
	skipnz
	goto	i1l386
	xorlw	11^10	; case 11
	skipnz
	goto	i1l387
	goto	i1l388
	opt asmopt_pop

	
i1l388:	
	line	191
;main.c: 191: g_doAdcSample = 1;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	i1l369
	line	197
	
i1l6711:	
;main.c: 197: Update_LED_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_Update_LED_Slot
	line	199
	
i1l6713:	
;main.c: 199: g_scanPhase = 2;
	movlw	low(02h)
	movwf	(_g_scanPhase)	;volatile
	line	200
;main.c: 200: break;
	goto	i1l369
	line	203
	
i1l6715:	
;main.c: 203: if(g_scanIndex == 0)
	movf	((_g_scanIndex)),w	;volatile
	btfss	status,2
	goto	u914_21
	goto	u914_20
u914_21:
	goto	i1l6763
u914_20:
	line	206
	
i1l6717:	
;main.c: 204: {
;main.c: 206: if(!g_adcBusy)
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u915_21
	goto	u915_20
u915_21:
	goto	i1l6731
u915_20:
	line	208
	
i1l6719:	
;main.c: 207: {
;main.c: 208: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	209
	
i1l6721:	
;main.c: 209: test_adc = ADC_Sample(31, 0);
	clrf	(i1ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	i1_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	210
	
i1l6723:	
;main.c: 210: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u916_21
	goto	u916_20
u916_21:
	goto	i1l6729
u916_20:
	line	212
	
i1l6725:	
;main.c: 211: {
;main.c: 212: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult),w	;volatile
	movwf	(i1___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((i1___lldiv@divisor))+1
	clrf	2+((i1___lldiv@divisor))
	clrf	3+((i1___lldiv@divisor))
	movlw	0
	movwf	(i1___lldiv@dividend+3)
	movlw	04Bh
	movwf	(i1___lldiv@dividend+2)
	movlw	0
	movwf	(i1___lldiv@dividend+1)
	movlw	0
	movwf	(i1___lldiv@dividend)

	fcall	i1___lldiv
	movf	(3+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+3)
	movf	(2+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+2)
	movf	(1+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+1)
	movf	(0+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt)

	line	213
	
i1l6727:	
;main.c: 213: g_vcc_mv = (unsigned int)pt;
	movf	(Isr_Timer@pt+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv+1)^080h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(Isr_Timer@pt),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv)^080h	;volatile
	line	215
	
i1l6729:	
;main.c: 214: }
;main.c: 215: g_adcBusy = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	218
	
i1l6731:	
;main.c: 216: }
;main.c: 218: Charging_Control();
	fcall	_Charging_Control
	line	219
	
i1l6733:	
;main.c: 219: CCCV_Control();
	fcall	_CCCV_Control
	line	220
	
i1l6735:	
;main.c: 220: Led_BlinkProcess();
	fcall	_Led_BlinkProcess
	line	224
	
i1l6737:	
;main.c: 223: {
;main.c: 224: if(g_tempPhase == 0)
	movf	((_g_tempPhase)),w	;volatile
	btfss	status,2
	goto	u917_21
	goto	u917_20
u917_21:
	goto	i1l6749
u917_20:
	line	226
	
i1l6739:	
;main.c: 225: {
;main.c: 226: g_tempReadRoundCnt++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_tempReadRoundCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1)^080h,f	;volatile
	line	227
	
i1l6741:	
;main.c: 227: if(g_tempReadRoundCnt >= 200)
	movlw	0
	subwf	(_g_tempReadRoundCnt+1)^080h,w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt)^080h,w	;volatile
	skipc
	goto	u918_21
	goto	u918_20
u918_21:
	goto	i1l6757
u918_20:
	line	229
	
i1l6743:	
;main.c: 228: {
;main.c: 229: g_tempReadRoundCnt = 0;
	clrf	(_g_tempReadRoundCnt)^080h	;volatile
	clrf	(_g_tempReadRoundCnt+1)^080h	;volatile
	line	230
	
i1l6745:	
;main.c: 230: g_tempPhase = 1;
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_tempPhase)	;volatile
	line	231
	
i1l6747:	
;main.c: 231: g_tempSettleCnt = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	goto	i1l6757
	line	236
	
i1l6749:	
;main.c: 234: else
;main.c: 235: {
;main.c: 236: g_tempSettleCnt++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_tempSettleCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1)^080h,f	;volatile
	line	237
	
i1l6751:	
;main.c: 237: if(g_tempSettleCnt >= 60)
	movlw	0
	subwf	(_g_tempSettleCnt+1)^080h,w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt)^080h,w	;volatile
	skipc
	goto	u919_21
	goto	u919_20
u919_21:
	goto	i1l6757
u919_20:
	line	239
	
i1l6753:	
;main.c: 238: {
;main.c: 239: g_doNtcRead = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	240
	
i1l6755:	
;main.c: 240: g_tempSettleCnt = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	line	241
;main.c: 241: g_tempPhase = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_tempPhase)	;volatile
	line	247
	
i1l6757:	
;main.c: 242: }
;main.c: 243: }
;main.c: 244: }
;main.c: 247: if(++g_printTick >= 100)
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_printTick)^080h,f	;volatile
	skipnz
	incf	(_g_printTick+1)^080h,f	;volatile
	movlw	0
	subwf	((_g_printTick+1)^080h),w	;volatile
	movlw	064h
	skipnz
	subwf	((_g_printTick)^080h),w	;volatile
	skipc
	goto	u920_21
	goto	u920_20
u920_21:
	goto	i1l6763
u920_20:
	line	249
	
i1l6759:	
;main.c: 248: {
;main.c: 249: g_printTick = 0;
	clrf	(_g_printTick)^080h	;volatile
	clrf	(_g_printTick+1)^080h	;volatile
	line	250
	
i1l6761:	
;main.c: 250: g_printFlag = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	255
	
i1l6763:	
;main.c: 251: }
;main.c: 252: }
;main.c: 255: if(++g_scanIndex >= 12)
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	incf	(_g_scanIndex),f	;volatile
	subwf	((_g_scanIndex)),w	;volatile
	skipc
	goto	u921_21
	goto	u921_20
u921_21:
	goto	i1l400
u921_20:
	line	256
	
i1l6765:	
;main.c: 256: g_scanIndex = 0;
	clrf	(_g_scanIndex)	;volatile
	
i1l400:	
	line	257
;main.c: 257: g_scanPhase = 0;
	clrf	(_g_scanPhase)	;volatile
	line	258
;main.c: 258: break;
	goto	i1l369
	line	184
	
i1l6771:	
	movf	(_g_scanPhase),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 2
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           17     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l371
	xorlw	1^0	; case 1
	skipnz
	goto	i1l6711
	xorlw	2^1	; case 2
	skipnz
	goto	i1l6715
	goto	i1l400
	opt asmopt_pop

	line	265
	
i1l369:	
	movf	(??_Isr_Timer+3),w
	movwf	btemp+1
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^00h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	i1___lldiv

;; *************** function i1___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    0[COMMON] unsigned long 
;;  dividend        4    4[COMMON] unsigned long 
;; Auto vars:     Size  Location     Type
;;  __lldiv         4    9[COMMON] unsigned long 
;;  __lldiv         1    8[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    0[COMMON] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         8       0       0       0       0
;;      Locals:         5       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:        13       0       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext23
__ptext23:	;psect for function i1___lldiv
psect	text23
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_ofi1___lldiv
	__size_ofi1___lldiv	equ	__end_ofi1___lldiv-i1___lldiv
	
i1___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in i1___lldiv: [wreg+status,2+status,0]
	line	14
	
i1l6655:	
	clrf	(i1___lldiv@quotient)
	clrf	(i1___lldiv@quotient+1)
	clrf	(i1___lldiv@quotient+2)
	clrf	(i1___lldiv@quotient+3)
	line	15
	
i1l6657:	
	movf	(i1___lldiv@divisor+3),w
	iorwf	(i1___lldiv@divisor+2),w
	iorwf	(i1___lldiv@divisor+1),w
	iorwf	(i1___lldiv@divisor),w
	skipnz
	goto	u903_21
	goto	u903_20
u903_21:
	goto	i1l6677
u903_20:
	line	16
	
i1l6659:	
	clrf	(i1___lldiv@counter)
	incf	(i1___lldiv@counter),f
	line	17
	goto	i1l6663
	line	18
	
i1l6661:	
	clrc
	rlf	(i1___lldiv@divisor),f
	rlf	(i1___lldiv@divisor+1),f
	rlf	(i1___lldiv@divisor+2),f
	rlf	(i1___lldiv@divisor+3),f
	line	19
	incf	(i1___lldiv@counter),f
	line	17
	
i1l6663:	
	btfss	(i1___lldiv@divisor+3),(31)&7
	goto	u904_21
	goto	u904_20
u904_21:
	goto	i1l6661
u904_20:
	line	22
	
i1l6665:	
	clrc
	rlf	(i1___lldiv@quotient),f
	rlf	(i1___lldiv@quotient+1),f
	rlf	(i1___lldiv@quotient+2),f
	rlf	(i1___lldiv@quotient+3),f
	line	23
	
i1l6667:	
	movf	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),w
	skipz
	goto	u905_25
	movf	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),w
	skipz
	goto	u905_25
	movf	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),w
	skipz
	goto	u905_25
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),w
u905_25:
	skipc
	goto	u905_21
	goto	u905_20
u905_21:
	goto	i1l6673
u905_20:
	line	24
	
i1l6669:	
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),f
	movf	(i1___lldiv@divisor+1),w
	skipc
	incfsz	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),f
	movf	(i1___lldiv@divisor+2),w
	skipc
	incfsz	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),f
	movf	(i1___lldiv@divisor+3),w
	skipc
	incfsz	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),f
	line	25
	
i1l6671:	
	bsf	(i1___lldiv@quotient)+(0/8),(0)&7
	line	27
	
i1l6673:	
	clrc
	rrf	(i1___lldiv@divisor+3),f
	rrf	(i1___lldiv@divisor+2),f
	rrf	(i1___lldiv@divisor+1),f
	rrf	(i1___lldiv@divisor),f
	line	28
	
i1l6675:	
	decfsz	(i1___lldiv@counter),f
	goto	u906_21
	goto	u906_20
u906_21:
	goto	i1l6665
u906_20:
	line	30
	
i1l6677:	
	movf	(i1___lldiv@quotient+3),w
	movwf	(?i1___lldiv+3)
	movf	(i1___lldiv@quotient+2),w
	movwf	(?i1___lldiv+2)
	movf	(i1___lldiv@quotient+1),w
	movwf	(?i1___lldiv+1)
	movf	(i1___lldiv@quotient),w
	movwf	(?i1___lldiv)

	line	31
	
i1l1063:	
	return
	opt stack 0
GLOBAL	__end_ofi1___lldiv
	__end_ofi1___lldiv:
	signat	i1___lldiv,92
	global	i1_ADC_Sample

;; *************** function i1_ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    0[BANK0 ] unsigned char 
;;  ADC_Sample      4    3[BANK0 ] volatile unsigned long 
;;  ADC_Sample      2   11[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    9[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    7[BANK0 ] volatile unsigned int 
;;  ADC_Sample      1    2[BANK0 ] unsigned char 
;;  ADC_Sample      1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      13       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext24
__ptext24:	;psect for function i1_ADC_Sample
psect	text24
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_ofi1_ADC_Sample
	__size_ofi1_ADC_Sample	equ	__end_ofi1_ADC_Sample-i1_ADC_Sample
	
i1_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in i1_ADC_Sample: [wreg+status,2+status,0]
;i1ADC_Sample@adch stored from wreg
	movwf	(i1ADC_Sample@adch)
	line	51
	
i1l5345:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	52
	
i1l5347:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(i1ADC_Sample@admin)	;volatile
	clrf	(i1ADC_Sample@admin+1)	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(i1ADC_Sample@admax)	;volatile
	clrf	(i1ADC_Sample@admax+1)	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	line	58
	
i1l5349:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u687_21
	goto	u687_20
u687_21:
	goto	i1l5355
u687_20:
	
i1l5351:	
	btfss	(i1ADC_Sample@adldo),(2)&7
	goto	u688_21
	goto	u688_20
u688_21:
	goto	i1l5355
u688_20:
	line	60
	
i1l5353:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??i1_ADC_Sample+0)+0),f
	u934_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u934_27
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	i1l5357
	line	64
	
i1l5355:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	67
	
i1l5357:	
;adc_drv.c: 67: if(adch & 0x10)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(i1ADC_Sample@adch),(4)&7
	goto	u689_21
	goto	u689_20
u689_21:
	goto	i1l475
u689_20:
	line	69
	
i1l5359:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
i1l5361:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(i1ADC_Sample@adch),f
	line	71
;adc_drv.c: 71: }
	goto	i1l5363
	line	72
	
i1l475:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
i1l5363:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@i)
	
i1l5365:	
	movlw	low(022h)
	subwf	(i1ADC_Sample@i),w
	skipc
	goto	u690_21
	goto	u690_20
u690_21:
	goto	i1l5369
u690_20:
	goto	i1l5401
	line	79
	
i1l5369:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(i1ADC_Sample@adch),w
	movwf	(??i1_ADC_Sample+0)+0
	movlw	(02h)-1
u691_25:
	clrc
	rlf	(??i1_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u691_25
	clrc
	rlf	(??i1_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
i1l5371:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	6
movwf	((??i1_ADC_Sample+0)+0),f
	u935_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u935_27
	nop
opt asmopt_pop

	line	81
	
i1l5373:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
i1l5375:	
;adc_drv.c: 84: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@j)
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	i1l479
	
i1l480:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(i1ADC_Sample@j),f
	goto	u692_21
	goto	u692_20
u692_21:
	goto	i1l479
u692_20:
	line	89
	
i1l5377:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	i1l482
	line	90
	
i1l479:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u693_21
	goto	u693_20
u693_21:
	goto	i1l480
u693_20:
	line	93
	
i1l5381:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	swapf	(i1ADC_Sample@ad_temp),f	;volatile
	swapf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp),f	;volatile
	
i1l5383:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(i1ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(i1ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
i1l5385:	
;adc_drv.c: 96: if(0 == admax)
	movf	((i1ADC_Sample@admax)),w	;volatile
iorwf	((i1ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u694_21
	goto	u694_20
u694_21:
	goto	i1l5389
u694_20:
	line	98
	
i1l5387:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	100
;adc_drv.c: 100: }
	goto	i1l485
	line	102
	
i1l5389:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	subwf	(i1ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u695_25
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	subwf	(i1ADC_Sample@admax),w	;volatile
u695_25:
	skipnc
	goto	u695_21
	goto	u695_20
u695_21:
	goto	i1l5393
u695_20:
	line	103
	
i1l5391:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	goto	i1l485
	line	105
	
i1l5393:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	subwf	(i1ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u696_25
	movf	(i1ADC_Sample@admin),w	;volatile
	subwf	(i1ADC_Sample@ad_temp),w	;volatile
u696_25:
	skipnc
	goto	u696_21
	goto	u696_20
u696_21:
	goto	i1l485
u696_20:
	line	106
	
i1l5395:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	108
	
i1l485:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	addwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u697_21
	addwf	(i1ADC_Sample@adsum+1),f	;volatile
u697_21:
	movf	2+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u697_22
	addwf	(i1ADC_Sample@adsum+2),f	;volatile
u697_22:
	movf	3+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u697_23
	addwf	(i1ADC_Sample@adsum+3),f	;volatile
u697_23:

	line	76
	
i1l5397:	
	incf	(i1ADC_Sample@i),f
	goto	i1l5365
	line	112
	
i1l5401:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(i1ADC_Sample@admax),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admax+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u698_25
	goto	u698_26
u698_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u698_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u698_27
	goto	u698_28
u698_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u698_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u698_29
	goto	u698_20
u698_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u698_20:

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	3+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u699_25
	movf	2+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u699_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u699_25
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),w	;volatile
u699_25:
	skipc
	goto	u699_21
	goto	u699_20
u699_21:
	goto	i1l489
u699_20:
	line	114
	
i1l5403:	
;adc_drv.c: 114: adsum -= admin;
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u700_25
	goto	u700_26
u700_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u700_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u700_27
	goto	u700_28
u700_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u700_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u700_29
	goto	u700_20
u700_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u700_20:

	goto	i1l5405
	line	115
	
i1l489:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	118
	
i1l5405:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(i1ADC_Sample@adsum),w	;volatile
	movwf	(??i1_ADC_Sample+0)+0
	movf	(i1ADC_Sample@adsum+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	movf	(i1ADC_Sample@adsum+2),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+2)
	movf	(i1ADC_Sample@adsum+3),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+3)
	movlw	05h
u701_25:
	clrc
	rrf	(??i1_ADC_Sample+0)+3,f
	rrf	(??i1_ADC_Sample+0)+2,f
	rrf	(??i1_ADC_Sample+0)+1,f
	rrf	(??i1_ADC_Sample+0)+0,f
u701_20:
	addlw	-1
	skipz
	goto	u701_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
i1l5407:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
i1l482:	
	return
	opt stack 0
GLOBAL	__end_ofi1_ADC_Sample
	__end_ofi1_ADC_Sample:
	signat	i1_ADC_Sample,89
	global	_Update_LED_Slot

;; *************** function _Update_LED_Slot *****************
;; Defined at:
;;		line 31 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    0[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	31
global __ptext25
__ptext25:	;psect for function _Update_LED_Slot
psect	text25
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	31
	global	__size_of_Update_LED_Slot
	__size_of_Update_LED_Slot	equ	__end_of_Update_LED_Slot-_Update_LED_Slot
	
_Update_LED_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _Update_LED_Slot: [wreg]
	line	36
	
i1l761:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Slot
	__end_of_Update_LED_Slot:
	signat	_Update_LED_Slot,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 63 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=0
	line	63
global __ptext26
__ptext26:	;psect for function _PowerOnLedSequence
psect	text26
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	63
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	65
	
i1l4525:	
;led.c: 65: g_powerOnTimer++;
	incf	(_g_powerOnTimer),f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1),f	;volatile
	line	67
	
i1l4527:	
;led.c: 67: if(g_powerOnPhase == 0)
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u545_21
	goto	u545_20
u545_21:
	goto	i1l4535
u545_20:
	line	70
	
i1l4529:	
;led.c: 68: {
;led.c: 70: if(g_powerOnTimer >= 100)
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u546_21
	goto	u546_20
u546_21:
	goto	i1l773
u546_20:
	line	72
	
i1l4531:	
;led.c: 71: {
;led.c: 72: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	73
	
i1l4533:	
;led.c: 73: g_powerOnPhase = 1;
	movlw	low(01h)
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l773
	line	76
	
i1l4535:	
;led.c: 76: else if(g_powerOnPhase == 1)
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u547_21
	goto	u547_20
u547_21:
	goto	i1l773
u547_20:
	line	79
	
i1l4537:	
;led.c: 77: {
;led.c: 79: if(g_powerOnTimer >= 100)
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u548_21
	goto	u548_20
u548_21:
	goto	i1l773
u548_20:
	line	81
	
i1l4539:	
;led.c: 80: {
;led.c: 81: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	82
	
i1l4541:	
;led.c: 82: g_powerOnPhase = 2;
	movlw	low(02h)
	movwf	(_g_powerOnPhase)	;volatile
	line	86
	
i1l773:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
	global	_Led_BlinkProcess

;; *************** function _Led_BlinkProcess *****************
;; Defined at:
;;		line 48 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=0
	line	48
global __ptext27
__ptext27:	;psect for function _Led_BlinkProcess
psect	text27
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	48
	global	__size_of_Led_BlinkProcess
	__size_of_Led_BlinkProcess	equ	__end_of_Led_BlinkProcess-_Led_BlinkProcess
	
_Led_BlinkProcess:	
;incstack = 0
	opt	stack 3
; Regs used in _Led_BlinkProcess: [wreg+status,2+status,0]
	line	50
	
i1l4705:	
;led.c: 50: g_blinkTick++;
	bcf	status, 5	;RP0=0, select bank0
	incf	(_g_blinkTick),f
	line	51
	
i1l4707:	
;led.c: 51: if(g_blinkTick >= 100)
	movlw	low(064h)
	subwf	(_g_blinkTick),w
	skipc
	goto	u585_21
	goto	u585_20
u585_21:
	goto	i1l765
u585_20:
	line	52
	
i1l4709:	
;led.c: 52: g_blinkTick = 0;
	clrf	(_g_blinkTick)
	line	53
	
i1l765:	
	return
	opt stack 0
GLOBAL	__end_of_Led_BlinkProcess
	__end_of_Led_BlinkProcess:
	signat	_Led_BlinkProcess,89
	global	_Charging_Control

;; *************** function _Charging_Control *****************
;; Defined at:
;;		line 668 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    5[COMMON] unsigned char 
;;  i               1    6[COMMON] unsigned char 
;;  chargeB7_12     1    4[COMMON] unsigned char 
;;  chargeB1_6      1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 100/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	668
global __ptext28
__ptext28:	;psect for function _Charging_Control
psect	text28
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	668
	global	__size_of_Charging_Control
	__size_of_Charging_Control	equ	__end_of_Charging_Control-_Charging_Control
	
_Charging_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _Charging_Control: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	671
	
i1l5859:	
;charge_mgr.c: 670: unsigned char i;
;charge_mgr.c: 671: unsigned char chargeB1_6 = 0;
	clrf	(Charging_Control@chargeB1_6)
	line	672
;charge_mgr.c: 672: unsigned char chargeB7_12 = 0;
	clrf	(Charging_Control@chargeB7_12)
	line	675
	
i1l5861:	
;charge_mgr.c: 675: if(g_tempProtect)
	movf	((_g_tempProtect)),w
	btfsc	status,2
	goto	u766_21
	goto	u766_20
u766_21:
	goto	i1l5867
u766_20:
	line	677
;charge_mgr.c: 676: {
;charge_mgr.c: 677: do { RA0=1; RA1=1; RB3=1; RB2=1; RA3=1; RA2=1; RD1=1; RD3=1; RB0=1; RB1=1; RD2=1; RD0=1; } while(0);
	
i1l678:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	bsf	(1073/8)^080h,(1073)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	bsf	(50/8),(50)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	bsf	(1074/8)^080h,(1074)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	bsf	(49/8),(49)&7	;volatile
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	
i1l679:	
	line	678
;charge_mgr.c: 678: RC3 = 0;
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	679
;charge_mgr.c: 679: RC5 = 0;
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	680
	
i1l5863:	
;charge_mgr.c: 680: g_pwmDuty = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	goto	i1l680
	line	687
	
i1l5867:	
;charge_mgr.c: 682: }
;charge_mgr.c: 687: if(g_vccProtect)
	movf	((_g_vccProtect)),w
	btfsc	status,2
	goto	u767_21
	goto	u767_20
u767_21:
	goto	i1l5877
u767_20:
	line	689
	
i1l5869:	
;charge_mgr.c: 688: {
;charge_mgr.c: 689: if(g_vcc_mv < 4600)
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u768_21
	goto	u768_20
u768_21:
	goto	i1l5875
u768_20:
	goto	i1l678
	line	697
	
i1l5875:	
;charge_mgr.c: 696: }
;charge_mgr.c: 697: g_vccProtect = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	line	698
;charge_mgr.c: 698: }
	goto	i1l5885
	line	701
	
i1l5877:	
;charge_mgr.c: 699: else
;charge_mgr.c: 700: {
;charge_mgr.c: 701: if(g_vcc_mv < 4400)
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u769_21
	goto	u769_20
u769_21:
	goto	i1l5885
u769_20:
	line	703
	
i1l5879:	
;charge_mgr.c: 702: {
;charge_mgr.c: 703: g_vccProtect = 1;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	incf	(_g_vccProtect),f
	goto	i1l678
	line	713
	
i1l5885:	
;charge_mgr.c: 709: }
;charge_mgr.c: 710: }
;charge_mgr.c: 713: for(i = 0; i < 12; i++)
	clrf	(Charging_Control@i)
	line	715
	
i1l5891:	
;charge_mgr.c: 714: {
;charge_mgr.c: 715: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Charging_Control@s)
	line	720
	
i1l5893:	
;charge_mgr.c: 718: if(s == 2 || s == 3 ||
;charge_mgr.c: 719: s == 4 || s == 5 ||
;charge_mgr.c: 720: s == 8)
		movlw	2
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u770_21
	goto	u770_20
u770_21:
	goto	i1l5905
u770_20:
	
i1l5895:	
		movlw	3
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u771_21
	goto	u771_20
u771_21:
	goto	i1l5905
u771_20:
	
i1l5897:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u772_21
	goto	u772_20
u772_21:
	goto	i1l5905
u772_20:
	
i1l5899:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u773_21
	goto	u773_20
u773_21:
	goto	i1l5905
u773_20:
	
i1l5901:	
		movlw	8
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u774_21
	goto	u774_20
u774_21:
	goto	i1l5913
u774_20:
	goto	i1l5905
	line	722
	
i1l696:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l5907
	
i1l698:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l5907
	
i1l699:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l5907
	
i1l700:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l5907
	
i1l701:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l5907
	
i1l702:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l5907
	
i1l703:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l5907
	
i1l704:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l5907
	
i1l705:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l5907
	
i1l706:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l5907
	
i1l707:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l5907
	
i1l708:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l5907
	
i1l5905:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l696
	xorlw	1^0	; case 1
	skipnz
	goto	i1l698
	xorlw	2^1	; case 2
	skipnz
	goto	i1l699
	xorlw	3^2	; case 3
	skipnz
	goto	i1l700
	xorlw	4^3	; case 4
	skipnz
	goto	i1l701
	xorlw	5^4	; case 5
	skipnz
	goto	i1l702
	xorlw	6^5	; case 6
	skipnz
	goto	i1l703
	xorlw	7^6	; case 7
	skipnz
	goto	i1l704
	xorlw	8^7	; case 8
	skipnz
	goto	i1l705
	xorlw	9^8	; case 9
	skipnz
	goto	i1l706
	xorlw	10^9	; case 10
	skipnz
	goto	i1l707
	xorlw	11^10	; case 11
	skipnz
	goto	i1l708
	goto	i1l5907
	opt asmopt_pop

	line	725
	
i1l5907:	
;charge_mgr.c: 725: if(i < 6)
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipnc
	goto	u775_21
	goto	u775_20
u775_21:
	goto	i1l710
u775_20:
	line	726
	
i1l5909:	
;charge_mgr.c: 726: chargeB1_6 = 1;
	clrf	(Charging_Control@chargeB1_6)
	incf	(Charging_Control@chargeB1_6),f
	goto	i1l5915
	line	727
	
i1l710:	
	line	728
;charge_mgr.c: 727: else
;charge_mgr.c: 728: chargeB7_12 = 1;
	clrf	(Charging_Control@chargeB7_12)
	incf	(Charging_Control@chargeB7_12),f
	goto	i1l5915
	line	732
	
i1l715:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l5915
	
i1l717:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l5915
	
i1l718:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	i1l5915
	
i1l719:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	i1l5915
	
i1l720:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l5915
	
i1l721:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l5915
	
i1l722:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l5915
	
i1l723:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l5915
	
i1l724:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	i1l5915
	
i1l725:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	i1l5915
	
i1l726:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l5915
	
i1l727:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l5915
	
i1l5913:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l715
	xorlw	1^0	; case 1
	skipnz
	goto	i1l717
	xorlw	2^1	; case 2
	skipnz
	goto	i1l718
	xorlw	3^2	; case 3
	skipnz
	goto	i1l719
	xorlw	4^3	; case 4
	skipnz
	goto	i1l720
	xorlw	5^4	; case 5
	skipnz
	goto	i1l721
	xorlw	6^5	; case 6
	skipnz
	goto	i1l722
	xorlw	7^6	; case 7
	skipnz
	goto	i1l723
	xorlw	8^7	; case 8
	skipnz
	goto	i1l724
	xorlw	9^8	; case 9
	skipnz
	goto	i1l725
	xorlw	10^9	; case 10
	skipnz
	goto	i1l726
	xorlw	11^10	; case 11
	skipnz
	goto	i1l727
	goto	i1l5915
	opt asmopt_pop

	line	713
	
i1l5915:	
	incf	(Charging_Control@i),f
	
i1l5917:	
	movlw	low(0Ch)
	subwf	(Charging_Control@i),w
	skipc
	goto	u776_21
	goto	u776_20
u776_21:
	goto	i1l5891
u776_20:
	
i1l690:	
	line	737
;charge_mgr.c: 733: }
;charge_mgr.c: 734: }
;charge_mgr.c: 737: RC3 = chargeB1_6;
	btfsc	(Charging_Control@chargeB1_6),0
	goto	u777_21
	goto	u777_20
	
u777_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2099/8)^0100h,(2099)&7	;volatile
	goto	u778_24
u777_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
u778_24:
	line	738
;charge_mgr.c: 738: RC5 = chargeB7_12;
	btfsc	(Charging_Control@chargeB7_12),0
	goto	u779_21
	goto	u779_20
	
u779_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u780_24
u779_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u780_24:
	line	741
	
i1l680:	
	return
	opt stack 0
GLOBAL	__end_of_Charging_Control
	__end_of_Charging_Control:
	signat	_Charging_Control,89
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 759 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    6[BANK0 ] unsigned int 
;;  s               1   17[BANK0 ] unsigned char 
;;  duty            2   14[BANK0 ] int 
;;  error           2   10[BANK0 ] int 
;;  adjust          2    0[BANK0 ] int 
;;  duty_initial    1   13[BANK0 ] unsigned char 
;;  duty_target     1   12[BANK0 ] unsigned char 
;;  maxV            2    8[BANK0 ] unsigned int 
;;  i               1   16[BANK0 ] unsigned char 
;;  preCount        1    5[BANK0 ] unsigned char 
;;  ccCount         1    4[BANK0 ] unsigned char 
;;  cvCount         1    3[BANK0 ] unsigned char 
;;  hasCharging     1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 100/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2      18       0       0       0
;;Total ram usage:       20 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___awdiv
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=0
	line	759
global __ptext29
__ptext29:	;psect for function _CCCV_Control
psect	text29
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	759
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	762
	
i1l5919:	
;charge_mgr.c: 761: unsigned char i;
;charge_mgr.c: 762: unsigned char hasCharging = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	763
;charge_mgr.c: 763: unsigned int maxV = 0;
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	764
;charge_mgr.c: 764: unsigned char cvCount = 0;
	clrf	(CCCV_Control@cvCount)
	line	765
;charge_mgr.c: 765: unsigned char ccCount = 0;
	clrf	(CCCV_Control@ccCount)
	line	766
;charge_mgr.c: 766: unsigned char preCount = 0;
	clrf	(CCCV_Control@preCount)
	line	769
;charge_mgr.c: 769: for(i = 0; i < 12; i++)
	clrf	(CCCV_Control@i)
	line	771
	
i1l5925:	
;charge_mgr.c: 770: {
;charge_mgr.c: 771: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	775
	
i1l5927:	
;charge_mgr.c: 773: if(s == 2 || s == 3 ||
;charge_mgr.c: 774: s == 4 || s == 5 ||
;charge_mgr.c: 775: s == 8)
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u781_21
	goto	u781_20
u781_21:
	goto	i1l735
u781_20:
	
i1l5929:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u782_21
	goto	u782_20
u782_21:
	goto	i1l735
u782_20:
	
i1l5931:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u783_21
	goto	u783_20
u783_21:
	goto	i1l735
u783_20:
	
i1l5933:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u784_21
	goto	u784_20
u784_21:
	goto	i1l735
u784_20:
	
i1l5935:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u785_21
	goto	u785_20
u785_21:
	goto	i1l733
u785_20:
	
i1l735:	
	line	777
;charge_mgr.c: 776: {
;charge_mgr.c: 777: hasCharging = 1;
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	779
	
i1l5937:	
;charge_mgr.c: 778: {
;charge_mgr.c: 779: unsigned int vt = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	780
	
i1l5939:	
;charge_mgr.c: 780: if(vt > maxV) maxV = vt;
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u786_25
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u786_25:
	skipnc
	goto	u786_21
	goto	u786_20
u786_21:
	goto	i1l5943
u786_20:
	
i1l5941:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	782
	
i1l5943:	
;charge_mgr.c: 781: }
;charge_mgr.c: 782: if(s == 5)
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u787_21
	goto	u787_20
u787_21:
	goto	i1l5947
u787_20:
	line	783
	
i1l5945:	
;charge_mgr.c: 783: cvCount++;
	incf	(CCCV_Control@cvCount),f
	line	784
	
i1l5947:	
;charge_mgr.c: 784: if(s == 4)
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u788_21
	goto	u788_20
u788_21:
	goto	i1l5951
u788_20:
	line	785
	
i1l5949:	
;charge_mgr.c: 785: ccCount++;
	incf	(CCCV_Control@ccCount),f
	line	786
	
i1l5951:	
;charge_mgr.c: 786: if(s == 3 || s == 2)
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u789_21
	goto	u789_20
u789_21:
	goto	i1l5955
u789_20:
	
i1l5953:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u790_21
	goto	u790_20
u790_21:
	goto	i1l733
u790_20:
	line	787
	
i1l5955:	
;charge_mgr.c: 787: preCount++;
	incf	(CCCV_Control@preCount),f
	line	788
	
i1l733:	
	line	769
	incf	(CCCV_Control@i),f
	
i1l5957:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u791_21
	goto	u791_20
u791_21:
	goto	i1l5925
u791_20:
	line	792
	
i1l5959:	
;charge_mgr.c: 788: }
;charge_mgr.c: 789: }
;charge_mgr.c: 792: if(!hasCharging)
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u792_21
	goto	u792_20
u792_21:
	goto	i1l5965
u792_20:
	line	794
	
i1l5961:	
;charge_mgr.c: 793: {
;charge_mgr.c: 794: g_pwmDuty = 0;
	clrf	(_g_pwmDuty)	;volatile
	line	795
;charge_mgr.c: 795: g_cvIntegral = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	i1l743
	line	803
	
i1l5965:	
;charge_mgr.c: 797: }
;charge_mgr.c: 803: if(cvCount == 0)
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u793_21
	goto	u793_20
u793_21:
	goto	i1l5995
u793_20:
	line	807
	
i1l5967:	
;charge_mgr.c: 804: {
;charge_mgr.c: 805: unsigned char duty_target, duty_initial;
;charge_mgr.c: 807: if(ccCount > 0)
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u794_21
	goto	u794_20
u794_21:
	goto	i1l5971
u794_20:
	line	810
	
i1l5969:	
;charge_mgr.c: 808: {
;charge_mgr.c: 810: duty_target = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	811
;charge_mgr.c: 811: duty_initial = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	812
;charge_mgr.c: 812: }
	goto	i1l5979
	line	813
	
i1l5971:	
;charge_mgr.c: 813: else if(preCount > 0)
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u795_21
	goto	u795_20
u795_21:
	goto	i1l5975
u795_20:
	line	816
	
i1l5973:	
;charge_mgr.c: 814: {
;charge_mgr.c: 816: duty_target = 8;
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	817
;charge_mgr.c: 817: duty_initial = 5;
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	818
;charge_mgr.c: 818: }
	goto	i1l5979
	line	823
	
i1l5975:	
;charge_mgr.c: 819: else
;charge_mgr.c: 820: {
;charge_mgr.c: 823: g_pwmDuty = 25;
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l743
	line	827
	
i1l5979:	
;charge_mgr.c: 825: }
;charge_mgr.c: 827: if(g_pwmDuty < duty_initial)
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u796_21
	goto	u796_20
u796_21:
	goto	i1l5987
u796_20:
	line	830
	
i1l5981:	
;charge_mgr.c: 828: {
;charge_mgr.c: 830: g_pwmDuty += 3;
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	831
	
i1l5983:	
;charge_mgr.c: 831: if(g_pwmDuty > duty_initial)
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u797_21
	goto	u797_20
u797_21:
	goto	i1l743
u797_20:
	line	832
	
i1l5985:	
;charge_mgr.c: 832: g_pwmDuty = duty_initial;
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l743
	line	834
	
i1l5987:	
	line	837
	
i1l5989:	
;charge_mgr.c: 835: {
;charge_mgr.c: 837: g_pwmDuty = duty_target;
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	838
;charge_mgr.c: 838: }
	goto	i1l743
	line	853
	
i1l5995:	
;charge_mgr.c: 845: }
;charge_mgr.c: 852: {
;charge_mgr.c: 853: int error = (int)(3100) - (int)(maxV);
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	856
;charge_mgr.c: 856: g_cvIntegral += error * 1;
	movf	(CCCV_Control@error),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral)^080h,f
	skipnc
	incf	(_g_cvIntegral+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(CCCV_Control@error+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral+1)^080h,f
	line	857
	
i1l5997:	
;charge_mgr.c: 857: if(g_cvIntegral > 200)
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u798_25
	movlw	0C9h
	subwf	(_g_cvIntegral)^080h,w
u798_25:

	skipc
	goto	u798_21
	goto	u798_20
u798_21:
	goto	i1l6001
u798_20:
	line	858
	
i1l5999:	
;charge_mgr.c: 858: g_cvIntegral = 200;
	movlw	0C8h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	i1l6005
	line	859
	
i1l6001:	
;charge_mgr.c: 859: else if(g_cvIntegral < -200)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u799_25
	movlw	038h
	subwf	(_g_cvIntegral)^080h,w
u799_25:

	skipnc
	goto	u799_21
	goto	u799_20
u799_21:
	goto	i1l6005
u799_20:
	line	860
	
i1l6003:	
;charge_mgr.c: 860: g_cvIntegral = -200;
	movlw	038h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	movlw	0FFh
	movwf	((_g_cvIntegral)^080h)+1
	line	863
	
i1l6005:	
;charge_mgr.c: 863: int adjust = (error * 4 + g_cvIntegral) / 8;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_cvIntegral)^080h,w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1)^080h,w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	864
	
i1l6007:	
;charge_mgr.c: 864: int duty = (int)g_pwmDuty + adjust;
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
i1l6009:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	867
	
i1l6011:	
;charge_mgr.c: 867: if(duty > 32) duty = 32;
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u800_25
	movlw	021h
	subwf	(CCCV_Control@duty),w
u800_25:

	skipc
	goto	u800_21
	goto	u800_20
u800_21:
	goto	i1l6015
u800_20:
	
i1l6013:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	868
	
i1l6015:	
;charge_mgr.c: 868: if(duty < 0) duty = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u801_21
	goto	u801_20
u801_21:
	goto	i1l6019
u801_20:
	
i1l6017:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	870
	
i1l6019:	
;charge_mgr.c: 870: g_pwmDuty = (unsigned char)duty;
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	872
	
i1l743:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	i1___bmul

;; *************** function i1___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[COMMON] unsigned char 
;;  __bmul          1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Charging_Control
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text30,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext30
__ptext30:	;psect for function i1___bmul
psect	text30
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_ofi1___bmul
	__size_ofi1___bmul	equ	__end_ofi1___bmul-i1___bmul
	
i1___bmul:	
;incstack = 0
	opt	stack 2
; Regs used in i1___bmul: [wreg+status,2+status,0]
;i1___bmul@multiplier stored from wreg
	movwf	(i1___bmul@multiplier)
	line	6
	
i1l2951:	
	clrf	(i1___bmul@product)
	line	43
	
i1l2953:	
	btfss	(i1___bmul@multiplier),(0)&7
	goto	u296_21
	goto	u296_20
u296_21:
	goto	i1l2957
u296_20:
	line	44
	
i1l2955:	
	movf	(i1___bmul@multiplicand),w
	addwf	(i1___bmul@product),f
	line	45
	
i1l2957:	
	clrc
	rlf	(i1___bmul@multiplicand),f
	line	46
	
i1l2959:	
	clrc
	rrf	(i1___bmul@multiplier),f
	line	47
	movf	((i1___bmul@multiplier)),w
	btfss	status,2
	goto	u297_21
	goto	u297_20
u297_21:
	goto	i1l2953
u297_20:
	line	50
	
i1l2961:	
	movf	(i1___bmul@product),w
	line	51
	
i1l797:	
	return
	opt stack 0
GLOBAL	__end_ofi1___bmul
	__end_ofi1___bmul:
	signat	i1___bmul,89
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] int 
;;  dividend        2    2[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] int 
;;  sign            1    5[COMMON] unsigned char 
;;  counter         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text31,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext31
__ptext31:	;psect for function ___awdiv
psect	text31
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
i1l4409:	
	clrf	(___awdiv@sign)
	line	15
	
i1l4411:	
	btfss	(___awdiv@divisor+1),7
	goto	u537_21
	goto	u537_20
u537_21:
	goto	i1l4417
u537_20:
	line	16
	
i1l4413:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
i1l4415:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
i1l4417:	
	btfss	(___awdiv@dividend+1),7
	goto	u538_21
	goto	u538_20
u538_21:
	goto	i1l4423
u538_20:
	line	20
	
i1l4419:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
i1l4421:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
i1l4423:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
i1l4425:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u539_21
	goto	u539_20
u539_21:
	goto	i1l4445
u539_20:
	line	25
	
i1l4427:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	i1l4431
	line	27
	
i1l4429:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
i1l4431:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u540_21
	goto	u540_20
u540_21:
	goto	i1l4429
u540_20:
	line	31
	
i1l4433:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
i1l4435:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u541_25
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u541_25:
	skipc
	goto	u541_21
	goto	u541_20
u541_21:
	goto	i1l4441
u541_20:
	line	33
	
i1l4437:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
i1l4439:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
i1l4441:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
i1l4443:	
	decfsz	(___awdiv@counter),f
	goto	u542_21
	goto	u542_20
u542_21:
	goto	i1l4433
u542_20:
	line	39
	
i1l4445:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u543_21
	goto	u543_20
u543_21:
	goto	i1l4449
u543_20:
	line	40
	
i1l4447:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
i1l4449:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
i1l909:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
