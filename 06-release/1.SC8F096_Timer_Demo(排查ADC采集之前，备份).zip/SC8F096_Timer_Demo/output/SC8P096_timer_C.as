opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_Print_Status
	FNCALL	_main,_System_Init
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,___bmul
	FNCALL	_Print_Status,___bmul
	FNCALL	_Print_Status,_uart_send_number
	FNCALL	_Print_Status,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNROOT	_main
	FNCALL	_Interrupt_Isr,_ADC_ReadChannel
	FNCALL	_Interrupt_Isr,_ADC_Sample
	FNCALL	_Interrupt_Isr,_CCCV_Control
	FNCALL	_Interrupt_Isr,_ChargeProcess_Slot
	FNCALL	_Interrupt_Isr,_Charging_Control
	FNCALL	_Interrupt_Isr,_Led_BlinkProcess
	FNCALL	_Interrupt_Isr,_PowerOnLedSequence
	FNCALL	_Interrupt_Isr,_Update_LED_Slot
	FNCALL	_Interrupt_Isr,___ftdiv
	FNCALL	_Interrupt_Isr,___fttol
	FNCALL	_Interrupt_Isr,___lwtoft
	FNCALL	_Interrupt_Isr,i1___bmul
	FNCALL	___lwtoft,___ftpack
	FNCALL	___ftdiv,___ftpack
	FNCALL	_Update_LED_Slot,i1___bmul
	FNCALL	_Led_BlinkProcess,i1___bmul
	FNCALL	_Charging_Control,i1___bmul
	FNCALL	_ChargeProcess_Slot,_Detect_BatteryType
	FNCALL	_ChargeProcess_Slot,i1___bmul
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,i1___bmul
	FNCALL	_ADC_ReadChannel,_ADC_Sample
	FNCALL	intlevel1,_Interrupt_Isr
	global	intlevel1
	FNROOT	intlevel1
	global	_g_temperature
psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	15

;initializer for _g_temperature
	retlw	019h
	global	_s_adcChannels
psect	strings,class=STRING,delta=2,noexec
global __pstrings
__pstrings:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 1 byte each
stringcode:stringdir:
movlw high(stringdir)
movwf pclath
movf fsr,w
incf fsr
	addwf pc
	global __stringbase
__stringbase:
	retlw	0
psect	strings
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	50
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_cvIntegral
	global	_g_systemTick
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_powerOnPhase
	global	_g_scanPhase
	global	_g_scanIndex
	global	_test_adc
	global	_adresult
	global	_g_printFlag
	global	_global_test
	global	_g_ntcDiagChk
	global	_g_ntcDiagVdd
	global	_g_ntcDiagAdc
	global	_g_powerOnTimer
	global	_power_ad
	global	_g_tempProtect
	global	_g_slot1
	global	_g_slot0
	global	_OSCCON
_OSCCON	set	20
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_GIE
_GIE	set	0x5F
	global	_PEIE
_PEIE	set	0x5E
	global	_T0IE
_T0IE	set	0x5D
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_CHS4
_CHS4	set	0x4B6
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC4
_RC4	set	0x834
	global	_RC5
_RC5	set	0x835
	global	_RC2
_RC2	set	0x832
	global	_RC3
_RC3	set	0x833
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	global	_SPBRG1
_SPBRG1	set	393
	global	_TXREG1
_TXREG1	set	391
	global	_RCSTA1
_RCSTA1	set	390
	global	_TXSTA1
_TXSTA1	set	389
	global	_TRMT1
_TRMT1	set	0xC29
	
STR_9:	
	retlw	32	;' '
	retlw	40	;'('
	retlw	66	;'B'
	retlw	49	;'1'
	retlw	47	;'/'
	retlw	86	;'V'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	70	;'F'
	retlw	47	;'/'
	retlw	115	;'s'
	retlw	97	;'a'
	retlw	116	;'t'
	retlw	41	;')'
	retlw	13
	retlw	10
	retlw	0
psect	strings
	
STR_14:	
	retlw	32	;' '
	retlw	98	;'b'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	97	;'a'
	retlw	117	;'u'
	retlw	115	;'s'
	retlw	101	;'e'
	retlw	32	;' '
	retlw	58	;':'
	retlw	32	;' '
	retlw	0
psect	strings
	
STR_1:	
	retlw	115	;'s'
	retlw	116	;'t'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	strings
	
STR_6:	
	retlw	68	;'D'
	retlw	66	;'B'
	retlw	71	;'G'
	retlw	58	;':'
	retlw	32	;' '
	retlw	66	;'B'
	retlw	49	;'1'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_3:	
	retlw	67	;'C'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	58	;':'
	retlw	0
psect	strings
	
STR_7:	
	retlw	32	;' '
	retlw	86	;'V'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	70	;'F'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_4:	
	retlw	32	;' '
	retlw	86	;'V'
	retlw	68	;'D'
	retlw	68	;'D'
	retlw	58	;':'
	retlw	0
psect	strings
	
STR_8:	
	retlw	32	;' '
	retlw	115	;'s'
	retlw	97	;'a'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_16:	
	retlw	32	;' '
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	0
psect	strings
	
STR_5:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	13
	retlw	10
	retlw	0
psect	strings
	
STR_17:	
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	71	;'G'
	retlw	0
psect	strings
	
STR_15:	
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	0
psect	strings
	
STR_12:	
	retlw	32	;' '
	retlw	83	;'S'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_13:	
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_11:	
	retlw	58	;':'
	retlw	86	;'V'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_2:	
	retlw	84	;'T'
	retlw	58	;':'
	retlw	0
psect	strings
	
STR_10:	
	retlw	66	;'B'
	retlw	0
psect	strings
STR_18	equ	STR_9+14
; #config settings
	file	"SC8P096_timer_C.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssBANK0,class=BANK0,bit,space=1,noexec
global __pbitbssBANK0
__pbitbssBANK0:
_g_printFlag:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_cvIntegral:
       ds      2

_g_systemTick:
       ds      2

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_powerOnPhase:
       ds      1

_g_scanPhase:
       ds      1

_g_scanIndex:
       ds      1

_test_adc:
       ds      1

_adresult:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_global_test:
       ds      2

_g_ntcDiagChk:
       ds      2

_g_ntcDiagVdd:
       ds      2

_g_ntcDiagAdc:
       ds      2

_g_powerOnTimer:
       ds      2

_power_ad:
       ds      2

_g_tempProtect:
       ds      1

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	15
_g_temperature:
       ds      1

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slot0:
       ds      72

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot1:
       ds      72

	file	"SC8P096_timer_C.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+0Dh)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+0Ch)
	fcall	clear_ram0
; Clear objects allocated to BITBANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	clrf	((__pbitbssBANK0/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
??_uart_send_char:	; 1 bytes @ 0x0
?___bmul:	; 1 bytes @ 0x0
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x0
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x0
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x0
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x0
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x0
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x0
	ds	1
??_uart_send_string:	; 1 bytes @ 0x1
??___bmul:	; 1 bytes @ 0x1
	global	uart_send_string@str
uart_send_string@str:	; 1 bytes @ 0x1
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x1
	ds	1
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x2
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x2
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x2
	ds	1
??_System_Init:	; 1 bytes @ 0x3
	ds	1
??___lwdiv:	; 1 bytes @ 0x4
??___lwmod:	; 1 bytes @ 0x4
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x4
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x4
	ds	1
	global	_System_Init$254
_System_Init$254:	; 1 bytes @ 0x5
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x5
	ds	1
	global	_System_Init$265
_System_Init$265:	; 1 bytes @ 0x6
	ds	1
?_uart_send_number:	; 1 bytes @ 0x7
	global	_System_Init$276
_System_Init$276:	; 1 bytes @ 0x7
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x7
	ds	1
	global	_System_Init$287
_System_Init$287:	; 1 bytes @ 0x8
	ds	1
??_uart_send_number:	; 1 bytes @ 0x9
	global	_System_Init$298
_System_Init$298:	; 1 bytes @ 0x9
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x9
	ds	1
	global	_System_Init$309
_System_Init$309:	; 1 bytes @ 0xA
	ds	1
	global	_System_Init$320
_System_Init$320:	; 1 bytes @ 0xB
	ds	1
	global	_System_Init$331
_System_Init$331:	; 1 bytes @ 0xC
	ds	1
	global	_System_Init$342
_System_Init$342:	; 1 bytes @ 0xD
	ds	1
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0xE
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0xF
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x10
	ds	1
??_Print_Status:	; 1 bytes @ 0x11
	global	_Print_Status$606
_Print_Status$606:	; 1 bytes @ 0x11
	ds	1
	global	_Print_Status$618
_Print_Status$618:	; 1 bytes @ 0x12
	ds	1
	global	_Print_Status$630
_Print_Status$630:	; 1 bytes @ 0x13
	ds	1
	global	_Print_Status$642
_Print_Status$642:	; 1 bytes @ 0x14
	ds	1
	global	_Print_Status$654
_Print_Status$654:	; 1 bytes @ 0x15
	ds	1
	global	_Print_Status$676
_Print_Status$676:	; 1 bytes @ 0x16
	ds	1
	global	_Print_Status$677
_Print_Status$677:	; 1 bytes @ 0x17
	ds	1
	global	Print_Status@i
Print_Status@i:	; 1 bytes @ 0x18
	ds	1
??_main:	; 1 bytes @ 0x19
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_uart_send_string:	; 1 bytes @ 0x0
?_Print_Status:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_ChargeProcess_Slot:	; 1 bytes @ 0x0
?_Update_LED_Slot:	; 1 bytes @ 0x0
?_Led_BlinkProcess:	; 1 bytes @ 0x0
?_Charging_Control:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_ADC_Sample:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?_Interrupt_Isr:	; 1 bytes @ 0x0
?_Detect_BatteryType:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?i1___bmul:	; 1 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	?___ftpack
?___ftpack:	; 3 bytes @ 0x0
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x0
	global	i1___bmul@multiplicand
i1___bmul@multiplicand:	; 1 bytes @ 0x0
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	global	___ftpack@arg
___ftpack@arg:	; 3 bytes @ 0x0
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x1
??i1___bmul:	; 1 bytes @ 0x1
	global	i1___bmul@multiplier
i1___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x2
	global	i1___bmul@product
i1___bmul@product:	; 1 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_ChargeProcess_Slot:	; 1 bytes @ 0x3
??_Update_LED_Slot:	; 1 bytes @ 0x3
??_Led_BlinkProcess:	; 1 bytes @ 0x3
??_Charging_Control:	; 1 bytes @ 0x3
	global	Charging_Control@chargeB1_6
Charging_Control@chargeB1_6:	; 1 bytes @ 0x3
	global	Update_LED_Slot@idx
Update_LED_Slot@idx:	; 1 bytes @ 0x3
	global	___ftpack@exp
___ftpack@exp:	; 1 bytes @ 0x3
	ds	1
??___awdiv:	; 1 bytes @ 0x4
	global	Charging_Control@chargeB7_12
Charging_Control@chargeB7_12:	; 1 bytes @ 0x4
	global	Update_LED_Slot@p
Update_LED_Slot@p:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	global	___ftpack@sign
___ftpack@sign:	; 1 bytes @ 0x4
	ds	1
??___ftpack:	; 1 bytes @ 0x5
	global	?_ADC_ReadChannel
?_ADC_ReadChannel:	; 2 bytes @ 0x5
	global	_Charging_Control$459
_Charging_Control$459:	; 1 bytes @ 0x5
	global	_Led_BlinkProcess$527
_Led_BlinkProcess$527:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	ds	1
	global	Charging_Control@s
Charging_Control@s:	; 1 bytes @ 0x6
	global	_Led_BlinkProcess$538
_Led_BlinkProcess$538:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	1
??_ADC_ReadChannel:	; 1 bytes @ 0x7
	global	ChargeProcess_Slot@idx
ChargeProcess_Slot@idx:	; 1 bytes @ 0x7
	global	Charging_Control@i
Charging_Control@i:	; 1 bytes @ 0x7
	global	_Led_BlinkProcess$549
_Led_BlinkProcess$549:	; 1 bytes @ 0x7
	ds	1
??_CCCV_Control:	; 1 bytes @ 0x8
	global	?___lwtoft
?___lwtoft:	; 3 bytes @ 0x8
	global	ADC_ReadChannel@ch
ADC_ReadChannel@ch:	; 1 bytes @ 0x8
	global	_Led_BlinkProcess$560
_Led_BlinkProcess$560:	; 1 bytes @ 0x8
	global	ChargeProcess_Slot@v
ChargeProcess_Slot@v:	; 2 bytes @ 0x8
	global	___lwtoft@c
___lwtoft@c:	; 2 bytes @ 0x8
	ds	1
	global	_Led_BlinkProcess$571
_Led_BlinkProcess$571:	; 1 bytes @ 0x9
	ds	1
	global	ChargeProcess_Slot@p
ChargeProcess_Slot@p:	; 1 bytes @ 0xA
	global	Led_BlinkProcess@i
Led_BlinkProcess@i:	; 1 bytes @ 0xA
	ds	1
??___ftdiv:	; 1 bytes @ 0xB
??___lwtoft:	; 1 bytes @ 0xB
	ds	3
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	?___ftdiv
?___ftdiv:	; 3 bytes @ 0x0
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x0
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x0
	global	___ftdiv@f2
___ftdiv@f2:	; 3 bytes @ 0x0
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x1
	ds	1
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x2
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x2
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x3
	global	___ftdiv@f1
___ftdiv@f1:	; 3 bytes @ 0x3
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	_CCCV_Control$476
_CCCV_Control$476:	; 1 bytes @ 0x4
	ds	1
	global	_CCCV_Control$487
_CCCV_Control$487:	; 1 bytes @ 0x5
	ds	1
	global	_CCCV_Control$498
_CCCV_Control$498:	; 1 bytes @ 0x6
	global	___ftdiv@cntr
___ftdiv@cntr:	; 1 bytes @ 0x6
	ds	1
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x7
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x7
	global	___ftdiv@f3
___ftdiv@f3:	; 3 bytes @ 0x7
	ds	2
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x9
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0x9
	ds	1
	global	___ftdiv@exp
___ftdiv@exp:	; 1 bytes @ 0xA
	ds	1
	global	___ftdiv@sign
___ftdiv@sign:	; 1 bytes @ 0xB
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0xB
	ds	1
	global	?___fttol
?___fttol:	; 4 bytes @ 0xC
	global	___fttol@f1
___fttol@f1:	; 3 bytes @ 0xC
	ds	1
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0xD
	ds	1
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0xE
	ds	2
??___fttol:	; 1 bytes @ 0x10
	ds	3
	global	___fttol@sign1
___fttol@sign1:	; 1 bytes @ 0x13
	ds	1
	global	___fttol@lval
___fttol@lval:	; 4 bytes @ 0x14
	ds	4
	global	___fttol@exp1
___fttol@exp1:	; 1 bytes @ 0x18
	ds	1
??_Interrupt_Isr:	; 1 bytes @ 0x19
	ds	6
	global	_Interrupt_Isr$370
_Interrupt_Isr$370:	; 1 bytes @ 0x1F
	ds	1
	global	_Interrupt_Isr$368
_Interrupt_Isr$368:	; 1 bytes @ 0x20
	ds	1
	global	_Interrupt_Isr$381
_Interrupt_Isr$381:	; 1 bytes @ 0x21
	ds	1
	global	_Interrupt_Isr$392
_Interrupt_Isr$392:	; 1 bytes @ 0x22
	ds	1
	global	_Interrupt_Isr$403
_Interrupt_Isr$403:	; 1 bytes @ 0x23
	ds	1
	global	Interrupt_Isr@wasCharging
Interrupt_Isr@wasCharging:	; 1 bytes @ 0x24
	ds	1
	global	Interrupt_Isr@s
Interrupt_Isr@s:	; 1 bytes @ 0x25
	ds	1
	global	Interrupt_Isr@power_temp
Interrupt_Isr@power_temp:	; 4 bytes @ 0x26
	ds	4
	global	Interrupt_Isr@idx
Interrupt_Isr@idx:	; 1 bytes @ 0x2A
	ds	1
;!
;!Data Sizes:
;!    Strings     113
;!    Constant    12
;!    Data        1
;!    BSS         169
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     14      14
;!    BANK0            80     43      56
;!    BANK1            80     25      39
;!    BANK3            80      0      72
;!    BANK2            80      0      72

;!
;!Pointer List with Targets:
;!
;!    Print_Status$677	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Print_Status$676	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Print_Status$654	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Print_Status$642	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Print_Status$630	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Print_Status$618	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Print_Status$606	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    uart_send_string@str	PTR const unsigned char  size(1) Largest target is 17
;!		 -> STR_18(CODE[3]), STR_17(CODE[5]), STR_16(CODE[6]), STR_15(CODE[5]), 
;!		 -> STR_14(CODE[12]), STR_13(CODE[4]), STR_12(CODE[4]), STR_11(CODE[4]), 
;!		 -> STR_10(CODE[2]), STR_9(CODE[17]), STR_8(CODE[6]), STR_7(CODE[7]), 
;!		 -> STR_6(CODE[9]), STR_5(CODE[5]), STR_4(CODE[6]), STR_3(CODE[7]), 
;!		 -> STR_2(CODE[3]), STR_1(CODE[11]), 
;!
;!    Led_BlinkProcess$571	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Led_BlinkProcess$560	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Led_BlinkProcess$549	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Led_BlinkProcess$538	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Led_BlinkProcess$527	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Update_LED_Slot@p	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    CCCV_Control$498	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    CCCV_Control$487	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    CCCV_Control$476	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Charging_Control$459	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    ChargeProcess_Slot@p	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Interrupt_Isr$403	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Interrupt_Isr$392	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Interrupt_Isr$381	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Interrupt_Isr$368	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    System_Init$342	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    System_Init$331	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    System_Init$320	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    System_Init$309	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    System_Init$298	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    System_Init$287	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    System_Init$276	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    System_Init$265	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    System_Init$254	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Interrupt_Isr in COMMON
;!
;!    _Interrupt_Isr->___ftdiv
;!    ___lwtoft->___ftpack
;!    ___fttol->___ftdiv
;!    ___ftdiv->___lwtoft
;!    _Update_LED_Slot->i1___bmul
;!    _Led_BlinkProcess->i1___bmul
;!    _Charging_Control->i1___bmul
;!    _ChargeProcess_Slot->i1___bmul
;!    _CCCV_Control->___awdiv
;!    _ADC_ReadChannel->_ADC_Sample
;!
;!Critical Paths under _main in BANK0
;!
;!    None.
;!
;!Critical Paths under _Interrupt_Isr in BANK0
;!
;!    _Interrupt_Isr->___fttol
;!    ___fttol->___ftdiv
;!    _ADC_ReadChannel->_ADC_Sample
;!
;!Critical Paths under _main in BANK1
;!
;!    _main->_Print_Status
;!    _System_Init->___bmul
;!    _Print_Status->_uart_send_number
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!
;!Critical Paths under _Interrupt_Isr in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Interrupt_Isr in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Interrupt_Isr in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 0, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 0     0      0   11017
;!                       _Print_Status
;!                        _System_Init
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                         12    12      0    3704
;!                                              3 BANK1     12    12      0
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _Print_Status                                         8     8      0    6587
;!                                             17 BANK1      8     8      0
;!                             ___bmul
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     1     1      0     726
;!                                              1 BANK1      1     1      0
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_number                                    10     8      2    2445
;!                                              7 BANK1     10     8      2
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       1     1      0      42
;!                                              0 BANK1      1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___lwmod                                              5     1      4     482
;!                                              0 BANK1      5     1      4
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4     500
;!                                              0 BANK1      7     3      4
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1    1934
;!                                              0 BANK1      3     2      1
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 3
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Interrupt_Isr                                       18    18      0   16015
;!                                             25 BANK0     18    18      0
;!                    _ADC_ReadChannel
;!                         _ADC_Sample
;!                       _CCCV_Control
;!                 _ChargeProcess_Slot
;!                   _Charging_Control
;!                   _Led_BlinkProcess
;!                 _PowerOnLedSequence
;!                    _Update_LED_Slot
;!                            ___ftdiv
;!                            ___fttol
;!                           ___lwtoft
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) ___lwtoft                                             3     0      3     912
;!                                              8 COMMON     3     0      3
;!                           ___ftpack
;! ---------------------------------------------------------------------------------
;! (5) ___fttol                                             13     9      4      62
;!                                             12 BANK0     13     9      4
;!                            ___ftdiv (ARG)
;!                           ___lwtoft (ARG)
;! ---------------------------------------------------------------------------------
;! (5) ___ftdiv                                             15     9      6     982
;!                                             11 COMMON     3     3      0
;!                                              0 BANK0     12     6      6
;!                           ___ftpack
;!                           ___lwtoft (ARG)
;! ---------------------------------------------------------------------------------
;! (6) ___ftpack                                             8     3      5     900
;!                                              0 COMMON     8     3      5
;! ---------------------------------------------------------------------------------
;! (5) _Update_LED_Slot                                      2     2      0    1034
;!                                              3 COMMON     2     2      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Led_BlinkProcess                                     8     8      0    1664
;!                                              3 COMMON     8     8      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _Charging_Control                                     5     5      0    1412
;!                                              3 COMMON     5     5      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _ChargeProcess_Slot                                   8     8      0    4217
;!                                              3 COMMON     8     8      0
;!                 _Detect_BatteryType
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (6) _Detect_BatteryType                                   2     0      2     273
;!                                              0 COMMON     2     0      2
;! ---------------------------------------------------------------------------------
;! (5) _CCCV_Control                                        17    17      0    2476
;!                                              8 COMMON     2     2      0
;!                                              0 BANK0     15    15      0
;!                            ___awdiv
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) i1___bmul                                             3     2      1     638
;!                                              0 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (6) ___awdiv                                              8     4      4     428
;!                                              0 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! (5) _ADC_ReadChannel                                      4     2      2     657
;!                                              5 COMMON     4     2      2
;!                         _ADC_Sample
;! ---------------------------------------------------------------------------------
;! (5) _ADC_Sample                                          18    17      1     635
;!                                              0 COMMON     5     4      1
;!                                              0 BANK0     13    13      0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _Print_Status
;!     ___bmul
;!     _uart_send_number
;!       ___lwdiv
;!       ___lwmod
;!       _uart_send_char
;!     _uart_send_string
;!       _uart_send_char
;!   _System_Init
;!     ___bmul
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Interrupt_Isr (ROOT)
;!   _ADC_ReadChannel
;!     _ADC_Sample
;!   _ADC_Sample
;!   _CCCV_Control
;!     ___awdiv
;!     i1___bmul
;!   _ChargeProcess_Slot
;!     _Detect_BatteryType
;!     i1___bmul
;!   _Charging_Control
;!     i1___bmul
;!   _Led_BlinkProcess
;!     i1___bmul
;!   _PowerOnLedSequence
;!   _Update_LED_Slot
;!     i1___bmul
;!   ___ftdiv
;!     ___ftpack
;!     ___lwtoft (ARG)
;!       ___ftpack
;!   ___fttol
;!     ___ftdiv (ARG)
;!       ___ftpack
;!       ___lwtoft (ARG)
;!         ___ftpack
;!     ___lwtoft (ARG)
;!       ___ftpack
;!   ___lwtoft
;!     ___ftpack
;!   i1___bmul
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50      0      48       8       90.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      0      48      10       90.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50     19      27       6       48.8%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     2B      38       4       70.0%
;!BITBANK0            50      0       1       3        1.3%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      E       E       1      100.0%
;!BITCOMMON            E      0       0       0        0.0%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0      FD      12        0.0%
;!ABS                  0      0      FD      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 241 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_Print_Status
;;		_System_Init
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	241
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	241
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	243
	
l5197:	
;main.c: 243: System_Init();
	fcall	_System_Init
	line	250
;main.c: 250: uart_send_string("start...\r\n");
	movlw	(low((((STR_1)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	315
;main.c: 315: while(1)
	
l390:	
	line	317
# 317 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	321
	
l5199:	
;main.c: 321: if(g_printFlag)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u6211
	goto	u6210
u6211:
	goto	l390
u6210:
	line	323
	
l5201:	
;main.c: 322: {
;main.c: 323: g_printFlag = 0;
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	324
	
l5203:	
;main.c: 324: Print_Status();
	fcall	_Print_Status
	goto	l390
	global	start
	ljmp	start
	opt stack 0
	line	329
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 78 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   14[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : B00/900
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      10       0       0
;;      Temps:          0       0       2       0       0
;;      Totals:         0       0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	78
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	78
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	84
	
l4501:	
# 84 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	85
# 85 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text1
	line	89
	
l4503:	
;main.c: 89: OSCCON = 0x72;
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	90
	
l4505:	
;main.c: 90: OPTION_REG = 0x00;
	clrf	(1)	;volatile
	line	91
# 91 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text1
	line	97
	
l4507:	
;main.c: 97: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_System_Init+0)^080h+0+1),f
	movlw	241
movwf	((??_System_Init+0)^080h+0),f
	u6447:
decfsz	((??_System_Init+0)^080h+0),f
	goto	u6447
	decfsz	((??_System_Init+0)^080h+0+1),f
	goto	u6447
opt asmopt_pop

	line	106
	
l4509:	
;main.c: 106: TRISA = 0B11110000;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(133)^080h	;volatile
	line	107
	
l4511:	
;main.c: 107: PORTA = 0B00001111;
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	108
;main.c: 108: WPUA = 0B00000000;
	clrf	(136)^080h	;volatile
	line	109
;main.c: 109: WPDA = 0B00000000;
	clrf	(135)^080h	;volatile
	line	110
;main.c: 110: IOCA = 0B00000000;
	clrf	(137)^080h	;volatile
	line	119
	
l4513:	
;main.c: 119: TRISB = 0B00110000;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	line	120
	
l4515:	
;main.c: 120: PORTB = 0B01001111;
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	121
;main.c: 121: WPUB = 0B00000000;
	clrf	(8)	;volatile
	line	122
;main.c: 122: WPDB = 0B00000000;
	clrf	(7)	;volatile
	line	123
;main.c: 123: IOCB = 0B00000000;
	clrf	(9)	;volatile
	line	133
	
l4517:	
;main.c: 133: TRISC = 0B00000011;
	movlw	low(03h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	line	134
	
l4519:	
;main.c: 134: PORTC = 0B00000000;
	clrf	(262)^0100h	;volatile
	line	135
	
l4521:	
;main.c: 135: WPUC = 0B00000000;
	clrf	(264)^0100h	;volatile
	line	143
	
l4523:	
;main.c: 143: TRISD = 0B11110000;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	line	144
	
l4525:	
;main.c: 144: PORTD = 0B00001111;
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	145
	
l4527:	
;main.c: 145: WPUD = 0B00000000;
	clrf	(277)^0100h	;volatile
	line	152
;main.c: 152: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	154
;main.c: 154: ANSEL1 = 0x20;
	movlw	low(020h)
	movwf	(148)^080h	;volatile
	line	158
;main.c: 158: ANSEL2 = 0x03;
	movlw	low(03h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	159
;main.c: 159: ANSEL3 = 0xF0;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	162
	
l4529:	
;main.c: 162: CC0CON = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	163
	
l4531:	
;main.c: 163: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	168
;main.c: 168: ADCON0 = 0X41;
	movlw	low(041h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	169
	
l4533:	
;main.c: 169: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	175
	
l4535:	
;main.c: 175: TXSTA1 = 0B10100000;
	movlw	low(0A0h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(389)^0180h	;volatile
	line	176
	
l4537:	
;main.c: 176: RCSTA1 = 0B10010000;
	movlw	low(090h)
	movwf	(390)^0180h	;volatile
	line	177
	
l4539:	
;main.c: 177: SPBRG1 = 103;
	movlw	low(067h)
	movwf	(393)^0180h	;volatile
	line	187
	
l4541:	
;main.c: 187: TMR0 = 6;
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(129)^080h	;volatile
	line	188
	
l4543:	
;main.c: 188: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	189
	
l4545:	
;main.c: 189: T0IE = 1;
	bsf	(93/8),(93)&7	;volatile
	line	192
	
l4547:	
;main.c: 192: PEIE = 1;
	bsf	(94/8),(94)&7	;volatile
	line	194
	
l4549:	
;main.c: 194: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	197
	
l4551:	
;main.c: 197: RB6 = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	198
	
l4553:	
;main.c: 198: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	199
	
l4555:	
;main.c: 199: RC3 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	200
	
l4557:	
;main.c: 200: RC2 = 0;
	bcf	(2098/8)^0100h,(2098)&7	;volatile
	line	201
	
l4559:	
;main.c: 201: RC5 = 0;
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	202
	
l4561:	
;main.c: 202: RC4 = 0;
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	205
	
l4563:	
;main.c: 205: for(i = 0; i < 12; i++)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(System_Init@i)^080h
	line	207
	
l4567:	
;main.c: 206: {
;main.c: 207: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->state = 0;
	movlw	low(06h)
	subwf	(System_Init@i)^080h,w
	skipc
	goto	u5151
	goto	u5150
u5151:
	goto	l4571
u5150:
	
l4569:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$254)^080h
	goto	l4573
	
l4571:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_System_Init$254)^080h
	
l4573:	
	incf	(_System_Init$254)^080h,w
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	208
	
l4575:	
;main.c: 208: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->type = 0;
	movlw	low(06h)
	subwf	(System_Init@i)^080h,w
	skipc
	goto	u5161
	goto	u5160
u5161:
	goto	l4579
u5160:
	
l4577:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$265)^080h
	goto	l4581
	
l4579:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_System_Init$265)^080h
	
l4581:	
	movf	(_System_Init$265)^080h,w
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	209
	
l4583:	
;main.c: 209: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->voltage = 0;
	movlw	low(06h)
	subwf	(System_Init@i)^080h,w
	skipc
	goto	u5171
	goto	u5170
u5171:
	goto	l4587
u5170:
	
l4585:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$276)^080h
	goto	l4589
	
l4587:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_System_Init$276)^080h
	
l4589:	
	movf	(_System_Init$276)^080h,w
	addlw	03h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	210
	
l4591:	
;main.c: 210: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->chargeTimer = 0;
	movlw	low(06h)
	subwf	(System_Init@i)^080h,w
	skipc
	goto	u5181
	goto	u5180
u5181:
	goto	l4595
u5180:
	
l4593:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$287)^080h
	goto	l4597
	
l4595:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_System_Init$287)^080h
	
l4597:	
	movf	(_System_Init$287)^080h,w
	addlw	05h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	211
	
l4599:	
;main.c: 211: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->ledState = 0;
	movlw	low(06h)
	subwf	(System_Init@i)^080h,w
	skipc
	goto	u5191
	goto	u5190
u5191:
	goto	l4603
u5190:
	
l4601:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$298)^080h
	goto	l4605
	
l4603:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_System_Init$298)^080h
	
l4605:	
	movf	(_System_Init$298)^080h,w
	addlw	02h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	212
	
l4607:	
;main.c: 212: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->blinkTimer = 0;
	movlw	low(06h)
	subwf	(System_Init@i)^080h,w
	skipc
	goto	u5201
	goto	u5200
u5201:
	goto	l4611
u5200:
	
l4609:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$309)^080h
	goto	l4613
	
l4611:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_System_Init$309)^080h
	
l4613:	
	movf	(_System_Init$309)^080h,w
	addlw	07h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	213
	
l4615:	
;main.c: 213: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->blinkPhase = 0;
	movlw	low(06h)
	subwf	(System_Init@i)^080h,w
	skipc
	goto	u5211
	goto	u5210
u5211:
	goto	l4619
u5210:
	
l4617:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$320)^080h
	goto	l4621
	
l4619:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_System_Init$320)^080h
	
l4621:	
	movf	(_System_Init$320)^080h,w
	addlw	09h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	214
	
l4623:	
;main.c: 214: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->stableCnt = 0;
	movlw	low(06h)
	subwf	(System_Init@i)^080h,w
	skipc
	goto	u5221
	goto	u5220
u5221:
	goto	l4627
u5220:
	
l4625:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$331)^080h
	goto	l4629
	
l4627:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_System_Init$331)^080h
	
l4629:	
	movf	(_System_Init$331)^080h,w
	addlw	0Ah
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	215
	
l4631:	
;main.c: 215: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->activatePulseCnt = 0;
	movlw	low(06h)
	subwf	(System_Init@i)^080h,w
	skipc
	goto	u5231
	goto	u5230
u5231:
	goto	l4635
u5230:
	
l4633:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$342)^080h
	goto	l4637
	
l4635:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_System_Init$342)^080h
	
l4637:	
	movf	(_System_Init$342)^080h,w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	205
	
l4639:	
	incf	(System_Init@i)^080h,f
	
l4641:	
	movlw	low(0Ch)
	subwf	(System_Init@i)^080h,w
	skipc
	goto	u5241
	goto	u5240
u5241:
	goto	l4567
u5240:
	line	219
	
l4643:	
;main.c: 216: }
;main.c: 219: g_scanIndex = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_scanIndex)
	line	220
;main.c: 220: g_scanPhase = 0;
	clrf	(_g_scanPhase)
	line	221
;main.c: 222: g_timerTick = 0;
	clrf	(_g_systemTick)
	clrf	(_g_systemTick+1)
	line	223
;main.c: 223: g_powerOnTimer = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_powerOnTimer)^080h
	clrf	(_g_powerOnTimer+1)^080h
	line	224
;main.c: 224: g_powerOnPhase = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_powerOnPhase)
	line	225
;main.c: 225: g_tempProtect = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	line	226
	
l4645:	
;main.c: 229: g_tempReadRoundCnt = 0;
	movlw	low(019h)
	movwf	(_g_temperature)^080h
	line	230
	
l385:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_Print_Status

;; *************** function _Print_Status *****************
;; Defined at:
;;		line 86 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   24[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       8       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___bmul
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	86
global __ptext2
__ptext2:	;psect for function _Print_Status
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	86
	global	__size_of_Print_Status
	__size_of_Print_Status	equ	__end_of_Print_Status-_Print_Status
	
_Print_Status:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_Status: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	91
	
l4647:	
;uart_dbg.c: 88: unsigned char i;
;uart_dbg.c: 91: uart_send_string("T:");
	movlw	(low((((STR_2)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	92
;uart_dbg.c: 92: uart_send_number(g_temperature);
	movf	(_g_temperature)^080h,w
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	93
;uart_dbg.c: 93: uart_send_string("C NTC:");
	movlw	(low((((STR_3)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	94
;uart_dbg.c: 94: uart_send_number(g_ntcAdc);
	clrf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	95
;uart_dbg.c: 95: uart_send_string(" VDD:");
	movlw	(low((((STR_4)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	96
;uart_dbg.c: 96: uart_send_number(power_ad);
	movf	(_power_ad+1)^080h,w	;volatile
	movwf	(uart_send_number@num+1)^080h
	movf	(_power_ad)^080h,w	;volatile
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	97
;uart_dbg.c: 97: uart_send_string("mV\r\n");
	movlw	(low((((STR_5)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	101
;uart_dbg.c: 101: uart_send_string("DBG: B1=");
	movlw	(low((((STR_6)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	102
;uart_dbg.c: 102: uart_send_number(g_ntcDiagAdc);
	movf	(_g_ntcDiagAdc+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_g_ntcDiagAdc)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	103
;uart_dbg.c: 103: uart_send_string(" VREF=");
	movlw	(low((((STR_7)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	104
;uart_dbg.c: 104: uart_send_number(g_ntcDiagChk);
	movf	(_g_ntcDiagChk+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_g_ntcDiagChk)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	105
;uart_dbg.c: 105: uart_send_string(" sat=");
	movlw	(low((((STR_8)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	106
;uart_dbg.c: 106: uart_send_number(g_ntcDiagVdd);
	movf	(_g_ntcDiagVdd+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_g_ntcDiagVdd)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	107
;uart_dbg.c: 107: uart_send_string(" (B1/VREF/sat)\r\n");
	movlw	(low((((STR_9)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	125
	
l4649:	
;uart_dbg.c: 125: for(i = 0; i < 12; i++)
	clrf	(Print_Status@i)^080h
	line	127
	
l4655:	
;uart_dbg.c: 126: {
;uart_dbg.c: 127: uart_send_string("B");
	movlw	(low((((STR_10)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	128
;uart_dbg.c: 128: uart_send_number(i + 1);
	movf	(Print_Status@i)^080h,w
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	incf	(uart_send_number@num)^080h,f
	skipnz
	incf	(uart_send_number@num+1)^080h,f
	fcall	_uart_send_number
	line	129
;uart_dbg.c: 129: uart_send_string(":V=");
	movlw	(low((((STR_11)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	130
	
l4657:	
;uart_dbg.c: 130: uart_send_number((((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->voltage);
	movlw	low(06h)
	subwf	(Print_Status@i)^080h,w
	skipc
	goto	u5251
	goto	u5250
u5251:
	goto	l4661
u5250:
	
l4659:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_Status@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Print_Status$606)^080h
	goto	l4663
	
l4661:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_Status@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Print_Status$606)^080h
	
l4663:	
	movf	(_Print_Status$606)^080h,w
	addlw	03h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(uart_send_number@num)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	131
	
l4665:	
;uart_dbg.c: 131: uart_send_string(" S=");
	movlw	(low((((STR_12)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	132
	
l4667:	
;uart_dbg.c: 132: uart_send_number((((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->state);
	movlw	low(06h)
	subwf	(Print_Status@i)^080h,w
	skipc
	goto	u5261
	goto	u5260
u5261:
	goto	l4671
u5260:
	
l4669:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_Status@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Print_Status$618)^080h
	goto	l4673
	
l4671:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_Status@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Print_Status$618)^080h
	
l4673:	
	incf	(_Print_Status$618)^080h,w
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	133
	
l4675:	
;uart_dbg.c: 133: uart_send_string(" T=");
	movlw	(low((((STR_13)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	134
	
l4677:	
;uart_dbg.c: 134: uart_send_number((((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->type);
	movlw	low(06h)
	subwf	(Print_Status@i)^080h,w
	skipc
	goto	u5271
	goto	u5270
u5271:
	goto	l4681
u5270:
	
l4679:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_Status@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Print_Status$630)^080h
	goto	l4683
	
l4681:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_Status@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Print_Status$630)^080h
	
l4683:	
	movf	(_Print_Status$630)^080h,w
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	135
	
l4685:	
;uart_dbg.c: 135: if(0 == i)
	bcf	status, 6	;RP1=0, select bank1
	movf	((Print_Status@i)^080h),w
	btfss	status,2
	goto	u5281
	goto	u5280
u5281:
	goto	l4689
u5280:
	line	137
	
l4687:	
;uart_dbg.c: 136: {
;uart_dbg.c: 137: uart_send_string(" because : ");
	movlw	(low((((STR_14)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	138
;uart_dbg.c: 138: uart_send_number(global_test);
	movf	(_global_test+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_global_test)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	141
	
l4689:	
;uart_dbg.c: 139: }
;uart_dbg.c: 141: if((((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->state == 7)
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	subwf	(Print_Status@i)^080h,w
	skipc
	goto	u5291
	goto	u5290
u5291:
	goto	l4693
u5290:
	
l4691:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_Status@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Print_Status$642)^080h
	goto	l4695
	
l4693:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_Status@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Print_Status$642)^080h
	
l4695:	
	incf	(_Print_Status$642)^080h,w
	movwf	fsr0
		movlw	7
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u5301
	goto	u5300
u5301:
	goto	l4699
u5300:
	line	142
	
l4697:	
;uart_dbg.c: 142: uart_send_string(" ERR");
	movlw	(low((((STR_15)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l773
	line	143
	
l4699:	
;uart_dbg.c: 143: else if((((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->state == 6)
	movlw	low(06h)
	subwf	(Print_Status@i)^080h,w
	skipc
	goto	u5311
	goto	u5310
u5311:
	goto	l4703
u5310:
	
l4701:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_Status@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Print_Status$654)^080h
	goto	l4705
	
l4703:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_Status@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Print_Status$654)^080h
	
l4705:	
	incf	(_Print_Status$654)^080h,w
	movwf	fsr0
		movlw	6
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u5321
	goto	u5320
u5321:
	goto	l4709
u5320:
	line	144
	
l4707:	
;uart_dbg.c: 144: uart_send_string(" FULL");
	movlw	(low((((STR_16)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l773
	line	146
	
l4709:	
;uart_dbg.c: 145: else if((((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->state == 4 ||
;uart_dbg.c: 146: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->state == 5)
	movlw	low(06h)
	subwf	(Print_Status@i)^080h,w
	skipc
	goto	u5331
	goto	u5330
u5331:
	goto	l4713
u5330:
	
l4711:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_Status@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Print_Status$676)^080h
	goto	l4715
	
l4713:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_Status@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Print_Status$676)^080h
	
l4715:	
	incf	(_Print_Status$676)^080h,w
	movwf	fsr0
		movlw	4
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfsc	status,2
	goto	u5341
	goto	u5340
u5341:
	goto	l4725
u5340:
	
l4717:	
	movlw	low(06h)
	subwf	(Print_Status@i)^080h,w
	skipc
	goto	u5351
	goto	u5350
u5351:
	goto	l4721
u5350:
	
l4719:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_Status@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Print_Status$677)^080h
	goto	l4723
	
l4721:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_Status@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Print_Status$677)^080h
	
l4723:	
	incf	(_Print_Status$677)^080h,w
	movwf	fsr0
		movlw	5
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u5361
	goto	u5360
u5361:
	goto	l773
u5360:
	line	147
	
l4725:	
;uart_dbg.c: 147: uart_send_string(" CHG");
	movlw	(low((((STR_17)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	149
	
l773:	
;uart_dbg.c: 149: uart_send_string("\r\n");
	movlw	(low((((STR_18)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	125
	
l4727:	
	incf	(Print_Status@i)^080h,f
	
l4729:	
	movlw	low(0Ch)
	subwf	(Print_Status@i)^080h,w
	skipc
	goto	u5371
	goto	u5370
u5371:
	goto	l4655
u5370:
	line	151
	
l791:	
	return
	opt stack 0
GLOBAL	__end_of_Print_Status
	__end_of_Print_Status:
	signat	_Print_Status,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 34 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             1    wreg     PTR const unsigned char 
;;		 -> STR_18(3), STR_17(5), STR_16(6), STR_15(5), 
;;		 -> STR_14(12), STR_13(4), STR_12(4), STR_11(4), 
;;		 -> STR_10(2), STR_9(17), STR_8(6), STR_7(7), 
;;		 -> STR_6(9), STR_5(5), STR_4(6), STR_3(7), 
;;		 -> STR_2(3), STR_1(11), 
;; Auto vars:     Size  Location     Type
;;  str             1    1[BANK1 ] PTR const unsigned char 
;;		 -> STR_18(3), STR_17(5), STR_16(6), STR_15(5), 
;;		 -> STR_14(12), STR_13(4), STR_12(4), STR_11(4), 
;;		 -> STR_10(2), STR_9(17), STR_8(6), STR_7(7), 
;;		 -> STR_6(9), STR_5(5), STR_4(6), STR_3(7), 
;;		 -> STR_2(3), STR_1(11), 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       1       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_main
;;		_Print_Status
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	line	34
global __ptext3
__ptext3:	;psect for function _uart_send_string
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	34
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;uart_send_string@str stored from wreg
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	line	36
	
l4427:	
;uart_dbg.c: 36: while(*str != '\0')
	goto	l4433
	line	37
	
l4429:	
;uart_dbg.c: 37: uart_send_char(*str++);
	movf	(uart_send_string@str)^080h,w
	movwf	fsr0
	fcall	stringdir
	fcall	_uart_send_char
	
l4431:	
	bcf	status, 6	;RP1=0, select bank1
	incf	(uart_send_string@str)^080h,f
	line	36
	
l4433:	
	movf	(uart_send_string@str)^080h,w
	movwf	fsr0
	fcall	stringdir
	xorlw	0
	skipz
	goto	u5011
	goto	u5010
u5011:
	goto	l4429
u5010:
	line	38
	
l741:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 47 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2    7[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    9[BANK1 ] unsigned char [6]
;;  j               1   16[BANK1 ] unsigned char 
;;  i               1   15[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 100/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      10       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_Status
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	line	47
global __ptext4
__ptext4:	;psect for function _uart_send_number
psect	text4
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	47
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 2
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	50
	
l4435:	
;uart_dbg.c: 49: unsigned char buf[6];
;uart_dbg.c: 50: unsigned char i = 0;
	clrf	(uart_send_number@i)^080h
	line	54
	
l4437:	
;uart_dbg.c: 51: unsigned char j;
;uart_dbg.c: 54: if(num == 0)
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u5021
	goto	u5020
u5021:
	goto	l4449
u5020:
	line	56
	
l4439:	
;uart_dbg.c: 55: {
;uart_dbg.c: 56: uart_send_char('0');
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l745
	line	63
	
l4443:	
;uart_dbg.c: 62: {
;uart_dbg.c: 63: buf[i++] = '0' + (num % 10);
	movf	(uart_send_number@i)^080h,w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)^080h
	clrf	(___lwmod@divisor+1)^080h
	movf	(uart_send_number@num+1)^080h,w
	movwf	(___lwmod@dividend+1)^080h
	movf	(uart_send_number@num)^080h,w
	movwf	(___lwmod@dividend)^080h
	fcall	___lwmod
	movf	(0+(?___lwmod))^080h,w
	addlw	030h
	bcf	status, 7	;select IRP bank1
	movwf	indf
	
l4445:	
	incf	(uart_send_number@i)^080h,f
	line	64
	
l4447:	
;uart_dbg.c: 64: num /= 10;
	movlw	0Ah
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(uart_send_number@num+1)^080h,w
	movwf	(___lwdiv@dividend+1)^080h
	movf	(uart_send_number@num)^080h,w
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(uart_send_number@num)^080h
	line	61
	
l4449:	
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u5031
	goto	u5030
u5031:
	goto	l4443
u5030:
	line	68
	
l4451:	
;uart_dbg.c: 65: }
;uart_dbg.c: 68: for(j = i; j > 0; j--)
	movf	(uart_send_number@i)^080h,w
	movwf	(uart_send_number@j)^080h
	
l4453:	
	movf	((uart_send_number@j)^080h),w
	btfss	status,2
	goto	u5041
	goto	u5040
u5041:
	goto	l4457
u5040:
	goto	l745
	line	69
	
l4457:	
;uart_dbg.c: 69: uart_send_char(buf[j-1]);
	movf	(uart_send_number@j)^080h,w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	fcall	_uart_send_char
	line	68
	
l4459:	
	bcf	status, 6	;RP1=0, select bank1
	decf	(uart_send_number@j)^080h,f
	goto	l4453
	line	70
	
l745:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 22 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1    0[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/300
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       1       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	22
global __ptext5
__ptext5:	;psect for function _uart_send_char
psect	text5
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	22
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_char: [wreg]
;uart_send_char@c stored from wreg
	movwf	(uart_send_char@c)^080h
	line	24
	
l4377:	
;uart_dbg.c: 24: while(TRMT1 == 0);
	
l732:	
	bsf	status, 6	;RP1=1, select bank3
	btfss	(3113/8)^0180h,(3113)&7	;volatile
	goto	u4921
	goto	u4920
u4921:
	goto	l732
u4920:
	line	25
	
l4379:	
;uart_dbg.c: 25: TXREG1 = c;
	bcf	status, 6	;RP1=0, select bank1
	movf	(uart_send_char@c)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(391)^0180h	;volatile
	line	26
	
l735:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK1 ] unsigned int 
;;  dividend        2    2[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1    4[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK1 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       4       0       0
;;      Locals:         0       0       1       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       5       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext6
__ptext6:	;psect for function ___lwmod
psect	text6
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l4407:	
	movf	((___lwmod@divisor)^080h),w
iorwf	((___lwmod@divisor+1)^080h),w
	btfsc	status,2
	goto	u4971
	goto	u4970
u4971:
	goto	l4423
u4970:
	line	14
	
l4409:	
	clrf	(___lwmod@counter)^080h
	incf	(___lwmod@counter)^080h,f
	line	15
	goto	l4413
	line	16
	
l4411:	
	clrc
	rlf	(___lwmod@divisor)^080h,f
	rlf	(___lwmod@divisor+1)^080h,f
	line	17
	incf	(___lwmod@counter)^080h,f
	line	15
	
l4413:	
	btfss	(___lwmod@divisor+1)^080h,(15)&7
	goto	u4981
	goto	u4980
u4981:
	goto	l4411
u4980:
	line	20
	
l4415:	
	movf	(___lwmod@divisor+1)^080h,w
	subwf	(___lwmod@dividend+1)^080h,w
	skipz
	goto	u4995
	movf	(___lwmod@divisor)^080h,w
	subwf	(___lwmod@dividend)^080h,w
u4995:
	skipc
	goto	u4991
	goto	u4990
u4991:
	goto	l4419
u4990:
	line	21
	
l4417:	
	movf	(___lwmod@divisor)^080h,w
	subwf	(___lwmod@dividend)^080h,f
	movf	(___lwmod@divisor+1)^080h,w
	skipc
	decf	(___lwmod@dividend+1)^080h,f
	subwf	(___lwmod@dividend+1)^080h,f
	line	22
	
l4419:	
	clrc
	rrf	(___lwmod@divisor+1)^080h,f
	rrf	(___lwmod@divisor)^080h,f
	line	23
	
l4421:	
	decfsz	(___lwmod@counter)^080h,f
	goto	u5001
	goto	u5000
u5001:
	goto	l4415
u5000:
	line	25
	
l4423:	
	movf	(___lwmod@dividend+1)^080h,w
	movwf	(?___lwmod+1)^080h
	movf	(___lwmod@dividend)^080h,w
	movwf	(?___lwmod)^080h
	line	26
	
l1144:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK1 ] unsigned int 
;;  dividend        2    2[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    5[BANK1 ] unsigned int 
;;  counter         1    4[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK1 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/100
;;		On exit  : B00/100
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       4       0       0
;;      Locals:         0       0       3       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       7       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext7
__ptext7:	;psect for function ___lwdiv
psect	text7
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l4381:	
	clrf	(___lwdiv@quotient)^080h
	clrf	(___lwdiv@quotient+1)^080h
	line	15
	
l4383:	
	movf	((___lwdiv@divisor)^080h),w
iorwf	((___lwdiv@divisor+1)^080h),w
	btfsc	status,2
	goto	u4931
	goto	u4930
u4931:
	goto	l4403
u4930:
	line	16
	
l4385:	
	clrf	(___lwdiv@counter)^080h
	incf	(___lwdiv@counter)^080h,f
	line	17
	goto	l4389
	line	18
	
l4387:	
	clrc
	rlf	(___lwdiv@divisor)^080h,f
	rlf	(___lwdiv@divisor+1)^080h,f
	line	19
	incf	(___lwdiv@counter)^080h,f
	line	17
	
l4389:	
	btfss	(___lwdiv@divisor+1)^080h,(15)&7
	goto	u4941
	goto	u4940
u4941:
	goto	l4387
u4940:
	line	22
	
l4391:	
	clrc
	rlf	(___lwdiv@quotient)^080h,f
	rlf	(___lwdiv@quotient+1)^080h,f
	line	23
	
l4393:	
	movf	(___lwdiv@divisor+1)^080h,w
	subwf	(___lwdiv@dividend+1)^080h,w
	skipz
	goto	u4955
	movf	(___lwdiv@divisor)^080h,w
	subwf	(___lwdiv@dividend)^080h,w
u4955:
	skipc
	goto	u4951
	goto	u4950
u4951:
	goto	l4399
u4950:
	line	24
	
l4395:	
	movf	(___lwdiv@divisor)^080h,w
	subwf	(___lwdiv@dividend)^080h,f
	movf	(___lwdiv@divisor+1)^080h,w
	skipc
	decf	(___lwdiv@dividend+1)^080h,f
	subwf	(___lwdiv@dividend+1)^080h,f
	line	25
	
l4397:	
	bsf	(___lwdiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l4399:	
	clrc
	rrf	(___lwdiv@divisor+1)^080h,f
	rrf	(___lwdiv@divisor)^080h,f
	line	28
	
l4401:	
	decfsz	(___lwdiv@counter)^080h,f
	goto	u4961
	goto	u4960
u4961:
	goto	l4391
u4960:
	line	30
	
l4403:	
	movf	(___lwdiv@quotient+1)^080h,w
	movwf	(?___lwdiv+1)^080h
	movf	(___lwdiv@quotient)^080h,w
	movwf	(?___lwdiv)^080h
	line	31
	
l1134:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[BANK1 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    2[BANK1 ] unsigned char 
;;  product         1    1[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       1       0       0
;;      Locals:         0       0       2       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Interrupt_Isr
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;;		_Led_BlinkProcess
;;		_Print_Status
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext8
__ptext8:	;psect for function ___bmul
psect	text8
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	movwf	(___bmul@multiplier)^080h
	line	6
	
l4463:	
	clrf	(___bmul@product)^080h
	line	43
	
l4465:	
	btfss	(___bmul@multiplier)^080h,(0)&7
	goto	u5051
	goto	u5050
u5051:
	goto	l4469
u5050:
	line	44
	
l4467:	
	movf	(___bmul@multiplicand)^080h,w
	addwf	(___bmul@product)^080h,f
	line	45
	
l4469:	
	clrc
	rlf	(___bmul@multiplicand)^080h,f
	line	46
	
l4471:	
	clrc
	rrf	(___bmul@multiplier)^080h,f
	line	47
	movf	((___bmul@multiplier)^080h),w
	btfss	status,2
	goto	u5061
	goto	u5060
u5061:
	goto	l4465
u5060:
	line	50
	
l4473:	
	movf	(___bmul@product)^080h,w
	line	51
	
l815:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_Interrupt_Isr

;; *************** function _Interrupt_Isr *****************
;; Defined at:
;;		line 339 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  power_temp      4   38[BANK0 ] volatile unsigned long 
;;  idx             1   42[BANK0 ] unsigned char 
;;  s               1   37[BANK0 ] unsigned char 
;;  wasCharging     1   36[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      12       0       0       0
;;      Temps:          0       6       0       0       0
;;      Totals:         0      18       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_ADC_ReadChannel
;;		_ADC_Sample
;;		_CCCV_Control
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_Led_BlinkProcess
;;		_PowerOnLedSequence
;;		_Update_LED_Slot
;;		___ftdiv
;;		___fttol
;;		___lwtoft
;;		i1___bmul
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	339
global __ptext9
__ptext9:	;psect for function _Interrupt_Isr
psect	text9
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	339
	global	__size_of_Interrupt_Isr
	__size_of_Interrupt_Isr	equ	__end_of_Interrupt_Isr-_Interrupt_Isr
	
_Interrupt_Isr:	
;incstack = 0
	opt	stack 2
; Regs used in _Interrupt_Isr: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Interrupt_Isr+2)
	movf	fsr0,w
	movwf	(??_Interrupt_Isr+3)
	movf	pclath,w
	movwf	(??_Interrupt_Isr+4)
	movf	btemp+1,w
	movwf	(??_Interrupt_Isr+5)
	ljmp	_Interrupt_Isr
psect	text9
	line	344
	
i1l5205:	
;main.c: 344: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u622_21
	goto	u622_20
u622_21:
	goto	i1l470
u622_20:
	line	346
	
i1l5207:	
;main.c: 345: {
;main.c: 346: TMR0 += 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	addwf	(129)^080h,f	;volatile
	line	347
	
i1l5209:	
;main.c: 348: g_timerTick++;
	bcf	(90/8),(90)&7	;volatile
	line	349
# 349 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text9
	line	355
	
i1l5211:	
;main.c: 355: g_pwmCounter++;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	356
;main.c: 356: if(g_pwmCounter >= 32)
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u623_21
	goto	u623_20
u623_21:
	goto	i1l5215
u623_20:
	line	357
	
i1l5213:	
;main.c: 357: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	358
	
i1l5215:	
;main.c: 358: RB7 = (g_pwmCounter < g_pwmDuty) ? 1 : 0;
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u624_21
	goto	u624_20
	
u624_21:
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(55/8),(55)&7	;volatile
	goto	u625_24
u624_20:
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(55/8),(55)&7	;volatile
u625_24:
	line	361
	
i1l5217:	
;main.c: 361: if(g_powerOnPhase < 2)
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w
	skipnc
	goto	u626_21
	goto	u626_20
u626_21:
	goto	i1l5339
u626_20:
	line	363
	
i1l5219:	
;main.c: 362: {
;main.c: 363: PowerOnLedSequence();
	fcall	_PowerOnLedSequence
	line	364
;main.c: 364: }
	goto	i1l470
	line	376
	
i1l5221:	
;main.c: 375: {
;main.c: 376: unsigned char idx = g_scanIndex;
	movf	(_g_scanIndex),w
	movwf	(Interrupt_Isr@idx)
	line	377
;main.c: 377: unsigned char s = (((idx) < 6) ? &g_slot0[(idx)] : &g_slot1[(idx)-6])->state;
	movlw	low(06h)
	subwf	(Interrupt_Isr@idx),w
	skipc
	goto	u627_21
	goto	u627_20
u627_21:
	goto	i1l5225
u627_20:
	
i1l5223:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Interrupt_Isr@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Interrupt_Isr$368)
	goto	i1l5227
	
i1l5225:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Interrupt_Isr@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Interrupt_Isr$368)
	
i1l5227:	
	incf	(_Interrupt_Isr$368),w
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Interrupt_Isr@s)
	line	379
	
i1l5229:	
;main.c: 378: unsigned char wasCharging = (s == 2 || s == 3 ||
;main.c: 379: s == 4 || s == 5);
	clrf	(_Interrupt_Isr$370)
	incf	(_Interrupt_Isr$370),f
	
i1l5231:	
		movlw	2
	xorwf	((Interrupt_Isr@s)),w
	btfsc	status,2
	goto	u628_21
	goto	u628_20
u628_21:
	goto	i1l5241
u628_20:
	
i1l5233:	
		movlw	3
	xorwf	((Interrupt_Isr@s)),w
	btfsc	status,2
	goto	u629_21
	goto	u629_20
u629_21:
	goto	i1l5241
u629_20:
	
i1l5235:	
		movlw	4
	xorwf	((Interrupt_Isr@s)),w
	btfsc	status,2
	goto	u630_21
	goto	u630_20
u630_21:
	goto	i1l5241
u630_20:
	
i1l5237:	
		movlw	5
	xorwf	((Interrupt_Isr@s)),w
	btfsc	status,2
	goto	u631_21
	goto	u631_20
u631_21:
	goto	i1l5241
u631_20:
	
i1l5239:	
	clrf	(_Interrupt_Isr$370)
	
i1l5241:	
	movf	(_Interrupt_Isr$370),w
	movwf	(Interrupt_Isr@wasCharging)
	line	381
	
i1l5243:	
;main.c: 381: if(wasCharging)
	movf	((Interrupt_Isr@wasCharging)),w
	btfsc	status,2
	goto	u632_21
	goto	u632_20
u632_21:
	goto	i1l411
u632_20:
	goto	i1l5247
	line	383
	
i1l414:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l5249
	
i1l416:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l5249
	
i1l417:	
	bsf	(51/8),(51)&7	;volatile
	goto	i1l5249
	
i1l418:	
	bsf	(50/8),(50)&7	;volatile
	goto	i1l5249
	
i1l419:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l5249
	
i1l420:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l5249
	
i1l421:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l5249
	
i1l422:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l5249
	
i1l423:	
	bsf	(48/8),(48)&7	;volatile
	goto	i1l5249
	
i1l424:	
	bsf	(49/8),(49)&7	;volatile
	goto	i1l5249
	
i1l425:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l5249
	
i1l426:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l5249
	
i1l5247:	
	movf	(Interrupt_Isr@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l414
	xorlw	1^0	; case 1
	skipnz
	goto	i1l416
	xorlw	2^1	; case 2
	skipnz
	goto	i1l417
	xorlw	3^2	; case 3
	skipnz
	goto	i1l418
	xorlw	4^3	; case 4
	skipnz
	goto	i1l419
	xorlw	5^4	; case 5
	skipnz
	goto	i1l420
	xorlw	6^5	; case 6
	skipnz
	goto	i1l421
	xorlw	7^6	; case 7
	skipnz
	goto	i1l422
	xorlw	8^7	; case 8
	skipnz
	goto	i1l423
	xorlw	9^8	; case 9
	skipnz
	goto	i1l424
	xorlw	10^9	; case 10
	skipnz
	goto	i1l425
	xorlw	11^10	; case 11
	skipnz
	goto	i1l426
	goto	i1l5249
	opt asmopt_pop

	line	384
	
i1l5249:	
;main.c: 384: _delay((unsigned long)((30)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	39
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Interrupt_Isr+0)+0),f
	u645_27:
decfsz	(??_Interrupt_Isr+0)+0,f
	goto	u645_27
opt asmopt_pop

	line	385
	
i1l411:	
	line	388
;main.c: 385: }
;main.c: 388: ADCON1 = 7;
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(150)^080h	;volatile
	line	389
;main.c: 389: _delay((unsigned long)((500)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
movlw	3
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Interrupt_Isr+0)+0+1),f
	movlw	151
movwf	((??_Interrupt_Isr+0)+0),f
	u646_27:
decfsz	((??_Interrupt_Isr+0)+0),f
	goto	u646_27
	decfsz	((??_Interrupt_Isr+0)+0+1),f
	goto	u646_27
opt asmopt_pop

	line	391
	
i1l5251:	
;main.c: 391: if(s_adcChannels[idx] & 0x10)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Interrupt_Isr@idx),w
	addlw	low((((_s_adcChannels)-__stringbase)|8000h))
	movwf	fsr0
	fcall	stringdir
	andlw	010h
	btfsc	status,2
	goto	u633_21
	goto	u633_20
u633_21:
	goto	i1l428
u633_20:
	line	392
	
i1l5253:	
;main.c: 392: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	goto	i1l5255
	line	393
	
i1l428:	
	line	394
;main.c: 393: else
;main.c: 394: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	396
	
i1l5255:	
;main.c: 396: (((idx) < 6) ? &g_slot0[(idx)] : &g_slot1[(idx)-6])->voltage = ADC_ReadChannel(s_adcChannels[idx]);
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Interrupt_Isr@idx),w
	skipc
	goto	u634_21
	goto	u634_20
u634_21:
	goto	i1l5259
u634_20:
	
i1l5257:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Interrupt_Isr@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Interrupt_Isr$381)
	goto	i1l5261
	
i1l5259:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Interrupt_Isr@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Interrupt_Isr$381)
	
i1l5261:	
	movf	(Interrupt_Isr@idx),w
	addlw	low((((_s_adcChannels)-__stringbase)|8000h))
	movwf	fsr0
	fcall	stringdir
	fcall	_ADC_ReadChannel
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_Interrupt_Isr$381),w
	addlw	03h
	movwf	fsr0
	movf	(0+(?_ADC_ReadChannel)),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(1+(?_ADC_ReadChannel)),w
	movwf	indf
	line	400
	
i1l5263:	
;main.c: 400: if(idx == 0)
	movf	((Interrupt_Isr@idx)),w
	btfss	status,2
	goto	u635_21
	goto	u635_20
u635_21:
	goto	i1l5285
u635_20:
	line	402
	
i1l5265:	
;main.c: 401: {
;main.c: 402: g_ntcDiagAdc = (((idx) < 6) ? &g_slot0[(idx)] : &g_slot1[(idx)-6])->voltage;
	movlw	low(06h)
	subwf	(Interrupt_Isr@idx),w
	skipc
	goto	u636_21
	goto	u636_20
u636_21:
	goto	i1l5269
u636_20:
	
i1l5267:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Interrupt_Isr@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Interrupt_Isr$392)
	goto	i1l5271
	
i1l5269:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Interrupt_Isr@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Interrupt_Isr$392)
	
i1l5271:	
	movf	(_Interrupt_Isr$392),w
	addlw	03h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_ntcDiagAdc)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(_g_ntcDiagAdc+1)^080h
	line	403
	
i1l5273:	
;main.c: 403: if((((idx) < 6) ? &g_slot0[(idx)] : &g_slot1[(idx)-6])->voltage >= 4095)
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Interrupt_Isr@idx),w
	skipc
	goto	u637_21
	goto	u637_20
u637_21:
	goto	i1l5277
u637_20:
	
i1l5275:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Interrupt_Isr@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Interrupt_Isr$403)
	goto	i1l5279
	
i1l5277:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Interrupt_Isr@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_Interrupt_Isr$403)
	
i1l5279:	
	movf	(_Interrupt_Isr$403),w
	addlw	03h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Interrupt_Isr+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Interrupt_Isr+0)+0+1
	movlw	0Fh
	subwf	1+(??_Interrupt_Isr+0)+0,w
	movlw	0FFh
	skipnz
	subwf	0+(??_Interrupt_Isr+0)+0,w
	skipc
	goto	u638_21
	goto	u638_20
u638_21:
	goto	i1l5283
u638_20:
	line	404
	
i1l5281:	
;main.c: 404: g_ntcDiagVdd++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_ntcDiagVdd)^080h,f
	skipnz
	incf	(_g_ntcDiagVdd+1)^080h,f
	line	408
	
i1l5283:	
;main.c: 408: g_ntcDiagChk = ADC_ReadChannel(31);
	movlw	low(01Fh)
	fcall	_ADC_ReadChannel
	movf	(1+(?_ADC_ReadChannel)),w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_ntcDiagChk+1)^080h
	movf	(0+(?_ADC_ReadChannel)),w
	movwf	(_g_ntcDiagChk)^080h
	line	412
	
i1l5285:	
;main.c: 409: }
;main.c: 412: if(wasCharging)
	bcf	status, 5	;RP0=0, select bank0
	movf	((Interrupt_Isr@wasCharging)),w
	btfsc	status,2
	goto	u639_21
	goto	u639_20
u639_21:
	goto	i1l5293
u639_20:
	goto	i1l5289
	line	414
	
i1l447:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l5291
	
i1l449:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l5291
	
i1l450:	
	bcf	(51/8),(51)&7	;volatile
	goto	i1l5291
	
i1l451:	
	bcf	(50/8),(50)&7	;volatile
	goto	i1l5291
	
i1l452:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l5291
	
i1l453:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l5291
	
i1l454:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l5291
	
i1l455:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l5291
	
i1l456:	
	bcf	(48/8),(48)&7	;volatile
	goto	i1l5291
	
i1l457:	
	bcf	(49/8),(49)&7	;volatile
	goto	i1l5291
	
i1l458:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l5291
	
i1l459:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l5291
	
i1l5289:	
	movf	(Interrupt_Isr@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l447
	xorlw	1^0	; case 1
	skipnz
	goto	i1l449
	xorlw	2^1	; case 2
	skipnz
	goto	i1l450
	xorlw	3^2	; case 3
	skipnz
	goto	i1l451
	xorlw	4^3	; case 4
	skipnz
	goto	i1l452
	xorlw	5^4	; case 5
	skipnz
	goto	i1l453
	xorlw	6^5	; case 6
	skipnz
	goto	i1l454
	xorlw	7^6	; case 7
	skipnz
	goto	i1l455
	xorlw	8^7	; case 8
	skipnz
	goto	i1l456
	xorlw	9^8	; case 9
	skipnz
	goto	i1l457
	xorlw	10^9	; case 10
	skipnz
	goto	i1l458
	xorlw	11^10	; case 11
	skipnz
	goto	i1l459
	goto	i1l5291
	opt asmopt_pop

	line	415
	
i1l5291:	
;main.c: 415: _delay((unsigned long)((10)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	12
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Interrupt_Isr+0)+0),f
	u647_27:
decfsz	(??_Interrupt_Isr+0)+0,f
	goto	u647_27
	nop
opt asmopt_pop

	line	417
	
i1l5293:	
;main.c: 416: }
;main.c: 417: g_scanPhase = 1;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_scanPhase)
	incf	(_g_scanPhase),f
	line	419
;main.c: 418: }
;main.c: 419: break;
	goto	i1l470
	line	425
	
i1l5295:	
;main.c: 425: ChargeProcess_Slot(g_scanIndex);
	movf	(_g_scanIndex),w
	fcall	_ChargeProcess_Slot
	line	426
;main.c: 426: Update_LED_Slot(g_scanIndex);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_scanIndex),w
	fcall	_Update_LED_Slot
	line	427
	
i1l5297:	
;main.c: 427: g_scanPhase = 2;
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_scanPhase)
	line	428
;main.c: 428: break;
	goto	i1l470
	line	438
	
i1l5299:	
;main.c: 438: if(g_scanIndex == 0)
	movf	((_g_scanIndex)),w
	btfss	status,2
	goto	u640_21
	goto	u640_20
u640_21:
	goto	i1l5305
u640_20:
	line	483
	
i1l5301:	
;main.c: 439: {
;main.c: 483: Led_BlinkProcess();
	fcall	_Led_BlinkProcess
	line	485
;main.c: 485: Charging_Control();
	fcall	_Charging_Control
	line	487
	
i1l5303:	
;main.c: 487: CCCV_Control();
	fcall	_CCCV_Control
	line	491
	
i1l5305:	
;main.c: 488: }
;main.c: 491: g_scanIndex++;
	incf	(_g_scanIndex),f
	line	492
	
i1l5307:	
;main.c: 492: if(g_scanIndex >= 12)
	movlw	low(0Ch)
	subwf	(_g_scanIndex),w
	skipc
	goto	u641_21
	goto	u641_20
u641_21:
	goto	i1l5313
u641_20:
	line	494
	
i1l5309:	
;main.c: 493: {
;main.c: 494: g_scanIndex = 0;
	clrf	(_g_scanIndex)
	line	495
	
i1l5311:	
;main.c: 495: g_systemTick++;
	incf	(_g_systemTick),f
	skipnz
	incf	(_g_systemTick+1),f
	line	497
	
i1l5313:	
;main.c: 496: }
;main.c: 497: g_scanPhase = 0;
	clrf	(_g_scanPhase)
	line	501
	
i1l5315:	
;main.c: 501: if(g_systemTick >= 100)
	movlw	0
	subwf	(_g_systemTick+1),w
	movlw	064h
	skipnz
	subwf	(_g_systemTick),w
	skipc
	goto	u642_21
	goto	u642_20
u642_21:
	goto	i1l402
u642_20:
	line	503
	
i1l5317:	
;main.c: 502: {
;main.c: 503: g_systemTick = 0;
	clrf	(_g_systemTick)
	clrf	(_g_systemTick+1)
	line	509
	
i1l5319:	
;main.c: 509: test_adc = ADC_Sample(31, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	510
	
i1l5321:	
;main.c: 510: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u643_21
	goto	u643_20
u643_21:
	goto	i1l5327
u643_20:
	line	514
	
i1l5323:	
;main.c: 511: {
;main.c: 512: volatile unsigned long power_temp;
;main.c: 514: power_temp = (unsigned long)(((4096UL*1.2*1000))/adresult);
	movlw	0x0
	movwf	(___ftdiv@f1)
	movlw	0x96
	movwf	(___ftdiv@f1+1)
	movlw	0x4a
	movwf	(___ftdiv@f1+2)
	movf	(_adresult+1),w	;volatile
	movwf	(___lwtoft@c+1)
	movf	(_adresult),w	;volatile
	movwf	(___lwtoft@c)
	fcall	___lwtoft
	movf	(0+(?___lwtoft)),w
	movwf	(___ftdiv@f2)
	movf	(1+(?___lwtoft)),w
	movwf	(___ftdiv@f2+1)
	movf	(2+(?___lwtoft)),w
	movwf	(___ftdiv@f2+2)
	fcall	___ftdiv
	movf	(0+(?___ftdiv)),w
	movwf	(___fttol@f1)
	movf	(1+(?___ftdiv)),w
	movwf	(___fttol@f1+1)
	movf	(2+(?___ftdiv)),w
	movwf	(___fttol@f1+2)
	fcall	___fttol
	movf	(3+(?___fttol)),w
	movwf	(Interrupt_Isr@power_temp+3)	;volatile
	movf	(2+(?___fttol)),w
	movwf	(Interrupt_Isr@power_temp+2)	;volatile
	movf	(1+(?___fttol)),w
	movwf	(Interrupt_Isr@power_temp+1)	;volatile
	movf	(0+(?___fttol)),w
	movwf	(Interrupt_Isr@power_temp)	;volatile

	line	515
	
i1l5325:	
;main.c: 515: power_ad = (unsigned int)(power_temp);
	movf	(Interrupt_Isr@power_temp+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_power_ad+1)^080h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(Interrupt_Isr@power_temp),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_power_ad)^080h	;volatile
	line	516
;main.c: 516: }
	goto	i1l5329
	line	520
	
i1l5327:	
;main.c: 517: else
;main.c: 518: {
;main.c: 520: ADCON0 = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(149)^080h	;volatile
	line	524
	
i1l5329:	
;main.c: 521: }
;main.c: 524: ADCON1 = 7;
	movlw	low(07h)
	movwf	(150)^080h	;volatile
	line	525
	
i1l5331:	
;main.c: 525: _delay((unsigned long)((500)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
movlw	3
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Interrupt_Isr+0)+0+1),f
	movlw	151
movwf	((??_Interrupt_Isr+0)+0),f
	u648_27:
decfsz	((??_Interrupt_Isr+0)+0),f
	goto	u648_27
	decfsz	((??_Interrupt_Isr+0)+0+1),f
	goto	u648_27
opt asmopt_pop

	line	528
;main.c: 528: g_ntcDiagVdd = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(_g_ntcDiagVdd)^080h
	clrf	(_g_ntcDiagVdd+1)^080h
	line	532
	
i1l5333:	
;main.c: 532: g_printFlag = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	i1l470
	line	538
	
i1l5335:	
;main.c: 538: g_scanPhase = 0;
	clrf	(_g_scanPhase)
	line	539
;main.c: 539: break;
	goto	i1l470
	line	368
	
i1l5339:	
	movf	(_g_scanPhase),w
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 2
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           17     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l5221
	xorlw	1^0	; case 1
	skipnz
	goto	i1l5295
	xorlw	2^1	; case 2
	skipnz
	goto	i1l5299
	goto	i1l5335
	opt asmopt_pop

	line	541
	
i1l402:	
	line	545
	
i1l470:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(??_Interrupt_Isr+5),w
	movwf	btemp+1
	movf	(??_Interrupt_Isr+4),w
	movwf	pclath
	movf	(??_Interrupt_Isr+3),w
	movwf	fsr0
	swapf	(??_Interrupt_Isr+2)^00h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Interrupt_Isr
	__end_of_Interrupt_Isr:
	signat	_Interrupt_Isr,89
	global	___lwtoft

;; *************** function ___lwtoft *****************
;; Defined at:
;;		line 28 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwtoft.c"
;; Parameters:    Size  Location     Type
;;  c               2    8[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  3    8[COMMON] float 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         3       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___ftpack
;; This function is called by:
;;		_Interrupt_Isr
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwtoft.c"
	line	28
global __ptext10
__ptext10:	;psect for function ___lwtoft
psect	text10
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwtoft.c"
	line	28
	global	__size_of___lwtoft
	__size_of___lwtoft	equ	__end_of___lwtoft-___lwtoft
	
___lwtoft:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwtoft: [wreg+status,2+status,0+pclath+cstack]
	line	30
	
i1l5193:	
	movf	(___lwtoft@c),w
	movwf	(___ftpack@arg)
	movf	(___lwtoft@c+1),w
	movwf	(___ftpack@arg+1)
	clrf	(___ftpack@arg+2)
	movlw	low(08Eh)
	movwf	(___ftpack@exp)
	clrf	(___ftpack@sign)
	fcall	___ftpack
	movf	(0+(?___ftpack)),w
	movwf	(?___lwtoft)
	movf	(1+(?___ftpack)),w
	movwf	(?___lwtoft+1)
	movf	(2+(?___ftpack)),w
	movwf	(?___lwtoft+2)
	line	31
	
i1l1149:	
	return
	opt stack 0
GLOBAL	__end_of___lwtoft
	__end_of___lwtoft:
	signat	___lwtoft,4219
	global	___fttol

;; *************** function ___fttol *****************
;; Defined at:
;;		line 44 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\fttol.c"
;; Parameters:    Size  Location     Type
;;  f1              3   12[BANK0 ] float 
;; Auto vars:     Size  Location     Type
;;  lval            4   20[BANK0 ] unsigned long 
;;  exp1            1   24[BANK0 ] unsigned char 
;;  sign1           1   19[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4   12[BANK0 ] long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       6       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0      13       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Interrupt_Isr
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\fttol.c"
	line	44
global __ptext11
__ptext11:	;psect for function ___fttol
psect	text11
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\fttol.c"
	line	44
	global	__size_of___fttol
	__size_of___fttol	equ	__end_of___fttol-___fttol
	
___fttol:	
;incstack = 0
	opt	stack 3
; Regs used in ___fttol: [wreg+status,2+status,0]
	line	49
	
i1l5153:	
	movf	(___fttol@f1),w
	movwf	((??___fttol+0)+0)
	movf	(___fttol@f1+1),w
	movwf	((??___fttol+0)+0+1)
	movf	(___fttol@f1+2),w
	movwf	((??___fttol+0)+0+2)
	clrc
	rlf	(??___fttol+0)+1,w
	rlf	(??___fttol+0)+2,w
	movwf	(___fttol@exp1)
	movf	(((___fttol@exp1))),w
	btfss	status,2
	goto	u613_21
	goto	u613_20
u613_21:
	goto	i1l5157
u613_20:
	line	50
	
i1l5155:	
	clrf	(?___fttol)
	clrf	(?___fttol+1)
	clrf	(?___fttol+2)
	clrf	(?___fttol+3)
	goto	i1l1040
	line	51
	
i1l5157:	
	movf	(___fttol@f1),w
	movwf	((??___fttol+0)+0)
	movf	(___fttol@f1+1),w
	movwf	((??___fttol+0)+0+1)
	movf	(___fttol@f1+2),w
	movwf	((??___fttol+0)+0+2)
	movlw	017h
u614_25:
	clrc
	rrf	(??___fttol+0)+2,f
	rrf	(??___fttol+0)+1,f
	rrf	(??___fttol+0)+0,f
u614_20:
	addlw	-1
	skipz
	goto	u614_25
	movf	0+(??___fttol+0)+0,w
	movwf	(___fttol@sign1)
	line	52
	
i1l5159:	
	bsf	(___fttol@f1)+(15/8),(15)&7
	line	53
	
i1l5161:	
	movlw	0FFh
	andwf	(___fttol@f1),f
	movlw	0FFh
	andwf	(___fttol@f1+1),f
	movlw	0
	andwf	(___fttol@f1+2),f
	line	54
	
i1l5163:	
	movf	(___fttol@f1),w
	movwf	(___fttol@lval)
	movf	(___fttol@f1+1),w
	movwf	((___fttol@lval))+1
	movf	(___fttol@f1+2),w
	movwf	((___fttol@lval))+2
	clrf	((___fttol@lval))+3
	line	55
	
i1l5165:	
	movlw	08Eh
	subwf	(___fttol@exp1),f
	line	56
	
i1l5167:	
	btfss	(___fttol@exp1),7
	goto	u615_21
	goto	u615_20
u615_21:
	goto	i1l5177
u615_20:
	line	57
	
i1l5169:	
	movf	(___fttol@exp1),w
	xorlw	80h
	addlw	-((-15)^80h)
	skipnc
	goto	u616_21
	goto	u616_20
u616_21:
	goto	i1l5173
u616_20:
	goto	i1l5155
	line	60
	
i1l5173:	
	clrc
	rrf	(___fttol@lval+3),f
	rrf	(___fttol@lval+2),f
	rrf	(___fttol@lval+1),f
	rrf	(___fttol@lval),f
	line	61
	
i1l5175:	
	incfsz	(___fttol@exp1),f
	goto	u617_21
	goto	u617_20
u617_21:
	goto	i1l5173
u617_20:
	goto	i1l5185
	line	63
	
i1l5177:	
	movlw	low(018h)
	subwf	(___fttol@exp1),w
	skipc
	goto	u618_21
	goto	u618_20
u618_21:
	goto	i1l5183
u618_20:
	goto	i1l5155
	line	66
	
i1l5181:	
	clrc
	rlf	(___fttol@lval),f
	rlf	(___fttol@lval+1),f
	rlf	(___fttol@lval+2),f
	rlf	(___fttol@lval+3),f
	line	67
	decf	(___fttol@exp1),f
	line	65
	
i1l5183:	
	movf	((___fttol@exp1)),w
	btfss	status,2
	goto	u619_21
	goto	u619_20
u619_21:
	goto	i1l5181
u619_20:
	line	70
	
i1l5185:	
	movf	((___fttol@sign1)),w
	btfsc	status,2
	goto	u620_21
	goto	u620_20
u620_21:
	goto	i1l5189
u620_20:
	line	71
	
i1l5187:	
	comf	(___fttol@lval),f
	comf	(___fttol@lval+1),f
	comf	(___fttol@lval+2),f
	comf	(___fttol@lval+3),f
	incf	(___fttol@lval),f
	skipnz
	incf	(___fttol@lval+1),f
	skipnz
	incf	(___fttol@lval+2),f
	skipnz
	incf	(___fttol@lval+3),f
	line	72
	
i1l5189:	
	movf	(___fttol@lval+3),w
	movwf	(?___fttol+3)
	movf	(___fttol@lval+2),w
	movwf	(?___fttol+2)
	movf	(___fttol@lval+1),w
	movwf	(?___fttol+1)
	movf	(___fttol@lval),w
	movwf	(?___fttol)

	line	73
	
i1l1040:	
	return
	opt stack 0
GLOBAL	__end_of___fttol
	__end_of___fttol:
	signat	___fttol,4220
	global	___ftdiv

;; *************** function ___ftdiv *****************
;; Defined at:
;;		line 56 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\ftdiv.c"
;; Parameters:    Size  Location     Type
;;  f2              3    0[BANK0 ] float 
;;  f1              3    3[BANK0 ] float 
;; Auto vars:     Size  Location     Type
;;  f3              3    7[BANK0 ] float 
;;  sign            1   11[BANK0 ] unsigned char 
;;  exp             1   10[BANK0 ] unsigned char 
;;  cntr            1    6[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  3    0[BANK0 ] float 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       6       0       0       0
;;      Locals:         0       6       0       0       0
;;      Temps:          3       0       0       0       0
;;      Totals:         3      12       0       0       0
;;Total ram usage:       15 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___ftpack
;; This function is called by:
;;		_Interrupt_Isr
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\ftdiv.c"
	line	56
global __ptext12
__ptext12:	;psect for function ___ftdiv
psect	text12
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\ftdiv.c"
	line	56
	global	__size_of___ftdiv
	__size_of___ftdiv	equ	__end_of___ftdiv-___ftdiv
	
___ftdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___ftdiv: [wreg+status,2+status,0+pclath+cstack]
	line	63
	
i1l5113:	
	movf	(___ftdiv@f1),w
	movwf	((??___ftdiv+0)+0)
	movf	(___ftdiv@f1+1),w
	movwf	((??___ftdiv+0)+0+1)
	movf	(___ftdiv@f1+2),w
	movwf	((??___ftdiv+0)+0+2)
	clrc
	rlf	(??___ftdiv+0)+1,w
	rlf	(??___ftdiv+0)+2,w
	movwf	(___ftdiv@exp)
	movf	(((___ftdiv@exp))),w
	btfss	status,2
	goto	u609_21
	goto	u609_20
u609_21:
	goto	i1l5117
u609_20:
	line	64
	
i1l5115:	
	clrf	(?___ftdiv)
	clrf	(?___ftdiv+1)
	clrf	(?___ftdiv+2)
	goto	i1l1004
	line	65
	
i1l5117:	
	movf	(___ftdiv@f2),w
	movwf	((??___ftdiv+0)+0)
	movf	(___ftdiv@f2+1),w
	movwf	((??___ftdiv+0)+0+1)
	movf	(___ftdiv@f2+2),w
	movwf	((??___ftdiv+0)+0+2)
	clrc
	rlf	(??___ftdiv+0)+1,w
	rlf	(??___ftdiv+0)+2,w
	movwf	(___ftdiv@sign)
	movf	(((___ftdiv@sign))),w
	btfss	status,2
	goto	u610_21
	goto	u610_20
u610_21:
	goto	i1l1005
u610_20:
	line	66
	
i1l5119:	
	clrf	(?___ftdiv)
	clrf	(?___ftdiv+1)
	clrf	(?___ftdiv+2)
	goto	i1l1004
	
i1l1005:	
	line	67
	clrf	(___ftdiv@f3)
	clrf	(___ftdiv@f3+1)
	clrf	(___ftdiv@f3+2)
	line	68
	
i1l5121:	
	movlw	low(089h)
	addwf	(___ftdiv@sign),w
	movwf	(??___ftdiv+0)+0
	movf	0+(??___ftdiv+0)+0,w
	subwf	(___ftdiv@exp),f
	line	69
	
i1l5123:	
	movf	0+(___ftdiv@f1)+02h,w
	movwf	(___ftdiv@sign)
	line	70
	
i1l5125:	
	movf	0+(___ftdiv@f2)+02h,w
	xorwf	(___ftdiv@sign),f
	line	71
	
i1l5127:	
	movlw	low(080h)
	andwf	(___ftdiv@sign),f
	line	72
	
i1l5129:	
	bsf	(___ftdiv@f1)+(15/8),(15)&7
	line	73
	
i1l5131:	
	movlw	0FFh
	andwf	(___ftdiv@f1),f
	movlw	0FFh
	andwf	(___ftdiv@f1+1),f
	movlw	0
	andwf	(___ftdiv@f1+2),f
	line	74
	
i1l5133:	
	bsf	(___ftdiv@f2)+(15/8),(15)&7
	line	75
	
i1l5135:	
	movlw	0FFh
	andwf	(___ftdiv@f2),f
	movlw	0FFh
	andwf	(___ftdiv@f2+1),f
	movlw	0
	andwf	(___ftdiv@f2+2),f
	line	76
	
i1l5137:	
	movlw	low(018h)
	movwf	(___ftdiv@cntr)
	line	78
	
i1l5139:	
	clrc
	rlf	(___ftdiv@f3),f
	rlf	(___ftdiv@f3+1),f
	rlf	(___ftdiv@f3+2),f
	line	79
	movf	(___ftdiv@f2+2),w
	subwf	(___ftdiv@f1+2),w
	skipz
	goto	u611_25
	movf	(___ftdiv@f2+1),w
	subwf	(___ftdiv@f1+1),w
	skipz
	goto	u611_25
	movf	(___ftdiv@f2),w
	subwf	(___ftdiv@f1),w
u611_25:
	skipc
	goto	u611_21
	goto	u611_20
u611_21:
	goto	i1l5145
u611_20:
	line	80
	
i1l5141:	
	movf	(___ftdiv@f2),w
	subwf	(___ftdiv@f1),f
	movf	(___ftdiv@f2+1),w
	skipc
	incfsz	(___ftdiv@f2+1),w
	subwf	(___ftdiv@f1+1),f
	movf	(___ftdiv@f2+2),w
	skipc
	incf	(___ftdiv@f2+2),w
	subwf	(___ftdiv@f1+2),f
	line	81
	
i1l5143:	
	bsf	(___ftdiv@f3)+(0/8),(0)&7
	line	83
	
i1l5145:	
	clrc
	rlf	(___ftdiv@f1),f
	rlf	(___ftdiv@f1+1),f
	rlf	(___ftdiv@f1+2),f
	line	84
	
i1l5147:	
	decfsz	(___ftdiv@cntr),f
	goto	u612_21
	goto	u612_20
u612_21:
	goto	i1l5139
u612_20:
	line	85
	
i1l5149:	
	movf	(___ftdiv@f3),w
	movwf	(___ftpack@arg)
	movf	(___ftdiv@f3+1),w
	movwf	(___ftpack@arg+1)
	movf	(___ftdiv@f3+2),w
	movwf	(___ftpack@arg+2)
	movf	(___ftdiv@exp),w
	movwf	(___ftpack@exp)
	movf	(___ftdiv@sign),w
	movwf	(___ftpack@sign)
	fcall	___ftpack
	movf	(0+(?___ftpack)),w
	movwf	(?___ftdiv)
	movf	(1+(?___ftpack)),w
	movwf	(?___ftdiv+1)
	movf	(2+(?___ftpack)),w
	movwf	(?___ftdiv+2)
	line	86
	
i1l1004:	
	return
	opt stack 0
GLOBAL	__end_of___ftdiv
	__end_of___ftdiv:
	signat	___ftdiv,8315
	global	___ftpack

;; *************** function ___ftpack *****************
;; Defined at:
;;		line 62 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\float.c"
;; Parameters:    Size  Location     Type
;;  arg             3    0[COMMON] unsigned um
;;  exp             1    3[COMMON] unsigned char 
;;  sign            1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  3    0[COMMON] float 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         5       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          3       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___lwtoft
;;		___ftdiv
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\float.c"
	line	62
global __ptext13
__ptext13:	;psect for function ___ftpack
psect	text13
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\float.c"
	line	62
	global	__size_of___ftpack
	__size_of___ftpack	equ	__end_of___ftpack-___ftpack
	
___ftpack:	
;incstack = 0
	opt	stack 2
; Regs used in ___ftpack: [wreg+status,2+status,0]
	line	64
	
i1l4477:	
	movf	((___ftpack@exp)),w
	btfsc	status,2
	goto	u507_21
	goto	u507_20
u507_21:
	goto	i1l951
u507_20:
	
i1l4479:	
	movf	(___ftpack@arg+2),w
	iorwf	(___ftpack@arg+1),w
	iorwf	(___ftpack@arg),w
	skipz
	goto	u508_21
	goto	u508_20
u508_21:
	goto	i1l4483
u508_20:
	
i1l951:	
	line	65
	clrf	(?___ftpack)
	clrf	(?___ftpack+1)
	clrf	(?___ftpack+2)
	goto	i1l952
	line	67
	
i1l4481:	
	incf	(___ftpack@exp),f
	line	68
	clrc
	rrf	(___ftpack@arg+2),f
	rrf	(___ftpack@arg+1),f
	rrf	(___ftpack@arg),f
	line	66
	
i1l4483:	
	movlw	low highword(0FE0000h)
	andwf	(___ftpack@arg+2),w
	btfss	status,2
	goto	u509_21
	goto	u509_20
u509_21:
	goto	i1l4481
u509_20:
	goto	i1l4487
	line	71
	
i1l4485:	
	incf	(___ftpack@exp),f
	line	72
	incf	(___ftpack@arg),f
	skipnz
	incf	(___ftpack@arg+1),f
	skipnz
	incf	(___ftpack@arg+2),f
	line	73
	clrc
	rrf	(___ftpack@arg+2),f
	rrf	(___ftpack@arg+1),f
	rrf	(___ftpack@arg),f
	line	70
	
i1l4487:	
	movlw	low highword(0FF0000h)
	andwf	(___ftpack@arg+2),w
	btfss	status,2
	goto	u510_21
	goto	u510_20
u510_21:
	goto	i1l4485
u510_20:
	goto	i1l4491
	line	76
	
i1l4489:	
	decf	(___ftpack@exp),f
	line	77
	clrc
	rlf	(___ftpack@arg),f
	rlf	(___ftpack@arg+1),f
	rlf	(___ftpack@arg+2),f
	line	75
	
i1l4491:	
	btfsc	(___ftpack@arg+1),(15)&7
	goto	u511_21
	goto	u511_20
u511_21:
	goto	i1l963
u511_20:
	
i1l4493:	
	movlw	low(02h)
	subwf	(___ftpack@exp),w
	skipnc
	goto	u512_21
	goto	u512_20
u512_21:
	goto	i1l4489
u512_20:
	
i1l963:	
	line	79
	btfsc	(___ftpack@exp),(0)&7
	goto	u513_21
	goto	u513_20
u513_21:
	goto	i1l964
u513_20:
	line	80
	
i1l4495:	
	bcf	(___ftpack@arg)+(15/8),(15)&7
	
i1l964:	
	line	81
	clrc
	rrf	(___ftpack@exp),f
	line	82
	
i1l4497:	
	movf	(___ftpack@exp),w
	movwf	((??___ftpack+0)+0+2)
	clrf	((??___ftpack+0)+0+1)
	clrf	((??___ftpack+0)+0+0)
	movf	0+(??___ftpack+0)+0,w
	iorwf	(___ftpack@arg),f
	movf	1+(??___ftpack+0)+0,w
	iorwf	(___ftpack@arg+1),f
	movf	2+(??___ftpack+0)+0,w
	iorwf	(___ftpack@arg+2),f
	line	83
	movf	((___ftpack@sign)),w
	btfsc	status,2
	goto	u514_21
	goto	u514_20
u514_21:
	goto	i1l965
u514_20:
	line	84
	
i1l4499:	
	bsf	(___ftpack@arg)+(23/8),(23)&7
	
i1l965:	
	line	85
	line	86
	
i1l952:	
	return
	opt stack 0
GLOBAL	__end_of___ftpack
	__end_of___ftpack:
	signat	___ftpack,12411
	global	_Update_LED_Slot

;; *************** function _Update_LED_Slot *****************
;; Defined at:
;;		line 30 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    3[COMMON] unsigned char 
;;  p               1    4[COMMON] PTR struct .
;;		 -> g_slot1(72), g_slot0(72), 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Interrupt_Isr
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	30
global __ptext14
__ptext14:	;psect for function _Update_LED_Slot
psect	text14
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	30
	global	__size_of_Update_LED_Slot
	__size_of_Update_LED_Slot	equ	__end_of_Update_LED_Slot-_Update_LED_Slot
	
_Update_LED_Slot:	
;incstack = 0
	opt	stack 2
; Regs used in _Update_LED_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Update_LED_Slot@idx stored from wreg
	movwf	(Update_LED_Slot@idx)
	line	32
	
i1l4893:	
;led.c: 32: BatterySlot_t *p = (((idx) < 6) ? &g_slot0[(idx)] : &g_slot1[(idx)-6]);
	movlw	low(06h)
	subwf	(Update_LED_Slot@idx),w
	skipc
	goto	u568_21
	goto	u568_20
u568_21:
	goto	i1l4897
u568_20:
	
i1l4895:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Update_LED_Slot@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(Update_LED_Slot@p)
	goto	i1l4911
	
i1l4897:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Update_LED_Slot@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(Update_LED_Slot@p)
	goto	i1l4911
	line	37
	
i1l4899:	
;led.c: 37: p->ledState = 0;
	movf	(Update_LED_Slot@p),w
	addlw	02h
	movwf	fsr0
	clrf	indf
	line	38
;led.c: 38: break;
	goto	i1l694
	line	42
	
i1l689:	
	line	44
	
i1l4901:	
;led.c: 40: case 2:
;led.c: 41: case 3:
;led.c: 42: case 4:
;led.c: 43: case 5:
;led.c: 44: p->ledState = 1;
	movf	(Update_LED_Slot@p),w
	addlw	02h
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	45
;led.c: 45: break;
	goto	i1l694
	line	47
	
i1l4903:	
;led.c: 47: p->ledState = 2;
	movf	(Update_LED_Slot@p),w
	addlw	02h
	movwf	fsr0
	movlw	low(02h)
	movwf	indf
	line	48
;led.c: 48: break;
	goto	i1l694
	line	50
	
i1l4905:	
;led.c: 50: p->ledState = 3;
	movf	(Update_LED_Slot@p),w
	addlw	02h
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	line	51
;led.c: 51: break;
	goto	i1l694
	line	53
	
i1l4907:	
;led.c: 53: p->ledState = 0;
	movf	(Update_LED_Slot@p),w
	addlw	02h
	movwf	fsr0
	clrf	indf
	line	54
;led.c: 54: break;
	goto	i1l694
	line	34
	
i1l4911:	
	incf	(Update_LED_Slot@p),w
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 8, Range of values is 0 to 7
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           25    13 (average)
; direct_byte           32     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l4899
	xorlw	1^0	; case 1
	skipnz
	goto	i1l689
	xorlw	2^1	; case 2
	skipnz
	goto	i1l4901
	xorlw	3^2	; case 3
	skipnz
	goto	i1l4901
	xorlw	4^3	; case 4
	skipnz
	goto	i1l4901
	xorlw	5^4	; case 5
	skipnz
	goto	i1l4901
	xorlw	6^5	; case 6
	skipnz
	goto	i1l4903
	xorlw	7^6	; case 7
	skipnz
	goto	i1l4905
	goto	i1l4907
	opt asmopt_pop

	line	56
	
i1l694:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Slot
	__end_of_Update_LED_Slot:
	signat	_Update_LED_Slot,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 95 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Interrupt_Isr
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=0
	line	95
global __ptext15
__ptext15:	;psect for function _PowerOnLedSequence
psect	text15
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	95
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	97
	
i1l2847:	
;led.c: 97: g_powerOnTimer++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_powerOnTimer)^080h,f
	skipnz
	incf	(_g_powerOnTimer+1)^080h,f
	line	99
	
i1l2849:	
;led.c: 99: if(g_powerOnPhase == 0)
	bcf	status, 5	;RP0=0, select bank0
	movf	((_g_powerOnPhase)),w
	btfss	status,2
	goto	u241_21
	goto	u241_20
u241_21:
	goto	i1l2859
u241_20:
	line	102
	
i1l2851:	
;led.c: 100: {
;led.c: 102: RC5 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	103
;led.c: 103: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	104
	
i1l2853:	
;led.c: 104: if(g_powerOnTimer >= 100)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w
	skipc
	goto	u242_21
	goto	u242_20
u242_21:
	goto	i1l729
u242_20:
	line	106
	
i1l2855:	
;led.c: 105: {
;led.c: 106: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)^080h
	clrf	(_g_powerOnTimer+1)^080h
	line	107
	
i1l2857:	
;led.c: 107: g_powerOnPhase = 1;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_powerOnPhase)
	incf	(_g_powerOnPhase),f
	goto	i1l729
	line	110
	
i1l2859:	
;led.c: 110: else if(g_powerOnPhase == 1)
		decf	((_g_powerOnPhase)),w
	btfss	status,2
	goto	u243_21
	goto	u243_20
u243_21:
	goto	i1l729
u243_20:
	line	113
	
i1l2861:	
;led.c: 111: {
;led.c: 113: if(g_powerOnTimer >= 100)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w
	skipc
	goto	u244_21
	goto	u244_20
u244_21:
	goto	i1l729
u244_20:
	line	115
	
i1l2863:	
;led.c: 114: {
;led.c: 115: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)^080h
	clrf	(_g_powerOnTimer+1)^080h
	line	116
	
i1l2865:	
;led.c: 116: g_powerOnPhase = 2;
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_powerOnPhase)
	line	117
	
i1l2867:	
;led.c: 117: RC5 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	118
	
i1l2869:	
;led.c: 118: RC4 = 0;
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	122
	
i1l729:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
	global	_Led_BlinkProcess

;; *************** function _Led_BlinkProcess *****************
;; Defined at:
;;		line 66 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   10[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         6       0       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Interrupt_Isr
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=0
	line	66
global __ptext16
__ptext16:	;psect for function _Led_BlinkProcess
psect	text16
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	66
	global	__size_of_Led_BlinkProcess
	__size_of_Led_BlinkProcess	equ	__end_of_Led_BlinkProcess-_Led_BlinkProcess
	
_Led_BlinkProcess:	
;incstack = 0
	opt	stack 2
; Regs used in _Led_BlinkProcess: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	69
	
i1l4913:	
;led.c: 68: unsigned char i;
;led.c: 69: for(i = 0; i < 12; i++)
	clrf	(Led_BlinkProcess@i)
	line	72
	
i1l4919:	
;led.c: 70: {
;led.c: 72: if((((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->ledState == 3)
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u569_21
	goto	u569_20
u569_21:
	goto	i1l4923
u569_20:
	
i1l4921:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Led_BlinkProcess$527)
	goto	i1l4925
	
i1l4923:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Led_BlinkProcess$527)
	
i1l4925:	
	movf	(_Led_BlinkProcess$527),w
	addlw	02h
	movwf	fsr0
		movlw	3
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u570_21
	goto	u570_20
u570_21:
	goto	i1l4959
u570_20:
	line	74
	
i1l4927:	
;led.c: 73: {
;led.c: 74: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->blinkTimer++;
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u571_21
	goto	u571_20
u571_21:
	goto	i1l4931
u571_20:
	
i1l4929:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Led_BlinkProcess$538)
	goto	i1l4933
	
i1l4931:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Led_BlinkProcess$538)
	
i1l4933:	
	movf	(_Led_BlinkProcess$538),w
	addlw	07h
	movwf	fsr0
	movlw	01h
	bsf	status, 7	;select IRP bank2
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	76
	
i1l4935:	
;led.c: 76: if((((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->blinkTimer >= (100 / 2))
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u572_21
	goto	u572_20
u572_21:
	goto	i1l4939
u572_20:
	
i1l4937:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Led_BlinkProcess$549)
	goto	i1l4941
	
i1l4939:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Led_BlinkProcess$549)
	
i1l4941:	
	movf	(_Led_BlinkProcess$549),w
	addlw	07h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_BlinkProcess+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_BlinkProcess+0)+0+1
	movlw	0
	subwf	1+(??_Led_BlinkProcess+0)+0,w
	movlw	032h
	skipnz
	subwf	0+(??_Led_BlinkProcess+0)+0,w
	skipc
	goto	u573_21
	goto	u573_20
u573_21:
	goto	i1l4959
u573_20:
	line	78
	
i1l4943:	
;led.c: 77: {
;led.c: 78: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->blinkTimer = 0;
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u574_21
	goto	u574_20
u574_21:
	goto	i1l4947
u574_20:
	
i1l4945:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Led_BlinkProcess$560)
	goto	i1l4949
	
i1l4947:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Led_BlinkProcess$560)
	
i1l4949:	
	movf	(_Led_BlinkProcess$560),w
	addlw	07h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	79
	
i1l4951:	
;led.c: 79: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->blinkPhase ^= 1;
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u575_21
	goto	u575_20
u575_21:
	goto	i1l4955
u575_20:
	
i1l4953:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Led_BlinkProcess$571)
	goto	i1l4957
	
i1l4955:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Led_BlinkProcess$571)
	
i1l4957:	
	movf	(_Led_BlinkProcess$571),w
	addlw	09h
	movwf	fsr0
	movlw	low(01h)
	bsf	status, 7	;select IRP bank2
	xorwf	indf,f
	line	69
	
i1l4959:	
	incf	(Led_BlinkProcess@i),f
	
i1l4961:	
	movlw	low(0Ch)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u576_21
	goto	u576_20
u576_21:
	goto	i1l4919
u576_20:
	line	83
	
i1l721:	
	return
	opt stack 0
GLOBAL	__end_of_Led_BlinkProcess
	__end_of_Led_BlinkProcess:
	signat	_Led_BlinkProcess,89
	global	_Charging_Control

;; *************** function _Charging_Control *****************
;; Defined at:
;;		line 376 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    6[COMMON] unsigned char 
;;  i               1    7[COMMON] unsigned char 
;;  chargeB7_12     1    4[COMMON] unsigned char 
;;  chargeB1_6      1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 800/800
;;		On exit  : 100/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         5       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Interrupt_Isr
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	376
global __ptext17
__ptext17:	;psect for function _Charging_Control
psect	text17
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	376
	global	__size_of_Charging_Control
	__size_of_Charging_Control	equ	__end_of_Charging_Control-_Charging_Control
	
_Charging_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _Charging_Control: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	379
	
i1l4963:	
;charge_mgr.c: 378: unsigned char i;
;charge_mgr.c: 379: unsigned char chargeB1_6 = 0;
	clrf	(Charging_Control@chargeB1_6)
	line	380
;charge_mgr.c: 380: unsigned char chargeB7_12 = 0;
	clrf	(Charging_Control@chargeB7_12)
	line	383
	
i1l4965:	
;charge_mgr.c: 383: if(g_tempProtect)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	((_g_tempProtect)^080h),w
	btfsc	status,2
	goto	u577_21
	goto	u577_20
u577_21:
	goto	i1l4971
u577_20:
	line	385
;charge_mgr.c: 384: {
;charge_mgr.c: 385: do { RA0=1; RA1=1; RB3=1; RB2=1; RA3=1; RA2=1; RD1=1; RD3=1; RB0=1; RB1=1; RD2=1; RD0=1; } while(0);
	
i1l576:	
	bsf	(1072/8)^080h,(1072)&7	;volatile
	bsf	(1073/8)^080h,(1073)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	bsf	(50/8),(50)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	bsf	(1074/8)^080h,(1074)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	bsf	(49/8),(49)&7	;volatile
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	
i1l577:	
	line	386
;charge_mgr.c: 386: RC3 = 0;
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	387
;charge_mgr.c: 387: RC2 = 0;
	bcf	(2098/8)^0100h,(2098)&7	;volatile
	line	388
	
i1l4967:	
;charge_mgr.c: 388: g_pwmDuty = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	goto	i1l578
	line	393
	
i1l4971:	
;charge_mgr.c: 390: }
;charge_mgr.c: 393: for(i = 0; i < 12; i++)
	clrf	(Charging_Control@i)
	line	395
	
i1l4977:	
;charge_mgr.c: 394: {
;charge_mgr.c: 395: unsigned char s = (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->state;
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipc
	goto	u578_21
	goto	u578_20
u578_21:
	goto	i1l4981
u578_20:
	
i1l4979:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Charging_Control$459)
	goto	i1l4983
	
i1l4981:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Charging_Control$459)
	
i1l4983:	
	incf	(_Charging_Control$459),w
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Charging_Control@s)
	line	399
	
i1l4985:	
;charge_mgr.c: 399: if(i == 2)
		movlw	2
	xorwf	((Charging_Control@i)),w
	btfss	status,2
	goto	u579_21
	goto	u579_20
u579_21:
	goto	i1l4991
u579_20:
	goto	i1l4989
	line	401
	
i1l588:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l5011
	
i1l590:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l5011
	
i1l591:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	i1l5011
	
i1l592:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	i1l5011
	
i1l593:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l5011
	
i1l594:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l5011
	
i1l595:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l5011
	
i1l596:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l5011
	
i1l597:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	i1l5011
	
i1l598:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	i1l5011
	
i1l599:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l5011
	
i1l600:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l5011
	
i1l4989:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l588
	xorlw	1^0	; case 1
	skipnz
	goto	i1l590
	xorlw	2^1	; case 2
	skipnz
	goto	i1l591
	xorlw	3^2	; case 3
	skipnz
	goto	i1l592
	xorlw	4^3	; case 4
	skipnz
	goto	i1l593
	xorlw	5^4	; case 5
	skipnz
	goto	i1l594
	xorlw	6^5	; case 6
	skipnz
	goto	i1l595
	xorlw	7^6	; case 7
	skipnz
	goto	i1l596
	xorlw	8^7	; case 8
	skipnz
	goto	i1l597
	xorlw	9^8	; case 9
	skipnz
	goto	i1l598
	xorlw	10^9	; case 10
	skipnz
	goto	i1l599
	xorlw	11^10	; case 11
	skipnz
	goto	i1l600
	goto	i1l5011
	opt asmopt_pop

	line	408
	
i1l4991:	
;charge_mgr.c: 403: }
;charge_mgr.c: 407: if(s == 2 || s == 3 ||
;charge_mgr.c: 408: s == 4 || s == 5)
		movlw	2
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u580_21
	goto	u580_20
u580_21:
	goto	i1l5001
u580_20:
	
i1l4993:	
		movlw	3
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u581_21
	goto	u581_20
u581_21:
	goto	i1l5001
u581_20:
	
i1l4995:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u582_21
	goto	u582_20
u582_21:
	goto	i1l5001
u582_20:
	
i1l4997:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u583_21
	goto	u583_20
u583_21:
	goto	i1l5009
u583_20:
	goto	i1l5001
	line	410
	
i1l608:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l5003
	
i1l610:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l5003
	
i1l611:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l5003
	
i1l612:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l5003
	
i1l613:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l5003
	
i1l614:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l5003
	
i1l615:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l5003
	
i1l616:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l5003
	
i1l617:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l5003
	
i1l618:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l5003
	
i1l619:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l5003
	
i1l620:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l5003
	
i1l5001:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l608
	xorlw	1^0	; case 1
	skipnz
	goto	i1l610
	xorlw	2^1	; case 2
	skipnz
	goto	i1l611
	xorlw	3^2	; case 3
	skipnz
	goto	i1l612
	xorlw	4^3	; case 4
	skipnz
	goto	i1l613
	xorlw	5^4	; case 5
	skipnz
	goto	i1l614
	xorlw	6^5	; case 6
	skipnz
	goto	i1l615
	xorlw	7^6	; case 7
	skipnz
	goto	i1l616
	xorlw	8^7	; case 8
	skipnz
	goto	i1l617
	xorlw	9^8	; case 9
	skipnz
	goto	i1l618
	xorlw	10^9	; case 10
	skipnz
	goto	i1l619
	xorlw	11^10	; case 11
	skipnz
	goto	i1l620
	goto	i1l5003
	opt asmopt_pop

	line	413
	
i1l5003:	
;charge_mgr.c: 413: if(i < 6)
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipnc
	goto	u584_21
	goto	u584_20
u584_21:
	goto	i1l622
u584_20:
	line	414
	
i1l5005:	
;charge_mgr.c: 414: chargeB1_6 = 1;
	clrf	(Charging_Control@chargeB1_6)
	incf	(Charging_Control@chargeB1_6),f
	goto	i1l5011
	line	415
	
i1l622:	
	line	416
;charge_mgr.c: 415: else
;charge_mgr.c: 416: chargeB7_12 = 1;
	clrf	(Charging_Control@chargeB7_12)
	incf	(Charging_Control@chargeB7_12),f
	goto	i1l5011
	line	420
	
i1l5009:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l588
	xorlw	1^0	; case 1
	skipnz
	goto	i1l590
	xorlw	2^1	; case 2
	skipnz
	goto	i1l591
	xorlw	3^2	; case 3
	skipnz
	goto	i1l592
	xorlw	4^3	; case 4
	skipnz
	goto	i1l593
	xorlw	5^4	; case 5
	skipnz
	goto	i1l594
	xorlw	6^5	; case 6
	skipnz
	goto	i1l595
	xorlw	7^6	; case 7
	skipnz
	goto	i1l596
	xorlw	8^7	; case 8
	skipnz
	goto	i1l597
	xorlw	9^8	; case 9
	skipnz
	goto	i1l598
	xorlw	10^9	; case 10
	skipnz
	goto	i1l599
	xorlw	11^10	; case 11
	skipnz
	goto	i1l600
	goto	i1l5011
	opt asmopt_pop

	line	393
	
i1l5011:	
	incf	(Charging_Control@i),f
	
i1l5013:	
	movlw	low(0Ch)
	subwf	(Charging_Control@i),w
	skipc
	goto	u585_21
	goto	u585_20
u585_21:
	goto	i1l4977
u585_20:
	
i1l580:	
	line	425
;charge_mgr.c: 421: }
;charge_mgr.c: 422: }
;charge_mgr.c: 425: RC3 = chargeB1_6;
	btfsc	(Charging_Control@chargeB1_6),0
	goto	u586_21
	goto	u586_20
	
u586_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2099/8)^0100h,(2099)&7	;volatile
	goto	u587_24
u586_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
u587_24:
	line	426
;charge_mgr.c: 426: RC2 = chargeB7_12;
	btfsc	(Charging_Control@chargeB7_12),0
	goto	u588_21
	goto	u588_20
	
u588_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2098/8)^0100h,(2098)&7	;volatile
	goto	u589_24
u588_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2098/8)^0100h,(2098)&7	;volatile
u589_24:
	line	429
	
i1l578:	
	return
	opt stack 0
GLOBAL	__end_of_Charging_Control
	__end_of_Charging_Control:
	signat	_Charging_Control,89
	global	_ChargeProcess_Slot

;; *************** function _ChargeProcess_Slot *****************
;; Defined at:
;;		line 157 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    7[COMMON] unsigned char 
;;  v               2    8[COMMON] unsigned int 
;;  tick            2    0        unsigned int 
;;  p               1   10[COMMON] PTR struct .
;;		 -> g_slot1(72), g_slot0(72), 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         6       0       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		_Detect_BatteryType
;;		i1___bmul
;; This function is called by:
;;		_Interrupt_Isr
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=0
	line	157
global __ptext18
__ptext18:	;psect for function _ChargeProcess_Slot
psect	text18
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	157
	global	__size_of_ChargeProcess_Slot
	__size_of_ChargeProcess_Slot	equ	__end_of_ChargeProcess_Slot-_ChargeProcess_Slot
	
_ChargeProcess_Slot:	
;incstack = 0
	opt	stack 2
; Regs used in _ChargeProcess_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;ChargeProcess_Slot@idx stored from wreg
	movwf	(ChargeProcess_Slot@idx)
	line	159
	
i1l4731:	
;charge_mgr.c: 159: BatterySlot_t *p = (((idx) < 6) ? &g_slot0[(idx)] : &g_slot1[(idx)-6]);
	movlw	low(06h)
	subwf	(ChargeProcess_Slot@idx),w
	skipc
	goto	u538_21
	goto	u538_20
u538_21:
	goto	i1l4735
u538_20:
	
i1l4733:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(ChargeProcess_Slot@p)
	goto	i1l4737
	
i1l4735:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(ChargeProcess_Slot@p)
	line	163
	
i1l4737:	
;charge_mgr.c: 163: if(idx == 2)
		movlw	2
	xorwf	((ChargeProcess_Slot@idx)),w
	btfss	status,2
	goto	u539_21
	goto	u539_20
u539_21:
	goto	i1l4743
u539_20:
	line	165
	
i1l4739:	
;charge_mgr.c: 164: {
;charge_mgr.c: 165: p->state = 0;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	goto	i1l533
	line	170
	
i1l4743:	
;charge_mgr.c: 167: }
;charge_mgr.c: 170: unsigned int v = p->voltage;
	movf	(ChargeProcess_Slot@p),w
	addlw	03h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(ChargeProcess_Slot@v)
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v+1)
	line	171
	
i1l4745:	
	line	173
;charge_mgr.c: 173: switch(p->state)
	goto	i1l4891
	line	177
	
i1l4747:	
;charge_mgr.c: 177: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	178
;charge_mgr.c: 178: p->stableCnt = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	0Ah
	movwf	fsr0
	clrf	indf
	line	179
	
i1l4749:	
;charge_mgr.c: 179: p->state = 1;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	180
;charge_mgr.c: 180: break;
	goto	i1l533
	line	184
	
i1l4751:	
;charge_mgr.c: 184: p->chargeTimer += tick;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	185
	
i1l4753:	
;charge_mgr.c: 185: if(p->chargeTimer < (2 * 100))
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+1
	movlw	0
	subwf	1+(??_ChargeProcess_Slot+0)+0,w
	movlw	0C8h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)+0,w
	skipnc
	goto	u540_21
	goto	u540_20
u540_21:
	goto	i1l4757
u540_20:
	goto	i1l533
	line	189
	
i1l4757:	
;charge_mgr.c: 189: p->type = Detect_BatteryType(v);
	movf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movf	(ChargeProcess_Slot@v+1),w
	movwf	(Detect_BatteryType@voltage+1)
	movf	(ChargeProcess_Slot@v),w
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	movwf	indf
	line	194
	
i1l4759:	
;charge_mgr.c: 192: if(p->type == 4 ||
;charge_mgr.c: 193: p->type == 2 ||
;charge_mgr.c: 194: p->type == 0)
	movf	(ChargeProcess_Slot@p),w
	movwf	fsr0
		movlw	4
	xorwf	(indf),w
	btfsc	status,2
	goto	u541_21
	goto	u541_20
u541_21:
	goto	i1l4765
u541_20:
	
i1l4761:	
	movf	(ChargeProcess_Slot@p),w
	movwf	fsr0
		movlw	2
	xorwf	(indf),w
	btfsc	status,2
	goto	u542_21
	goto	u542_20
u542_21:
	goto	i1l4765
u542_20:
	
i1l4763:	
	movf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movf	(indf),w
	btfss	status,2
	goto	u543_21
	goto	u543_20
u543_21:
	goto	i1l4771
u543_20:
	line	196
	
i1l4765:	
;charge_mgr.c: 195: {
;charge_mgr.c: 196: p->state = 7;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	197
	
i1l4767:	
;charge_mgr.c: 197: if(idx == 0)
	movf	((ChargeProcess_Slot@idx)),w
	btfss	status,2
	goto	u544_21
	goto	u544_20
u544_21:
	goto	i1l533
u544_20:
	line	199
	
i1l4769:	
;charge_mgr.c: 198: {
;charge_mgr.c: 199: global_test = p->type;
	movf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_global_test)^080h
	clrf	(_global_test+1)^080h
	goto	i1l533
	line	205
	
i1l4771:	
;charge_mgr.c: 202: }
;charge_mgr.c: 205: if(v <= 228)
	movlw	0
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	0E5h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u545_21
	goto	u545_20
u545_21:
	goto	i1l4779
u545_20:
	line	207
	
i1l4773:	
;charge_mgr.c: 206: {
;charge_mgr.c: 207: p->state = 2;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(02h)
	movwf	indf
	line	208
	
i1l4775:	
;charge_mgr.c: 208: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	209
	
i1l4777:	
;charge_mgr.c: 209: p->activatePulseCnt = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	0Bh
	movwf	fsr0
	clrf	indf
	line	210
;charge_mgr.c: 210: }
	goto	i1l533
	line	212
	
i1l4779:	
;charge_mgr.c: 212: else if(v < 1138)
	movlw	04h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	072h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u546_21
	goto	u546_20
u546_21:
	goto	i1l4785
u546_20:
	line	214
	
i1l4781:	
;charge_mgr.c: 213: {
;charge_mgr.c: 214: p->state = 3;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	line	215
	
i1l4783:	
;charge_mgr.c: 215: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	216
;charge_mgr.c: 216: }
	goto	i1l533
	line	220
	
i1l4785:	
;charge_mgr.c: 218: else
;charge_mgr.c: 219: {
;charge_mgr.c: 220: p->state = 4;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(04h)
	movwf	indf
	line	221
	
i1l4787:	
;charge_mgr.c: 221: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	i1l533
	line	228
	
i1l4789:	
;charge_mgr.c: 228: p->chargeTimer += tick;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	230
	
i1l4791:	
;charge_mgr.c: 230: if(p->chargeTimer > (60 * 100))
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+1
	movlw	017h
	subwf	1+(??_ChargeProcess_Slot+0)+0,w
	movlw	071h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)+0,w
	skipc
	goto	u547_21
	goto	u547_20
u547_21:
	goto	i1l4799
u547_20:
	line	232
	
i1l4793:	
;charge_mgr.c: 231: {
;charge_mgr.c: 232: p->state = 7;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	233
	
i1l4795:	
;charge_mgr.c: 233: if(idx == 0)
	movf	((ChargeProcess_Slot@idx)),w
	btfss	status,2
	goto	u548_21
	goto	u548_20
u548_21:
	goto	i1l533
u548_20:
	line	235
	
i1l4797:	
;charge_mgr.c: 234: {
;charge_mgr.c: 235: global_test += 10;
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	addwf	(_global_test)^080h,f
	skipnc
	incf	(_global_test+1)^080h,f
	goto	i1l533
	line	240
	
i1l4799:	
;charge_mgr.c: 238: }
;charge_mgr.c: 240: if(v > 228)
	movlw	0
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	0E5h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u549_21
	goto	u549_20
u549_21:
	goto	i1l4805
u549_20:
	line	242
	
i1l4801:	
;charge_mgr.c: 241: {
;charge_mgr.c: 242: p->state = 3;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	line	243
	
i1l4803:	
;charge_mgr.c: 243: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	244
;charge_mgr.c: 244: break;
	goto	i1l533
	line	247
	
i1l4805:	
;charge_mgr.c: 245: }
;charge_mgr.c: 247: if(v >= 3641)
	movlw	0Eh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	039h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u550_21
	goto	u550_20
u550_21:
	goto	i1l533
u550_20:
	line	249
	
i1l4807:	
;charge_mgr.c: 248: {
;charge_mgr.c: 249: p->state = 7;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	250
	
i1l4809:	
;charge_mgr.c: 250: if(idx == 0)
	movf	((ChargeProcess_Slot@idx)),w
	btfss	status,2
	goto	u551_21
	goto	u551_20
u551_21:
	goto	i1l533
u551_20:
	line	252
	
i1l4811:	
;charge_mgr.c: 251: {
;charge_mgr.c: 252: global_test += 100;
	movlw	064h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	addwf	(_global_test)^080h,f
	skipnc
	incf	(_global_test+1)^080h,f
	goto	i1l533
	line	260
	
i1l4813:	
;charge_mgr.c: 260: p->chargeTimer += tick;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	262
	
i1l4815:	
;charge_mgr.c: 262: if(p->chargeTimer > (300 * 100))
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+1
	movlw	075h
	subwf	1+(??_ChargeProcess_Slot+0)+0,w
	movlw	031h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)+0,w
	skipc
	goto	u552_21
	goto	u552_20
u552_21:
	goto	i1l4819
u552_20:
	line	264
	
i1l4817:	
;charge_mgr.c: 263: {
;charge_mgr.c: 264: p->state = 7;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	265
;charge_mgr.c: 265: break;
	goto	i1l533
	line	268
	
i1l4819:	
;charge_mgr.c: 266: }
;charge_mgr.c: 268: if(v >= 3641)
	movlw	0Eh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	039h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u553_21
	goto	u553_20
u553_21:
	goto	i1l4827
u553_20:
	line	270
	
i1l4821:	
;charge_mgr.c: 269: {
;charge_mgr.c: 270: p->state = 7;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	271
	
i1l4823:	
;charge_mgr.c: 271: if(idx == 0)
	movf	((ChargeProcess_Slot@idx)),w
	btfss	status,2
	goto	u554_21
	goto	u554_20
u554_21:
	goto	i1l533
u554_20:
	line	273
	
i1l4825:	
;charge_mgr.c: 272: {
;charge_mgr.c: 273: global_test += 1000;
	movlw	0E8h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	addwf	(_global_test)^080h,f
	skipnc
	incf	(_global_test+1)^080h,f
	movlw	03h
	addwf	(_global_test+1)^080h,f
	goto	i1l533
	line	278
	
i1l4827:	
;charge_mgr.c: 276: }
;charge_mgr.c: 278: if(v >= 2276)
	movlw	08h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	0E4h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u555_21
	goto	u555_20
u555_21:
	goto	i1l533
u555_20:
	line	280
	
i1l4829:	
;charge_mgr.c: 279: {
;charge_mgr.c: 280: p->state = 4;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(04h)
	movwf	indf
	line	281
	
i1l4831:	
;charge_mgr.c: 281: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	i1l533
	line	287
	
i1l4833:	
;charge_mgr.c: 287: p->chargeTimer += tick;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	289
	
i1l4835:	
;charge_mgr.c: 289: if(p->chargeTimer > (10800 * 100))
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+1
	movlw	07Ah
	subwf	1+(??_ChargeProcess_Slot+0)+0,w
	movlw	0C1h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)+0,w
	skipc
	goto	u556_21
	goto	u556_20
u556_21:
	goto	i1l4843
u556_20:
	line	291
	
i1l4837:	
;charge_mgr.c: 290: {
;charge_mgr.c: 291: p->state = 7;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	292
	
i1l4839:	
;charge_mgr.c: 292: if(idx == 0)
	movf	((ChargeProcess_Slot@idx)),w
	btfss	status,2
	goto	u557_21
	goto	u557_20
u557_21:
	goto	i1l533
u557_20:
	line	294
	
i1l4841:	
;charge_mgr.c: 293: {
;charge_mgr.c: 294: global_test += 10000;
	movlw	010h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	addwf	(_global_test)^080h,f
	skipnc
	incf	(_global_test+1)^080h,f
	movlw	027h
	addwf	(_global_test+1)^080h,f
	goto	i1l533
	line	299
	
i1l4843:	
;charge_mgr.c: 297: }
;charge_mgr.c: 299: if(v >= 3641)
	movlw	0Eh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	039h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u558_21
	goto	u558_20
u558_21:
	goto	i1l4851
u558_20:
	line	301
	
i1l4845:	
;charge_mgr.c: 300: {
;charge_mgr.c: 301: p->state = 7;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	302
	
i1l4847:	
;charge_mgr.c: 302: if(idx == 0)
	movf	((ChargeProcess_Slot@idx)),w
	btfss	status,2
	goto	u559_21
	goto	u559_20
u559_21:
	goto	i1l533
u559_20:
	line	304
	
i1l4849:	
;charge_mgr.c: 303: {
;charge_mgr.c: 304: global_test += 100000;
	movlw	0A0h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	addwf	(_global_test)^080h,f
	skipnc
	incf	(_global_test+1)^080h,f
	movlw	086h
	addwf	(_global_test+1)^080h,f
	goto	i1l533
	line	309
	
i1l4851:	
;charge_mgr.c: 307: }
;charge_mgr.c: 309: if(v >= 3459)
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	083h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u560_21
	goto	u560_20
u560_21:
	goto	i1l533
u560_20:
	line	311
	
i1l4853:	
;charge_mgr.c: 310: {
;charge_mgr.c: 311: p->state = 5;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(05h)
	movwf	indf
	line	312
	
i1l4855:	
;charge_mgr.c: 312: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	i1l533
	line	318
	
i1l4857:	
;charge_mgr.c: 318: p->chargeTimer += tick;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	320
	
i1l4859:	
;charge_mgr.c: 320: if(v >= 3641)
	movlw	0Eh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	039h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u561_21
	goto	u561_20
u561_21:
	goto	i1l4867
u561_20:
	line	322
	
i1l4861:	
;charge_mgr.c: 321: {
;charge_mgr.c: 322: p->state = 7;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	324
	
i1l4863:	
;charge_mgr.c: 324: if(idx == 0)
	movf	((ChargeProcess_Slot@idx)),w
	btfss	status,2
	goto	u562_21
	goto	u562_20
u562_21:
	goto	i1l533
u562_20:
	line	326
	
i1l4865:	
;charge_mgr.c: 325: {
;charge_mgr.c: 326: global_test += 1000000;
	movlw	040h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	addwf	(_global_test)^080h,f
	skipnc
	incf	(_global_test+1)^080h,f
	movlw	042h
	addwf	(_global_test+1)^080h,f
	goto	i1l533
	line	331
	
i1l4867:	
;charge_mgr.c: 329: }
;charge_mgr.c: 331: if(p->chargeTimer > (600 * 100))
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+1
	movlw	0EAh
	subwf	1+(??_ChargeProcess_Slot+0)+0,w
	movlw	061h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)+0,w
	skipc
	goto	u563_21
	goto	u563_20
u563_21:
	goto	i1l533
u563_20:
	line	333
	
i1l4869:	
;charge_mgr.c: 332: {
;charge_mgr.c: 333: p->state = 6;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(06h)
	movwf	indf
	goto	i1l533
	line	340
	
i1l4871:	
;charge_mgr.c: 340: if(v < (3459 - 10))
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	079h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u564_21
	goto	u564_20
u564_21:
	goto	i1l533
u564_20:
	line	342
	
i1l4873:	
;charge_mgr.c: 341: {
;charge_mgr.c: 342: p->state = 4;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(04h)
	movwf	indf
	line	343
	
i1l4875:	
;charge_mgr.c: 343: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	i1l533
	line	351
	
i1l4877:	
;charge_mgr.c: 350: if(v > 228 && v < 3641 &&
;charge_mgr.c: 351: p->type == 1)
	movlw	0
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	0E5h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u565_21
	goto	u565_20
u565_21:
	goto	i1l533
u565_20:
	
i1l4879:	
	movlw	0Eh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	039h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u566_21
	goto	u566_20
u566_21:
	goto	i1l533
u566_20:
	
i1l4881:	
	movf	(ChargeProcess_Slot@p),w
	movwf	fsr0
		decf	(indf),w
	btfss	status,2
	goto	u567_21
	goto	u567_20
u567_21:
	goto	i1l533
u567_20:
	line	353
	
i1l4883:	
;charge_mgr.c: 352: {
;charge_mgr.c: 353: p->state = 1;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	354
	
i1l4885:	
;charge_mgr.c: 354: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	i1l533
	line	359
	
i1l4887:	
;charge_mgr.c: 359: p->state = 0;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	clrf	indf
	line	360
;charge_mgr.c: 360: break;
	goto	i1l533
	line	173
	
i1l4891:	
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 8, Range of values is 0 to 7
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           25    13 (average)
; direct_byte           32     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l4747
	xorlw	1^0	; case 1
	skipnz
	goto	i1l4751
	xorlw	2^1	; case 2
	skipnz
	goto	i1l4789
	xorlw	3^2	; case 3
	skipnz
	goto	i1l4813
	xorlw	4^3	; case 4
	skipnz
	goto	i1l4833
	xorlw	5^4	; case 5
	skipnz
	goto	i1l4857
	xorlw	6^5	; case 6
	skipnz
	goto	i1l4871
	xorlw	7^6	; case 7
	skipnz
	goto	i1l4877
	goto	i1l4887
	opt asmopt_pop

	line	362
	
i1l533:	
	return
	opt stack 0
GLOBAL	__end_of_ChargeProcess_Slot
	__end_of_ChargeProcess_Slot:
	signat	_ChargeProcess_Slot,4217
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 96 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2    0[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 800/800
;;		On exit  : 800/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         2       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=0
	line	96
global __ptext19
__ptext19:	;psect for function _Detect_BatteryType
psect	text19
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	96
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 2
; Regs used in _Detect_BatteryType: [wreg]
	line	99
	
i1l2469:	
;charge_mgr.c: 99: if(voltage <= 91)
	movlw	0
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	05Ch
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u194_21
	goto	u194_20
u194_21:
	goto	i1l2475
u194_20:
	line	100
	
i1l2471:	
;charge_mgr.c: 100: return 4;
	movlw	low(04h)
	goto	i1l514
	line	103
	
i1l2475:	
;charge_mgr.c: 103: if(voltage <= 228)
	movlw	0
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0E5h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u195_21
	goto	u195_20
u195_21:
	goto	i1l2481
u195_20:
	line	104
	
i1l2477:	
;charge_mgr.c: 104: return 1;
	movlw	low(01h)
	goto	i1l514
	line	107
	
i1l2481:	
;charge_mgr.c: 107: if(voltage >= 2503 && voltage <= 2958)
	movlw	09h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0C7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u196_21
	goto	u196_20
u196_21:
	goto	i1l2489
u196_20:
	
i1l2483:	
	movlw	0Bh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	08Fh
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u197_21
	goto	u197_20
u197_21:
	goto	i1l2489
u197_20:
	line	108
	
i1l2485:	
;charge_mgr.c: 108: return 2;
	movlw	low(02h)
	goto	i1l514
	line	111
	
i1l2489:	
;charge_mgr.c: 111: if(voltage >= 1138 && voltage <= 3459)
	movlw	04h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	072h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u198_21
	goto	u198_20
u198_21:
	goto	i1l2497
u198_20:
	
i1l2491:	
	movlw	0Dh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	084h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u199_21
	goto	u199_20
u199_21:
	goto	i1l2497
u199_20:
	goto	i1l2477
	line	115
	
i1l2497:	
;charge_mgr.c: 115: if(voltage > 3459 && voltage < 3641)
	movlw	0Dh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	084h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u200_21
	goto	u200_20
u200_21:
	goto	i1l2505
u200_20:
	
i1l2499:	
	movlw	0Eh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	039h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u201_21
	goto	u201_20
u201_21:
	goto	i1l2505
u201_20:
	goto	i1l2477
	line	120
	
i1l2505:	
;charge_mgr.c: 120: if(voltage >= 3641 && voltage < 4095)
	movlw	0Eh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	039h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u202_21
	goto	u202_20
u202_21:
	goto	i1l2513
u202_20:
	
i1l2507:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0FFh
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u203_21
	goto	u203_20
u203_21:
	goto	i1l2513
u203_20:
	goto	i1l2477
	line	124
	
i1l2513:	
;charge_mgr.c: 124: return 0;
	movlw	low(0)
	line	125
	
i1l514:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 447 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1   13[BANK0 ] unsigned char 
;;  duty            2   11[BANK0 ] int 
;;  error           2    9[BANK0 ] int 
;;  adjust          2    0[BANK0 ] int 
;;  maxV            2    7[BANK0 ] unsigned int 
;;  i               1   14[BANK0 ] unsigned char 
;;  cvCount         1    3[BANK0 ] unsigned char 
;;  hasCharging     1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 100/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      15       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2      15       0       0       0
;;Total ram usage:       17 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___awdiv
;;		i1___bmul
;; This function is called by:
;;		_Interrupt_Isr
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	line	447
global __ptext20
__ptext20:	;psect for function _CCCV_Control
psect	text20
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	447
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	450
	
i1l5015:	
;charge_mgr.c: 449: unsigned char i;
;charge_mgr.c: 450: unsigned char hasCharging = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	451
;charge_mgr.c: 451: unsigned int maxV = 0;
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	452
;charge_mgr.c: 452: unsigned char cvCount = 0;
	clrf	(CCCV_Control@cvCount)
	line	455
;charge_mgr.c: 455: for(i = 0; i < 12; i++)
	clrf	(CCCV_Control@i)
	line	457
	
i1l5021:	
;charge_mgr.c: 456: {
;charge_mgr.c: 457: unsigned char s = (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->state;
	movlw	low(06h)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u590_21
	goto	u590_20
u590_21:
	goto	i1l5025
u590_20:
	
i1l5023:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$476)
	goto	i1l5027
	
i1l5025:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$476)
	
i1l5027:	
	incf	(_CCCV_Control$476),w
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(CCCV_Control@s)
	line	461
	
i1l5029:	
;charge_mgr.c: 461: if(i == 2) continue;
		movlw	2
	xorwf	((CCCV_Control@i)),w
	btfss	status,2
	goto	u591_21
	goto	u591_20
u591_21:
	goto	i1l5033
u591_20:
	goto	i1l650
	line	465
	
i1l5033:	
;charge_mgr.c: 464: if(s == 2 || s == 3 ||
;charge_mgr.c: 465: s == 4 || s == 5)
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u592_21
	goto	u592_20
u592_21:
	goto	i1l653
u592_20:
	
i1l5035:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u593_21
	goto	u593_20
u593_21:
	goto	i1l653
u593_20:
	
i1l5037:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u594_21
	goto	u594_20
u594_21:
	goto	i1l653
u594_20:
	
i1l5039:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u595_21
	goto	u595_20
u595_21:
	goto	i1l650
u595_20:
	
i1l653:	
	line	467
;charge_mgr.c: 466: {
;charge_mgr.c: 467: hasCharging = 1;
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	468
	
i1l5041:	
;charge_mgr.c: 468: if((((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->voltage > maxV)
	movlw	low(06h)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u596_21
	goto	u596_20
u596_21:
	goto	i1l5045
u596_20:
	
i1l5043:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$487)
	goto	i1l5047
	
i1l5045:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$487)
	
i1l5047:	
	movf	(_CCCV_Control$487),w
	addlw	03h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_CCCV_Control+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_CCCV_Control+0)+0+1
	movf	1+(??_CCCV_Control+0)+0,w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u597_25
	movf	0+(??_CCCV_Control+0)+0,w
	subwf	(CCCV_Control@maxV),w
u597_25:
	skipnc
	goto	u597_21
	goto	u597_20
u597_21:
	goto	i1l5057
u597_20:
	line	469
	
i1l5049:	
;charge_mgr.c: 469: maxV = (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->voltage;
	movlw	low(06h)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u598_21
	goto	u598_20
u598_21:
	goto	i1l5053
u598_20:
	
i1l5051:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$498)
	goto	i1l5055
	
i1l5053:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$498)
	
i1l5055:	
	movf	(_CCCV_Control$498),w
	addlw	03h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(CCCV_Control@maxV)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@maxV+1)
	line	470
	
i1l5057:	
;charge_mgr.c: 470: if(s == 5)
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u599_21
	goto	u599_20
u599_21:
	goto	i1l650
u599_20:
	line	471
	
i1l5059:	
;charge_mgr.c: 471: cvCount++;
	incf	(CCCV_Control@cvCount),f
	line	455
	
i1l650:	
	incf	(CCCV_Control@i),f
	
i1l5061:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u600_21
	goto	u600_20
u600_21:
	goto	i1l5021
u600_20:
	line	476
	
i1l5063:	
;charge_mgr.c: 472: }
;charge_mgr.c: 473: }
;charge_mgr.c: 476: if(!hasCharging)
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u601_21
	goto	u601_20
u601_21:
	goto	i1l5069
u601_20:
	line	478
	
i1l5065:	
;charge_mgr.c: 477: {
;charge_mgr.c: 478: g_pwmDuty = 0;
	clrf	(_g_pwmDuty)	;volatile
	line	479
;charge_mgr.c: 479: g_cvIntegral = 0;
	clrf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l665
	line	486
	
i1l5069:	
;charge_mgr.c: 481: }
;charge_mgr.c: 486: if(cvCount == 0)
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u602_21
	goto	u602_20
u602_21:
	goto	i1l5087
u602_20:
	line	488
	
i1l5071:	
;charge_mgr.c: 487: {
;charge_mgr.c: 488: if(g_pwmDuty < 25)
	movlw	low(019h)
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u603_21
	goto	u603_20
u603_21:
	goto	i1l5079
u603_20:
	line	491
	
i1l5073:	
;charge_mgr.c: 489: {
;charge_mgr.c: 491: g_pwmDuty += 3;
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	492
	
i1l5075:	
;charge_mgr.c: 492: if(g_pwmDuty > 25)
	movlw	low(01Ah)
	subwf	(_g_pwmDuty),w	;volatile
	skipc
	goto	u604_21
	goto	u604_20
u604_21:
	goto	i1l665
u604_20:
	line	493
	
i1l5077:	
;charge_mgr.c: 493: g_pwmDuty = 25;
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l665
	line	495
	
i1l5079:	
	goto	i1l5077
	line	514
	
i1l5087:	
;charge_mgr.c: 506: }
;charge_mgr.c: 513: {
;charge_mgr.c: 514: int error = (int)(3459) - (int)(maxV);
	movlw	083h
	movwf	(CCCV_Control@error)
	movlw	0Dh
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	517
;charge_mgr.c: 517: g_cvIntegral += error * 1;
	movf	(CCCV_Control@error),w
	addwf	(_g_cvIntegral),f
	skipnc
	incf	(_g_cvIntegral+1),f
	movf	(CCCV_Control@error+1),w
	addwf	(_g_cvIntegral+1),f
	line	518
	
i1l5089:	
;charge_mgr.c: 518: if(g_cvIntegral > 200)
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u605_25
	movlw	0C9h
	subwf	(_g_cvIntegral),w
u605_25:

	skipc
	goto	u605_21
	goto	u605_20
u605_21:
	goto	i1l5093
u605_20:
	line	519
	
i1l5091:	
;charge_mgr.c: 519: g_cvIntegral = 200;
	movlw	0C8h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l5097
	line	520
	
i1l5093:	
;charge_mgr.c: 520: else if(g_cvIntegral < -200)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u606_25
	movlw	038h
	subwf	(_g_cvIntegral),w
u606_25:

	skipnc
	goto	u606_21
	goto	u606_20
u606_21:
	goto	i1l5097
u606_20:
	line	521
	
i1l5095:	
;charge_mgr.c: 521: g_cvIntegral = -200;
	movlw	038h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	movlw	0FFh
	movwf	((_g_cvIntegral))+1
	line	524
	
i1l5097:	
;charge_mgr.c: 524: int adjust = (error * 4 + g_cvIntegral) / 8;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	movf	(_g_cvIntegral),w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1),w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	525
	
i1l5099:	
;charge_mgr.c: 525: int duty = (int)g_pwmDuty + adjust;
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
i1l5101:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	528
	
i1l5103:	
;charge_mgr.c: 528: if(duty > 32) duty = 32;
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u607_25
	movlw	021h
	subwf	(CCCV_Control@duty),w
u607_25:

	skipc
	goto	u607_21
	goto	u607_20
u607_21:
	goto	i1l5107
u607_20:
	
i1l5105:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	529
	
i1l5107:	
;charge_mgr.c: 529: if(duty < 0) duty = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u608_21
	goto	u608_20
u608_21:
	goto	i1l5111
u608_20:
	
i1l5109:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	531
	
i1l5111:	
;charge_mgr.c: 531: g_pwmDuty = (unsigned char)duty;
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	533
	
i1l665:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	i1___bmul

;; *************** function i1___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[COMMON] unsigned char 
;;  __bmul          1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Interrupt_Isr
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;;		_Led_BlinkProcess
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext21
__ptext21:	;psect for function i1___bmul
psect	text21
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_ofi1___bmul
	__size_ofi1___bmul	equ	__end_ofi1___bmul-i1___bmul
	
i1___bmul:	
;incstack = 0
	opt	stack 3
; Regs used in i1___bmul: [wreg+status,2+status,0]
;i1___bmul@multiplier stored from wreg
	movwf	(i1___bmul@multiplier)
	line	6
	
i1l2603:	
	clrf	(i1___bmul@product)
	line	43
	
i1l2605:	
	btfss	(i1___bmul@multiplier),(0)&7
	goto	u216_21
	goto	u216_20
u216_21:
	goto	i1l2609
u216_20:
	line	44
	
i1l2607:	
	movf	(i1___bmul@multiplicand),w
	addwf	(i1___bmul@product),f
	line	45
	
i1l2609:	
	clrc
	rlf	(i1___bmul@multiplicand),f
	line	46
	
i1l2611:	
	clrc
	rrf	(i1___bmul@multiplier),f
	line	47
	movf	((i1___bmul@multiplier)),w
	btfss	status,2
	goto	u217_21
	goto	u217_20
u217_21:
	goto	i1l2605
u217_20:
	line	50
	
i1l2613:	
	movf	(i1___bmul@product),w
	line	51
	
i1l815:	
	return
	opt stack 0
GLOBAL	__end_ofi1___bmul
	__end_ofi1___bmul:
	signat	i1___bmul,89
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] int 
;;  dividend        2    2[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] int 
;;  sign            1    5[COMMON] unsigned char 
;;  counter         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext22
__ptext22:	;psect for function ___awdiv
psect	text22
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
i1l2559:	
	clrf	(___awdiv@sign)
	line	15
	
i1l2561:	
	btfss	(___awdiv@divisor+1),7
	goto	u209_21
	goto	u209_20
u209_21:
	goto	i1l2567
u209_20:
	line	16
	
i1l2563:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
i1l2565:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
i1l2567:	
	btfss	(___awdiv@dividend+1),7
	goto	u210_21
	goto	u210_20
u210_21:
	goto	i1l2573
u210_20:
	line	20
	
i1l2569:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
i1l2571:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
i1l2573:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
i1l2575:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u211_21
	goto	u211_20
u211_21:
	goto	i1l2595
u211_20:
	line	25
	
i1l2577:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	i1l2581
	line	27
	
i1l2579:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
i1l2581:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u212_21
	goto	u212_20
u212_21:
	goto	i1l2579
u212_20:
	line	31
	
i1l2583:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
i1l2585:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u213_25
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u213_25:
	skipc
	goto	u213_21
	goto	u213_20
u213_21:
	goto	i1l2591
u213_20:
	line	33
	
i1l2587:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
i1l2589:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
i1l2591:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
i1l2593:	
	decfsz	(___awdiv@counter),f
	goto	u214_21
	goto	u214_20
u214_21:
	goto	i1l2583
u214_20:
	line	39
	
i1l2595:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u215_21
	goto	u215_20
u215_21:
	goto	i1l2599
u215_20:
	line	40
	
i1l2597:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
i1l2599:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
i1l927:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
	global	_ADC_ReadChannel

;; *************** function _ADC_ReadChannel *****************
;; Defined at:
;;		line 131 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  ch              1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  ch              1    8[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    5[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         2       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          1       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		_ADC_Sample
;; This function is called by:
;;		_Interrupt_Isr
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	131
global __ptext23
__ptext23:	;psect for function _ADC_ReadChannel
psect	text23
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	131
	global	__size_of_ADC_ReadChannel
	__size_of_ADC_ReadChannel	equ	__end_of_ADC_ReadChannel-_ADC_ReadChannel
	
_ADC_ReadChannel:	
;incstack = 0
	opt	stack 2
; Regs used in _ADC_ReadChannel: [wreg+status,2+status,0+pclath+cstack]
;ADC_ReadChannel@ch stored from wreg
	movwf	(ADC_ReadChannel@ch)
	line	133
	
i1l2871:	
;adc_drv.c: 133: test_adc = ADC_Sample(ch, 7);
	movlw	low(07h)
	movwf	(ADC_Sample@adldo)
	movf	(ADC_ReadChannel@ch),w
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	134
	
i1l2873:	
;adc_drv.c: 134: if (0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u245_21
	goto	u245_20
u245_21:
	goto	i1l2879
u245_20:
	line	135
	
i1l2875:	
;adc_drv.c: 135: return adresult;
	movf	(_adresult+1),w	;volatile
	movwf	(?_ADC_ReadChannel+1)
	movf	(_adresult),w	;volatile
	movwf	(?_ADC_ReadChannel)
	goto	i1l501
	line	138
	
i1l2879:	
;adc_drv.c: 138: ADCON0 = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(149)^080h	;volatile
	line	139
;adc_drv.c: 139: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	140
	
i1l2881:	
;adc_drv.c: 140: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??_ADC_ReadChannel+0)+0),f
	u649_27:
decfsz	(??_ADC_ReadChannel+0)+0,f
	goto	u649_27
opt asmopt_pop

	line	141
	
i1l2883:	
;adc_drv.c: 141: return 0;
	clrf	(?_ADC_ReadChannel)
	clrf	(?_ADC_ReadChannel+1)
	line	142
	
i1l501:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_ReadChannel
	__end_of_ADC_ReadChannel:
	signat	_ADC_ReadChannel,4218
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 43 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    1[BANK0 ] unsigned char 
;;  j               1    0[BANK0 ] unsigned char 
;;  adsum           4    3[BANK0 ] volatile unsigned long 
;;  ad_temp         2   11[BANK0 ] volatile unsigned int 
;;  admax           2    9[BANK0 ] volatile unsigned int 
;;  admin           2    7[BANK0 ] volatile unsigned int 
;;  i               1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      13       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Interrupt_Isr
;;		_ADC_ReadChannel
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	line	43
global __ptext24
__ptext24:	;psect for function _ADC_Sample
psect	text24
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	43
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@adch)
	line	45
	
i1l2399:	
;adc_drv.c: 45: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	46
	
i1l2401:	
;adc_drv.c: 46: volatile unsigned int admin = 0;
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	47
;adc_drv.c: 47: volatile unsigned int admax = 0;
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	48
;adc_drv.c: 48: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	51
	
i1l2403:	
;adc_drv.c: 51: if ((!LDO_EN) && (adldo & 0x04))
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u179_21
	goto	u179_20
u179_21:
	goto	i1l2409
u179_20:
	
i1l2405:	
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u180_21
	goto	u180_20
u180_21:
	goto	i1l2409
u180_20:
	line	53
	
i1l2407:	
;adc_drv.c: 52: {
;adc_drv.c: 53: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	54
;adc_drv.c: 54: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??_ADC_Sample+0)+0),f
	u650_27:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u650_27
opt asmopt_pop

	line	55
;adc_drv.c: 55: }
	goto	i1l2411
	line	57
	
i1l2409:	
;adc_drv.c: 56: else
;adc_drv.c: 57: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	60
	
i1l2411:	
;adc_drv.c: 60: if(adch & 0x10)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(ADC_Sample@adch),(4)&7
	goto	u181_21
	goto	u181_20
u181_21:
	goto	i1l482
u181_20:
	line	62
	
i1l2413:	
;adc_drv.c: 61: {
;adc_drv.c: 62: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	63
	
i1l2415:	
;adc_drv.c: 63: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(ADC_Sample@adch),f
	line	64
;adc_drv.c: 64: }
	goto	i1l2417
	line	65
	
i1l482:	
	line	66
;adc_drv.c: 65: else
;adc_drv.c: 66: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	68
	
i1l2417:	
;adc_drv.c: 68: unsigned char i = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@i)
	line	70
;adc_drv.c: 70: for (i = 0; i < 10; i++)
	clrf	(ADC_Sample@i)
	line	73
	
i1l2423:	
;adc_drv.c: 71: {
;adc_drv.c: 73: ADCON0 = (unsigned char)(0X41 | (adch << 2));
	movf	(ADC_Sample@adch),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u182_25:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u182_25
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	041h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	74
# 74 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
nop ;# 
	line	75
# 75 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
nop ;# 
	line	76
# 76 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
nop ;# 
	line	77
# 77 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
nop ;# 
psect	text24
	line	78
	
i1l2425:	
;adc_drv.c: 78: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	81
	
i1l2427:	
;adc_drv.c: 81: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	82
;adc_drv.c: 82: while (GODONE)
	goto	i1l486
	
i1l487:	
	line	84
;adc_drv.c: 83: {
;adc_drv.c: 84: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	85
;adc_drv.c: 85: if (0 == (--j))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u183_21
	goto	u183_20
u183_21:
	goto	i1l486
u183_20:
	line	86
	
i1l2429:	
;adc_drv.c: 86: return 0;
	movlw	low(0)
	goto	i1l489
	line	87
	
i1l486:	
	line	82
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u184_21
	goto	u184_20
u184_21:
	goto	i1l487
u184_20:
	line	90
	
i1l2433:	
;adc_drv.c: 87: }
;adc_drv.c: 90: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
i1l2435:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	93
	
i1l2437:	
;adc_drv.c: 93: if (0 == admax)
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u185_21
	goto	u185_20
u185_21:
	goto	i1l2441
u185_20:
	line	95
	
i1l2439:	
;adc_drv.c: 94: {
;adc_drv.c: 95: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	96
;adc_drv.c: 96: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	97
;adc_drv.c: 97: }
	goto	i1l492
	line	99
	
i1l2441:	
;adc_drv.c: 99: else if (ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u186_25
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u186_25:
	skipnc
	goto	u186_21
	goto	u186_20
u186_21:
	goto	i1l2445
u186_20:
	line	100
	
i1l2443:	
;adc_drv.c: 100: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	i1l492
	line	102
	
i1l2445:	
;adc_drv.c: 102: else if (ad_temp < admin)
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u187_25
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u187_25:
	skipnc
	goto	u187_21
	goto	u187_20
u187_21:
	goto	i1l492
u187_20:
	line	103
	
i1l2447:	
;adc_drv.c: 103: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	105
	
i1l492:	
;adc_drv.c: 105: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u188_21
	addwf	(ADC_Sample@adsum+1),f	;volatile
u188_21:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u188_22
	addwf	(ADC_Sample@adsum+2),f	;volatile
u188_22:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u188_23
	addwf	(ADC_Sample@adsum+3),f	;volatile
u188_23:

	line	70
	
i1l2449:	
	incf	(ADC_Sample@i),f
	
i1l2451:	
	movlw	low(0Ah)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u189_21
	goto	u189_20
u189_21:
	goto	i1l2423
u189_20:
	line	109
	
i1l2453:	
;adc_drv.c: 106: }
;adc_drv.c: 109: adsum -= admax;
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u190_25
	goto	u190_26
u190_25:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u190_26:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u190_27
	goto	u190_28
u190_27:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u190_28:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u190_29
	goto	u190_20
u190_29:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u190_20:

	line	110
;adc_drv.c: 110: if (adsum >= admin)
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u191_25
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u191_25
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u191_25
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u191_25:
	skipc
	goto	u191_21
	goto	u191_20
u191_21:
	goto	i1l496
u191_20:
	line	111
	
i1l2455:	
;adc_drv.c: 111: adsum -= admin;
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u192_25
	goto	u192_26
u192_25:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u192_26:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u192_27
	goto	u192_28
u192_27:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u192_28:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u192_29
	goto	u192_20
u192_29:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u192_20:

	goto	i1l2457
	line	112
	
i1l496:	
	line	113
;adc_drv.c: 112: else
;adc_drv.c: 113: adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	115
	
i1l2457:	
;adc_drv.c: 115: adresult = adsum >> 3;
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	03h
u193_25:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u193_20:
	addlw	-1
	skipz
	goto	u193_25
	movf	1+(??_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	118
	
i1l2459:	
;adc_drv.c: 118: adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	119
	
i1l2461:	
;adc_drv.c: 119: admin = 0;
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	120
	
i1l2463:	
;adc_drv.c: 120: admax = 0;
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	121
	
i1l2465:	
;adc_drv.c: 121: return 0xA5;
	movlw	low(0A5h)
	line	122
	
i1l489:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
