/*-------------------------------------------
  L1211 12槽充电器 - 灯光模块 (V58X / 方案A)
  基线: V58W(判型/充电逻辑一行未改)
  改动范围: 本文件 + config.h(声明) + main.c(1行调用)
            charge_mgr.c / adc_drv.c / uart_dbg.c 未改(MD5与V58W一致)

  ┌─ 硬件事实(决定一切, 见 V58W led.c 注释与原理图 LED 区)─────────────┐
  │ ① 全板只有 2 条颜色公共轨, 12 槽共用 ⇒ 任一时刻"全板同色":        │
  │      RC5 = 网标"LED_IO1" → Q11 ⇒ 物理【绿灯】轨  (低有效: 0=亮)   │
  │      RC4 = 网标"LED_IO2" → Q8  ⇒ 物理【红灯】轨  (低有效: 0=亮)   │
  │      ⚠ 网标"IO1/IO2"不是颜色名(这是历次红绿搞反的根源!) ⇒ 代码里  │
  │        一律用 PIN_LED_RED / PIN_LED_GREEN(见 config.h), 不要直接用 │
  │        PIN_LED_IO1 / PIN_LED_IO2 表达颜色. 依现场两次实测(V60A 与  │
  │        V58X): 驱动 IO1(RC5) 报错槽显示绿色; 驱动 IO2(RC4) 显示红.  │
  │    ⇒ "逐槽各显示各的颜色"本硬件做不到(要额外控制每颗灯亮灭就得给    │
  │      采样脚灌电流 ⇒ 会破坏 DETECT/IMP 判型, V60G 已实测三槽全ERROR) │
  │ ② "某槽亮不亮"由该槽自身通路决定, 软件改不了:                     │
  │      · 该槽 MOSFET 导通(正在检测/充电脉冲) ⇒ 节点被抬到 VCC ⇒ 灭  │
  │      · 该槽 MOSFET 关(空闲/报错/充满)      ⇒ 亮                   │
  │      · 无电池 ⇒ 基本灭                                            │
  │ ③ RC4(绿灯脚)与软件UART TX复用(见 config.h) ⇒ UART_PRINT_EN=1 时   │
  │    绿灯输出必须放弃, 否则串口数据会把绿灯轨当 TX 翻转(现场"灯乱闪") │
  └───────────────────────────────────────────────────────────────────┘

  显示规则(整板同色, 优先级从高到低) —— 与需求表"状态显示"一致, 且"测量优先":
    0. 有电池正在检测/阻抗测量(DETECT/IMP_*) → 绿灯轨导通(小电流, 不扰动判型) ★V58Z1
    1. 任一槽 ERROR(含 Dry/NiMH 不可充报警)  → 红灯闪(1Hz), 绿灯灭
    2. 任一槽"有电池且在实际充电中"          → 红灯常亮, 绿灯灭
    3. 任一槽 FULL(无 0/1/2)                → 绿灯常亮, 红灯灭
    4. 其余(全空 / 空闲有电池)              → 全灭
  ⚠ 规则0 的原因: 灯亮 = 往该槽节点灌电流 ⇒ 测量期间点灯会干扰判型; 实测用
     【红灯轨】判型卡住(镍氢停在检测中), 用【绿灯轨】(Vf高、电流小)则正常 ⇒
     测量窗口回到 V58W 的已知良好组合。

  上电自检(ISR 调用, 保持 V58W 行为): Phase0 = 绿1s → Phase1 = 红1s → Phase2 正常

  隔离保证: 本模块只写 RC5/RC4 两个专用驱动脚, 不碰任何采样脚,
            不写门控(MOSFET), 不写 ADC 相关寄存器 ⇒ 判型不受影响。
  闪烁基准: 按真实 10ms 节拍(g_elapsedTicks)累加, 与主循环轮速/打印阻塞解耦
            (沿用 V58W 缺陷①修复)
  -------------------------------------------*/
#include "config.h"

/* (V58Z)闪烁周期长度(10ms节拍数), 名字沿用V58W:
   ⚠ 本宏是"一个完整周期(亮+灭)"的长度 —— 相位在 0..本值-1 循环, 亮相为本值的前半.
     TICK_PER_SEC = 100节拍 = 1.0s ⇒ 亮0.5s / 灭0.5s = 1Hz
   原值 TICK_PER_SEC/4 = 25节拍 ⇒ 周期250ms(约4Hz): 现场实测红灯轨(RC4/Q8)
   表现为"红灯常亮不闪"(绿灯轨RC5/Q11同样代码能闪) ⇒ 放慢到 1Hz:
     ① 更符合"报警灯"观感; ② 同时用于判别红灯轨门极RC是否过慢(若能闪即为门极RC). */
#define LED_BLINK_HALF      (TICK_PER_SEC)

static unsigned char s_ledBlinkCnt = 0;   /* 闪烁相位累积节拍(仅主循环访问) */

/* --- 引脚输出宏 ---------------------------------------------------------
   LED_RED_WRITE(0)=红亮  LED_RED_WRITE(1)=红灭  (低有效)
   LED_GREEN_WRITE(...) 同上; 调试版(UART_PRINT_EN=1)时 RC4 归软件UART的TX,
   绿灯写操作变空操作 ⇒ 既保护串口输出, 也避免"绿灯乱闪"被误判为显示故障。
   注: 生产版(UART_PRINT_EN=0)绿灯正常工作。 */
#if UART_PRINT_EN
	/* 调试版: 红灯轨(RC4)与软件UART TX复用 ⇒ 放弃红灯输出以保护串口日志;
	   绿灯轨(RC5)不受影响, 仍可指示。⚠ 灯色验收请用生产版(UART=0)。 */
	#define LED_RED_WRITE(lv)       ((void)0)
	#define LED_GREEN_WRITE(lv)     (PIN_LED_GREEN = (lv))
#else
	#define LED_RED_WRITE(lv)       (PIN_LED_RED = (lv))
	#define LED_GREEN_WRITE(lv)     (PIN_LED_GREEN = (lv))
#endif

/*========================================================================
  灯光 API (6个): 红/绿灯 的 常亮 / 常灭 / 闪烁
  ----------------------------------------------------------------------
  · 常亮/常灭: 立即写引脚, 立即可见.
  · 闪烁: 按 s_ledBlinkCnt 相位输出(亮半周期/灭半周期), 相位由
          Led_Display_Update() 每轮推进一次 ⇒ 闪烁函数需"主循环周期调用"
          (规则表内部就是这样用的); 直连调用时请保证每轮调用一次.
  · 红绿各自独立, 但本硬件"同时点亮红绿"无显示意义 ⇒ 规则表里始终成对设置
    (红亮/绿灭 或 红灭/绿亮 或 全灭).
========================================================================*/
void Led_Red_On(void)      { LED_RED_WRITE(0); }
void Led_Red_Off(void)     { LED_RED_WRITE(1); }
void Led_Green_On(void)    { LED_GREEN_WRITE(0); }
void Led_Green_Off(void)   { LED_GREEN_WRITE(1); }
void Led_All_Off(void)     { LED_RED_WRITE(1); LED_GREEN_WRITE(1); }

void Led_Red_Blink(void)
{
	if(s_ledBlinkCnt < (LED_BLINK_HALF / 2))
		LED_RED_WRITE(0);        /* 亮相 */
	else
		LED_RED_WRITE(1);        /* 灭相 */
}

void Led_Green_Blink(void)
{
	if(s_ledBlinkCnt < (LED_BLINK_HALF / 2))
		LED_GREEN_WRITE(0);
	else
		LED_GREEN_WRITE(1);
}

/*========================================================================
  函数: Led_Display_Update
  功能: 按"电池类型 + 充电状态"刷新灯光(主循环每轮调用一次)
  隔离: 只读 g_slot[].state / .voltage, 只写 2 个 LED 驱动脚
========================================================================*/
void Led_Display_Update(void)
{
	unsigned char i;
	unsigned char hasErr  = 0;    /* 有槽报错(不可充/异常) */
	unsigned char hasMeas = 0;    /* 有电池且处于【测量态】(检测/阻抗/二极管) */
	unsigned char hasChg  = 0;    /* 有电池且处于【实际充电】(激活/预充/CC/CV) */
	unsigned char hasFull = 0;    /* 有槽充满 */

	/* --- 闪烁相位推进(按真实10ms节拍, 与轮速解耦) --- */
	s_ledBlinkCnt = (unsigned char)(s_ledBlinkCnt + g_elapsedTicks);
	if(s_ledBlinkCnt >= LED_BLINK_HALF)
		s_ledBlinkCnt = 0;

	/* --- 统计 12 槽 --- */
	for(i = 0; i < BATTERY_SLOTS; i++)
	{
		unsigned char s = S_STATE(i);

		if(s == CHG_DETECT || s == CHG_IMP_CHECK || s == CHG_IMP_DIODE_TEST)
		{
			/* (V58Z1)测量态: 只需保护"确实有电池"的槽 —— 空槽没有到GND的
			   回流路径, 灯电流进不了它的节点, 不影响空槽轮询判定. */
			if(S_VOLT(i) < ADC_V_OPEN)
				hasMeas = 1;
		}
		else if(s == CHG_ERROR)
		{
			hasErr = 1;
		}
		else if(s != CHG_IDLE && s != CHG_FULL)
		{
			/* 只有"确实有电池"的槽才算忙: 空槽也会走 IDLE→DETECT→IMP→IDLE
			   轮询(空槽读数≈VCC_norm≈4247 ≥ ADC_V_OPEN), 若把空槽检测态也算
			   充电中, 12个空槽时几乎总有一个在DETECT ⇒ 违反"全空⇒全灭"
			   (V58W 缺陷②修复, 保留原判据) */
			if(S_VOLT(i) < ADC_V_OPEN)
				hasChg = 1;
		}
		else if(s == CHG_FULL)
		{
			hasFull = 1;
		}
	}

	/* --- 规则表: 整板同色(优先级 0>1>2>3>4) ---
	   ⚠ (V58Z1)"测量态"必须排第一, 且必须用【绿灯轨】:
	     灯回路 = LED轨 → 管芯 → R → 槽节点 → 电池 → GND ⇒ "灯亮"本身就是
	     往该槽节点灌电流 ⇒ 测量期间点灯会改变节点电位, 干扰判型(判型靠的就是
	     节点电压/阻抗响应). 本工程历史同样结论: 显示接管门控 ⇒ "镍氢判型卡死".
	     实测对照(同代码, 只差用哪条轨):
	       V58W/V58X: 检测期导通【绿灯轨】(绿管芯Vf高 ⇒ 电流小) ⇒ 镍氢几秒识别 ✓
	       V58Y/V58Z: 检测期导通【红灯轨】(红管芯Vf低 ⇒ 电流大) ⇒ B6 卡在 DETECT
	                  ⇒ 现场表现"红灯常亮不闪"(不是灯关不掉, 而是状态一直停在
	                    "检测中"对应的红常亮) ✗
	     ⇒ 故测量窗口回到"绿灯轨导通"(= V58W 已知良好组合), 不用红灯轨. */
	if(hasMeas)
	{
		/* 0. 有电池正在检测/阻抗测量 ⇒ 绿灯轨导通(小电流, 不扰动判型) */
		Led_Red_Off();
		Led_Green_On();
	}
	else if(hasErr)
	{
		/* 1. 任一槽报错(含 Dry/NiMH 不可充) ⇒ 红灯闪, 绿灯灭 */
		Led_Green_Off();
		Led_Red_Blink();
	}
	else
	{
		s_ledBlinkCnt = 0;       /* 非错误态复位相位: 下次进错误态必从"亮"开始 */

		if(hasChg)
		{
			/* 2. 有电池在实际充电(激活/预充/CC/CV) ⇒ 红灯常亮, 绿灯灭 */
			Led_Green_Off();
			Led_Red_On();
		}
		else if(hasFull)
		{
			/* 3. 有槽充满(无 0/1/2) ⇒ 绿灯常亮, 红灯灭 */
			Led_Red_Off();
			Led_Green_On();
		}
		else
		{
			/* 4. 全空 / 空闲有电池 ⇒ 全灭 */
			Led_All_Off();
		}
	}
}

/*========================================================================
  函数: PowerOnLedSequence   (V58W 原样: 相位0=绿1s → 相位1=红1s → 相位2=正常)
  说明: ISR 中 g_powerOnPhase < 2 时调用; 引脚由本函数独占, 主循环此时不刷灯.
        自检期主循环把12槽采样脚灌电流(空板可见的原理), 与灯色无关.
========================================================================*/
void PowerOnLedSequence(void)
{
	/* g_powerOnTimer 已由 ISR 按 10ms 显式节拍递增, 此处不自增 */

	if(g_powerOnPhase == 0)
	{
		/* 相位0: 仅绿 1 秒(需求: 上电后先绿) */
		LED_RED_WRITE(1);        /* 红灯灭 */
		LED_GREEN_WRITE(0);      /* 绿灯亮 */
		if(g_powerOnTimer >= TICK_PER_SEC)
		{
			g_powerOnTimer = 0;
			g_powerOnPhase = 1;
		}
	}
	else if(g_powerOnPhase == 1)
	{
		/* 相位1: 仅红 1 秒 */
		LED_RED_WRITE(0);        /* 红灯亮 */
		LED_GREEN_WRITE(1);      /* 绿灯灭 */
		if(g_powerOnTimer >= TICK_PER_SEC)
		{
			g_powerOnTimer = 0;
			g_powerOnPhase = 2;  /* 自检完成, 转入 Led_Display_Update 正常显示 */
		}
	}
	/* 相位2: 由 Led_Display_Update 按槽状态驱动 */
}
