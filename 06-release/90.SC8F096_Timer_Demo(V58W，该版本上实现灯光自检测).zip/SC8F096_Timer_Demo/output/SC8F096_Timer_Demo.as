opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_CCCV_Control
	FNCALL	_main,_Get_Vcc
	FNCALL	_main,_Read_Temperature
	FNCALL	_main,_Sense_Pins_AsSink
	FNCALL	_main,_Sense_Pins_Restore
	FNCALL	_main,_Slot_Charge_Ctrl
	FNCALL	_main,_System_Init
	FNCALL	_main,_Update_LED_Global
	FNCALL	_Update_LED_Global,___bmul
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_Slot_Charge_Ctrl,_Adc_Norm
	FNCALL	_Slot_Charge_Ctrl,_Detect_BatteryType
	FNCALL	_Slot_Charge_Ctrl,_Detect_Classify
	FNCALL	_Slot_Charge_Ctrl,_Enter_DiodeTest
	FNCALL	_Slot_Charge_Ctrl,_Get_Vcc
	FNCALL	_Slot_Charge_Ctrl,_Route_LiIon
	FNCALL	_Slot_Charge_Ctrl,_Route_LinearLi
	FNCALL	_Slot_Charge_Ctrl,___bmul
	FNCALL	_Slot_Charge_Ctrl,___lldiv
	FNCALL	_Slot_Charge_Ctrl,___wmul
	FNCALL	_Route_LinearLi,_Route_DetectLi
	FNCALL	_Route_LiIon,_Route_DetectLi
	FNCALL	_Detect_Classify,_Get_Vcc
	FNCALL	_Detect_Classify,_Route_DetectLi
	FNCALL	_Detect_Classify,___lwdiv
	FNCALL	_Route_DetectLi,___lldiv
	FNCALL	_Route_DetectLi,___lmul
	FNCALL	_Get_Vcc,_ADC_Sample
	FNCALL	_Get_Vcc,___lldiv
	FNCALL	_Adc_Norm,_ADC_Sample
	FNCALL	_Adc_Norm,___lldiv
	FNCALL	_Adc_Norm,___lmul
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,___bmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_elapsedTicks
	global	_g_detectWaiter
	global	_g_detectOwner
	global	_g_vcc_mv
psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	29

;initializer for _g_elapsedTicks
	retlw	01h
	retlw	0

	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	35

;initializer for _g_detectWaiter
	retlw	0FFh
	line	29

;initializer for _g_detectOwner
	retlw	0FFh
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	15

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

	global	_s_adcChannels
psect	strings,class=STRING,delta=2,noexec
global __pstrings
__pstrings:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 1 byte each
stringcode:stringdir:
movlw high(stringdir)
movwf pclath
movf fsr,w
incf fsr
	addwf pc
	global __stringbase
__stringbase:
	retlw	0
psect	strings
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	45
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_pwmDuty
	global	_g_doNtcRead
	global	_s_work
	global	_g_impData
	global	_g_slotRefV
	global	_g_detectLowCnt
	global	_g_diodeTrace
	global	_g_highVFlag
	global	_g_capFlag
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_lastHwTick
	global	_g_hwTick
	global	_g_powerOnTimer
	global	_g_cvIntegral
	global	_s_ledBlinkCnt
	global	_g_diodeTraceCnt
	global	_g_vccProtect
	global	_g_tempProtect
	global	_test_adc
	global	_g_tempPhase
	global	_g_hwTickDiv
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_adresult
	global	_g_slot
	global	_g_stableCnt
	global	_g_ovCnt
	global	_g_ccBlocks
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB5
_RB5	set	0x35
	global	_RB4
_RB4	set	0x34
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA7
_RA7	set	0x437
	global	_RA6
_RA6	set	0x436
	global	_RA5
_RA5	set	0x435
	global	_RA4
_RA4	set	0x434
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RD0
_RD0	set	0x838
	global	_RD1
_RD1	set	0x839
	global	_RC1
_RC1	set	0x831
	global	_RC0
_RC0	set	0x830
	global	_RD5
_RD5	set	0x83D
	global	_RD4
_RD4	set	0x83C
	global	_RD3
_RD3	set	0x83B
	global	_RD2
_RD2	set	0x83A
	global	_RC4
_RC4	set	0x834
	global	_RC5
_RC5	set	0x835
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
; #config settings
	file	"SC8F096_Timer_Demo.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_g_doNtcRead:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_g_pwmDuty:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_s_work:
       ds      6

_g_impData:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_slotRefV:
       ds      24

_g_detectLowCnt:
       ds      12

_g_diodeTrace:
       ds      4

_g_highVFlag:
       ds      2

_g_capFlag:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_lastHwTick:
       ds      2

_g_hwTick:
       ds      2

_g_powerOnTimer:
       ds      2

_g_cvIntegral:
       ds      2

_s_ledBlinkCnt:
       ds      1

_g_diodeTraceCnt:
       ds      1

_g_vccProtect:
       ds      1

_g_tempProtect:
       ds      1

_test_adc:
       ds      1

_g_tempPhase:
       ds      1

_g_hwTickDiv:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_adresult:
       ds      2

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	29
_g_elapsedTicks:
       ds      2

psect	dataBANK1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	35
_g_detectWaiter:
       ds      1

psect	dataBANK1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	29
_g_detectOwner:
       ds      1

psect	dataBANK1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	15
_g_vcc_mv:
       ds      2

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_stableCnt:
       ds      12

_g_ovCnt:
       ds      12

_g_ccBlocks:
       ds      12

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"SC8F096_Timer_Demo.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
	fcall	__pidataBANK1+2		;fetch initializer
	movwf	__pdataBANK1+2&07fh		
	fcall	__pidataBANK1+3		;fetch initializer
	movwf	__pdataBANK1+3&07fh		
	fcall	__pidataBANK1+4		;fetch initializer
	movwf	__pdataBANK1+4&07fh		
	fcall	__pidataBANK1+5		;fetch initializer
	movwf	__pdataBANK1+5&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+024h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+043h)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+08h)
	fcall	clear_ram0
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
??_main:	; 1 bytes @ 0x0
	ds	2
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Slot_Charge_Ctrl:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Update_LED_Global:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
??_Isr_Timer:	; 1 bytes @ 0x0
?_Sense_Pins_AsSink:	; 1 bytes @ 0x0
?_Sense_Pins_Restore:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?_Route_LiIon:	; 1 bytes @ 0x0
?_Enter_DiodeTest:	; 1 bytes @ 0x0
?_Get_Vcc:	; 2 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	ds	2
??_AD_Init:	; 1 bytes @ 0x2
??_Sense_Pins_AsSink:	; 1 bytes @ 0x2
??_Sense_Pins_Restore:	; 1 bytes @ 0x2
?_ADC_Sample:	; 1 bytes @ 0x2
?_Detect_BatteryType:	; 1 bytes @ 0x2
??_Enter_DiodeTest:	; 1 bytes @ 0x2
?___bmul:	; 1 bytes @ 0x2
	global	?___wmul
?___wmul:	; 2 bytes @ 0x2
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x2
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x2
	global	?___lmul
?___lmul:	; 4 bytes @ 0x2
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x2
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x2
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x2
	global	___wmul@multiplier
___wmul@multiplier:	; 2 bytes @ 0x2
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x2
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x2
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x2
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x3
??___bmul:	; 1 bytes @ 0x3
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x3
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x4
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x4
	global	___wmul@multiplicand
___wmul@multiplicand:	; 2 bytes @ 0x4
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x4
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x4
	ds	1
??_Update_LED_Global:	; 1 bytes @ 0x5
??_System_Init:	; 1 bytes @ 0x5
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x5
	global	Enter_DiodeTest@idx
Enter_DiodeTest@idx:	; 1 bytes @ 0x5
	ds	1
??___wmul:	; 1 bytes @ 0x6
??___awdiv:	; 1 bytes @ 0x6
??___lwdiv:	; 1 bytes @ 0x6
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x6
	global	___wmul@product
___wmul@product:	; 2 bytes @ 0x6
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x6
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x6
	ds	1
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x7
	ds	1
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x8
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x8
	ds	2
??_Get_Vcc:	; 1 bytes @ 0xA
??_Adc_Norm:	; 1 bytes @ 0xA
??___lmul:	; 1 bytes @ 0xA
??___lldiv:	; 1 bytes @ 0xA
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
??_CCCV_Control:	; 1 bytes @ 0x0
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x0
	global	Update_LED_Global@hasErr
Update_LED_Global@hasErr:	; 1 bytes @ 0x0
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x0
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x1
	global	Update_LED_Global@hasChg
Update_LED_Global@hasChg:	; 1 bytes @ 0x1
	ds	1
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x2
	global	Update_LED_Global@hasFull
Update_LED_Global@hasFull:	; 1 bytes @ 0x2
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x2
	ds	1
	global	Update_LED_Global@s
Update_LED_Global@s:	; 1 bytes @ 0x3
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x4
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x4
	global	Update_LED_Global@i
Update_LED_Global@i:	; 1 bytes @ 0x4
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x4
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x5
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0x6
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0x7
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x8
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x8
	ds	1
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0xA
	ds	1
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xC
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0xC
	ds	2
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0xE
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0xF
	ds	1
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x10
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0x10
	ds	1
??_Read_Temperature:	; 1 bytes @ 0x11
?_Route_DetectLi:	; 1 bytes @ 0x11
	global	?_Adc_Norm
?_Adc_Norm:	; 2 bytes @ 0x11
	global	Route_DetectLi@slot_v
Route_DetectLi@slot_v:	; 2 bytes @ 0x11
	global	Get_Vcc@pt
Get_Vcc@pt:	; 4 bytes @ 0x11
	ds	1
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x12
	ds	1
??_Route_DetectLi:	; 1 bytes @ 0x13
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x13
	ds	1
	global	Adc_Norm@ch
Adc_Norm@ch:	; 1 bytes @ 0x14
	ds	1
	global	Adc_Norm@raw
Adc_Norm@raw:	; 2 bytes @ 0x15
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x15
	ds	2
	global	Route_DetectLi@bat_mv
Route_DetectLi@bat_mv:	; 2 bytes @ 0x17
	ds	2
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x19
	global	Route_DetectLi@vx_mv
Route_DetectLi@vx_mv:	; 4 bytes @ 0x19
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x1B
	ds	2
	global	Route_DetectLi@bat_mv_long
Route_DetectLi@bat_mv_long:	; 4 bytes @ 0x1D
	ds	4
	global	Route_DetectLi@st
Route_DetectLi@st:	; 1 bytes @ 0x21
	ds	1
	global	Route_DetectLi@idx
Route_DetectLi@idx:	; 1 bytes @ 0x22
	ds	1
??_Route_LiIon:	; 1 bytes @ 0x23
?_Route_LinearLi:	; 1 bytes @ 0x23
?_Detect_Classify:	; 1 bytes @ 0x23
	global	Detect_Classify@fromHighV
Detect_Classify@fromHighV:	; 1 bytes @ 0x23
	global	Route_LinearLi@pre
Route_LinearLi@pre:	; 2 bytes @ 0x23
	ds	1
??_Detect_Classify:	; 1 bytes @ 0x24
	ds	1
??_Route_LinearLi:	; 1 bytes @ 0x25
	ds	1
	global	Route_LiIon@idx
Route_LiIon@idx:	; 1 bytes @ 0x26
	ds	1
	global	Detect_Classify@idx
Detect_Classify@idx:	; 1 bytes @ 0x27
	ds	1
	global	Route_LinearLi@idx
Route_LinearLi@idx:	; 1 bytes @ 0x28
	ds	1
??_Slot_Charge_Ctrl:	; 1 bytes @ 0x29
	ds	5
	global	Slot_Charge_Ctrl@v_init
Slot_Charge_Ctrl@v_init:	; 2 bytes @ 0x2E
	ds	2
	global	Slot_Charge_Ctrl@vcc_norm_pre
Slot_Charge_Ctrl@vcc_norm_pre:	; 2 bytes @ 0x30
	ds	2
	global	Slot_Charge_Ctrl@vcc_norm_now
Slot_Charge_Ctrl@vcc_norm_now:	; 2 bytes @ 0x32
	ds	2
	global	Slot_Charge_Ctrl@ptTick
Slot_Charge_Ctrl@ptTick:	; 2 bytes @ 0x34
	ds	2
	global	Slot_Charge_Ctrl@vcc_norm
Slot_Charge_Ctrl@vcc_norm:	; 2 bytes @ 0x36
	ds	2
	global	Slot_Charge_Ctrl@pt
Slot_Charge_Ctrl@pt:	; 1 bytes @ 0x38
	ds	1
	global	_Slot_Charge_Ctrl$322
_Slot_Charge_Ctrl$322:	; 2 bytes @ 0x39
	ds	2
	global	Slot_Charge_Ctrl@charge_ticks_prev
Slot_Charge_Ctrl@charge_ticks_prev:	; 2 bytes @ 0x3B
	ds	2
	global	Slot_Charge_Ctrl@newv
Slot_Charge_Ctrl@newv:	; 2 bytes @ 0x3D
	ds	2
	global	Slot_Charge_Ctrl@v_ref
Slot_Charge_Ctrl@v_ref:	; 2 bytes @ 0x3F
	ds	2
	global	Slot_Charge_Ctrl@dly
Slot_Charge_Ctrl@dly:	; 1 bytes @ 0x41
	ds	1
	global	Slot_Charge_Ctrl@diff
Slot_Charge_Ctrl@diff:	; 2 bytes @ 0x42
	ds	2
	global	Slot_Charge_Ctrl@pre
Slot_Charge_Ctrl@pre:	; 2 bytes @ 0x44
	ds	2
	global	Slot_Charge_Ctrl@idx
Slot_Charge_Ctrl@idx:	; 1 bytes @ 0x46
	ds	1
	global	main@i
main@i:	; 1 bytes @ 0x47
	ds	1
;!
;!Data Sizes:
;!    Strings     0
;!    Constant    12
;!    Data        6
;!    BSS         184
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     10      12
;!    BANK0            80     72      80
;!    BANK1            80      2      75
;!    BANK3            80      0      36
;!    BANK2            80      0      72

;!
;!Pointer List with Targets:
;!
;!    None.


;!
;!Critical Paths under _main in COMMON
;!
;!    _Update_LED_Global->___bmul
;!    _System_Init->___bmul
;!    _Route_DetectLi->___lmul
;!    _Adc_Norm->___lmul
;!    _Read_Temperature->___lmul
;!    ___lldiv->___lmul
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    None.
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Slot_Charge_Ctrl
;!    _Slot_Charge_Ctrl->_Route_LinearLi
;!    _Route_LinearLi->_Route_DetectLi
;!    _Route_LiIon->_Route_DetectLi
;!    _Detect_Classify->_Route_DetectLi
;!    _Route_DetectLi->___lldiv
;!    _Get_Vcc->___lldiv
;!    _Adc_Norm->___lldiv
;!    _Read_Temperature->___lldiv
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    None.
;!
;!Critical Paths under _main in BANK1
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 3     3      0   34596
;!                                             71 BANK0      1     1      0
;!                                              0 BANK1      2     2      0
;!                       _CCCV_Control
;!                            _Get_Vcc
;!                   _Read_Temperature
;!                  _Sense_Pins_AsSink
;!                 _Sense_Pins_Restore
;!                   _Slot_Charge_Ctrl
;!                        _System_Init
;!                  _Update_LED_Global
;! ---------------------------------------------------------------------------------
;! (1) _Update_LED_Global                                    7     7      0     629
;!                                              5 COMMON     2     2      0
;!                                              0 BANK0      5     5      0
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0     556
;!                                              5 COMMON     1     1      0
;!                            _AD_Init
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Slot_Charge_Ctrl                                    30    30      0   26156
;!                                             41 BANK0     30    30      0
;!                           _Adc_Norm
;!                 _Detect_BatteryType
;!                    _Detect_Classify
;!                    _Enter_DiodeTest
;!                            _Get_Vcc
;!                        _Route_LiIon
;!                     _Route_LinearLi
;!                             ___bmul
;!                            ___lldiv
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (2) ___wmul                                               6     2      4    1842
;!                                              2 COMMON     6     2      4
;! ---------------------------------------------------------------------------------
;! (2) _Route_LinearLi                                       6     4      2    3257
;!                                             35 BANK0      6     4      2
;!                     _Route_DetectLi
;! ---------------------------------------------------------------------------------
;! (2) _Route_LiIon                                          4     4      0    2740
;!                                             35 BANK0      4     4      0
;!                     _Route_DetectLi
;! ---------------------------------------------------------------------------------
;! (2) _Enter_DiodeTest                                      4     4      0      33
;!                                              2 COMMON     4     4      0
;! ---------------------------------------------------------------------------------
;! (2) _Detect_Classify                                      5     4      1    5679
;!                                             35 BANK0      5     4      1
;!                            _Get_Vcc
;!                     _Route_DetectLi
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (3) _Route_DetectLi                                      18    16      2    2678
;!                                             17 BANK0     18    16      2
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (2) _Get_Vcc                                              4     4      0    1889
;!                                             17 BANK0      4     4      0
;!                         _ADC_Sample
;!                            ___lldiv
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     185
;!                                              2 COMMON     2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _Adc_Norm                                             6     3      3    2683
;!                                             17 BANK0      6     3      3
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (1) _Sense_Pins_Restore                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Sense_Pins_AsSink                                    0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Read_Temperature                                    12    12      0    3363
;!                                             17 BANK0     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4     480
;!                                              2 COMMON     7     3      4
;! ---------------------------------------------------------------------------------
;! (4) ___lmul                                              12     4      8     750
;!                                              2 COMMON     8     0      8
;!                                              0 BANK0      4     4      0
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1182
;!                                              4 BANK0     13     5      8
;!                             ___lmul (ARG)
;!                             ___wmul (ARG)
;! ---------------------------------------------------------------------------------
;! (3) _ADC_Sample                                          18    17      1     684
;!                                              2 COMMON     5     4      1
;!                                              0 BANK0     13    13      0
;! ---------------------------------------------------------------------------------
;! (1) _CCCV_Control                                        20    20      0    1904
;!                                              0 BANK0     20    20      0
;!                            ___awdiv
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1     378
;!                                              2 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (2) ___awdiv                                              8     4      4     428
;!                                              2 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 4
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (5) _Isr_Timer                                            2     2      0       0
;!                                              0 COMMON     2     2      0
;!                 _PowerOnLedSequence
;! ---------------------------------------------------------------------------------
;! (6) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     ___bmul
;!   _Get_Vcc
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!       ___wmul (ARG)
;!   _Read_Temperature
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!       ___wmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!   _Sense_Pins_AsSink
;!   _Sense_Pins_Restore
;!   _Slot_Charge_Ctrl
;!     _Adc_Norm
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!         ___wmul (ARG)
;!       ___lmul
;!     _Detect_BatteryType
;!     _Detect_Classify
;!       _Get_Vcc
;!         _ADC_Sample
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!       _Route_DetectLi
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!         ___lmul
;!       ___lwdiv
;!     _Enter_DiodeTest
;!     _Get_Vcc
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!         ___wmul (ARG)
;!     _Route_LiIon
;!       _Route_DetectLi
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!         ___lmul
;!     _Route_LinearLi
;!       _Route_DetectLi
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!         ___lmul
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!       ___wmul (ARG)
;!     ___wmul
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!   _Update_LED_Global
;!     ___bmul
;!
;! _Isr_Timer (ROOT)
;!   _PowerOnLedSequence
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50      0      24       8       45.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      0      48      10       90.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50      2      4B       6       93.8%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     48      50       4      100.0%
;!BITBANK0            50      0       0       3        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      A       C       1       85.7%
;!BITCOMMON            E      0       1       0        7.1%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     113      12        0.0%
;!ABS                  0      0     113      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 456 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   71[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       2       0       0
;;      Totals:         0       1       2       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_CCCV_Control
;;		_Get_Vcc
;;		_Read_Temperature
;;		_Sense_Pins_AsSink
;;		_Sense_Pins_Restore
;;		_Slot_Charge_Ctrl
;;		_System_Init
;;		_Update_LED_Global
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	456
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	456
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	461
	
l5693:	
;main.c: 458: unsigned char i;
;main.c: 461: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_main+0)^080h+0+1),f
	movlw	241
movwf	((??_main+0)^080h+0),f
	u9717:
decfsz	((??_main+0)^080h+0),f
	goto	u9717
	decfsz	((??_main+0)^080h+0+1),f
	goto	u9717
opt asmopt_pop

	line	462
# 462 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	465
	
l5695:	
;main.c: 465: System_Init();
	fcall	_System_Init
	line	473
;main.c: 473: while(1)
	
l360:	
	line	475
# 475 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	481
	
l5697:	
;main.c: 481: g_elapsedTicks = g_hwTick - g_lastHwTick;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_hwTick+1)^080h,w	;volatile
	movwf	(_g_elapsedTicks+1)^080h
	movf	(_g_hwTick)^080h,w	;volatile
	movwf	(_g_elapsedTicks)^080h
	
l5699:	
	movf	(_g_lastHwTick)^080h,w
	subwf	(_g_elapsedTicks)^080h,f
	movf	(_g_lastHwTick+1)^080h,w
	skipc
	decf	(_g_elapsedTicks+1)^080h,f
	subwf	(_g_elapsedTicks+1)^080h,f
	line	482
	
l5701:	
;main.c: 482: if(g_elapsedTicks == 0U)
	movf	((_g_elapsedTicks)^080h),w
iorwf	((_g_elapsedTicks+1)^080h),w
	btfss	status,2
	goto	u9671
	goto	u9670
u9671:
	goto	l5705
u9670:
	line	483
	
l5703:	
;main.c: 483: g_elapsedTicks = 1U;
	clrf	(_g_elapsedTicks)^080h
	incf	(_g_elapsedTicks)^080h,f
	clrf	(_g_elapsedTicks+1)^080h
	line	484
	
l5705:	
;main.c: 484: g_lastHwTick = g_hwTick;
	movf	(_g_hwTick+1)^080h,w	;volatile
	movwf	(_g_lastHwTick+1)^080h
	movf	(_g_hwTick)^080h,w	;volatile
	movwf	(_g_lastHwTick)^080h
	line	487
	
l5707:	
;main.c: 487: Get_Vcc();
	fcall	_Get_Vcc
	line	500
	
l5709:	
;main.c: 500: if(g_powerOnPhase >= 2U)
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_powerOnPhase)^080h,w
	skipc
	goto	u9681
	goto	u9680
u9681:
	goto	l5729
u9680:
	line	503
	
l5711:	
;main.c: 501: {
;main.c: 503: Sense_Pins_Restore();
	fcall	_Sense_Pins_Restore
	line	506
	
l5713:	
;main.c: 506: for(i = 0; i < 12; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(main@i)
	line	508
	
l5719:	
;main.c: 507: {
;main.c: 508: Slot_Charge_Ctrl(i);
	movf	(main@i),w
	fcall	_Slot_Charge_Ctrl
	line	506
	
l5721:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(main@i),f
	
l5723:	
	movlw	low(0Ch)
	subwf	(main@i),w
	skipc
	goto	u9691
	goto	u9690
u9691:
	goto	l5719
u9690:
	line	512
	
l5725:	
;main.c: 509: }
;main.c: 512: CCCV_Control();
	fcall	_CCCV_Control
	line	515
	
l5727:	
;main.c: 515: Update_LED_Global();
	fcall	_Update_LED_Global
	line	516
;main.c: 516: }
	goto	l5731
	line	520
	
l5729:	
;main.c: 517: else
;main.c: 518: {
;main.c: 520: Sense_Pins_AsSink();
	fcall	_Sense_Pins_AsSink
	line	524
	
l5731:	
;main.c: 521: }
;main.c: 524: if(g_doNtcRead)
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u9701
	goto	u9700
u9701:
	goto	l360
u9700:
	line	526
	
l5733:	
;main.c: 525: {
;main.c: 526: g_doNtcRead = 0;
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	527
	
l5735:	
;main.c: 527: Read_Temperature();
	fcall	_Read_Temperature
	goto	l360
	global	start
	ljmp	start
	opt stack 0
	line	540
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_Update_LED_Global

;; *************** function _Update_LED_Global *****************
;; Defined at:
;;		line 41 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    3[BANK0 ] unsigned char 
;;  i               1    4[BANK0 ] unsigned char 
;;  hasFull         1    2[BANK0 ] unsigned char 
;;  hasChg          1    1[BANK0 ] unsigned char 
;;  hasErr          1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2       5       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	41
global __ptext1
__ptext1:	;psect for function _Update_LED_Global
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	41
	global	__size_of_Update_LED_Global
	__size_of_Update_LED_Global	equ	__end_of_Update_LED_Global-_Update_LED_Global
	
_Update_LED_Global:	
;incstack = 0
	opt	stack 4
; Regs used in _Update_LED_Global: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	44
	
l4415:	
;led.c: 43: unsigned char i;
;led.c: 44: unsigned char hasErr = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Update_LED_Global@hasErr)
	line	45
;led.c: 45: unsigned char hasChg = 0;
	clrf	(Update_LED_Global@hasChg)
	line	46
;led.c: 46: unsigned char hasFull = 0;
	clrf	(Update_LED_Global@hasFull)
	line	48
;led.c: 48: for(i = 0; i < 12; i++)
	clrf	(Update_LED_Global@i)
	line	50
	
l4421:	
;led.c: 49: {
;led.c: 50: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Update_LED_Global@s)
	line	51
	
l4423:	
;led.c: 51: if(s == 7)
		movlw	7
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u6671
	goto	u6670
u6671:
	goto	l4427
u6670:
	line	53
	
l4425:	
;led.c: 52: {
;led.c: 53: hasErr = 1;
	clrf	(Update_LED_Global@hasErr)
	incf	(Update_LED_Global@hasErr),f
	line	54
;led.c: 54: }
	goto	l4439
	line	55
	
l4427:	
;led.c: 55: else if(s != 0 && s != 6)
	movf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u6681
	goto	u6680
u6681:
	goto	l4435
u6680:
	
l4429:	
		movlw	6
	xorwf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u6691
	goto	u6690
u6691:
	goto	l4435
u6690:
	line	62
	
l4431:	
;led.c: 56: {
;led.c: 62: if(g_slot[(unsigned char)(i)].voltage < 3990)
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Update_LED_Global+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Update_LED_Global+0)+0+1
	movlw	0Fh
	subwf	1+(??_Update_LED_Global+0)+0,w
	movlw	096h
	skipnz
	subwf	0+(??_Update_LED_Global+0)+0,w
	skipnc
	goto	u6701
	goto	u6700
u6701:
	goto	l4439
u6700:
	line	63
	
l4433:	
;led.c: 63: hasChg = 1;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(Update_LED_Global@hasChg)
	incf	(Update_LED_Global@hasChg),f
	goto	l4439
	line	65
	
l4435:	
;led.c: 65: else if(s == 6)
		movlw	6
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u6711
	goto	u6710
u6711:
	goto	l4439
u6710:
	line	67
	
l4437:	
;led.c: 66: {
;led.c: 67: hasFull = 1;
	clrf	(Update_LED_Global@hasFull)
	incf	(Update_LED_Global@hasFull),f
	line	48
	
l4439:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Update_LED_Global@i),f
	
l4441:	
	movlw	low(0Ch)
	subwf	(Update_LED_Global@i),w
	skipc
	goto	u6721
	goto	u6720
u6721:
	goto	l4421
u6720:
	line	71
	
l4443:	
;led.c: 68: }
;led.c: 69: }
;led.c: 71: if(hasErr)
	movf	((Update_LED_Global@hasErr)),w
	btfsc	status,2
	goto	u6731
	goto	u6730
u6731:
	goto	l4455
u6730:
	line	75
	
l4445:	
;led.c: 72: {
;led.c: 75: RC4 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	76
	
l4447:	
;led.c: 76: s_ledBlinkCnt = (unsigned char)(s_ledBlinkCnt + g_elapsedTicks);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_elapsedTicks)^080h,w
	addwf	(_s_ledBlinkCnt)^080h,f
	line	77
	
l4449:	
;led.c: 77: if(s_ledBlinkCnt >= (100 / 4))
	movlw	low(019h)
	subwf	(_s_ledBlinkCnt)^080h,w
	skipc
	goto	u6741
	goto	u6740
u6741:
	goto	l4453
u6740:
	line	78
	
l4451:	
;led.c: 78: s_ledBlinkCnt = 0;
	clrf	(_s_ledBlinkCnt)^080h
	line	79
	
l4453:	
;led.c: 79: RC5 = (s_ledBlinkCnt < ((100 / 4) / 2)) ? 0 : 1;
	movlw	low(0Ch)
	subwf	(_s_ledBlinkCnt)^080h,w
	skipnc
	goto	u6751
	goto	u6750
	
u6751:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u6764
u6750:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u6764:
	line	80
;led.c: 80: }
	goto	l841
	line	83
	
l4455:	
;led.c: 81: else
;led.c: 82: {
;led.c: 83: s_ledBlinkCnt = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_ledBlinkCnt)^080h
	line	85
	
l4457:	
;led.c: 85: if(hasChg)
	bcf	status, 5	;RP0=0, select bank0
	movf	((Update_LED_Global@hasChg)),w
	btfsc	status,2
	goto	u6771
	goto	u6770
u6771:
	goto	l4461
u6770:
	line	88
	
l4459:	
;led.c: 86: {
;led.c: 88: RC5 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	89
;led.c: 89: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	90
;led.c: 90: }
	goto	l841
	line	91
	
l4461:	
;led.c: 91: else if(hasFull)
	movf	((Update_LED_Global@hasFull)),w
	btfsc	status,2
	goto	u6781
	goto	u6780
u6781:
	goto	l839
u6780:
	line	96
	
l4463:	
;led.c: 92: {
;led.c: 96: RC5 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	97
;led.c: 97: RC4 = 0;
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	98
;led.c: 98: }
	goto	l841
	line	99
	
l839:	
	line	102
;led.c: 99: else
;led.c: 100: {
;led.c: 102: RC5 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	103
;led.c: 103: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	106
	
l841:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Global
	__end_of_Update_LED_Global:
	signat	_Update_LED_Global,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 66 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         1       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_AD_Init
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	66
global __ptext2
__ptext2:	;psect for function _System_Init
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	66
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 4
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	71
	
l3323:	
# 71 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	72
# 72 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text2
	line	73
	
l3325:	
;main.c: 73: OSCCON = 0x72;
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	77
;main.c: 77: TRISA = 0xF0; PORTA = 0x0F;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	78
;main.c: 78: TRISB = 0x30; PORTB = 0x4F;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	79
;main.c: 79: TRISC = 0x07; PORTC = 0x00;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l3327:	
	clrf	(262)^0100h	;volatile
	line	81
	
l3329:	
;main.c: 81: TRISD = 0xF0; PORTD = 0x0F;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l3331:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	84
	
l3333:	
;main.c: 84: WPUA = 0x00; WPDA = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l3335:	
	clrf	(135)^080h	;volatile
	line	85
	
l3337:	
;main.c: 85: WPUB = 0x00; WPDB = 0x00;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l3339:	
	clrf	(7)	;volatile
	line	86
	
l3341:	
;main.c: 86: WPUC = 0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	87
	
l3343:	
;main.c: 87: WPUD = 0x00;
	clrf	(277)^0100h	;volatile
	line	90
	
l3345:	
;main.c: 90: IOCA = 0x00; IOCB = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l3347:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	93
	
l3349:	
;main.c: 93: CC0CON = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	94
	
l3351:	
;main.c: 94: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	101
	
l3353:	
;main.c: 101: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	102
	
l3355:	
;main.c: 102: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	103
	
l3357:	
;main.c: 103: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	104
	
l3359:	
;main.c: 104: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	107
	
l3361:	
;main.c: 107: AD_Init();
	fcall	_AD_Init
	line	118
	
l3363:	
;main.c: 118: OPTION_REG = 0x00;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(1)	;volatile
	line	119
	
l3365:	
;main.c: 119: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	120
	
l3367:	
;main.c: 120: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	121
	
l3369:	
;main.c: 121: INTCON = 0xE0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	125
	
l3371:	
;main.c: 125: g_pwmDuty = 0;
	clrf	(_g_pwmDuty)	;volatile
	line	126
	
l3373:	
;main.c: 126: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)^080h	;volatile
	line	127
	
l3375:	
;main.c: 127: RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	128
	
l3377:	
;main.c: 128: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	129
	
l3379:	
;main.c: 129: RB6 = 1;
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	130
	
l3381:	
;main.c: 130: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	133
	
l3383:	
;main.c: 133: for(i = 0; i < 12; i++)
	clrf	(System_Init@i)
	line	135
	
l3389:	
;main.c: 134: {
;main.c: 135: g_slot[i].state = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	136
;main.c: 136: g_slot[i].type = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	137
;main.c: 137: g_slot[i].voltage = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	138
;main.c: 138: g_slot[i].chargeTimer = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	139
	
l3391:	
;main.c: 139: g_ccBlocks[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	140
	
l3393:	
;main.c: 140: g_ovCnt[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	133
	
l3395:	
	incf	(System_Init@i),f
	
l3397:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u4181
	goto	u4180
u4181:
	goto	l3389
u4180:
	line	144
	
l333:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
global __ptext3
__ptext3:	;psect for function _AD_Init
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 4
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l3095:	
;adc_drv.c: 25: CC0CON = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
;adc_drv.c: 26: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	27
	
l3097:	
;adc_drv.c: 27: ADCON0 = 0X81;
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l3099:	
;adc_drv.c: 28: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	29
	
l376:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Slot_Charge_Ctrl

;; *************** function _Slot_Charge_Ctrl *****************
;; Defined at:
;;		line 427 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   70[BANK0 ] unsigned char 
;;  vcc_norm        2   54[BANK0 ] unsigned int 
;;  pre             2   68[BANK0 ] unsigned int 
;;  diff            2   66[BANK0 ] int 
;;  vcc_norm_now    2   50[BANK0 ] unsigned int 
;;  vcc_norm_pre    2   48[BANK0 ] unsigned int 
;;  ptTick          2   52[BANK0 ] unsigned int 
;;  pt              1   56[BANK0 ] unsigned char 
;;  v_ref           2   63[BANK0 ] unsigned int 
;;  v_init          2   46[BANK0 ] unsigned int 
;;  newv            2   61[BANK0 ] unsigned int 
;;  charge_ticks    2   59[BANK0 ] unsigned int 
;;  dly             1   65[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      25       0       0       0
;;      Temps:          0       5       0       0       0
;;      Totals:         0      30       0       0       0
;;Total ram usage:       30 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Adc_Norm
;;		_Detect_BatteryType
;;		_Detect_Classify
;;		_Enter_DiodeTest
;;		_Get_Vcc
;;		_Route_LiIon
;;		_Route_LinearLi
;;		___bmul
;;		___lldiv
;;		___wmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	427
global __ptext4
__ptext4:	;psect for function _Slot_Charge_Ctrl
psect	text4
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	427
	global	__size_of_Slot_Charge_Ctrl
	__size_of_Slot_Charge_Ctrl	equ	__end_of_Slot_Charge_Ctrl-_Slot_Charge_Ctrl
	
_Slot_Charge_Ctrl:	
;incstack = 0
	opt	stack 2
; Regs used in _Slot_Charge_Ctrl: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
;Slot_Charge_Ctrl@idx stored from wreg
	movwf	(Slot_Charge_Ctrl@idx)
	line	433
	
l4733:	
;charge_mgr.c: 429: unsigned int charge_ticks_prev;
;charge_mgr.c: 430: unsigned char dly;
;charge_mgr.c: 433: s_work = g_slot[idx];
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(_s_work)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	6
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
u7230:
	
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	((??_Slot_Charge_Ctrl+0)+0+2)
	incf	fsr,w
	movwf	((??_Slot_Charge_Ctrl+0)+0+3)
	movf	(??_Slot_Charge_Ctrl+0)+0,w
	movwf	fsr
	bcf	status, 7	;select IRP bank0
	
	movf	((??_Slot_Charge_Ctrl+0)+0+2),w
	movwf	indf
	incf	fsr,w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	((??_Slot_Charge_Ctrl+0)+0+3),w
	movwf	fsr
	decfsz	((??_Slot_Charge_Ctrl+0)+0+1),f
	goto	u7230
	
	line	438
	
l4735:	
;charge_mgr.c: 438: charge_ticks_prev = s_work.chargeTimer;
	movf	1+(_s_work)+04h,w
	movwf	(Slot_Charge_Ctrl@charge_ticks_prev+1)
	movf	0+(_s_work)+04h,w
	movwf	(Slot_Charge_Ctrl@charge_ticks_prev)
	line	439
	
l4737:	
;charge_mgr.c: 439: s_work.chargeTimer += (unsigned int)g_elapsedTicks;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_elapsedTicks)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	0+(_s_work)+04h,f
	skipnc
	incf	1+(_s_work)+04h,f
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_elapsedTicks+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	1+(_s_work)+04h,f
	line	447
	
l4739:	
;charge_mgr.c: 446: if((s_work.state == 1 || s_work.state == 8 || s_work.state == 9) &&
;charge_mgr.c: 447: g_detectOwner != 0xFF && g_detectOwner != idx)
		decf	((_s_work)),w
	btfsc	status,2
	goto	u7241
	goto	u7240
u7241:
	goto	l4745
u7240:
	
l4741:	
		movlw	8
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u7251
	goto	u7250
u7251:
	goto	l4745
u7250:
	
l4743:	
		movlw	9
	xorwf	((_s_work)),w
	btfss	status,2
	goto	u7261
	goto	u7260
u7261:
	goto	l4763
u7260:
	
l4745:	
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectOwner)^080h),w
	btfsc	status,2
	goto	u7271
	goto	u7270
u7271:
	goto	l4763
u7270:
	
l4747:	
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipnz
	goto	u7281
	goto	u7280
u7281:
	goto	l4763
u7280:
	line	451
	
l4749:	
;charge_mgr.c: 448: {
;charge_mgr.c: 451: if(g_detectWaiter == 0xFF)
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectWaiter)^080h),w
	btfss	status,2
	goto	u7291
	goto	u7290
u7291:
	goto	l4755
u7290:
	line	452
	
l4751:	
;charge_mgr.c: 452: g_detectWaiter = idx;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectWaiter)^080h
	goto	l4755
	line	453
	
l506:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l4757
	
l508:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l4757
	
l509:	
	bsf	(51/8),(51)&7	;volatile
	goto	l4757
	
l510:	
	bsf	(50/8),(50)&7	;volatile
	goto	l4757
	
l511:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l4757
	
l512:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l4757
	
l513:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l4757
	
l514:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l4757
	
l515:	
	bsf	(48/8),(48)&7	;volatile
	goto	l4757
	
l516:	
	bsf	(49/8),(49)&7	;volatile
	goto	l4757
	
l517:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l4757
	
l518:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l4757
	
l4755:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l506
	xorlw	1^0	; case 1
	skipnz
	goto	l508
	xorlw	2^1	; case 2
	skipnz
	goto	l509
	xorlw	3^2	; case 3
	skipnz
	goto	l510
	xorlw	4^3	; case 4
	skipnz
	goto	l511
	xorlw	5^4	; case 5
	skipnz
	goto	l512
	xorlw	6^5	; case 6
	skipnz
	goto	l513
	xorlw	7^6	; case 7
	skipnz
	goto	l514
	xorlw	8^7	; case 8
	skipnz
	goto	l515
	xorlw	9^8	; case 9
	skipnz
	goto	l516
	xorlw	10^9	; case 10
	skipnz
	goto	l517
	xorlw	11^10	; case 11
	skipnz
	goto	l518
	goto	l4757
	opt asmopt_pop

	line	454
	
l4757:	
;charge_mgr.c: 454: g_slot[idx] = s_work;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_s_work),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+4,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+5,w
	movwf	indf
	goto	l520
	line	459
	
l523:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l4765
	
l525:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l4765
	
l526:	
	bsf	(51/8),(51)&7	;volatile
	goto	l4765
	
l527:	
	bsf	(50/8),(50)&7	;volatile
	goto	l4765
	
l528:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l4765
	
l529:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l4765
	
l530:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l4765
	
l531:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l4765
	
l532:	
	bsf	(48/8),(48)&7	;volatile
	goto	l4765
	
l533:	
	bsf	(49/8),(49)&7	;volatile
	goto	l4765
	
l534:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l4765
	
l535:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l4765
	
l4763:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l523
	xorlw	1^0	; case 1
	skipnz
	goto	l525
	xorlw	2^1	; case 2
	skipnz
	goto	l526
	xorlw	3^2	; case 3
	skipnz
	goto	l527
	xorlw	4^3	; case 4
	skipnz
	goto	l528
	xorlw	5^4	; case 5
	skipnz
	goto	l529
	xorlw	6^5	; case 6
	skipnz
	goto	l530
	xorlw	7^6	; case 7
	skipnz
	goto	l531
	xorlw	8^7	; case 8
	skipnz
	goto	l532
	xorlw	9^8	; case 9
	skipnz
	goto	l533
	xorlw	10^9	; case 10
	skipnz
	goto	l534
	xorlw	11^10	; case 11
	skipnz
	goto	l535
	goto	l4765
	opt asmopt_pop

	line	460
	
l4765:	
;charge_mgr.c: 460: if(s_work.state == 1 || s_work.state == 8 || s_work.state == 9)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
		decf	((_s_work)),w
	btfsc	status,2
	goto	u7301
	goto	u7300
u7301:
	goto	l4771
u7300:
	
l4767:	
		movlw	8
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u7311
	goto	u7310
u7311:
	goto	l4771
u7310:
	
l4769:	
		movlw	9
	xorwf	((_s_work)),w
	btfss	status,2
	goto	u7321
	goto	u7320
u7321:
	goto	l4783
u7320:
	line	463
	
l4771:	
;charge_mgr.c: 461: {
;charge_mgr.c: 463: for(dly = 0; dly < 20; dly++)
	clrf	(Slot_Charge_Ctrl@dly)
	
l4773:	
	movlw	low(014h)
	subwf	(Slot_Charge_Ctrl@dly),w
	skipc
	goto	u7331
	goto	u7330
u7331:
	goto	l4777
u7330:
	goto	l4785
	line	464
	
l4777:	
;charge_mgr.c: 464: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u9727:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9727
	nop
opt asmopt_pop

	line	463
	
l4779:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Slot_Charge_Ctrl@dly),f
	goto	l4773
	line	468
	
l4783:	
;charge_mgr.c: 466: else
;charge_mgr.c: 467: {
;charge_mgr.c: 468: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u9737:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9737
	nop
opt asmopt_pop

	line	472
	
l4785:	
;charge_mgr.c: 469: }
;charge_mgr.c: 471: {
;charge_mgr.c: 472: unsigned int newv = Adc_Norm(s_adcChannels[idx]);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low((((_s_adcChannels)-__stringbase)|8000h))
	movwf	fsr0
	fcall	stringdir
	fcall	_Adc_Norm
	movf	(1+(?_Adc_Norm)),w
	movwf	(Slot_Charge_Ctrl@newv+1)
	movf	(0+(?_Adc_Norm)),w
	movwf	(Slot_Charge_Ctrl@newv)
	line	476
	
l4787:	
;charge_mgr.c: 474: if(!(s_work.type == 6 &&
;charge_mgr.c: 475: (s_work.state == 4 || s_work.state == 5) &&
;charge_mgr.c: 476: newv >= 3990))
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u7341
	goto	u7340
u7341:
	goto	l4795
u7340:
	
l4789:	
		movlw	4
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u7351
	goto	u7350
u7351:
	goto	l4793
u7350:
	
l4791:	
		movlw	5
	xorwf	((_s_work)),w
	btfss	status,2
	goto	u7361
	goto	u7360
u7361:
	goto	l4795
u7360:
	
l4793:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@newv+1),w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@newv),w
	skipnc
	goto	u7371
	goto	u7370
u7371:
	goto	l5505
u7370:
	line	478
	
l4795:	
;charge_mgr.c: 477: {
;charge_mgr.c: 478: s_work.voltage = newv;
	movf	(Slot_Charge_Ctrl@newv+1),w
	movwf	1+(_s_work)+02h
	movf	(Slot_Charge_Ctrl@newv),w
	movwf	0+(_s_work)+02h
	goto	l5505
	line	487
	
l4797:	
;charge_mgr.c: 487: if(s_work.voltage >= 3990)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u7381
	goto	u7380
u7381:
	goto	l4803
u7380:
	line	489
	
l4799:	
;charge_mgr.c: 488: {
;charge_mgr.c: 489: if(s_work.chargeTimer < (2400))
	movlw	09h
	subwf	1+(_s_work)+04h,w
	movlw	060h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipnc
	goto	u7391
	goto	u7390
u7391:
	goto	l4803
u7390:
	goto	l5507
	line	497
	
l4803:	
;charge_mgr.c: 491: }
;charge_mgr.c: 496: if((g_detectOwner != 0xFF && g_detectOwner != idx) ||
;charge_mgr.c: 497: (g_detectWaiter != 0xFF && g_detectWaiter != idx))
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectOwner)^080h),w
	btfsc	status,2
	goto	u7401
	goto	u7400
u7401:
	goto	l4807
u7400:
	
l4805:	
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u7411
	goto	u7410
u7411:
	goto	l5507
u7410:
	
l4807:	
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectWaiter)^080h),w
	btfsc	status,2
	goto	u7421
	goto	u7420
u7421:
	goto	l4811
u7420:
	
l4809:	
	movf	(_g_detectWaiter)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipnz
	goto	u7431
	goto	u7430
u7431:
	goto	l4811
u7430:
	goto	l5507
	line	500
	
l4811:	
;charge_mgr.c: 500: s_work.chargeTimer = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	501
	
l4813:	
;charge_mgr.c: 501: s_work.state = 1;
	clrf	(_s_work)
	incf	(_s_work),f
	line	502
	
l4815:	
;charge_mgr.c: 502: g_ccBlocks[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	503
	
l4817:	
;charge_mgr.c: 503: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7444
u7445:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7444:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7445
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	506
	
l4819:	
;charge_mgr.c: 506: if(s_work.voltage < 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u7451
	goto	u7450
u7451:
	goto	l4823
u7450:
	line	507
	
l4821:	
;charge_mgr.c: 507: g_slotRefV[idx] = s_work.voltage;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	0+(_s_work)+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)+02h,w
	movwf	indf
	goto	l5507
	line	509
	
l4823:	
;charge_mgr.c: 508: else
;charge_mgr.c: 509: g_slotRefV[idx] = 0;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l5507
	line	516
	
l4825:	
;charge_mgr.c: 516: if(charge_ticks_prev < 1U && s_work.chargeTimer >= 1U)
	movf	((Slot_Charge_Ctrl@charge_ticks_prev)),w
iorwf	((Slot_Charge_Ctrl@charge_ticks_prev+1)),w
	btfss	status,2
	goto	u7461
	goto	u7460
u7461:
	goto	l4833
u7460:
	
l4827:	
	movf	(0+(_s_work)+04h),w
iorwf	(1+(_s_work)+04h),w
	btfsc	status,2
	goto	u7471
	goto	u7470
u7471:
	goto	l4833
u7470:
	line	518
	
l4829:	
;charge_mgr.c: 517: {
;charge_mgr.c: 518: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	519
	
l4831:	
;charge_mgr.c: 519: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7484
u7485:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7484:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7485
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	522
	
l4833:	
;charge_mgr.c: 520: }
;charge_mgr.c: 522: if(s_work.chargeTimer < (240))
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(_s_work)+04h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipnc
	goto	u7491
	goto	u7490
u7491:
	goto	l4837
u7490:
	goto	l5507
	line	537
	
l4837:	
;charge_mgr.c: 529: }
;charge_mgr.c: 537: if(charge_ticks_prev < (240) && s_work.chargeTimer >= (240))
	movlw	0
	subwf	(Slot_Charge_Ctrl@charge_ticks_prev+1),w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@charge_ticks_prev),w
	skipnc
	goto	u7501
	goto	u7500
u7501:
	goto	l4847
u7500:
	
l4839:	
	movlw	0
	subwf	1+(_s_work)+04h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u7511
	goto	u7510
u7511:
	goto	l4847
u7510:
	line	539
	
l4841:	
;charge_mgr.c: 538: {
;charge_mgr.c: 539: g_slotRefV[idx] = s_work.voltage;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	0+(_s_work)+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)+02h,w
	movwf	indf
	line	540
	
l4843:	
;charge_mgr.c: 540: if(s_work.voltage > 2900)
	movlw	0Bh
	subwf	1+(_s_work)+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u7521
	goto	u7520
u7521:
	goto	l5507
u7520:
	line	541
	
l4845:	
;charge_mgr.c: 541: g_capFlag |= (unsigned int)1 << idx;
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7534
u7535:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7534:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7535
	
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag+1)^080h,f
	goto	l5507
	line	544
	
l4847:	
;charge_mgr.c: 543: }
;charge_mgr.c: 544: if(s_work.voltage > 2900 && s_work.voltage < 3990)
	movlw	0Bh
	subwf	1+(_s_work)+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u7541
	goto	u7540
u7541:
	goto	l4909
u7540:
	
l4849:	
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u7551
	goto	u7550
u7551:
	goto	l4909
u7550:
	line	556
	
l4851:	
;charge_mgr.c: 545: {
;charge_mgr.c: 555: if(!(g_capFlag & ((unsigned int)1 << idx)) && s_work.type != 5 &&
;charge_mgr.c: 556: s_work.voltage <= 3500)
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7564
u7565:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7564:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7565
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfss	status,2
	goto	u7571
	goto	u7570
u7571:
	goto	l4865
u7570:
	
l4853:	
		movlw	5
	xorwf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u7581
	goto	u7580
u7581:
	goto	l4865
u7580:
	
l4855:	
	movlw	0Dh
	subwf	1+(_s_work)+02h,w
	movlw	0ADh
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u7591
	goto	u7590
u7591:
	goto	l4865
u7590:
	line	558
	
l4857:	
;charge_mgr.c: 557: {
;charge_mgr.c: 558: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	559
	
l4859:	
;charge_mgr.c: 559: g_slotRefV[idx] = 0;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	560
	
l4861:	
;charge_mgr.c: 560: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	561
	
l4863:	
;charge_mgr.c: 561: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	562
;charge_mgr.c: 562: break;
	goto	l5507
	line	572
	
l4865:	
;charge_mgr.c: 563: }
;charge_mgr.c: 572: unsigned int v_init = g_slotRefV[idx];
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_init)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_init+1)
	line	574
;charge_mgr.c: 574: if((g_stableCnt[idx]) >= 20)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u7601
	goto	u7600
u7601:
	goto	l4889
u7600:
	line	579
	
l4867:	
;charge_mgr.c: 575: {
;charge_mgr.c: 579: g_highVFlag |= (unsigned int)1 << idx;
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7614
u7615:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7614:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7615
	
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag+1)^080h,f
	line	581
	
l4869:	
;charge_mgr.c: 581: if(s_work.voltage <= 2900)
	movlw	0Bh
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(_s_work)+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u7621
	goto	u7620
u7621:
	goto	l4877
u7620:
	line	584
	
l4871:	
;charge_mgr.c: 582: {
;charge_mgr.c: 584: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7634
u7635:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7634:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7635
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	585
	
l4873:	
;charge_mgr.c: 585: (g_stableCnt[idx]) = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	586
	
l4875:	
;charge_mgr.c: 586: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7644
u7645:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7644:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7645
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	587
;charge_mgr.c: 587: }
	goto	l4921
	line	588
	
l4877:	
;charge_mgr.c: 588: else if(s_work.chargeTimer < (240) + (800))
	movlw	04h
	subwf	1+(_s_work)+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipnc
	goto	u7651
	goto	u7650
u7651:
	goto	l4887
u7650:
	line	595
	
l4879:	
;charge_mgr.c: 589: {
;charge_mgr.c: 595: if(s_work.chargeTimer >= (240) + 25U)
	movlw	01h
	subwf	1+(_s_work)+04h,w
	movlw	09h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u7661
	goto	u7660
u7661:
	goto	l4821
u7660:
	line	597
	
l4881:	
;charge_mgr.c: 596: {
;charge_mgr.c: 597: Detect_Classify(idx, 1);
	clrf	(Detect_Classify@fromHighV)
	incf	(Detect_Classify@fromHighV),f
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	598
;charge_mgr.c: 598: break;
	goto	l5507
	line	607
	
l4887:	
;charge_mgr.c: 604: else
;charge_mgr.c: 605: {
;charge_mgr.c: 607: Detect_Classify(idx, 1);
	clrf	(Detect_Classify@fromHighV)
	incf	(Detect_Classify@fromHighV),f
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	608
;charge_mgr.c: 608: break;
	goto	l5507
	line	616
	
l4889:	
;charge_mgr.c: 611: else
;charge_mgr.c: 612: {
;charge_mgr.c: 616: if(s_work.chargeTimer >= (240) + (800))
	movlw	04h
	subwf	1+(_s_work)+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u7671
	goto	u7670
u7671:
	goto	l4893
u7670:
	line	618
	
l4891:	
;charge_mgr.c: 617: {
;charge_mgr.c: 618: Detect_Classify(idx, 1);
	clrf	(Detect_Classify@fromHighV)
	incf	(Detect_Classify@fromHighV),f
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	619
;charge_mgr.c: 619: break;
	goto	l5507
	line	624
	
l4893:	
;charge_mgr.c: 620: }
;charge_mgr.c: 624: g_slotRefV[idx] = s_work.voltage;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	0+(_s_work)+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)+02h,w
	movwf	indf
	line	625
	
l4895:	
;charge_mgr.c: 625: if(s_work.voltage + 50 < v_init)
	movf	0+(_s_work)+02h,w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	1+(_s_work)+02h,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v_init+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u7685
	movf	(Slot_Charge_Ctrl@v_init),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u7685:
	skipnc
	goto	u7681
	goto	u7680
u7681:
	goto	l4899
u7680:
	line	626
	
l4897:	
;charge_mgr.c: 626: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l576
	line	628
	
l4899:	
;charge_mgr.c: 627: else
;charge_mgr.c: 628: (g_stableCnt[idx])++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	
l576:	
	line	629
;charge_mgr.c: 629: if((g_stableCnt[idx]) < 20)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u7691
	goto	u7690
u7691:
	goto	l4903
u7690:
	goto	l5507
	line	632
	
l4903:	
;charge_mgr.c: 632: if(g_capFlag & ((unsigned int)1 << idx))
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7704
u7705:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7704:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7705
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u7711
	goto	u7710
u7711:
	goto	l4907
u7710:
	goto	l5507
	line	634
	
l4907:	
;charge_mgr.c: 634: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l4921
	line	637
	
l4909:	
;charge_mgr.c: 637: else if(s_work.chargeTimer < (240) + (800) && s_work.voltage < 3990)
	movlw	04h
	subwf	1+(_s_work)+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipnc
	goto	u7721
	goto	u7720
u7721:
	goto	l4921
u7720:
	
l4911:	
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u7731
	goto	u7730
u7731:
	goto	l4921
u7730:
	line	639
	
l4913:	
;charge_mgr.c: 638: {
;charge_mgr.c: 639: unsigned int v_ref = g_slotRefV[idx];
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_ref)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_ref+1)
	line	640
	
l4915:	
;charge_mgr.c: 640: if(v_ref < 3990 && s_work.voltage + 50 < v_ref)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v_ref+1),w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v_ref),w
	skipnc
	goto	u7741
	goto	u7740
u7741:
	goto	l4921
u7740:
	
l4917:	
	movf	0+(_s_work)+02h,w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	1+(_s_work)+02h,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v_ref+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u7755
	movf	(Slot_Charge_Ctrl@v_ref),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u7755:
	skipnc
	goto	u7751
	goto	u7750
u7751:
	goto	l4921
u7750:
	goto	l4821
	line	650
	
l4921:	
;charge_mgr.c: 644: }
;charge_mgr.c: 645: }
;charge_mgr.c: 650: if(g_capFlag & ((unsigned int)1 << idx))
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7764
u7765:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7764:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7765
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u7771
	goto	u7770
u7771:
	goto	l4929
u7770:
	line	652
	
l4923:	
;charge_mgr.c: 651: {
;charge_mgr.c: 652: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7784
u7785:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7784:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7785
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	653
	
l4925:	
;charge_mgr.c: 653: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	654
	
l4927:	
;charge_mgr.c: 654: s_work.type = 5;
	movlw	low(05h)
	movwf	0+(_s_work)+01h
	line	655
;charge_mgr.c: 655: }
	goto	l583
	line	658
	
l4929:	
;charge_mgr.c: 656: else
;charge_mgr.c: 657: {
;charge_mgr.c: 658: s_work.type = Detect_BatteryType(s_work.voltage);
	movf	1+(_s_work)+02h,w
	movwf	(Detect_BatteryType@voltage+1)
	movf	0+(_s_work)+02h,w
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	movwf	0+(_s_work)+01h
	line	664
	
l4931:	
;charge_mgr.c: 663: if(s_work.type == 0 && s_work.voltage >= 3990 &&
;charge_mgr.c: 664: s_work.chargeTimer >= (240) + (800))
	movf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u7791
	goto	u7790
u7791:
	goto	l583
u7790:
	
l4933:	
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u7801
	goto	u7800
u7801:
	goto	l583
u7800:
	
l4935:	
	movlw	04h
	subwf	1+(_s_work)+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u7811
	goto	u7810
u7811:
	goto	l583
u7810:
	goto	l4927
	line	666
	
l583:	
	line	670
;charge_mgr.c: 666: }
;charge_mgr.c: 670: if(s_work.voltage < 500)
	movlw	01h
	subwf	1+(_s_work)+02h,w
	movlw	0F4h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u7821
	goto	u7820
u7821:
	goto	l4943
u7820:
	line	672
	
l4939:	
;charge_mgr.c: 671: {
;charge_mgr.c: 672: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	673
;charge_mgr.c: 673: if(g_detectLowCnt[idx] < 5)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u7831
	goto	u7830
u7831:
	goto	l4951
u7830:
	goto	l5507
	line	677
	
l4943:	
;charge_mgr.c: 677: else if(s_work.type != 5 && s_work.type != 1 && s_work.type != 6)
		movlw	5
	xorwf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u7841
	goto	u7840
u7841:
	goto	l4951
u7840:
	
l4945:	
		decf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u7851
	goto	u7850
u7851:
	goto	l4951
u7850:
	
l4947:	
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u7861
	goto	u7860
u7861:
	goto	l4951
u7860:
	line	679
	
l4949:	
;charge_mgr.c: 678: {
;charge_mgr.c: 679: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	686
	
l4951:	
;charge_mgr.c: 680: }
;charge_mgr.c: 686: Detect_Classify(idx, 0);
	clrf	(Detect_Classify@fromHighV)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	687
;charge_mgr.c: 687: break;
	goto	l5507
	line	692
	
l4953:	
;charge_mgr.c: 692: if(s_work.chargeTimer < 5)
	movlw	0
	subwf	1+(_s_work)+04h,w
	movlw	05h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipnc
	goto	u7871
	goto	u7870
u7871:
	goto	l4957
u7870:
	goto	l5507
	line	697
	
l4957:	
;charge_mgr.c: 695: {
;charge_mgr.c: 697: Get_Vcc();
	fcall	_Get_Vcc
	line	703
	
l4959:	
;charge_mgr.c: 703: if(s_work.voltage >= 4050U && ((g_impData) & 0x0FFFU) >= 4050U)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(_s_work)+02h,w
	movlw	0D2h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u7881
	goto	u7880
u7881:
	goto	l4969
u7880:
	
l4961:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0D2h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u7891
	goto	u7890
u7891:
	goto	l4969
u7890:
	line	705
	
l4963:	
;charge_mgr.c: 704: {
;charge_mgr.c: 705: s_work.type = 0;
	clrf	0+(_s_work)+01h
	line	706
;charge_mgr.c: 706: s_work.state = 0;
	clrf	(_s_work)
	line	707
	
l4965:	
;charge_mgr.c: 707: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	708
	
l4967:	
;charge_mgr.c: 708: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7904
u7905:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7904:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7905
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	709
;charge_mgr.c: 709: break;
	goto	l5507
	line	719
	
l4969:	
;charge_mgr.c: 710: }
;charge_mgr.c: 718: {
;charge_mgr.c: 719: unsigned int vcc_norm_pre = ((unsigned int)(((unsigned long)((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U)) * 4096UL) / 5000UL));
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(0+(?___wmul)),w
	movwf	((??_Slot_Charge_Ctrl+0)+0)
	movf	(1+(?___wmul)),w
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
	clrf	((??_Slot_Charge_Ctrl+0)+0+2)
	clrf	((??_Slot_Charge_Ctrl+0)+0+3)
	movlw	0Ch
u7915:
	clrc
	rlf	(??_Slot_Charge_Ctrl+0)+0,f
	rlf	(??_Slot_Charge_Ctrl+0)+1,f
	rlf	(??_Slot_Charge_Ctrl+0)+2,f
	rlf	(??_Slot_Charge_Ctrl+0)+3,f
u7910:
	addlw	-1
	skipz
	goto	u7915
	movf	3+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_pre+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_pre)
	line	720
;charge_mgr.c: 720: unsigned int vcc_norm_now = ((unsigned int)(((unsigned long)(g_vcc_mv) * 4096UL) / 5000UL));
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lldiv@dividend))+1
	clrf	2+((___lldiv@dividend))
	clrf	3+((___lldiv@dividend))
	movlw	0Ch
	movwf	(??_Slot_Charge_Ctrl+0)+0
u7925:
	clrc
	rlf	(___lldiv@dividend),f
	rlf	(___lldiv@dividend+1),f
	rlf	(___lldiv@dividend+2),f
	rlf	(___lldiv@dividend+3),f
	decfsz	(??_Slot_Charge_Ctrl+0)+0
	goto	u7925
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_now+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_now)
	line	722
	
l4971:	
;charge_mgr.c: 721: if((((g_impData) & 0x0FFFU) + 150 >= vcc_norm_pre) &&
;charge_mgr.c: 722: (s_work.voltage + 150 >= vcc_norm_now))
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	(Slot_Charge_Ctrl@vcc_norm_pre+1),w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u7935
	movf	(Slot_Charge_Ctrl@vcc_norm_pre),w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u7935:
	skipc
	goto	u7931
	goto	u7930
u7931:
	goto	l4981
u7930:
	
l4973:	
	movf	0+(_s_work)+02h,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	1+(_s_work)+02h,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@vcc_norm_now+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u7945
	movf	(Slot_Charge_Ctrl@vcc_norm_now),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u7945:
	skipc
	goto	u7941
	goto	u7940
u7941:
	goto	l4981
u7940:
	goto	l4963
	line	735
	
l4981:	
;charge_mgr.c: 729: }
;charge_mgr.c: 730: }
;charge_mgr.c: 735: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 300U && s_work.voltage >= 3990)
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	addlw	low(012Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w
	skipnc
	addlw	1
	addlw	high(012Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u7955
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u7955:
	skipnc
	goto	u7951
	goto	u7950
u7951:
	goto	l4989
u7950:
	
l4983:	
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u7961
	goto	u7960
u7961:
	goto	l4989
u7960:
	line	737
	
l4985:	
;charge_mgr.c: 736: {
;charge_mgr.c: 737: s_work.type = 2;
	movlw	low(02h)
	movwf	0+(_s_work)+01h
	line	738
;charge_mgr.c: 738: s_work.state = 7;
	movlw	low(07h)
	movwf	(_s_work)
	line	739
;charge_mgr.c: 739: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	goto	l4967
	line	749
	
l4989:	
;charge_mgr.c: 742: }
;charge_mgr.c: 748: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 200U &&
;charge_mgr.c: 749: ((g_impData) & 0x0FFFU) < 3100U)
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	addlw	low(0C8h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w
	skipnc
	addlw	1
	addlw	high(0C8h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u7975
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u7975:
	skipnc
	goto	u7971
	goto	u7970
u7971:
	goto	l4995
u7970:
	
l4991:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Ch
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	01Ch
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u7981
	goto	u7980
u7981:
	goto	l4995
u7980:
	line	751
	
l4993:	
;charge_mgr.c: 750: {
;charge_mgr.c: 751: s_work.state = Route_LiIon(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	movwf	(_s_work)
	line	752
;charge_mgr.c: 752: break;
	goto	l5507
	line	761
	
l4995:	
;charge_mgr.c: 753: }
;charge_mgr.c: 759: if(!(g_highVFlag & ((unsigned int)1 << idx)) &&
;charge_mgr.c: 760: (((g_impData) & 0x0FFFU) > s_work.voltage) &&
;charge_mgr.c: 761: (((g_impData) & 0x0FFFU) - s_work.voltage) > 1000U)
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7994
u7995:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7994:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7995
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfss	status,2
	goto	u8001
	goto	u8000
u8001:
	goto	l5007
u8000:
	
l4997:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u8015
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(_s_work)+02h,w
u8015:
	skipnc
	goto	u8011
	goto	u8010
u8011:
	goto	l5007
u8010:
	
l4999:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(_s_work)+02h,w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(_s_work)+02h,w
	skipc
	incf	1+(_s_work)+02h,w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	03h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0E9h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipc
	goto	u8021
	goto	u8020
u8021:
	goto	l5007
u8020:
	line	763
	
l5001:	
;charge_mgr.c: 762: {
;charge_mgr.c: 763: s_work.type = 3;
	movlw	low(03h)
	movwf	0+(_s_work)+01h
	line	764
;charge_mgr.c: 764: s_work.state = 7;
	movlw	low(07h)
	movwf	(_s_work)
	line	765
;charge_mgr.c: 765: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	766
	
l5003:	
;charge_mgr.c: 766: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8034
u8035:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8034:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8035
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	goto	l4863
	line	775
	
l5007:	
;charge_mgr.c: 769: }
;charge_mgr.c: 774: if((((g_impData) & 0x0FFFU) > 3500) &&
;charge_mgr.c: 775: ((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) <= g_vcc_mv + 200U))
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Dh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0ADh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u8041
	goto	u8040
u8041:
	goto	l5013
u8040:
	
l5009:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	addlw	low(0C8h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w
	skipnc
	addlw	1
	addlw	high(0C8h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8055
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8055:
	skipc
	goto	u8051
	goto	u8050
u8051:
	goto	l5013
u8050:
	line	777
	
l5011:	
;charge_mgr.c: 776: {
;charge_mgr.c: 777: Enter_DiodeTest(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Enter_DiodeTest
	line	778
;charge_mgr.c: 778: break;
	goto	l5507
	line	786
	
l5013:	
;charge_mgr.c: 779: }
;charge_mgr.c: 786: Enter_DiodeTest(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Enter_DiodeTest
	line	788
;charge_mgr.c: 787: }
;charge_mgr.c: 788: break;
	goto	l5507
	line	804
	
l5015:	
;charge_mgr.c: 803: {
;charge_mgr.c: 804: unsigned char pt = (unsigned char)(g_diodeTraceCnt + 1U);
	movf	(_g_diodeTraceCnt)^080h,w
	addlw	01h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@pt)
	line	805
	
l5017:	
;charge_mgr.c: 805: unsigned int ptTick = (unsigned int)pt * 7U;
	movf	(Slot_Charge_Ctrl@pt),w
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	07h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(1+(?___wmul)),w
	movwf	(Slot_Charge_Ctrl@ptTick+1)
	movf	(0+(?___wmul)),w
	movwf	(Slot_Charge_Ctrl@ptTick)
	line	806
	
l5019:	
;charge_mgr.c: 806: if(s_work.chargeTimer < ptTick)
	movf	(Slot_Charge_Ctrl@ptTick+1),w
	subwf	1+(_s_work)+04h,w
	skipz
	goto	u8065
	movf	(Slot_Charge_Ctrl@ptTick),w
	subwf	0+(_s_work)+04h,w
u8065:
	skipnc
	goto	u8061
	goto	u8060
u8061:
	goto	l5023
u8060:
	goto	l5039
	line	809
	
l5023:	
;charge_mgr.c: 808: {
;charge_mgr.c: 809: signed int diff = (signed int)s_work.voltage - (signed int)((g_impData) & 0x0FFFU);
	movf	1+(_s_work)+02h,w
	movwf	(Slot_Charge_Ctrl@diff+1)
	movf	0+(_s_work)+02h,w
	movwf	(Slot_Charge_Ctrl@diff)
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	(Slot_Charge_Ctrl@diff),f
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	decf	(Slot_Charge_Ctrl@diff+1),f
	subwf	(Slot_Charge_Ctrl@diff+1),f
	line	810
;charge_mgr.c: 810: diff >>= 2;
	rlf	(Slot_Charge_Ctrl@diff+1),w
	rrf	(Slot_Charge_Ctrl@diff+1),f
	rrf	(Slot_Charge_Ctrl@diff),f
	rlf	(Slot_Charge_Ctrl@diff+1),w
	rrf	(Slot_Charge_Ctrl@diff+1),f
	rrf	(Slot_Charge_Ctrl@diff),f
	line	811
	
l5025:	
;charge_mgr.c: 811: if(diff > 127) diff = 127;
	movf	(Slot_Charge_Ctrl@diff+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u8075
	movlw	080h
	subwf	(Slot_Charge_Ctrl@diff),w
u8075:

	skipc
	goto	u8071
	goto	u8070
u8071:
	goto	l5029
u8070:
	
l5027:	
	movlw	07Fh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff)
	clrf	(Slot_Charge_Ctrl@diff+1)
	line	812
	
l5029:	
;charge_mgr.c: 812: if(diff < -128) diff = -128;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@diff+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u8085
	movlw	080h
	subwf	(Slot_Charge_Ctrl@diff),w
u8085:

	skipnc
	goto	u8081
	goto	u8080
u8081:
	goto	l5033
u8080:
	
l5031:	
	movlw	080h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff)
	movlw	0FFh
	movwf	((Slot_Charge_Ctrl@diff))+1
	line	813
	
l5033:	
;charge_mgr.c: 813: g_diodeTrace[g_diodeTraceCnt++] = (unsigned char)(diff + 128);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_diodeTraceCnt)^080h,w
	addlw	low(_g_diodeTrace|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@diff),w
	addlw	080h
	bcf	status, 7	;select IRP bank1
	movwf	indf
	
l5035:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_diodeTraceCnt)^080h,f
	line	802
	
l5037:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_diodeTraceCnt)^080h,w
	skipc
	goto	u8091
	goto	u8090
u8091:
	goto	l5015
u8090:
	line	826
	
l5039:	
;charge_mgr.c: 814: }
;charge_mgr.c: 815: }
;charge_mgr.c: 816: {
;charge_mgr.c: 825: if(((g_impData) & 0x0FFFU) >= 2100 &&
;charge_mgr.c: 826: s_work.voltage > ((g_impData) & 0x0FFFU) + 900)
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	034h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u8101
	goto	u8100
u8101:
	goto	l5049
u8100:
	
l5041:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(0384h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(0384h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(_s_work)+02h,w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u8115
	movf	0+(_s_work)+02h,w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u8115:
	skipnc
	goto	u8111
	goto	u8110
u8111:
	goto	l5049
u8110:
	line	830
	
l5043:	
;charge_mgr.c: 827: {
;charge_mgr.c: 830: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150U)
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8125
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8125:
	skipnc
	goto	u8121
	goto	u8120
u8121:
	goto	l5047
u8120:
	line	831
	
l5045:	
;charge_mgr.c: 831: s_work.state = Route_LiIon(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	movwf	(_s_work)
	goto	l5507
	line	833
	
l5047:	
;charge_mgr.c: 832: else
;charge_mgr.c: 833: s_work.state = Route_LinearLi(idx, (unsigned int)((g_impData) & 0x0FFFU));
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(Route_LinearLi@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	movwf	(_s_work)
	goto	l5507
	line	845
	
l5049:	
;charge_mgr.c: 835: }
;charge_mgr.c: 843: if((((g_impData) & 0x0FFFU) > 3000U) &&
;charge_mgr.c: 844: (s_work.voltage > 2900) &&
;charge_mgr.c: 845: (s_work.voltage < ((g_impData) & 0x0FFFU)))
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Bh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0B9h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u8131
	goto	u8130
u8131:
	goto	l5057
u8130:
	
l5051:	
	movlw	0Bh
	subwf	1+(_s_work)+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8141
	goto	u8140
u8141:
	goto	l5057
u8140:
	
l5053:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u8155
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(_s_work)+02h,w
u8155:
	skipnc
	goto	u8151
	goto	u8150
u8151:
	goto	l5057
u8150:
	line	847
	
l5055:	
;charge_mgr.c: 846: {
;charge_mgr.c: 847: s_work.state = Route_LinearLi(idx, (unsigned int)((g_impData) & 0x0FFFU));
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(Route_LinearLi@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	movwf	(_s_work)
	line	848
;charge_mgr.c: 848: break;
	goto	l5507
	line	858
	
l5057:	
;charge_mgr.c: 849: }
;charge_mgr.c: 857: if((s_work.voltage > 2900) &&
;charge_mgr.c: 858: (((g_impData) & 0x0FFFU) < 2100))
	movlw	0Bh
	subwf	1+(_s_work)+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8161
	goto	u8160
u8161:
	goto	l5067
u8160:
	
l5059:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	034h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u8171
	goto	u8170
u8171:
	goto	l5067
u8170:
	goto	l5001
	line	879
	
l5067:	
;charge_mgr.c: 866: }
;charge_mgr.c: 876: if(s_work.chargeTimer >= 20U && s_work.voltage > 2100U &&
;charge_mgr.c: 877: ((g_impData) & 0x0FFFU) <= 2300U &&
;charge_mgr.c: 878: s_work.voltage + 160U >= ((g_impData) & 0x0FFFU) &&
;charge_mgr.c: 879: s_work.voltage <= ((g_impData) & 0x0FFFU) + 150)
	movlw	0
	subwf	1+(_s_work)+04h,w
	movlw	014h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u8181
	goto	u8180
u8181:
	goto	l5079
u8180:
	
l5069:	
	movlw	08h
	subwf	1+(_s_work)+02h,w
	movlw	035h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8191
	goto	u8190
u8191:
	goto	l5079
u8190:
	
l5071:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u8201
	goto	u8200
u8201:
	goto	l5079
u8200:
	
l5073:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(_s_work)+02h,w
	addlw	low(0A0h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(_s_work)+02h,w
	skipnc
	addlw	1
	addlw	high(0A0h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u8215
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u8215:
	skipc
	goto	u8211
	goto	u8210
u8211:
	goto	l5079
u8210:
	
l5075:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(_s_work)+02h,w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u8225
	movf	0+(_s_work)+02h,w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u8225:
	skipc
	goto	u8221
	goto	u8220
u8221:
	goto	l5079
u8220:
	line	881
	
l5077:	
;charge_mgr.c: 880: {
;charge_mgr.c: 881: s_work.state = Route_LinearLi(idx, (unsigned int)((g_impData) & 0x0FFFU));
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(Route_LinearLi@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	movwf	(_s_work)
	line	882
;charge_mgr.c: 882: break;
	goto	l5507
	line	890
	
l5079:	
;charge_mgr.c: 883: }
;charge_mgr.c: 890: if(s_work.chargeTimer >= 240)
	movlw	0
	subwf	1+(_s_work)+04h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u8231
	goto	u8230
u8231:
	goto	l5507
u8230:
	line	892
	
l5081:	
;charge_mgr.c: 891: {
;charge_mgr.c: 892: unsigned int pre = (unsigned int)((g_impData) & 0x0FFFU);
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(Slot_Charge_Ctrl@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Slot_Charge_Ctrl@pre)
	line	901
	
l5083:	
;charge_mgr.c: 900: {
;charge_mgr.c: 901: unsigned int vcc_norm = ((unsigned int)(((unsigned long)(g_vcc_mv) * 4096UL) / 5000UL));
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lldiv@dividend))+1
	clrf	2+((___lldiv@dividend))
	clrf	3+((___lldiv@dividend))
	movlw	0Ch
	movwf	(??_Slot_Charge_Ctrl+0)+0
u8245:
	clrc
	rlf	(___lldiv@dividend),f
	rlf	(___lldiv@dividend+1),f
	rlf	(___lldiv@dividend+2),f
	rlf	(___lldiv@dividend+3),f
	decfsz	(??_Slot_Charge_Ctrl+0)+0
	goto	u8245
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm)
	line	902
	
l5085:	
;charge_mgr.c: 902: if(s_work.voltage + 150 >= vcc_norm)
	movf	0+(_s_work)+02h,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	1+(_s_work)+02h,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@vcc_norm+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8255
	movf	(Slot_Charge_Ctrl@vcc_norm),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8255:
	skipc
	goto	u8251
	goto	u8250
u8251:
	goto	l5093
u8250:
	line	904
	
l5087:	
;charge_mgr.c: 903: {
;charge_mgr.c: 904: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150U)
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8265
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8265:
	skipnc
	goto	u8261
	goto	u8260
u8261:
	goto	l5091
u8260:
	line	905
	
l5089:	
;charge_mgr.c: 905: s_work.state = Route_LiIon(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	movwf	(_s_work)
	goto	l5507
	line	907
	
l5091:	
;charge_mgr.c: 906: else
;charge_mgr.c: 907: s_work.state = Route_LinearLi(idx, pre);
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	movwf	(_s_work)
	goto	l5507
	line	918
	
l5093:	
;charge_mgr.c: 909: }
;charge_mgr.c: 910: }
;charge_mgr.c: 917: if(pre > 3500 && pre < 3990 &&
;charge_mgr.c: 918: s_work.voltage >= pre + 50)
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0ADh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipc
	goto	u8271
	goto	u8270
u8271:
	goto	l5105
u8270:
	
l5095:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u8281
	goto	u8280
u8281:
	goto	l5105
u8280:
	
l5097:	
	movf	(Slot_Charge_Ctrl@pre),w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u8295
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(_s_work)+02h,w
u8295:
	skipc
	goto	u8291
	goto	u8290
u8291:
	goto	l5105
u8290:
	line	920
	
l5099:	
;charge_mgr.c: 919: {
;charge_mgr.c: 920: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150U)
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8305
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8305:
	skipnc
	goto	u8301
	goto	u8300
u8301:
	goto	l5103
u8300:
	line	921
	
l5101:	
;charge_mgr.c: 921: s_work.state = Route_LiIon(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	movwf	(_s_work)
	goto	l5507
	line	923
	
l5103:	
;charge_mgr.c: 922: else
;charge_mgr.c: 923: s_work.state = Route_LinearLi(idx, pre);
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	movwf	(_s_work)
	goto	l5507
	line	944
	
l5105:	
;charge_mgr.c: 925: }
;charge_mgr.c: 941: if(s_work.voltage > 2600 && s_work.voltage < 3990 &&
;charge_mgr.c: 942: pre >= 2100 && pre < 3500U &&
;charge_mgr.c: 943: ((pre < 3000 && s_work.voltage + 150U >= pre) ||
;charge_mgr.c: 944: s_work.voltage >= pre + 50))
	movlw	0Ah
	subwf	1+(_s_work)+02h,w
	movlw	029h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8311
	goto	u8310
u8311:
	goto	l5121
u8310:
	
l5107:	
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u8321
	goto	u8320
u8321:
	goto	l5121
u8320:
	
l5109:	
	movlw	08h
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	034h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipc
	goto	u8331
	goto	u8330
u8331:
	goto	l5121
u8330:
	
l5111:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0ACh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u8341
	goto	u8340
u8341:
	goto	l5121
u8340:
	
l5113:	
	movlw	0Bh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0B8h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u8351
	goto	u8350
u8351:
	goto	l5117
u8350:
	
l5115:	
	movf	0+(_s_work)+02h,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	1+(_s_work)+02h,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8365
	movf	(Slot_Charge_Ctrl@pre),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8365:
	skipnc
	goto	u8361
	goto	u8360
u8361:
	goto	l5119
u8360:
	
l5117:	
	movf	(Slot_Charge_Ctrl@pre),w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u8375
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(_s_work)+02h,w
u8375:
	skipc
	goto	u8371
	goto	u8370
u8371:
	goto	l5121
u8370:
	line	946
	
l5119:	
;charge_mgr.c: 945: {
;charge_mgr.c: 946: s_work.state = Route_LinearLi(idx, pre);
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	movwf	(_s_work)
	line	947
;charge_mgr.c: 947: break;
	goto	l5507
	line	955
	
l5121:	
;charge_mgr.c: 948: }
;charge_mgr.c: 954: if(s_work.voltage > pre + 150 && s_work.voltage < 3990 &&
;charge_mgr.c: 955: pre > 1936 && pre < 3500U)
	movf	(Slot_Charge_Ctrl@pre),w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(_s_work)+02h,w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8385
	movf	0+(_s_work)+02h,w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8385:
	skipnc
	goto	u8381
	goto	u8380
u8381:
	goto	l5001
u8380:
	
l5123:	
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u8391
	goto	u8390
u8391:
	goto	l5001
u8390:
	
l5125:	
	movlw	07h
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	091h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipc
	goto	u8401
	goto	u8400
u8401:
	goto	l5001
u8400:
	
l5127:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0ACh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u8411
	goto	u8410
u8411:
	goto	l5001
u8410:
	line	957
	
l5129:	
;charge_mgr.c: 956: {
;charge_mgr.c: 957: s_work.state = Route_LinearLi(idx, pre);
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	movwf	(_s_work)
	line	958
;charge_mgr.c: 958: break;
	goto	l5507
	line	971
	
l5137:	
;charge_mgr.c: 971: if(s_work.chargeTimer > (60 * 100))
	movlw	017h
	subwf	1+(_s_work)+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u8421
	goto	u8420
u8421:
	goto	l5141
u8420:
	line	973
	
l5139:	
;charge_mgr.c: 972: {
;charge_mgr.c: 973: s_work.state = 7;
	movlw	low(07h)
	movwf	(_s_work)
	line	974
;charge_mgr.c: 974: break;
	goto	l5507
	line	976
	
l5141:	
;charge_mgr.c: 975: }
;charge_mgr.c: 976: if(s_work.voltage > 750)
	movlw	02h
	subwf	1+(_s_work)+02h,w
	movlw	0EFh
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8431
	goto	u8430
u8431:
	goto	l5147
u8430:
	line	978
	
l5143:	
;charge_mgr.c: 977: {
;charge_mgr.c: 978: s_work.state = 3;
	movlw	low(03h)
	movwf	(_s_work)
	line	979
	
l5145:	
;charge_mgr.c: 979: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	980
;charge_mgr.c: 980: break;
	goto	l5507
	line	982
	
l5147:	
;charge_mgr.c: 981: }
;charge_mgr.c: 982: if(s_work.voltage >= 3850)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8441
	goto	u8440
u8441:
	goto	l5507
u8440:
	goto	l5139
	line	991
	
l5151:	
;charge_mgr.c: 991: if(s_work.chargeTimer > (300 * 100))
	movlw	075h
	subwf	1+(_s_work)+04h,w
	movlw	031h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u8451
	goto	u8450
u8451:
	goto	l5155
u8450:
	goto	l5139
	line	996
	
l5155:	
;charge_mgr.c: 995: }
;charge_mgr.c: 996: if(s_work.voltage >= 3850)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8461
	goto	u8460
u8461:
	goto	l5161
u8460:
	line	998
	
l5157:	
;charge_mgr.c: 997: {
;charge_mgr.c: 998: g_ovCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	999
;charge_mgr.c: 999: if(g_ovCnt[idx] >= 5)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u8471
	goto	u8470
u8471:
	goto	l5163
u8470:
	goto	l5139
	line	1007
	
l5161:	
;charge_mgr.c: 1005: else
;charge_mgr.c: 1006: {
;charge_mgr.c: 1007: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	1009
	
l5163:	
;charge_mgr.c: 1008: }
;charge_mgr.c: 1009: if(s_work.voltage >= 2700)
	movlw	0Ah
	subwf	1+(_s_work)+02h,w
	movlw	08Ch
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8481
	goto	u8480
u8481:
	goto	l5507
u8480:
	line	1011
	
l5165:	
;charge_mgr.c: 1010: {
;charge_mgr.c: 1011: s_work.state = 4;
	movlw	low(04h)
	movwf	(_s_work)
	line	1012
	
l5167:	
;charge_mgr.c: 1012: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	1013
	
l5169:	
;charge_mgr.c: 1013: g_ccBlocks[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1014
	
l5171:	
;charge_mgr.c: 1014: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1015
	
l5173:	
;charge_mgr.c: 1015: g_slotRefV[idx] = s_work.voltage;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	0+(_s_work)+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)+02h,w
	movwf	indf
	line	1016
	
l5175:	
;charge_mgr.c: 1016: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l5507
	line	1022
	
l5177:	
;charge_mgr.c: 1022: if(s_work.chargeTimer >= (600 * 100))
	movlw	0EAh
	subwf	1+(_s_work)+04h,w
	movlw	060h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u8491
	goto	u8490
u8491:
	goto	l5183
u8490:
	line	1024
	
l5179:	
;charge_mgr.c: 1023: {
;charge_mgr.c: 1024: s_work.chargeTimer -= (600 * 100);
	movlw	060h
	subwf	0+(_s_work)+04h,f
	movlw	0EAh
	skipc
	decf	1+(_s_work)+04h,f
	subwf	1+(_s_work)+04h,f
	line	1025
	
l5181:	
;charge_mgr.c: 1025: (g_ccBlocks[idx]++);
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1030
	
l5183:	
;charge_mgr.c: 1026: }
;charge_mgr.c: 1030: if(((g_ccBlocks[idx]) & 0x7FU) >= 18)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(07Fh)
	bsf	status, 7	;select IRP bank3
	andwf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	low(012h)
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u8501
	goto	u8500
u8501:
	goto	l5187
u8500:
	goto	l5139
	line	1039
	
l5187:	
;charge_mgr.c: 1034: }
;charge_mgr.c: 1039: if(s_work.voltage >= 3990 && s_work.type == 6)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8511
	goto	u8510
u8511:
	goto	l5193
u8510:
	
l5189:	
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u8521
	goto	u8520
u8521:
	goto	l5193
u8520:
	goto	l5201
	line	1043
	
l5193:	
;charge_mgr.c: 1043: else if(s_work.chargeTimer <= (6000))
	movlw	017h
	subwf	1+(_s_work)+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipnc
	goto	u8531
	goto	u8530
u8531:
	goto	l5197
u8530:
	goto	l5201
	line	1051
	
l5197:	
;charge_mgr.c: 1049: else
;charge_mgr.c: 1050: {
;charge_mgr.c: 1051: if(s_work.voltage > g_slotRefV[idx]) g_slotRefV[idx] = s_work.voltage;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(_s_work)+02h,w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8545
	movf	0+(_s_work)+02h,w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8545:
	skipnc
	goto	u8541
	goto	u8540
u8541:
	goto	l5201
u8540:
	
l5199:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	0+(_s_work)+02h,w
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)+02h,w
	movwf	indf
	line	1058
	
l5201:	
;charge_mgr.c: 1052: }
;charge_mgr.c: 1058: if(s_work.type == 6)
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u8551
	goto	u8550
u8551:
	goto	l5247
u8550:
	line	1060
	
l5203:	
;charge_mgr.c: 1059: {
;charge_mgr.c: 1060: if(s_work.voltage < 2000U)
	movlw	07h
	subwf	1+(_s_work)+02h,w
	movlw	0D0h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u8561
	goto	u8560
u8561:
	goto	l5213
u8560:
	line	1062
	
l5205:	
;charge_mgr.c: 1061: {
;charge_mgr.c: 1062: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1063
;charge_mgr.c: 1063: if(g_detectLowCnt[idx] >= 33U)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u8571
	goto	u8570
u8571:
	goto	l5215
u8570:
	line	1065
	
l5207:	
;charge_mgr.c: 1064: {
;charge_mgr.c: 1065: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1066
	
l5209:	
;charge_mgr.c: 1066: s_work.state = 7;
	movlw	low(07h)
	movwf	(_s_work)
	goto	l5145
	line	1073
	
l5213:	
;charge_mgr.c: 1071: else
;charge_mgr.c: 1072: {
;charge_mgr.c: 1073: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	1083
	
l5215:	
;charge_mgr.c: 1074: }
;charge_mgr.c: 1083: if(s_work.chargeTimer >= 1600)
	movlw	06h
	subwf	1+(_s_work)+04h,w
	movlw	040h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u8581
	goto	u8580
u8581:
	goto	l5281
u8580:
	line	1085
	
l5217:	
;charge_mgr.c: 1084: {
;charge_mgr.c: 1085: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	1086
	
l5219:	
;charge_mgr.c: 1086: if(s_work.voltage >= 2800U && s_work.voltage < 3990)
	movlw	0Ah
	subwf	1+(_s_work)+02h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8591
	goto	u8590
u8591:
	goto	l5231
u8590:
	
l5221:	
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u8601
	goto	u8600
u8601:
	goto	l5231
u8600:
	line	1088
	
l5223:	
;charge_mgr.c: 1087: {
;charge_mgr.c: 1088: s_work.state = 5;
	movlw	low(05h)
	movwf	(_s_work)
	line	1089
	
l5225:	
;charge_mgr.c: 1089: g_ccBlocks[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l5173
	line	1093
	
l5231:	
;charge_mgr.c: 1093: else if(s_work.voltage >= g_slotRefV[idx] + (30))
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u8615
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	0+(_s_work)+02h,w
u8615:
	skipc
	goto	u8611
	goto	u8610
u8611:
	goto	l5235
u8610:
	line	1095
	
l5233:	
;charge_mgr.c: 1094: {
;charge_mgr.c: 1095: (g_stableCnt[idx]) = 1;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	indf,f
	line	1096
;charge_mgr.c: 1096: g_slotRefV[idx] = s_work.voltage;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	0+(_s_work)+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)+02h,w
	movwf	indf
	line	1097
;charge_mgr.c: 1097: }
	goto	l5507
	line	1098
	
l5235:	
;charge_mgr.c: 1098: else if((g_stableCnt[idx]) != 0)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfsc	status,2
	goto	u8621
	goto	u8620
u8621:
	goto	l5239
u8620:
	goto	l4821
	line	1102
	
l5239:	
;charge_mgr.c: 1102: else if(((g_ccBlocks[idx]) & 0x80))
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	btfss	indf,(7)&7
	goto	u8631
	goto	u8630
u8631:
	goto	l5243
u8630:
	goto	l5139
	line	1108
	
l5243:	
;charge_mgr.c: 1106: else
;charge_mgr.c: 1107: {
;charge_mgr.c: 1108: (g_ccBlocks[idx] |= 0x80);
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(7/8),(7)&7
	line	1109
	
l5245:	
;charge_mgr.c: 1109: s_work.state = 1;
	clrf	(_s_work)
	incf	(_s_work),f
	line	1110
;charge_mgr.c: 1110: g_slotRefV[idx] = 0;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	1111
;charge_mgr.c: 1111: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l5507
	line	1120
	
l5247:	
;charge_mgr.c: 1116: else
;charge_mgr.c: 1117: {
;charge_mgr.c: 1120: if((s_work.voltage < g_slotRefV[idx] && g_slotRefV[idx] - s_work.voltage > 500) || s_work.voltage < 2000U)
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u8645
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(_s_work)+02h,w
u8645:
	skipnc
	goto	u8641
	goto	u8640
u8641:
	goto	l5251
u8640:
	
l5249:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(_s_work)+02h,w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(_s_work)+02h,w
	skipc
	incf	1+(_s_work)+02h,w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	01h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipnc
	goto	u8651
	goto	u8650
u8651:
	goto	l5253
u8650:
	
l5251:	
	movlw	07h
	subwf	1+(_s_work)+02h,w
	movlw	0D0h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u8661
	goto	u8660
u8661:
	goto	l5265
u8660:
	line	1122
	
l5253:	
;charge_mgr.c: 1121: {
;charge_mgr.c: 1122: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	1123
;charge_mgr.c: 1123: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8671
	goto	u8670
u8671:
	goto	l5257
u8670:
	goto	l5507
	line	1125
	
l5257:	
;charge_mgr.c: 1125: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1126
	
l5259:	
;charge_mgr.c: 1126: s_work.state = 1;
	clrf	(_s_work)
	incf	(_s_work),f
	goto	l5145
	line	1132
	
l5265:	
;charge_mgr.c: 1130: else
;charge_mgr.c: 1131: {
;charge_mgr.c: 1132: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1140
	
l5267:	
;charge_mgr.c: 1133: }
;charge_mgr.c: 1140: if(s_work.chargeTimer <= (6000))
	movlw	017h
	subwf	1+(_s_work)+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipnc
	goto	u8681
	goto	u8680
u8681:
	goto	l5273
u8680:
	line	1142
	
l5269:	
;charge_mgr.c: 1141: {
;charge_mgr.c: 1142: if(s_work.voltage >= g_slotRefV[idx] + (30))
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u8695
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	0+(_s_work)+02h,w
u8695:
	skipc
	goto	u8691
	goto	u8690
u8691:
	goto	l5273
u8690:
	line	1143
	
l5271:	
;charge_mgr.c: 1143: (g_stableCnt[idx]) = 1;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	indf,f
	line	1145
	
l5273:	
;charge_mgr.c: 1144: }
;charge_mgr.c: 1145: if(s_work.chargeTimer > (6000) && (g_stableCnt[idx]) == 0)
	movlw	017h
	subwf	1+(_s_work)+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u8701
	goto	u8700
u8701:
	goto	l5281
u8700:
	
l5275:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfss	status,2
	goto	u8711
	goto	u8710
u8711:
	goto	l5281
u8710:
	goto	l5209
	line	1159
	
l5281:	
;charge_mgr.c: 1150: }
;charge_mgr.c: 1151: }
;charge_mgr.c: 1159: if(s_work.voltage >= 3990 && s_work.type == 1)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8721
	goto	u8720
u8721:
	goto	l5289
u8720:
	
l5283:	
		decf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u8731
	goto	u8730
u8731:
	goto	l5289
u8730:
	line	1161
	
l5285:	
;charge_mgr.c: 1160: {
;charge_mgr.c: 1161: s_work.state = 6;
	movlw	low(06h)
	movwf	(_s_work)
	goto	l5145
	line	1169
	
l5289:	
;charge_mgr.c: 1164: }
;charge_mgr.c: 1169: if(s_work.voltage >= 3850 && s_work.type != 6)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8741
	goto	u8740
u8741:
	goto	l5297
u8740:
	
l5291:	
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u8751
	goto	u8750
u8751:
	goto	l5297
u8750:
	line	1171
	
l5293:	
;charge_mgr.c: 1170: {
;charge_mgr.c: 1171: g_ovCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1172
;charge_mgr.c: 1172: if(g_ovCnt[idx] >= 5)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u8761
	goto	u8760
u8761:
	goto	l5507
u8760:
	goto	l5139
	line	1180
	
l5297:	
;charge_mgr.c: 1178: else
;charge_mgr.c: 1179: {
;charge_mgr.c: 1180: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	1182
	
l5299:	
;charge_mgr.c: 1182: if(s_work.voltage >= 3100 && !(s_work.voltage >= 3990 && s_work.type == 6))
	movlw	0Ch
	subwf	1+(_s_work)+02h,w
	movlw	01Ch
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8771
	goto	u8770
u8771:
	goto	l5507
u8770:
	
l5301:	
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8781
	goto	u8780
u8781:
	goto	l5305
u8780:
	
l5303:	
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u8791
	goto	u8790
u8791:
	goto	l5507
u8790:
	line	1184
	
l5305:	
;charge_mgr.c: 1183: {
;charge_mgr.c: 1184: s_work.state = 5;
	movlw	low(05h)
	movwf	(_s_work)
	line	1185
	
l5307:	
;charge_mgr.c: 1185: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	1186
	
l5309:	
;charge_mgr.c: 1186: g_ccBlocks[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l5507
	line	1193
	
l5311:	
;charge_mgr.c: 1193: if(s_work.chargeTimer > (600 * 100))
	movlw	0EAh
	subwf	1+(_s_work)+04h,w
	movlw	061h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u8801
	goto	u8800
u8801:
	goto	l673
u8800:
	line	1194
	
l5313:	
;charge_mgr.c: 1194: s_work.state = 6;
	movlw	low(06h)
	movwf	(_s_work)
	
l673:	
	line	1202
;charge_mgr.c: 1202: if(s_work.voltage >= 3990 && s_work.type == 6)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8811
	goto	u8810
u8811:
	goto	l5319
u8810:
	
l5315:	
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u8821
	goto	u8820
u8821:
	goto	l5319
u8820:
	goto	l5507
	line	1212
	
l5319:	
;charge_mgr.c: 1212: if(s_work.voltage < 3990 && s_work.chargeTimer <= (6000) && s_work.type == 1)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u8831
	goto	u8830
u8831:
	goto	l5341
u8830:
	
l5321:	
	movlw	017h
	subwf	1+(_s_work)+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipnc
	goto	u8841
	goto	u8840
u8841:
	goto	l5341
u8840:
	
l5323:	
		decf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u8851
	goto	u8850
u8851:
	goto	l5341
u8850:
	line	1214
	
l5325:	
;charge_mgr.c: 1213: {
;charge_mgr.c: 1214: if((g_ccBlocks[idx]) == 0)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfss	status,2
	goto	u8861
	goto	u8860
u8861:
	goto	l5329
u8860:
	line	1216
	
l5327:	
;charge_mgr.c: 1215: {
;charge_mgr.c: 1216: g_slotRefV[idx] = s_work.voltage;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	0+(_s_work)+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)+02h,w
	movwf	indf
	line	1217
;charge_mgr.c: 1217: (g_ccBlocks[idx]) = 1;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	indf,f
	line	1218
;charge_mgr.c: 1218: }
	goto	l5341
	line	1219
	
l5329:	
;charge_mgr.c: 1219: else if(s_work.voltage >= g_slotRefV[idx] + (50))
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u8875
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	0+(_s_work)+02h,w
u8875:
	skipc
	goto	u8871
	goto	u8870
u8871:
	goto	l5339
u8870:
	line	1221
	
l5331:	
;charge_mgr.c: 1220: {
;charge_mgr.c: 1221: if(++(g_stableCnt[idx]) >= 3)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	movlw	low(03h)
	subwf	(indf),w
	skipc
	goto	u8881
	goto	u8880
u8881:
	goto	l677
u8880:
	line	1223
	
l5333:	
;charge_mgr.c: 1222: {
;charge_mgr.c: 1223: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l5209
	line	1231
	
l5339:	
;charge_mgr.c: 1229: else
;charge_mgr.c: 1230: {
;charge_mgr.c: 1231: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l5341
	line	1232
	
l677:	
	line	1240
	
l5341:	
;charge_mgr.c: 1232: }
;charge_mgr.c: 1233: }
;charge_mgr.c: 1240: if(s_work.voltage >= 3990)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8891
	goto	u8890
u8891:
	goto	l5371
u8890:
	line	1242
	
l5343:	
;charge_mgr.c: 1241: {
;charge_mgr.c: 1242: if(s_work.type == 1)
		decf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u8901
	goto	u8900
u8901:
	goto	l5355
u8900:
	line	1244
	
l5345:	
;charge_mgr.c: 1243: {
;charge_mgr.c: 1244: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1245
;charge_mgr.c: 1245: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8911
	goto	u8910
u8911:
	goto	l5349
u8910:
	goto	l5507
	line	1247
	
l5349:	
;charge_mgr.c: 1247: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l5285
	line	1252
	
l5355:	
;charge_mgr.c: 1251: }
;charge_mgr.c: 1252: if(s_work.type == 6)
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u8921
	goto	u8920
u8921:
	goto	l5359
u8920:
	goto	l5507
	line	1257
	
l5359:	
;charge_mgr.c: 1256: }
;charge_mgr.c: 1257: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1258
;charge_mgr.c: 1258: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8931
	goto	u8930
u8931:
	goto	l5363
u8930:
	goto	l5507
	line	1260
	
l5363:	
;charge_mgr.c: 1260: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1261
	
l5365:	
;charge_mgr.c: 1261: s_work.type = 0;
	clrf	0+(_s_work)+01h
	line	1262
	
l5367:	
;charge_mgr.c: 1262: s_work.state = 0;
	clrf	(_s_work)
	goto	l5145
	line	1272
	
l5371:	
;charge_mgr.c: 1265: }
;charge_mgr.c: 1272: if(s_work.type == 6)
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u8941
	goto	u8940
u8941:
	goto	l5385
u8940:
	line	1274
	
l5373:	
;charge_mgr.c: 1273: {
;charge_mgr.c: 1274: if(s_work.voltage < 2000U)
	movlw	07h
	subwf	1+(_s_work)+02h,w
	movlw	0D0h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u8951
	goto	u8950
u8951:
	goto	l5383
u8950:
	line	1276
	
l5375:	
;charge_mgr.c: 1275: {
;charge_mgr.c: 1276: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1277
;charge_mgr.c: 1277: if(g_detectLowCnt[idx] >= 33U)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u8961
	goto	u8960
u8961:
	goto	l5401
u8960:
	goto	l5207
	line	1287
	
l5383:	
;charge_mgr.c: 1285: else
;charge_mgr.c: 1286: {
;charge_mgr.c: 1287: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l5401
	line	1292
	
l5385:	
;charge_mgr.c: 1290: else
;charge_mgr.c: 1291: {
;charge_mgr.c: 1292: if(s_work.voltage < g_slotRefV[idx] && g_slotRefV[idx] - s_work.voltage > 500)
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u8975
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(_s_work)+02h,w
u8975:
	skipnc
	goto	u8971
	goto	u8970
u8971:
	goto	l5383
u8970:
	
l5387:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(_s_work)+02h,w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(_s_work)+02h,w
	skipc
	incf	1+(_s_work)+02h,w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	01h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipc
	goto	u8981
	goto	u8980
u8981:
	goto	l5383
u8980:
	line	1294
	
l5389:	
;charge_mgr.c: 1293: {
;charge_mgr.c: 1294: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	1295
;charge_mgr.c: 1295: if(g_detectLowCnt[idx] >= 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipc
	goto	u8991
	goto	u8990
u8991:
	goto	l5401
u8990:
	line	1297
	
l5391:	
;charge_mgr.c: 1296: {
;charge_mgr.c: 1297: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1298
;charge_mgr.c: 1298: (g_ccBlocks[idx])++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1300
	
l5393:	
;charge_mgr.c: 1300: s_work.type = 0;
	clrf	0+(_s_work)+01h
	goto	l5259
	line	1316
	
l5401:	
;charge_mgr.c: 1309: }
;charge_mgr.c: 1310: }
;charge_mgr.c: 1316: if(s_work.voltage >= 3850 && s_work.type == 1)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9001
	goto	u9000
u9001:
	goto	l5409
u9000:
	
l5403:	
		decf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u9011
	goto	u9010
u9011:
	goto	l5409
u9010:
	line	1318
	
l5405:	
;charge_mgr.c: 1317: {
;charge_mgr.c: 1318: g_ovCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1319
;charge_mgr.c: 1319: if(g_ovCnt[idx] >= 5)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u9021
	goto	u9020
u9021:
	goto	l5507
u9020:
	goto	l5139
	line	1327
	
l5409:	
;charge_mgr.c: 1325: else
;charge_mgr.c: 1326: {
;charge_mgr.c: 1327: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l5507
	line	1338
	
l5411:	
;charge_mgr.c: 1338: if(s_work.voltage >= 3990)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9031
	goto	u9030
u9031:
	goto	l5429
u9030:
	line	1340
	
l5413:	
;charge_mgr.c: 1339: {
;charge_mgr.c: 1340: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1341
	
l5415:	
;charge_mgr.c: 1341: if(g_detectLowCnt[idx] >= (s_work.type == 6 ? 50 : 2))
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u9041
	goto	u9040
u9041:
	goto	l5419
u9040:
	
l5417:	
	movlw	02h
	movwf	(_Slot_Charge_Ctrl$322)
	clrf	(_Slot_Charge_Ctrl$322+1)
	goto	l5421
	
l5419:	
	movlw	032h
	movwf	(_Slot_Charge_Ctrl$322)
	clrf	(_Slot_Charge_Ctrl$322+1)
	
l5421:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(_Slot_Charge_Ctrl$322+1),w
	xorlw	80h
	sublw	080h
	skipz
	goto	u9055
	movf	(_Slot_Charge_Ctrl$322),w
	subwf	indf,w
u9055:

	skipc
	goto	u9051
	goto	u9050
u9051:
	goto	l5507
u9050:
	line	1343
	
l5423:	
;charge_mgr.c: 1342: {
;charge_mgr.c: 1343: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l5367
	line	1352
	
l5429:	
;charge_mgr.c: 1348: }
;charge_mgr.c: 1352: if(s_work.voltage < 2800U)
	movlw	0Ah
	subwf	1+(_s_work)+02h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u9061
	goto	u9060
u9061:
	goto	l4863
u9060:
	line	1354
	
l5431:	
;charge_mgr.c: 1353: {
;charge_mgr.c: 1354: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1355
;charge_mgr.c: 1355: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9071
	goto	u9070
u9071:
	goto	l5435
u9070:
	goto	l5507
	line	1357
	
l5435:	
;charge_mgr.c: 1357: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1358
	
l5437:	
;charge_mgr.c: 1358: s_work.state = 4;
	movlw	low(04h)
	movwf	(_s_work)
	line	1359
	
l5439:	
;charge_mgr.c: 1359: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	1360
	
l5441:	
;charge_mgr.c: 1360: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l5225
	line	1373
	
l5451:	
;charge_mgr.c: 1373: if(s_work.voltage >= 3990)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9081
	goto	u9080
u9081:
	goto	l5467
u9080:
	line	1375
	
l5453:	
;charge_mgr.c: 1374: {
;charge_mgr.c: 1375: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1376
;charge_mgr.c: 1376: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9091
	goto	u9090
u9091:
	goto	l5457
u9090:
	goto	l5507
	line	1378
	
l5457:	
;charge_mgr.c: 1378: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1379
	
l5459:	
;charge_mgr.c: 1379: s_work.type = 0;
	clrf	0+(_s_work)+01h
	line	1380
	
l5461:	
;charge_mgr.c: 1380: s_work.state = 0;
	clrf	(_s_work)
	goto	l5307
	line	1393
	
l5467:	
;charge_mgr.c: 1384: }
;charge_mgr.c: 1393: if(s_work.type == 2 || s_work.type == 3)
		movlw	2
	xorwf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u9101
	goto	u9100
u9101:
	goto	l5471
u9100:
	
l5469:	
		movlw	3
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u9111
	goto	u9110
u9111:
	goto	l5487
u9110:
	line	1395
	
l5471:	
;charge_mgr.c: 1394: {
;charge_mgr.c: 1395: if(s_work.voltage > 2700U && (g_highVFlag & ((unsigned int)1 << idx)))
	movlw	0Ah
	subwf	1+(_s_work)+02h,w
	movlw	08Dh
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9121
	goto	u9120
u9121:
	goto	l4863
u9120:
	
l5473:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9134
u9135:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9134:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9135
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u9141
	goto	u9140
u9141:
	goto	l4863
u9140:
	line	1397
	
l5475:	
;charge_mgr.c: 1396: {
;charge_mgr.c: 1397: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1398
;charge_mgr.c: 1398: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9151
	goto	u9150
u9151:
	goto	l5257
u9150:
	goto	l5507
	line	1411
	
l5487:	
;charge_mgr.c: 1409: }
;charge_mgr.c: 1411: if(s_work.voltage > 750)
	movlw	02h
	subwf	1+(_s_work)+02h,w
	movlw	0EFh
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9161
	goto	u9160
u9161:
	goto	l4863
u9160:
	line	1413
	
l5489:	
;charge_mgr.c: 1412: {
;charge_mgr.c: 1413: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1414
;charge_mgr.c: 1414: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9171
	goto	u9170
u9171:
	goto	l5257
u9170:
	goto	l5507
	line	1427
	
l5501:	
;charge_mgr.c: 1427: s_work.state = 0;
	clrf	(_s_work)
	line	1428
;charge_mgr.c: 1428: break;
	goto	l5507
	line	482
	
l5505:	
	movf	(_s_work),w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l4797
	xorlw	1^0	; case 1
	skipnz
	goto	l4825
	xorlw	2^1	; case 2
	skipnz
	goto	l5137
	xorlw	3^2	; case 3
	skipnz
	goto	l5151
	xorlw	4^3	; case 4
	skipnz
	goto	l5177
	xorlw	5^4	; case 5
	skipnz
	goto	l5311
	xorlw	6^5	; case 6
	skipnz
	goto	l5411
	xorlw	7^6	; case 7
	skipnz
	goto	l5451
	xorlw	8^7	; case 8
	skipnz
	goto	l4953
	xorlw	9^8	; case 9
	skipnz
	goto	l5037
	goto	l5501
	opt asmopt_pop

	line	1440
	
l5507:	
;charge_mgr.c: 1439: if(s_work.state == 1 || s_work.state == 8 ||
;charge_mgr.c: 1440: s_work.state == 9)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
		decf	((_s_work)),w
	btfsc	status,2
	goto	u9181
	goto	u9180
u9181:
	goto	l5513
u9180:
	
l5509:	
		movlw	8
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u9191
	goto	u9190
u9191:
	goto	l5513
u9190:
	
l5511:	
		movlw	9
	xorwf	((_s_work)),w
	btfss	status,2
	goto	u9201
	goto	u9200
u9201:
	goto	l5517
u9200:
	line	1442
	
l5513:	
;charge_mgr.c: 1441: {
;charge_mgr.c: 1442: if(g_detectOwner == 0xFF)
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectOwner)^080h),w
	btfss	status,2
	goto	u9211
	goto	u9210
u9211:
	goto	l724
u9210:
	line	1443
	
l5515:	
;charge_mgr.c: 1443: g_detectOwner = idx;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	goto	l724
	line	1447
	
l5517:	
;charge_mgr.c: 1445: else
;charge_mgr.c: 1446: {
;charge_mgr.c: 1447: if(g_detectOwner == idx)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u9221
	goto	u9220
u9221:
	goto	l724
u9220:
	line	1448
	
l5519:	
;charge_mgr.c: 1448: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	1449
	
l724:	
	line	1455
;charge_mgr.c: 1449: }
;charge_mgr.c: 1453: if(g_detectWaiter == idx &&
;charge_mgr.c: 1454: !(s_work.state == 1 || s_work.state == 8 ||
;charge_mgr.c: 1455: s_work.state == 9))
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_detectWaiter)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u9231
	goto	u9230
u9231:
	goto	l5529
u9230:
	
l5521:	
		decf	((_s_work)),w
	btfsc	status,2
	goto	u9241
	goto	u9240
u9241:
	goto	l5529
u9240:
	
l5523:	
		movlw	8
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u9251
	goto	u9250
u9251:
	goto	l5529
u9250:
	
l5525:	
		movlw	9
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u9261
	goto	u9260
u9261:
	goto	l5529
u9260:
	line	1456
	
l5527:	
;charge_mgr.c: 1456: g_detectWaiter = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectWaiter)^080h
	line	1458
	
l5529:	
;charge_mgr.c: 1458: g_slot[idx] = s_work;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_s_work),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+4,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+5,w
	movwf	indf
	line	1467
	
l5531:	
;charge_mgr.c: 1465: if((s_work.state == 2 || s_work.state == 3 ||
;charge_mgr.c: 1466: s_work.state == 4 || s_work.state == 5) &&
;charge_mgr.c: 1467: g_detectOwner != 0xFF)
		movlw	2
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u9271
	goto	u9270
u9271:
	goto	l5539
u9270:
	
l5533:	
		movlw	3
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u9281
	goto	u9280
u9281:
	goto	l5539
u9280:
	
l5535:	
		movlw	4
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u9291
	goto	u9290
u9291:
	goto	l5539
u9290:
	
l5537:	
		movlw	5
	xorwf	((_s_work)),w
	btfss	status,2
	goto	u9301
	goto	u9300
u9301:
	goto	l5545
u9300:
	
l5539:	
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectOwner)^080h),w
	btfsc	status,2
	goto	u9311
	goto	u9310
u9311:
	goto	l5545
u9310:
	goto	l5543
	line	1469
	
l732:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l520
	
l734:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l520
	
l735:	
	bsf	(51/8),(51)&7	;volatile
	goto	l520
	
l736:	
	bsf	(50/8),(50)&7	;volatile
	goto	l520
	
l737:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l520
	
l738:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l520
	
l739:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l520
	
l740:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l520
	
l741:	
	bsf	(48/8),(48)&7	;volatile
	goto	l520
	
l742:	
	bsf	(49/8),(49)&7	;volatile
	goto	l520
	
l743:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l520
	
l744:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l520
	
l5543:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l732
	xorlw	1^0	; case 1
	skipnz
	goto	l734
	xorlw	2^1	; case 2
	skipnz
	goto	l735
	xorlw	3^2	; case 3
	skipnz
	goto	l736
	xorlw	4^3	; case 4
	skipnz
	goto	l737
	xorlw	5^4	; case 5
	skipnz
	goto	l738
	xorlw	6^5	; case 6
	skipnz
	goto	l739
	xorlw	7^6	; case 7
	skipnz
	goto	l740
	xorlw	8^7	; case 8
	skipnz
	goto	l741
	xorlw	9^8	; case 9
	skipnz
	goto	l742
	xorlw	10^9	; case 10
	skipnz
	goto	l743
	xorlw	11^10	; case 11
	skipnz
	goto	l744
	goto	l520
	opt asmopt_pop

	line	1474
	
l5545:	
;charge_mgr.c: 1471: else if((s_work.state == 2 || s_work.state == 3 ||
;charge_mgr.c: 1472: s_work.state == 4 || s_work.state == 5 ||
;charge_mgr.c: 1473: ((s_work.state == 8 || s_work.state == 1) && g_detectOwner == idx)) &&
;charge_mgr.c: 1474: !g_tempProtect && !g_vccProtect)
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u9321
	goto	u9320
u9321:
	goto	l5559
u9320:
	
l5547:	
		movlw	3
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u9331
	goto	u9330
u9331:
	goto	l5559
u9330:
	
l5549:	
		movlw	4
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u9341
	goto	u9340
u9341:
	goto	l5559
u9340:
	
l5551:	
		movlw	5
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u9351
	goto	u9350
u9351:
	goto	l5559
u9350:
	
l5553:	
		movlw	8
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u9361
	goto	u9360
u9361:
	goto	l5557
u9360:
	
l5555:	
		decf	((_s_work)),w
	btfss	status,2
	goto	u9371
	goto	u9370
u9371:
	goto	l5569
u9370:
	
l5557:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u9381
	goto	u9380
u9381:
	goto	l5569
u9380:
	
l5559:	
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u9391
	goto	u9390
u9391:
	goto	l5569
u9390:
	
l5561:	
	movf	((_g_vccProtect)^080h),w
	btfss	status,2
	goto	u9401
	goto	u9400
u9401:
	goto	l5569
u9400:
	goto	l5565
	line	1476
	
l754:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	l520
	
l756:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	l520
	
l757:	
	bcf	(51/8),(51)&7	;volatile
	goto	l520
	
l758:	
	bcf	(50/8),(50)&7	;volatile
	goto	l520
	
l759:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	l520
	
l760:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	l520
	
l761:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l520
	
l762:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l520
	
l763:	
	bcf	(48/8),(48)&7	;volatile
	goto	l520
	
l764:	
	bcf	(49/8),(49)&7	;volatile
	goto	l520
	
l765:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l520
	
l766:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l520
	
l5565:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l754
	xorlw	1^0	; case 1
	skipnz
	goto	l756
	xorlw	2^1	; case 2
	skipnz
	goto	l757
	xorlw	3^2	; case 3
	skipnz
	goto	l758
	xorlw	4^3	; case 4
	skipnz
	goto	l759
	xorlw	5^4	; case 5
	skipnz
	goto	l760
	xorlw	6^5	; case 6
	skipnz
	goto	l761
	xorlw	7^6	; case 7
	skipnz
	goto	l762
	xorlw	8^7	; case 8
	skipnz
	goto	l763
	xorlw	9^8	; case 9
	skipnz
	goto	l764
	xorlw	10^9	; case 10
	skipnz
	goto	l765
	xorlw	11^10	; case 11
	skipnz
	goto	l766
	goto	l520
	opt asmopt_pop

	line	1480
	
l5569:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l732
	xorlw	1^0	; case 1
	skipnz
	goto	l734
	xorlw	2^1	; case 2
	skipnz
	goto	l735
	xorlw	3^2	; case 3
	skipnz
	goto	l736
	xorlw	4^3	; case 4
	skipnz
	goto	l737
	xorlw	5^4	; case 5
	skipnz
	goto	l738
	xorlw	6^5	; case 6
	skipnz
	goto	l739
	xorlw	7^6	; case 7
	skipnz
	goto	l740
	xorlw	8^7	; case 8
	skipnz
	goto	l741
	xorlw	9^8	; case 9
	skipnz
	goto	l742
	xorlw	10^9	; case 10
	skipnz
	goto	l743
	xorlw	11^10	; case 11
	skipnz
	goto	l744
	goto	l520
	opt asmopt_pop

	line	1482
	
l520:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_Charge_Ctrl
	__end_of_Slot_Charge_Ctrl:
	signat	_Slot_Charge_Ctrl,4217
	global	___wmul

;; *************** function ___wmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
;; Parameters:    Size  Location     Type
;;  multiplier      2    2[COMMON] unsigned int 
;;  multiplicand    2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  product         2    6[COMMON] unsigned int 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         6       0       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
global __ptext5
__ptext5:	;psect for function ___wmul
psect	text5
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
	global	__size_of___wmul
	__size_of___wmul	equ	__end_of___wmul-___wmul
	
___wmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___wmul: [wreg+status,2+status,0]
	line	43
	
l3249:	
	clrf	(___wmul@product)
	clrf	(___wmul@product+1)
	line	45
	
l3251:	
	btfss	(___wmul@multiplier),(0)&7
	goto	u4071
	goto	u4070
u4071:
	goto	l3255
u4070:
	line	46
	
l3253:	
	movf	(___wmul@multiplicand),w
	addwf	(___wmul@product),f
	skipnc
	incf	(___wmul@product+1),f
	movf	(___wmul@multiplicand+1),w
	addwf	(___wmul@product+1),f
	line	47
	
l3255:	
	clrc
	rlf	(___wmul@multiplicand),f
	rlf	(___wmul@multiplicand+1),f
	line	48
	
l3257:	
	clrc
	rrf	(___wmul@multiplier+1),f
	rrf	(___wmul@multiplier),f
	line	49
	
l3259:	
	movf	((___wmul@multiplier)),w
iorwf	((___wmul@multiplier+1)),w
	btfss	status,2
	goto	u4081
	goto	u4080
u4081:
	goto	l3251
u4080:
	line	52
	
l3261:	
	movf	(___wmul@product+1),w
	movwf	(?___wmul+1)
	movf	(___wmul@product),w
	movwf	(?___wmul)
	line	53
	
l855:	
	return
	opt stack 0
GLOBAL	__end_of___wmul
	__end_of___wmul:
	signat	___wmul,8314
	global	_Route_LinearLi

;; *************** function _Route_LinearLi *****************
;; Defined at:
;;		line 315 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  pre             2   35[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1   40[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       6       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Route_DetectLi
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	315
global __ptext6
__ptext6:	;psect for function _Route_LinearLi
psect	text6
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	315
	global	__size_of_Route_LinearLi
	__size_of_Route_LinearLi	equ	__end_of_Route_LinearLi-_Route_LinearLi
	
_Route_LinearLi:	
;incstack = 0
	opt	stack 2
; Regs used in _Route_LinearLi: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Route_LinearLi@idx stored from wreg
	movwf	(Route_LinearLi@idx)
	line	317
	
l4655:	
;charge_mgr.c: 317: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	318
	
l4657:	
;charge_mgr.c: 318: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Route_LinearLi@idx),w
	movwf	(??_Route_LinearLi+0)+0
	movlw	01h
	movwf	(??_Route_LinearLi+1)+0
	movlw	0
	movwf	(??_Route_LinearLi+1)+0+1
	goto	u7104
u7105:
	clrc
	rlf	(??_Route_LinearLi+1)+0,f
	rlf	(??_Route_LinearLi+1)+1,f
u7104:
	decfsz	(??_Route_LinearLi+0)+0,f
	goto	u7105
	
	comf	(??_Route_LinearLi+1)+0,f
	comf	(??_Route_LinearLi+1)+1,f
	movf	0+(??_Route_LinearLi+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Route_LinearLi+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	319
	
l4659:	
;charge_mgr.c: 319: if(((g_ccBlocks[idx]) & 0x80))
	bcf	status, 5	;RP0=0, select bank0
	movf	(Route_LinearLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	btfss	indf,(7)&7
	goto	u7111
	goto	u7110
u7111:
	goto	l4665
u7110:
	line	321
	
l4661:	
;charge_mgr.c: 320: {
;charge_mgr.c: 321: s_work.type = 3;
	movlw	low(03h)
	movwf	0+(_s_work)+01h
	line	322
;charge_mgr.c: 322: return 7;
	movlw	low(07h)
	goto	l478
	line	324
	
l4665:	
;charge_mgr.c: 323: }
;charge_mgr.c: 324: s_work.type = 6;
	movlw	low(06h)
	movwf	0+(_s_work)+01h
	line	325
	
l4667:	
;charge_mgr.c: 325: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	326
	
l4669:	
;charge_mgr.c: 326: return Route_DetectLi(idx, pre);
	movf	(Route_LinearLi@pre+1),w
	movwf	(Route_DetectLi@slot_v+1)
	movf	(Route_LinearLi@pre),w
	movwf	(Route_DetectLi@slot_v)
	movf	(Route_LinearLi@idx),w
	fcall	_Route_DetectLi
	line	327
	
l478:	
	return
	opt stack 0
GLOBAL	__end_of_Route_LinearLi
	__end_of_Route_LinearLi:
	signat	_Route_LinearLi,8313
	global	_Route_LiIon

;; *************** function _Route_LiIon *****************
;; Defined at:
;;		line 290 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   38[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Route_DetectLi
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	line	290
global __ptext7
__ptext7:	;psect for function _Route_LiIon
psect	text7
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	290
	global	__size_of_Route_LiIon
	__size_of_Route_LiIon	equ	__end_of_Route_LiIon-_Route_LiIon
	
_Route_LiIon:	
;incstack = 0
	opt	stack 2
; Regs used in _Route_LiIon: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Route_LiIon@idx stored from wreg
	movwf	(Route_LiIon@idx)
	line	292
	
l4643:	
;charge_mgr.c: 292: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	293
	
l4645:	
;charge_mgr.c: 293: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Route_LiIon@idx),w
	movwf	(??_Route_LiIon+0)+0
	movlw	01h
	movwf	(??_Route_LiIon+1)+0
	movlw	0
	movwf	(??_Route_LiIon+1)+0+1
	goto	u7094
u7095:
	clrc
	rlf	(??_Route_LiIon+1)+0,f
	rlf	(??_Route_LiIon+1)+1,f
u7094:
	decfsz	(??_Route_LiIon+0)+0,f
	goto	u7095
	
	comf	(??_Route_LiIon+1)+0,f
	comf	(??_Route_LiIon+1)+1,f
	movf	0+(??_Route_LiIon+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Route_LiIon+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	294
	
l4647:	
;charge_mgr.c: 294: s_work.type = 1;
	bcf	status, 5	;RP0=0, select bank0
	clrf	0+(_s_work)+01h
	incf	0+(_s_work)+01h,f
	line	295
	
l4649:	
;charge_mgr.c: 295: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	296
	
l4651:	
;charge_mgr.c: 296: return Route_DetectLi(idx, s_work.voltage);
	movf	1+(_s_work)+02h,w
	movwf	(Route_DetectLi@slot_v+1)
	movf	0+(_s_work)+02h,w
	movwf	(Route_DetectLi@slot_v)
	movf	(Route_LiIon@idx),w
	fcall	_Route_DetectLi
	line	297
	
l474:	
	return
	opt stack 0
GLOBAL	__end_of_Route_LiIon
	__end_of_Route_LiIon:
	signat	_Route_LiIon,4217
	global	_Enter_DiodeTest

;; *************** function _Enter_DiodeTest *****************
;; Defined at:
;;		line 406 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          3       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	406
global __ptext8
__ptext8:	;psect for function _Enter_DiodeTest
psect	text8
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	406
	global	__size_of_Enter_DiodeTest
	__size_of_Enter_DiodeTest	equ	__end_of_Enter_DiodeTest-_Enter_DiodeTest
	
_Enter_DiodeTest:	
;incstack = 0
	opt	stack 4
; Regs used in _Enter_DiodeTest: [wreg+status,2+status,0]
;Enter_DiodeTest@idx stored from wreg
	movwf	(Enter_DiodeTest@idx)
	line	408
	
l3241:	
;charge_mgr.c: 408: s_work.state = 9;
	movlw	low(09h)
	movwf	(_s_work)
	line	409
	
l3243:	
;charge_mgr.c: 409: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	410
	
l3245:	
;charge_mgr.c: 411: g_diodeTraceSlot = (unsigned char)idx;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_diodeTraceCnt)^080h
	line	412
	
l3247:	
;charge_mgr.c: 412: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(Enter_DiodeTest@idx),w
	movwf	(??_Enter_DiodeTest+0)+0
	movlw	01h
	movwf	(??_Enter_DiodeTest+1)+0
	movlw	0
	movwf	(??_Enter_DiodeTest+1)+0+1
	goto	u4064
u4065:
	clrc
	rlf	(??_Enter_DiodeTest+1)+0,f
	rlf	(??_Enter_DiodeTest+1)+1,f
u4064:
	decfsz	(??_Enter_DiodeTest+0)+0,f
	goto	u4065
	
	comf	(??_Enter_DiodeTest+1)+0,f
	comf	(??_Enter_DiodeTest+1)+1,f
	movf	0+(??_Enter_DiodeTest+1)+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_Enter_DiodeTest+1)+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	413
	
l497:	
	return
	opt stack 0
GLOBAL	__end_of_Enter_DiodeTest
	__end_of_Enter_DiodeTest:
	signat	_Enter_DiodeTest,4217
	global	_Detect_Classify

;; *************** function _Detect_Classify *****************
;; Defined at:
;;		line 342 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  fromHighV       1   35[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   39[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       5       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Get_Vcc
;;		_Route_DetectLi
;;		___lwdiv
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	342
global __ptext9
__ptext9:	;psect for function _Detect_Classify
psect	text9
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	342
	global	__size_of_Detect_Classify
	__size_of_Detect_Classify	equ	__end_of_Detect_Classify-_Detect_Classify
	
_Detect_Classify:	
;incstack = 0
	opt	stack 2
; Regs used in _Detect_Classify: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Detect_Classify@idx stored from wreg
	movwf	(Detect_Classify@idx)
	line	344
	
l4673:	
;charge_mgr.c: 344: if(fromHighV)
	movf	((Detect_Classify@fromHighV)),w
	btfsc	status,2
	goto	u7121
	goto	u7120
u7121:
	goto	l4681
u7120:
	line	352
	
l4675:	
;charge_mgr.c: 345: {
;charge_mgr.c: 352: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Detect_Classify@idx),w
	movwf	(??_Detect_Classify+0)+0
	movlw	01h
	movwf	(??_Detect_Classify+1)+0
	movlw	0
	movwf	(??_Detect_Classify+1)+0+1
	goto	u7134
u7135:
	clrc
	rlf	(??_Detect_Classify+1)+0,f
	rlf	(??_Detect_Classify+1)+1,f
u7134:
	decfsz	(??_Detect_Classify+0)+0,f
	goto	u7135
	
	comf	(??_Detect_Classify+1)+0,f
	comf	(??_Detect_Classify+1)+1,f
	movf	0+(??_Detect_Classify+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Detect_Classify+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	353
	
l4677:	
;charge_mgr.c: 353: g_stableCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Detect_Classify@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	354
	
l4679:	
;charge_mgr.c: 354: s_work.type = 5;
	movlw	low(05h)
	movwf	0+(_s_work)+01h
	line	356
	
l4681:	
;charge_mgr.c: 355: }
;charge_mgr.c: 356: if(s_work.type == 5)
		movlw	5
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u7141
	goto	u7140
u7141:
	goto	l4703
u7140:
	line	360
	
l4683:	
;charge_mgr.c: 357: {
;charge_mgr.c: 360: g_detectLowCnt[idx]++;
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	361
;charge_mgr.c: 361: if(g_detectLowCnt[idx] < 2)
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u7151
	goto	u7150
u7151:
	goto	l4687
u7150:
	goto	l484
	line	365
	
l4687:	
;charge_mgr.c: 365: g_detectOwner = idx;
	movf	(Detect_Classify@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	366
	
l4689:	
;charge_mgr.c: 366: Get_Vcc();
	fcall	_Get_Vcc
	line	368
	
l4691:	
;charge_mgr.c: 368: g_impData = ((((s_work.voltage) > 0x0FFFU) ? 0x0FFFU : (s_work.voltage)) | ((unsigned int)((((g_vcc_mv) + 50U) / 100U) - 38U) << 12));
	movlw	064h
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	addlw	low(032h)
	movwf	(___lwdiv@dividend)
	movf	(_g_vcc_mv+1)^080h,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_impData+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_g_impData)
	movlw	0Ch
	
u7165:
	clrc
	rlf	(_g_impData),f
	rlf	(_g_impData+1),f
	addlw	-1
	skipz
	goto	u7165
	movlw	(0A000h >> 8)
	addwf	(_g_impData+1),f
	movlw	010h
	subwf	1+(_s_work)+02h,w
	movlw	0
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u7171
	goto	u7170
u7171:
	goto	l4695
u7170:
	
l4693:	
	movf	0+(_s_work)+02h,w
	iorwf	(_g_impData),f
	movf	1+(_s_work)+02h,w
	iorwf	(_g_impData+1),f
	goto	l488
	
l4695:	
	movlw	0FFh
	iorwf	(_g_impData),f
	movlw	0Fh
	iorwf	(_g_impData+1),f
	
l488:	
	line	369
;charge_mgr.c: 369: s_work.state = 8;
	movlw	low(08h)
	movwf	(_s_work)
	line	370
	
l4697:	
;charge_mgr.c: 370: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	371
	
l4699:	
;charge_mgr.c: 371: g_detectLowCnt[idx] = 0;
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l484
	line	374
	
l4703:	
;charge_mgr.c: 373: }
;charge_mgr.c: 374: if(s_work.type == 1 || s_work.type == 6)
		decf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u7181
	goto	u7180
u7181:
	goto	l4707
u7180:
	
l4705:	
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u7191
	goto	u7190
u7191:
	goto	l4717
u7190:
	line	377
	
l4707:	
;charge_mgr.c: 375: {
;charge_mgr.c: 377: g_detectLowCnt[idx]++;
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	378
;charge_mgr.c: 378: if(g_detectLowCnt[idx] < 2)
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u7201
	goto	u7200
u7201:
	goto	l4711
u7200:
	goto	l484
	line	380
	
l4711:	
;charge_mgr.c: 380: s_work.state = Route_DetectLi(idx, s_work.voltage);
	movf	1+(_s_work)+02h,w
	movwf	(Route_DetectLi@slot_v+1)
	movf	0+(_s_work)+02h,w
	movwf	(Route_DetectLi@slot_v)
	movf	(Detect_Classify@idx),w
	fcall	_Route_DetectLi
	movwf	(_s_work)
	line	381
	
l4713:	
;charge_mgr.c: 381: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	goto	l484
	line	384
	
l4717:	
;charge_mgr.c: 383: }
;charge_mgr.c: 384: if(s_work.type == 0)
	movf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u7211
	goto	u7210
u7211:
	goto	l4723
u7210:
	line	387
	
l4719:	
;charge_mgr.c: 385: {
;charge_mgr.c: 387: if(s_work.voltage >= 3990)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u7221
	goto	u7220
u7221:
	goto	l4723
u7220:
	goto	l484
	line	389
	
l4723:	
;charge_mgr.c: 389: s_work.state = 7;
	movlw	low(07h)
	movwf	(_s_work)
	goto	l4699
	line	396
	
l484:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_Classify
	__end_of_Detect_Classify:
	signat	_Detect_Classify,8313
	global	_Route_DetectLi

;; *************** function _Route_DetectLi *****************
;; Defined at:
;;		line 218 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  slot_v          2   17[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1   34[BANK0 ] unsigned char 
;;  bat_mv_long     4   29[BANK0 ] unsigned long 
;;  vx_mv           4   25[BANK0 ] unsigned long 
;;  bat_mv          2   23[BANK0 ] unsigned int 
;;  st              1   33[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0      12       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      18       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_Route_LiIon
;;		_Route_LinearLi
;;		_Detect_Classify
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=0
	line	218
global __ptext10
__ptext10:	;psect for function _Route_DetectLi
psect	text10
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	218
	global	__size_of_Route_DetectLi
	__size_of_Route_DetectLi	equ	__end_of_Route_DetectLi-_Route_DetectLi
	
_Route_DetectLi:	
;incstack = 0
	opt	stack 2
; Regs used in _Route_DetectLi: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Route_DetectLi@idx stored from wreg
	movwf	(Route_DetectLi@idx)
	line	231
	
l4601:	
;charge_mgr.c: 226: unsigned long vx_mv;
;charge_mgr.c: 227: unsigned long bat_mv_long;
;charge_mgr.c: 228: unsigned int bat_mv;
;charge_mgr.c: 229: unsigned char st;
;charge_mgr.c: 231: vx_mv = (unsigned long)slot_v * 5000UL / 4096UL;
	movf	(Route_DetectLi@slot_v),w
	movwf	(___lmul@multiplier)
	movf	(Route_DetectLi@slot_v+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv)

	
l4603:	
	movlw	0Ch
u7045:
	clrc
	rrf	(Route_DetectLi@vx_mv+3),f
	rrf	(Route_DetectLi@vx_mv+2),f
	rrf	(Route_DetectLi@vx_mv+1),f
	rrf	(Route_DetectLi@vx_mv),f
	addlw	-1
	skipz
	goto	u7045

	line	232
	
l4605:	
;charge_mgr.c: 232: bat_mv_long = 124UL * vx_mv + 206UL * 5000UL;
	movf	(Route_DetectLi@vx_mv+3),w
	movwf	(___lmul@multiplier+3)
	movf	(Route_DetectLi@vx_mv+2),w
	movwf	(___lmul@multiplier+2)
	movf	(Route_DetectLi@vx_mv+1),w
	movwf	(___lmul@multiplier+1)
	movf	(Route_DetectLi@vx_mv),w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long+3)
	movf	(2+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long+2)
	movf	(1+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long+1)
	movf	(0+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long)

	
l4607:	
	movlw	070h
	addwf	(Route_DetectLi@bat_mv_long),f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Route_DetectLi@bat_mv_long+1),f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Route_DetectLi@bat_mv_long+2),f
	movlw	0
	skipnc
movlw 1
	addwf	(Route_DetectLi@bat_mv_long+3),f
	line	233
	
l4609:	
;charge_mgr.c: 233: bat_mv = (unsigned int)((bat_mv_long + 1000UL/2UL) / 1000UL);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Route_DetectLi+0)+0)
	movlw	01h
	movwf	((??_Route_DetectLi+0)+0+1)
	movlw	0
	movwf	((??_Route_DetectLi+0)+0+2)
	movlw	0
	movwf	((??_Route_DetectLi+0)+0+3)
	movf	(Route_DetectLi@bat_mv_long),w
	addwf	(??_Route_DetectLi+0)+0,f
	movf	(Route_DetectLi@bat_mv_long+1),w
	skipnc
	incfsz	(Route_DetectLi@bat_mv_long+1),w
	goto	u7050
	goto	u7051
u7050:
	addwf	(??_Route_DetectLi+0)+1,f
u7051:
	movf	(Route_DetectLi@bat_mv_long+2),w
	skipnc
	incfsz	(Route_DetectLi@bat_mv_long+2),w
	goto	u7052
	goto	u7053
u7052:
	addwf	(??_Route_DetectLi+0)+2,f
u7053:
	movf	(Route_DetectLi@bat_mv_long+3),w
	skipnc
	incf	(Route_DetectLi@bat_mv_long+3),w
	addwf	(??_Route_DetectLi+0)+3,f
	movf	3+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Route_DetectLi@bat_mv+1)
	movf	(0+(?___lldiv)),w
	movwf	(Route_DetectLi@bat_mv)
	line	236
	
l4611:	
;charge_mgr.c: 236: if(slot_v >= 3235 || bat_mv > 60000U)
	movlw	0Ch
	subwf	(Route_DetectLi@slot_v+1),w
	movlw	0A3h
	skipnz
	subwf	(Route_DetectLi@slot_v),w
	skipnc
	goto	u7061
	goto	u7060
u7061:
	goto	l4615
u7060:
	
l4613:	
	movlw	0EAh
	subwf	(Route_DetectLi@bat_mv+1),w
	movlw	061h
	skipnz
	subwf	(Route_DetectLi@bat_mv),w
	skipc
	goto	u7071
	goto	u7070
u7071:
	goto	l4627
u7070:
	line	238
	
l4615:	
;charge_mgr.c: 237: {
;charge_mgr.c: 238: if((g_ccBlocks[idx]) >= 2)
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u7081
	goto	u7080
u7081:
	goto	l4619
u7080:
	line	240
	
l4617:	
;charge_mgr.c: 239: {
;charge_mgr.c: 240: st = 7;
	movlw	low(07h)
	movwf	(Route_DetectLi@st)
	line	241
;charge_mgr.c: 241: }
	goto	l4635
	line	244
	
l4619:	
;charge_mgr.c: 242: else
;charge_mgr.c: 243: {
;charge_mgr.c: 244: st = 5;
	movlw	low(05h)
	movwf	(Route_DetectLi@st)
	line	245
	
l4621:	
;charge_mgr.c: 245: g_slotRefV[idx] = slot_v;
	clrc
	rlf	(Route_DetectLi@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Route_DetectLi@slot_v),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	(Route_DetectLi@slot_v+1),w
	movwf	indf
	line	246
	
l4623:	
;charge_mgr.c: 246: g_ccBlocks[idx] = 0;
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	247
	
l4625:	
;charge_mgr.c: 247: g_stableCnt[idx] = 0;
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l4635
	line	252
	
l4627:	
;charge_mgr.c: 250: else
;charge_mgr.c: 251: {
;charge_mgr.c: 252: st = 4;
	movlw	low(04h)
	movwf	(Route_DetectLi@st)
	line	253
	
l4629:	
;charge_mgr.c: 253: (g_ccBlocks[idx] &= 0x80);
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(080h)
	bsf	status, 7	;select IRP bank3
	andwf	indf,f
	line	255
	
l4631:	
;charge_mgr.c: 255: g_slotRefV[idx] = slot_v;
	clrc
	rlf	(Route_DetectLi@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Route_DetectLi@slot_v),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	(Route_DetectLi@slot_v+1),w
	movwf	indf
	goto	l4625
	line	258
	
l4635:	
;charge_mgr.c: 257: }
;charge_mgr.c: 258: g_ovCnt[idx] = 0;
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	259
	
l4637:	
;charge_mgr.c: 259: g_detectLowCnt[idx] = 0;
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	260
	
l4639:	
;charge_mgr.c: 260: return st;
	movf	(Route_DetectLi@st),w
	line	261
	
l471:	
	return
	opt stack 0
GLOBAL	__end_of_Route_DetectLi
	__end_of_Route_DetectLi:
	signat	_Route_DetectLi,8313
	global	_Get_Vcc

;; *************** function _Get_Vcc *****************
;; Defined at:
;;		line 81 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   17[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  2   48[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/900
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;; This function is called by:
;;		_main
;;		_Detect_Classify
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	line	81
global __ptext11
__ptext11:	;psect for function _Get_Vcc
psect	text11
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	81
	global	__size_of_Get_Vcc
	__size_of_Get_Vcc	equ	__end_of_Get_Vcc-_Get_Vcc
	
_Get_Vcc:	
;incstack = 0
	opt	stack 3
; Regs used in _Get_Vcc: [wreg+status,2+status,0+pclath+cstack]
	line	83
	
l3019:	
;charge_mgr.c: 83: if(0xA5 == ADC_Sample(31, 0))
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u3741
	goto	u3740
u3741:
	goto	l432
u3740:
	line	85
	
l3021:	
;charge_mgr.c: 84: {
;charge_mgr.c: 85: unsigned long pt = (4096UL * 1200UL) / adresult;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Get_Vcc@pt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Get_Vcc@pt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Get_Vcc@pt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Get_Vcc@pt)

	line	86
	
l3023:	
;charge_mgr.c: 86: g_vcc_mv = (unsigned int)pt;
	movf	(Get_Vcc@pt+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(Get_Vcc@pt),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv)^080h
	line	89
	
l432:	
	return
	opt stack 0
GLOBAL	__end_of_Get_Vcc
	__end_of_Get_Vcc:
	signat	_Get_Vcc,90
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 142 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2    2[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         2       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	line	142
global __ptext12
__ptext12:	;psect for function _Detect_BatteryType
psect	text12
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	142
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 4
; Regs used in _Detect_BatteryType: [wreg]
	line	144
	
l3119:	
;charge_mgr.c: 144: if(voltage >= 3990)
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u3861
	goto	u3860
u3861:
	goto	l3125
u3860:
	line	145
	
l3121:	
;charge_mgr.c: 145: return 0;
	movlw	low(0)
	goto	l455
	line	146
	
l3125:	
;charge_mgr.c: 146: if(voltage < 500)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u3871
	goto	u3870
u3871:
	goto	l3131
u3870:
	goto	l3121
	line	161
	
l3131:	
;charge_mgr.c: 161: if(voltage >= 1015 && voltage < 3990)
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u3881
	goto	u3880
u3881:
	goto	l3139
u3880:
	
l3133:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u3891
	goto	u3890
u3891:
	goto	l3139
u3890:
	line	162
	
l3135:	
;charge_mgr.c: 162: return 5;
	movlw	low(05h)
	goto	l455
	line	167
	
l3139:	
;charge_mgr.c: 167: if(voltage >= 500 && voltage < 3990)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u3901
	goto	u3900
u3901:
	goto	l3121
u3900:
	
l3141:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u3911
	goto	u3910
u3911:
	goto	l3121
u3910:
	line	168
	
l3143:	
;charge_mgr.c: 168: return 1;
	movlw	low(01h)
	line	171
	
l455:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_Adc_Norm

;; *************** function _Adc_Norm *****************
;; Defined at:
;;		line 98 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  ch              1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  ch              1   20[BANK0 ] unsigned char 
;;  raw             2   21[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   17[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       3       0       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       6       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=0
	line	98
global __ptext13
__ptext13:	;psect for function _Adc_Norm
psect	text13
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	98
	global	__size_of_Adc_Norm
	__size_of_Adc_Norm	equ	__end_of_Adc_Norm-_Adc_Norm
	
_Adc_Norm:	
;incstack = 0
	opt	stack 3
; Regs used in _Adc_Norm: [wreg+status,2+status,0+pclath+cstack]
;Adc_Norm@ch stored from wreg
	movwf	(Adc_Norm@ch)
	line	101
	
l3101:	
;charge_mgr.c: 100: unsigned int raw;
;charge_mgr.c: 101: if(0xA5 != ADC_Sample(ch, 0))
	clrf	(ADC_Sample@adldo)
	movf	(Adc_Norm@ch),w
	fcall	_ADC_Sample
	xorlw	0A5h
	skipnz
	goto	u3841
	goto	u3840
u3841:
	goto	l3107
u3840:
	line	102
	
l3103:	
;charge_mgr.c: 102: return 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(?_Adc_Norm)
	clrf	(?_Adc_Norm+1)
	goto	l436
	line	103
	
l3107:	
;charge_mgr.c: 103: raw = adresult;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Adc_Norm@raw+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Adc_Norm@raw)
	line	104
	
l3109:	
;charge_mgr.c: 104: if(g_vcc_mv == 0)
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_vcc_mv)^080h),w
iorwf	((_g_vcc_mv+1)^080h),w
	btfss	status,2
	goto	u3851
	goto	u3850
u3851:
	goto	l3115
u3850:
	line	105
	
l3111:	
;charge_mgr.c: 105: return raw;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Adc_Norm@raw+1),w
	movwf	(?_Adc_Norm+1)
	movf	(Adc_Norm@raw),w
	movwf	(?_Adc_Norm)
	goto	l436
	line	106
	
l3115:	
;charge_mgr.c: 106: return (unsigned int)(((unsigned long)raw * (unsigned long)g_vcc_mv) / 5000UL);
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	movf	(Adc_Norm@raw),w
	movwf	(___lmul@multiplier)
	movf	(Adc_Norm@raw+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	movwf	(___lmul@multiplicand)
	movf	(_g_vcc_mv+1)^080h,w
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(?_Adc_Norm+1)
	movf	(0+(?___lldiv)),w
	movwf	(?_Adc_Norm)
	line	107
	
l436:	
	return
	opt stack 0
GLOBAL	__end_of_Adc_Norm
	__end_of_Adc_Norm:
	signat	_Adc_Norm,4218
	global	_Sense_Pins_Restore

;; *************** function _Sense_Pins_Restore *****************
;; Defined at:
;;		line 444 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	444
global __ptext14
__ptext14:	;psect for function _Sense_Pins_Restore
psect	text14
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	444
	global	__size_of_Sense_Pins_Restore
	__size_of_Sense_Pins_Restore	equ	__end_of_Sense_Pins_Restore-_Sense_Pins_Restore
	
_Sense_Pins_Restore:	
;incstack = 0
	opt	stack 5
; Regs used in _Sense_Pins_Restore: [wreg+status,2+status,0]
	line	446
	
l3445:	
;main.c: 446: TRISA |= 0xF0;
	movlw	low(0F0h)
	iorwf	(133)^080h,f	;volatile
	line	447
;main.c: 447: TRISB |= 0x30;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(5),f	;volatile
	line	448
;main.c: 448: TRISD |= 0xF0;
	movlw	low(0F0h)
	bsf	status, 6	;RP1=1, select bank2
	iorwf	(276)^0100h,f	;volatile
	line	449
;main.c: 449: TRISC |= 0x07;
	movlw	low(07h)
	iorwf	(261)^0100h,f	;volatile
	line	450
	
l3447:	
;main.c: 450: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	451
	
l3449:	
;main.c: 451: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	452
	
l3451:	
;main.c: 452: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	453
	
l3453:	
;main.c: 453: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	454
	
l355:	
	return
	opt stack 0
GLOBAL	__end_of_Sense_Pins_Restore
	__end_of_Sense_Pins_Restore:
	signat	_Sense_Pins_Restore,89
	global	_Sense_Pins_AsSink

;; *************** function _Sense_Pins_AsSink *****************
;; Defined at:
;;		line 432 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=0
	line	432
global __ptext15
__ptext15:	;psect for function _Sense_Pins_AsSink
psect	text15
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	432
	global	__size_of_Sense_Pins_AsSink
	__size_of_Sense_Pins_AsSink	equ	__end_of_Sense_Pins_AsSink-_Sense_Pins_AsSink
	
_Sense_Pins_AsSink:	
;incstack = 0
	opt	stack 5
; Regs used in _Sense_Pins_AsSink: [wreg+status,2+status,0]
	line	435
	
l3419:	
;main.c: 435: ANSEL0 &= 0x0F; TRISA &= 0x0F; RA4 = 0; RA5 = 0; RA6 = 0; RA7 = 0;
	movlw	low(0Fh)
	andwf	(147)^080h,f	;volatile
	movlw	low(0Fh)
	andwf	(133)^080h,f	;volatile
	
l3421:	
	bcf	(1076/8)^080h,(1076)&7	;volatile
	
l3423:	
	bcf	(1077/8)^080h,(1077)&7	;volatile
	
l3425:	
	bcf	(1078/8)^080h,(1078)&7	;volatile
	
l3427:	
	bcf	(1079/8)^080h,(1079)&7	;volatile
	line	437
;main.c: 437: ANSEL1 &= 0xCF; TRISB &= 0xCF; RB4 = 0; RB5 = 0;
	movlw	low(0CFh)
	andwf	(148)^080h,f	;volatile
	movlw	low(0CFh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(5),f	;volatile
	
l3429:	
	bcf	(52/8),(52)&7	;volatile
	
l3431:	
	bcf	(53/8),(53)&7	;volatile
	line	439
;main.c: 439: ANSEL3 &= 0xC3; TRISD &= 0xC3; RD2 = 0; RD3 = 0; RD4 = 0; RD5 = 0;
	movlw	low(0C3h)
	bsf	status, 5	;RP0=1, select bank1
	andwf	(140)^080h,f	;volatile
	movlw	low(0C3h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	andwf	(276)^0100h,f	;volatile
	
l3433:	
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	
l3435:	
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	
l3437:	
	bcf	(2108/8)^0100h,(2108)&7	;volatile
	
l3439:	
	bcf	(2109/8)^0100h,(2109)&7	;volatile
	line	441
;main.c: 441: ANSEL2 &= 0xFC; TRISC &= 0xFC; RC0 = 0; RC1 = 0;
	movlw	low(0FCh)
	andwf	(265)^0100h,f	;volatile
	movlw	low(0FCh)
	andwf	(261)^0100h,f	;volatile
	
l3441:	
	bcf	(2096/8)^0100h,(2096)&7	;volatile
	
l3443:	
	bcf	(2097/8)^0100h,(2097)&7	;volatile
	line	442
	
l352:	
	return
	opt stack 0
GLOBAL	__end_of_Sense_Pins_AsSink
	__end_of_Sense_Pins_AsSink:
	signat	_Sense_Pins_AsSink,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 109 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   21[BANK0 ] unsigned long 
;;  temp_x10        2   27[BANK0 ] unsigned int 
;;  ntcVal          2   25[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   56[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/A00
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	109
global __ptext16
__ptext16:	;psect for function _Read_Temperature
psect	text16
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	109
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 4
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	114
	
l4465:	
;charge_mgr.c: 111: unsigned int ntcVal;
;charge_mgr.c: 112: unsigned int temp_x10;
;charge_mgr.c: 114: test_adc = ADC_Sample(18, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_test_adc)^080h
	line	115
	
l4467:	
;charge_mgr.c: 115: if(0xA5 != test_adc)
		movlw	165
	xorwf	((_test_adc)^080h),w
	btfsc	status,2
	goto	u6791
	goto	u6790
u6791:
	goto	l4471
u6790:
	goto	l441
	line	118
	
l4471:	
;charge_mgr.c: 118: ntcVal = adresult;
	movf	(_adresult+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Read_Temperature@ntcVal+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Read_Temperature@ntcVal)
	line	119
;charge_mgr.c: 119: if(ntcVal < 100 || ntcVal > 3996)
	movlw	0
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u6801
	goto	u6800
u6801:
	goto	l441
u6800:
	
l4473:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u6811
	goto	u6810
u6811:
	goto	l4475
u6810:
	goto	l441
	line	124
	
l4475:	
;charge_mgr.c: 122: {
;charge_mgr.c: 123: unsigned long rt;
;charge_mgr.c: 124: rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	010h
	movwf	(___lldiv@divisor+1)
	movlw	0
	movwf	(___lldiv@divisor)

	movf	(Read_Temperature@ntcVal),w
	movwf	((??_Read_Temperature+0)+0)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((??_Read_Temperature+0)+0+1)
	clrf	((??_Read_Temperature+0)+0+2)
	clrf	((??_Read_Temperature+0)+0+3)
	movf	0+(??_Read_Temperature+0)+0,w
	subwf	(___lldiv@divisor),f
	movf	1+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)+0,w
	goto	u6825
	goto	u6826
u6825:
	subwf	(___lldiv@divisor+1),f
u6826:
	movf	2+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)+0,w
	goto	u6827
	goto	u6828
u6827:
	subwf	(___lldiv@divisor+2),f
u6828:
	movf	3+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)+0,w
	goto	u6829
	goto	u6820
u6829:
	subwf	(___lldiv@divisor+3),f
u6820:

	movf	(Read_Temperature@ntcVal),w
	movwf	(___lmul@multiplier)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	027h
	movwf	(___lmul@multiplicand+1)
	movlw	010h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Read_Temperature@rt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Read_Temperature@rt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@rt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@rt)

	line	125
	
l4477:	
;charge_mgr.c: 125: if(rt >= 10000UL)
		movf	(Read_Temperature@rt+3),w
	btfss	status,2
	goto	u6830
	movf	(Read_Temperature@rt+2),w
	btfss	status,2
	goto	u6830
	movlw	39
	subwf	(Read_Temperature@rt+1),w
	skipz
	goto	u6833
	movlw	16
	subwf	(Read_Temperature@rt),w
	skipz
	goto	u6833
u6833:
	btfss	status,0
	goto	u6831
	goto	u6830

u6831:
	goto	l4483
u6830:
	line	126
	
l4479:	
;charge_mgr.c: 126: temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l4481:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0F0h
	movwf	((??_Read_Temperature+0)+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+3)
	movf	(Read_Temperature@rt),w
	addwf	(??_Read_Temperature+0)+0,f
	movf	(Read_Temperature@rt+1),w
	skipnc
	incfsz	(Read_Temperature@rt+1),w
	goto	u6840
	goto	u6841
u6840:
	addwf	(??_Read_Temperature+0)+1,f
u6841:
	movf	(Read_Temperature@rt+2),w
	skipnc
	incfsz	(Read_Temperature@rt+2),w
	goto	u6842
	goto	u6843
u6842:
	addwf	(??_Read_Temperature+0)+2,f
u6843:
	movf	(Read_Temperature@rt+3),w
	skipnc
	incf	(Read_Temperature@rt+3),w
	addwf	(??_Read_Temperature+0)+3,f
	movf	3+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+3)
	movf	2+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+2)
	movf	1+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+1)
	movf	0+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier)

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(0+(?___lldiv)),w
	subwf	(Read_Temperature@temp_x10),f
	movf	(1+(?___lldiv)),w
	skipc
	decf	(Read_Temperature@temp_x10+1),f
	subwf	(Read_Temperature@temp_x10+1),f
	goto	l4487
	line	128
	
l4483:	
;charge_mgr.c: 127: else
;charge_mgr.c: 128: temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0
	movwf	(___lmul@multiplier+3)
	movlw	0
	movwf	(___lmul@multiplier+2)
	movlw	027h
	movwf	(___lmul@multiplier+1)
	movlw	010h
	movwf	(___lmul@multiplier)

	movf	(Read_Temperature@rt),w
	subwf	(___lmul@multiplier),f
	movf	(Read_Temperature@rt+1),w
	skipc
	incfsz	(Read_Temperature@rt+1),w
	goto	u6855
	goto	u6856
u6855:
	subwf	(___lmul@multiplier+1),f
u6856:
	movf	(Read_Temperature@rt+2),w
	skipc
	incfsz	(Read_Temperature@rt+2),w
	goto	u6857
	goto	u6858
u6857:
	subwf	(___lmul@multiplier+2),f
u6858:
	movf	(Read_Temperature@rt+3),w
	skipc
	incfsz	(Read_Temperature@rt+3),w
	goto	u6859
	goto	u6850
u6859:
	subwf	(___lmul@multiplier+3),f
u6850:

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10)
	
l4485:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10),f
	skipnc
	incf	(Read_Temperature@temp_x10+1),f
	line	129
	
l4487:	
;charge_mgr.c: 129: if(temp_x10 < 100U) temp_x10 = 100U;
	movlw	0
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipnc
	goto	u6861
	goto	u6860
u6861:
	goto	l447
u6860:
	
l4489:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l447:	
	line	130
;charge_mgr.c: 130: if(temp_x10 > 750U) temp_x10 = 750U;
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipc
	goto	u6871
	goto	u6870
u6871:
	goto	l4493
u6870:
	
l4491:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)
	movlw	02h
	movwf	((Read_Temperature@temp_x10))+1
	line	134
	
l4493:	
;charge_mgr.c: 134: if((temp_x10 / 10U) >= 60)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u6881
	goto	u6880
u6881:
	goto	l4497
u6880:
	line	135
	
l4495:	
;charge_mgr.c: 135: g_tempProtect = 1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	incf	(_g_tempProtect)^080h,f
	goto	l441
	line	136
	
l4497:	
;charge_mgr.c: 136: else if((temp_x10 / 10U) <= 50)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bcf	status, 5	;RP0=0, select bank0
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u6891
	goto	u6890
u6891:
	goto	l441
u6890:
	line	137
	
l4499:	
;charge_mgr.c: 137: g_tempProtect = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	line	140
	
l441:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] unsigned int 
;;  dividend        2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] unsigned int 
;;  counter         1    8[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/100
;;		On exit  : 200/0
;;		Unchanged: 200/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         3       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         7       0       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Read_Temperature
;;		_Detect_Classify
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext17
__ptext17:	;psect for function ___lwdiv
psect	text17
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l3069:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l3071:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u3801
	goto	u3800
u3801:
	goto	l3091
u3800:
	line	16
	
l3073:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l3077
	line	18
	
l3075:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l3077:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u3811
	goto	u3810
u3811:
	goto	l3075
u3810:
	line	22
	
l3079:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l3081:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u3825
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u3825:
	skipc
	goto	u3821
	goto	u3820
u3821:
	goto	l3087
u3820:
	line	24
	
l3083:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l3085:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l3087:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l3089:	
	decfsz	(___lwdiv@counter),f
	goto	u3831
	goto	u3830
u3831:
	goto	l3079
u3830:
	line	30
	
l3091:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l1192:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    2[COMMON] unsigned long 
;;  multiplicand    4    6[COMMON] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    0[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    2[COMMON] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         8       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       4       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Route_DetectLi
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext18
__ptext18:	;psect for function ___lmul
psect	text18
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 2
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l2981:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l864:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u3671
	goto	u3670
u3671:
	goto	l2985
u3670:
	line	122
	
l2983:	
	movf	(___lmul@multiplicand),w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3681
	addwf	(___lmul@product+1),f
u3681:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3682
	addwf	(___lmul@product+2),f
u3682:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3683
	addwf	(___lmul@product+3),f
u3683:

	line	123
	
l2985:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l2987:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u3691
	goto	u3690
u3691:
	goto	l864
u3690:
	line	128
	
l2989:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l867:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    4[BANK0 ] unsigned long 
;;  dividend        4    8[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   12[BANK0 ] unsigned long 
;;  counter         1   16[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    4[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      13       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Get_Vcc
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Route_DetectLi
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext19
__ptext19:	;psect for function ___lldiv
psect	text19
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 4
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l2993:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l2995:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u3701
	goto	u3700
u3701:
	goto	l3015
u3700:
	line	16
	
l2997:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l3001
	line	18
	
l2999:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l3001:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u3711
	goto	u3710
u3711:
	goto	l2999
u3710:
	line	22
	
l3003:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l3005:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u3725
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u3725
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u3725
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u3725:
	skipc
	goto	u3721
	goto	u3720
u3721:
	goto	l3011
u3720:
	line	24
	
l3007:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l3009:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l3011:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l3013:	
	decfsz	(___lldiv@counter),f
	goto	u3731
	goto	u3730
u3731:
	goto	l3003
u3730:
	line	30
	
l3015:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l1139:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    2[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    1[BANK0 ] unsigned char 
;;  j               1    0[BANK0 ] unsigned char 
;;  adsum           4    3[BANK0 ] volatile unsigned long 
;;  ad_temp         2   11[BANK0 ] volatile unsigned int 
;;  admax           2    9[BANK0 ] volatile unsigned int 
;;  admin           2    7[BANK0 ] volatile unsigned int 
;;  i               1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/900
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      13       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Get_Vcc
;;		_Adc_Norm
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext20
__ptext20:	;psect for function _ADC_Sample
psect	text20
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(ADC_Sample@adch)
	line	51
	
l2915:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	52
	
l2917:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	58
	
l2919:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u3521
	goto	u3520
u3521:
	goto	l2925
u3520:
	
l2921:	
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u3531
	goto	u3530
u3531:
	goto	l2925
u3530:
	line	60
	
l2923:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??_ADC_Sample+0)+0),f
	u9747:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u9747
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	l2927
	line	64
	
l2925:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	67
	
l2927:	
;adc_drv.c: 67: if(adch & 0x10)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(ADC_Sample@adch),(4)&7
	goto	u3541
	goto	u3540
u3541:
	goto	l381
u3540:
	line	69
	
l2929:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l2931:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(ADC_Sample@adch),f
	line	71
;adc_drv.c: 71: }
	goto	l2933
	line	72
	
l381:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l2933:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@i)
	line	79
	
l2939:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(ADC_Sample@adch),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u3555:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u3555
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l2941:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	6
movwf	((??_ADC_Sample+0)+0),f
	u9757:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u9757
	nop
opt asmopt_pop

	line	81
	
l2943:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l2945:	
;adc_drv.c: 84: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	l385
	
l386:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u3561
	goto	u3560
u3561:
	goto	l385
u3560:
	line	89
	
l2947:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	l388
	line	90
	
l385:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u3571
	goto	u3570
u3571:
	goto	l386
u3570:
	line	93
	
l2951:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
l2953:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
l2955:	
;adc_drv.c: 96: if(0 == admax)
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u3581
	goto	u3580
u3581:
	goto	l2959
u3580:
	line	98
	
l2957:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	100
;adc_drv.c: 100: }
	goto	l391
	line	102
	
l2959:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u3595
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u3595:
	skipnc
	goto	u3591
	goto	u3590
u3591:
	goto	l2963
u3590:
	line	103
	
l2961:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	l391
	line	105
	
l2963:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u3605
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u3605:
	skipnc
	goto	u3601
	goto	u3600
u3601:
	goto	l391
u3600:
	line	106
	
l2965:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	108
	
l391:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3611
	addwf	(ADC_Sample@adsum+1),f	;volatile
u3611:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3612
	addwf	(ADC_Sample@adsum+2),f	;volatile
u3612:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3613
	addwf	(ADC_Sample@adsum+3),f	;volatile
u3613:

	line	76
	
l2967:	
	incf	(ADC_Sample@i),f
	
l2969:	
	movlw	low(022h)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u3621
	goto	u3620
u3621:
	goto	l2939
u3620:
	line	112
	
l2971:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u3635
	goto	u3636
u3635:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u3636:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u3637
	goto	u3638
u3637:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u3638:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u3639
	goto	u3630
u3639:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u3630:

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u3645
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u3645
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u3645
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u3645:
	skipc
	goto	u3641
	goto	u3640
u3641:
	goto	l395
u3640:
	line	114
	
l2973:	
;adc_drv.c: 114: adsum -= admin;
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u3655
	goto	u3656
u3655:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u3656:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u3657
	goto	u3658
u3657:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u3658:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u3659
	goto	u3650
u3659:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u3650:

	goto	l2975
	line	115
	
l395:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	118
	
l2975:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u3665:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u3660:
	addlw	-1
	skipz
	goto	u3665
	movf	1+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_adresult+1)^080h
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)^080h
	line	119
	
l2977:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
l388:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 1500 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    8[BANK0 ] unsigned int 
;;  s               1   19[BANK0 ] unsigned char 
;;  duty            2   16[BANK0 ] int 
;;  error           2   12[BANK0 ] int 
;;  adjust          2    2[BANK0 ] int 
;;  duty_initial    1   15[BANK0 ] unsigned char 
;;  duty_target     1   14[BANK0 ] unsigned char 
;;  maxV            2   10[BANK0 ] unsigned int 
;;  i               1   18[BANK0 ] unsigned char 
;;  preCount        1    7[BANK0 ] unsigned char 
;;  ccCount         1    6[BANK0 ] unsigned char 
;;  cvCount         1    5[BANK0 ] unsigned char 
;;  hasCharging     1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          0       2       0       0       0
;;      Totals:         0      20       0       0       0
;;Total ram usage:       20 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___awdiv
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1500
global __ptext21
__ptext21:	;psect for function _CCCV_Control
psect	text21
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1500
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 4
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1503
	
l5571:	
;charge_mgr.c: 1502: unsigned char i;
;charge_mgr.c: 1503: unsigned char hasCharging = 0;
	clrf	(CCCV_Control@hasCharging)
	line	1504
;charge_mgr.c: 1504: unsigned int maxV = 0;
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	1505
;charge_mgr.c: 1505: unsigned char cvCount = 0;
	clrf	(CCCV_Control@cvCount)
	line	1506
;charge_mgr.c: 1506: unsigned char ccCount = 0;
	clrf	(CCCV_Control@ccCount)
	line	1507
;charge_mgr.c: 1507: unsigned char preCount = 0;
	clrf	(CCCV_Control@preCount)
	line	1510
	
l5573:	
;charge_mgr.c: 1510: if(g_vccProtect)
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u9411
	goto	u9410
u9411:
	goto	l5579
u9410:
	line	1512
	
l5575:	
;charge_mgr.c: 1511: {
;charge_mgr.c: 1512: if(g_vcc_mv >= 4600)
	movlw	011h
	subwf	(_g_vcc_mv+1)^080h,w
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv)^080h,w
	skipc
	goto	u9421
	goto	u9420
u9421:
	goto	l5583
u9420:
	line	1513
	
l5577:	
;charge_mgr.c: 1513: g_vccProtect = 0;
	clrf	(_g_vccProtect)^080h
	goto	l5583
	line	1517
	
l5579:	
;charge_mgr.c: 1515: else
;charge_mgr.c: 1516: {
;charge_mgr.c: 1517: if(g_vcc_mv < 4400)
	movlw	011h
	subwf	(_g_vcc_mv+1)^080h,w
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv)^080h,w
	skipnc
	goto	u9431
	goto	u9430
u9431:
	goto	l5583
u9430:
	line	1518
	
l5581:	
;charge_mgr.c: 1518: g_vccProtect = 1;
	clrf	(_g_vccProtect)^080h
	incf	(_g_vccProtect)^080h,f
	line	1522
	
l5583:	
;charge_mgr.c: 1519: }
;charge_mgr.c: 1522: if(g_tempProtect || g_vccProtect)
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u9441
	goto	u9440
u9441:
	goto	l5587
u9440:
	
l5585:	
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u9451
	goto	u9450
u9451:
	goto	l5591
u9450:
	line	1524
	
l5587:	
;charge_mgr.c: 1523: {
;charge_mgr.c: 1524: g_pwmDuty = 0;
	clrf	(_g_pwmDuty)	;volatile
	line	1525
;charge_mgr.c: 1525: g_cvIntegral = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	l794
	line	1530
	
l5591:	
;charge_mgr.c: 1527: }
;charge_mgr.c: 1530: for(i = 0; i < 12; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(CCCV_Control@i)
	line	1532
	
l5597:	
;charge_mgr.c: 1531: {
;charge_mgr.c: 1532: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	1536
	
l5599:	
;charge_mgr.c: 1534: if(s == 2 || s == 3 ||
;charge_mgr.c: 1535: s == 4 || s == 5 ||
;charge_mgr.c: 1536: s == 8)
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9461
	goto	u9460
u9461:
	goto	l799
u9460:
	
l5601:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9471
	goto	u9470
u9471:
	goto	l799
u9470:
	
l5603:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9481
	goto	u9480
u9481:
	goto	l799
u9480:
	
l5605:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9491
	goto	u9490
u9491:
	goto	l799
u9490:
	
l5607:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9501
	goto	u9500
u9501:
	goto	l797
u9500:
	
l799:	
	line	1538
;charge_mgr.c: 1537: {
;charge_mgr.c: 1538: hasCharging = 1;
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	1540
	
l5609:	
;charge_mgr.c: 1539: {
;charge_mgr.c: 1540: unsigned int vt = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	1541
	
l5611:	
;charge_mgr.c: 1541: if(vt > maxV) maxV = vt;
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u9515
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u9515:
	skipnc
	goto	u9511
	goto	u9510
u9511:
	goto	l5615
u9510:
	
l5613:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	1543
	
l5615:	
;charge_mgr.c: 1542: }
;charge_mgr.c: 1543: if(s == 5)
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9521
	goto	u9520
u9521:
	goto	l5619
u9520:
	line	1544
	
l5617:	
;charge_mgr.c: 1544: cvCount++;
	incf	(CCCV_Control@cvCount),f
	line	1545
	
l5619:	
;charge_mgr.c: 1545: if(s == 4)
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9531
	goto	u9530
u9531:
	goto	l5623
u9530:
	line	1546
	
l5621:	
;charge_mgr.c: 1546: ccCount++;
	incf	(CCCV_Control@ccCount),f
	line	1547
	
l5623:	
;charge_mgr.c: 1547: if(s == 3 || s == 2)
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9541
	goto	u9540
u9541:
	goto	l5627
u9540:
	
l5625:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9551
	goto	u9550
u9551:
	goto	l797
u9550:
	line	1548
	
l5627:	
;charge_mgr.c: 1548: preCount++;
	incf	(CCCV_Control@preCount),f
	line	1549
	
l797:	
	line	1530
	incf	(CCCV_Control@i),f
	
l5629:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u9561
	goto	u9560
u9561:
	goto	l5597
u9560:
	line	1553
	
l5631:	
;charge_mgr.c: 1549: }
;charge_mgr.c: 1550: }
;charge_mgr.c: 1553: if(!hasCharging)
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u9571
	goto	u9570
u9571:
	goto	l5637
u9570:
	goto	l5587
	line	1564
	
l5637:	
;charge_mgr.c: 1558: }
;charge_mgr.c: 1564: if(cvCount == 0)
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u9581
	goto	u9580
u9581:
	goto	l5667
u9580:
	line	1568
	
l5639:	
;charge_mgr.c: 1565: {
;charge_mgr.c: 1566: unsigned char duty_target, duty_initial;
;charge_mgr.c: 1568: if(ccCount > 0)
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u9591
	goto	u9590
u9591:
	goto	l5643
u9590:
	line	1571
	
l5641:	
;charge_mgr.c: 1569: {
;charge_mgr.c: 1571: duty_target = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	1572
;charge_mgr.c: 1572: duty_initial = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	1573
;charge_mgr.c: 1573: }
	goto	l5651
	line	1574
	
l5643:	
;charge_mgr.c: 1574: else if(preCount > 0)
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u9601
	goto	u9600
u9601:
	goto	l5647
u9600:
	line	1577
	
l5645:	
;charge_mgr.c: 1575: {
;charge_mgr.c: 1577: duty_target = 8;
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	1578
;charge_mgr.c: 1578: duty_initial = 5;
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	1579
;charge_mgr.c: 1579: }
	goto	l5651
	line	1584
	
l5647:	
;charge_mgr.c: 1580: else
;charge_mgr.c: 1581: {
;charge_mgr.c: 1584: g_pwmDuty = 25;
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	l794
	line	1588
	
l5651:	
;charge_mgr.c: 1586: }
;charge_mgr.c: 1588: if(g_pwmDuty < duty_initial)
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u9611
	goto	u9610
u9611:
	goto	l5659
u9610:
	line	1591
	
l5653:	
;charge_mgr.c: 1589: {
;charge_mgr.c: 1591: g_pwmDuty += 3;
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	1592
	
l5655:	
;charge_mgr.c: 1592: if(g_pwmDuty > duty_initial)
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u9621
	goto	u9620
u9621:
	goto	l794
u9620:
	line	1593
	
l5657:	
;charge_mgr.c: 1593: g_pwmDuty = duty_initial;
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	l794
	line	1595
	
l5659:	
	line	1598
	
l5661:	
;charge_mgr.c: 1596: {
;charge_mgr.c: 1598: g_pwmDuty = duty_target;
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	1599
;charge_mgr.c: 1599: }
	goto	l794
	line	1614
	
l5667:	
;charge_mgr.c: 1606: }
;charge_mgr.c: 1613: {
;charge_mgr.c: 1614: int error = (int)(3100) - (int)(maxV);
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	1617
;charge_mgr.c: 1617: g_cvIntegral += error * 1;
	movf	(CCCV_Control@error),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral)^080h,f
	skipnc
	incf	(_g_cvIntegral+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(CCCV_Control@error+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral+1)^080h,f
	line	1618
	
l5669:	
;charge_mgr.c: 1618: if(g_cvIntegral > 200)
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u9635
	movlw	0C9h
	subwf	(_g_cvIntegral)^080h,w
u9635:

	skipc
	goto	u9631
	goto	u9630
u9631:
	goto	l5673
u9630:
	line	1619
	
l5671:	
;charge_mgr.c: 1619: g_cvIntegral = 200;
	movlw	0C8h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	l5677
	line	1620
	
l5673:	
;charge_mgr.c: 1620: else if(g_cvIntegral < -200)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u9645
	movlw	038h
	subwf	(_g_cvIntegral)^080h,w
u9645:

	skipnc
	goto	u9641
	goto	u9640
u9641:
	goto	l5677
u9640:
	line	1621
	
l5675:	
;charge_mgr.c: 1621: g_cvIntegral = -200;
	movlw	038h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	movlw	0FFh
	movwf	((_g_cvIntegral)^080h)+1
	line	1624
	
l5677:	
;charge_mgr.c: 1624: int adjust = (error * 4 + g_cvIntegral) / 8;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_cvIntegral)^080h,w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1)^080h,w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	1625
	
l5679:	
;charge_mgr.c: 1625: int duty = (int)g_pwmDuty + adjust;
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
l5681:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	1628
	
l5683:	
;charge_mgr.c: 1628: if(duty > 32) duty = 32;
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u9655
	movlw	021h
	subwf	(CCCV_Control@duty),w
u9655:

	skipc
	goto	u9651
	goto	u9650
u9651:
	goto	l5687
u9650:
	
l5685:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1629
	
l5687:	
;charge_mgr.c: 1629: if(duty < 0) duty = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u9661
	goto	u9660
u9661:
	goto	l5691
u9660:
	
l5689:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1631
	
l5691:	
;charge_mgr.c: 1631: g_pwmDuty = (unsigned char)duty;
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	1633
	
l794:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    2[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    4[COMMON] unsigned char 
;;  product         1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Slot_Charge_Ctrl
;;		_CCCV_Control
;;		_Update_LED_Global
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext22
__ptext22:	;psect for function ___bmul
psect	text22
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	movwf	(___bmul@multiplier)
	line	6
	
l3265:	
	clrf	(___bmul@product)
	line	43
	
l3267:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u4091
	goto	u4090
u4091:
	goto	l3271
u4090:
	line	44
	
l3269:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l3271:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l3273:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u4101
	goto	u4100
u4101:
	goto	l3267
u4100:
	line	50
	
l3275:	
	movf	(___bmul@product),w
	line	51
	
l873:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] int 
;;  dividend        2    4[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    8[COMMON] int 
;;  sign            1    7[COMMON] unsigned char 
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext23
__ptext23:	;psect for function ___awdiv
psect	text23
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 4
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
l3279:	
	clrf	(___awdiv@sign)
	line	15
	
l3281:	
	btfss	(___awdiv@divisor+1),7
	goto	u4111
	goto	u4110
u4111:
	goto	l3287
u4110:
	line	16
	
l3283:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
l3285:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
l3287:	
	btfss	(___awdiv@dividend+1),7
	goto	u4121
	goto	u4120
u4121:
	goto	l3293
u4120:
	line	20
	
l3289:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
l3291:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
l3293:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
l3295:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u4131
	goto	u4130
u4131:
	goto	l3315
u4130:
	line	25
	
l3297:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	l3301
	line	27
	
l3299:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
l3301:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u4141
	goto	u4140
u4141:
	goto	l3299
u4140:
	line	31
	
l3303:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
l3305:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u4155
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u4155:
	skipc
	goto	u4151
	goto	u4150
u4151:
	goto	l3311
u4150:
	line	33
	
l3307:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
l3309:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
l3311:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
l3313:	
	decfsz	(___awdiv@counter),f
	goto	u4161
	goto	u4160
u4161:
	goto	l3303
u4160:
	line	39
	
l3315:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u4171
	goto	u4170
u4171:
	goto	l3319
u4170:
	line	40
	
l3317:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
l3319:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
l985:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 156 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		_PowerOnLedSequence
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	156
global __ptext24
__ptext24:	;psect for function _Isr_Timer
psect	text24
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	156
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 2
; Regs used in _Isr_Timer: [wreg+status,2+status,0+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Isr_Timer+0)
	movf	pclath,w
	movwf	(??_Isr_Timer+1)
	ljmp	_Isr_Timer
psect	text24
	line	159
	
i1l4503:	
;main.c: 159: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u690_21
	goto	u690_20
u690_21:
	goto	i1l345
u690_20:
	line	161
	
i1l4505:	
;main.c: 160: {
;main.c: 161: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	162
	
i1l4507:	
;main.c: 162: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(129)^080h	;volatile
	line	163
# 163 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text24
	line	166
	
i1l4509:	
;main.c: 166: g_pwmCounter++;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(_g_pwmCounter)^080h,f	;volatile
	line	167
	
i1l4511:	
;main.c: 167: if(g_pwmCounter >= 32)
	movlw	low(020h)
	subwf	(_g_pwmCounter)^080h,w	;volatile
	skipc
	goto	u691_21
	goto	u691_20
u691_21:
	goto	i1l4515
u691_20:
	line	168
	
i1l4513:	
;main.c: 168: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)^080h	;volatile
	line	170
	
i1l4515:	
;main.c: 170: if(g_pwmDuty > 0 && g_pwmCounter < g_pwmDuty)
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u692_21
	goto	u692_20
u692_21:
	goto	i1l340
u692_20:
	
i1l4517:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter)^080h,w	;volatile
	skipnc
	goto	u693_21
	goto	u693_20
u693_21:
	goto	i1l340
u693_20:
	line	171
	
i1l4519:	
;main.c: 171: RB7 = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(55/8),(55)&7	;volatile
	goto	i1l4521
	line	172
	
i1l340:	
	line	173
;main.c: 172: else
;main.c: 173: RB7 = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(55/8),(55)&7	;volatile
	line	179
	
i1l4521:	
;main.c: 179: if(++g_hwTickDiv >= 80U)
	movlw	low(050h)
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_hwTickDiv)^080h,f	;volatile
	subwf	((_g_hwTickDiv)^080h),w	;volatile
	skipc
	goto	u694_21
	goto	u694_20
u694_21:
	goto	i1l4531
u694_20:
	line	181
	
i1l4523:	
;main.c: 180: {
;main.c: 181: g_hwTickDiv = 0;
	clrf	(_g_hwTickDiv)^080h	;volatile
	line	182
	
i1l4525:	
;main.c: 182: g_hwTick++;
	incf	(_g_hwTick)^080h,f	;volatile
	skipnz
	incf	(_g_hwTick+1)^080h,f	;volatile
	line	183
	
i1l4527:	
;main.c: 183: if(g_powerOnPhase < 2U)
	movlw	low(02h)
	subwf	(_g_powerOnPhase)^080h,w
	skipnc
	goto	u695_21
	goto	u695_20
u695_21:
	goto	i1l4531
u695_20:
	line	184
	
i1l4529:	
;main.c: 184: g_powerOnTimer++;
	incf	(_g_powerOnTimer)^080h,f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1)^080h,f	;volatile
	line	198
	
i1l4531:	
;main.c: 192: }
;main.c: 198: if(g_powerOnPhase < 2)
	movlw	low(02h)
	subwf	(_g_powerOnPhase)^080h,w	;volatile
	skipnc
	goto	u696_21
	goto	u696_20
u696_21:
	goto	i1l4537
u696_20:
	line	200
	
i1l4533:	
;main.c: 199: {
;main.c: 200: PowerOnLedSequence();
	fcall	_PowerOnLedSequence
	goto	i1l345
	line	205
	
i1l4537:	
;main.c: 202: }
;main.c: 205: if(g_tempPhase == 0)
	movf	((_g_tempPhase)^080h),w	;volatile
	btfss	status,2
	goto	u697_21
	goto	u697_20
u697_21:
	goto	i1l4549
u697_20:
	line	207
	
i1l4539:	
;main.c: 206: {
;main.c: 207: g_tempReadRoundCnt++;
	incf	(_g_tempReadRoundCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1)^080h,f	;volatile
	line	208
	
i1l4541:	
;main.c: 208: if(g_tempReadRoundCnt >= 200)
	movlw	0
	subwf	(_g_tempReadRoundCnt+1)^080h,w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt)^080h,w	;volatile
	skipc
	goto	u698_21
	goto	u698_20
u698_21:
	goto	i1l345
u698_20:
	line	210
	
i1l4543:	
;main.c: 209: {
;main.c: 210: g_tempReadRoundCnt = 0;
	clrf	(_g_tempReadRoundCnt)^080h	;volatile
	clrf	(_g_tempReadRoundCnt+1)^080h	;volatile
	line	211
	
i1l4545:	
;main.c: 211: g_tempPhase = 1;
	movlw	low(01h)
	movwf	(_g_tempPhase)^080h	;volatile
	line	212
	
i1l4547:	
;main.c: 212: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	goto	i1l345
	line	217
	
i1l4549:	
;main.c: 215: else
;main.c: 216: {
;main.c: 217: g_tempSettleCnt++;
	incf	(_g_tempSettleCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1)^080h,f	;volatile
	line	218
	
i1l4551:	
;main.c: 218: if(g_tempSettleCnt >= 60)
	movlw	0
	subwf	(_g_tempSettleCnt+1)^080h,w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt)^080h,w	;volatile
	skipc
	goto	u699_21
	goto	u699_20
u699_21:
	goto	i1l345
u699_20:
	line	220
	
i1l4553:	
;main.c: 219: {
;main.c: 220: g_doNtcRead = 1;
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	221
	
i1l4555:	
;main.c: 221: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	line	222
;main.c: 222: g_tempPhase = 0;
	clrf	(_g_tempPhase)^080h	;volatile
	line	226
	
i1l345:	
	movf	(??_Isr_Timer+1),w
	movwf	pclath
	swapf	(??_Isr_Timer+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 137 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	137
global __ptext25
__ptext25:	;psect for function _PowerOnLedSequence
psect	text25
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	137
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 2
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	141
	
i1l3399:	
;led.c: 141: if(g_powerOnPhase == 0)
	movf	((_g_powerOnPhase)^080h),w	;volatile
	btfss	status,2
	goto	u419_21
	goto	u419_20
u419_21:
	goto	i1l3409
u419_20:
	line	145
	
i1l3401:	
;led.c: 142: {
;led.c: 145: RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	146
;led.c: 146: RC4 = 0;
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	147
	
i1l3403:	
;led.c: 147: if(g_powerOnTimer >= 100)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u420_21
	goto	u420_20
u420_21:
	goto	i1l849
u420_20:
	line	149
	
i1l3405:	
;led.c: 148: {
;led.c: 149: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)^080h	;volatile
	clrf	(_g_powerOnTimer+1)^080h	;volatile
	line	150
	
i1l3407:	
;led.c: 150: g_powerOnPhase = 1;
	movlw	low(01h)
	movwf	(_g_powerOnPhase)^080h	;volatile
	goto	i1l849
	line	153
	
i1l3409:	
;led.c: 153: else if(g_powerOnPhase == 1)
		decf	((_g_powerOnPhase)^080h),w	;volatile
	btfss	status,2
	goto	u421_21
	goto	u421_20
u421_21:
	goto	i1l849
u421_20:
	line	156
	
i1l3411:	
;led.c: 154: {
;led.c: 156: RC5 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	157
;led.c: 157: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	158
	
i1l3413:	
;led.c: 158: if(g_powerOnTimer >= 100)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u422_21
	goto	u422_20
u422_21:
	goto	i1l849
u422_20:
	line	160
	
i1l3415:	
;led.c: 159: {
;led.c: 160: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)^080h	;volatile
	clrf	(_g_powerOnTimer+1)^080h	;volatile
	line	161
	
i1l3417:	
;led.c: 161: g_powerOnPhase = 2;
	movlw	low(02h)
	movwf	(_g_powerOnPhase)^080h	;volatile
	line	165
	
i1l849:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
