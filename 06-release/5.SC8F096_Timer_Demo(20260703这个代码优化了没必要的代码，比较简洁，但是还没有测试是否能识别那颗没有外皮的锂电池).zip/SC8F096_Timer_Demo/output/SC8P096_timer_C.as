opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ChargeProcess_Slot
	FNCALL	_main,_Do_AdcSample
	FNCALL	_main,_Do_NtcRead
	FNCALL	_main,_Print_DetectLog
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_System_Init
	FNCALL	_main,___bmul
	FNCALL	_main,_uart_send_number
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_Print_DetectLog,_uart_send_char
	FNCALL	_Print_DetectLog,_uart_send_number
	FNCALL	_Print_DetectLog,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_Do_NtcRead,_Read_Temperature
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Do_AdcSample,_ADC_Sample
	FNCALL	_Do_AdcSample,___bmul
	FNCALL	_ChargeProcess_Slot,_Detect_BatteryType
	FNCALL	_ChargeProcess_Slot,___bmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_CCCV_Control
	FNCALL	_Isr_Timer,_Charging_Control
	FNCALL	_Isr_Timer,_Led_BlinkProcess
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Update_LED_Slot
	FNCALL	_Update_LED_Slot,i1___bmul
	FNCALL	_Charging_Control,i1___bmul
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,i1___bmul
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_temperature
psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	9

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	45
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_dbgNewState
	global	_g_dbgSlot
	global	_g_tempPhase
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_scanPhase
	global	_g_scanIndex
	global	_g_detectLogType
	global	_g_detectLogSlot
	global	_test_adc
	global	_adresult
	global	_g_dbgDetectFlag
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_adcBusy
	global	_g_doAdcSample
	global	_g_detectLogFlag
	global	_g_blinkTimer
	global	_g_blinkPhase
	global	_g_ledState
	global	_g_dbgVoltage
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_powerOnTimer
	global	_g_cvIntegral
	global	_g_tempProtect
	global	_g_dbgNewType
	global	_g_impRefV
	global	_g_slot
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_GIE
_GIE	set	0x5F
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RC4
_RC4	set	0x834
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC5
_RC5	set	0x835
	global	_RC3
_RC3	set	0x833
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_25:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	101	;'e'
	retlw	108	;'l'
	retlw	108	;'l'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	68	;'D'
	retlw	66	;'B'
	retlw	71	;'G'
	retlw	58	;':'
	retlw	32	;' '
	retlw	115	;'s'
	retlw	108	;'l'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_27:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	87	;'W'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_32:	
	retlw	32	;' '
	retlw	118	;'v'
	retlw	114	;'r'
	retlw	102	;'f'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_9:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_29:	
	retlw	32	;' '
	retlw	115	;'s'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_30:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_11:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_31:	
	retlw	32	;' '
	retlw	86	;'V'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
STR_7	equ	STR_2+0
STR_8	equ	STR_3+0
STR_23	equ	STR_27+7
STR_33	equ	STR_27+7
; #config settings
	file	"SC8P096_timer_C.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssBANK0,class=BANK0,bit,space=1,noexec
global __pbitbssBANK0
__pbitbssBANK0:
_g_dbgDetectFlag:
       ds      1

_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

_g_adcBusy:
       ds      1

_g_doAdcSample:
       ds      1

_g_detectLogFlag:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_dbgNewState:
       ds      1

_g_dbgSlot:
       ds      1

_g_tempPhase:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_scanPhase:
       ds      1

_g_scanIndex:
       ds      1

_g_detectLogType:
       ds      1

_g_detectLogSlot:
       ds      1

_test_adc:
       ds      1

_adresult:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_blinkTimer:
       ds      24

_g_blinkPhase:
       ds      12

_g_ledState:
       ds      12

_g_dbgVoltage:
       ds      2

_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_powerOnTimer:
       ds      2

_g_cvIntegral:
       ds      2

_g_tempProtect:
       ds      1

_g_dbgNewType:
       ds      1

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	9
_g_temperature:
       ds      2

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slot:
       ds      72

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_impRefV:
       ds      24

	file	"SC8P096_timer_C.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+018h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+03Eh)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+0Dh)
	fcall	clear_ram0
; Clear objects allocated to BITBANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	clrf	((__pbitbssBANK0/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK2,class=BANK2,space=1,noexec
global __pcstackBANK2
__pcstackBANK2:
	global	_Print_SystemStatus$710
_Print_SystemStatus$710:	; 2 bytes @ 0x0
	ds	2
	global	_Print_SystemStatus$711
_Print_SystemStatus$711:	; 2 bytes @ 0x2
	ds	2
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x4
	ds	4
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x8
	ds	1
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x9
	ds	2
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0xB
	ds	4
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0xF
	ds	4
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x13
	ds	2
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x15
	ds	1
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
??_main:	; 1 bytes @ 0x0
	ds	2
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Update_LED_Slot:	; 1 bytes @ 0x0
?_Charging_Control:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Led_BlinkProcess:	; 1 bytes @ 0x0
??_Led_BlinkProcess:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_ChargeProcess_Slot:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Do_AdcSample:	; 1 bytes @ 0x0
?_Do_NtcRead:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_Print_DetectLog:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?i1___bmul:	; 1 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	i1___bmul@multiplicand
i1___bmul@multiplicand:	; 1 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	ds	1
??i1___bmul:	; 1 bytes @ 0x1
	global	i1___bmul@multiplier
i1___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
	global	Led_BlinkProcess@i
Led_BlinkProcess@i:	; 1 bytes @ 0x2
	global	i1___bmul@product
i1___bmul@product:	; 1 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_Update_LED_Slot:	; 1 bytes @ 0x3
??_Charging_Control:	; 1 bytes @ 0x3
	global	Charging_Control@chargeB1_6
Charging_Control@chargeB1_6:	; 1 bytes @ 0x3
	global	Update_LED_Slot@s
Update_LED_Slot@s:	; 1 bytes @ 0x3
	ds	1
??___awdiv:	; 1 bytes @ 0x4
	global	Charging_Control@chargeB7_12
Charging_Control@chargeB7_12:	; 1 bytes @ 0x4
	global	Update_LED_Slot@idx
Update_LED_Slot@idx:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	ds	1
	global	Charging_Control@s
Charging_Control@s:	; 1 bytes @ 0x5
	global	Update_LED_Slot@led
Update_LED_Slot@led:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	ds	1
	global	Charging_Control@i
Charging_Control@i:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	2
??_CCCV_Control:	; 1 bytes @ 0x8
	ds	2
??_Isr_Timer:	; 1 bytes @ 0xA
	ds	4
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x0
	ds	2
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x2
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x3
	ds	1
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x4
	ds	2
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x6
	ds	2
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0x8
	ds	2
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0xA
	ds	2
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0xC
	ds	1
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0xD
	ds	1
??_AD_Init:	; 1 bytes @ 0xE
??_uart_init:	; 1 bytes @ 0xE
?_ADC_Sample:	; 1 bytes @ 0xE
??_uart_send_char:	; 1 bytes @ 0xE
?_Detect_BatteryType:	; 1 bytes @ 0xE
?___bmul:	; 1 bytes @ 0xE
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0xE
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0xE
	global	?___lmul
?___lmul:	; 4 bytes @ 0xE
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0xE
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0xE
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0xE
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0xE
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0xE
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0xE
	ds	1
??_ADC_Sample:	; 1 bytes @ 0xF
??___bmul:	; 1 bytes @ 0xF
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0xF
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0xF
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x10
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x10
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x10
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x10
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x10
	ds	1
?_uart_send_string:	; 1 bytes @ 0x11
??_ChargeProcess_Slot:	; 1 bytes @ 0x11
??_System_Init:	; 1 bytes @ 0x11
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x11
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x11
	global	ChargeProcess_Slot@delta
ChargeProcess_Slot@delta:	; 2 bytes @ 0x11
	ds	1
??___lwdiv:	; 1 bytes @ 0x12
??___lwmod:	; 1 bytes @ 0x12
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x12
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x12
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x12
	ds	1
??_uart_send_string:	; 1 bytes @ 0x13
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x13
	global	ChargeProcess_Slot@rise
ChargeProcess_Slot@rise:	; 2 bytes @ 0x13
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x13
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x14
	ds	1
?_uart_send_number:	; 1 bytes @ 0x15
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x15
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x15
	global	ChargeProcess_Slot@v_before
ChargeProcess_Slot@v_before:	; 2 bytes @ 0x15
	ds	1
??___lmul:	; 1 bytes @ 0x16
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x16
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x16
	ds	1
??_uart_send_number:	; 1 bytes @ 0x17
	global	ChargeProcess_Slot@v_start
ChargeProcess_Slot@v_start:	; 2 bytes @ 0x17
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x17
	ds	3
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x1A
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x1A
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x1A
	ds	1
	global	ChargeProcess_Slot@st
ChargeProcess_Slot@st:	; 1 bytes @ 0x1B
	ds	1
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x1C
	global	ChargeProcess_Slot@ct
ChargeProcess_Slot@ct:	; 2 bytes @ 0x1C
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0x1D
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x1E
	global	ChargeProcess_Slot@ty
ChargeProcess_Slot@ty:	; 1 bytes @ 0x1E
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0x1E
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x1E
	ds	1
??_Print_NtcTemp:	; 1 bytes @ 0x1F
??_Print_DetectLog:	; 1 bytes @ 0x1F
	global	ChargeProcess_Slot@idx
ChargeProcess_Slot@idx:	; 1 bytes @ 0x1F
	global	_Print_NtcTemp$708
_Print_NtcTemp$708:	; 2 bytes @ 0x1F
	ds	1
??_Do_AdcSample:	; 1 bytes @ 0x20
	global	Do_AdcSample@ch
Do_AdcSample@ch:	; 1 bytes @ 0x20
	global	ChargeProcess_Slot@v
ChargeProcess_Slot@v:	; 2 bytes @ 0x20
	ds	1
	global	_Print_NtcTemp$709
_Print_NtcTemp$709:	; 2 bytes @ 0x21
	ds	1
??___lldiv:	; 1 bytes @ 0x22
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x22
	ds	4
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x26
	ds	1
??_Read_Temperature:	; 1 bytes @ 0x27
??_Print_SystemStatus:	; 1 bytes @ 0x27
	ds	4
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x2B
	ds	4
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x2F
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x31
	ds	2
??_Do_NtcRead:	; 1 bytes @ 0x33
	global	main@slot
main@slot:	; 1 bytes @ 0x33
	ds	1
;!
;!Data Sizes:
;!    Strings     268
;!    Constant    12
;!    Data        2
;!    BSS         171
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     14      14
;!    BANK0            80     52      66
;!    BANK1            80      2      66
;!    BANK3            80      0      72
;!    BANK2            80     22      46

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 37
;!		 -> STR_33(CODE[3]), STR_32(CODE[7]), STR_31(CODE[4]), STR_30(CODE[5]), 
;!		 -> STR_29(CODE[5]), STR_28(CODE[11]), STR_27(CODE[10]), STR_26(CODE[21]), 
;!		 -> STR_25(CODE[37]), STR_24(CODE[33]), STR_23(CODE[3]), STR_22(CODE[6]), 
;!		 -> STR_21(CODE[8]), STR_20(CODE[6]), STR_19(CODE[6]), STR_18(CODE[7]), 
;!		 -> STR_17(CODE[5]), STR_16(CODE[5]), STR_15(CODE[6]), STR_14(CODE[6]), 
;!		 -> STR_13(CODE[6]), STR_12(CODE[7]), STR_11(CODE[4]), STR_10(CODE[6]), 
;!		 -> STR_9(CODE[6]), STR_8(CODE[4]), STR_7(CODE[2]), STR_6(CODE[6]), 
;!		 -> STR_5(CODE[5]), STR_4(CODE[29]), STR_3(CODE[4]), STR_2(CODE[2]), 
;!		 -> STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->_CCCV_Control
;!    _Update_LED_Slot->i1___bmul
;!    _Charging_Control->i1___bmul
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _main in BANK0
;!
;!    _System_Init->___bmul
;!    _Print_SystemStatus->___lldiv
;!    _Print_NtcTemp->_uart_send_number
;!    _Print_DetectLog->_uart_send_number
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _Do_NtcRead->_Read_Temperature
;!    _Read_Temperature->___lldiv
;!    ___lldiv->___lmul
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->___bmul
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    _Isr_Timer->_CCCV_Control
;!
;!Critical Paths under _main in BANK1
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    _main->_Print_SystemStatus
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 3     3      0   36852
;!                                             51 BANK0      1     1      0
;!                                              0 BANK1      2     2      0
;!                 _ChargeProcess_Slot
;!                       _Do_AdcSample
;!                         _Do_NtcRead
;!                    _Print_DetectLog
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                        _System_Init
;!                             ___bmul
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1116
;!                                             17 BANK0      1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  30    30      0   10140
;!                                             39 BANK0      8     8      0
;!                                              0 BANK2     22    22      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    5811
;!                                             31 BANK0      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_DetectLog                                      0     0      0    4878
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    2312
;!                                             17 BANK0      2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_number                                    10     8      2    2464
;!                                             21 BANK0     10     8      2
;!                             ___bmul (ARG)
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     102
;!                                             14 BANK0      3     3      0
;! ---------------------------------------------------------------------------------
;! (2) ___lwmod                                              5     1      4     378
;!                                             14 BANK0      5     1      4
;! ---------------------------------------------------------------------------------
;! (1) _Do_NtcRead                                           0     0      0    3892
;!                   _Read_Temperature
;! ---------------------------------------------------------------------------------
;! (2) _Read_Temperature                                    12    12      0    3892
;!                                             39 BANK0     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (2) ___lwdiv                                              7     3      4     647
;!                                             14 BANK0      7     3      4
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8    1077
;!                                             14 BANK0     12     4      8
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8     800
;!                                             26 BANK0     13     5      8
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (1) _Do_AdcSample                                         1     1      0    1762
;!                                             32 BANK0      1     1      0
;!                         _ADC_Sample
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) _ADC_Sample                                          18    17      1     965
;!                                             14 BANK0     18    17      1
;! ---------------------------------------------------------------------------------
;! (1) _ChargeProcess_Slot                                  17    17      0    3649
;!                                             17 BANK0     17    17      0
;!                 _Detect_BatteryType
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) ___bmul                                               3     2      1     763
;!                                             14 BANK0      3     2      1
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     317
;!                                             14 BANK0      2     0      2
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 2
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            4     4      0    2377
;!                                             10 COMMON     4     4      0
;!                       _CCCV_Control
;!                   _Charging_Control
;!                   _Led_BlinkProcess
;!                 _PowerOnLedSequence
;!                    _Update_LED_Slot
;! ---------------------------------------------------------------------------------
;! (5) _Update_LED_Slot                                      3     3      0     286
;!                                              3 COMMON     3     3      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Led_BlinkProcess                                     3     3      0     156
;!                                              0 COMMON     3     3      0
;! ---------------------------------------------------------------------------------
;! (5) _Charging_Control                                     4     4      0     599
;!                                              3 COMMON     4     4      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _CCCV_Control                                        16    16      0    1336
;!                                              8 COMMON     2     2      0
;!                                              0 BANK0     14    14      0
;!                            ___awdiv
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (6) i1___bmul                                             3     2      1     144
;!                                              0 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (6) ___awdiv                                              8     4      4     428
;!                                              0 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ChargeProcess_Slot
;!     _Detect_BatteryType
;!     ___bmul
;!   _Do_AdcSample
;!     _ADC_Sample
;!     ___bmul
;!   _Do_NtcRead
;!     _Read_Temperature
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!       ___lwdiv
;!   _Print_DetectLog
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   ___bmul
;!   _uart_send_number
;!     ___bmul (ARG)
;!     ___lwdiv (ARG)
;!     ___lwmod (ARG)
;!     _uart_send_char (ARG)
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     i1___bmul
;!   _Charging_Control
;!     i1___bmul
;!   _Led_BlinkProcess
;!   _PowerOnLedSequence
;!   _Update_LED_Slot
;!     i1___bmul
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50      0      48       8       90.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50     16      2E      10       57.5%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50      2      42       6       82.5%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     34      42       4       82.5%
;!BITBANK0            50      0       1       3        1.3%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      E       E       1      100.0%
;!BITCOMMON            E      0       0       0        0.0%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     108      12        0.0%
;!ABS                  0      0     108      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 422 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  slot            1   51[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       2       0       0
;;      Totals:         0       1       2       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ChargeProcess_Slot
;;		_Do_AdcSample
;;		_Do_NtcRead
;;		_Print_DetectLog
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_System_Init
;;		___bmul
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	422
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	422
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	425
	
l4254:	
;main.c: 425: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_main+0)^080h+0+1),f
	movlw	241
movwf	((??_main+0)^080h+0),f
	u4817:
decfsz	((??_main+0)^080h+0),f
	goto	u4817
	decfsz	((??_main+0)^080h+0+1),f
	goto	u4817
opt asmopt_pop

	line	426
# 426 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	429
	
l4256:	
;main.c: 429: System_Init();
	fcall	_System_Init
	line	432
	
l4258:	
;main.c: 432: uart_send_string("L1211 Charger V2.1\r\n");
	movlw	low(((STR_26)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	433
	
l4260:	
;main.c: 433: uart_send_string("Init...\r\n");
	movlw	low(((STR_27)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	436
;main.c: 436: while(1)
	
l442:	
	line	438
# 438 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	441
	
l4262:	
;main.c: 441: if(g_doAdcSample)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u4761
	goto	u4760
u4761:
	goto	l4300
u4760:
	line	443
	
l4264:	
;main.c: 442: {
;main.c: 443: g_doAdcSample = 0;
	bcf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	line	444
;main.c: 444: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	445
	
l4266:	
;main.c: 445: Do_AdcSample();
	fcall	_Do_AdcSample
	line	449
	
l4268:	
;main.c: 449: ChargeProcess_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_ChargeProcess_Slot
	line	452
	
l4270:	
;main.c: 452: if(g_dbgDetectFlag)
	btfss	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	goto	u4771
	goto	u4770
u4771:
	goto	l4298
u4770:
	line	454
	
l4272:	
;main.c: 453: {
;main.c: 454: unsigned char slot = g_dbgSlot;
	movf	(_g_dbgSlot),w	;volatile
	movwf	(main@slot)
	line	455
	
l4274:	
;main.c: 455: g_dbgDetectFlag = 0;
	bcf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	458
	
l4276:	
;main.c: 458: uart_send_string("DBG: slot=");
	movlw	low(((STR_28)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	459
	
l4278:	
;main.c: 459: uart_send_number(slot);
	movf	(main@slot),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	460
	
l4280:	
;main.c: 460: uart_send_string(" st=");
	movlw	low(((STR_29)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	461
	
l4282:	
;main.c: 461: uart_send_number(g_dbgNewState);
	movf	(_g_dbgNewState),w	;volatile
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	462
	
l4284:	
;main.c: 462: uart_send_string(" ty=");
	movlw	low(((STR_30)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	463
	
l4286:	
;main.c: 463: uart_send_number(g_dbgNewType);
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_dbgNewType)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	464
	
l4288:	
;main.c: 464: uart_send_string(" V=");
	movlw	low(((STR_31)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	465
	
l4290:	
;main.c: 465: uart_send_number(g_dbgVoltage);
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_dbgVoltage+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_dbgVoltage)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	466
	
l4292:	
;main.c: 466: uart_send_string(" vrfy=");
	movlw	low(((STR_32)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	467
	
l4294:	
;main.c: 467: uart_send_number(g_slot[slot].state);
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(main@slot),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	468
	
l4296:	
;main.c: 468: uart_send_string("\r\n");
	movlw	low(((STR_33)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	471
	
l4298:	
;main.c: 469: }
;main.c: 471: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	475
	
l4300:	
;main.c: 472: }
;main.c: 475: if(g_doNtcRead)
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u4781
	goto	u4780
u4781:
	goto	l4308
u4780:
	line	477
	
l4302:	
;main.c: 476: {
;main.c: 477: g_doNtcRead = 0;
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	478
;main.c: 478: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	479
	
l4304:	
;main.c: 479: Do_NtcRead();
	fcall	_Do_NtcRead
	line	480
	
l4306:	
;main.c: 480: g_adcBusy = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	484
	
l4308:	
;main.c: 481: }
;main.c: 484: if(g_printFlag)
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u4791
	goto	u4790
u4791:
	goto	l4314
u4790:
	line	486
	
l4310:	
;main.c: 485: {
;main.c: 486: g_printFlag = 0;
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	487
	
l4312:	
;main.c: 487: Print_SystemStatus();
	fcall	_Print_SystemStatus
	line	488
;main.c: 488: Print_NtcTemp();
	fcall	_Print_NtcTemp
	line	492
	
l4314:	
;main.c: 489: }
;main.c: 492: if(g_detectLogFlag)
	btfss	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	goto	u4801
	goto	u4800
u4801:
	goto	l442
u4800:
	line	494
	
l4316:	
;main.c: 493: {
;main.c: 494: g_detectLogFlag = 0;
	bcf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	line	495
	
l4318:	
;main.c: 495: Print_DetectLog();
	fcall	_Print_DetectLog
	goto	l442
	global	start
	ljmp	start
	opt stack 0
	line	498
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 66 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   17[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	66
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	66
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	71
	
l3606:	
# 71 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	72
# 72 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text1
	line	73
	
l3608:	
;main.c: 73: OSCCON = 0x72;
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	77
;main.c: 77: TRISA = 0xF0; PORTA = 0x0F;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	78
;main.c: 78: TRISB = 0x30; PORTB = 0x4F;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	79
;main.c: 79: TRISC = 0x07; PORTC = 0x00;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l3610:	
	clrf	(262)^0100h	;volatile
	line	80
	
l3612:	
;main.c: 80: TRISD = 0xF0; PORTD = 0x0F;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l3614:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	83
	
l3616:	
;main.c: 83: WPUA = 0x00; WPDA = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l3618:	
	clrf	(135)^080h	;volatile
	line	84
	
l3620:	
;main.c: 84: WPUB = 0x00; WPDB = 0x00;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l3622:	
	clrf	(7)	;volatile
	line	85
	
l3624:	
;main.c: 85: WPUC = 0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	86
	
l3626:	
;main.c: 86: WPUD = 0x00;
	clrf	(277)^0100h	;volatile
	line	89
	
l3628:	
;main.c: 89: IOCA = 0x00; IOCB = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l3630:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	92
	
l3632:	
;main.c: 92: CC0CON = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	93
	
l3634:	
;main.c: 93: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	100
	
l3636:	
;main.c: 100: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	101
	
l3638:	
;main.c: 101: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	102
	
l3640:	
;main.c: 102: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	103
	
l3642:	
;main.c: 103: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	106
	
l3644:	
;main.c: 106: AD_Init();
	fcall	_AD_Init
	line	109
	
l3646:	
;main.c: 109: uart_init();
	fcall	_uart_init
	line	116
;main.c: 116: OPTION_REG = 0x00;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	117
	
l3648:	
;main.c: 117: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	118
	
l3650:	
;main.c: 118: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	119
	
l3652:	
;main.c: 119: INTCON = 0xE0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	122
;main.c: 122: g_pwmDuty = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	123
;main.c: 123: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	124
	
l3654:	
;main.c: 124: RC3 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	125
	
l3656:	
;main.c: 125: RC5 = 0;
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	126
	
l3658:	
;main.c: 126: RB6 = 1;
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	127
	
l3660:	
;main.c: 127: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	130
;main.c: 130: for(i = 0; i < 12; i++)
	clrf	(System_Init@i)
	line	132
	
l3666:	
;main.c: 131: {
;main.c: 132: g_slot[i].state = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	133
;main.c: 133: g_slot[i].type = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	134
;main.c: 134: g_slot[i].voltage = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	135
;main.c: 135: g_slot[i].chargeTimer = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	130
	
l3668:	
	incf	(System_Init@i),f
	
l3670:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u3861
	goto	u3860
u3861:
	goto	l3666
u3860:
	line	137
	
l3672:	
;main.c: 136: }
;main.c: 137: for(i = 0; i < 12; i++)
	clrf	(System_Init@i)
	line	139
	
l3678:	
;main.c: 138: {
;main.c: 139: g_ledState[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ledState|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	140
;main.c: 140: g_blinkPhase[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_blinkPhase|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	141
;main.c: 141: g_blinkTimer[i] = 0;
	clrc
	rlf	(System_Init@i),w
	addlw	low(_g_blinkTimer|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	137
	
l3680:	
	incf	(System_Init@i),f
	
l3682:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u3871
	goto	u3870
u3871:
	goto	l3678
u3870:
	line	145
	
l357:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
global __ptext2
__ptext2:	;psect for function _uart_init
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_init: []
	line	23
	
l2392:	
;uart_dbg.c: 23: TRISC &= (unsigned char)~0x10;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
;uart_dbg.c: 24: ANSEL2 &= (unsigned char)~0x10;
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
;uart_dbg.c: 25: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l480:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
global __ptext3
__ptext3:	;psect for function _AD_Init
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l2386:	
;adc_drv.c: 25: CC0CON = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
;adc_drv.c: 26: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	27
	
l2388:	
;adc_drv.c: 27: ADCON0 = 0X81;
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l2390:	
;adc_drv.c: 28: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	29
	
l457:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 307 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  bat_mv_long     4   15[BANK2 ] unsigned long 
;;  vx_mv           4   11[BANK2 ] unsigned long 
;;  v               2    9[BANK2 ] unsigned int 
;;  s               1    8[BANK2 ] unsigned char 
;;  pt              4    4[BANK2 ] unsigned long 
;;  vcc_mv          2   19[BANK2 ] unsigned int 
;;  i               1   21[BANK2 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0      22
;;      Temps:          0       8       0       0       0
;;      Totals:         0       8       0       0      22
;;Total ram usage:       30 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	307
global __ptext4
__ptext4:	;psect for function _Print_SystemStatus
psect	text4
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	307
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	312
	
l3852:	
;main.c: 309: unsigned char i;
;main.c: 310: unsigned int vcc_mv;
;main.c: 312: uart_send_string("\r\n== L1211 12CH CHARGER ==\r\n");
	movlw	low(((STR_4)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	315
	
l3854:	
;main.c: 315: test_adc = ADC_Sample(31, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	316
	
l3856:	
;main.c: 316: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u4191
	goto	u4190
u4191:
	goto	l3862
u4190:
	line	318
	
l3858:	
;main.c: 317: {
;main.c: 318: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult),w	;volatile
	movwf	(___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@pt+3)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(2+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@pt+2)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@pt+1)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@pt)^0100h

	line	319
	
l3860:	
;main.c: 319: vcc_mv = (unsigned int)pt;
	movf	(Print_SystemStatus@pt+1)^0100h,w
	movwf	(Print_SystemStatus@vcc_mv+1)^0100h
	movf	(Print_SystemStatus@pt)^0100h,w
	movwf	(Print_SystemStatus@vcc_mv)^0100h
	line	320
;main.c: 320: }
	goto	l3864
	line	322
	
l3862:	
;main.c: 321: else
;main.c: 322: vcc_mv = 5000;
	movlw	088h
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@vcc_mv)^0100h
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv)^0100h)+1
	line	324
	
l3864:	
;main.c: 324: uart_send_string("VCC=");
	movlw	low(((STR_5)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	325
	
l3866:	
;main.c: 325: uart_send_number(vcc_mv);
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	326
	
l3868:	
;main.c: 326: uart_send_string("mV T=");
	movlw	low(((STR_6)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	327
	
l3870:	
;main.c: 327: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(_Print_SystemStatus$710+1)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(_Print_SystemStatus$710)^0100h
	
l3872:	
;main.c: 327: uart_send_number(g_temperature / 10U);
	movf	(_Print_SystemStatus$710+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	(_Print_SystemStatus$710)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	328
	
l3874:	
;main.c: 328: uart_send_string(".");
	movlw	low(((STR_7)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	329
	
l3876:	
;main.c: 329: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(_Print_SystemStatus$711+1)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(0+(?___lwmod)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(_Print_SystemStatus$711)^0100h
	
l3878:	
;main.c: 329: uart_send_number(g_temperature % 10U);
	movf	(_Print_SystemStatus$711+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	(_Print_SystemStatus$711)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	330
	
l3880:	
;main.c: 330: uart_send_string("C\r\n");
	movlw	low(((STR_8)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	337
	
l3882:	
;main.c: 337: for(i = 0; i < 1; i++)
	bsf	status, 6	;RP1=1, select bank2
	clrf	(Print_SystemStatus@i)^0100h
	line	340
	
l3888:	
;main.c: 339: {
;main.c: 340: unsigned int v = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@i)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@v)^0100h
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)^0100h
	line	341
;main.c: 341: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@i)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@s)^0100h
	line	348
	
l3890:	
;main.c: 348: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	349
	
l3892:	
;main.c: 349: uart_send_number((unsigned int)i + 1U);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@i)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	350
;main.c: 350: uart_send_char('=');
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	351
	
l3894:	
;main.c: 351: uart_send_number(v);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@v+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@v)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	357
	
l3896:	
;main.c: 356: {
;main.c: 357: unsigned long vx_mv = (unsigned long)v * (unsigned long)vcc_mv / 4096UL;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@v)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@v+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___lmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@vx_mv+3)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@vx_mv+2)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(1+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@vx_mv+1)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(0+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@vx_mv)^0100h

	
l3898:	
	movlw	0Ch
u4205:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3)^0100h,f
	rrf	(Print_SystemStatus@vx_mv+2)^0100h,f
	rrf	(Print_SystemStatus@vx_mv+1)^0100h,f
	rrf	(Print_SystemStatus@vx_mv)^0100h,f
	addlw	-1
	skipz
	goto	u4205

	line	358
	
l3900:	
;main.c: 358: if(vx_mv + 200U >= (unsigned long)vcc_mv)
	movf	(Print_SystemStatus@vcc_mv)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_Print_SystemStatus+0)+0)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_Print_SystemStatus+0)+0+1)
	clrf	((??_Print_SystemStatus+0)+0+2)
	clrf	((??_Print_SystemStatus+0)+0+3)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+4)+0)
	movlw	0
	movwf	((??_Print_SystemStatus+4)+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+4)+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+4)+0+3)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vx_mv)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	addwf	(??_Print_SystemStatus+4)+0,f
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vx_mv+1)^0100h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1)^0100h,w
	goto	u4210
	goto	u4211
u4210:
	bcf	status, 6	;RP1=0, select bank0
	addwf	(??_Print_SystemStatus+4)+1,f
u4211:
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vx_mv+2)^0100h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2)^0100h,w
	goto	u4212
	goto	u4213
u4212:
	bcf	status, 6	;RP1=0, select bank0
	addwf	(??_Print_SystemStatus+4)+2,f
u4213:
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vx_mv+3)^0100h,w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	addwf	(??_Print_SystemStatus+4)+3,f
	movf	3+(??_Print_SystemStatus+0)+0,w
	subwf	3+(??_Print_SystemStatus+4)+0,w
	skipz
	goto	u4225
	movf	2+(??_Print_SystemStatus+0)+0,w
	subwf	2+(??_Print_SystemStatus+4)+0,w
	skipz
	goto	u4225
	movf	1+(??_Print_SystemStatus+0)+0,w
	subwf	1+(??_Print_SystemStatus+4)+0,w
	skipz
	goto	u4225
	movf	0+(??_Print_SystemStatus+0)+0,w
	subwf	0+(??_Print_SystemStatus+4)+0,w
u4225:
	skipc
	goto	u4221
	goto	u4220
u4221:
	goto	l3904
u4220:
	line	360
	
l3902:	
;main.c: 359: {
;main.c: 360: uart_send_string(" OPEN");
	movlw	low(((STR_9)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	361
;main.c: 361: }
	goto	l3914
	line	364
	
l3904:	
;main.c: 362: else
;main.c: 363: {
;main.c: 364: unsigned long bat_mv_long = 1159UL * vx_mv;
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vx_mv+3)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___lmul@multiplier+3)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vx_mv+2)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___lmul@multiplier+2)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vx_mv+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___lmul@multiplier+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vx_mv)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___lmul@multiplier)

	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	04h
	movwf	(___lmul@multiplicand+1)
	movlw	087h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@bat_mv_long+3)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@bat_mv_long+2)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(1+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@bat_mv_long+1)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(0+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@bat_mv_long)^0100h

	line	365
;main.c: 365: if(bat_mv_long > (647UL * (unsigned long)vcc_mv))
	movf	(Print_SystemStatus@vcc_mv)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	02h
	movwf	(___lmul@multiplicand+1)
	movlw	087h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@bat_mv_long+3)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	subwf	(3+(?___lmul)),w
	skipz
	goto	u4235
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@bat_mv_long+2)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	subwf	(2+(?___lmul)),w
	skipz
	goto	u4235
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@bat_mv_long+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	subwf	(1+(?___lmul)),w
	skipz
	goto	u4235
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@bat_mv_long)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	subwf	(0+(?___lmul)),w
u4235:
	skipnc
	goto	u4231
	goto	u4230
u4231:
	goto	l3914
u4230:
	line	367
	
l3906:	
;main.c: 366: {
;main.c: 367: bat_mv_long = (bat_mv_long - 647UL * (unsigned long)vcc_mv + 1000UL/2UL) / 1000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Print_SystemStatus+0)+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+3)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)
	movlw	0FDh
	movwf	(___lmul@multiplicand+1)
	movlw	079h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(0+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	addwf	(Print_SystemStatus@bat_mv_long)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_Print_SystemStatus+4)+0+0)
	movlw	0
	skipnc
	movlw	1
	addwf	(1+(?___lmul)),w
	clrf	((??_Print_SystemStatus+4)+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)+0+2),f
	bsf	status, 6	;RP1=1, select bank2
	addwf	(Print_SystemStatus@bat_mv_long+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_Print_SystemStatus+4)+0+1)
	skipnc
	incf	((??_Print_SystemStatus+4)+0+2),f
	movf	(2+(?___lmul)),w
	addwf	((??_Print_SystemStatus+4)+0+2),w
	clrf	((??_Print_SystemStatus+4)+0+3)
	skipnc
	incf	((??_Print_SystemStatus+4)+0+3),f
	bsf	status, 6	;RP1=1, select bank2
	addwf	(Print_SystemStatus@bat_mv_long+2)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_Print_SystemStatus+4)+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)+0+3),f
	movf	(3+(?___lmul)),w
	addwf	((??_Print_SystemStatus+4)+0+3),w
	bsf	status, 6	;RP1=1, select bank2
	addwf	(Print_SystemStatus@bat_mv_long+3)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_Print_SystemStatus+4)+0+3)
	movf	0+(??_Print_SystemStatus+4)+0,w
	addwf	(??_Print_SystemStatus+0)+0,f
	movf	1+(??_Print_SystemStatus+4)+0,w
	skipnc
	incfsz	1+(??_Print_SystemStatus+4)+0,w
	goto	u4240
	goto	u4241
u4240:
	addwf	(??_Print_SystemStatus+0)+1,f
u4241:
	movf	2+(??_Print_SystemStatus+4)+0,w
	skipnc
	incfsz	2+(??_Print_SystemStatus+4)+0,w
	goto	u4242
	goto	u4243
u4242:
	addwf	(??_Print_SystemStatus+0)+2,f
u4243:
	movf	3+(??_Print_SystemStatus+4)+0,w
	skipnc
	incf	3+(??_Print_SystemStatus+4)+0,w
	addwf	(??_Print_SystemStatus+0)+3,f
	movf	3+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@bat_mv_long+3)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(2+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@bat_mv_long+2)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@bat_mv_long+1)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@bat_mv_long)^0100h

	line	368
	
l3908:	
;main.c: 368: uart_send_string(" BAT(");
	movlw	low(((STR_10)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	369
	
l3910:	
;main.c: 369: uart_send_number((unsigned int)bat_mv_long);
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@bat_mv_long+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@bat_mv_long)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	370
	
l3912:	
;main.c: 370: uart_send_string("mV)");
	movlw	low(((STR_11)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	377
	
l3914:	
;main.c: 371: }
;main.c: 373: }
;main.c: 374: }
;main.c: 377: uart_send_char(' ');
	movlw	low(020h)
	fcall	_uart_send_char
	line	378
;main.c: 378: switch(s)
	goto	l3940
	line	380
	
l3916:	
	movlw	low(((STR_12)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3942
	line	381
	
l3918:	
	movlw	low(((STR_13)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3942
	line	382
	
l3920:	
	movlw	low(((STR_14)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3942
	line	383
	
l3922:	
	movlw	low(((STR_15)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3942
	line	384
	
l3924:	
	movlw	low(((STR_16)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3942
	line	385
	
l3926:	
	movlw	low(((STR_17)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3942
	line	386
	
l3928:	
	movlw	low(((STR_18)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3942
	line	387
	
l3930:	
	movlw	low(((STR_19)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3942
	line	388
	
l3932:	
	movlw	low(((STR_20)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3942
	line	389
	
l3934:	
	movlw	low(((STR_21)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3942
	line	390
	
l3936:	
	movlw	low(((STR_22)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3942
	line	378
	
l3940:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@s)^0100h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l3916
	xorlw	1^0	; case 1
	skipnz
	goto	l3918
	xorlw	2^1	; case 2
	skipnz
	goto	l3920
	xorlw	3^2	; case 3
	skipnz
	goto	l3922
	xorlw	4^3	; case 4
	skipnz
	goto	l3924
	xorlw	5^4	; case 5
	skipnz
	goto	l3926
	xorlw	6^5	; case 6
	skipnz
	goto	l3928
	xorlw	7^6	; case 7
	skipnz
	goto	l3930
	xorlw	8^7	; case 8
	skipnz
	goto	l3932
	xorlw	9^8	; case 9
	skipnz
	goto	l3934
	goto	l3936
	opt asmopt_pop

	line	337
	
l3942:	
	bsf	status, 6	;RP1=1, select bank2
	incf	(Print_SystemStatus@i)^0100h,f
	
l3944:	
	movf	((Print_SystemStatus@i)^0100h),w
	btfsc	status,2
	goto	u4251
	goto	u4250
u4251:
	goto	l3888
u4250:
	line	393
	
l3946:	
;main.c: 392: }
;main.c: 393: uart_send_string("\r\n");
	movlw	low(((STR_23)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	394
	
l431:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 289 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	289
global __ptext5
__ptext5:	;psect for function _Print_NtcTemp
psect	text5
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	289
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	291
	
l3840:	
;main.c: 291: uart_send_string("NTC=");
	movlw	low(((STR_1)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	292
	
l3842:	
;main.c: 292: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$708+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$708)
	
l3844:	
;main.c: 292: uart_send_number(g_temperature / 10U);
	movf	(_Print_NtcTemp$708+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$708),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	293
	
l3846:	
;main.c: 293: uart_send_string(".");
	movlw	low(((STR_2)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	294
	
l3848:	
;main.c: 294: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	movwf	(_Print_NtcTemp$709+1)
	movf	(0+(?___lwmod)),w
	movwf	(_Print_NtcTemp$709)
;main.c: 294: uart_send_number(g_temperature % 10U);
	movf	(_Print_NtcTemp$709+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$709),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	295
	
l3850:	
;main.c: 295: uart_send_string("C\r\n");
	movlw	low(((STR_3)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	296
	
l408:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_Print_DetectLog

;; *************** function _Print_DetectLog *****************
;; Defined at:
;;		line 400 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	line	400
global __ptext6
__ptext6:	;psect for function _Print_DetectLog
psect	text6
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	400
	global	__size_of_Print_DetectLog
	__size_of_Print_DetectLog	equ	__end_of_Print_DetectLog-_Print_DetectLog
	
_Print_DetectLog:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_DetectLog: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	402
	
l3948:	
;main.c: 402: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	403
	
l3950:	
;main.c: 403: uart_send_number((unsigned int)g_detectLogSlot + 1U);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_detectLogSlot),w	;volatile
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	405
	
l3952:	
;main.c: 405: if(g_detectLogType == 2)
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u4261
	goto	u4260
u4261:
	goto	l3956
u4260:
	line	406
	
l3954:	
;main.c: 406: uart_send_string(": NiMH detected! Not charging.\r\n");
	movlw	low(((STR_24)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l437
	line	407
	
l3956:	
;main.c: 407: else if(g_detectLogType == 3)
		movlw	3
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u4271
	goto	u4270
u4271:
	goto	l437
u4270:
	line	408
	
l3958:	
;main.c: 408: uart_send_string(": Dry cell detected! Not charging.\r\n");
	movlw	low(((STR_25)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	409
	
l437:	
	return
	opt stack 0
GLOBAL	__end_of_Print_DetectLog
	__end_of_Print_DetectLog:
	signat	_Print_DetectLog,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2   17[BANK0 ] PTR const unsigned char 
;;		 -> STR_33(3), STR_32(7), STR_31(4), STR_30(5), 
;;		 -> STR_29(5), STR_28(11), STR_27(10), STR_26(21), 
;;		 -> STR_25(37), STR_24(33), STR_23(3), STR_22(6), 
;;		 -> STR_21(8), STR_20(6), STR_19(6), STR_18(7), 
;;		 -> STR_17(5), STR_16(5), STR_15(6), STR_14(6), 
;;		 -> STR_13(6), STR_12(7), STR_11(4), STR_10(6), 
;;		 -> STR_9(6), STR_8(4), STR_7(2), STR_6(6), 
;;		 -> STR_5(5), STR_4(29), STR_3(4), STR_2(2), 
;;		 -> STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
global __ptext7
__ptext7:	;psect for function _uart_send_string
psect	text7
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l3556:	
;uart_dbg.c: 63: while(*str != '\0')
	goto	l3562
	line	65
	
l3558:	
;uart_dbg.c: 64: {
;uart_dbg.c: 65: uart_send_char(*str++);
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	fcall	_uart_send_char
	
l3560:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(uart_send_string@str),f
	skipnz
	incf	(uart_send_string@str+1),f
	line	66
# 66 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
clrwdt ;# 
psect	text7
	line	63
	
l3562:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u3801
	goto	u3800
u3801:
	goto	l3558
u3800:
	line	68
	
l493:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2   21[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6   23[BANK0 ] unsigned char [6]
;;  j               1   30[BANK0 ] unsigned char 
;;  i               1   29[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      10       0       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext8
__ptext8:	;psect for function _uart_send_number
psect	text8
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l3564:	
;uart_dbg.c: 79: unsigned char buf[6];
;uart_dbg.c: 80: unsigned char i = 0;
	clrf	(uart_send_number@i)
	line	84
	
l3566:	
;uart_dbg.c: 81: unsigned char j;
;uart_dbg.c: 84: if(num == 0)
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u3811
	goto	u3810
u3811:
	goto	l3578
u3810:
	line	86
	
l3568:	
;uart_dbg.c: 85: {
;uart_dbg.c: 86: uart_send_char('0');
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l497
	line	93
	
l3572:	
;uart_dbg.c: 92: {
;uart_dbg.c: 93: buf[i++] = '0' + (num % 10);
	movf	(uart_send_number@i),w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwmod@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank0
	movwf	indf
	
l3574:	
	incf	(uart_send_number@i),f
	line	94
	
l3576:	
;uart_dbg.c: 94: num /= 10;
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(uart_send_number@num+1)
	movf	(0+(?___lwdiv)),w
	movwf	(uart_send_number@num)
	line	91
	
l3578:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u3821
	goto	u3820
u3821:
	goto	l3572
u3820:
	line	98
	
l3580:	
;uart_dbg.c: 95: }
;uart_dbg.c: 98: for(j = i; j > 0; j--)
	movf	(uart_send_number@i),w
	movwf	(uart_send_number@j)
	
l3582:	
	movf	((uart_send_number@j)),w
	btfss	status,2
	goto	u3831
	goto	u3830
u3831:
	goto	l3586
u3830:
	goto	l497
	line	99
	
l3586:	
;uart_dbg.c: 99: uart_send_char(buf[(unsigned char)(j - 1)]);
	movf	(uart_send_number@j),w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l3588:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decf	(uart_send_number@j),f
	goto	l3582
	line	100
	
l497:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1   15[BANK0 ] unsigned char 
;;  i               1   16[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/A00
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext9
__ptext9:	;psect for function _uart_send_char
psect	text9
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_char: [wreg+status,2+status,0]
;uart_send_char@c stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_char@c)
	line	38
	
l3410:	
;uart_dbg.c: 37: unsigned char i;
;uart_dbg.c: 38: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	39
;uart_dbg.c: 39: RC4 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l3412:	
;uart_dbg.c: 40: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u4827:
decfsz	(??_uart_send_char+0)+0,f
	goto	u4827
	nop2
opt asmopt_pop

	line	41
	
l3414:	
;uart_dbg.c: 41: for(i = 0; i < 8; i++)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(uart_send_char@i)
	line	42
	
l483:	
	line	43
;uart_dbg.c: 42: {
;uart_dbg.c: 43: if(c & 0x01)
	btfss	(uart_send_char@c),(0)&7
	goto	u3531
	goto	u3530
u3531:
	goto	l485
u3530:
	line	44
	
l3420:	
;uart_dbg.c: 44: RC4 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l3422
	line	45
	
l485:	
	line	46
;uart_dbg.c: 45: else
;uart_dbg.c: 46: RC4 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l3422:	
;uart_dbg.c: 47: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u4837:
decfsz	(??_uart_send_char+0)+0,f
	goto	u4837
	nop2
opt asmopt_pop

	line	48
	
l3424:	
;uart_dbg.c: 48: c >>= 1;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rrf	(uart_send_char@c),f
	line	41
	
l3426:	
	incf	(uart_send_char@i),f
	
l3428:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u3541
	goto	u3540
u3541:
	goto	l483
u3540:
	
l484:	
	line	50
;uart_dbg.c: 49: }
;uart_dbg.c: 50: RC4 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l3430:	
;uart_dbg.c: 51: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u4847:
decfsz	(??_uart_send_char+0)+0,f
	goto	u4847
	nop2
opt asmopt_pop

	line	52
	
l3432:	
;uart_dbg.c: 52: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l487:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   14[BANK0 ] unsigned int 
;;  dividend        2   16[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1   18[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   14[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       5       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext10
__ptext10:	;psect for function ___lwmod
psect	text10
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l3498:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u3661
	goto	u3660
u3661:
	goto	l3514
u3660:
	line	14
	
l3500:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l3504
	line	16
	
l3502:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l3504:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u3671
	goto	u3670
u3671:
	goto	l3502
u3670:
	line	20
	
l3506:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u3685
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u3685:
	skipc
	goto	u3681
	goto	u3680
u3681:
	goto	l3510
u3680:
	line	21
	
l3508:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l3510:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l3512:	
	decfsz	(___lwmod@counter),f
	goto	u3691
	goto	u3690
u3691:
	goto	l3506
u3690:
	line	25
	
l3514:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1063:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	_Do_NtcRead

;; *************** function _Do_NtcRead *****************
;; Defined at:
;;		line 280 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Read_Temperature
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	280
global __ptext11
__ptext11:	;psect for function _Do_NtcRead
psect	text11
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	280
	global	__size_of_Do_NtcRead
	__size_of_Do_NtcRead	equ	__end_of_Do_NtcRead-_Do_NtcRead
	
_Do_NtcRead:	
;incstack = 0
	opt	stack 2
; Regs used in _Do_NtcRead: [wreg+status,2+status,0+pclath+cstack]
	line	282
	
l3838:	
;main.c: 282: Read_Temperature();
	fcall	_Read_Temperature
	line	283
	
l405:	
	return
	opt stack 0
GLOBAL	__end_of_Do_NtcRead
	__end_of_Do_NtcRead:
	signat	_Do_NtcRead,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 22 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   43[BANK0 ] unsigned long 
;;  temp_x10        2   49[BANK0 ] unsigned int 
;;  ntcVal          2   47[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   64[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Do_NtcRead
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	22
global __ptext12
__ptext12:	;psect for function _Read_Temperature
psect	text12
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	22
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 2
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	27
	
l3518:	
;charge_mgr.c: 24: unsigned int ntcVal;
;charge_mgr.c: 25: unsigned int temp_x10;
;charge_mgr.c: 27: test_adc = ADC_Sample(18, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	28
	
l3520:	
;charge_mgr.c: 28: if(0xA5 != test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u3701
	goto	u3700
u3701:
	goto	l3524
u3700:
	goto	l524
	line	31
	
l3524:	
;charge_mgr.c: 31: ntcVal = adresult;
	movf	(_adresult+1),w	;volatile
	movwf	(Read_Temperature@ntcVal+1)
	movf	(_adresult),w	;volatile
	movwf	(Read_Temperature@ntcVal)
	line	32
;charge_mgr.c: 32: if(ntcVal < 100 || ntcVal > 3996)
	movlw	0
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u3711
	goto	u3710
u3711:
	goto	l524
u3710:
	
l3526:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u3721
	goto	u3720
u3721:
	goto	l3528
u3720:
	goto	l524
	line	37
	
l3528:	
;charge_mgr.c: 35: {
;charge_mgr.c: 36: unsigned long rt;
;charge_mgr.c: 37: rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	010h
	movwf	(___lldiv@divisor+1)
	movlw	0
	movwf	(___lldiv@divisor)

	movf	(Read_Temperature@ntcVal),w
	movwf	((??_Read_Temperature+0)+0)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((??_Read_Temperature+0)+0+1)
	clrf	((??_Read_Temperature+0)+0+2)
	clrf	((??_Read_Temperature+0)+0+3)
	movf	0+(??_Read_Temperature+0)+0,w
	subwf	(___lldiv@divisor),f
	movf	1+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)+0,w
	goto	u3735
	goto	u3736
u3735:
	subwf	(___lldiv@divisor+1),f
u3736:
	movf	2+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)+0,w
	goto	u3737
	goto	u3738
u3737:
	subwf	(___lldiv@divisor+2),f
u3738:
	movf	3+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)+0,w
	goto	u3739
	goto	u3730
u3739:
	subwf	(___lldiv@divisor+3),f
u3730:

	movf	(Read_Temperature@ntcVal),w
	movwf	(___lmul@multiplier)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	027h
	movwf	(___lmul@multiplicand+1)
	movlw	010h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Read_Temperature@rt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Read_Temperature@rt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@rt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@rt)

	line	38
	
l3530:	
;charge_mgr.c: 38: if(rt >= 10000UL)
		movf	(Read_Temperature@rt+3),w
	btfss	status,2
	goto	u3740
	movf	(Read_Temperature@rt+2),w
	btfss	status,2
	goto	u3740
	movlw	39
	subwf	(Read_Temperature@rt+1),w
	skipz
	goto	u3743
	movlw	16
	subwf	(Read_Temperature@rt),w
	skipz
	goto	u3743
u3743:
	btfss	status,0
	goto	u3741
	goto	u3740

u3741:
	goto	l3536
u3740:
	line	39
	
l3532:	
;charge_mgr.c: 39: temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l3534:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0F0h
	movwf	((??_Read_Temperature+0)+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+3)
	movf	(Read_Temperature@rt),w
	addwf	(??_Read_Temperature+0)+0,f
	movf	(Read_Temperature@rt+1),w
	skipnc
	incfsz	(Read_Temperature@rt+1),w
	goto	u3750
	goto	u3751
u3750:
	addwf	(??_Read_Temperature+0)+1,f
u3751:
	movf	(Read_Temperature@rt+2),w
	skipnc
	incfsz	(Read_Temperature@rt+2),w
	goto	u3752
	goto	u3753
u3752:
	addwf	(??_Read_Temperature+0)+2,f
u3753:
	movf	(Read_Temperature@rt+3),w
	skipnc
	incf	(Read_Temperature@rt+3),w
	addwf	(??_Read_Temperature+0)+3,f
	movf	3+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+3)
	movf	2+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+2)
	movf	1+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+1)
	movf	0+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier)

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(0+(?___lldiv)),w
	subwf	(Read_Temperature@temp_x10),f
	movf	(1+(?___lldiv)),w
	skipc
	decf	(Read_Temperature@temp_x10+1),f
	subwf	(Read_Temperature@temp_x10+1),f
	goto	l3540
	line	41
	
l3536:	
;charge_mgr.c: 40: else
;charge_mgr.c: 41: temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0
	movwf	(___lmul@multiplier+3)
	movlw	0
	movwf	(___lmul@multiplier+2)
	movlw	027h
	movwf	(___lmul@multiplier+1)
	movlw	010h
	movwf	(___lmul@multiplier)

	movf	(Read_Temperature@rt),w
	subwf	(___lmul@multiplier),f
	movf	(Read_Temperature@rt+1),w
	skipc
	incfsz	(Read_Temperature@rt+1),w
	subwf	(___lmul@multiplier+1),f
	movf	(Read_Temperature@rt+2),w
	skipc
	incfsz	(Read_Temperature@rt+2),w
	subwf	(___lmul@multiplier+2),f
	movf	(Read_Temperature@rt+3),w
	skipc
	incfsz	(Read_Temperature@rt+3),w
	subwf	(___lmul@multiplier+3),f
	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10)
	
l3538:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10),f
	skipnc
	incf	(Read_Temperature@temp_x10+1),f
	line	42
	
l3540:	
;charge_mgr.c: 42: if(temp_x10 < 100U) temp_x10 = 100U;
	movlw	0
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipnc
	goto	u3761
	goto	u3760
u3761:
	goto	l530
u3760:
	
l3542:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l530:	
	line	43
;charge_mgr.c: 43: if(temp_x10 > 750U) temp_x10 = 750U;
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipc
	goto	u3771
	goto	u3770
u3771:
	goto	l531
u3770:
	
l3544:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)
	movlw	02h
	movwf	((Read_Temperature@temp_x10))+1
	
l531:	
	line	46
;charge_mgr.c: 44: }
;charge_mgr.c: 46: g_temperature = temp_x10;
	movf	(Read_Temperature@temp_x10+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_temperature+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(Read_Temperature@temp_x10),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_temperature)^080h
	line	47
	
l3546:	
;charge_mgr.c: 47: if((temp_x10 / 10U) >= 60)
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u3781
	goto	u3780
u3781:
	goto	l3550
u3780:
	line	48
	
l3548:	
;charge_mgr.c: 48: g_tempProtect = 1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	incf	(_g_tempProtect)^080h,f
	goto	l524
	line	49
	
l3550:	
;charge_mgr.c: 49: else if((temp_x10 / 10U) <= 50)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u3791
	goto	u3790
u3791:
	goto	l524
u3790:
	line	50
	
l3552:	
;charge_mgr.c: 50: g_tempProtect = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	line	53
	
l524:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   14[BANK0 ] unsigned int 
;;  dividend        2   16[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2   19[BANK0 ] unsigned int 
;;  counter         1   18[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   14[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       7       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext13
__ptext13:	;psect for function ___lwdiv
psect	text13
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l3472:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l3474:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u3621
	goto	u3620
u3621:
	goto	l3494
u3620:
	line	16
	
l3476:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l3480
	line	18
	
l3478:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l3480:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u3631
	goto	u3630
u3631:
	goto	l3478
u3630:
	line	22
	
l3482:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l3484:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u3645
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u3645:
	skipc
	goto	u3641
	goto	u3640
u3641:
	goto	l3490
u3640:
	line	24
	
l3486:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l3488:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l3490:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l3492:	
	decfsz	(___lwdiv@counter),f
	goto	u3651
	goto	u3650
u3651:
	goto	l3482
u3650:
	line	30
	
l3494:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l1053:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4   14[BANK0 ] unsigned long 
;;  multiplicand    4   18[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4   22[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4   14[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext14
__ptext14:	;psect for function ___lmul
psect	text14
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l3434:	
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l725:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u3551
	goto	u3550
u3551:
	goto	l3438
u3550:
	line	122
	
l3436:	
	movf	(___lmul@multiplicand),w
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3561
	addwf	(___lmul@product+1),f
u3561:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3562
	addwf	(___lmul@product+2),f
u3562:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3563
	addwf	(___lmul@product+3),f
u3563:

	line	123
	
l3438:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l3440:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u3571
	goto	u3570
u3571:
	goto	l725
u3570:
	line	128
	
l3442:	
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l728:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4   26[BANK0 ] unsigned long 
;;  dividend        4   30[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   34[BANK0 ] unsigned long 
;;  counter         1   38[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4   26[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      13       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext15
__ptext15:	;psect for function ___lldiv
psect	text15
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l3446:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l3448:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u3581
	goto	u3580
u3581:
	goto	l3468
u3580:
	line	16
	
l3450:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l3454
	line	18
	
l3452:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l3454:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u3591
	goto	u3590
u3591:
	goto	l3452
u3590:
	line	22
	
l3456:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l3458:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u3605
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u3605
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u3605
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u3605:
	skipc
	goto	u3601
	goto	u3600
u3601:
	goto	l3464
u3600:
	line	24
	
l3460:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l3462:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l3464:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l3466:	
	decfsz	(___lldiv@counter),f
	goto	u3611
	goto	u3610
u3611:
	goto	l3456
u3610:
	line	30
	
l3468:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l1000:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_Do_AdcSample

;; *************** function _Do_AdcSample *****************
;; Defined at:
;;		line 261 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  ch              1   32[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	261
global __ptext16
__ptext16:	;psect for function _Do_AdcSample
psect	text16
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	261
	global	__size_of_Do_AdcSample
	__size_of_Do_AdcSample	equ	__end_of_Do_AdcSample-_Do_AdcSample
	
_Do_AdcSample:	
;incstack = 0
	opt	stack 3
; Regs used in _Do_AdcSample: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	263
	
l3826:	
;main.c: 263: unsigned char ch = s_adcChannels[g_scanIndex];
	movf	(_g_scanIndex),w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(Do_AdcSample@ch)
	line	264
	
l3828:	
;main.c: 264: test_adc = ADC_Sample(ch, 0);
	clrf	(ADC_Sample@adldo)
	movf	(Do_AdcSample@ch),w
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	266
	
l3830:	
;main.c: 266: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u4181
	goto	u4180
u4181:
	goto	l3834
u4180:
	line	267
	
l3832:	
;main.c: 267: g_slot[g_scanIndex].voltage = adresult;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	movf	(_adresult),w	;volatile
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(_adresult+1),w	;volatile
	movwf	indf
	goto	l3836
	line	269
	
l3834:	
;main.c: 268: else
;main.c: 269: g_slot[g_scanIndex].voltage = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	271
	
l3836:	
;main.c: 271: g_scanPhase = 1;
	movlw	low(01h)
	movwf	(_g_scanPhase)	;volatile
	line	272
	
l402:	
	return
	opt stack 0
GLOBAL	__end_of_Do_AdcSample
	__end_of_Do_AdcSample:
	signat	_Do_AdcSample,89
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1   14[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1   20[BANK0 ] unsigned char 
;;  j               1   19[BANK0 ] unsigned char 
;;  adsum           4   22[BANK0 ] volatile unsigned long 
;;  ad_temp         2   30[BANK0 ] volatile unsigned int 
;;  admax           2   28[BANK0 ] volatile unsigned int 
;;  admin           2   26[BANK0 ] volatile unsigned int 
;;  i               1   21[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      18       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext17
__ptext17:	;psect for function _ADC_Sample
psect	text17
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	movwf	(ADC_Sample@adch)
	line	51
	
l3344:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	52
	
l3346:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	58
	
l3348:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u3381
	goto	u3380
u3381:
	goto	l3354
u3380:
	
l3350:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u3391
	goto	u3390
u3391:
	goto	l3354
u3390:
	line	60
	
l3352:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u4857:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u4857
	nop
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	l3356
	line	64
	
l3354:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	bcf	status, 5	;RP0=0, select bank0
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	67
	
l3356:	
;adc_drv.c: 67: if(adch & 0x10)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(ADC_Sample@adch),(4)&7
	goto	u3401
	goto	u3400
u3401:
	goto	l462
u3400:
	line	69
	
l3358:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l3360:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(ADC_Sample@adch),f
	line	71
;adc_drv.c: 71: }
	goto	l3362
	line	72
	
l462:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l3362:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@i)
	line	79
	
l3368:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(ADC_Sample@adch),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u3415:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u3415
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l3370:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	5
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u4867:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u4867
	nop2
opt asmopt_pop

	line	81
	
l3372:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l3374:	
;adc_drv.c: 84: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	l466
	
l467:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u3421
	goto	u3420
u3421:
	goto	l466
u3420:
	line	89
	
l3376:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	l469
	line	90
	
l466:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u3431
	goto	u3430
u3431:
	goto	l467
u3430:
	line	93
	
l3380:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
l3382:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
l3384:	
;adc_drv.c: 96: if(0 == admax)
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u3441
	goto	u3440
u3441:
	goto	l3388
u3440:
	line	98
	
l3386:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	100
;adc_drv.c: 100: }
	goto	l472
	line	102
	
l3388:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u3455
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u3455:
	skipnc
	goto	u3451
	goto	u3450
u3451:
	goto	l3392
u3450:
	line	103
	
l3390:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	l472
	line	105
	
l3392:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u3465
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u3465:
	skipnc
	goto	u3461
	goto	u3460
u3461:
	goto	l472
u3460:
	line	106
	
l3394:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	108
	
l472:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3471
	addwf	(ADC_Sample@adsum+1),f	;volatile
u3471:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3472
	addwf	(ADC_Sample@adsum+2),f	;volatile
u3472:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3473
	addwf	(ADC_Sample@adsum+3),f	;volatile
u3473:

	line	76
	
l3396:	
	incf	(ADC_Sample@i),f
	
l3398:	
	movlw	low(022h)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u3481
	goto	u3480
u3481:
	goto	l3368
u3480:
	line	112
	
l3400:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u3495
	goto	u3496
u3495:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u3496:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u3497
	goto	u3498
u3497:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u3498:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u3499
	goto	u3490
u3499:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u3490:

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u3505
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u3505
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u3505
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u3505:
	skipc
	goto	u3501
	goto	u3500
u3501:
	goto	l476
u3500:
	line	114
	
l3402:	
;adc_drv.c: 114: adsum -= admin;
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u3515
	goto	u3516
u3515:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u3516:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u3517
	goto	u3518
u3517:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u3518:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u3519
	goto	u3510
u3519:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u3510:

	goto	l3404
	line	115
	
l476:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	118
	
l3404:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u3525:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u3520:
	addlw	-1
	skipz
	goto	u3525
	movf	1+(??_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
l3406:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
l469:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_ChargeProcess_Slot

;; *************** function _ChargeProcess_Slot *****************
;; Defined at:
;;		line 92 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   31[BANK0 ] unsigned char 
;;  v_start         2   23[BANK0 ] unsigned int 
;;  rise            2   19[BANK0 ] unsigned int 
;;  v_before        2   21[BANK0 ] unsigned int 
;;  delta           2   17[BANK0 ] unsigned int 
;;  v               2   32[BANK0 ] unsigned int 
;;  ct              2   28[BANK0 ] unsigned int 
;;  tick            2    0        unsigned int 
;;  ty              1   30[BANK0 ] unsigned char 
;;  st              1   27[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      17       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      17       0       0       0
;;Total ram usage:       17 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Detect_BatteryType
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	92
global __ptext18
__ptext18:	;psect for function _ChargeProcess_Slot
psect	text18
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	92
	global	__size_of_ChargeProcess_Slot
	__size_of_ChargeProcess_Slot	equ	__end_of_ChargeProcess_Slot-_ChargeProcess_Slot
	
_ChargeProcess_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _ChargeProcess_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;ChargeProcess_Slot@idx stored from wreg
	movwf	(ChargeProcess_Slot@idx)
	line	96
	
l3960:	
	line	98
	
l3962:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(ChargeProcess_Slot@st)
	
l3964:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(ChargeProcess_Slot@ty)
	
l3966:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(ChargeProcess_Slot@v)
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v+1)
	
l3968:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(ChargeProcess_Slot@ct)
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@ct+1)
	goto	l4172
	line	103
	
l3970:	
;charge_mgr.c: 103: ct = 0;
	clrf	(ChargeProcess_Slot@ct)
	clrf	(ChargeProcess_Slot@ct+1)
	line	104
	
l3972:	
;charge_mgr.c: 104: st = 1;
	clrf	(ChargeProcess_Slot@st)
	incf	(ChargeProcess_Slot@st),f
	line	105
;charge_mgr.c: 105: break;
	goto	l4174
	line	108
	
l3974:	
;charge_mgr.c: 108: ct += tick;
	incf	(ChargeProcess_Slot@ct),f
	skipnz
	incf	(ChargeProcess_Slot@ct+1),f
	line	109
;charge_mgr.c: 109: if(ct < (2 * 100))
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1),w
	movlw	0C8h
	skipnz
	subwf	(ChargeProcess_Slot@ct),w
	skipnc
	goto	u4281
	goto	u4280
u4281:
	goto	l3978
u4280:
	goto	l4174
	line	112
	
l3978:	
;charge_mgr.c: 112: ty = Detect_BatteryType(v);
	movf	(ChargeProcess_Slot@v+1),w
	movwf	(Detect_BatteryType@voltage+1)
	movf	(ChargeProcess_Slot@v),w
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	movwf	(ChargeProcess_Slot@ty)
	line	114
	
l3980:	
;charge_mgr.c: 114: if(ty == 5)
		movlw	5
	xorwf	((ChargeProcess_Slot@ty)),w
	btfss	status,2
	goto	u4291
	goto	u4290
u4291:
	goto	l3988
u4290:
	line	116
	
l3982:	
;charge_mgr.c: 115: {
;charge_mgr.c: 116: g_impRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx),w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v),w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1),w
	movwf	indf
	line	117
	
l3984:	
;charge_mgr.c: 117: st = 8;
	movlw	low(08h)
	movwf	(ChargeProcess_Slot@st)
	line	118
	
l3986:	
;charge_mgr.c: 118: ct = 0;
	clrf	(ChargeProcess_Slot@ct)
	clrf	(ChargeProcess_Slot@ct+1)
	line	119
;charge_mgr.c: 119: }
	goto	l4026
	line	120
	
l3988:	
;charge_mgr.c: 120: else if(ty == 2 || ty == 3 || ty == 0)
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)),w
	btfsc	status,2
	goto	u4301
	goto	u4300
u4301:
	goto	l3994
u4300:
	
l3990:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)),w
	btfsc	status,2
	goto	u4311
	goto	u4310
u4311:
	goto	l3994
u4310:
	
l3992:	
	movf	((ChargeProcess_Slot@ty)),w
	btfss	status,2
	goto	u4321
	goto	u4320
u4321:
	goto	l4004
u4320:
	line	122
	
l3994:	
;charge_mgr.c: 121: {
;charge_mgr.c: 122: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)
	line	123
	
l3996:	
;charge_mgr.c: 123: if(ty == 2 || ty == 3)
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)),w
	btfsc	status,2
	goto	u4331
	goto	u4330
u4331:
	goto	l4000
u4330:
	
l3998:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)),w
	btfss	status,2
	goto	u4341
	goto	u4340
u4341:
	goto	l4026
u4340:
	line	125
	
l4000:	
;charge_mgr.c: 124: {
;charge_mgr.c: 125: g_detectLogSlot = idx;
	movf	(ChargeProcess_Slot@idx),w
	movwf	(_g_detectLogSlot)	;volatile
	line	126
;charge_mgr.c: 126: g_detectLogType = ty;
	movf	(ChargeProcess_Slot@ty),w
	movwf	(_g_detectLogType)	;volatile
	line	127
	
l4002:	
;charge_mgr.c: 127: g_detectLogFlag = 1;
	bsf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	goto	l4026
	line	132
	
l4004:	
;charge_mgr.c: 130: else
;charge_mgr.c: 131: {
;charge_mgr.c: 132: if(v <= 2357)
	movlw	09h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	036h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u4351
	goto	u4350
u4351:
	goto	l4010
u4350:
	line	134
	
l4006:	
;charge_mgr.c: 133: {
;charge_mgr.c: 134: st = 2;
	movlw	low(02h)
	movwf	(ChargeProcess_Slot@st)
	goto	l3986
	line	137
	
l4010:	
;charge_mgr.c: 137: else if(v < 2640)
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	050h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u4361
	goto	u4360
u4361:
	goto	l4016
u4360:
	line	139
	
l4012:	
;charge_mgr.c: 138: {
;charge_mgr.c: 139: st = 3;
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@st)
	goto	l3986
	line	142
	
l4016:	
;charge_mgr.c: 142: else if(v >= 3361)
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	021h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4371
	goto	u4370
u4371:
	goto	l4022
u4370:
	line	144
	
l4018:	
;charge_mgr.c: 143: {
;charge_mgr.c: 144: st = 5;
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)
	goto	l3986
	line	149
	
l4022:	
;charge_mgr.c: 147: else
;charge_mgr.c: 148: {
;charge_mgr.c: 149: st = 4;
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)
	goto	l3986
	line	154
	
l4026:	
;charge_mgr.c: 151: }
;charge_mgr.c: 152: }
;charge_mgr.c: 154: g_dbgSlot = idx;
	movf	(ChargeProcess_Slot@idx),w
	movwf	(_g_dbgSlot)	;volatile
	line	155
	
l4028:	
;charge_mgr.c: 155: g_dbgNewState = st;
	movf	(ChargeProcess_Slot@st),w
	movwf	(_g_dbgNewState)	;volatile
	line	156
	
l4030:	
;charge_mgr.c: 156: g_dbgNewType = ty;
	movf	(ChargeProcess_Slot@ty),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_dbgNewType)^080h	;volatile
	line	157
	
l4032:	
;charge_mgr.c: 157: g_dbgVoltage = v;
	bcf	status, 5	;RP0=0, select bank0
	movf	(ChargeProcess_Slot@v+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_dbgVoltage+1)^080h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(ChargeProcess_Slot@v),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_dbgVoltage)^080h	;volatile
	line	158
	
l4034:	
;charge_mgr.c: 158: g_dbgDetectFlag = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	159
;charge_mgr.c: 159: break;
	goto	l4174
	line	162
	
l4036:	
;charge_mgr.c: 162: if(v >= 3990)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4381
	goto	u4380
u4381:
	goto	l4040
u4380:
	line	164
	
l4038:	
;charge_mgr.c: 163: {
;charge_mgr.c: 164: ty = 0;
	clrf	(ChargeProcess_Slot@ty)
	line	165
;charge_mgr.c: 165: st = 0;
	clrf	(ChargeProcess_Slot@st)
	line	166
;charge_mgr.c: 166: break;
	goto	l4174
	line	168
	
l4040:	
;charge_mgr.c: 167: }
;charge_mgr.c: 168: ct += tick;
	incf	(ChargeProcess_Slot@ct),f
	skipnz
	incf	(ChargeProcess_Slot@ct+1),f
	line	169
;charge_mgr.c: 169: if(ct < 3)
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1),w
	movlw	03h
	skipnz
	subwf	(ChargeProcess_Slot@ct),w
	skipnc
	goto	u4391
	goto	u4390
u4391:
	goto	l4044
u4390:
	goto	l4174
	line	173
	
l4044:	
;charge_mgr.c: 172: {
;charge_mgr.c: 173: unsigned int v_before = g_impRefV[idx];
	clrc
	rlf	(ChargeProcess_Slot@idx),w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_before)
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_before+1)
	line	175
	
l4046:	
;charge_mgr.c: 174: unsigned int delta;
;charge_mgr.c: 175: if(v_before > v) delta = v_before - v;
	movf	(ChargeProcess_Slot@v_before+1),w
	subwf	(ChargeProcess_Slot@v+1),w
	skipz
	goto	u4405
	movf	(ChargeProcess_Slot@v_before),w
	subwf	(ChargeProcess_Slot@v),w
u4405:
	skipnc
	goto	u4401
	goto	u4400
u4401:
	goto	l4050
u4400:
	
l4048:	
	movf	(ChargeProcess_Slot@v_before+1),w
	movwf	(ChargeProcess_Slot@delta+1)
	movf	(ChargeProcess_Slot@v_before),w
	movwf	(ChargeProcess_Slot@delta)
	movf	(ChargeProcess_Slot@v),w
	subwf	(ChargeProcess_Slot@delta),f
	movf	(ChargeProcess_Slot@v+1),w
	skipc
	decf	(ChargeProcess_Slot@delta+1),f
	subwf	(ChargeProcess_Slot@delta+1),f
	goto	l4052
	line	176
	
l4050:	
;charge_mgr.c: 176: else delta = 0;
	clrf	(ChargeProcess_Slot@delta)
	clrf	(ChargeProcess_Slot@delta+1)
	line	178
	
l4052:	
;charge_mgr.c: 178: if(delta > 80)
	movlw	0
	subwf	(ChargeProcess_Slot@delta+1),w
	movlw	051h
	skipnz
	subwf	(ChargeProcess_Slot@delta),w
	skipc
	goto	u4411
	goto	u4410
u4411:
	goto	l4058
u4410:
	line	180
	
l4054:	
;charge_mgr.c: 179: {
;charge_mgr.c: 180: ty = 3;
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@ty)
	line	181
;charge_mgr.c: 181: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)
	line	182
;charge_mgr.c: 182: g_detectLogSlot = idx;
	movf	(ChargeProcess_Slot@idx),w
	movwf	(_g_detectLogSlot)	;volatile
	line	183
;charge_mgr.c: 183: g_detectLogType = 3;
	movlw	low(03h)
	movwf	(_g_detectLogType)	;volatile
	line	184
	
l4056:	
;charge_mgr.c: 184: g_detectLogFlag = 1;
	bsf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	line	185
;charge_mgr.c: 185: }
	goto	l4174
	line	188
	
l4058:	
;charge_mgr.c: 186: else
;charge_mgr.c: 187: {
;charge_mgr.c: 188: g_impRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx),w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v),w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1),w
	movwf	indf
	line	189
	
l4060:	
;charge_mgr.c: 189: st = 9;
	movlw	low(09h)
	movwf	(ChargeProcess_Slot@st)
	line	190
	
l4062:	
;charge_mgr.c: 190: ct = 0;
	clrf	(ChargeProcess_Slot@ct)
	clrf	(ChargeProcess_Slot@ct+1)
	goto	l4174
	line	196
	
l4064:	
;charge_mgr.c: 196: if(v >= 3990)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4421
	goto	u4420
u4421:
	goto	l4068
u4420:
	goto	l4038
	line	202
	
l4068:	
;charge_mgr.c: 201: }
;charge_mgr.c: 202: ct += tick;
	incf	(ChargeProcess_Slot@ct),f
	skipnz
	incf	(ChargeProcess_Slot@ct+1),f
	line	203
;charge_mgr.c: 203: if(ct < (30 * 100))
	movlw	0Bh
	subwf	(ChargeProcess_Slot@ct+1),w
	movlw	0B8h
	skipnz
	subwf	(ChargeProcess_Slot@ct),w
	skipnc
	goto	u4431
	goto	u4430
u4431:
	goto	l4078
u4430:
	line	205
	
l4070:	
;charge_mgr.c: 204: {
;charge_mgr.c: 205: if(v > 3204)
	movlw	0Ch
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	085h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4441
	goto	u4440
u4441:
	goto	l4174
u4440:
	line	207
	
l4072:	
;charge_mgr.c: 206: {
;charge_mgr.c: 207: ty = 1;
	clrf	(ChargeProcess_Slot@ty)
	incf	(ChargeProcess_Slot@ty),f
	line	208
	
l4074:	
;charge_mgr.c: 208: st = 4;
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)
	goto	l4062
	line	215
	
l4078:	
;charge_mgr.c: 212: }
;charge_mgr.c: 214: {
;charge_mgr.c: 215: unsigned int v_start = g_impRefV[idx];
	clrc
	rlf	(ChargeProcess_Slot@idx),w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_start)
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_start+1)
	line	217
	
l4080:	
;charge_mgr.c: 216: unsigned int rise;
;charge_mgr.c: 217: if(v > v_start) rise = v - v_start;
	movf	(ChargeProcess_Slot@v+1),w
	subwf	(ChargeProcess_Slot@v_start+1),w
	skipz
	goto	u4455
	movf	(ChargeProcess_Slot@v),w
	subwf	(ChargeProcess_Slot@v_start),w
u4455:
	skipnc
	goto	u4451
	goto	u4450
u4451:
	goto	l4084
u4450:
	
l4082:	
	movf	(ChargeProcess_Slot@v+1),w
	movwf	(ChargeProcess_Slot@rise+1)
	movf	(ChargeProcess_Slot@v),w
	movwf	(ChargeProcess_Slot@rise)
	movf	(ChargeProcess_Slot@v_start),w
	subwf	(ChargeProcess_Slot@rise),f
	movf	(ChargeProcess_Slot@v_start+1),w
	skipc
	decf	(ChargeProcess_Slot@rise+1),f
	subwf	(ChargeProcess_Slot@rise+1),f
	goto	l4086
	line	218
	
l4084:	
;charge_mgr.c: 218: else rise = 0;
	clrf	(ChargeProcess_Slot@rise)
	clrf	(ChargeProcess_Slot@rise+1)
	line	220
	
l4086:	
;charge_mgr.c: 220: if(rise >= 20 && v > 3204)
	movlw	0
	subwf	(ChargeProcess_Slot@rise+1),w
	movlw	014h
	skipnz
	subwf	(ChargeProcess_Slot@rise),w
	skipc
	goto	u4461
	goto	u4460
u4461:
	goto	l4096
u4460:
	
l4088:	
	movlw	0Ch
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	085h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4471
	goto	u4470
u4471:
	goto	l4096
u4470:
	goto	l4072
	line	228
	
l4096:	
;charge_mgr.c: 226: else
;charge_mgr.c: 227: {
;charge_mgr.c: 228: ty = 2;
	movlw	low(02h)
	movwf	(ChargeProcess_Slot@ty)
	line	229
;charge_mgr.c: 229: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)
	line	230
;charge_mgr.c: 230: g_detectLogSlot = idx;
	movf	(ChargeProcess_Slot@idx),w
	movwf	(_g_detectLogSlot)	;volatile
	line	231
;charge_mgr.c: 231: g_detectLogType = 2;
	movlw	low(02h)
	movwf	(_g_detectLogType)	;volatile
	goto	l4056
	line	238
	
l4100:	
;charge_mgr.c: 238: ct += tick;
	incf	(ChargeProcess_Slot@ct),f
	skipnz
	incf	(ChargeProcess_Slot@ct+1),f
	line	239
;charge_mgr.c: 239: if(ct > (60 * 100))
	movlw	017h
	subwf	(ChargeProcess_Slot@ct+1),w
	movlw	071h
	skipnz
	subwf	(ChargeProcess_Slot@ct),w
	skipc
	goto	u4481
	goto	u4480
u4481:
	goto	l4104
u4480:
	line	241
	
l4102:	
;charge_mgr.c: 240: {
;charge_mgr.c: 241: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)
	line	242
;charge_mgr.c: 242: break;
	goto	l4174
	line	244
	
l4104:	
;charge_mgr.c: 243: }
;charge_mgr.c: 244: if(v > 2357)
	movlw	09h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	036h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4491
	goto	u4490
u4491:
	goto	l4110
u4490:
	line	246
	
l4106:	
;charge_mgr.c: 245: {
;charge_mgr.c: 246: st = 3;
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@st)
	goto	l4062
	line	250
	
l4110:	
;charge_mgr.c: 249: }
;charge_mgr.c: 250: if(v >= 3418)
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	05Ah
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4501
	goto	u4500
u4501:
	goto	l4174
u4500:
	goto	l4102
	line	258
	
l4114:	
;charge_mgr.c: 258: ct += tick;
	incf	(ChargeProcess_Slot@ct),f
	skipnz
	incf	(ChargeProcess_Slot@ct+1),f
	line	259
;charge_mgr.c: 259: if(ct > (300 * 100))
	movlw	075h
	subwf	(ChargeProcess_Slot@ct+1),w
	movlw	031h
	skipnz
	subwf	(ChargeProcess_Slot@ct),w
	skipc
	goto	u4511
	goto	u4510
u4511:
	goto	l4118
u4510:
	goto	l4102
	line	264
	
l4118:	
;charge_mgr.c: 263: }
;charge_mgr.c: 264: if(v >= 3418)
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	05Ah
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4521
	goto	u4520
u4521:
	goto	l4122
u4520:
	goto	l4102
	line	269
	
l4122:	
;charge_mgr.c: 268: }
;charge_mgr.c: 269: if(v >= 2993)
	movlw	0Bh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	0B1h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4531
	goto	u4530
u4531:
	goto	l4174
u4530:
	goto	l4074
	line	277
	
l4128:	
;charge_mgr.c: 277: ct += tick;
	incf	(ChargeProcess_Slot@ct),f
	skipnz
	incf	(ChargeProcess_Slot@ct+1),f
	line	283
;charge_mgr.c: 278: if(ct > (10800UL * 100))
	
l4132:	
;charge_mgr.c: 282: }
;charge_mgr.c: 283: if(v >= 3418)
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	05Ah
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4541
	goto	u4540
u4541:
	goto	l4136
u4540:
	goto	l4102
	line	288
	
l4136:	
;charge_mgr.c: 287: }
;charge_mgr.c: 288: if(v >= 3361)
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	021h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4551
	goto	u4550
u4551:
	goto	l4174
u4550:
	line	290
	
l4138:	
;charge_mgr.c: 289: {
;charge_mgr.c: 290: st = 5;
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)
	goto	l4062
	line	296
	
l4142:	
;charge_mgr.c: 296: ct += tick;
	incf	(ChargeProcess_Slot@ct),f
	skipnz
	incf	(ChargeProcess_Slot@ct+1),f
	line	297
;charge_mgr.c: 297: if(ct > (600 * 100))
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1),w
	movlw	061h
	skipnz
	subwf	(ChargeProcess_Slot@ct),w
	skipc
	goto	u4561
	goto	u4560
u4561:
	goto	l4174
u4560:
	line	298
	
l4144:	
;charge_mgr.c: 298: st = 6;
	movlw	low(06h)
	movwf	(ChargeProcess_Slot@st)
	goto	l4174
	line	302
	
l4146:	
;charge_mgr.c: 302: if(v < (3361 - 10))
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	017h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u4571
	goto	u4570
u4571:
	goto	l4174
u4570:
	goto	l4074
	line	310
	
l4152:	
;charge_mgr.c: 310: if(ty == 2 || ty == 3)
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)),w
	btfsc	status,2
	goto	u4581
	goto	u4580
u4581:
	goto	l4156
u4580:
	
l4154:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)),w
	btfss	status,2
	goto	u4591
	goto	u4590
u4591:
	goto	l4160
u4590:
	line	312
	
l4156:	
;charge_mgr.c: 311: {
;charge_mgr.c: 312: if(v >= 3990)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4601
	goto	u4600
u4601:
	goto	l4174
u4600:
	line	314
	
l4158:	
;charge_mgr.c: 313: {
;charge_mgr.c: 314: ty = 0;
	clrf	(ChargeProcess_Slot@ty)
	line	315
;charge_mgr.c: 315: st = 0;
	clrf	(ChargeProcess_Slot@st)
	line	316
;charge_mgr.c: 316: ct = 0;
	clrf	(ChargeProcess_Slot@ct)
	clrf	(ChargeProcess_Slot@ct+1)
	goto	l4174
	line	320
	
l4160:	
;charge_mgr.c: 319: }
;charge_mgr.c: 320: if(v > 2357 && v < 3990)
	movlw	09h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	036h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4611
	goto	u4610
u4611:
	goto	l4174
u4610:
	
l4162:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u4621
	goto	u4620
u4621:
	goto	l4174
u4620:
	line	322
	
l4164:	
;charge_mgr.c: 321: {
;charge_mgr.c: 322: st = 1;
	clrf	(ChargeProcess_Slot@st)
	incf	(ChargeProcess_Slot@st),f
	goto	l4062
	line	328
	
l4168:	
;charge_mgr.c: 328: st = 0;
	clrf	(ChargeProcess_Slot@st)
	line	329
;charge_mgr.c: 329: break;
	goto	l4174
	line	100
	
l4172:	
	movf	(ChargeProcess_Slot@st),w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l3970
	xorlw	1^0	; case 1
	skipnz
	goto	l3974
	xorlw	2^1	; case 2
	skipnz
	goto	l4100
	xorlw	3^2	; case 3
	skipnz
	goto	l4114
	xorlw	4^3	; case 4
	skipnz
	goto	l4128
	xorlw	5^4	; case 5
	skipnz
	goto	l4142
	xorlw	6^5	; case 6
	skipnz
	goto	l4146
	xorlw	7^6	; case 7
	skipnz
	goto	l4152
	xorlw	8^7	; case 8
	skipnz
	goto	l4036
	xorlw	9^8	; case 9
	skipnz
	goto	l4064
	goto	l4168
	opt asmopt_pop

	line	332
	
l4174:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@st),w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@ty),w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v),w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1),w
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@ct),w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@ct+1),w
	movwf	indf
	line	333
	
l611:	
	return
	opt stack 0
GLOBAL	__end_of_ChargeProcess_Slot
	__end_of_ChargeProcess_Slot:
	signat	_ChargeProcess_Slot,4217
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1   14[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1   16[BANK0 ] unsigned char 
;;  product         1   15[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 100/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_main
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext19
__ptext19:	;psect for function ___bmul
psect	text19
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplier)
	line	6
	
l3592:	
	clrf	(___bmul@product)
	line	43
	
l3594:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u3841
	goto	u3840
u3841:
	goto	l3598
u3840:
	line	44
	
l3596:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l3598:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l3600:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u3851
	goto	u3850
u3851:
	goto	l3594
u3850:
	line	50
	
l3602:	
	movf	(___bmul@product),w
	line	51
	
l734:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 55 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2   14[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	55
global __ptext20
__ptext20:	;psect for function _Detect_BatteryType
psect	text20
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	55
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	57
	
l2468:	
;charge_mgr.c: 57: if(voltage >= 3990)
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2131
	goto	u2130
u2131:
	goto	l2474
u2130:
	line	58
	
l2470:	
;charge_mgr.c: 58: return 0;
	movlw	low(0)
	goto	l538
	line	59
	
l2474:	
;charge_mgr.c: 59: if(voltage < 2314)
	movlw	09h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0Ah
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2141
	goto	u2140
u2141:
	goto	l2480
u2140:
	goto	l2470
	line	63
	
l2480:	
;charge_mgr.c: 63: if(voltage >= 3063 && voltage <= 3204)
	movlw	0Bh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2151
	goto	u2150
u2151:
	goto	l2488
u2150:
	
l2482:	
	movlw	0Ch
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	085h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2161
	goto	u2160
u2161:
	goto	l2488
u2160:
	line	64
	
l2484:	
;charge_mgr.c: 64: return 5;
	movlw	low(05h)
	goto	l538
	line	67
	
l2488:	
;charge_mgr.c: 67: if(voltage >= 2640 && voltage <= 3361)
	movlw	0Ah
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	050h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2171
	goto	u2170
u2171:
	goto	l2496
u2170:
	
l2490:	
	movlw	0Dh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	022h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2181
	goto	u2180
u2181:
	goto	l2496
u2180:
	line	68
	
l2492:	
;charge_mgr.c: 68: return 1;
	movlw	low(01h)
	goto	l538
	line	69
	
l2496:	
;charge_mgr.c: 69: if(voltage > 3361 && voltage < 3418)
	movlw	0Dh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	022h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2191
	goto	u2190
u2191:
	goto	l2504
u2190:
	
l2498:	
	movlw	0Dh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	05Ah
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2201
	goto	u2200
u2201:
	goto	l2504
u2200:
	goto	l2492
	line	71
	
l2504:	
;charge_mgr.c: 71: if(voltage >= 3418 && voltage < 3990)
	movlw	0Dh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	05Ah
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2211
	goto	u2210
u2211:
	goto	l2512
u2210:
	
l2506:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2221
	goto	u2220
u2221:
	goto	l2512
u2220:
	goto	l2492
	line	73
	
l2512:	
;charge_mgr.c: 73: if(voltage >= 2314 && voltage < 2640)
	movlw	09h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0Ah
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2231
	goto	u2230
u2231:
	goto	l2470
u2230:
	
l2514:	
	movlw	0Ah
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	050h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2241
	goto	u2240
u2241:
	goto	l2470
u2240:
	goto	l2492
	line	77
	
l538:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 157 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_CCCV_Control
;;		_Charging_Control
;;		_Led_BlinkProcess
;;		_PowerOnLedSequence
;;		_Update_LED_Slot
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	157
global __ptext21
__ptext21:	;psect for function _Isr_Timer
psect	text21
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	157
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 2
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	btemp+1,w
	movwf	(??_Isr_Timer+3)
	ljmp	_Isr_Timer
psect	text21
	line	160
	
i1l4176:	
;main.c: 160: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u463_21
	goto	u463_20
u463_21:
	goto	i1l367
u463_20:
	line	162
	
i1l4178:	
;main.c: 161: {
;main.c: 162: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	163
	
i1l4180:	
;main.c: 163: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	164
# 164 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text21
	line	167
	
i1l4182:	
;main.c: 167: g_pwmCounter++;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	168
	
i1l4184:	
;main.c: 168: if(g_pwmCounter >= 32)
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u464_21
	goto	u464_20
u464_21:
	goto	i1l4188
u464_20:
	line	169
	
i1l4186:	
;main.c: 169: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	172
	
i1l4188:	
;main.c: 172: if(g_pwmDuty > 0 && g_pwmCounter < g_pwmDuty)
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u465_21
	goto	u465_20
u465_21:
	goto	i1l364
u465_20:
	
i1l4190:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u466_21
	goto	u466_20
u466_21:
	goto	i1l364
u466_20:
	line	173
	
i1l4192:	
;main.c: 173: RB7 = 1;
	bsf	(55/8),(55)&7	;volatile
	goto	i1l4194
	line	174
	
i1l364:	
	line	175
;main.c: 174: else
;main.c: 175: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	178
	
i1l4194:	
;main.c: 178: if(g_powerOnPhase < 2)
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u467_21
	goto	u467_20
u467_21:
	goto	i1l4252
u467_20:
	line	180
	
i1l4196:	
;main.c: 179: {
;main.c: 180: PowerOnLedSequence();
	fcall	_PowerOnLedSequence
	goto	i1l367
	line	187
;main.c: 186: {
;main.c: 187: case 0:
	
i1l369:	
	line	189
;main.c: 189: if(!g_adcBusy && !g_doAdcSample)
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u468_21
	goto	u468_20
u468_21:
	goto	i1l367
u468_20:
	
i1l4200:	
	btfsc	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u469_21
	goto	u469_20
u469_21:
	goto	i1l367
u469_20:
	goto	i1l4204
	line	191
	
i1l373:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l386
	
i1l375:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l386
	
i1l376:	
	bsf	(51/8),(51)&7	;volatile
	goto	i1l386
	
i1l377:	
	bsf	(50/8),(50)&7	;volatile
	goto	i1l386
	
i1l378:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l386
	
i1l379:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l386
	
i1l380:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l386
	
i1l381:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l386
	
i1l382:	
	bsf	(48/8),(48)&7	;volatile
	goto	i1l386
	
i1l383:	
	bsf	(49/8),(49)&7	;volatile
	goto	i1l386
	
i1l384:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l386
	
i1l385:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l386
	
i1l4204:	
	movf	(_g_scanIndex),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l373
	xorlw	1^0	; case 1
	skipnz
	goto	i1l375
	xorlw	2^1	; case 2
	skipnz
	goto	i1l376
	xorlw	3^2	; case 3
	skipnz
	goto	i1l377
	xorlw	4^3	; case 4
	skipnz
	goto	i1l378
	xorlw	5^4	; case 5
	skipnz
	goto	i1l379
	xorlw	6^5	; case 6
	skipnz
	goto	i1l380
	xorlw	7^6	; case 7
	skipnz
	goto	i1l381
	xorlw	8^7	; case 8
	skipnz
	goto	i1l382
	xorlw	9^8	; case 9
	skipnz
	goto	i1l383
	xorlw	10^9	; case 10
	skipnz
	goto	i1l384
	xorlw	11^10	; case 11
	skipnz
	goto	i1l385
	goto	i1l386
	opt asmopt_pop

	
i1l386:	
	line	192
;main.c: 192: g_doAdcSample = 1;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	i1l367
	line	198
	
i1l4206:	
;main.c: 198: Update_LED_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_Update_LED_Slot
	line	200
	
i1l4208:	
;main.c: 200: g_scanPhase = 2;
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_scanPhase)	;volatile
	line	201
;main.c: 201: break;
	goto	i1l367
	line	204
	
i1l4210:	
;main.c: 204: if(g_scanIndex == 0)
	movf	((_g_scanIndex)),w	;volatile
	btfss	status,2
	goto	u470_21
	goto	u470_20
u470_21:
	goto	i1l4244
u470_20:
	line	206
	
i1l4212:	
;main.c: 205: {
;main.c: 206: Charging_Control();
	fcall	_Charging_Control
	line	207
	
i1l4214:	
;main.c: 207: CCCV_Control();
	fcall	_CCCV_Control
	line	208
	
i1l4216:	
;main.c: 208: Led_BlinkProcess();
	fcall	_Led_BlinkProcess
	line	212
	
i1l4218:	
;main.c: 211: {
;main.c: 212: if(g_tempPhase == 0)
	bcf	status, 5	;RP0=0, select bank0
	movf	((_g_tempPhase)),w	;volatile
	btfss	status,2
	goto	u471_21
	goto	u471_20
u471_21:
	goto	i1l4230
u471_20:
	line	214
	
i1l4220:	
;main.c: 213: {
;main.c: 214: g_tempReadRoundCnt++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_tempReadRoundCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1)^080h,f	;volatile
	line	215
	
i1l4222:	
;main.c: 215: if(g_tempReadRoundCnt >= 200)
	movlw	0
	subwf	(_g_tempReadRoundCnt+1)^080h,w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt)^080h,w	;volatile
	skipc
	goto	u472_21
	goto	u472_20
u472_21:
	goto	i1l4238
u472_20:
	line	217
	
i1l4224:	
;main.c: 216: {
;main.c: 217: g_tempReadRoundCnt = 0;
	clrf	(_g_tempReadRoundCnt)^080h	;volatile
	clrf	(_g_tempReadRoundCnt+1)^080h	;volatile
	line	218
	
i1l4226:	
;main.c: 218: g_tempPhase = 1;
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_tempPhase)	;volatile
	line	219
	
i1l4228:	
;main.c: 219: g_tempSettleCnt = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	goto	i1l4238
	line	224
	
i1l4230:	
;main.c: 222: else
;main.c: 223: {
;main.c: 224: g_tempSettleCnt++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_tempSettleCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1)^080h,f	;volatile
	line	225
	
i1l4232:	
;main.c: 225: if(g_tempSettleCnt >= 60)
	movlw	0
	subwf	(_g_tempSettleCnt+1)^080h,w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt)^080h,w	;volatile
	skipc
	goto	u473_21
	goto	u473_20
u473_21:
	goto	i1l4238
u473_20:
	line	227
	
i1l4234:	
;main.c: 226: {
;main.c: 227: g_doNtcRead = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	228
	
i1l4236:	
;main.c: 228: g_tempSettleCnt = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	line	229
;main.c: 229: g_tempPhase = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_tempPhase)	;volatile
	line	235
	
i1l4238:	
;main.c: 230: }
;main.c: 231: }
;main.c: 232: }
;main.c: 235: if(++g_printTick >= 100)
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_printTick)^080h,f	;volatile
	skipnz
	incf	(_g_printTick+1)^080h,f	;volatile
	movlw	0
	subwf	((_g_printTick+1)^080h),w	;volatile
	movlw	064h
	skipnz
	subwf	((_g_printTick)^080h),w	;volatile
	skipc
	goto	u474_21
	goto	u474_20
u474_21:
	goto	i1l4244
u474_20:
	line	237
	
i1l4240:	
;main.c: 236: {
;main.c: 237: g_printTick = 0;
	clrf	(_g_printTick)^080h	;volatile
	clrf	(_g_printTick+1)^080h	;volatile
	line	238
	
i1l4242:	
;main.c: 238: g_printFlag = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	243
	
i1l4244:	
;main.c: 239: }
;main.c: 240: }
;main.c: 243: if(++g_scanIndex >= 12)
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	incf	(_g_scanIndex),f	;volatile
	subwf	((_g_scanIndex)),w	;volatile
	skipc
	goto	u475_21
	goto	u475_20
u475_21:
	goto	i1l396
u475_20:
	line	244
	
i1l4246:	
;main.c: 244: g_scanIndex = 0;
	clrf	(_g_scanIndex)	;volatile
	
i1l396:	
	line	245
;main.c: 245: g_scanPhase = 0;
	clrf	(_g_scanPhase)	;volatile
	line	246
;main.c: 246: break;
	goto	i1l367
	line	185
	
i1l4252:	
	movf	(_g_scanPhase),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 2
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           17     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l369
	xorlw	1^0	; case 1
	skipnz
	goto	i1l4206
	xorlw	2^1	; case 2
	skipnz
	goto	i1l4210
	goto	i1l396
	opt asmopt_pop

	line	253
	
i1l367:	
	movf	(??_Isr_Timer+3),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	btemp+1
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	_Update_LED_Slot

;; *************** function _Update_LED_Slot *****************
;; Defined at:
;;		line 30 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    4[COMMON] unsigned char 
;;  led             1    5[COMMON] unsigned char 
;;  s               1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 800/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         3       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	30
global __ptext22
__ptext22:	;psect for function _Update_LED_Slot
psect	text22
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	30
	global	__size_of_Update_LED_Slot
	__size_of_Update_LED_Slot	equ	__end_of_Update_LED_Slot-_Update_LED_Slot
	
_Update_LED_Slot:	
;incstack = 0
	opt	stack 2
; Regs used in _Update_LED_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Update_LED_Slot@idx stored from wreg
	movwf	(Update_LED_Slot@idx)
	line	32
	
i1l3684:	
;led.c: 32: unsigned char s = g_slot[idx].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Update_LED_Slot@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(Update_LED_Slot@s)
	line	35
;led.c: 33: unsigned char led;
;led.c: 35: switch(s)
	goto	i1l3696
	line	38
	
i1l3686:	
;led.c: 38: led = 0;
	clrf	(Update_LED_Slot@led)
	line	39
;led.c: 39: break;
	goto	i1l3698
	line	43
	
i1l688:	
	line	46
	
i1l691:	
	line	47
;led.c: 41: case 2:
;led.c: 42: case 3:
;led.c: 43: case 4:
;led.c: 44: case 5:
;led.c: 45: case 8:
;led.c: 46: case 9:
;led.c: 47: led = 1;
	clrf	(Update_LED_Slot@led)
	incf	(Update_LED_Slot@led),f
	line	48
;led.c: 48: break;
	goto	i1l3698
	line	50
	
i1l3688:	
;led.c: 50: led = 2;
	movlw	low(02h)
	movwf	(Update_LED_Slot@led)
	line	51
;led.c: 51: break;
	goto	i1l3698
	line	53
	
i1l3690:	
;led.c: 53: led = 3;
	movlw	low(03h)
	movwf	(Update_LED_Slot@led)
	line	54
;led.c: 54: break;
	goto	i1l3698
	line	35
	
i1l3696:	
	movf	(Update_LED_Slot@s),w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l3686
	xorlw	1^0	; case 1
	skipnz
	goto	i1l688
	xorlw	2^1	; case 2
	skipnz
	goto	i1l691
	xorlw	3^2	; case 3
	skipnz
	goto	i1l691
	xorlw	4^3	; case 4
	skipnz
	goto	i1l691
	xorlw	5^4	; case 5
	skipnz
	goto	i1l691
	xorlw	6^5	; case 6
	skipnz
	goto	i1l3688
	xorlw	7^6	; case 7
	skipnz
	goto	i1l3690
	xorlw	8^7	; case 8
	skipnz
	goto	i1l691
	xorlw	9^8	; case 9
	skipnz
	goto	i1l691
	goto	i1l3686
	opt asmopt_pop

	line	60
	
i1l3698:	
;led.c: 60: g_ledState[idx] = led;
	movf	(Update_LED_Slot@idx),w
	addlw	low(_g_ledState|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Update_LED_Slot@led),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	line	61
	
i1l695:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Slot
	__end_of_Update_LED_Slot:
	signat	_Update_LED_Slot,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 97 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	line	97
global __ptext23
__ptext23:	;psect for function _PowerOnLedSequence
psect	text23
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	97
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	99
	
i1l2674:	
;led.c: 99: g_powerOnTimer++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_powerOnTimer)^080h,f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1)^080h,f	;volatile
	line	101
	
i1l2676:	
;led.c: 101: if(g_powerOnPhase == 0)
	bcf	status, 5	;RP0=0, select bank0
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u238_21
	goto	u238_20
u238_21:
	goto	i1l2684
u238_20:
	line	104
	
i1l2678:	
;led.c: 102: {
;led.c: 104: if(g_powerOnTimer >= 100)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u239_21
	goto	u239_20
u239_21:
	goto	i1l710
u239_20:
	line	106
	
i1l2680:	
;led.c: 105: {
;led.c: 106: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)^080h	;volatile
	clrf	(_g_powerOnTimer+1)^080h	;volatile
	line	107
	
i1l2682:	
;led.c: 107: g_powerOnPhase = 1;
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l710
	line	110
	
i1l2684:	
;led.c: 110: else if(g_powerOnPhase == 1)
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u240_21
	goto	u240_20
u240_21:
	goto	i1l710
u240_20:
	line	113
	
i1l2686:	
;led.c: 111: {
;led.c: 113: if(g_powerOnTimer >= 100)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u241_21
	goto	u241_20
u241_21:
	goto	i1l710
u241_20:
	line	115
	
i1l2688:	
;led.c: 114: {
;led.c: 115: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)^080h	;volatile
	clrf	(_g_powerOnTimer+1)^080h	;volatile
	line	116
	
i1l2690:	
;led.c: 116: g_powerOnPhase = 2;
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_powerOnPhase)	;volatile
	line	120
	
i1l710:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
	global	_Led_BlinkProcess

;; *************** function _Led_BlinkProcess *****************
;; Defined at:
;;		line 71 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : A00/0
;;		Unchanged: 200/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	line	71
global __ptext24
__ptext24:	;psect for function _Led_BlinkProcess
psect	text24
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	71
	global	__size_of_Led_BlinkProcess
	__size_of_Led_BlinkProcess	equ	__end_of_Led_BlinkProcess-_Led_BlinkProcess
	
_Led_BlinkProcess:	
;incstack = 0
	opt	stack 3
; Regs used in _Led_BlinkProcess: [wreg-fsr0h+status,2+status,0]
	line	75
	
i1l2834:	
;led.c: 73: unsigned char i;
;led.c: 75: for(i = 0; i < 12; i++)
	clrf	(Led_BlinkProcess@i)
	line	77
	
i1l2840:	
;led.c: 76: {
;led.c: 77: if(g_ledState[i] == 3)
	movf	(Led_BlinkProcess@i),w
	addlw	low(_g_ledState|((0x0)<<8))&0ffh
	movwf	fsr0
		movlw	3
	bcf	status, 7	;select IRP bank1
	xorwf	(indf),w
	btfss	status,2
	goto	u272_21
	goto	u272_20
u272_21:
	goto	i1l2846
u272_20:
	line	79
	
i1l2842:	
;led.c: 78: {
;led.c: 79: g_blinkTimer[i]++;
	clrc
	rlf	(Led_BlinkProcess@i),w
	addlw	low(_g_blinkTimer|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	80
;led.c: 80: if(g_blinkTimer[i] >= (100 / 2))
	clrc
	rlf	(Led_BlinkProcess@i),w
	addlw	low(_g_blinkTimer|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Led_BlinkProcess+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_BlinkProcess+0)+0+1
	movlw	0
	subwf	1+(??_Led_BlinkProcess+0)+0,w
	movlw	032h
	skipnz
	subwf	0+(??_Led_BlinkProcess+0)+0,w
	skipc
	goto	u273_21
	goto	u273_20
u273_21:
	goto	i1l2846
u273_20:
	line	82
	
i1l2844:	
;led.c: 81: {
;led.c: 82: g_blinkTimer[i] = 0;
	clrc
	rlf	(Led_BlinkProcess@i),w
	addlw	low(_g_blinkTimer|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	83
;led.c: 83: g_blinkPhase[i] ^= 1;
	movf	(Led_BlinkProcess@i),w
	addlw	low(_g_blinkPhase|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(01h)
	xorwf	indf,f
	line	75
	
i1l2846:	
	incf	(Led_BlinkProcess@i),f
	
i1l2848:	
	movlw	low(0Ch)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u274_21
	goto	u274_20
u274_21:
	goto	i1l2840
u274_20:
	line	87
	
i1l702:	
	return
	opt stack 0
GLOBAL	__end_of_Led_BlinkProcess
	__end_of_Led_BlinkProcess:
	signat	_Led_BlinkProcess,89
	global	_Charging_Control

;; *************** function _Charging_Control *****************
;; Defined at:
;;		line 347 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    5[COMMON] unsigned char 
;;  i               1    6[COMMON] unsigned char 
;;  chargeB7_12     1    4[COMMON] unsigned char 
;;  chargeB1_6      1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 100/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	347
global __ptext25
__ptext25:	;psect for function _Charging_Control
psect	text25
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	347
	global	__size_of_Charging_Control
	__size_of_Charging_Control	equ	__end_of_Charging_Control-_Charging_Control
	
_Charging_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _Charging_Control: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	350
	
i1l3700:	
;charge_mgr.c: 349: unsigned char i;
;charge_mgr.c: 350: unsigned char chargeB1_6 = 0;
	clrf	(Charging_Control@chargeB1_6)
	line	351
;charge_mgr.c: 351: unsigned char chargeB7_12 = 0;
	clrf	(Charging_Control@chargeB7_12)
	line	354
	
i1l3702:	
;charge_mgr.c: 354: if(g_tempProtect)
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_tempProtect)^080h),w
	btfsc	status,2
	goto	u388_21
	goto	u388_20
u388_21:
	goto	i1l3708
u388_20:
	line	356
;charge_mgr.c: 355: {
;charge_mgr.c: 356: do { RA0=1; RA1=1; RB3=1; RB2=1; RA3=1; RA2=1; RD1=1; RD3=1; RB0=1; RB1=1; RD2=1; RD0=1; } while(0);
	
i1l615:	
	bsf	(1072/8)^080h,(1072)&7	;volatile
	bsf	(1073/8)^080h,(1073)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	bsf	(50/8),(50)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	bsf	(1074/8)^080h,(1074)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	bsf	(49/8),(49)&7	;volatile
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	
i1l616:	
	line	357
;charge_mgr.c: 357: RC3 = 0;
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	358
;charge_mgr.c: 358: RC5 = 0;
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	359
	
i1l3704:	
;charge_mgr.c: 359: g_pwmDuty = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	goto	i1l617
	line	364
	
i1l3708:	
;charge_mgr.c: 361: }
;charge_mgr.c: 364: for(i = 0; i < 12; i++)
	clrf	(Charging_Control@i)
	line	366
	
i1l3714:	
;charge_mgr.c: 365: {
;charge_mgr.c: 366: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(Charging_Control@s)
	line	371
	
i1l3716:	
;charge_mgr.c: 369: if(s == 2 || s == 3 ||
;charge_mgr.c: 370: s == 4 || s == 5 ||
;charge_mgr.c: 371: s == 8 || s == 9)
		movlw	2
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u389_21
	goto	u389_20
u389_21:
	goto	i1l3730
u389_20:
	
i1l3718:	
		movlw	3
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u390_21
	goto	u390_20
u390_21:
	goto	i1l3730
u390_20:
	
i1l3720:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u391_21
	goto	u391_20
u391_21:
	goto	i1l3730
u391_20:
	
i1l3722:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u392_21
	goto	u392_20
u392_21:
	goto	i1l3730
u392_20:
	
i1l3724:	
		movlw	8
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u393_21
	goto	u393_20
u393_21:
	goto	i1l3730
u393_20:
	
i1l3726:	
		movlw	9
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u394_21
	goto	u394_20
u394_21:
	goto	i1l3738
u394_20:
	goto	i1l3730
	line	373
	
i1l625:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l3732
	
i1l627:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l3732
	
i1l628:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l3732
	
i1l629:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l3732
	
i1l630:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l3732
	
i1l631:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l3732
	
i1l632:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l3732
	
i1l633:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l3732
	
i1l634:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l3732
	
i1l635:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l3732
	
i1l636:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l3732
	
i1l637:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l3732
	
i1l3730:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l625
	xorlw	1^0	; case 1
	skipnz
	goto	i1l627
	xorlw	2^1	; case 2
	skipnz
	goto	i1l628
	xorlw	3^2	; case 3
	skipnz
	goto	i1l629
	xorlw	4^3	; case 4
	skipnz
	goto	i1l630
	xorlw	5^4	; case 5
	skipnz
	goto	i1l631
	xorlw	6^5	; case 6
	skipnz
	goto	i1l632
	xorlw	7^6	; case 7
	skipnz
	goto	i1l633
	xorlw	8^7	; case 8
	skipnz
	goto	i1l634
	xorlw	9^8	; case 9
	skipnz
	goto	i1l635
	xorlw	10^9	; case 10
	skipnz
	goto	i1l636
	xorlw	11^10	; case 11
	skipnz
	goto	i1l637
	goto	i1l3732
	opt asmopt_pop

	line	376
	
i1l3732:	
;charge_mgr.c: 376: if(i < 6)
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipnc
	goto	u395_21
	goto	u395_20
u395_21:
	goto	i1l639
u395_20:
	line	377
	
i1l3734:	
;charge_mgr.c: 377: chargeB1_6 = 1;
	clrf	(Charging_Control@chargeB1_6)
	incf	(Charging_Control@chargeB1_6),f
	goto	i1l3740
	line	378
	
i1l639:	
	line	379
;charge_mgr.c: 378: else
;charge_mgr.c: 379: chargeB7_12 = 1;
	clrf	(Charging_Control@chargeB7_12)
	incf	(Charging_Control@chargeB7_12),f
	goto	i1l3740
	line	383
	
i1l644:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l3740
	
i1l646:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l3740
	
i1l647:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	i1l3740
	
i1l648:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	i1l3740
	
i1l649:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l3740
	
i1l650:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l3740
	
i1l651:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l3740
	
i1l652:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l3740
	
i1l653:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	i1l3740
	
i1l654:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	i1l3740
	
i1l655:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l3740
	
i1l656:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l3740
	
i1l3738:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l644
	xorlw	1^0	; case 1
	skipnz
	goto	i1l646
	xorlw	2^1	; case 2
	skipnz
	goto	i1l647
	xorlw	3^2	; case 3
	skipnz
	goto	i1l648
	xorlw	4^3	; case 4
	skipnz
	goto	i1l649
	xorlw	5^4	; case 5
	skipnz
	goto	i1l650
	xorlw	6^5	; case 6
	skipnz
	goto	i1l651
	xorlw	7^6	; case 7
	skipnz
	goto	i1l652
	xorlw	8^7	; case 8
	skipnz
	goto	i1l653
	xorlw	9^8	; case 9
	skipnz
	goto	i1l654
	xorlw	10^9	; case 10
	skipnz
	goto	i1l655
	xorlw	11^10	; case 11
	skipnz
	goto	i1l656
	goto	i1l3740
	opt asmopt_pop

	line	364
	
i1l3740:	
	incf	(Charging_Control@i),f
	
i1l3742:	
	movlw	low(0Ch)
	subwf	(Charging_Control@i),w
	skipc
	goto	u396_21
	goto	u396_20
u396_21:
	goto	i1l3714
u396_20:
	
i1l619:	
	line	388
;charge_mgr.c: 384: }
;charge_mgr.c: 385: }
;charge_mgr.c: 388: RC3 = chargeB1_6;
	btfsc	(Charging_Control@chargeB1_6),0
	goto	u397_21
	goto	u397_20
	
u397_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2099/8)^0100h,(2099)&7	;volatile
	goto	u398_24
u397_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
u398_24:
	line	389
;charge_mgr.c: 389: RC5 = chargeB7_12;
	btfsc	(Charging_Control@chargeB7_12),0
	goto	u399_21
	goto	u399_20
	
u399_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u400_24
u399_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u400_24:
	line	392
	
i1l617:	
	return
	opt stack 0
GLOBAL	__end_of_Charging_Control
	__end_of_Charging_Control:
	signat	_Charging_Control,89
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 410 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    4[BANK0 ] unsigned int 
;;  s               1   13[BANK0 ] unsigned char 
;;  duty            2   10[BANK0 ] int 
;;  error           2    8[BANK0 ] int 
;;  adjust          2    0[BANK0 ] int 
;;  maxV            2    6[BANK0 ] unsigned int 
;;  i               1   12[BANK0 ] unsigned char 
;;  cvCount         1    3[BANK0 ] unsigned char 
;;  hasCharging     1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 100/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      14       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2      14       0       0       0
;;Total ram usage:       16 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___awdiv
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=0
	line	410
global __ptext26
__ptext26:	;psect for function _CCCV_Control
psect	text26
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	410
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	413
	
i1l3744:	
;charge_mgr.c: 412: unsigned char i;
;charge_mgr.c: 413: unsigned char hasCharging = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	414
;charge_mgr.c: 414: unsigned int maxV = 0;
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	415
;charge_mgr.c: 415: unsigned char cvCount = 0;
	clrf	(CCCV_Control@cvCount)
	line	418
;charge_mgr.c: 418: for(i = 0; i < 12; i++)
	clrf	(CCCV_Control@i)
	line	420
	
i1l3750:	
;charge_mgr.c: 419: {
;charge_mgr.c: 420: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	424
	
i1l3752:	
;charge_mgr.c: 422: if(s == 2 || s == 3 ||
;charge_mgr.c: 423: s == 4 || s == 5 ||
;charge_mgr.c: 424: s == 8 || s == 9)
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u401_21
	goto	u401_20
u401_21:
	goto	i1l664
u401_20:
	
i1l3754:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u402_21
	goto	u402_20
u402_21:
	goto	i1l664
u402_20:
	
i1l3756:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u403_21
	goto	u403_20
u403_21:
	goto	i1l664
u403_20:
	
i1l3758:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u404_21
	goto	u404_20
u404_21:
	goto	i1l664
u404_20:
	
i1l3760:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u405_21
	goto	u405_20
u405_21:
	goto	i1l664
u405_20:
	
i1l3762:	
		movlw	9
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u406_21
	goto	u406_20
u406_21:
	goto	i1l662
u406_20:
	
i1l664:	
	line	426
;charge_mgr.c: 425: {
;charge_mgr.c: 426: hasCharging = 1;
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	428
	
i1l3764:	
;charge_mgr.c: 427: {
;charge_mgr.c: 428: unsigned int vt = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	429
	
i1l3766:	
;charge_mgr.c: 429: if(vt > maxV) maxV = vt;
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u407_25
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u407_25:
	skipnc
	goto	u407_21
	goto	u407_20
u407_21:
	goto	i1l3770
u407_20:
	
i1l3768:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	431
	
i1l3770:	
;charge_mgr.c: 430: }
;charge_mgr.c: 431: if(s == 5)
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u408_21
	goto	u408_20
u408_21:
	goto	i1l662
u408_20:
	line	432
	
i1l3772:	
;charge_mgr.c: 432: cvCount++;
	incf	(CCCV_Control@cvCount),f
	line	433
	
i1l662:	
	line	418
	incf	(CCCV_Control@i),f
	
i1l3774:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u409_21
	goto	u409_20
u409_21:
	goto	i1l3750
u409_20:
	line	437
	
i1l3776:	
;charge_mgr.c: 433: }
;charge_mgr.c: 434: }
;charge_mgr.c: 437: if(!hasCharging)
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u410_21
	goto	u410_20
u410_21:
	goto	i1l3782
u410_20:
	line	439
	
i1l3778:	
;charge_mgr.c: 438: {
;charge_mgr.c: 439: g_pwmDuty = 0;
	clrf	(_g_pwmDuty)	;volatile
	line	440
;charge_mgr.c: 440: g_cvIntegral = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	i1l668
	line	447
	
i1l3782:	
;charge_mgr.c: 442: }
;charge_mgr.c: 447: if(cvCount == 0)
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u411_21
	goto	u411_20
u411_21:
	goto	i1l3800
u411_20:
	line	449
	
i1l3784:	
;charge_mgr.c: 448: {
;charge_mgr.c: 449: if(g_pwmDuty < 25)
	movlw	low(019h)
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u412_21
	goto	u412_20
u412_21:
	goto	i1l3792
u412_20:
	line	452
	
i1l3786:	
;charge_mgr.c: 450: {
;charge_mgr.c: 452: g_pwmDuty += 3;
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	453
	
i1l3788:	
;charge_mgr.c: 453: if(g_pwmDuty > 25)
	movlw	low(01Ah)
	subwf	(_g_pwmDuty),w	;volatile
	skipc
	goto	u413_21
	goto	u413_20
u413_21:
	goto	i1l668
u413_20:
	line	454
	
i1l3790:	
;charge_mgr.c: 454: g_pwmDuty = 25;
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l668
	line	456
	
i1l3792:	
	goto	i1l3790
	line	475
	
i1l3800:	
;charge_mgr.c: 467: }
;charge_mgr.c: 474: {
;charge_mgr.c: 475: int error = (int)(3361) - (int)(maxV);
	movlw	021h
	movwf	(CCCV_Control@error)
	movlw	0Dh
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	478
;charge_mgr.c: 478: g_cvIntegral += error * 1;
	movf	(CCCV_Control@error),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral)^080h,f
	skipnc
	incf	(_g_cvIntegral+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(CCCV_Control@error+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral+1)^080h,f
	line	479
	
i1l3802:	
;charge_mgr.c: 479: if(g_cvIntegral > 200)
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u414_25
	movlw	0C9h
	subwf	(_g_cvIntegral)^080h,w
u414_25:

	skipc
	goto	u414_21
	goto	u414_20
u414_21:
	goto	i1l3806
u414_20:
	line	480
	
i1l3804:	
;charge_mgr.c: 480: g_cvIntegral = 200;
	movlw	0C8h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	i1l3810
	line	481
	
i1l3806:	
;charge_mgr.c: 481: else if(g_cvIntegral < -200)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u415_25
	movlw	038h
	subwf	(_g_cvIntegral)^080h,w
u415_25:

	skipnc
	goto	u415_21
	goto	u415_20
u415_21:
	goto	i1l3810
u415_20:
	line	482
	
i1l3808:	
;charge_mgr.c: 482: g_cvIntegral = -200;
	movlw	038h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	movlw	0FFh
	movwf	((_g_cvIntegral)^080h)+1
	line	485
	
i1l3810:	
;charge_mgr.c: 485: int adjust = (error * 4 + g_cvIntegral) / 8;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_cvIntegral)^080h,w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1)^080h,w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	486
	
i1l3812:	
;charge_mgr.c: 486: int duty = (int)g_pwmDuty + adjust;
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
i1l3814:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	489
	
i1l3816:	
;charge_mgr.c: 489: if(duty > 32) duty = 32;
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u416_25
	movlw	021h
	subwf	(CCCV_Control@duty),w
u416_25:

	skipc
	goto	u416_21
	goto	u416_20
u416_21:
	goto	i1l3820
u416_20:
	
i1l3818:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	490
	
i1l3820:	
;charge_mgr.c: 490: if(duty < 0) duty = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u417_21
	goto	u417_20
u417_21:
	goto	i1l3824
u417_20:
	
i1l3822:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	492
	
i1l3824:	
;charge_mgr.c: 492: g_pwmDuty = (unsigned char)duty;
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	494
	
i1l668:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	i1___bmul

;; *************** function i1___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[COMMON] unsigned char 
;;  __bmul          1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext27
__ptext27:	;psect for function i1___bmul
psect	text27
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_ofi1___bmul
	__size_ofi1___bmul	equ	__end_ofi1___bmul-i1___bmul
	
i1___bmul:	
;incstack = 0
	opt	stack 2
; Regs used in i1___bmul: [wreg+status,2+status,0]
;i1___bmul@multiplier stored from wreg
	movwf	(i1___bmul@multiplier)
	line	6
	
i1l2582:	
	clrf	(i1___bmul@product)
	line	43
	
i1l2584:	
	btfss	(i1___bmul@multiplier),(0)&7
	goto	u234_21
	goto	u234_20
u234_21:
	goto	i1l2588
u234_20:
	line	44
	
i1l2586:	
	movf	(i1___bmul@multiplicand),w
	addwf	(i1___bmul@product),f
	line	45
	
i1l2588:	
	clrc
	rlf	(i1___bmul@multiplicand),f
	line	46
	
i1l2590:	
	clrc
	rrf	(i1___bmul@multiplier),f
	line	47
	movf	((i1___bmul@multiplier)),w
	btfss	status,2
	goto	u235_21
	goto	u235_20
u235_21:
	goto	i1l2584
u235_20:
	line	50
	
i1l2592:	
	movf	(i1___bmul@product),w
	line	51
	
i1l734:	
	return
	opt stack 0
GLOBAL	__end_ofi1___bmul
	__end_ofi1___bmul:
	signat	i1___bmul,89
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] int 
;;  dividend        2    2[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] int 
;;  sign            1    5[COMMON] unsigned char 
;;  counter         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext28
__ptext28:	;psect for function ___awdiv
psect	text28
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
i1l2538:	
	clrf	(___awdiv@sign)
	line	15
	
i1l2540:	
	btfss	(___awdiv@divisor+1),7
	goto	u227_21
	goto	u227_20
u227_21:
	goto	i1l2546
u227_20:
	line	16
	
i1l2542:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
i1l2544:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
i1l2546:	
	btfss	(___awdiv@dividend+1),7
	goto	u228_21
	goto	u228_20
u228_21:
	goto	i1l2552
u228_20:
	line	20
	
i1l2548:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
i1l2550:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
i1l2552:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
i1l2554:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u229_21
	goto	u229_20
u229_21:
	goto	i1l2574
u229_20:
	line	25
	
i1l2556:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	i1l2560
	line	27
	
i1l2558:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
i1l2560:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u230_21
	goto	u230_20
u230_21:
	goto	i1l2558
u230_20:
	line	31
	
i1l2562:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
i1l2564:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u231_25
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u231_25:
	skipc
	goto	u231_21
	goto	u231_20
u231_21:
	goto	i1l2570
u231_20:
	line	33
	
i1l2566:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
i1l2568:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
i1l2570:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
i1l2572:	
	decfsz	(___awdiv@counter),f
	goto	u232_21
	goto	u232_20
u232_21:
	goto	i1l2562
u232_20:
	line	39
	
i1l2574:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u233_21
	goto	u233_20
u233_21:
	goto	i1l2578
u233_20:
	line	40
	
i1l2576:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
i1l2578:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
i1l846:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
