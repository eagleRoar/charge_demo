/*-------------------------------------------
  L1211 12槽充电器 - UART调试输出模块
  功能: 串口发送、状态打印(每秒一次)
  配置: 9600bps, 8N1, TX=RB3(与B3共用), RX=RB4
  输出格式:
    T:温度C VDD:电源电压mV
    B1:V=ADC值 S=状态 T=类型 [ERR/FULL/CHG]
    B2:V=... ...
    ... (共12路)
  注: 调试输出可通过UART_PRINT_EN宏开关控制
-------------------------------------------*/
#include "config.h"

#if UART_PRINT_EN

/*========================================================================
  函数: uart_send_char
  功能: 发送单个字符
  参数: c - 要发送的字符
  说明: 阻塞发送, 等待发送缓冲区空闲
========================================================================*/
void uart_send_char(unsigned char c)
{
	while(TRMT1 == 0);              /* 等待发送缓冲区空闲 */
	TXREG1 = c;                     /* 写入发送寄存器 */
}

/*========================================================================
  函数: uart_send_string
  功能: 发送字符串(以'\0'结尾)
  参数: str - 字符串指针
  说明: 逐个字符发送, 直到遇到'\0'
========================================================================*/
void uart_send_string(const unsigned char *str)
{
	while(*str != '\0')
		uart_send_char(*str++);     /* 逐字符发送 */
}

/*========================================================================
  函数: uart_send_number
  功能: 发送无符号整数的十进制字符串
  参数: num - 要发送的数字
  算法: 逐位取模转字符, 先存后逆序发送
  例如: num=123 -> buf=['3','2','1'] -> 发送"123"
========================================================================*/
void uart_send_number(unsigned int num)
{
	unsigned char buf[6];           /* 最大65535, 5位+1 */
	unsigned char i = 0;
	unsigned char j;

	/* 特殊处理: 0 */
	if(num == 0)
	{
		uart_send_char('0');
		return;
	}

	/* 逐位取模, 存入缓冲区(低位在前) */
	while(num > 0)
	{
		buf[i++] = '0' + (num % 10);  /* 数字转ASCII字符 */
		num /= 10;
	}

	/* 逆序发送(高位在前) */
	for(j = i; j > 0; j--)
		uart_send_char(buf[j-1]);
}

/*========================================================================
  函数: Print_Status
  功能: MINIMAL B1-ONLY 测试模式 - 打印B1/VREF诊断信息
  输出格式: B1=curr [min~max] VREF=curr [min~max] sat=N
  含义:
    B1跳VREF也跳 → LDO参考电压不稳
    B1跳VREF稳   → B1AD(RC1/AN17)硬件噪声
    都不跳       → 问题已修复
========================================================================*/
void Print_Status(void)
{
	uart_send_string("B1=");
	uart_send_number(g_ntcDiagAdc);
	uart_send_string("[");
	uart_send_number(g_b1Min);
	uart_send_string("~");
	uart_send_number(g_b1Max);
	uart_send_string("] VREF=");
	uart_send_number(g_ntcDiagChk);
	uart_send_string("[");
	uart_send_number(g_vrefMin);
	uart_send_string("~");
	uart_send_number(g_vrefMax);
	uart_send_string("] sat=");
	uart_send_number(g_satSaved);
	uart_send_string("\r\n");
}
#endif