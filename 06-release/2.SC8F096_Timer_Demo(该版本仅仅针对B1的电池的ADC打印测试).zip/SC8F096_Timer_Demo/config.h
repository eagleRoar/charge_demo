/*-------------------------------------------
  L1211 12槽充电器 - 全局配置文件
  MCU: SC8F096AD832 QFN32
  功能: 12通道恒压锂电池脉冲充电管理
  版本: 2026/06/01 <V2.0>

  原理图参考: L1211 TOP V2.0
  需求参考: requirement_20260518.xlsx
  资源分配参考: resource_allocation.txt

  引脚分配:
    B1~B12  MOSFET栅极控制(AO3401 P沟道, Gate=Low导通, Gate=High关闭)
    B1  = RA0/AN0  /PWMA0  (pin31)
    B2  = RA1/AN1  /PWMA1  (pin30)
    B3  = RB3/AN11 /PWMD2  (pin12)
    B4  = RB2/AN10 /PWMD4  (pin13)
    B5  = RA3/AN3  /PWMA3  (pin28)
    B6  = RA2/AN2  /PWMA2  (pin29)
    B7  = RD1/AN23 /PWMD1  (pin22)
    B8  = RD3/AN25 /PWMD3  (pin20)
    B9  = RB0/AN8  /PWMD0  (pin15)
    B10 = RB1/AN9  /PWMD1  (pin14)
    B11 = RD2/AN24 /PWMD2  (pin21)
    B12 = RD0/AN22 /PWMD0  (pin23)
    注: B1~B12为纯数字输出(仅控制MOSFET开关), ADC采样由独立BxAD引脚完成
    B1AD    : RC1/AN17      B1电压采样(独立ADC通道, 不受MOSFET状态影响)
    B2AD    : RC0/AN16      B2电压采样
    B3AD    : RB4/AN12      B3电压采样(与UART RX共用, 调试时注意)
    B4AD    : RB5/AN13      B4电压采样
    B5AD    : RA5/AN5       B5电压采样
    B6AD    : RA4/AN4       B6电压采样
    B7AD    : AN28          B7电压采样(高通道, 模拟专用)
    B8AD    : AN29          B8电压采样(高通道, 模拟专用)
    B9AD    : AN27          B9电压采样(高通道, 模拟专用)
    B10AD   : AN26          B10电压采样(高通道, 模拟专用)
    B11AD   : RA7/AN7       B11电压采样
    B12AD   : RA6/AN6       B12电压采样
    NTC     : RC5/AN21      温度检测(CMFA103J3950HANT,10K上拉)
    LED IO1    : RC5/AN21      LED电源控制1(与NTC分时复用,与DAT共用)
    LED IO2    : RC4/AN20      LED电源控制2(与CLK共用)
    PWM        : RB7/AN15      PWM总控输出(pin8)
    CD IO1     : RC3/AN19      充电组控制1(B1-B6组)
    CD IO2     : RC2/AN18      充电组控制2(B7-B12组)
    EN         : RB6/AN14      主电源使能(Q3 4435)
    UART TX    : RB3           UART发送(调试用,与B3共用RB3)
    UART RX    : RB4           UART接收
    CLK/DAT    : RC4/RC5       ICSP调试接口(与LED IO2/LED IO1共用RC4/RC5)
-------------------------------------------*/
#ifndef __CONFIG_H__
#define __CONFIG_H__

#include <sc.h>

/* --- 系统时钟配置 --- */
#ifndef _XTAL_FREQ
#define _XTAL_FREQ 16000000     /* 系统时钟: 16MHz */
#endif

/* --- 电源电压检测参数 --- */
/* 电源电压 = ADC值 * 1.2V(内部参考) / 4096 * 1000(转mV) */
#define POWER_RATIO        (4096UL*1.2*1000)
#define UART_PRINT_EN      1       /* UART调试输出开关: 1=启用, 0=禁用 */

/* --- 充电槽位数量 --- */
#define BATTERY_SLOTS      12      /* 12路独立充电槽位 */

/*========================================================================
  充电状态枚举
  状态转换流程: IDLE -> DETECT -> ACTIVATE/PRECHARGE/CC_CHARGE -> CV_CHARGE -> FULL
  异常状态: ERROR(短路/镍氢/未知电池/超时/过压)
========================================================================*/
#define CHG_IDLE           0       /* 空闲: 初始状态, 等待插入电池 */
#define CHG_DETECT         1       /* 检测: 等待2s稳定后判断电池类型 */
#define CHG_ACTIVATE       2       /* 激活: 过放电池脉冲激活(电压<0.1V) */
#define CHG_PRECHARGE      3       /* 预充: 小电流预充电(0.1V~0.5V) */
#define CHG_CC_CHARGE      4       /* 恒流充电: 正常充电阶段(0.5V~满电) */
#define CHG_CV_CHARGE      5       /* 恒压充电: 到达满电后保持10min */
#define CHG_FULL           6       /* 充满: 充电完成, 绿灯常亮 */
#define CHG_ERROR          7       /* 错误: 异常状态, 红灯闪烁 */

/*========================================================================
  电池类型枚举
  通过开路电压判断电池类型, 决定是否充电
========================================================================*/
#define BAT_TYPE_UNKNOWN   0       /* 未知类型 */
#define BAT_TYPE_LI_ION    1       /* 锂电池: 正常充电 */
#define BAT_TYPE_NIMH      2       /* 镍氢电池: 不充电, 报错 */
#define BAT_TYPE_DRY       3       /* 干电池: 不充电, 报错 */
#define BAT_TYPE_SHORT     4       /* 短路: 不充电, 报错 */

/*========================================================================
  LED状态枚举
  红灯亮=充电中, 绿灯亮=充满, 红灯闪=错误
========================================================================*/
#define LED_OFF            0       /* LED关闭 */
#define LED_RED_ON         1       /* 红灯常亮(充电中) */
#define LED_GREEN_ON       2       /* 绿灯常亮(充满) */
#define LED_RED_FLASH      3       /* 红灯闪烁(错误) */

/*========================================================================
  电压阈值(ADC原始值)
  参考电压: 内部LDO≈1.8V(基于1.614V→3689校准), ADC值=0~4095(左对齐12位)
  ADC引脚无分压: BxAD引脚电压 = 电池电压直连
  电池电压(V) = ADC值 / 4096 * Vref
  校准数据: ①B1AD=1.614V→ADC=3689, Vref≈1.79V (稳定读数)
             ②B1AD=1.08V →ADC=3110, Vref≈1.42V (MOSFET干扰导致不准确)
  当前阈值基于校准①, 若LDO实际输出更低需重新校准
  注: SC8F096 LDO使能时ADC为8位有效精度, 显示值=8位值×16
  注: 充电MOSFET导通时BxAD被VDD拉高读4095, Phase0已加入关MOSFET逻辑
========================================================================*/
#define ADC_V_FULL          3459   /* 1.52V: 锂电池满电电压 */
#define ADC_V_OVER          3641   /* 1.60V: 过充保护阈值 */
#define ADC_V_PRE_MIN       1138   /* 0.50V: 预充下限 */
#define ADC_V_PRE_MAX       2276   /* 1.00V: 预充上限, 进入恒流充电 */
#define ADC_V_ACTIVATE      228    /* 0.10V: 激活阈值, 低于此值需脉冲激活 */
#define ADC_V_SHORT         91     /* 0.04V: 短路判断阈值 */
#define ADC_V_NIMH_LOW      2503   /* 1.10V: 镍氢电池电压下限 */
#define ADC_V_NIMH_HIGH     2958   /* 1.30V: 镍氢电池电压上限 */

/*========================================================================
  充电时间阈值
  说明: chargeTimer在ChargeProcess_Slot中每次+1, 每轮扫描(12槽×3阶段=36次Timer0)调用一次
  Timer0周期125us, 但部分ISR阶段(Phase0/Phase2)耗时>125us导致扫描周期拉长
   每轮扫描实测≈7.9ms, 1秒≈1000/7.9≈126个tick, 取100(留余量)
  ========================================================================*/
#define TICK_PER_SEC        100         /* 1秒对应的扫描tick数(校准值) */
#define TIME_ACTIVATE_MAX   (60 * TICK_PER_SEC)            /* 激活超时: 60秒 */
#define TIME_PRECHARGE_MAX  (300 * TICK_PER_SEC)           /* 预充超时: 300秒(5分钟) */
#define TIME_CHARGE_MAX     (10800 * TICK_PER_SEC)         /* 充电超时: 10800秒(3小时) */
#define TIME_DETECT_WAIT    (2 * TICK_PER_SEC)             /* 检测等待: 2秒 */
#define TIME_CV_HOLD        (600 * TICK_PER_SEC)           /* CV恒压保持: 600秒(10分钟) */

/*========================================================================
  CC-CV 充电控制参数
========================================================================*/
/* 软件PWM参数 (RB7/VT_PWM1, 基于Timer0 ISR生成)
   PWM周期 = 32 × 125us = 4ms, 频率 = 250Hz, 占空比分辨率: 3.125%/step */
#define PWM_RESOLUTION      32     /* PWM分辨率(32级) */
#define PWM_MAX             32     /* 100%占空比 */

/* CC恒流阶段: 固定占空比(无电流检测时用电压监控替代闭环) */
#define CC_DUTY_INITIAL     25     /* CC初始占空比(25/32≈78%), 软启动起点 */
#define CC_DUTY_TARGET      25     /* CC目标占空比(25/32≈78%) */
#define CC_DUTY_RAMP_STEP   3      /* 软启动每步增量 */

/* CV恒压阶段: PI闭环控制参数
   error = ADC_V_FULL - 当前电压
   duty += error * CV_KP / CV_DIV
   CV_KI用于慢速积分修正 */
#define CV_KP               4      /* 比例系数 */
#define CV_KI               1      /* 积分系数 */
#define CV_KI_LIMIT         200    /* 积分限幅, 防止积分饱和 */

/*========================================================================
  NTC 旁路开关
  设置为 1: 跳过所有NTC温度检测, 使用固定默认温度25C, 不触发温度保护
  设置为 0: 正常NTC温度检测(需NTC电路正常工作)
  用途: NTC电路异常时临时旁路, 方便调试充电逻辑
========================================================================*/
#define NTC_BYPASS          1       /* 1=NTC旁路, 0=正常 */

/*========================================================================
  温度保护阈值
  NTC型号: CMFA103J3950HANT (10K@25C, B=3950)
  温度>=60C停止充电, 温度<=50C恢复充电(10C回差防抖)
========================================================================*/
#define TEMP_STOP           60      /* 停止充电温度 */
#define TEMP_RESUME         50      /* 恢复充电温度 */

/*========================================================================
  NTC ADC 建立时间配置 (C12 = 22uF 并接在 RC5 与 GND 之间)
  RC5 引脚分时复用: LED IO1(数字输出, 平时驱低) / NTC(模拟输入, 测温时切换)
  拓扑: VDD → R48(10K) → RC5/AN21 → NTC1(CMFA103J3950HANT, 10K@25C) → GND
                                        └── C12(22uF) → GND
  当 RC5 从数字输出(驱低)切换到模拟输入(高阻)后, C12 需要通过 R48||R_ntc 充电:
    - 室温下 R48||R_ntc ≈ 5KΩ,  τ = 5KΩ × 22uF = 110ms
    - 充电到 96% 需要 ~3.3τ ≈ 360ms
    - 充电到 99% 需要 ~5τ ≈ 550ms
  扫描轮周期: 12槽 × 3阶段 × 125us ≈ 4.5ms/轮 → 取整约 9ms/轮(ISR耗时拉长)
  NTC_SETTLE_ROUNDS = 60 → 60 × 9ms = 540ms > 5τ, 保证 ADC 采样精度
  TEMP_READ_INTERVAL = 200 → 约 1.8s 读一次温度(温度变化缓慢, 无需高频读取)
========================================================================*/
#define NTC_SETTLE_ROUNDS    60      /* NTC建立等待轮数(60轮≈540ms>5τ) */
#define TEMP_READ_INTERVAL   200     /* 温度读取间隔(200轮≈1.8s) */

/*========================================================================
  ADC通道定义
  B1AD~B12AD: 独立ADC采样引脚(纯模拟输入), 与B1~B12 MOSFET控制引脚分离
  注: B1~B12为纯数字输出，无需分时复用切换模拟/数字模式
========================================================================*/
#define ADC_CH_B1AD         17    /* B1AD: RC1/AN17 */
#define ADC_CH_B2AD         16    /* B2AD: RC0/AN16 */
#define ADC_CH_B3AD         12    /* B3AD: RB4/AN12(与UART RX共用) */
#define ADC_CH_B4AD         13    /* B4AD: RB5/AN13 */
#define ADC_CH_B5AD         5     /* B5AD: RA5/AN5 */
#define ADC_CH_B6AD         4     /* B6AD: RA4/AN4 */
#define ADC_CH_B7AD         28    /* B7AD: AN28(高通道, 模拟专用) */
#define ADC_CH_B8AD         29    /* B8AD: AN29(高通道, 模拟专用) */
#define ADC_CH_B9AD         27    /* B9AD: AN27(高通道, 模拟专用) */
#define ADC_CH_B10AD        26    /* B10AD: AN26(高通道, 模拟专用) */
#define ADC_CH_B11AD        7     /* B11AD: RA7/AN7 */
#define ADC_CH_B12AD        6     /* B12AD: RA6/AN6 */
#define ADC_CH_NTC          21    /* NTC: RC5/AN21 */
#define ADC_CH_VREF         31    /* 内部1.2V参考电压(用于计算VDD) */

/*========================================================================
  GPIO引脚宏定义
========================================================================*/
/* 总控引脚 */
#define PIN_PWM             RB7     /* PWM总控输出(VT_PWM1, pin8=RB7/AN15) */
#define PIN_CD1             RC3     /* 充电组控制1(B1-B6) */
#define PIN_CD2             RC2     /* 充电组控制2(B7-B12) */
#define PIN_LED_IO1         RC5     /* LED电源控制1(与NTC分时复用RC5) */
#define PIN_LED_IO2         RC4     /* LED电源控制2 */
#define PIN_EN              RB6     /* 主电源使能(Q3 4435) */

/* B1-B12 独立MOSFET栅极控制引脚
   AO3401 P沟道MOSFET: Gate=Low(0)时导通充电, Gate=High(1)时关闭
   B1=RA0/AN0  B2=RA1/AN1  B3=RB3/AN11  B4=RB2/AN10
   B5=RA3/AN3  B6=RA2/AN2  B7=RD1/AN23  B8=RD3/AN25
   B9=RB0/AN8  B10=RB1/AN9 B11=RD2/AN24 B12=RD0/AN22 */
#define PIN_B1_CTRL         RA0     /* B1: RA0 */
#define PIN_B2_CTRL         RA1     /* B2: RA1 */
#define PIN_B3_CTRL         RB3     /* B3: RB3(与UART TX共用) */
#define PIN_B4_CTRL         RB2     /* B4: RB2 */
#define PIN_B5_CTRL         RA3     /* B5: RA3 */
#define PIN_B6_CTRL         RA2     /* B6: RA2 */
#define PIN_B7_CTRL         RD1     /* B7: RD1 */
#define PIN_B8_CTRL         RD3     /* B8: RD3 */
#define PIN_B9_CTRL         RB0     /* B9: RB0 */
#define PIN_B10_CTRL        RB1     /* B10: RB1 */
#define PIN_B11_CTRL        RD2     /* B11: RD2 */
#define PIN_B12_CTRL        RD0     /* B12: RD0 */

/*========================================================================
  每槽独立MOSFET控制宏
  AO3401 P沟道: Gate=0时导通充电, Gate=1时关闭
========================================================================*/
/* 打开指定槽位充电(Gate=0, MOSFET导通) */
#define SLOT_CHARGE_ON(idx)    do { \
	switch(idx) { \
	case 0: PIN_B1_CTRL=0; break;  case 1: PIN_B2_CTRL=0; break; \
	case 2: PIN_B3_CTRL=0; break;  case 3: PIN_B4_CTRL=0; break; \
	case 4: PIN_B5_CTRL=0; break;  case 5: PIN_B6_CTRL=0; break; \
	case 6: PIN_B7_CTRL=0; break;  case 7: PIN_B8_CTRL=0; break; \
	case 8: PIN_B9_CTRL=0; break;  case 9: PIN_B10_CTRL=0; break; \
	case 10: PIN_B11_CTRL=0; break; case 11: PIN_B12_CTRL=0; break; \
	} \
} while(0)

/* 关闭指定槽位充电(Gate=1, MOSFET关闭) */
#define SLOT_CHARGE_OFF(idx)   do { \
	switch(idx) { \
	case 0: PIN_B1_CTRL=1; break;  case 1: PIN_B2_CTRL=1; break; \
	case 2: PIN_B3_CTRL=1; break;  case 3: PIN_B4_CTRL=1; break; \
	case 4: PIN_B5_CTRL=1; break;  case 5: PIN_B6_CTRL=1; break; \
	case 6: PIN_B7_CTRL=1; break;  case 7: PIN_B8_CTRL=1; break; \
	case 8: PIN_B9_CTRL=1; break;  case 9: PIN_B10_CTRL=1; break; \
	case 10: PIN_B11_CTRL=1; break; case 11: PIN_B12_CTRL=1; break; \
	} \
} while(0)

/* 关闭所有槽位充电(温度保护时使用) */
#define SLOT_ALL_OFF()  do { \
	PIN_B1_CTRL=1; PIN_B2_CTRL=1; PIN_B3_CTRL=1; PIN_B4_CTRL=1; \
	PIN_B5_CTRL=1; PIN_B6_CTRL=1; PIN_B7_CTRL=1; PIN_B8_CTRL=1; \
	PIN_B9_CTRL=1; PIN_B10_CTRL=1; PIN_B11_CTRL=1; PIN_B12_CTRL=1; \
} while(0)

/*========================================================================
  数据结构定义
========================================================================*/
/* 单槽电池状态结构体(12字节)
   注: 为节省RAM, stableCnt和activatePulseCnt使用unsigned char */
typedef struct {
	unsigned char type;             /* 电池类型(BAT_TYPE_xxx) */
	unsigned char state;            /* 充电状态(CHG_xxx) */
	unsigned char ledState;         /* LED状态(LED_xxx) */
	unsigned int  voltage;          /* 当前ADC电压值 */
	unsigned int  chargeTimer;      /* 充电计时器(tick) */
	unsigned int  blinkTimer;       /* LED闪烁计时器(tick) */
	unsigned char blinkPhase;       /* LED闪烁相位(0/1交替) */
	unsigned char stableCnt;        /* 稳定计数器 */
	unsigned char activatePulseCnt; /* 激活脉冲计数 */
} BatterySlot_t;

/*========================================================================
  全局变量声明(extern)
  定义分散在各模块.c文件中, 避免单Bank内存不足
========================================================================*/
extern volatile unsigned int adresult;      /* ADC采样结果(去极值平均后) */
extern volatile unsigned int power_ad;      /* 电源电压(mV) */
extern volatile unsigned char test_adc;     /* ADC采样状态标记 */

/* 槽位数据: 拆分为两个6元素数组, 分别放入不同RAM Bank
   每数组72字节(6*12), 可放入Bank0(96字节)和Bank1(80字节) */
extern BatterySlot_t g_slot0[6];            /* B1-B6 槽位数据 */
extern BatterySlot_t g_slot1[6];            /* B7-B12 槽位数据 */

/* 透明访问宏: 根据索引自动选择对应数组 */
#define GSLOT(idx) (((idx) < 6) ? &g_slot0[(idx)] : &g_slot1[(idx)-6])

/* 系统计时变量 */
extern unsigned int  g_timerTick;           /* Timer0中断计数(250us/tick) */
extern unsigned int  g_systemTick;          /* 系统秒计数(4000tick=1s) */
extern unsigned int  g_ntcAdc;             /* NTC ADC原始值 */
extern unsigned char g_temperature;         /* 当前温度(摄氏度) */
extern unsigned char g_tempProtect;         /* 温度保护标志: 1=保护中, 0=正常 */
extern unsigned char g_scanIndex;           /* 当前扫描槽位索引(0-11) */
extern unsigned char g_scanPhase;           /* 当前扫描阶段(0/1/2) */
extern unsigned int  g_powerOnTimer;        /* 上电自检计时器 */
extern unsigned char g_powerOnPhase;        /* 上电自检阶段(0/1/2) */

/* NTC读温状态机变量 */
extern unsigned char g_tempPhase;           /* NTC读温状态: 0=等待间隔, 1=建立中 */
extern unsigned int  g_tempSettleCnt;       /* NTC建立等待计数器(轮) */
extern unsigned int  g_tempReadRoundCnt;    /* 温度读取间隔计数器(轮) */

/* NTC调试变量 */
extern unsigned int  g_ntcDebugAdc;         /* ISR状态机NTC读取快照 */
extern unsigned char g_ntcDebugPhase;       /* NTC调试阶段快照 */
extern unsigned int  g_ntcDebugSettleCnt;   /* NTC建立计数器快照 */
extern unsigned int  g_ntcDiagAdc;          /* 阻塞式NTC读(LDO参考,600ms延时) */
extern unsigned int  g_ntcDiagVdd;          /* 阻塞式NTC读(VDD参考,对比LDO) */
extern unsigned int  g_ntcDiagChk;          /* 阻塞式高通道AN28读(验证CHS4) */

/* MINIMAL B1-ONLY TEST: 每秒min/max追踪 */
extern unsigned int  g_b1Min;               /* 每秒B1 ADC最小值 */
extern unsigned int  g_b1Max;               /* 每秒B1 ADC最大值 */
extern unsigned int  g_vrefMin;             /* 每秒VREF ADC最小值 */
extern unsigned int  g_vrefMax;             /* 每秒VREF ADC最大值 */
extern unsigned int  g_satSaved;            /* 打印前的sat快照(避免清零bug) */
extern unsigned char g_timerTick8;          /* ISR内8分频计数器 */
extern volatile bit g_doAdcSample;          /* ADC采样请求标志 */

/* PWM/CC-CV 控制变量 */
extern volatile unsigned char g_pwmDuty;       /* 当前PWM占空比(0~PWM_MAX) */
extern volatile unsigned char g_pwmCounter;    /* PWM计数器(ISR中递增, 0~31循环) */
extern signed int g_cvIntegral;                /* CV PI积分累加器 */

/* UART通信变量 */
extern volatile bit g_printFlag;            /* 打印标志: ISR置1, 主循环检查 */

/* 只读配置表(存放于ROM) */
extern const unsigned char s_adcChannels[BATTERY_SLOTS];   /* 12槽BxAD ADC通道映射表 */

/*========================================================================
  函数声明
========================================================================*/
/* 系统初始化与引脚控制 */
void System_Init(void);                     /* 系统初始化(时钟/IO/ADC/UART/Timer) */

/* ADC驱动 */
void AD_Init(void);                         /* ADC模块初始化 */
unsigned char ADC_Sample(unsigned char adch, unsigned char adldo);  /* ADC单次采样(去极值平均) */
unsigned int  ADC_ReadChannel(unsigned char ch);                    /* 读取指定ADC通道 */

/* 充电管理 */
unsigned char Read_Temperature(void);       /* 读取NTC温度(摄氏度) */
unsigned char Detect_BatteryType(unsigned int voltage); /* 根据电压判断电池类型 */
void ChargeProcess_Slot(unsigned char idx); /* 单槽充电状态机处理 */
void Charging_Control(void);                /* 12路充电使能控制(含温度保护) */
void CCCV_Control(void);                    /* CC-CV恒流恒压PWM占空比调节 */

/* LED控制 */
void Update_LED_Slot(unsigned char idx);    /* 根据槽位状态更新LED显示 */
void Led_BlinkProcess(void);                /* LED闪烁计时处理 */
void PowerOnLedSequence(void);              /* 上电LED自检序列 */

/* UART调试输出 */
#if UART_PRINT_EN
void uart_send_char(unsigned char c);       /* 发送单字符 */
void uart_send_string(const unsigned char *str); /* 发送字符串 */
void uart_send_number(unsigned int num);    /* 发送数字 */
void Print_Status(void);                    /* 打印系统状态 */
#endif

#endif