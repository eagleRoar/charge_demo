opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ADC_ReadChannel
	FNCALL	_main,_Print_Status
	FNCALL	_main,_System_Init
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,___bmul
	FNCALL	_Print_Status,_uart_send_number
	FNCALL	_Print_Status,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_ADC_ReadChannel,_ADC_Sample
	FNROOT	_main
	FNCALL	intlevel1,_Interrupt_Isr
	global	intlevel1
	FNROOT	intlevel1
	global	_g_vrefMin
	global	_g_b1Min
psect	idataBANK0,class=CODE,space=0,delta=2,noexec
global __pidataBANK0
__pidataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	48

;initializer for _g_vrefMin
	retlw	0Fh
	retlw	027h

	line	46

;initializer for _g_b1Min
	retlw	0Fh
	retlw	027h

	global	_test_adc
	global	_g_timerTick8
	global	_g_doAdcSample
	global	_g_printFlag
	global	_adresult
	global	_g_satSaved
	global	_g_vrefMax
	global	_g_b1Max
	global	_g_ntcDiagChk
	global	_g_ntcDiagVdd
	global	_g_ntcDiagAdc
	global	_g_powerOnTimer
	global	_g_systemTick
	global	_power_ad
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_powerOnPhase
	global	_g_slot0
	global	_g_slot1
	global	_OSCCON
_OSCCON	set	20
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_GIE
_GIE	set	0x5F
	global	_PEIE
_PEIE	set	0x5E
	global	_T0IE
_T0IE	set	0x5D
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC4
_RC4	set	0x834
	global	_RC5
_RC5	set	0x835
	global	_RC2
_RC2	set	0x832
	global	_RC3
_RC3	set	0x833
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	global	_SPBRG1
_SPBRG1	set	393
	global	_TXREG1
_TXREG1	set	391
	global	_RCSTA1
_RCSTA1	set	390
	global	_TXSTA1
_TXSTA1	set	389
	global	_TRMT1
_TRMT1	set	0xC29
psect	strings,class=STRING,delta=2,noexec
global __pstrings
__pstrings:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 1 byte each
stringcode:stringdir:
movlw high(stringdir)
movwf pclath
movf fsr,w
incf fsr
	addwf pc
	global __stringbase
__stringbase:
	retlw	0
psect	strings
	global    __end_of__stringtab
__end_of__stringtab:
	
STR_1:	
	retlw	115	;'s'
	retlw	116	;'t'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	strings
	
STR_5:	
	retlw	93	;']'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	70	;'F'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_8:	
	retlw	93	;']'
	retlw	32	;' '
	retlw	115	;'s'
	retlw	97	;'a'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_2:	
	retlw	66	;'B'
	retlw	49	;'1'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_3:	
	retlw	91	;'['
	retlw	0
psect	strings
	
STR_4:	
	retlw	126	;'~'
	retlw	0
psect	strings
STR_7	equ	STR_4+0
STR_6	equ	STR_3+0
STR_9	equ	STR_1+8
; #config settings
	file	"SC8P096_timer_C.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_g_doAdcSample:
       ds      1

_g_printFlag:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_test_adc:
       ds      1

_g_timerTick8:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_adresult:
       ds      2

_g_satSaved:
       ds      2

_g_vrefMax:
       ds      2

_g_b1Max:
       ds      2

_g_ntcDiagChk:
       ds      2

_g_ntcDiagVdd:
       ds      2

_g_ntcDiagAdc:
       ds      2

_g_powerOnTimer:
       ds      2

_g_systemTick:
       ds      2

_power_ad:
       ds      2

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_powerOnPhase:
       ds      1

psect	dataBANK0,class=BANK0,space=1,noexec
global __pdataBANK0
__pdataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	48
_g_vrefMin:
       ds      2

psect	dataBANK0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	46
_g_b1Min:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_slot0:
       ds      72

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slot1:
       ds      72

	file	"SC8P096_timer_C.as"
	line	#
; Initialize objects allocated to BANK0
	global __pidataBANK0
psect cinit,class=CODE,delta=2,merge=1
	fcall	__pidataBANK0+0		;fetch initializer
	movwf	__pdataBANK0+0&07fh		
	fcall	__pidataBANK0+1		;fetch initializer
	movwf	__pdataBANK0+1&07fh		
	fcall	__pidataBANK0+2		;fetch initializer
	movwf	__pdataBANK0+2&07fh		
	fcall	__pidataBANK0+3		;fetch initializer
	movwf	__pdataBANK0+3&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+017h)
	fcall	clear_ram0
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
	clrf	((__pbssCOMMON)+1)&07Fh
; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_uart_send_string:	; 1 bytes @ 0x0
?_Print_Status:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?_Interrupt_Isr:	; 1 bytes @ 0x0
??_Interrupt_Isr:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
	ds	2
?_ADC_Sample:	; 1 bytes @ 0x2
??_uart_send_char:	; 1 bytes @ 0x2
?___bmul:	; 1 bytes @ 0x2
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x2
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x2
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x2
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x2
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x2
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x2
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x2
	ds	1
??_uart_send_string:	; 1 bytes @ 0x3
??_ADC_Sample:	; 1 bytes @ 0x3
??___bmul:	; 1 bytes @ 0x3
	global	uart_send_string@str
uart_send_string@str:	; 1 bytes @ 0x3
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x3
	ds	1
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x4
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x4
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x4
	ds	1
??_System_Init:	; 1 bytes @ 0x5
	ds	1
??___lwdiv:	; 1 bytes @ 0x6
??___lwmod:	; 1 bytes @ 0x6
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x6
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x6
	ds	1
	global	?_ADC_ReadChannel
?_ADC_ReadChannel:	; 2 bytes @ 0x7
	ds	1
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x8
	ds	1
??_Print_Status:	; 1 bytes @ 0x9
??_uart_send_number:	; 1 bytes @ 0x9
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
?_uart_send_number:	; 1 bytes @ 0x0
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x0
	global	_System_Init$227
_System_Init$227:	; 2 bytes @ 0x0
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x0
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x1
	ds	1
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x2
	global	_System_Init$238
_System_Init$238:	; 2 bytes @ 0x2
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x2
	ds	1
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	_System_Init$249
_System_Init$249:	; 2 bytes @ 0x4
	ds	2
	global	_System_Init$260
_System_Init$260:	; 2 bytes @ 0x6
	ds	1
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0x8
	global	_System_Init$271
_System_Init$271:	; 2 bytes @ 0x8
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x9
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	1
	global	_System_Init$282
_System_Init$282:	; 2 bytes @ 0xA
	ds	1
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	_System_Init$293
_System_Init$293:	; 2 bytes @ 0xC
	ds	1
??_ADC_ReadChannel:	; 1 bytes @ 0xD
	ds	1
	global	ADC_ReadChannel@ch
ADC_ReadChannel@ch:	; 1 bytes @ 0xE
	global	_System_Init$304
_System_Init$304:	; 2 bytes @ 0xE
	ds	2
	global	_System_Init$315
_System_Init$315:	; 2 bytes @ 0x10
	ds	2
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x12
	ds	1
??_main:	; 1 bytes @ 0x13
	ds	2
	global	main@vref
main@vref:	; 2 bytes @ 0x15
	ds	2
	global	main@b1
main@b1:	; 2 bytes @ 0x17
	ds	2
;!
;!Data Sizes:
;!    Strings     34
;!    Constant    0
;!    Data        4
;!    BSS         169
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14      9      12
;!    BANK0            80     25      52
;!    BANK1            80      0      72
;!    BANK3            80      0      72
;!    BANK2            80      0       0

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(1) Largest target is 11
;!		 -> STR_9(CODE[3]), STR_8(CODE[7]), STR_7(CODE[2]), STR_6(CODE[2]), 
;!		 -> STR_5(CODE[8]), STR_4(CODE[2]), STR_3(CODE[2]), STR_2(CODE[4]), 
;!		 -> STR_1(CODE[11]), 
;!
;!    System_Init$315	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    System_Init$304	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    System_Init$293	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    System_Init$282	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    System_Init$271	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    System_Init$260	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    System_Init$249	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    System_Init$238	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!
;!    System_Init$227	PTR struct . size(2) Largest target is 72
;!		 -> g_slot1(BANK3[72]), g_slot0(BANK1[72]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    _main->_ADC_ReadChannel
;!    _System_Init->___bmul
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _ADC_ReadChannel->_ADC_Sample
;!
;!Critical Paths under _Interrupt_Isr in COMMON
;!
;!    None.
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_System_Init
;!    _Print_Status->_uart_send_number
;!    _ADC_ReadChannel->_ADC_Sample
;!
;!Critical Paths under _Interrupt_Isr in BANK0
;!
;!    None.
;!
;!Critical Paths under _main in BANK1
;!
;!    None.
;!
;!Critical Paths under _Interrupt_Isr in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Interrupt_Isr in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Interrupt_Isr in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 6     6      0    4940
;!                                             19 BANK0      6     6      0
;!                    _ADC_ReadChannel
;!                       _Print_Status
;!                        _System_Init
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                         21    21      0    1720
;!                                              5 COMMON     2     2      0
;!                                              0 BANK0     19    19      0
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1     846
;!                                              2 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (1) _Print_Status                                         0     0      0    1685
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     1     1      0     310
;!                                              3 COMMON     1     1      0
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_number                                    10     8      2    1375
;!                                              0 BANK0     10     8      2
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       1     1      0      22
;!                                              2 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___lwmod                                              5     1      4     265
;!                                              2 COMMON     5     1      4
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4     268
;!                                              2 COMMON     7     3      4
;! ---------------------------------------------------------------------------------
;! (1) _ADC_ReadChannel                                      4     2      2     878
;!                                              7 COMMON     2     0      2
;!                                             13 BANK0      2     2      0
;!                         _ADC_Sample
;! ---------------------------------------------------------------------------------
;! (2) _ADC_Sample                                          18    17      1     847
;!                                              2 COMMON     5     4      1
;!                                              0 BANK0     13    13      0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 3
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Interrupt_Isr                                        2     2      0       0
;!                                              0 COMMON     2     2      0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 4
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ADC_ReadChannel
;!     _ADC_Sample
;!   _Print_Status
;!     _uart_send_number
;!       ___lwdiv
;!       ___lwmod
;!       _uart_send_char
;!     _uart_send_string
;!       _uart_send_char
;!   _System_Init
;!     ___bmul
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Interrupt_Isr (ROOT)
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50      0      48       8       90.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      0       0      10        0.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50      0      48       6       90.0%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     19      34       4       65.0%
;!BITBANK0            50      0       0       3        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      9       C       1       85.7%
;!BITCOMMON            E      0       1       0        7.1%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0      D0      12        0.0%
;!ABS                  0      0      D0      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 250 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  b1              2   23[BANK0 ] unsigned int 
;;  vref            2   21[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       2       0       0       0
;;      Totals:         0       6       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_ReadChannel
;;		_Print_Status
;;		_System_Init
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	250
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	250
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 4
; Regs used in _main: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	252
	
l2142:	
;main.c: 252: System_Init();
	fcall	_System_Init
	line	259
;main.c: 259: uart_send_string("start...\r\n");
	movlw	(low((((STR_1)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	324
;main.c: 324: while(1)
	
l386:	
	line	326
# 326 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	329
	
l2144:	
;main.c: 329: if(g_doAdcSample)
	btfss	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u1281
	goto	u1280
u1281:
	goto	l386
u1280:
	line	332
	
l2146:	
;main.c: 330: {
;main.c: 331: unsigned int b1, vref;
;main.c: 332: g_doAdcSample = 0;
	bcf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	l2150
	line	335
	
l390:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l2152
	
l392:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l2152
	
l393:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	l2152
	
l394:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	l2152
	
l395:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l2152
	
l396:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l2152
	
l397:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l2152
	
l398:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l2152
	
l399:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	l2152
	
l400:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	l2152
	
l401:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l2152
	
l402:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l2152
	
l2150:	
	; Switch on 2 bytes has been partitioned into a top level switch of size 1, and 1 sub-switches
; Switch size 1, requested type "space"
; Number of cases is 1, Range of values is 0 to 0
; switch strategies available:
; Name         Instructions Cycles
; simple_byte            4     3 (average)
; direct_byte           11     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	movlw high(0)
	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l2230
	goto	l2152
	opt asmopt_pop
	
l2230:	
; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	movlw low(0)
	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l390
	xorlw	1^0	; case 1
	skipnz
	goto	l392
	xorlw	2^1	; case 2
	skipnz
	goto	l393
	xorlw	3^2	; case 3
	skipnz
	goto	l394
	xorlw	4^3	; case 4
	skipnz
	goto	l395
	xorlw	5^4	; case 5
	skipnz
	goto	l396
	xorlw	6^5	; case 6
	skipnz
	goto	l397
	xorlw	7^6	; case 7
	skipnz
	goto	l398
	xorlw	8^7	; case 8
	skipnz
	goto	l399
	xorlw	9^8	; case 9
	skipnz
	goto	l400
	xorlw	10^9	; case 10
	skipnz
	goto	l401
	xorlw	11^10	; case 11
	skipnz
	goto	l402
	goto	l2152
	opt asmopt_pop

	line	338
	
l2152:	
;main.c: 338: ADCON1 = 7;
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(150)^080h	;volatile
	line	339
;main.c: 339: _delay((unsigned long)((500)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
movlw	3
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_main+0)+0+1),f
	movlw	151
movwf	((??_main+0)+0),f
	u1357:
decfsz	((??_main+0)+0),f
	goto	u1357
	decfsz	((??_main+0)+0+1),f
	goto	u1357
opt asmopt_pop

	line	342
	
l2154:	
;main.c: 342: b1 = ADC_ReadChannel(17);
	movlw	low(011h)
	fcall	_ADC_ReadChannel
	movf	(1+(?_ADC_ReadChannel)),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(main@b1+1)
	movf	(0+(?_ADC_ReadChannel)),w
	movwf	(main@b1)
	line	343
	
l2156:	
;main.c: 343: g_ntcDiagAdc = b1;
	movf	(main@b1+1),w
	movwf	(_g_ntcDiagAdc+1)
	movf	(main@b1),w
	movwf	(_g_ntcDiagAdc)
	line	346
;main.c: 346: vref = ADC_ReadChannel(31);
	movlw	low(01Fh)
	fcall	_ADC_ReadChannel
	movf	(1+(?_ADC_ReadChannel)),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(main@vref+1)
	movf	(0+(?_ADC_ReadChannel)),w
	movwf	(main@vref)
	line	347
	
l2158:	
;main.c: 347: g_ntcDiagChk = vref;
	movf	(main@vref+1),w
	movwf	(_g_ntcDiagChk+1)
	movf	(main@vref),w
	movwf	(_g_ntcDiagChk)
	line	350
	
l2160:	
;main.c: 350: if(b1 >= 4095)
	movlw	0Fh
	subwf	(main@b1+1),w
	movlw	0FFh
	skipnz
	subwf	(main@b1),w
	skipc
	goto	u1291
	goto	u1290
u1291:
	goto	l2164
u1290:
	line	351
	
l2162:	
;main.c: 351: g_ntcDiagVdd++;
	incf	(_g_ntcDiagVdd),f
	skipnz
	incf	(_g_ntcDiagVdd+1),f
	line	354
	
l2164:	
;main.c: 354: if(b1 < g_b1Min) g_b1Min = b1;
	movf	(_g_b1Min+1),w
	subwf	(main@b1+1),w
	skipz
	goto	u1305
	movf	(_g_b1Min),w
	subwf	(main@b1),w
u1305:
	skipnc
	goto	u1301
	goto	u1300
u1301:
	goto	l405
u1300:
	
l2166:	
	movf	(main@b1+1),w
	movwf	(_g_b1Min+1)
	movf	(main@b1),w
	movwf	(_g_b1Min)
	
l405:	
	line	355
;main.c: 355: if(b1 > g_b1Max) g_b1Max = b1;
	movf	(main@b1+1),w
	subwf	(_g_b1Max+1),w
	skipz
	goto	u1315
	movf	(main@b1),w
	subwf	(_g_b1Max),w
u1315:
	skipnc
	goto	u1311
	goto	u1310
u1311:
	goto	l406
u1310:
	
l2168:	
	movf	(main@b1+1),w
	movwf	(_g_b1Max+1)
	movf	(main@b1),w
	movwf	(_g_b1Max)
	
l406:	
	line	356
;main.c: 356: if(vref < g_vrefMin) g_vrefMin = vref;
	movf	(_g_vrefMin+1),w
	subwf	(main@vref+1),w
	skipz
	goto	u1325
	movf	(_g_vrefMin),w
	subwf	(main@vref),w
u1325:
	skipnc
	goto	u1321
	goto	u1320
u1321:
	goto	l407
u1320:
	
l2170:	
	movf	(main@vref+1),w
	movwf	(_g_vrefMin+1)
	movf	(main@vref),w
	movwf	(_g_vrefMin)
	
l407:	
	line	357
;main.c: 357: if(vref > g_vrefMax) g_vrefMax = vref;
	movf	(main@vref+1),w
	subwf	(_g_vrefMax+1),w
	skipz
	goto	u1335
	movf	(main@vref),w
	subwf	(_g_vrefMax),w
u1335:
	skipnc
	goto	u1331
	goto	u1330
u1331:
	goto	l2174
u1330:
	
l2172:	
	movf	(main@vref+1),w
	movwf	(_g_vrefMax+1)
	movf	(main@vref),w
	movwf	(_g_vrefMax)
	line	360
	
l2174:	
;main.c: 360: g_systemTick++;
	incf	(_g_systemTick),f
	skipnz
	incf	(_g_systemTick+1),f
	line	361
	
l2176:	
;main.c: 361: if(g_systemTick >= 900)
	movlw	03h
	subwf	(_g_systemTick+1),w
	movlw	084h
	skipnz
	subwf	(_g_systemTick),w
	skipc
	goto	u1341
	goto	u1340
u1341:
	goto	l386
u1340:
	line	363
	
l2178:	
;main.c: 362: {
;main.c: 363: g_satSaved = g_ntcDiagVdd;
	movf	(_g_ntcDiagVdd+1),w
	movwf	(_g_satSaved+1)
	movf	(_g_ntcDiagVdd),w
	movwf	(_g_satSaved)
	line	364
	
l2180:	
;main.c: 364: g_systemTick = 0;
	clrf	(_g_systemTick)
	clrf	(_g_systemTick+1)
	line	365
	
l2182:	
;main.c: 365: g_ntcDiagVdd = 0;
	clrf	(_g_ntcDiagVdd)
	clrf	(_g_ntcDiagVdd+1)
	line	369
	
l2184:	
;main.c: 369: Print_Status();
	fcall	_Print_Status
	line	372
	
l2186:	
;main.c: 372: g_b1Min = 9999;
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_b1Min)
	movlw	027h
	movwf	((_g_b1Min))+1
	line	373
	
l2188:	
;main.c: 373: g_b1Max = 0;
	clrf	(_g_b1Max)
	clrf	(_g_b1Max+1)
	line	374
	
l2190:	
;main.c: 374: g_vrefMin = 9999;
	movlw	0Fh
	movwf	(_g_vrefMin)
	movlw	027h
	movwf	((_g_vrefMin))+1
	line	375
	
l2192:	
;main.c: 375: g_vrefMax = 0;
	clrf	(_g_vrefMax)
	clrf	(_g_vrefMax+1)
	goto	l386
	global	start
	ljmp	start
	opt stack 0
	line	379
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 87 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   18[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      19       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2      19       0       0       0
;;Total ram usage:       21 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	87
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	87
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 5
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	93
	
l1744:	
# 93 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	94
# 94 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text1
	line	98
	
l1746:	
;main.c: 98: OSCCON = 0x72;
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	99
	
l1748:	
;main.c: 99: OPTION_REG = 0x00;
	clrf	(1)	;volatile
	line	100
# 100 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text1
	line	106
	
l1750:	
;main.c: 106: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
movwf	((??_System_Init+0)+0+1),f
	movlw	241
movwf	((??_System_Init+0)+0),f
	u1367:
decfsz	((??_System_Init+0)+0),f
	goto	u1367
	decfsz	((??_System_Init+0)+0+1),f
	goto	u1367
	nop2
opt asmopt_pop

	line	115
	
l1752:	
;main.c: 115: TRISA = 0B11110000;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(133)^080h	;volatile
	line	116
	
l1754:	
;main.c: 116: PORTA = 0B00001111;
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	117
;main.c: 117: WPUA = 0B00000000;
	clrf	(136)^080h	;volatile
	line	118
;main.c: 118: WPDA = 0B00000000;
	clrf	(135)^080h	;volatile
	line	119
;main.c: 119: IOCA = 0B00000000;
	clrf	(137)^080h	;volatile
	line	128
	
l1756:	
;main.c: 128: TRISB = 0B00110000;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	line	129
	
l1758:	
;main.c: 129: PORTB = 0B01001111;
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	130
;main.c: 130: WPUB = 0B00000000;
	clrf	(8)	;volatile
	line	131
;main.c: 131: WPDB = 0B00000000;
	clrf	(7)	;volatile
	line	132
;main.c: 132: IOCB = 0B00000000;
	clrf	(9)	;volatile
	line	142
	
l1760:	
;main.c: 142: TRISC = 0B00000011;
	movlw	low(03h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	line	143
	
l1762:	
;main.c: 143: PORTC = 0B00000000;
	clrf	(262)^0100h	;volatile
	line	144
	
l1764:	
;main.c: 144: WPUC = 0B00000000;
	clrf	(264)^0100h	;volatile
	line	152
	
l1766:	
;main.c: 152: TRISD = 0B11110000;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	line	153
	
l1768:	
;main.c: 153: PORTD = 0B00001111;
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	154
	
l1770:	
;main.c: 154: WPUD = 0B00000000;
	clrf	(277)^0100h	;volatile
	line	161
;main.c: 161: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	163
;main.c: 163: ANSEL1 = 0x20;
	movlw	low(020h)
	movwf	(148)^080h	;volatile
	line	167
;main.c: 167: ANSEL2 = 0x03;
	movlw	low(03h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	168
;main.c: 168: ANSEL3 = 0xF0;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	171
	
l1772:	
;main.c: 171: CC0CON = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	172
	
l1774:	
;main.c: 172: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	177
;main.c: 177: ADCON0 = 0X41;
	movlw	low(041h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	178
	
l1776:	
;main.c: 178: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	184
	
l1778:	
;main.c: 184: TXSTA1 = 0B10100000;
	movlw	low(0A0h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(389)^0180h	;volatile
	line	185
	
l1780:	
;main.c: 185: RCSTA1 = 0B10010000;
	movlw	low(090h)
	movwf	(390)^0180h	;volatile
	line	186
	
l1782:	
;main.c: 186: SPBRG1 = 103;
	movlw	low(067h)
	movwf	(393)^0180h	;volatile
	line	196
	
l1784:	
;main.c: 196: TMR0 = 6;
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(129)^080h	;volatile
	line	197
	
l1786:	
;main.c: 197: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	198
	
l1788:	
;main.c: 198: T0IE = 1;
	bsf	(93/8),(93)&7	;volatile
	line	201
	
l1790:	
;main.c: 201: PEIE = 1;
	bsf	(94/8),(94)&7	;volatile
	line	203
	
l1792:	
;main.c: 203: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	206
	
l1794:	
;main.c: 206: RB6 = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	207
	
l1796:	
;main.c: 207: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	208
	
l1798:	
;main.c: 208: RC3 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	209
	
l1800:	
;main.c: 209: RC2 = 0;
	bcf	(2098/8)^0100h,(2098)&7	;volatile
	line	210
	
l1802:	
;main.c: 210: RC5 = 0;
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	211
	
l1804:	
;main.c: 211: RC4 = 0;
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	214
	
l1806:	
;main.c: 214: for(i = 0; i < 12; i++)
	bcf	status, 6	;RP1=0, select bank0
	clrf	(System_Init@i)
	line	216
	
l1810:	
;main.c: 215: {
;main.c: 216: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->state = 0;
	movlw	low(06h)
	subwf	(System_Init@i),w
	skipc
	goto	u851
	goto	u850
u851:
	goto	l1814
u850:
	
l1812:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$227)
	movlw	(0x1)
	movwf	(_System_Init$227+1)
	goto	l1816
	
l1814:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	movwf	(_System_Init$227)
	movlw	(0x0)
	movwf	(_System_Init$227+1)
	
l1816:	
	movlw	low(01h)
	addwf	(_System_Init$227),w
	movwf	(??_System_Init+0)+0
	movf	(_System_Init$227+1),w
	skipnc
	addlw	1
	movwf	1+((??_System_Init+0)+0)
	movf	0+(??_System_Init+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_System_Init+0)+0,0
	bcf	status,7
	clrf	indf
	line	217
	
l1818:	
;main.c: 217: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->type = 0;
	movlw	low(06h)
	subwf	(System_Init@i),w
	skipc
	goto	u861
	goto	u860
u861:
	goto	l1822
u860:
	
l1820:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$238)
	movlw	(0x1)
	movwf	(_System_Init$238+1)
	goto	l1824
	
l1822:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	movwf	(_System_Init$238)
	movlw	(0x0)
	movwf	(_System_Init$238+1)
	
l1824:	
	movf	(_System_Init$238),w
	movwf	fsr0
	bsf	status,7
	btfss	(_System_Init$238+1),0
	bcf	status,7
	clrf	indf
	line	218
	
l1826:	
;main.c: 218: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->voltage = 0;
	movlw	low(06h)
	subwf	(System_Init@i),w
	skipc
	goto	u871
	goto	u870
u871:
	goto	l1830
u870:
	
l1828:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$249)
	movlw	(0x1)
	movwf	(_System_Init$249+1)
	goto	l1832
	
l1830:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	movwf	(_System_Init$249)
	movlw	(0x0)
	movwf	(_System_Init$249+1)
	
l1832:	
	movlw	low(03h)
	addwf	(_System_Init$249),w
	movwf	(??_System_Init+0)+0
	movf	(_System_Init$249+1),w
	skipnc
	addlw	1
	movwf	1+((??_System_Init+0)+0)
	movf	0+(??_System_Init+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_System_Init+0)+0,0
	bcf	status,7
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	219
	
l1834:	
;main.c: 219: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->chargeTimer = 0;
	movlw	low(06h)
	subwf	(System_Init@i),w
	skipc
	goto	u881
	goto	u880
u881:
	goto	l1838
u880:
	
l1836:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$260)
	movlw	(0x1)
	movwf	(_System_Init$260+1)
	goto	l1840
	
l1838:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	movwf	(_System_Init$260)
	movlw	(0x0)
	movwf	(_System_Init$260+1)
	
l1840:	
	movlw	low(05h)
	addwf	(_System_Init$260),w
	movwf	(??_System_Init+0)+0
	movf	(_System_Init$260+1),w
	skipnc
	addlw	1
	movwf	1+((??_System_Init+0)+0)
	movf	0+(??_System_Init+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_System_Init+0)+0,0
	bcf	status,7
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	220
	
l1842:	
;main.c: 220: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->ledState = 0;
	movlw	low(06h)
	subwf	(System_Init@i),w
	skipc
	goto	u891
	goto	u890
u891:
	goto	l1846
u890:
	
l1844:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$271)
	movlw	(0x1)
	movwf	(_System_Init$271+1)
	goto	l1848
	
l1846:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	movwf	(_System_Init$271)
	movlw	(0x0)
	movwf	(_System_Init$271+1)
	
l1848:	
	movlw	low(02h)
	addwf	(_System_Init$271),w
	movwf	(??_System_Init+0)+0
	movf	(_System_Init$271+1),w
	skipnc
	addlw	1
	movwf	1+((??_System_Init+0)+0)
	movf	0+(??_System_Init+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_System_Init+0)+0,0
	bcf	status,7
	clrf	indf
	line	221
	
l1850:	
;main.c: 221: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->blinkTimer = 0;
	movlw	low(06h)
	subwf	(System_Init@i),w
	skipc
	goto	u901
	goto	u900
u901:
	goto	l1854
u900:
	
l1852:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$282)
	movlw	(0x1)
	movwf	(_System_Init$282+1)
	goto	l1856
	
l1854:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	movwf	(_System_Init$282)
	movlw	(0x0)
	movwf	(_System_Init$282+1)
	
l1856:	
	movlw	low(07h)
	addwf	(_System_Init$282),w
	movwf	(??_System_Init+0)+0
	movf	(_System_Init$282+1),w
	skipnc
	addlw	1
	movwf	1+((??_System_Init+0)+0)
	movf	0+(??_System_Init+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_System_Init+0)+0,0
	bcf	status,7
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	222
	
l1858:	
;main.c: 222: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->blinkPhase = 0;
	movlw	low(06h)
	subwf	(System_Init@i),w
	skipc
	goto	u911
	goto	u910
u911:
	goto	l1862
u910:
	
l1860:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$293)
	movlw	(0x1)
	movwf	(_System_Init$293+1)
	goto	l1864
	
l1862:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	movwf	(_System_Init$293)
	movlw	(0x0)
	movwf	(_System_Init$293+1)
	
l1864:	
	movlw	low(09h)
	addwf	(_System_Init$293),w
	movwf	(??_System_Init+0)+0
	movf	(_System_Init$293+1),w
	skipnc
	addlw	1
	movwf	1+((??_System_Init+0)+0)
	movf	0+(??_System_Init+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_System_Init+0)+0,0
	bcf	status,7
	clrf	indf
	line	223
	
l1866:	
;main.c: 223: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->stableCnt = 0;
	movlw	low(06h)
	subwf	(System_Init@i),w
	skipc
	goto	u921
	goto	u920
u921:
	goto	l1870
u920:
	
l1868:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$304)
	movlw	(0x1)
	movwf	(_System_Init$304+1)
	goto	l1872
	
l1870:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	movwf	(_System_Init$304)
	movlw	(0x0)
	movwf	(_System_Init$304+1)
	
l1872:	
	movlw	low(0Ah)
	addwf	(_System_Init$304),w
	movwf	(??_System_Init+0)+0
	movf	(_System_Init$304+1),w
	skipnc
	addlw	1
	movwf	1+((??_System_Init+0)+0)
	movf	0+(??_System_Init+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_System_Init+0)+0,0
	bcf	status,7
	clrf	indf
	line	224
	
l1874:	
;main.c: 224: (((i) < 6) ? &g_slot0[(i)] : &g_slot1[(i)-6])->activatePulseCnt = 0;
	movlw	low(06h)
	subwf	(System_Init@i),w
	skipc
	goto	u931
	goto	u930
u931:
	goto	l1878
u930:
	
l1876:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_System_Init$315)
	movlw	(0x1)
	movwf	(_System_Init$315+1)
	goto	l1880
	
l1878:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x0)<<8))&0ffh
	movwf	(_System_Init$315)
	movlw	(0x0)
	movwf	(_System_Init$315+1)
	
l1880:	
	movlw	low(0Bh)
	addwf	(_System_Init$315),w
	movwf	(??_System_Init+0)+0
	movf	(_System_Init$315+1),w
	skipnc
	addlw	1
	movwf	1+((??_System_Init+0)+0)
	movf	0+(??_System_Init+0)+0,w
	movwf	fsr0
	bsf	status,7
	btfss	1+(??_System_Init+0)+0,0
	bcf	status,7
	clrf	indf
	line	214
	
l1882:	
	incf	(System_Init@i),f
	
l1884:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u941
	goto	u940
u941:
	goto	l1810
u940:
	line	230
	
l1886:	
;main.c: 231: g_timerTick = 0;
	clrf	(_g_systemTick)
	clrf	(_g_systemTick+1)
	line	232
;main.c: 232: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)
	clrf	(_g_powerOnTimer+1)
	line	233
;main.c: 238: g_tempReadRoundCnt = 0;
	clrf	(_g_powerOnPhase)
	line	239
	
l381:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    2[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    4[COMMON] unsigned char 
;;  product         1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext2
__ptext2:	;psect for function ___bmul
psect	text2
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 5
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	movwf	(___bmul@multiplier)
	line	6
	
l1730:	
	clrf	(___bmul@product)
	line	43
	
l1732:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u831
	goto	u830
u831:
	goto	l1736
u830:
	line	44
	
l1734:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l1736:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l1738:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u841
	goto	u840
u841:
	goto	l1732
u840:
	line	50
	
l1740:	
	movf	(___bmul@product),w
	line	51
	
l732:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_Print_Status

;; *************** function _Print_Status *****************
;; Defined at:
;;		line 81 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	81
global __ptext3
__ptext3:	;psect for function _Print_Status
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	81
	global	__size_of_Print_Status
	__size_of_Print_Status	equ	__end_of_Print_Status-_Print_Status
	
_Print_Status:	
;incstack = 0
	opt	stack 4
; Regs used in _Print_Status: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	83
	
l2140:	
;uart_dbg.c: 83: uart_send_string("B1=");
	movlw	(low((((STR_2)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	84
;uart_dbg.c: 84: uart_send_number(g_ntcDiagAdc);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_ntcDiagAdc+1),w
	movwf	(uart_send_number@num+1)
	movf	(_g_ntcDiagAdc),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	85
;uart_dbg.c: 85: uart_send_string("[");
	movlw	(low((((STR_3)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	86
;uart_dbg.c: 86: uart_send_number(g_b1Min);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_b1Min+1),w
	movwf	(uart_send_number@num+1)
	movf	(_g_b1Min),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	87
;uart_dbg.c: 87: uart_send_string("~");
	movlw	(low((((STR_4)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	88
;uart_dbg.c: 88: uart_send_number(g_b1Max);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_b1Max+1),w
	movwf	(uart_send_number@num+1)
	movf	(_g_b1Max),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	89
;uart_dbg.c: 89: uart_send_string("] VREF=");
	movlw	(low((((STR_5)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	90
;uart_dbg.c: 90: uart_send_number(g_ntcDiagChk);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_ntcDiagChk+1),w
	movwf	(uart_send_number@num+1)
	movf	(_g_ntcDiagChk),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	91
;uart_dbg.c: 91: uart_send_string("[");
	movlw	(low((((STR_6)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	92
;uart_dbg.c: 92: uart_send_number(g_vrefMin);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_vrefMin+1),w
	movwf	(uart_send_number@num+1)
	movf	(_g_vrefMin),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	93
;uart_dbg.c: 93: uart_send_string("~");
	movlw	(low((((STR_7)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	94
;uart_dbg.c: 94: uart_send_number(g_vrefMax);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_vrefMax+1),w
	movwf	(uart_send_number@num+1)
	movf	(_g_vrefMax),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	95
;uart_dbg.c: 95: uart_send_string("] sat=");
	movlw	(low((((STR_8)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	96
;uart_dbg.c: 96: uart_send_number(g_satSaved);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_satSaved+1),w
	movwf	(uart_send_number@num+1)
	movf	(_g_satSaved),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	97
;uart_dbg.c: 97: uart_send_string("\r\n");
	movlw	(low((((STR_9)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	98
	
l708:	
	return
	opt stack 0
GLOBAL	__end_of_Print_Status
	__end_of_Print_Status:
	signat	_Print_Status,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 34 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             1    wreg     PTR const unsigned char 
;;		 -> STR_9(3), STR_8(7), STR_7(2), STR_6(2), 
;;		 -> STR_5(8), STR_4(2), STR_3(2), STR_2(4), 
;;		 -> STR_1(11), 
;; Auto vars:     Size  Location     Type
;;  str             1    3[COMMON] PTR const unsigned char 
;;		 -> STR_9(3), STR_8(7), STR_7(2), STR_6(2), 
;;		 -> STR_5(8), STR_4(2), STR_3(2), STR_2(4), 
;;		 -> STR_1(11), 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         1       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_main
;;		_Print_Status
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	line	34
global __ptext4
__ptext4:	;psect for function _uart_send_string
psect	text4
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	34
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 5
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;uart_send_string@str stored from wreg
	movwf	(uart_send_string@str)
	line	36
	
l1624:	
;uart_dbg.c: 36: while(*str != '\0')
	goto	l1630
	line	37
	
l1626:	
;uart_dbg.c: 37: uart_send_char(*str++);
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringdir
	fcall	_uart_send_char
	
l1628:	
	incf	(uart_send_string@str),f
	line	36
	
l1630:	
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringdir
	xorlw	0
	skipz
	goto	u641
	goto	u640
u641:
	goto	l1626
u640:
	line	38
	
l696:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 47 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2    0[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    2[BANK0 ] unsigned char [6]
;;  j               1    9[BANK0 ] unsigned char 
;;  i               1    8[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      10       0       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_Status
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	47
global __ptext5
__ptext5:	;psect for function _uart_send_number
psect	text5
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	47
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 4
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	50
	
l2096:	
;uart_dbg.c: 49: unsigned char buf[6];
;uart_dbg.c: 50: unsigned char i = 0;
	clrf	(uart_send_number@i)
	line	54
	
l2098:	
;uart_dbg.c: 51: unsigned char j;
;uart_dbg.c: 54: if(num == 0)
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u1241
	goto	u1240
u1241:
	goto	l2110
u1240:
	line	56
	
l2100:	
;uart_dbg.c: 55: {
;uart_dbg.c: 56: uart_send_char('0');
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l700
	line	63
	
l2104:	
;uart_dbg.c: 62: {
;uart_dbg.c: 63: buf[i++] = '0' + (num % 10);
	movf	(uart_send_number@i),w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwmod@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank0
	movwf	indf
	
l2106:	
	incf	(uart_send_number@i),f
	line	64
	
l2108:	
;uart_dbg.c: 64: num /= 10;
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(uart_send_number@num+1)
	movf	(0+(?___lwdiv)),w
	movwf	(uart_send_number@num)
	line	61
	
l2110:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u1251
	goto	u1250
u1251:
	goto	l2104
u1250:
	line	68
	
l2112:	
;uart_dbg.c: 65: }
;uart_dbg.c: 68: for(j = i; j > 0; j--)
	movf	(uart_send_number@i),w
	movwf	(uart_send_number@j)
	
l2114:	
	movf	((uart_send_number@j)),w
	btfss	status,2
	goto	u1261
	goto	u1260
u1261:
	goto	l2118
u1260:
	goto	l700
	line	69
	
l2118:	
;uart_dbg.c: 69: uart_send_char(buf[j-1]);
	movf	(uart_send_number@j),w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	fcall	_uart_send_char
	line	68
	
l2120:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decf	(uart_send_number@j),f
	goto	l2114
	line	70
	
l700:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 22 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/300
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         1       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	line	22
global __ptext6
__ptext6:	;psect for function _uart_send_char
psect	text6
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	22
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 5
; Regs used in _uart_send_char: [wreg]
;uart_send_char@c stored from wreg
	movwf	(uart_send_char@c)
	line	24
	
l1574:	
;uart_dbg.c: 24: while(TRMT1 == 0);
	
l687:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	btfss	(3113/8)^0180h,(3113)&7	;volatile
	goto	u551
	goto	u550
u551:
	goto	l687
u550:
	line	25
	
l1576:	
;uart_dbg.c: 25: TXREG1 = c;
	movf	(uart_send_char@c),w
	movwf	(391)^0180h	;volatile
	line	26
	
l690:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] unsigned int 
;;  dividend        2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext7
__ptext7:	;psect for function ___lwmod
psect	text7
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 4
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l1604:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u601
	goto	u600
u601:
	goto	l1620
u600:
	line	14
	
l1606:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l1610
	line	16
	
l1608:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l1610:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u611
	goto	u610
u611:
	goto	l1608
u610:
	line	20
	
l1612:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u625
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u625:
	skipc
	goto	u621
	goto	u620
u621:
	goto	l1616
u620:
	line	21
	
l1614:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l1616:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l1618:	
	decfsz	(___lwmod@counter),f
	goto	u631
	goto	u630
u631:
	goto	l1612
u630:
	line	25
	
l1620:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1061:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] unsigned int 
;;  dividend        2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] unsigned int 
;;  counter         1    8[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : B00/0
;;		Unchanged: B00/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         3       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         7       0       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext8
__ptext8:	;psect for function ___lwdiv
psect	text8
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 4
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l1578:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l1580:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u561
	goto	u560
u561:
	goto	l1600
u560:
	line	16
	
l1582:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l1586
	line	18
	
l1584:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l1586:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u571
	goto	u570
u571:
	goto	l1584
u570:
	line	22
	
l1588:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l1590:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u585
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u585:
	skipc
	goto	u581
	goto	u580
u581:
	goto	l1596
u580:
	line	24
	
l1592:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l1594:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l1596:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l1598:	
	decfsz	(___lwdiv@counter),f
	goto	u591
	goto	u590
u591:
	goto	l1588
u590:
	line	30
	
l1600:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l1051:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	_ADC_ReadChannel

;; *************** function _ADC_ReadChannel *****************
;; Defined at:
;;		line 131 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  ch              1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  ch              1   14[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    7[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/100
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         2       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         2       2       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_ADC_Sample
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	131
global __ptext9
__ptext9:	;psect for function _ADC_ReadChannel
psect	text9
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	131
	global	__size_of_ADC_ReadChannel
	__size_of_ADC_ReadChannel	equ	__end_of_ADC_ReadChannel-_ADC_ReadChannel
	
_ADC_ReadChannel:	
;incstack = 0
	opt	stack 5
; Regs used in _ADC_ReadChannel: [wreg+status,2+status,0+pclath+cstack]
;ADC_ReadChannel@ch stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(ADC_ReadChannel@ch)
	line	133
	
l2124:	
;adc_drv.c: 133: test_adc = ADC_Sample(ch, 7);
	movlw	low(07h)
	movwf	(ADC_Sample@adldo)
	movf	(ADC_ReadChannel@ch),w
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	134
	
l2126:	
;adc_drv.c: 134: if (0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u1271
	goto	u1270
u1271:
	goto	l2132
u1270:
	line	135
	
l2128:	
;adc_drv.c: 135: return adresult;
	movf	(_adresult+1),w	;volatile
	movwf	(?_ADC_ReadChannel+1)
	movf	(_adresult),w	;volatile
	movwf	(?_ADC_ReadChannel)
	goto	l456
	line	138
	
l2132:	
;adc_drv.c: 138: ADCON0 = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(149)^080h	;volatile
	line	139
;adc_drv.c: 139: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	140
	
l2134:	
;adc_drv.c: 140: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_ReadChannel+0)+0),f
	u1377:
decfsz	(??_ADC_ReadChannel+0)+0,f
	goto	u1377
	nop
opt asmopt_pop

	line	141
	
l2136:	
;adc_drv.c: 141: return 0;
	clrf	(?_ADC_ReadChannel)
	clrf	(?_ADC_ReadChannel+1)
	line	142
	
l456:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_ReadChannel
	__end_of_ADC_ReadChannel:
	signat	_ADC_ReadChannel,4218
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 43 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    2[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    1[BANK0 ] unsigned char 
;;  j               1    0[BANK0 ] unsigned char 
;;  adsum           4    3[BANK0 ] volatile unsigned long 
;;  ad_temp         2   11[BANK0 ] volatile unsigned int 
;;  admax           2    9[BANK0 ] volatile unsigned int 
;;  admin           2    7[BANK0 ] volatile unsigned int 
;;  i               1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      13       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ADC_ReadChannel
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=0
	line	43
global __ptext10
__ptext10:	;psect for function _ADC_Sample
psect	text10
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	43
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 5
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	movwf	(ADC_Sample@adch)
	line	45
	
l2026:	
;adc_drv.c: 45: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	46
	
l2028:	
;adc_drv.c: 46: volatile unsigned int admin = 0;
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	47
;adc_drv.c: 47: volatile unsigned int admax = 0;
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	48
;adc_drv.c: 48: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	51
	
l2030:	
;adc_drv.c: 51: if ((!LDO_EN) && (adldo & 0x04))
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u1091
	goto	u1090
u1091:
	goto	l2036
u1090:
	
l2032:	
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u1101
	goto	u1100
u1101:
	goto	l2036
u1100:
	line	53
	
l2034:	
;adc_drv.c: 52: {
;adc_drv.c: 53: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	54
;adc_drv.c: 54: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??_ADC_Sample+0)+0),f
	u1387:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u1387
opt asmopt_pop

	line	55
;adc_drv.c: 55: }
	goto	l2038
	line	57
	
l2036:	
;adc_drv.c: 56: else
;adc_drv.c: 57: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	60
	
l2038:	
;adc_drv.c: 60: if(adch & 0x10)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(ADC_Sample@adch),(4)&7
	goto	u1111
	goto	u1110
u1111:
	goto	l437
u1110:
	line	62
	
l2040:	
;adc_drv.c: 61: {
;adc_drv.c: 62: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	63
	
l2042:	
;adc_drv.c: 63: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(ADC_Sample@adch),f
	line	64
;adc_drv.c: 64: }
	goto	l2044
	line	65
	
l437:	
	line	66
;adc_drv.c: 65: else
;adc_drv.c: 66: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	68
	
l2044:	
;adc_drv.c: 68: unsigned char i = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@i)
	line	70
;adc_drv.c: 70: for (i = 0; i < 10; i++)
	clrf	(ADC_Sample@i)
	line	73
	
l2050:	
;adc_drv.c: 71: {
;adc_drv.c: 73: ADCON0 = (unsigned char)(0X41 | (adch << 2));
	movf	(ADC_Sample@adch),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u1125:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u1125
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	041h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	74
# 74 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
nop ;# 
	line	75
# 75 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
nop ;# 
	line	76
# 76 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
nop ;# 
	line	77
# 77 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
nop ;# 
psect	text10
	line	78
	
l2052:	
;adc_drv.c: 78: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	81
	
l2054:	
;adc_drv.c: 81: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	82
;adc_drv.c: 82: while (GODONE)
	goto	l441
	
l442:	
	line	84
;adc_drv.c: 83: {
;adc_drv.c: 84: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	85
;adc_drv.c: 85: if (0 == (--j))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u1131
	goto	u1130
u1131:
	goto	l441
u1130:
	line	86
	
l2056:	
;adc_drv.c: 86: return 0;
	movlw	low(0)
	goto	l444
	line	87
	
l441:	
	line	82
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u1141
	goto	u1140
u1141:
	goto	l442
u1140:
	line	90
	
l2060:	
;adc_drv.c: 87: }
;adc_drv.c: 90: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
l2062:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	93
	
l2064:	
;adc_drv.c: 93: if (0 == admax)
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u1151
	goto	u1150
u1151:
	goto	l2068
u1150:
	line	95
	
l2066:	
;adc_drv.c: 94: {
;adc_drv.c: 95: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	96
;adc_drv.c: 96: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	97
;adc_drv.c: 97: }
	goto	l447
	line	99
	
l2068:	
;adc_drv.c: 99: else if (ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u1165
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u1165:
	skipnc
	goto	u1161
	goto	u1160
u1161:
	goto	l2072
u1160:
	line	100
	
l2070:	
;adc_drv.c: 100: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	l447
	line	102
	
l2072:	
;adc_drv.c: 102: else if (ad_temp < admin)
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u1175
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u1175:
	skipnc
	goto	u1171
	goto	u1170
u1171:
	goto	l447
u1170:
	line	103
	
l2074:	
;adc_drv.c: 103: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	105
	
l447:	
;adc_drv.c: 105: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u1181
	addwf	(ADC_Sample@adsum+1),f	;volatile
u1181:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u1182
	addwf	(ADC_Sample@adsum+2),f	;volatile
u1182:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u1183
	addwf	(ADC_Sample@adsum+3),f	;volatile
u1183:

	line	70
	
l2076:	
	incf	(ADC_Sample@i),f
	
l2078:	
	movlw	low(0Ah)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u1191
	goto	u1190
u1191:
	goto	l2050
u1190:
	line	109
	
l2080:	
;adc_drv.c: 106: }
;adc_drv.c: 109: adsum -= admax;
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u1205
	goto	u1206
u1205:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u1206:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u1207
	goto	u1208
u1207:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u1208:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u1209
	goto	u1200
u1209:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u1200:

	line	110
;adc_drv.c: 110: if (adsum >= admin)
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u1215
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u1215
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u1215
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u1215:
	skipc
	goto	u1211
	goto	u1210
u1211:
	goto	l451
u1210:
	line	111
	
l2082:	
;adc_drv.c: 111: adsum -= admin;
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u1225
	goto	u1226
u1225:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u1226:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u1227
	goto	u1228
u1227:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u1228:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u1229
	goto	u1220
u1229:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u1220:

	goto	l2084
	line	112
	
l451:	
	line	113
;adc_drv.c: 112: else
;adc_drv.c: 113: adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	115
	
l2084:	
;adc_drv.c: 115: adresult = adsum >> 3;
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	03h
u1235:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u1230:
	addlw	-1
	skipz
	goto	u1235
	movf	1+(??_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	118
	
l2086:	
;adc_drv.c: 118: adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	119
	
l2088:	
;adc_drv.c: 119: admin = 0;
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	120
	
l2090:	
;adc_drv.c: 120: admax = 0;
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	121
	
l2092:	
;adc_drv.c: 121: return 0xA5;
	movlw	low(0A5h)
	line	122
	
l444:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Interrupt_Isr

;; *************** function _Interrupt_Isr *****************
;; Defined at:
;;		line 388 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	388
global __ptext11
__ptext11:	;psect for function _Interrupt_Isr
psect	text11
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	388
	global	__size_of_Interrupt_Isr
	__size_of_Interrupt_Isr	equ	__end_of_Interrupt_Isr-_Interrupt_Isr
	
_Interrupt_Isr:	
;incstack = 0
	opt	stack 4
; Regs used in _Interrupt_Isr: [wreg+status,2+status,0]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Interrupt_Isr+0)
	movf	pclath,w
	movwf	(??_Interrupt_Isr+1)
	ljmp	_Interrupt_Isr
psect	text11
	line	390
	
i1l1964:	
;main.c: 390: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u103_21
	goto	u103_20
u103_21:
	goto	i1l425
u103_20:
	line	392
	
i1l1966:	
;main.c: 391: {
;main.c: 392: TMR0 += 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	addwf	(129)^080h,f	;volatile
	line	393
	
i1l1968:	
;main.c: 394: g_timerTick++;
	bcf	(90/8),(90)&7	;volatile
	line	395
# 395 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text11
	line	398
	
i1l1970:	
;main.c: 398: if(g_powerOnPhase < 2)
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(_g_powerOnPhase),w
	skipnc
	goto	u104_21
	goto	u104_20
u104_21:
	goto	i1l1988
u104_20:
	line	400
	
i1l1972:	
;main.c: 399: {
;main.c: 400: g_powerOnTimer++;
	incf	(_g_powerOnTimer),f
	skipnz
	incf	(_g_powerOnTimer+1),f
	line	401
	
i1l1974:	
;main.c: 401: if(g_powerOnPhase == 0)
	movf	((_g_powerOnPhase)),w
	btfss	status,2
	goto	u105_21
	goto	u105_20
u105_21:
	goto	i1l1982
u105_20:
	line	403
	
i1l1976:	
;main.c: 402: {
;main.c: 403: if(g_powerOnTimer >= 100)
	movlw	0
	subwf	(_g_powerOnTimer+1),w
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w
	skipc
	goto	u106_21
	goto	u106_20
u106_21:
	goto	i1l423
u106_20:
	line	405
	
i1l1978:	
;main.c: 404: {
;main.c: 405: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)
	clrf	(_g_powerOnTimer+1)
	line	406
	
i1l1980:	
;main.c: 406: g_powerOnPhase = 1;
	clrf	(_g_powerOnPhase)
	incf	(_g_powerOnPhase),f
	goto	i1l425
	line	411
	
i1l1982:	
;main.c: 409: else
;main.c: 410: {
;main.c: 411: if(g_powerOnTimer >= 100)
	movlw	0
	subwf	(_g_powerOnTimer+1),w
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w
	skipc
	goto	u107_21
	goto	u107_20
u107_21:
	goto	i1l423
u107_20:
	line	413
	
i1l1984:	
;main.c: 412: {
;main.c: 413: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)
	clrf	(_g_powerOnTimer+1)
	line	414
	
i1l1986:	
;main.c: 414: g_powerOnPhase = 2;
	movlw	low(02h)
	movwf	(_g_powerOnPhase)
	goto	i1l425
	line	422
	
i1l1988:	
;main.c: 418: else
;main.c: 419: {
;main.c: 422: g_timerTick8++;
	incf	(_g_timerTick8),f
	line	423
	
i1l1990:	
;main.c: 423: if(g_timerTick8 >= 8)
	movlw	low(08h)
	subwf	(_g_timerTick8),w
	skipc
	goto	u108_21
	goto	u108_20
u108_21:
	goto	i1l425
u108_20:
	line	425
	
i1l1992:	
;main.c: 424: {
;main.c: 425: g_timerTick8 = 0;
	clrf	(_g_timerTick8)
	line	426
	
i1l1994:	
;main.c: 426: g_doAdcSample = 1;
	bsf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	i1l425
	line	428
	
i1l423:	
	line	430
	
i1l425:	
	movf	(??_Interrupt_Isr+1),w
	movwf	pclath
	swapf	(??_Interrupt_Isr+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Interrupt_Isr
	__end_of_Interrupt_Isr:
	signat	_Interrupt_Isr,89
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
