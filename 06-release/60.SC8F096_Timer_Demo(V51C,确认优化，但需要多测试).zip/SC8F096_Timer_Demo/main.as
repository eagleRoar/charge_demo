opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ChargeProcess_Slot
	FNCALL	_main,_Do_AdcSample
	FNCALL	_main,_Do_NtcRead
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_System_Init
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_Do_NtcRead,_Read_Temperature
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Do_AdcSample,_ADC_Sample
	FNCALL	_Do_AdcSample,___bmul
	FNCALL	_ChargeProcess_Slot,_ADC_Sample
	FNCALL	_ChargeProcess_Slot,_Detect_BatteryType
	FNCALL	_ChargeProcess_Slot,___bmul
	FNCALL	_ChargeProcess_Slot,___lldiv
	FNCALL	_ChargeProcess_Slot,___lmul
	FNCALL	_ChargeProcess_Slot,___lwdiv
	FNCALL	_ChargeProcess_Slot,___wmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_CCCV_Control
	FNCALL	_Isr_Timer,_Charging_Control
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Update_LED_Slot
	FNCALL	_Isr_Timer,i1_ADC_Sample
	FNCALL	_Isr_Timer,i1___lldiv
	FNCALL	_Update_LED_Slot,i1___bmul
	FNCALL	_Charging_Control,i1___bmul
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,i1___bmul
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_temperature
	global	_g_vcc_mv
	global	_g_impCheckSlot
psect	idataBANK0,class=CODE,space=0,delta=2,noexec
global __pidataBANK0
__pidataBANK0:
	file	"charge_mgr.c"
	line	12

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	file	"main.c"
	line	15

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

	file	"charge_mgr.c"
	line	19

;initializer for _g_impCheckSlot
	retlw	0FFh
	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"main.c"
	line	41
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_s_ledBlinkCnt
	global	_g_tempProtect
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_adcBusy
	global	_g_doAdcSample
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_powerOnTimer
	global	_g_cvIntegral
	global	_g_vccProtect
	global	_g_tempPhase
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_scanPhase
	global	_g_scanIndex
	global	_test_adc
	global	_adresult
	global	_g_detectLowCnt
	global	_g_highVFlag
	global	_g_impData
	global	_g_capFlag
	global	_g_slot
	global	_g_slotRefV
	global	_g_stableCnt
	global	_g_ovCnt
	global	_g_ccBlocks
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_GIE
_GIE	set	0x5F
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC4
_RC4	set	0x834
	global	_RC5
_RC5	set	0x835
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	0
psect	stringtext
	
STR_33:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_23:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	45	;'-'
	retlw	105	;'i'
	retlw	111	;'o'
	retlw	110	;'n'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	67	;'C'
	retlw	32	;' '
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	95	;'_'
	retlw	76	;'L'
	retlw	79	;'O'
	retlw	67	;'C'
	retlw	75	;'K'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_34:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_8:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_27:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	73	;'I'
	retlw	79	;'O'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_25:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_7:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_29:	
	retlw	32	;' '
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_30:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	53	;'5'
	retlw	49	;'1'
	retlw	67	;'C'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
STR_9	equ	STR_2+0
STR_11	equ	STR_34+7
STR_31	equ	STR_34+7
STR_32	equ	STR_34+7
; #config settings
	file	"main.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

_g_adcBusy:
       ds      1

_g_doAdcSample:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_s_ledBlinkCnt:
       ds      1

_g_tempProtect:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_powerOnTimer:
       ds      2

_g_cvIntegral:
       ds      2

_g_vccProtect:
       ds      1

_g_tempPhase:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_scanPhase:
       ds      1

_g_scanIndex:
       ds      1

_test_adc:
       ds      1

_adresult:
       ds      2

psect	dataBANK0,class=BANK0,space=1,noexec
global __pdataBANK0
__pdataBANK0:
	file	"charge_mgr.c"
	line	12
_g_temperature:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_detectLowCnt:
       ds      12

_g_highVFlag:
       ds      2

_g_impData:
       ds      2

_g_capFlag:
       ds      2

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"main.c"
	line	15
_g_vcc_mv:
       ds      2

psect	dataBANK1
	file	"charge_mgr.c"
	line	19
_g_impCheckSlot:
       ds      1

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slotRefV:
       ds      24

_g_stableCnt:
       ds      12

_g_ovCnt:
       ds      12

_g_ccBlocks:
       ds      12

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"main.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
	fcall	__pidataBANK1+2		;fetch initializer
	movwf	__pdataBANK1+2&07fh		
; Initialize objects allocated to BANK0
	global __pidataBANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	fcall	__pidataBANK0+0		;fetch initializer
	movwf	__pdataBANK0+0&07fh		
	fcall	__pidataBANK0+1		;fetch initializer
	movwf	__pdataBANK0+1&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+03Ch)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+012h)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+014h)
	fcall	clear_ram0
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
	clrf	((__pbssCOMMON)+1)&07Fh
; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK3,class=BANK3,space=1,noexec
global __pcstackBANK3
__pcstackBANK3:
	global	ChargeProcess_Slot@v_ref
ChargeProcess_Slot@v_ref:	; 2 bytes @ 0x0
	ds	2
	global	ChargeProcess_Slot@bat_mv
ChargeProcess_Slot@bat_mv:	; 2 bytes @ 0x2
	ds	2
	global	ChargeProcess_Slot@bat_mv_369
ChargeProcess_Slot@bat_mv_369:	; 2 bytes @ 0x4
	ds	2
	global	ChargeProcess_Slot@bat_mv_372
ChargeProcess_Slot@bat_mv_372:	; 2 bytes @ 0x6
	ds	4
	global	ChargeProcess_Slot@ty
ChargeProcess_Slot@ty:	; 1 bytes @ 0xA
	ds	1
	global	ChargeProcess_Slot@ct
ChargeProcess_Slot@ct:	; 2 bytes @ 0xB
	ds	2
	global	ChargeProcess_Slot@v
ChargeProcess_Slot@v:	; 2 bytes @ 0xD
	ds	2
	global	ChargeProcess_Slot@idx
ChargeProcess_Slot@idx:	; 1 bytes @ 0xF
	ds	1
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
?_uart_send_string:	; 1 bytes @ 0x0
	global	?___wmul
?___wmul:	; 2 bytes @ 0x0
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x0
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x0
	global	?___lmul
?___lmul:	; 4 bytes @ 0x0
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x0
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x0
	global	___wmul@multiplier
___wmul@multiplier:	; 2 bytes @ 0x0
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x0
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x0
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x0
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x1
	ds	1
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x2
	global	___wmul@multiplicand
___wmul@multiplicand:	; 2 bytes @ 0x2
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x2
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x2
	ds	1
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
?_uart_send_number:	; 1 bytes @ 0x4
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x4
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x4
	ds	2
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x6
	ds	1
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x8
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x8
	ds	1
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	2
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0xC
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0xC
	ds	1
	global	Do_AdcSample@ch
Do_AdcSample@ch:	; 1 bytes @ 0xD
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0xD
	ds	1
	global	Do_AdcSample@ty
Do_AdcSample@ty:	; 1 bytes @ 0xE
	global	_Print_NtcTemp$725
_Print_NtcTemp$725:	; 2 bytes @ 0xE
	ds	1
	global	Do_AdcSample@dly
Do_AdcSample@dly:	; 1 bytes @ 0xF
	ds	1
	global	Do_AdcSample@st
Do_AdcSample@st:	; 1 bytes @ 0x10
	global	_Print_NtcTemp$726
_Print_NtcTemp$726:	; 2 bytes @ 0x10
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x10
	ds	4
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x14
	ds	1
??_Read_Temperature:	; 1 bytes @ 0x15
??_ChargeProcess_Slot:	; 1 bytes @ 0x15
??_Print_SystemStatus:	; 1 bytes @ 0x15
	ds	4
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x19
	ds	1
	global	ChargeProcess_Slot@v_init
ChargeProcess_Slot@v_init:	; 2 bytes @ 0x1A
	ds	2
	global	ChargeProcess_Slot@vx_mv
ChargeProcess_Slot@vx_mv:	; 4 bytes @ 0x1C
	ds	1
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x1D
	global	_Print_SystemStatus$727
_Print_SystemStatus$727:	; 2 bytes @ 0x1D
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x1F
	global	_Print_SystemStatus$728
_Print_SystemStatus$728:	; 2 bytes @ 0x1F
	ds	1
	global	ChargeProcess_Slot@bat_mv_long
ChargeProcess_Slot@bat_mv_long:	; 4 bytes @ 0x20
	ds	1
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x21
	ds	3
	global	ChargeProcess_Slot@vx_mv_367
ChargeProcess_Slot@vx_mv_367:	; 4 bytes @ 0x24
	ds	1
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x25
	ds	1
	global	_Print_SystemStatus$272
_Print_SystemStatus$272:	; 2 bytes @ 0x26
	ds	2
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x28
	global	ChargeProcess_Slot@bat_mv_long_368
ChargeProcess_Slot@bat_mv_long_368:	; 4 bytes @ 0x28
	ds	2
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0x2A
	ds	2
	global	ChargeProcess_Slot@vx_mv_370
ChargeProcess_Slot@vx_mv_370:	; 4 bytes @ 0x2C
	ds	2
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0x2E
	ds	2
	global	ChargeProcess_Slot@bat_mv_long_371
ChargeProcess_Slot@bat_mv_long_371:	; 4 bytes @ 0x30
	ds	2
	global	Print_SystemStatus@t
Print_SystemStatus@t:	; 1 bytes @ 0x32
	ds	1
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x33
	ds	1
	global	_ChargeProcess_Slot$373
_ChargeProcess_Slot$373:	; 2 bytes @ 0x34
	ds	1
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x35
	ds	1
	global	ChargeProcess_Slot@st
ChargeProcess_Slot@st:	; 1 bytes @ 0x36
	ds	1
??_main:	; 1 bytes @ 0x37
	ds	2
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Update_LED_Slot:	; 1 bytes @ 0x0
?_Charging_Control:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_ChargeProcess_Slot:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Do_AdcSample:	; 1 bytes @ 0x0
?_Do_NtcRead:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?i1_ADC_Sample:	; 1 bytes @ 0x0
?i1___bmul:	; 1 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	?i1___lldiv
?i1___lldiv:	; 4 bytes @ 0x0
	global	i1ADC_Sample@adldo
i1ADC_Sample@adldo:	; 1 bytes @ 0x0
	global	i1___bmul@multiplicand
i1___bmul@multiplicand:	; 1 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	global	i1___lldiv@divisor
i1___lldiv@divisor:	; 4 bytes @ 0x0
	ds	1
??i1_ADC_Sample:	; 1 bytes @ 0x1
??i1___bmul:	; 1 bytes @ 0x1
	global	i1___bmul@multiplier
i1___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
	global	i1___bmul@product
i1___bmul@product:	; 1 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_Update_LED_Slot:	; 1 bytes @ 0x3
??_Charging_Control:	; 1 bytes @ 0x3
	global	Charging_Control@s
Charging_Control@s:	; 1 bytes @ 0x3
	global	Update_LED_Slot@idx
Update_LED_Slot@idx:	; 1 bytes @ 0x3
	ds	1
??___awdiv:	; 1 bytes @ 0x4
	global	Charging_Control@i
Charging_Control@i:	; 1 bytes @ 0x4
	global	Update_LED_Slot@hasErr
Update_LED_Slot@hasErr:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	global	i1___lldiv@dividend
i1___lldiv@dividend:	; 4 bytes @ 0x4
	ds	1
	global	Update_LED_Slot@hasChg
Update_LED_Slot@hasChg:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	ds	1
	global	Update_LED_Slot@hasFull
Update_LED_Slot@hasFull:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	1
	global	Update_LED_Slot@i
Update_LED_Slot@i:	; 1 bytes @ 0x7
	ds	1
??_CCCV_Control:	; 1 bytes @ 0x8
??i1___lldiv:	; 1 bytes @ 0x8
	global	Update_LED_Slot@s
Update_LED_Slot@s:	; 1 bytes @ 0x8
	ds	2
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	i1ADC_Sample@adch
i1ADC_Sample@adch:	; 1 bytes @ 0x0
	global	i1___lldiv@counter
i1___lldiv@counter:	; 1 bytes @ 0x0
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x0
	ds	1
	global	i1ADC_Sample@j
i1ADC_Sample@j:	; 1 bytes @ 0x1
	global	i1___lldiv@quotient
i1___lldiv@quotient:	; 4 bytes @ 0x1
	ds	1
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x2
	global	i1ADC_Sample@i
i1ADC_Sample@i:	; 1 bytes @ 0x2
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x3
	global	i1ADC_Sample@adsum
i1ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0x4
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0x5
	ds	1
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x6
	ds	1
	global	i1ADC_Sample@admin
i1ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x8
	ds	1
	global	i1ADC_Sample@admax
i1ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	1
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xA
	ds	1
	global	i1ADC_Sample@ad_temp
i1ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0xC
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0xD
	ds	1
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0xE
	ds	2
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x10
	ds	1
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x11
	ds	1
??_Isr_Timer:	; 1 bytes @ 0x12
	ds	4
	global	Isr_Timer@pt
Isr_Timer@pt:	; 4 bytes @ 0x16
	ds	4
??_AD_Init:	; 1 bytes @ 0x1A
??_uart_init:	; 1 bytes @ 0x1A
?_ADC_Sample:	; 1 bytes @ 0x1A
??_uart_send_char:	; 1 bytes @ 0x1A
?_Detect_BatteryType:	; 1 bytes @ 0x1A
??___wmul:	; 1 bytes @ 0x1A
??___lmul:	; 1 bytes @ 0x1A
?___bmul:	; 1 bytes @ 0x1A
??___lwdiv:	; 1 bytes @ 0x1A
??___lwmod:	; 1 bytes @ 0x1A
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x1A
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x1A
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x1A
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x1A
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x1A
	global	___wmul@product
___wmul@product:	; 2 bytes @ 0x1A
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x1A
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x1B
??___bmul:	; 1 bytes @ 0x1B
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x1B
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x1B
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x1B
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x1C
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x1C
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x1C
	ds	1
??_uart_send_string:	; 1 bytes @ 0x1D
??_uart_send_number:	; 1 bytes @ 0x1D
??_System_Init:	; 1 bytes @ 0x1D
??_Print_NtcTemp:	; 1 bytes @ 0x1D
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x1D
	ds	1
??___lldiv:	; 1 bytes @ 0x1E
	ds	1
??_Do_AdcSample:	; 1 bytes @ 0x1F
??_Do_NtcRead:	; 1 bytes @ 0x1F
	ds	1
;!
;!Data Sizes:
;!    Strings     237
;!    Constant    12
;!    Data        5
;!    BSS         172
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     10      13
;!    BANK0            80     32      54
;!    BANK1            80     57      78
;!    BANK3            80     16      76
;!    BANK2            80      0      72

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 25
;!		 -> STR_34(CODE[10]), STR_33(CODE[21]), STR_32(CODE[3]), STR_31(CODE[3]), 
;!		 -> STR_30(CODE[5]), STR_29(CODE[5]), STR_28(CODE[6]), STR_27(CODE[6]), 
;!		 -> STR_26(CODE[6]), STR_25(CODE[6]), STR_24(CODE[16]), STR_23(CODE[13]), 
;!		 -> STR_22(CODE[15]), STR_21(CODE[7]), STR_20(CODE[5]), STR_19(CODE[5]), 
;!		 -> STR_18(CODE[6]), STR_17(CODE[6]), STR_16(CODE[6]), STR_15(CODE[7]), 
;!		 -> STR_14(CODE[4]), STR_13(CODE[6]), STR_12(CODE[6]), STR_11(CODE[3]), 
;!		 -> STR_10(CODE[12]), STR_9(CODE[2]), STR_8(CODE[6]), STR_7(CODE[5]), 
;!		 -> STR_6(CODE[6]), STR_5(CODE[5]), STR_4(CODE[25]), STR_3(CODE[4]), 
;!		 -> STR_2(CODE[2]), STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->_CCCV_Control
;!    _Update_LED_Slot->i1___bmul
;!    _Charging_Control->i1___bmul
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Do_AdcSample
;!    _System_Init->___bmul
;!    _Print_SystemStatus->_ADC_Sample
;!    _Print_NtcTemp->___lwdiv
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___bmul
;!    _uart_send_number->___lwdiv
;!    _uart_send_number->_uart_send_char
;!    _Read_Temperature->_ADC_Sample
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->_ADC_Sample
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    _Isr_Timer->_CCCV_Control
;!
;!Critical Paths under _main in BANK1
;!
;!    _main->_ChargeProcess_Slot
;!    _Print_SystemStatus->___lldiv
;!    _Print_NtcTemp->_uart_send_number
;!    _uart_send_number->___lwdiv
;!    _uart_send_number->___lwmod
;!    _Do_NtcRead->_Read_Temperature
;!    _Read_Temperature->___lldiv
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->___lldiv
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    _main->_ChargeProcess_Slot
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 2     2      0   62273
;!                                             55 BANK1      2     2      0
;!                 _ChargeProcess_Slot
;!                       _Do_AdcSample
;!                         _Do_NtcRead
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                        _System_Init
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1542
;!                                             29 BANK0      1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  33    33      0   15365
;!                                             21 BANK1     33    33      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    7285
;!                                             14 BANK1      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    2920
;!                                              0 BANK1      2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_number                                    10     8      2    2953
;!                                              4 BANK1     10     8      2
;!                             ___bmul (ARG)
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     144
;!                                             26 BANK0      3     3      0
;! ---------------------------------------------------------------------------------
;! (3) ___lwmod                                              5     1      4     378
;!                                             26 BANK0      1     1      0
;!                                              0 BANK1      4     0      4
;! ---------------------------------------------------------------------------------
;! (1) _Do_NtcRead                                           0     0      0    7052
;!                   _Read_Temperature
;! ---------------------------------------------------------------------------------
;! (2) _Read_Temperature                                    12    12      0    7052
;!                                             21 BANK1     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (1) _Do_AdcSample                                         5     5      0    3446
;!                                             31 BANK0      1     1      0
;!                                             13 BANK1      4     4      0
;!                         _ADC_Sample
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _ChargeProcess_Slot                                  50    50      0   24663
;!                                             21 BANK1     34    34      0
;!                                              0 BANK3     16    16      0
;!                         _ADC_Sample
;!                 _Detect_BatteryType
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (2) ___wmul                                               6     2      4    2404
;!                                             26 BANK0      2     2      0
;!                                              0 BANK1      4     0      4
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4    1010
;!                                             26 BANK0      3     3      0
;!                                              0 BANK1      4     0      4
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8    2762
;!                                             26 BANK0      4     4      0
;!                                              0 BANK1      8     0      8
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1212
;!                                              8 BANK1     13     5      8
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1    1194
;!                                             26 BANK0      3     2      1
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     251
;!                                             26 BANK0      2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _ADC_Sample                                          18    17      1    1508
;!                                             26 BANK0      5     4      1
;!                                              0 BANK1     13    13      0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 3
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            8     8      0    4077
;!                                             18 BANK0      8     8      0
;!                       _CCCV_Control
;!                   _Charging_Control
;!                 _PowerOnLedSequence
;!                    _Update_LED_Slot
;!                       i1_ADC_Sample
;!                          i1___lldiv
;! ---------------------------------------------------------------------------------
;! (5) i1___lldiv                                           13     5      8      44
;!                                              0 COMMON     8     0      8
;!                                              0 BANK0      5     5      0
;! ---------------------------------------------------------------------------------
;! (5) i1_ADC_Sample                                        18    17      1     551
;!                                              0 COMMON     5     4      1
;!                                              0 BANK0     13    13      0
;! ---------------------------------------------------------------------------------
;! (5) _Update_LED_Slot                                      6     6      0     660
;!                                              3 COMMON     6     6      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Charging_Control                                     2     2      0     666
;!                                              3 COMMON     2     2      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _CCCV_Control                                        20    20      0    2108
;!                                              8 COMMON     2     2      0
;!                                              0 BANK0     18    18      0
;!                            ___awdiv
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (6) i1___bmul                                             3     2      1     144
;!                                              0 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (6) ___awdiv                                              8     4      4     428
;!                                              0 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ChargeProcess_Slot
;!     _ADC_Sample
;!     _Detect_BatteryType
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___wmul
;!   _Do_AdcSample
;!     _ADC_Sample
;!     ___bmul
;!   _Do_NtcRead
;!     _Read_Temperature
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!       ___lwdiv
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     i1___bmul
;!   _Charging_Control
;!     i1___bmul
;!   _PowerOnLedSequence
;!   _Update_LED_Slot
;!     i1___bmul
;!   i1_ADC_Sample
;!   i1___lldiv
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50     10      4C       8       95.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      0      48      10       90.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50     39      4E       6       97.5%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     20      36       4       67.5%
;!BITBANK0            50      0       0       3        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      A       D       1       92.9%
;!BITCOMMON            E      0       1       0        7.1%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     125      12        0.0%
;!ABS                  0      0     125      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 501 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       2       0       0
;;      Totals:         0       0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ChargeProcess_Slot
;;		_Do_AdcSample
;;		_Do_NtcRead
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_System_Init
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"main.c"
	line	501
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"main.c"
	line	501
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	504
	
l8360:	
	opt asmopt_push
opt asmopt_off
movlw	52
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_main+0)^080h+0+1),f
	movlw	241
movwf	((??_main+0)^080h+0),f
	u13427:
decfsz	((??_main+0)^080h+0),f
	goto	u13427
	decfsz	((??_main+0)^080h+0+1),f
	goto	u13427
opt asmopt_pop

	line	505
# 505 "main.c"
clrwdt ;# 
psect	maintext
	line	508
	
l8362:	
	fcall	_System_Init
	line	512
	
l8364:	
	movlw	low(((STR_33)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	513
	
l8366:	
	movlw	low(((STR_34)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_34)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	517
	
l446:	
	line	519
# 519 "main.c"
clrwdt ;# 
psect	maintext
	line	522
	
l8368:	
	btfss	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u13391
	goto	u13390
u13391:
	goto	l8378
u13390:
	line	524
	
l8370:	
	bcf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	line	525
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	526
	
l8372:	
	fcall	_Do_AdcSample
	line	527
	
l8374:	
	movf	(_g_scanIndex),w	;volatile
	fcall	_ChargeProcess_Slot
	line	529
	
l8376:	
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	533
	
l8378:	
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u13401
	goto	u13400
u13401:
	goto	l8386
u13400:
	line	535
	
l8380:	
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	536
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	537
	
l8382:	
	fcall	_Do_NtcRead
	line	538
	
l8384:	
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	543
	
l8386:	
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u13411
	goto	u13410
u13411:
	goto	l446
u13410:
	line	545
	
l8388:	
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	546
	
l8390:	
	fcall	_Print_SystemStatus
	line	547
	fcall	_Print_NtcTemp
	goto	l446
	global	start
	ljmp	start
	opt stack 0
	line	551
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 62 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   29[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	62
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"main.c"
	line	62
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	67
	
l6954:	
# 67 "main.c"
nop ;# 
	line	68
# 68 "main.c"
clrwdt ;# 
psect	text1
	line	69
	
l6956:	
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	73
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	74
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	75
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l6958:	
	clrf	(262)^0100h	;volatile
	line	77
	
l6960:	
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l6962:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	80
	
l6964:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l6966:	
	clrf	(135)^080h	;volatile
	line	81
	
l6968:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l6970:	
	clrf	(7)	;volatile
	line	82
	
l6972:	
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	83
	
l6974:	
	clrf	(277)^0100h	;volatile
	line	86
	
l6976:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l6978:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	89
	
l6980:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	90
	
l6982:	
	clrf	(406)^0180h	;volatile
	line	97
	
l6984:	
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	98
	
l6986:	
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	99
	
l6988:	
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	100
	
l6990:	
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	103
	
l6992:	
	fcall	_AD_Init
	line	107
	
l6994:	
	fcall	_uart_init
	line	115
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	116
	
l6996:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	117
	
l6998:	
	bcf	(90/8),(90)&7	;volatile
	line	118
	
l7000:	
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	122
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	123
	clrf	(_g_pwmCounter)	;volatile
	line	124
	
l7002:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	125
	
l7004:	
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	126
	
l7006:	
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	127
	
l7008:	
	bcf	(55/8),(55)&7	;volatile
	line	130
	clrf	(System_Init@i)
	line	132
	
l7014:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	133
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	134
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	135
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	136
	
l7016:	
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	137
	
l7018:	
	movf	(System_Init@i),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	130
	
l7020:	
	incf	(System_Init@i),f
	
l7022:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u10691
	goto	u10690
u10691:
	goto	l7014
u10690:
	line	141
	
l337:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"uart_dbg.c"
	line	21
global __ptext2
__ptext2:	;psect for function _uart_init
psect	text2
	file	"uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_init: []
	line	23
	
l3268:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l482:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	23
global __ptext3
__ptext3:	;psect for function _AD_Init
psect	text3
	file	"adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l3262:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
	clrf	(406)^0180h	;volatile
	line	27
	
l3264:	
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l3266:	
	clrf	(150)^080h	;volatile
	line	29
	
l459:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 373 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  t               1   50[BANK1 ] unsigned char 
;;  bat_mv_long     4   46[BANK1 ] unsigned long 
;;  vx_mv           4   42[BANK1 ] unsigned long 
;;  v               2   40[BANK1 ] unsigned int 
;;  s               1   37[BANK1 ] unsigned char 
;;  pt              4   33[BANK1 ] unsigned long 
;;  vcc_mv          2   51[BANK1 ] unsigned int 
;;  i               1   53[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      25       0       0
;;      Temps:          0       0       8       0       0
;;      Totals:         0       0      33       0       0
;;Total ram usage:       33 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	373
global __ptext4
__ptext4:	;psect for function _Print_SystemStatus
psect	text4
	file	"main.c"
	line	373
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	378
	
l7310:	
	movlw	low(((STR_4)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	379
	movlw	low(((STR_5)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	380
	movlw	low(((STR_6)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	383
	
l7312:	
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	384
	
l7314:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u11311
	goto	u11310
u11311:
	goto	l7320
u11310:
	line	386
	
l7316:	
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt)^080h

	line	387
	
l7318:	
	movf	(Print_SystemStatus@pt+1)^080h,w
	movwf	(Print_SystemStatus@vcc_mv+1)^080h
	movf	(Print_SystemStatus@pt)^080h,w
	movwf	(Print_SystemStatus@vcc_mv)^080h
	line	388
	goto	l410
	line	390
	
l7320:	
	movlw	088h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vcc_mv)^080h
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv)^080h)+1
	
l410:	
	line	392
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	line	394
	
l7322:	
	movlw	low(((STR_7)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	395
	
l7324:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	396
	
l7326:	
	movlw	low(((STR_8)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	397
	
l7328:	
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(_Print_SystemStatus$727+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(_Print_SystemStatus$727)^080h
	
l7330:	
	movf	(_Print_SystemStatus$727+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$727)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	398
	
l7332:	
	movlw	low(((STR_9)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	399
	
l7334:	
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@divisor)^080h
	clrf	(___lwmod@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend)^080h
	fcall	___lwmod
	movf	(1+(?___lwmod))^080h,w
	movwf	(_Print_SystemStatus$728+1)^080h
	movf	(0+(?___lwmod))^080h,w
	movwf	(_Print_SystemStatus$728)^080h
	
l7336:	
	movf	(_Print_SystemStatus$728+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$728)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	400
	
l7338:	
	movlw	low(((STR_10)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	401
	
l7340:	
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u11321
	goto	u11320
u11321:
	goto	l7344
u11320:
	
l7342:	
	movf	(_g_impCheckSlot)^080h,w
	movwf	(_Print_SystemStatus$272)^080h
	clrf	(_Print_SystemStatus$272+1)^080h
	goto	l7346
	
l7344:	
	movlw	0FFh
	movwf	(_Print_SystemStatus$272)^080h
	clrf	(_Print_SystemStatus$272+1)^080h
	
l7346:	
	movf	(_Print_SystemStatus$272+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$272)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	402
	
l7348:	
	movlw	low(((STR_11)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	409
	
l7350:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(Print_SystemStatus@i)^080h
	line	415
	
l7356:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@v)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)^080h
	line	416
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@s)^080h
	line	418
	
l7358:	
	movlw	low(042h)
	fcall	_uart_send_char
	line	419
	
l7360:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	incf	(uart_send_number@num)^080h,f
	skipnz
	incf	(uart_send_number@num+1)^080h,f
	fcall	_uart_send_number
	line	420
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	421
	
l7362:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(Print_SystemStatus@v)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	427
	
l7364:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Print_SystemStatus@v+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(___lmul@multiplicand)^080h
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv)^080h

	
l7366:	
	movlw	0Ch
u11335:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3)^080h,f
	rrf	(Print_SystemStatus@vx_mv+2)^080h,f
	rrf	(Print_SystemStatus@vx_mv+1)^080h,f
	rrf	(Print_SystemStatus@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u11335

	line	428
	
l7368:	
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	clrf	((??_Print_SystemStatus+0)^080h+0+2)
	clrf	((??_Print_SystemStatus+0)^080h+0+3)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+4)^080h+0)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	(Print_SystemStatus@vx_mv)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+0,f
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1)^080h,w
	goto	u11340
	goto	u11341
u11340:
	addwf	(??_Print_SystemStatus+4)^080h+1,f
u11341:
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2)^080h,w
	goto	u11342
	goto	u11343
u11342:
	addwf	(??_Print_SystemStatus+4)^080h+2,f
u11343:
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	subwf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u11355
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	subwf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u11355
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	subwf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u11355
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	subwf	0+(??_Print_SystemStatus+4)^080h+0,w
u11355:
	skipc
	goto	u11351
	goto	u11350
u11351:
	goto	l7372
u11350:
	line	430
	
l7370:	
	movlw	low(((STR_12)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	431
	goto	l7382
	line	434
	
l7372:	
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(Print_SystemStatus@vx_mv)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long)^080h

	line	435
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(Print_SystemStatus@bat_mv_long+3)^080h,w
	subwf	(3+(?___lmul))^080h,w
	skipz
	goto	u11365
	movf	(Print_SystemStatus@bat_mv_long+2)^080h,w
	subwf	(2+(?___lmul))^080h,w
	skipz
	goto	u11365
	movf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	subwf	(1+(?___lmul))^080h,w
	skipz
	goto	u11365
	movf	(Print_SystemStatus@bat_mv_long)^080h,w
	subwf	(0+(?___lmul))^080h,w
u11365:
	skipnc
	goto	u11361
	goto	u11360
u11361:
	goto	l7382
u11360:
	line	437
	
l7374:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+3)
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+1)^080h
	movlw	032h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(Print_SystemStatus@bat_mv_long)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+0)
	movlw	0
	skipnc
	movlw	1
	addwf	(1+(?___lmul))^080h,w
	clrf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	addwf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	movf	(2+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+2),w
	clrf	((??_Print_SystemStatus+4)^080h+0+3)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	addwf	(Print_SystemStatus@bat_mv_long+2)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	movf	(3+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+3),w
	addwf	(Print_SystemStatus@bat_mv_long+3)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	0+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+0,f
	movf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	1+(??_Print_SystemStatus+4)^080h+0,w
	goto	u11370
	goto	u11371
u11370:
	addwf	(??_Print_SystemStatus+0)^080h+1,f
u11371:
	movf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	2+(??_Print_SystemStatus+4)^080h+0,w
	goto	u11372
	goto	u11373
u11372:
	addwf	(??_Print_SystemStatus+0)^080h+2,f
u11373:
	movf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incf	3+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long)^080h

	line	438
	
l7376:	
	movlw	low(((STR_13)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	439
	
l7378:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(Print_SystemStatus@bat_mv_long)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	440
	
l7380:	
	movlw	low(((STR_14)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	447
	
l7382:	
	movlw	low(020h)
	fcall	_uart_send_char
	line	448
	goto	l7424
	line	450
	
l7384:	
	movlw	low(((STR_15)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7426
	line	451
	
l7386:	
	movlw	low(((STR_16)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7426
	line	452
	
l7388:	
	movlw	low(((STR_17)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7426
	line	453
	
l7390:	
	movlw	low(((STR_18)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7426
	line	454
	
l7392:	
	movlw	low(((STR_19)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7426
	line	455
	
l7394:	
	movlw	low(((STR_20)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7426
	line	456
	
l7396:	
	movlw	low(((STR_21)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7426
	line	459
	
l7398:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@t)^080h
	line	460
	
l7400:	
		movlw	2
	xorwf	((Print_SystemStatus@t)^080h),w
	btfsc	status,2
	goto	u11381
	goto	u11380
u11381:
	goto	l7404
u11380:
	
l7402:	
		movlw	3
	xorwf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u11391
	goto	u11390
u11391:
	goto	l7406
u11390:
	line	461
	
l7404:	
	movlw	low(((STR_22)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7426
	line	462
	
l7406:	
		decf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u11401
	goto	u11400
u11401:
	goto	l7410
u11400:
	line	463
	
l7408:	
	movlw	low(((STR_23)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7426
	line	464
	
l7410:	
		movlw	6
	xorwf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u11411
	goto	u11410
u11411:
	goto	l7414
u11410:
	line	465
	
l7412:	
	movlw	low(((STR_24)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7426
	line	467
	
l7414:	
	movlw	low(((STR_25)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7426
	line	470
	
l7416:	
	movlw	low(((STR_26)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7426
	line	471
	
l7418:	
	movlw	low(((STR_27)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7426
	line	472
	
l7420:	
	movlw	low(((STR_28)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7426
	line	448
	
l7424:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@s)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l7384
	xorlw	1^0	; case 1
	skipnz
	goto	l7386
	xorlw	2^1	; case 2
	skipnz
	goto	l7388
	xorlw	3^2	; case 3
	skipnz
	goto	l7390
	xorlw	4^3	; case 4
	skipnz
	goto	l7392
	xorlw	5^4	; case 5
	skipnz
	goto	l7394
	xorlw	6^5	; case 6
	skipnz
	goto	l7396
	xorlw	7^6	; case 7
	skipnz
	goto	l7398
	xorlw	8^7	; case 8
	skipnz
	goto	l7416
	xorlw	9^8	; case 9
	skipnz
	goto	l7418
	goto	l7420
	opt asmopt_pop

	line	476
	
l7426:	
	movlw	low(((STR_29)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	477
	
l7428:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	478
	
l7430:	
	movlw	low(((STR_30)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	479
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	482
	
l7432:	
	movlw	low(((STR_31)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	409
	
l7434:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(Print_SystemStatus@i)^080h,f
	
l7436:	
	movlw	low(0Ch)
	subwf	(Print_SystemStatus@i)^080h,w
	skipc
	goto	u11421
	goto	u11420
u11421:
	goto	l7356
u11420:
	line	485
	
l7438:	
	movlw	low(((STR_32)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	486
	
l441:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 353 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	353
global __ptext5
__ptext5:	;psect for function _Print_NtcTemp
psect	text5
	file	"main.c"
	line	353
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	355
	
l7298:	
	movlw	low(((STR_1)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	356
	
l7300:	
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(_Print_NtcTemp$725+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(_Print_NtcTemp$725)^080h
	
l7302:	
	movf	(_Print_NtcTemp$725+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$725)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	357
	
l7304:	
	movlw	low(((STR_2)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	358
	
l7306:	
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@divisor)^080h
	clrf	(___lwmod@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend)^080h
	fcall	___lwmod
	movf	(1+(?___lwmod))^080h,w
	movwf	(_Print_NtcTemp$726+1)^080h
	movf	(0+(?___lwmod))^080h,w
	movwf	(_Print_NtcTemp$726)^080h
	movf	(_Print_NtcTemp$726+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$726)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	359
	
l7308:	
	movlw	low(((STR_3)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	360
	
l406:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2    0[BANK1 ] PTR const unsigned char 
;;		 -> STR_34(10), STR_33(21), STR_32(3), STR_31(3), 
;;		 -> STR_30(5), STR_29(5), STR_28(6), STR_27(6), 
;;		 -> STR_26(6), STR_25(6), STR_24(16), STR_23(13), 
;;		 -> STR_22(15), STR_21(7), STR_20(5), STR_19(5), 
;;		 -> STR_18(6), STR_17(6), STR_16(6), STR_15(7), 
;;		 -> STR_14(4), STR_13(6), STR_12(6), STR_11(3), 
;;		 -> STR_10(12), STR_9(2), STR_8(6), STR_7(5), 
;;		 -> STR_6(6), STR_5(5), STR_4(25), STR_3(4), 
;;		 -> STR_2(2), STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	file	"uart_dbg.c"
	line	61
global __ptext6
__ptext6:	;psect for function _uart_send_string
psect	text6
	file	"uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l6904:	
	goto	l6910
	line	65
	
l6906:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	btemp+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str)^080h,w
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	fcall	stringtab
	fcall	_uart_send_char
	
l6908:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(uart_send_string@str)^080h,f
	skipnz
	incf	(uart_send_string@str+1)^080h,f
	line	66
# 66 "uart_dbg.c"
clrwdt ;# 
psect	text6
	line	63
	
l6910:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(uart_send_string@str+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	btemp+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str)^080h,w
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u10631
	goto	u10630
u10631:
	goto	l6906
u10630:
	line	68
	
l495:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2    4[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    6[BANK1 ] unsigned char [6]
;;  j               1   13[BANK1 ] unsigned char 
;;  i               1   12[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      10       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext7
__ptext7:	;psect for function _uart_send_number
psect	text7
	file	"uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 2
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l6912:	
	clrf	(uart_send_number@i)^080h
	line	84
	
l6914:	
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u10641
	goto	u10640
u10641:
	goto	l6926
u10640:
	line	86
	
l6916:	
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l499
	line	93
	
l6920:	
	movf	(uart_send_number@i)^080h,w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)^080h
	clrf	(___lwmod@divisor+1)^080h
	movf	(uart_send_number@num+1)^080h,w
	movwf	(___lwmod@dividend+1)^080h
	movf	(uart_send_number@num)^080h,w
	movwf	(___lwmod@dividend)^080h
	fcall	___lwmod
	movf	(0+(?___lwmod))^080h,w
	addlw	030h
	bcf	status, 7	;select IRP bank1
	movwf	indf
	
l6922:	
	incf	(uart_send_number@i)^080h,f
	line	94
	
l6924:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(uart_send_number@num+1)^080h,w
	movwf	(___lwdiv@dividend+1)^080h
	movf	(uart_send_number@num)^080h,w
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(uart_send_number@num)^080h
	line	91
	
l6926:	
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u10651
	goto	u10650
u10651:
	goto	l6920
u10650:
	line	98
	
l6928:	
	movf	(uart_send_number@i)^080h,w
	movwf	(uart_send_number@j)^080h
	
l6930:	
	movf	((uart_send_number@j)^080h),w
	btfss	status,2
	goto	u10661
	goto	u10660
u10661:
	goto	l6934
u10660:
	goto	l499
	line	99
	
l6934:	
	movf	(uart_send_number@j)^080h,w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l6936:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decf	(uart_send_number@j)^080h,f
	goto	l6930
	line	100
	
l499:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1   27[BANK0 ] unsigned char 
;;  i               1   28[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext8
__ptext8:	;psect for function _uart_send_char
psect	text8
	file	"uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_char: [wreg+status,2+status,0]
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_char@c)
	line	38
	
l6804:	
	bcf	(95/8),(95)&7	;volatile
	line	39
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l6806:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u13437:
decfsz	(??_uart_send_char+0)+0,f
	goto	u13437
	nop2
opt asmopt_pop

	line	41
	
l6808:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(uart_send_char@i)
	line	42
	
l485:	
	line	43
	btfss	(uart_send_char@c),(0)&7
	goto	u10441
	goto	u10440
u10441:
	goto	l487
u10440:
	line	44
	
l6814:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l6816
	line	45
	
l487:	
	line	46
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l6816:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u13447:
decfsz	(??_uart_send_char+0)+0,f
	goto	u13447
	nop2
opt asmopt_pop

	line	48
	
l6818:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rrf	(uart_send_char@c),f
	line	41
	
l6820:	
	incf	(uart_send_char@i),f
	
l6822:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u10451
	goto	u10450
u10451:
	goto	l485
u10450:
	
l486:	
	line	50
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l6824:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u13457:
decfsz	(??_uart_send_char+0)+0,f
	goto	u13457
	nop2
opt asmopt_pop

	line	52
	
l6826:	
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l489:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK1 ] unsigned int 
;;  dividend        2    2[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1   26[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK1 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       4       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       4       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext9
__ptext9:	;psect for function ___lwmod
psect	text9
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l5144:	
	movf	((___lwmod@divisor)^080h),w
iorwf	((___lwmod@divisor+1)^080h),w
	btfsc	status,2
	goto	u7281
	goto	u7280
u7281:
	goto	l5160
u7280:
	line	14
	
l5146:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l5150
	line	16
	
l5148:	
	clrc
	rlf	(___lwmod@divisor)^080h,f
	rlf	(___lwmod@divisor+1)^080h,f
	line	17
	bcf	status, 5	;RP0=0, select bank0
	incf	(___lwmod@counter),f
	line	15
	
l5150:	
	bsf	status, 5	;RP0=1, select bank1
	btfss	(___lwmod@divisor+1)^080h,(15)&7
	goto	u7291
	goto	u7290
u7291:
	goto	l5148
u7290:
	line	20
	
l5152:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lwmod@divisor+1)^080h,w
	subwf	(___lwmod@dividend+1)^080h,w
	skipz
	goto	u7305
	movf	(___lwmod@divisor)^080h,w
	subwf	(___lwmod@dividend)^080h,w
u7305:
	skipc
	goto	u7301
	goto	u7300
u7301:
	goto	l5156
u7300:
	line	21
	
l5154:	
	movf	(___lwmod@divisor)^080h,w
	subwf	(___lwmod@dividend)^080h,f
	movf	(___lwmod@divisor+1)^080h,w
	skipc
	decf	(___lwmod@dividend+1)^080h,f
	subwf	(___lwmod@dividend+1)^080h,f
	line	22
	
l5156:	
	clrc
	rrf	(___lwmod@divisor+1)^080h,f
	rrf	(___lwmod@divisor)^080h,f
	line	23
	
l5158:	
	bcf	status, 5	;RP0=0, select bank0
	decfsz	(___lwmod@counter),f
	goto	u7311
	goto	u7310
u7311:
	goto	l5152
u7310:
	line	25
	
l5160:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lwmod@dividend+1)^080h,w
	movwf	(?___lwmod+1)^080h
	movf	(___lwmod@dividend)^080h,w
	movwf	(?___lwmod)^080h
	line	26
	
l1231:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	_Do_NtcRead

;; *************** function _Do_NtcRead *****************
;; Defined at:
;;		line 343 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Read_Temperature
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	343
global __ptext10
__ptext10:	;psect for function _Do_NtcRead
psect	text10
	file	"main.c"
	line	343
	global	__size_of_Do_NtcRead
	__size_of_Do_NtcRead	equ	__end_of_Do_NtcRead-_Do_NtcRead
	
_Do_NtcRead:	
;incstack = 0
	opt	stack 2
; Regs used in _Do_NtcRead: [wreg+status,2+status,0+pclath+cstack]
	line	345
	
l7296:	
	fcall	_Read_Temperature
	line	346
	
l403:	
	return
	opt stack 0
GLOBAL	__end_of_Do_NtcRead
	__end_of_Do_NtcRead:
	signat	_Do_NtcRead,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 30 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   25[BANK1 ] unsigned long 
;;  temp_x10        2   31[BANK1 ] unsigned int 
;;  ntcVal          2   29[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   62[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Do_NtcRead
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	30
global __ptext11
__ptext11:	;psect for function _Read_Temperature
psect	text11
	file	"charge_mgr.c"
	line	30
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 2
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	35
	
l6866:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	36
	
l6868:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u10531
	goto	u10530
u10531:
	goto	l6872
u10530:
	goto	l532
	line	39
	
l6872:	
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal)^080h
	line	40
	movlw	0
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u10541
	goto	u10540
u10541:
	goto	l532
u10540:
	
l6874:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u10551
	goto	u10550
u10551:
	goto	l6876
u10550:
	goto	l532
	line	45
	
l6876:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	010h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0
	movwf	(___lldiv@divisor)^080h

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0)
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0+1)
	clrf	((??_Read_Temperature+0)^080h+0+2)
	clrf	((??_Read_Temperature+0)^080h+0+3)
	movf	0+(??_Read_Temperature+0)^080h+0,w
	subwf	(___lldiv@divisor)^080h,f
	movf	1+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)^080h+0,w
	goto	u10565
	goto	u10566
u10565:
	subwf	(___lldiv@divisor+1)^080h,f
u10566:
	movf	2+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)^080h+0,w
	goto	u10567
	goto	u10568
u10567:
	subwf	(___lldiv@divisor+2)^080h,f
u10568:
	movf	3+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)^080h+0,w
	goto	u10569
	goto	u10560
u10569:
	subwf	(___lldiv@divisor+3)^080h,f
u10560:

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0
	movwf	(___lmul@multiplicand+2)^080h
	movlw	027h
	movwf	(___lmul@multiplicand+1)^080h
	movlw	010h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt)^080h

	line	46
	
l6878:	
		movf	(Read_Temperature@rt+3)^080h,w
	btfss	status,2
	goto	u10570
	movf	(Read_Temperature@rt+2)^080h,w
	btfss	status,2
	goto	u10570
	movlw	39
	subwf	(Read_Temperature@rt+1)^080h,w
	skipz
	goto	u10573
	movlw	16
	subwf	(Read_Temperature@rt)^080h,w
	skipz
	goto	u10573
u10573:
	btfss	status,0
	goto	u10571
	goto	u10570

u10571:
	goto	l6884
u10570:
	line	47
	
l6880:	
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l6882:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0F0h
	movwf	((??_Read_Temperature+0)^080h+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)^080h+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+3)
	movf	(Read_Temperature@rt)^080h,w
	addwf	(??_Read_Temperature+0)^080h+0,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+1)^080h,w
	goto	u10580
	goto	u10581
u10580:
	addwf	(??_Read_Temperature+0)^080h+1,f
u10581:
	movf	(Read_Temperature@rt+2)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+2)^080h,w
	goto	u10582
	goto	u10583
u10582:
	addwf	(??_Read_Temperature+0)^080h+2,f
u10583:
	movf	(Read_Temperature@rt+3)^080h,w
	skipnc
	incf	(Read_Temperature@rt+3)^080h,w
	addwf	(??_Read_Temperature+0)^080h+3,f
	movf	3+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+3)^080h
	movf	2+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+2)^080h
	movf	1+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+1)^080h
	movf	0+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier)^080h

	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(0+(?___lldiv))^080h,w
	subwf	(Read_Temperature@temp_x10)^080h,f
	movf	(1+(?___lldiv))^080h,w
	skipc
	decf	(Read_Temperature@temp_x10+1)^080h,f
	subwf	(Read_Temperature@temp_x10+1)^080h,f
	goto	l6888
	line	49
	
l6884:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0
	movwf	(___lmul@multiplier+3)^080h
	movlw	0
	movwf	(___lmul@multiplier+2)^080h
	movlw	027h
	movwf	(___lmul@multiplier+1)^080h
	movlw	010h
	movwf	(___lmul@multiplier)^080h

	movf	(Read_Temperature@rt)^080h,w
	subwf	(___lmul@multiplier)^080h,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+1)^080h,w
	subwf	(___lmul@multiplier+1)^080h,f
	movf	(Read_Temperature@rt+2)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+2)^080h,w
	subwf	(___lmul@multiplier+2)^080h,f
	movf	(Read_Temperature@rt+3)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+3)^080h,w
	subwf	(___lmul@multiplier+3)^080h,f
	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10)^080h
	
l6886:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10)^080h,f
	skipnc
	incf	(Read_Temperature@temp_x10+1)^080h,f
	line	50
	
l6888:	
	movlw	0
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipnc
	goto	u10591
	goto	u10590
u10591:
	goto	l538
u10590:
	
l6890:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l538:	
	line	51
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipc
	goto	u10601
	goto	u10600
u10601:
	goto	l539
u10600:
	
l6892:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)^080h
	movlw	02h
	movwf	((Read_Temperature@temp_x10)^080h)+1
	
l539:	
	line	54
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature)
	line	55
	
l6894:	
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(Read_Temperature@temp_x10+1)^080h,w
	movwf	(___lwdiv@dividend+1)^080h
	movf	(Read_Temperature@temp_x10)^080h,w
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv))^080h,w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv))^080h,w
	skipc
	goto	u10611
	goto	u10610
u10611:
	goto	l6898
u10610:
	line	56
	
l6896:	
	clrf	(_g_tempProtect)
	incf	(_g_tempProtect),f
	goto	l532
	line	57
	
l6898:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(Read_Temperature@temp_x10+1)^080h,w
	movwf	(___lwdiv@dividend+1)^080h
	movf	(Read_Temperature@temp_x10)^080h,w
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv))^080h,w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv))^080h,w
	skipnc
	goto	u10621
	goto	u10620
u10621:
	goto	l532
u10620:
	line	58
	
l6900:	
	clrf	(_g_tempProtect)
	line	61
	
l532:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	_Do_AdcSample

;; *************** function _Do_AdcSample *****************
;; Defined at:
;;		line 271 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  st              1   16[BANK1 ] unsigned char 
;;  dly             1   15[BANK1 ] unsigned char 
;;  ty              1   14[BANK1 ] unsigned char 
;;  ch              1   13[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       1       4       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	271
global __ptext12
__ptext12:	;psect for function _Do_AdcSample
psect	text12
	file	"main.c"
	line	271
	global	__size_of_Do_AdcSample
	__size_of_Do_AdcSample	equ	__end_of_Do_AdcSample-_Do_AdcSample
	
_Do_AdcSample:	
;incstack = 0
	opt	stack 3
; Regs used in _Do_AdcSample: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	273
	
l7232:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_scanIndex),w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@ch)^080h
	line	274
	
l7234:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@ty)^080h
	line	275
	
l7236:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@st)^080h
	line	296
	
l7238:	
		movlw	6
	xorwf	((Do_AdcSample@ty)^080h),w
	btfss	status,2
	goto	u11141
	goto	u11140
u11141:
	goto	l7248
u11140:
	
l7240:	
		movlw	2
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11151
	goto	u11150
u11151:
	goto	l7254
u11150:
	
l7242:	
		movlw	3
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11161
	goto	u11160
u11161:
	goto	l7254
u11160:
	
l7244:	
		movlw	4
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11171
	goto	u11170
u11171:
	goto	l7254
u11170:
	
l7246:	
		movlw	5
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11181
	goto	u11180
u11181:
	goto	l7254
u11180:
	
l7248:	
		decf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11191
	goto	u11190
u11191:
	goto	l7254
u11190:
	
l7250:	
		movlw	8
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11201
	goto	u11200
u11201:
	goto	l7254
u11200:
	
l7252:	
		movlw	9
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u11211
	goto	u11210
u11211:
	goto	l7272
u11210:
	line	300
	
l7254:	
		decf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11221
	goto	u11220
u11221:
	goto	l7260
u11220:
	
l7256:	
		movlw	8
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11231
	goto	u11230
u11231:
	goto	l7260
u11230:
	
l7258:	
		movlw	9
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u11241
	goto	u11240
u11241:
	goto	l7272
u11240:
	line	302
	
l7260:	
	clrf	(Do_AdcSample@dly)^080h
	line	303
	
l7266:	
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Do_AdcSample+0)+0),f
	u13467:
decfsz	(??_Do_AdcSample+0)+0,f
	goto	u13467
	nop
opt asmopt_pop

	line	302
	
l7268:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(Do_AdcSample@dly)^080h,f
	
l7270:	
	movlw	low(014h)
	subwf	(Do_AdcSample@dly)^080h,w
	skipc
	goto	u11251
	goto	u11250
u11251:
	goto	l7266
u11250:
	goto	l7276
	line	307
	
l7272:	
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Do_AdcSample+0)+0),f
	u13477:
decfsz	(??_Do_AdcSample+0)+0,f
	goto	u13477
	nop
opt asmopt_pop

	line	315
	
l7276:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@adldo)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Do_AdcSample@ch)^080h,w
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	317
	
l7278:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u11261
	goto	u11260
u11261:
	goto	l7292
u11260:
	line	322
	
l7280:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	((Do_AdcSample@ty)^080h),w
	btfss	status,2
	goto	u11271
	goto	u11270
u11271:
	goto	l7290
u11270:
	
l7282:	
		movlw	4
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11281
	goto	u11280
u11281:
	goto	l7286
u11280:
	
l7284:	
		movlw	5
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u11291
	goto	u11290
u11291:
	goto	l7290
u11290:
	
l7286:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_adresult+1),w	;volatile
	movlw	096h
	skipnz
	subwf	(_adresult),w	;volatile
	skipc
	goto	u11301
	goto	u11300
u11301:
	goto	l7290
u11300:
	goto	l7294
	line	328
	
l7290:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	movf	(_adresult),w	;volatile
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_adresult+1),w	;volatile
	movwf	indf
	goto	l7294
	line	332
	
l7292:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	334
	
l7294:	
	movlw	low(01h)
	movwf	(_g_scanPhase)	;volatile
	line	335
	
l400:	
	return
	opt stack 0
GLOBAL	__end_of_Do_AdcSample
	__end_of_Do_AdcSample:
	signat	_Do_AdcSample,89
	global	_ChargeProcess_Slot

;; *************** function _ChargeProcess_Slot *****************
;; Defined at:
;;		line 139 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   15[BANK3 ] unsigned char 
;;  bat_mv_long     4   32[BANK1 ] unsigned long 
;;  vx_mv           4   28[BANK1 ] unsigned long 
;;  bat_mv          2    2[BANK3 ] unsigned int 
;;  bat_mv_long     4   48[BANK1 ] unsigned long 
;;  vx_mv           4   44[BANK1 ] unsigned long 
;;  bat_mv          2    6[BANK3 ] unsigned int 
;;  bat_mv_long     4   40[BANK1 ] unsigned long 
;;  vx_mv           4   36[BANK1 ] unsigned long 
;;  bat_mv          2    4[BANK3 ] unsigned int 
;;  v_ref           2    0[BANK3 ] unsigned int 
;;  v_init          2   26[BANK1 ] unsigned int 
;;  v               2   13[BANK3 ] unsigned int 
;;  ct              2   11[BANK3 ] unsigned int 
;;  tick            2    0        unsigned int 
;;  ty              1   10[BANK3 ] unsigned char 
;;  st              1   54[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/B00
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      29      16       0
;;      Temps:          0       0       5       0       0
;;      Totals:         0       0      34      16       0
;;Total ram usage:       50 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		_Detect_BatteryType
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___wmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	139
global __ptext13
__ptext13:	;psect for function _ChargeProcess_Slot
psect	text13
	file	"charge_mgr.c"
	line	139
	global	__size_of_ChargeProcess_Slot
	__size_of_ChargeProcess_Slot	equ	__end_of_ChargeProcess_Slot-_ChargeProcess_Slot
	
_ChargeProcess_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _ChargeProcess_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@idx)^0180h
	line	143
	
l7440:	
	line	145
	
l7442:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l7444:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	
l7446:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@v)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v+1)^0180h
	
l7448:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ct)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@ct+1)^0180h
	goto	l8240
	line	154
	
l7450:	
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11431
	goto	u11430
u11431:
	goto	l7456
u11430:
	line	156
	
l7452:	
	movlw	01h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	02Ch
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u11441
	goto	u11440
u11441:
	goto	l7456
u11440:
	line	158
	
l7454:	
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	159
	goto	l8242
	line	162
	
l7456:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	163
	
l7458:	
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@st)^080h
	incf	(ChargeProcess_Slot@st)^080h,f
	line	164
	
l7460:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	165
	
l7462:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11454
u11455:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11454:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11455
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	168
	
l7464:	
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11461
	goto	u11460
u11461:
	goto	l7468
u11460:
	line	169
	
l7466:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	goto	l8242
	line	171
	
l7468:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l8242
	line	175
	
l7470:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	178
	
l7472:	
		decf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u11471
	goto	u11470
u11471:
	goto	l7478
u11470:
	line	180
	
l7474:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	181
	
l7476:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11484
u11485:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11484:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11485
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	184
	
l7478:	
	movlw	0
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	01Eh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u11491
	goto	u11490
u11491:
	goto	l7492
u11490:
	line	191
	
l7480:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movlw	09h
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0C5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u11501
	goto	u11500
u11501:
	goto	l8242
u11500:
	
l7482:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(03E8h)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(03E8h)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	skipz
	goto	u11515
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
u11515:
	skipnc
	goto	u11511
	goto	u11510
u11511:
	goto	l8242
u11510:
	
l7484:	
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11521
	goto	u11520
u11521:
	goto	l8242
u11520:
	line	193
	
l7486:	
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	194
	movlw	low(07h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	195
	
l7488:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11534
u11535:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11534:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11535
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	196
	
l7490:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	197
	goto	l8242
	line	208
	
l7492:	
		movlw	30
	xorwf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u11541
	goto	u11540
u11541:
	goto	l7500
u11540:
	line	210
	
l7494:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	211
	
l7496:	
	movlw	0Bh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11551
	goto	u11550
u11551:
	goto	l8242
u11550:
	line	212
	
l7498:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11564
u11565:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11564:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11565
	
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_capFlag+1)^080h,f
	goto	l8242
	line	215
	
l7500:	
	movlw	0Bh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11571
	goto	u11570
u11571:
	goto	l7562
u11570:
	
l7502:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11581
	goto	u11580
u11581:
	goto	l7562
u11580:
	line	227
	
l7504:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11594
u11595:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11594:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11595
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfss	status,2
	goto	u11601
	goto	u11600
u11601:
	goto	l7518
u11600:
	
l7506:	
		movlw	5
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11611
	goto	u11610
u11611:
	goto	l7518
u11610:
	
l7508:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0ADh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11621
	goto	u11620
u11621:
	goto	l7518
u11620:
	line	229
	
l7510:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	230
	
l7512:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	231
	
l7514:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7490
	line	243
	
l7518:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@v_init)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_init+1)^080h
	line	245
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipc
	goto	u11631
	goto	u11630
u11631:
	goto	l7548
u11630:
	line	250
	
l7520:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11644
u11645:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11644:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11645
	
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_highVFlag+1)^080h,f
	line	252
	
l7522:	
	movlw	0Bh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11651
	goto	u11650
u11651:
	goto	l7530
u11650:
	line	255
	
l7524:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11664
u11665:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11664:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11665
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	256
	
l7526:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	257
	
l7528:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11674
u11675:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11674:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11675
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	258
	goto	l7574
	line	259
	
l7530:	
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	082h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u11681
	goto	u11680
u11681:
	goto	l7542
u11680:
	line	265
	
l7532:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11694
u11695:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11694:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11695
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u11701
	goto	u11700
u11701:
	goto	l7466
u11700:
	
l7534:	
	movlw	0
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	037h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11711
	goto	u11710
u11711:
	goto	l7466
u11710:
	line	278
	
l7542:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11724
u11725:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11724:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11725
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	279
	
l7544:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	280
	
l7546:	
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	281
	goto	l7604
	line	287
	
l7548:	
	movf	(ChargeProcess_Slot@v)^0180h,w
	addlw	low(032h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(ChargeProcess_Slot@v_init+1)^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11735
	movf	(ChargeProcess_Slot@v_init)^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11735:
	skipnc
	goto	u11731
	goto	u11730
u11731:
	goto	l7552
u11730:
	line	290
	
l7550:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	291
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	292
	goto	l581
	line	296
	
l7552:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	297
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	298
	
l581:	
	line	299
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u11741
	goto	u11740
u11741:
	goto	l7556
u11740:
	goto	l8242
	line	302
	
l7556:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11754
u11755:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11754:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11755
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u11761
	goto	u11760
u11761:
	goto	l7560
u11760:
	goto	l8242
	line	304
	
l7560:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7574
	line	307
	
l7562:	
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	082h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u11771
	goto	u11770
u11771:
	goto	l7574
u11770:
	
l7564:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11781
	goto	u11780
u11781:
	goto	l7574
u11780:
	line	309
	
l7566:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_ref)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_ref+1)^0180h
	line	310
	
l7568:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v_ref+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v_ref)^0180h,w
	skipnc
	goto	u11791
	goto	u11790
u11791:
	goto	l7574
u11790:
	
l7570:	
	movf	(ChargeProcess_Slot@v)^0180h,w
	addlw	low(032h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_ref+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11805
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_ref)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11805:
	skipnc
	goto	u11801
	goto	u11800
u11801:
	goto	l7574
u11800:
	goto	l7466
	line	320
	
l7574:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11814
u11815:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11814:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11815
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u11821
	goto	u11820
u11821:
	goto	l7582
u11820:
	line	322
	
l7576:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11834
u11835:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11834:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11835
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	323
	
l7578:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	324
	
l7580:	
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	325
	goto	l588
	line	328
	
l7582:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Detect_BatteryType@voltage+1)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	336
	
l7584:	
	movf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11841
	goto	u11840
u11841:
	goto	l588
u11840:
	
l7586:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11851
	goto	u11850
u11851:
	goto	l588
u11850:
	
l7588:	
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	082h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11861
	goto	u11860
u11861:
	goto	l588
u11860:
	goto	l7580
	line	338
	
l588:	
	line	342
	movlw	01h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0F4h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11871
	goto	u11870
u11871:
	goto	l7596
u11870:
	line	344
	
l7592:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	345
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u11881
	goto	u11880
u11881:
	goto	l7604
u11880:
	goto	l8242
	line	349
	
l7596:	
		movlw	5
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11891
	goto	u11890
u11891:
	goto	l7604
u11890:
	
l7598:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11901
	goto	u11900
u11901:
	goto	l7604
u11900:
	
l7600:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11911
	goto	u11910
u11911:
	goto	l7604
u11910:
	line	351
	
l7602:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	355
	
l7604:	
		movlw	5
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11921
	goto	u11920
u11921:
	goto	l7634
u11920:
	line	362
	
l7606:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	363
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11931
	goto	u11930
u11931:
	goto	l7610
u11930:
	goto	l8242
	line	367
	
l7610:	
	bcf	status, 6	;RP1=0, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u11941
	goto	u11940
u11941:
	goto	l7616
u11940:
	
l7612:	
	movf	(_g_impCheckSlot)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	xorwf	(ChargeProcess_Slot@idx)^0180h,w
	skipnz
	goto	u11951
	goto	u11950
u11951:
	goto	l7616
u11950:
	goto	l8242
	line	369
	
l7616:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	373
	
l7618:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u11961
	goto	u11960
u11961:
	goto	l597
u11960:
	line	374
	
l7620:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(0+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	
l597:	
	line	378
	movlw	064h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(032h)
	movwf	(___lwdiv@dividend)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(_g_impData+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(_g_impData)^080h
	
l7622:	
	movlw	0Ch
	
u11975:
	clrc
	rlf	(_g_impData)^080h,f
	rlf	(_g_impData+1)^080h,f
	addlw	-1
	skipz
	goto	u11975
	
l7624:	
	movlw	(0A000h >> 8)
	addwf	(_g_impData+1)^080h,f
	
l7626:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	iorwf	(_g_impData)^080h,f
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	iorwf	(_g_impData+1)^080h,f
	line	379
	
l7628:	
	movlw	low(08h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	380
	
l7630:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	381
	
l7632:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	383
	
l7634:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11981
	goto	u11980
u11981:
	goto	l7638
u11980:
	
l7636:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11991
	goto	u11990
u11991:
	goto	l7688
u11990:
	line	386
	
l7638:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	387
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12001
	goto	u12000
u12001:
	goto	l7642
u12000:
	goto	l8242
	line	389
	
l7642:	
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv)^080h

	
l7644:	
	movlw	0Ch
u12015:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u12015

	
l7646:	
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long)^080h

	
l7648:	
	movf	(ChargeProcess_Slot@vx_mv+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12021
	addwf	(ChargeProcess_Slot@bat_mv_long+1)^080h,f
u12021:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12022
	addwf	(ChargeProcess_Slot@bat_mv_long+2)^080h,f
u12022:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12023
	addwf	(ChargeProcess_Slot@bat_mv_long+3)^080h,f
u12023:

	
l7650:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	goto	u12030
	goto	u12031
u12030:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u12031:
	movf	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	goto	u12032
	goto	u12033
u12032:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u12033:
	movf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv)^0180h
	
l7652:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u12041
	goto	u12040
u12041:
	goto	l7656
u12040:
	
l7654:	
	movlw	low(02h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7682
	
l7656:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u12051
	goto	u12050
u12051:
	goto	l7660
u12050:
	
l7658:	
	movlw	low(03h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7682
	
l7660:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipc
	goto	u12061
	goto	u12060
u12061:
	goto	l7674
u12060:
	
l7662:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u12071
	goto	u12070
u12071:
	goto	l7666
u12070:
	
l7664:	
	movlw	low(07h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7682
	
l7666:	
	movlw	low(05h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l7668:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	
l7670:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l7672:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7682
	
l7674:	
	movlw	low(04h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l7676:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l7678:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	goto	l7672
	
l7682:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	
l7684:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l7490
	line	391
	
l7688:	
	movf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12081
	goto	u12080
u12081:
	goto	l7698
u12080:
	line	396
	
l7690:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12091
	goto	u12090
u12091:
	goto	l7694
u12090:
	goto	l8242
	line	398
	
l7694:	
	movlw	low(07h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7490
	line	401
	
l7698:	
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12101
	goto	u12100
u12101:
	goto	l7694
u12100:
	
l7700:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12111
	goto	u12110
u12111:
	goto	l8242
u12110:
	goto	l7694
	line	409
	
l7706:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	410
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	05h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u12121
	goto	u12120
u12121:
	goto	l7710
u12120:
	goto	l8242
	line	415
	
l7710:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u12131
	goto	u12130
u12131:
	goto	l7714
u12130:
	line	416
	
l7712:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(0+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	line	421
	
l7714:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12141
	goto	u12140
u12141:
	goto	l7724
u12140:
	
l7716:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	096h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u12151
	goto	u12150
u12151:
	goto	l7724
u12150:
	line	423
	
l7718:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	424
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@st)^080h
	line	425
	
l7720:	
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	line	426
	
l7722:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12164
u12165:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12164:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12165
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	427
	goto	l8242
	line	433
	
l7724:	
	bcf	status, 6	;RP1=0, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)^080h
	clrf	(___wmul@multiplier+1)^080h
	movlw	0Fh
	andwf	(___wmul@multiplier)^080h,f
	clrf	(___wmul@multiplier+1)^080h
	movlw	026h
	addwf	(___wmul@multiplier)^080h,f
	skipnc
	incf	(___wmul@multiplier+1)^080h,f
	movlw	064h
	movwf	(___wmul@multiplicand)^080h
	clrf	(___wmul@multiplicand+1)^080h
	fcall	___wmul
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(012Ch)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(012Ch)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(1+(?___wmul))^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u12175
	movf	(0+(?___wmul))^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u12175:
	skipnc
	goto	u12171
	goto	u12170
u12171:
	goto	l7732
u12170:
	
l7726:	
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12181
	goto	u12180
u12181:
	goto	l7732
u12180:
	line	435
	
l7728:	
	movlw	low(02h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	436
	movlw	low(07h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	437
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	goto	l7722
	line	443
	
l7732:	
	bcf	status, 6	;RP1=0, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)^080h
	clrf	(___wmul@multiplier+1)^080h
	movlw	0Fh
	andwf	(___wmul@multiplier)^080h,f
	clrf	(___wmul@multiplier+1)^080h
	movlw	026h
	addwf	(___wmul@multiplier)^080h,f
	skipnc
	incf	(___wmul@multiplier+1)^080h,f
	movlw	064h
	movwf	(___wmul@multiplicand)^080h
	clrf	(___wmul@multiplicand+1)^080h
	fcall	___wmul
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(0C8h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(1+(?___wmul))^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u12195
	movf	(0+(?___wmul))^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u12195:
	skipnc
	goto	u12191
	goto	u12190
u12191:
	goto	l7736
u12190:
	goto	l7762
	line	448
	
l7736:	
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	skipz
	goto	u12205
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v)^0180h,w
u12205:
	skipnc
	goto	u12201
	goto	u12200
u12201:
	goto	l7746
u12200:
	
l7738:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	03h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0E9h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u12211
	goto	u12210
u12211:
	goto	l7746
u12210:
	line	450
	
l7740:	
	movlw	low(03h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	451
	movlw	low(07h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	452
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	goto	l7488
	line	462
	
l7746:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Dh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0ADh
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u12221
	goto	u12220
u12221:
	goto	l7752
u12220:
	
l7748:	
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)^080h
	clrf	(___wmul@multiplier+1)^080h
	movlw	0Fh
	andwf	(___wmul@multiplier)^080h,f
	clrf	(___wmul@multiplier+1)^080h
	movlw	026h
	addwf	(___wmul@multiplier)^080h,f
	skipnc
	incf	(___wmul@multiplier+1)^080h,f
	movlw	064h
	movwf	(___wmul@multiplicand)^080h
	clrf	(___wmul@multiplicand+1)^080h
	fcall	___wmul
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(0C8h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(1+(?___wmul))^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u12235
	movf	(0+(?___wmul))^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u12235:
	skipc
	goto	u12231
	goto	u12230
u12231:
	goto	l7752
u12230:
	goto	l7756
	line	469
	
l7752:	
	line	475
	
l7756:	
	movlw	low(09h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	476
	
l7758:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	goto	l7722
	line	483
	
l7762:	
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	line	484
	
l7764:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12244
u12245:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12244:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12245
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	485
	
l7766:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	incf	(ChargeProcess_Slot@ty)^0180h,f
	line	486
	
l7768:	
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_367+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_367+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_367+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_367)^080h

	
l7770:	
	movlw	0Ch
u12255:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_367+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_367+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_367+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_367)^080h,f
	addlw	-1
	skipz
	goto	u12255

	
l7772:	
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_368+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_368+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_368+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_368)^080h

	
l7774:	
	movf	(ChargeProcess_Slot@vx_mv_367+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv_367+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv_367+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv_367)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long_368)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12261
	addwf	(ChargeProcess_Slot@bat_mv_long_368+1)^080h,f
u12261:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12262
	addwf	(ChargeProcess_Slot@bat_mv_long_368+2)^080h,f
u12262:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12263
	addwf	(ChargeProcess_Slot@bat_mv_long_368+3)^080h,f
u12263:

	
l7776:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long_368)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long_368+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_368+1)^080h,w
	goto	u12270
	goto	u12271
u12270:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u12271:
	movf	(ChargeProcess_Slot@bat_mv_long_368+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_368+2)^080h,w
	goto	u12272
	goto	u12273
u12272:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u12273:
	movf	(ChargeProcess_Slot@bat_mv_long_368+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_368+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_369+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_369)^0180h
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_369+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_369)^0180h,w
	skipnc
	goto	u12281
	goto	u12280
u12281:
	goto	l7780
u12280:
	goto	l7654
	
l7780:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_369+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_369)^0180h,w
	skipnc
	goto	u12291
	goto	u12290
u12291:
	goto	l7784
u12290:
	goto	l7658
	
l7784:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_369+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_369)^0180h,w
	skipc
	goto	u12301
	goto	u12300
u12301:
	goto	l7674
u12300:
	
l7786:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u12311
	goto	u12310
u12311:
	goto	l7666
u12310:
	goto	l7664
	line	497
	
l7812:	
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	498
	
l7814:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12324
u12325:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12324:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12325
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	499
	
l7816:	
	movlw	low(06h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	500
	
l7818:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(___lmul@multiplier)^080h
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(___lmul@multiplier)^080h
	clrf	2+(___lmul@multiplier)^080h
	clrf	3+(___lmul@multiplier)^080h
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_370+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_370+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_370+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_370)^080h

	
l7820:	
	movlw	0Ch
u12335:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_370+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_370+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_370+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_370)^080h,f
	addlw	-1
	skipz
	goto	u12335

	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_371+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_371+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_371+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_371)^080h

	movf	(ChargeProcess_Slot@vx_mv_370+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv_370+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv_370+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv_370)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long_371)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12341
	addwf	(ChargeProcess_Slot@bat_mv_long_371+1)^080h,f
u12341:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12342
	addwf	(ChargeProcess_Slot@bat_mv_long_371+2)^080h,f
u12342:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12343
	addwf	(ChargeProcess_Slot@bat_mv_long_371+3)^080h,f
u12343:

	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long_371)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long_371+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_371+1)^080h,w
	goto	u12350
	goto	u12351
u12350:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u12351:
	movf	(ChargeProcess_Slot@bat_mv_long_371+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_371+2)^080h,w
	goto	u12352
	goto	u12353
u12352:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u12353:
	movf	(ChargeProcess_Slot@bat_mv_long_371+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_371+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_372+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_372)^0180h
	
l7822:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_372+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_372)^0180h,w
	skipnc
	goto	u12361
	goto	u12360
u12361:
	goto	l7826
u12360:
	goto	l7654
	
l7826:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_372+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_372)^0180h,w
	skipnc
	goto	u12371
	goto	u12370
u12371:
	goto	l7830
u12370:
	goto	l7658
	
l7830:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_372+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_372)^0180h,w
	skipc
	goto	u12381
	goto	u12380
u12381:
	goto	l7844
u12380:
	
l7832:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u12391
	goto	u12390
u12391:
	goto	l7836
u12390:
	goto	l7664
	
l7836:	
	movlw	low(05h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l7838:	
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	goto	l7670
	
l7844:	
	movlw	low(04h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l7846:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l7848:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	goto	l7672
	line	510
	
l7858:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	519
	
l7862:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(0384h)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(0384h)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	skipz
	goto	u12405
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
u12405:
	skipnc
	goto	u12401
	goto	u12400
u12401:
	goto	l7870
u12400:
	line	523
	
l7864:	
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)^080h
	clrf	(___wmul@multiplier+1)^080h
	movlw	0Fh
	andwf	(___wmul@multiplier)^080h,f
	clrf	(___wmul@multiplier+1)^080h
	movlw	026h
	addwf	(___wmul@multiplier)^080h,f
	skipnc
	incf	(___wmul@multiplier+1)^080h,f
	movlw	064h
	movwf	(___wmul@multiplicand)^080h
	clrf	(___wmul@multiplicand+1)^080h
	fcall	___wmul
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(096h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(1+(?___wmul))^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u12415
	movf	(0+(?___wmul))^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u12415:
	skipnc
	goto	u12411
	goto	u12410
u12411:
	goto	l7812
u12410:
	goto	l7762
	line	537
	
l7870:	
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Bh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0B9h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u12421
	goto	u12420
u12421:
	goto	l7878
u12420:
	
l7872:	
	movlw	0Bh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12431
	goto	u12430
u12431:
	goto	l7878
u12430:
	
l7874:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	skipz
	goto	u12445
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v)^0180h,w
u12445:
	skipnc
	goto	u12441
	goto	u12440
u12441:
	goto	l7878
u12440:
	goto	l7812
	line	544
	
l7878:	
	movlw	0Bh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12451
	goto	u12450
u12451:
	goto	l7888
u12450:
	
l7880:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	08h
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	goto	u12461
	goto	u12460
u12461:
	goto	l7888
u12460:
	goto	l7740
	line	559
	
l7888:	
	movlw	0
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	014h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12471
	goto	u12470
u12471:
	goto	l7896
u12470:
	
l7890:	
	movlw	08h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	035h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12481
	goto	u12480
u12481:
	goto	l7896
u12480:
	
l7892:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	addlw	low(064h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipnc
	addlw	1
	addlw	high(064h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	skipz
	goto	u12495
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
u12495:
	skipc
	goto	u12491
	goto	u12490
u12491:
	goto	l7896
u12490:
	goto	l7812
	line	563
	
l7896:	
	movlw	0
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	01Eh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12501
	goto	u12500
u12501:
	goto	l8242
u12500:
	goto	l7740
	line	575
	
l7904:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	576
	movlw	017h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	071h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12511
	goto	u12510
u12511:
	goto	l7908
u12510:
	line	578
	
l7906:	
	movlw	low(07h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	579
	goto	l8242
	line	581
	
l7908:	
	movlw	02h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12521
	goto	u12520
u12521:
	goto	l7914
u12520:
	line	583
	
l7910:	
	movlw	low(03h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	584
	
l7912:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	585
	goto	l8242
	line	587
	
l7914:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12531
	goto	u12530
u12531:
	goto	l8242
u12530:
	goto	l7906
	line	595
	
l7918:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	596
	movlw	075h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	031h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12541
	goto	u12540
u12541:
	goto	l7922
u12540:
	goto	l7906
	line	601
	
l7922:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12551
	goto	u12550
u12551:
	goto	l7928
u12550:
	line	603
	
l7924:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	604
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u12561
	goto	u12560
u12561:
	goto	l7930
u12560:
	goto	l7906
	line	612
	
l7928:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	614
	
l7930:	
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	08Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12571
	goto	u12570
u12571:
	goto	l8242
u12570:
	line	616
	
l7932:	
	movlw	low(04h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	617
	
l7934:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	618
	
l7936:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	619
	
l7938:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	620
	
l7940:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	621
	
l7942:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8242
	line	626
	
l7944:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	627
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	060h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12581
	goto	u12580
u12581:
	goto	l7950
u12580:
	line	629
	
l7946:	
	movlw	060h
	subwf	(ChargeProcess_Slot@ct)^0180h,f
	movlw	0EAh
	skipc
	decf	(ChargeProcess_Slot@ct+1)^0180h,f
	subwf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	630
	
l7948:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	632
	
l7950:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(012h)
	subwf	indf,w
	skipc
	goto	u12591
	goto	u12590
u12591:
	goto	l7954
u12590:
	goto	l7906
	line	641
	
l7954:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12601
	goto	u12600
u12601:
	goto	l7960
u12600:
	
l7956:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12611
	goto	u12610
u12611:
	goto	l7960
u12610:
	goto	l7970
	line	645
	
l7960:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12621
	goto	u12620
u12621:
	goto	l7966
u12620:
	
l7962:	
	movlw	02h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u12631
	goto	u12630
u12631:
	goto	l7966
u12630:
	goto	l7970
	line	653
	
l7966:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u12645
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u12645:
	skipnc
	goto	u12641
	goto	u12640
u12641:
	goto	l7970
u12640:
	
l7968:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	663
	
l7970:	
		movlw	6
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12651
	goto	u12650
u12651:
	goto	l7990
u12650:
	line	665
	
l7972:	
	movlw	07h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0D0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u12661
	goto	u12660
u12661:
	goto	l7982
u12660:
	line	667
	
l7974:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	668
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u12671
	goto	u12670
u12671:
	goto	l7984
u12670:
	line	670
	
l7976:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	671
	
l7978:	
	movlw	low(07h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7912
	line	678
	
l7982:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	683
	
l7984:	
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0C8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12681
	goto	u12680
u12681:
	goto	l8024
u12680:
	goto	l7978
	line	695
	
l7990:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	skipz
	goto	u12695
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v)^0180h,w
u12695:
	skipnc
	goto	u12691
	goto	u12690
u12691:
	goto	l7994
u12690:
	
l7992:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipnc
	goto	u12701
	goto	u12700
u12701:
	goto	l7996
u12700:
	
l7994:	
	movlw	07h
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0D0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u12711
	goto	u12710
u12711:
	goto	l8008
u12710:
	line	697
	
l7996:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	698
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12721
	goto	u12720
u12721:
	goto	l8000
u12720:
	goto	l8242
	line	700
	
l8000:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	701
	
l8002:	
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@st)^080h
	incf	(ChargeProcess_Slot@st)^080h,f
	goto	l7912
	line	707
	
l8008:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	719
	
l8010:	
	movlw	02h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u12731
	goto	u12730
u12731:
	goto	l8016
u12730:
	line	721
	
l8012:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(01Eh)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	skipz
	goto	u12745
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v)^0180h,w
u12745:
	skipc
	goto	u12741
	goto	u12740
u12741:
	goto	l8016
u12740:
	line	722
	
l8014:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	724
	
l8016:	
	movlw	02h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12751
	goto	u12750
u12751:
	goto	l8024
u12750:
	
l8018:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfss	status,2
	goto	u12761
	goto	u12760
u12761:
	goto	l8024
u12760:
	goto	l7978
	line	738
	
l8024:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12771
	goto	u12770
u12771:
	goto	l8032
u12770:
	
l8026:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12781
	goto	u12780
u12781:
	goto	l8032
u12780:
	line	740
	
l8028:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7912
	line	748
	
l8032:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12791
	goto	u12790
u12791:
	goto	l8040
u12790:
	
l8034:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12801
	goto	u12800
u12801:
	goto	l8040
u12800:
	line	750
	
l8036:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	751
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u12811
	goto	u12810
u12811:
	goto	l560
u12810:
	goto	l7906
	line	759
	
l8040:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	761
	
l8042:	
	movlw	0Ch
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	01Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12821
	goto	u12820
u12821:
	goto	l560
u12820:
	
l8044:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12831
	goto	u12830
u12831:
	goto	l8048
u12830:
	
l8046:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12841
	goto	u12840
u12841:
	goto	l560
u12840:
	line	763
	
l8048:	
	movlw	low(05h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	764
	
l8050:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	765
	
l8052:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7942
	line	772
	
l8056:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	773
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	061h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12851
	goto	u12850
u12851:
	goto	l702
u12850:
	line	774
	
l8058:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l702:	
	line	782
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12861
	goto	u12860
u12861:
	goto	l8064
u12860:
	
l8060:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12871
	goto	u12870
u12871:
	goto	l8064
u12870:
	goto	l8242
	line	793
	
l8064:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u12881
	goto	u12880
u12881:
	goto	l8084
u12880:
	
l8066:	
	movlw	02h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u12891
	goto	u12890
u12891:
	goto	l8084
u12890:
	line	795
	
l8068:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(indf),w
	btfss	status,2
	goto	u12901
	goto	u12900
u12901:
	goto	l8072
u12900:
	line	797
	
l8070:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	798
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	799
	goto	l8084
	line	800
	
l8072:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(032h)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	skipz
	goto	u12915
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v)^0180h,w
u12915:
	skipc
	goto	u12911
	goto	u12910
u12911:
	goto	l8082
u12910:
	line	802
	
l8074:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	movlw	low(03h)
	subwf	(indf),w
	skipc
	goto	u12921
	goto	u12920
u12921:
	goto	l706
u12920:
	line	804
	
l8076:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7978
	line	812
	
l8082:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8084
	line	813
	
l706:	
	line	819
	
l8084:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12931
	goto	u12930
u12931:
	goto	l8110
u12930:
	line	821
	
l8086:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12941
	goto	u12940
u12941:
	goto	l8098
u12940:
	line	823
	
l8088:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	824
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12951
	goto	u12950
u12951:
	goto	l8092
u12950:
	goto	l8242
	line	826
	
l8092:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8028
	line	831
	
l8098:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	832
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12961
	goto	u12960
u12961:
	goto	l8102
u12960:
	goto	l8242
	line	834
	
l8102:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	835
	
l8104:	
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	836
	
l8106:	
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@st)^080h
	goto	l7912
	line	847
	
l8110:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12971
	goto	u12970
u12971:
	goto	l8124
u12970:
	line	849
	
l8112:	
	movlw	07h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0D0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u12981
	goto	u12980
u12981:
	goto	l8122
u12980:
	line	851
	
l8114:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	852
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u12991
	goto	u12990
u12991:
	goto	l8140
u12990:
	goto	l7976
	line	862
	
l8122:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l8140
	line	867
	
l8124:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	skipz
	goto	u13005
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v)^0180h,w
u13005:
	skipnc
	goto	u13001
	goto	u13000
u13001:
	goto	l8122
u13000:
	
l8126:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u13011
	goto	u13010
u13011:
	goto	l8122
u13010:
	line	869
	
l8128:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	870
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipc
	goto	u13021
	goto	u13020
u13021:
	goto	l8140
u13020:
	line	872
	
l8130:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	873
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	876
	
l8132:	
	clrf	(ChargeProcess_Slot@ty)^0180h
	goto	l8002
	line	889
	
l8140:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u13031
	goto	u13030
u13031:
	goto	l8146
u13030:
	line	891
	
l8142:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	892
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u13041
	goto	u13040
u13041:
	goto	l560
u13040:
	goto	l7906
	line	900
	
l8146:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l8242
	line	911
	
l8148:	
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u13051
	goto	u13050
u13051:
	goto	l8166
u13050:
	line	913
	
l8150:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	914
	
l8152:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u13061
	goto	u13060
u13061:
	goto	l8156
u13060:
	
l8154:	
	movlw	02h
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_ChargeProcess_Slot$373)^080h
	clrf	(_ChargeProcess_Slot$373+1)^080h
	goto	l8158
	
l8156:	
	movlw	032h
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_ChargeProcess_Slot$373)^080h
	clrf	(_ChargeProcess_Slot$373+1)^080h
	
l8158:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 6	;RP1=0, select bank1
	movf	(_ChargeProcess_Slot$373+1)^080h,w
	xorlw	80h
	sublw	080h
	skipz
	goto	u13075
	movf	(_ChargeProcess_Slot$373)^080h,w
	subwf	indf,w
u13075:

	skipc
	goto	u13071
	goto	u13070
u13071:
	goto	l8242
u13070:
	line	916
	
l8160:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l8106
	line	925
	
l8166:	
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u13081
	goto	u13080
u13081:
	goto	l7490
u13080:
	line	927
	
l8168:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	928
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u13091
	goto	u13090
u13091:
	goto	l8172
u13090:
	goto	l8242
	line	930
	
l8172:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	931
	
l8174:	
	movlw	low(04h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	932
	
l8176:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	933
	
l8178:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	934
	
l8180:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7940
	line	946
	
l8188:	
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u13101
	goto	u13100
u13101:
	goto	l8202
u13100:
	line	948
	
l8190:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	949
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u13111
	goto	u13110
u13111:
	goto	l8102
u13110:
	goto	l8242
	line	965
	
l8202:	
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u13121
	goto	u13120
u13121:
	goto	l8206
u13120:
	
l8204:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u13131
	goto	u13130
u13131:
	goto	l8222
u13130:
	line	967
	
l8206:	
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	08Dh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u13141
	goto	u13140
u13141:
	goto	l7490
u13140:
	
l8208:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u13154
u13155:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u13154:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u13155
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u13161
	goto	u13160
u13161:
	goto	l7490
u13160:
	line	969
	
l8210:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	970
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u13171
	goto	u13170
u13171:
	goto	l8000
u13170:
	goto	l8242
	line	983
	
l8222:	
	movlw	02h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u13181
	goto	u13180
u13181:
	goto	l7490
u13180:
	line	985
	
l8224:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	986
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u13191
	goto	u13190
u13191:
	goto	l8000
u13190:
	goto	l8242
	line	999
	
l8236:	
	clrf	(ChargeProcess_Slot@st)^080h
	line	1000
	goto	l8242
	line	147
	
l8240:	
	bcf	status, 6	;RP1=0, select bank1
	movf	(ChargeProcess_Slot@st)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l7450
	xorlw	1^0	; case 1
	skipnz
	goto	l7470
	xorlw	2^1	; case 2
	skipnz
	goto	l7904
	xorlw	3^2	; case 3
	skipnz
	goto	l7918
	xorlw	4^3	; case 4
	skipnz
	goto	l7944
	xorlw	5^4	; case 5
	skipnz
	goto	l8056
	xorlw	6^5	; case 6
	skipnz
	goto	l8148
	xorlw	7^6	; case 7
	skipnz
	goto	l8188
	xorlw	8^7	; case 8
	skipnz
	goto	l7706
	xorlw	9^8	; case 9
	skipnz
	goto	l7858
	goto	l8236
	opt asmopt_pop

	line	1001
	
l560:	
	line	1003
	
l8242:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@st)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ty)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ct)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@ct+1)^0180h,w
	movwf	indf
	line	1004
	
l750:	
	return
	opt stack 0
GLOBAL	__end_of_ChargeProcess_Slot
	__end_of_ChargeProcess_Slot:
	signat	_ChargeProcess_Slot,4217
	global	___wmul

;; *************** function ___wmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
;; Parameters:    Size  Location     Type
;;  multiplier      2    0[BANK1 ] unsigned int 
;;  multiplicand    2    2[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  product         2   26[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2    0[BANK1 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       4       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       4       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
global __ptext14
__ptext14:	;psect for function ___wmul
psect	text14
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
	global	__size_of___wmul
	__size_of___wmul	equ	__end_of___wmul-___wmul
	
___wmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___wmul: [wreg+status,2+status,0]
	line	43
	
l5270:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___wmul@product)
	clrf	(___wmul@product+1)
	line	45
	
l5272:	
	bsf	status, 5	;RP0=1, select bank1
	btfss	(___wmul@multiplier)^080h,(0)&7
	goto	u7521
	goto	u7520
u7521:
	goto	l5276
u7520:
	line	46
	
l5274:	
	movf	(___wmul@multiplicand)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___wmul@product),f
	skipnc
	incf	(___wmul@product+1),f
	bsf	status, 5	;RP0=1, select bank1
	movf	(___wmul@multiplicand+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___wmul@product+1),f
	line	47
	
l5276:	
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(___wmul@multiplicand)^080h,f
	rlf	(___wmul@multiplicand+1)^080h,f
	line	48
	
l5278:	
	clrc
	rrf	(___wmul@multiplier+1)^080h,f
	rrf	(___wmul@multiplier)^080h,f
	line	49
	
l5280:	
	movf	((___wmul@multiplier)^080h),w
iorwf	((___wmul@multiplier+1)^080h),w
	btfss	status,2
	goto	u7531
	goto	u7530
u7531:
	goto	l5272
u7530:
	line	52
	
l5282:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___wmul@product+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___wmul+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___wmul@product),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___wmul)^080h
	line	53
	
l884:	
	return
	opt stack 0
GLOBAL	__end_of___wmul
	__end_of___wmul:
	signat	___wmul,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK1 ] unsigned int 
;;  dividend        2    2[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2   27[BANK0 ] unsigned int 
;;  counter         1   26[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK1 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       4       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       3       4       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext15
__ptext15:	;psect for function ___lwdiv
psect	text15
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l6840:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l6842:	
	bsf	status, 5	;RP0=1, select bank1
	movf	((___lwdiv@divisor)^080h),w
iorwf	((___lwdiv@divisor+1)^080h),w
	btfsc	status,2
	goto	u10491
	goto	u10490
u10491:
	goto	l6862
u10490:
	line	16
	
l6844:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l6848
	line	18
	
l6846:	
	clrc
	rlf	(___lwdiv@divisor)^080h,f
	rlf	(___lwdiv@divisor+1)^080h,f
	line	19
	bcf	status, 5	;RP0=0, select bank0
	incf	(___lwdiv@counter),f
	line	17
	
l6848:	
	bsf	status, 5	;RP0=1, select bank1
	btfss	(___lwdiv@divisor+1)^080h,(15)&7
	goto	u10501
	goto	u10500
u10501:
	goto	l6846
u10500:
	line	22
	
l6850:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l6852:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lwdiv@divisor+1)^080h,w
	subwf	(___lwdiv@dividend+1)^080h,w
	skipz
	goto	u10515
	movf	(___lwdiv@divisor)^080h,w
	subwf	(___lwdiv@dividend)^080h,w
u10515:
	skipc
	goto	u10511
	goto	u10510
u10511:
	goto	l6858
u10510:
	line	24
	
l6854:	
	movf	(___lwdiv@divisor)^080h,w
	subwf	(___lwdiv@dividend)^080h,f
	movf	(___lwdiv@divisor+1)^080h,w
	skipc
	decf	(___lwdiv@dividend+1)^080h,f
	subwf	(___lwdiv@dividend+1)^080h,f
	line	25
	
l6856:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l6858:	
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rrf	(___lwdiv@divisor+1)^080h,f
	rrf	(___lwdiv@divisor)^080h,f
	line	28
	
l6860:	
	bcf	status, 5	;RP0=0, select bank0
	decfsz	(___lwdiv@counter),f
	goto	u10521
	goto	u10520
u10521:
	goto	l6850
u10520:
	line	30
	
l6862:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lwdiv@quotient+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lwdiv+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lwdiv@quotient),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lwdiv)^080h
	line	31
	
l1221:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    0[BANK1 ] unsigned long 
;;  multiplicand    4    4[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4   26[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    0[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       8       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext16
__ptext16:	;psect for function ___lmul
psect	text16
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l6828:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l893:	
	line	121
	bsf	status, 5	;RP0=1, select bank1
	btfss	(___lmul@multiplier)^080h,(0)&7
	goto	u10461
	goto	u10460
u10461:
	goto	l6832
u10460:
	line	122
	
l6830:	
	movf	(___lmul@multiplicand)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product),f
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lmul@multiplicand+1)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10471
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product+1),f
u10471:
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lmul@multiplicand+2)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10472
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product+2),f
u10472:
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lmul@multiplicand+3)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10473
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product+3),f
u10473:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 5	;RP0=0, select bank0

	line	123
	
l6832:	
	clrc
	bsf	status, 5	;RP0=1, select bank1
	rlf	(___lmul@multiplicand)^080h,f
	rlf	(___lmul@multiplicand+1)^080h,f
	rlf	(___lmul@multiplicand+2)^080h,f
	rlf	(___lmul@multiplicand+3)^080h,f
	line	124
	
l6834:	
	clrc
	rrf	(___lmul@multiplier+3)^080h,f
	rrf	(___lmul@multiplier+2)^080h,f
	rrf	(___lmul@multiplier+1)^080h,f
	rrf	(___lmul@multiplier)^080h,f
	line	125
	movf	(___lmul@multiplier+3)^080h,w
	iorwf	(___lmul@multiplier+2)^080h,w
	iorwf	(___lmul@multiplier+1)^080h,w
	iorwf	(___lmul@multiplier)^080h,w
	skipz
	goto	u10481
	goto	u10480
u10481:
	goto	l893
u10480:
	line	128
	
l6836:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+3),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+2),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul)^080h

	line	129
	
l896:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    8[BANK1 ] unsigned long 
;;  dividend        4   12[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   16[BANK1 ] unsigned long 
;;  counter         1   20[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    8[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       0       5       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext17
__ptext17:	;psect for function ___lldiv
psect	text17
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l5092:	
	clrf	(___lldiv@quotient)^080h
	clrf	(___lldiv@quotient+1)^080h
	clrf	(___lldiv@quotient+2)^080h
	clrf	(___lldiv@quotient+3)^080h
	line	15
	
l5094:	
	movf	(___lldiv@divisor+3)^080h,w
	iorwf	(___lldiv@divisor+2)^080h,w
	iorwf	(___lldiv@divisor+1)^080h,w
	iorwf	(___lldiv@divisor)^080h,w
	skipnz
	goto	u7201
	goto	u7200
u7201:
	goto	l5114
u7200:
	line	16
	
l5096:	
	clrf	(___lldiv@counter)^080h
	incf	(___lldiv@counter)^080h,f
	line	17
	goto	l5100
	line	18
	
l5098:	
	clrc
	rlf	(___lldiv@divisor)^080h,f
	rlf	(___lldiv@divisor+1)^080h,f
	rlf	(___lldiv@divisor+2)^080h,f
	rlf	(___lldiv@divisor+3)^080h,f
	line	19
	incf	(___lldiv@counter)^080h,f
	line	17
	
l5100:	
	btfss	(___lldiv@divisor+3)^080h,(31)&7
	goto	u7211
	goto	u7210
u7211:
	goto	l5098
u7210:
	line	22
	
l5102:	
	clrc
	rlf	(___lldiv@quotient)^080h,f
	rlf	(___lldiv@quotient+1)^080h,f
	rlf	(___lldiv@quotient+2)^080h,f
	rlf	(___lldiv@quotient+3)^080h,f
	line	23
	
l5104:	
	movf	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,w
	skipz
	goto	u7225
	movf	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,w
	skipz
	goto	u7225
	movf	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,w
	skipz
	goto	u7225
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,w
u7225:
	skipc
	goto	u7221
	goto	u7220
u7221:
	goto	l5110
u7220:
	line	24
	
l5106:	
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,f
	movf	(___lldiv@divisor+1)^080h,w
	skipc
	incfsz	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,f
	movf	(___lldiv@divisor+2)^080h,w
	skipc
	incfsz	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,f
	movf	(___lldiv@divisor+3)^080h,w
	skipc
	incfsz	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,f
	line	25
	
l5108:	
	bsf	(___lldiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l5110:	
	clrc
	rrf	(___lldiv@divisor+3)^080h,f
	rrf	(___lldiv@divisor+2)^080h,f
	rrf	(___lldiv@divisor+1)^080h,f
	rrf	(___lldiv@divisor)^080h,f
	line	28
	
l5112:	
	decfsz	(___lldiv@counter)^080h,f
	goto	u7231
	goto	u7230
u7231:
	goto	l5102
u7230:
	line	30
	
l5114:	
	movf	(___lldiv@quotient+3)^080h,w
	movwf	(?___lldiv+3)^080h
	movf	(___lldiv@quotient+2)^080h,w
	movwf	(?___lldiv+2)^080h
	movf	(___lldiv@quotient+1)^080h,w
	movwf	(?___lldiv+1)^080h
	movf	(___lldiv@quotient)^080h,w
	movwf	(?___lldiv)^080h

	line	31
	
l1168:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1   26[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1   28[BANK0 ] unsigned char 
;;  product         1   27[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext18
__ptext18:	;psect for function ___bmul
psect	text18
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___bmul: [wreg+status,2+status,0]
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplier)
	line	6
	
l6940:	
	clrf	(___bmul@product)
	line	43
	
l6942:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u10671
	goto	u10670
u10671:
	goto	l6946
u10670:
	line	44
	
l6944:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l6946:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l6948:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u10681
	goto	u10680
u10681:
	goto	l6942
u10680:
	line	50
	
l6950:	
	movf	(___bmul@product),w
	line	51
	
l902:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 63 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2   26[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	63
global __ptext19
__ptext19:	;psect for function _Detect_BatteryType
psect	text19
	file	"charge_mgr.c"
	line	63
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	65
	
l5238:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u7461
	goto	u7460
u7461:
	goto	l5244
u7460:
	line	66
	
l5240:	
	movlw	low(0)
	goto	l546
	line	67
	
l5244:	
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u7471
	goto	u7470
u7471:
	goto	l5250
u7470:
	goto	l5240
	line	82
	
l5250:	
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u7481
	goto	u7480
u7481:
	goto	l5258
u7480:
	
l5252:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u7491
	goto	u7490
u7491:
	goto	l5258
u7490:
	line	83
	
l5254:	
	movlw	low(05h)
	goto	l546
	line	88
	
l5258:	
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u7501
	goto	u7500
u7501:
	goto	l5240
u7500:
	
l5260:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u7511
	goto	u7510
u7511:
	goto	l5240
u7510:
	line	89
	
l5262:	
	movlw	low(01h)
	line	92
	
l546:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1   26[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    1[BANK1 ] unsigned char 
;;  j               1    0[BANK1 ] unsigned char 
;;  adsum           4    3[BANK1 ] volatile unsigned long 
;;  ad_temp         2   11[BANK1 ] volatile unsigned int 
;;  admax           2    9[BANK1 ] volatile unsigned int 
;;  admin           2    7[BANK1 ] volatile unsigned int 
;;  i               1    2[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       0      13       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0       5      13       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	49
global __ptext20
__ptext20:	;psect for function _ADC_Sample
psect	text20
	file	"adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ADC_Sample@adch)^080h
	line	51
	
l6738:	
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	52
	
l6740:	
	clrf	(ADC_Sample@admin)^080h	;volatile
	clrf	(ADC_Sample@admin+1)^080h	;volatile
	line	53
	clrf	(ADC_Sample@admax)^080h	;volatile
	clrf	(ADC_Sample@admax+1)^080h	;volatile
	line	54
	clrf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	line	58
	
l6742:	
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u10291
	goto	u10290
u10291:
	goto	l6748
u10290:
	
l6744:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u10301
	goto	u10300
u10301:
	goto	l6748
u10300:
	line	60
	
l6746:	
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	61
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u13487:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u13487
	nop
opt asmopt_pop

	line	62
	goto	l6750
	line	64
	
l6748:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	67
	
l6750:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	btfss	(ADC_Sample@adch)^080h,(4)&7
	goto	u10311
	goto	u10310
u10311:
	goto	l464
u10310:
	line	69
	
l6752:	
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l6754:	
	movlw	low(0Fh)
	andwf	(ADC_Sample@adch)^080h,f
	line	71
	goto	l6756
	line	72
	
l464:	
	line	73
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l6756:	
	clrf	(ADC_Sample@i)^080h
	line	79
	
l6762:	
	movf	(ADC_Sample@adch)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u10325:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u10325
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l6764:	
	opt asmopt_push
opt asmopt_off
	movlw	5
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u13497:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u13497
	nop2
opt asmopt_pop

	line	81
	
l6766:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l6768:	
	clrf	(ADC_Sample@j)^080h
	line	85
	goto	l468
	
l469:	
	line	87
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decfsz	(ADC_Sample@j)^080h,f
	goto	u10331
	goto	u10330
u10331:
	goto	l468
u10330:
	line	89
	
l6770:	
	movlw	low(0)
	goto	l471
	line	90
	
l468:	
	line	85
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u10341
	goto	u10340
u10341:
	goto	l469
u10340:
	line	93
	
l6774:	
	movf	(153)^080h,w	;volatile
	movwf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	swapf	(ADC_Sample@ad_temp)^080h,f	;volatile
	swapf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	
l6776:	
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	addwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	line	96
	
l6778:	
	movf	((ADC_Sample@admax)^080h),w	;volatile
iorwf	((ADC_Sample@admax+1)^080h),w	;volatile
	btfss	status,2
	goto	u10351
	goto	u10350
u10351:
	goto	l6782
u10350:
	line	98
	
l6780:	
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	line	99
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	100
	goto	l474
	line	102
	
l6782:	
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	subwf	(ADC_Sample@admax+1)^080h,w	;volatile
	skipz
	goto	u10365
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	subwf	(ADC_Sample@admax)^080h,w	;volatile
u10365:
	skipnc
	goto	u10361
	goto	u10360
u10361:
	goto	l6786
u10360:
	line	103
	
l6784:	
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	goto	l474
	line	105
	
l6786:	
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	skipz
	goto	u10375
	movf	(ADC_Sample@admin)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp)^080h,w	;volatile
u10375:
	skipnc
	goto	u10371
	goto	u10370
u10371:
	goto	l474
u10370:
	line	106
	
l6788:	
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	108
	
l474:	
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ADC_Sample@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10381
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u10381:
	bcf	status, 5	;RP0=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10382
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u10382:
	bcf	status, 5	;RP0=0, select bank0
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10383
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u10383:
	bcf	status, 5	;RP0=0, select bank0
	bsf	status, 5	;RP0=1, select bank1

	line	76
	
l6790:	
	incf	(ADC_Sample@i)^080h,f
	
l6792:	
	movlw	low(022h)
	subwf	(ADC_Sample@i)^080h,w
	skipc
	goto	u10391
	goto	u10390
u10391:
	goto	l6762
u10390:
	line	112
	
l6794:	
	movf	(ADC_Sample@admax)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@admax+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u10405
	goto	u10406
u10405:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u10406:
	bcf	status, 5	;RP0=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u10407
	goto	u10408
u10407:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u10408:
	bcf	status, 5	;RP0=0, select bank0
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u10409
	goto	u10400
u10409:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u10400:
	bcf	status, 5	;RP0=0, select bank0
	bsf	status, 5	;RP0=1, select bank1

	line	113
	movf	(ADC_Sample@admin)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+3)^080h,w	;volatile
	skipz
	goto	u10415
	bcf	status, 5	;RP0=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+2)^080h,w	;volatile
	skipz
	goto	u10415
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+1)^080h,w	;volatile
	skipz
	goto	u10415
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum)^080h,w	;volatile
u10415:
	skipc
	goto	u10411
	goto	u10410
u10411:
	goto	l478
u10410:
	line	114
	
l6796:	
	movf	(ADC_Sample@admin)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u10425
	goto	u10426
u10425:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u10426:
	bcf	status, 5	;RP0=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u10427
	goto	u10428
u10427:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u10428:
	bcf	status, 5	;RP0=0, select bank0
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u10429
	goto	u10420
u10429:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u10420:
	bcf	status, 5	;RP0=0, select bank0
	bsf	status, 5	;RP0=1, select bank1

	goto	l6798
	line	115
	
l478:	
	line	116
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	118
	
l6798:	
	movf	(ADC_Sample@adsum)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_ADC_Sample+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@adsum+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@adsum+2)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@adsum+3)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u10435:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u10430:
	addlw	-1
	skipz
	goto	u10435
	movf	1+(??_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
l6800:	
	movlw	low(0A5h)
	line	120
	
l471:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 153 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   22[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0       8       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_CCCV_Control
;;		_Charging_Control
;;		_PowerOnLedSequence
;;		_Update_LED_Slot
;;		i1_ADC_Sample
;;		i1___lldiv
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	153
global __ptext21
__ptext21:	;psect for function _Isr_Timer
psect	text21
	file	"main.c"
	line	153
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 2
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	movf	btemp+1,w
	movwf	(??_Isr_Timer+3)
	ljmp	_Isr_Timer
psect	text21
	line	156
	
i1l8270:	
	btfss	(90/8),(90)&7	;volatile
	goto	u1324_21
	goto	u1324_20
u1324_21:
	goto	i1l347
u1324_20:
	line	158
	
i1l8272:	
	bcf	(90/8),(90)&7	;volatile
	line	159
	
i1l8274:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	160
# 160 "main.c"
clrwdt ;# 
psect	text21
	line	163
	
i1l8276:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	164
	
i1l8278:	
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u1325_21
	goto	u1325_20
u1325_21:
	goto	i1l8282
u1325_20:
	line	165
	
i1l8280:	
	clrf	(_g_pwmCounter)	;volatile
	line	168
	
i1l8282:	
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u1326_21
	goto	u1326_20
u1326_21:
	goto	i1l344
u1326_20:
	
i1l8284:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u1327_21
	goto	u1327_20
u1327_21:
	goto	i1l344
u1327_20:
	line	169
	
i1l8286:	
	bsf	(55/8),(55)&7	;volatile
	goto	i1l8288
	line	170
	
i1l344:	
	line	171
	bcf	(55/8),(55)&7	;volatile
	line	174
	
i1l8288:	
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u1328_21
	goto	u1328_20
u1328_21:
	goto	i1l8358
u1328_20:
	line	176
	
i1l8290:	
	fcall	_PowerOnLedSequence
	goto	i1l347
	line	183
	
i1l349:	
	line	185
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u1329_21
	goto	u1329_20
u1329_21:
	goto	i1l347
u1329_20:
	
i1l8294:	
	btfsc	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u1330_21
	goto	u1330_20
u1330_21:
	goto	i1l347
u1330_20:
	goto	i1l8298
	line	187
	
i1l353:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l366
	
i1l355:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l366
	
i1l356:	
	bsf	(51/8),(51)&7	;volatile
	goto	i1l366
	
i1l357:	
	bsf	(50/8),(50)&7	;volatile
	goto	i1l366
	
i1l358:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l366
	
i1l359:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l366
	
i1l360:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l366
	
i1l361:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l366
	
i1l362:	
	bsf	(48/8),(48)&7	;volatile
	goto	i1l366
	
i1l363:	
	bsf	(49/8),(49)&7	;volatile
	goto	i1l366
	
i1l364:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l366
	
i1l365:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l366
	
i1l8298:	
	movf	(_g_scanIndex),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l353
	xorlw	1^0	; case 1
	skipnz
	goto	i1l355
	xorlw	2^1	; case 2
	skipnz
	goto	i1l356
	xorlw	3^2	; case 3
	skipnz
	goto	i1l357
	xorlw	4^3	; case 4
	skipnz
	goto	i1l358
	xorlw	5^4	; case 5
	skipnz
	goto	i1l359
	xorlw	6^5	; case 6
	skipnz
	goto	i1l360
	xorlw	7^6	; case 7
	skipnz
	goto	i1l361
	xorlw	8^7	; case 8
	skipnz
	goto	i1l362
	xorlw	9^8	; case 9
	skipnz
	goto	i1l363
	xorlw	10^9	; case 10
	skipnz
	goto	i1l364
	xorlw	11^10	; case 11
	skipnz
	goto	i1l365
	goto	i1l366
	opt asmopt_pop

	
i1l366:	
	line	188
	bsf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	i1l347
	line	194
	
i1l8300:	
	movf	(_g_scanIndex),w	;volatile
	fcall	_Update_LED_Slot
	line	196
	
i1l8302:	
	movlw	low(02h)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_scanPhase)	;volatile
	line	197
	goto	i1l347
	line	200
	
i1l8304:	
	movf	((_g_scanIndex)),w	;volatile
	btfss	status,2
	goto	u1331_21
	goto	u1331_20
u1331_21:
	goto	i1l8350
u1331_20:
	line	203
	
i1l8306:	
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u1332_21
	goto	u1332_20
u1332_21:
	goto	i1l8320
u1332_20:
	line	205
	
i1l8308:	
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	206
	
i1l8310:	
	clrf	(i1ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	i1_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	207
	
i1l8312:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u1333_21
	goto	u1333_20
u1333_21:
	goto	i1l8318
u1333_20:
	line	209
	
i1l8314:	
	movf	(_adresult),w	;volatile
	movwf	(i1___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((i1___lldiv@divisor))+1
	clrf	2+((i1___lldiv@divisor))
	clrf	3+((i1___lldiv@divisor))
	movlw	0
	movwf	(i1___lldiv@dividend+3)
	movlw	04Bh
	movwf	(i1___lldiv@dividend+2)
	movlw	0
	movwf	(i1___lldiv@dividend+1)
	movlw	0
	movwf	(i1___lldiv@dividend)

	fcall	i1___lldiv
	movf	(3+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+3)
	movf	(2+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+2)
	movf	(1+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+1)
	movf	(0+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt)

	line	210
	
i1l8316:	
	movf	(Isr_Timer@pt+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv+1)^080h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(Isr_Timer@pt),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv)^080h	;volatile
	line	212
	
i1l8318:	
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	215
	
i1l8320:	
	fcall	_Charging_Control
	line	216
	
i1l8322:	
	fcall	_CCCV_Control
	line	220
	
i1l8324:	
	movf	((_g_tempPhase)),w	;volatile
	btfss	status,2
	goto	u1334_21
	goto	u1334_20
u1334_21:
	goto	i1l8336
u1334_20:
	line	222
	
i1l8326:	
	incf	(_g_tempReadRoundCnt),f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1),f	;volatile
	line	223
	
i1l8328:	
	movlw	0
	subwf	(_g_tempReadRoundCnt+1),w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt),w	;volatile
	skipc
	goto	u1335_21
	goto	u1335_20
u1335_21:
	goto	i1l8344
u1335_20:
	line	225
	
i1l8330:	
	clrf	(_g_tempReadRoundCnt)	;volatile
	clrf	(_g_tempReadRoundCnt+1)	;volatile
	line	226
	
i1l8332:	
	movlw	low(01h)
	movwf	(_g_tempPhase)	;volatile
	line	227
	
i1l8334:	
	clrf	(_g_tempSettleCnt)	;volatile
	clrf	(_g_tempSettleCnt+1)	;volatile
	goto	i1l8344
	line	232
	
i1l8336:	
	incf	(_g_tempSettleCnt),f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1),f	;volatile
	line	233
	
i1l8338:	
	movlw	0
	subwf	(_g_tempSettleCnt+1),w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt),w	;volatile
	skipc
	goto	u1336_21
	goto	u1336_20
u1336_21:
	goto	i1l8344
u1336_20:
	line	235
	
i1l8340:	
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	236
	
i1l8342:	
	clrf	(_g_tempSettleCnt)	;volatile
	clrf	(_g_tempSettleCnt+1)	;volatile
	line	237
	clrf	(_g_tempPhase)	;volatile
	line	244
	
i1l8344:	
	incf	(_g_printTick),f	;volatile
	skipnz
	incf	(_g_printTick+1),f	;volatile
	movlw	0
	subwf	((_g_printTick+1)),w	;volatile
	movlw	064h
	skipnz
	subwf	((_g_printTick)),w	;volatile
	skipc
	goto	u1337_21
	goto	u1337_20
u1337_21:
	goto	i1l8350
u1337_20:
	line	246
	
i1l8346:	
	clrf	(_g_printTick)	;volatile
	clrf	(_g_printTick+1)	;volatile
	line	247
	
i1l8348:	
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	253
	
i1l8350:	
	movlw	low(0Ch)
	incf	(_g_scanIndex),f	;volatile
	subwf	((_g_scanIndex)),w	;volatile
	skipc
	goto	u1338_21
	goto	u1338_20
u1338_21:
	goto	i1l378
u1338_20:
	line	254
	
i1l8352:	
	clrf	(_g_scanIndex)	;volatile
	
i1l378:	
	line	255
	clrf	(_g_scanPhase)	;volatile
	line	256
	goto	i1l347
	line	181
	
i1l8358:	
	movf	(_g_scanPhase),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 2
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           17     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l349
	xorlw	1^0	; case 1
	skipnz
	goto	i1l8300
	xorlw	2^1	; case 2
	skipnz
	goto	i1l8304
	goto	i1l378
	opt asmopt_pop

	line	263
	
i1l347:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(??_Isr_Timer+3),w
	movwf	btemp+1
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^00h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	i1___lldiv

;; *************** function i1___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    0[COMMON] unsigned long 
;;  dividend        4    4[COMMON] unsigned long 
;; Auto vars:     Size  Location     Type
;;  __lldiv         4    1[BANK0 ] unsigned long 
;;  __lldiv         1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    0[COMMON] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         8       0       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       5       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext22
__ptext22:	;psect for function i1___lldiv
psect	text22
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_ofi1___lldiv
	__size_ofi1___lldiv	equ	__end_ofi1___lldiv-i1___lldiv
	
i1___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in i1___lldiv: [wreg+status,2+status,0]
	line	14
	
i1l8244:	
	clrf	(i1___lldiv@quotient)
	clrf	(i1___lldiv@quotient+1)
	clrf	(i1___lldiv@quotient+2)
	clrf	(i1___lldiv@quotient+3)
	line	15
	
i1l8246:	
	movf	(i1___lldiv@divisor+3),w
	iorwf	(i1___lldiv@divisor+2),w
	iorwf	(i1___lldiv@divisor+1),w
	iorwf	(i1___lldiv@divisor),w
	skipnz
	goto	u1320_21
	goto	u1320_20
u1320_21:
	goto	i1l8266
u1320_20:
	line	16
	
i1l8248:	
	clrf	(i1___lldiv@counter)
	incf	(i1___lldiv@counter),f
	line	17
	goto	i1l8252
	line	18
	
i1l8250:	
	clrc
	rlf	(i1___lldiv@divisor),f
	rlf	(i1___lldiv@divisor+1),f
	rlf	(i1___lldiv@divisor+2),f
	rlf	(i1___lldiv@divisor+3),f
	line	19
	incf	(i1___lldiv@counter),f
	line	17
	
i1l8252:	
	btfss	(i1___lldiv@divisor+3),(31)&7
	goto	u1321_21
	goto	u1321_20
u1321_21:
	goto	i1l8250
u1321_20:
	line	22
	
i1l8254:	
	clrc
	rlf	(i1___lldiv@quotient),f
	rlf	(i1___lldiv@quotient+1),f
	rlf	(i1___lldiv@quotient+2),f
	rlf	(i1___lldiv@quotient+3),f
	line	23
	
i1l8256:	
	movf	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),w
	skipz
	goto	u1322_25
	movf	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),w
	skipz
	goto	u1322_25
	movf	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),w
	skipz
	goto	u1322_25
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),w
u1322_25:
	skipc
	goto	u1322_21
	goto	u1322_20
u1322_21:
	goto	i1l8262
u1322_20:
	line	24
	
i1l8258:	
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),f
	movf	(i1___lldiv@divisor+1),w
	skipc
	incfsz	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),f
	movf	(i1___lldiv@divisor+2),w
	skipc
	incfsz	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),f
	movf	(i1___lldiv@divisor+3),w
	skipc
	incfsz	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),f
	line	25
	
i1l8260:	
	bsf	(i1___lldiv@quotient)+(0/8),(0)&7
	line	27
	
i1l8262:	
	clrc
	rrf	(i1___lldiv@divisor+3),f
	rrf	(i1___lldiv@divisor+2),f
	rrf	(i1___lldiv@divisor+1),f
	rrf	(i1___lldiv@divisor),f
	line	28
	
i1l8264:	
	decfsz	(i1___lldiv@counter),f
	goto	u1323_21
	goto	u1323_20
u1323_21:
	goto	i1l8254
u1323_20:
	line	30
	
i1l8266:	
	movf	(i1___lldiv@quotient+3),w
	movwf	(?i1___lldiv+3)
	movf	(i1___lldiv@quotient+2),w
	movwf	(?i1___lldiv+2)
	movf	(i1___lldiv@quotient+1),w
	movwf	(?i1___lldiv+1)
	movf	(i1___lldiv@quotient),w
	movwf	(?i1___lldiv)

	line	31
	
i1l1168:	
	return
	opt stack 0
GLOBAL	__end_ofi1___lldiv
	__end_ofi1___lldiv:
	signat	i1___lldiv,92
	global	i1_ADC_Sample

;; *************** function i1_ADC_Sample *****************
;; Defined at:
;;		line 49 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    0[BANK0 ] unsigned char 
;;  ADC_Sample      4    3[BANK0 ] volatile unsigned long 
;;  ADC_Sample      2   11[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    9[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    7[BANK0 ] volatile unsigned int 
;;  ADC_Sample      1    2[BANK0 ] unsigned char 
;;  ADC_Sample      1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      13       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	49
global __ptext23
__ptext23:	;psect for function i1_ADC_Sample
psect	text23
	file	"adc_drv.c"
	line	49
	global	__size_ofi1_ADC_Sample
	__size_ofi1_ADC_Sample	equ	__end_ofi1_ADC_Sample-i1_ADC_Sample
	
i1_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in i1_ADC_Sample: [wreg+status,2+status,0]
	movwf	(i1ADC_Sample@adch)
	line	51
	
i1l4802:	
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	52
	
i1l4804:	
	clrf	(i1ADC_Sample@admin)	;volatile
	clrf	(i1ADC_Sample@admin+1)	;volatile
	line	53
	clrf	(i1ADC_Sample@admax)	;volatile
	clrf	(i1ADC_Sample@admax+1)	;volatile
	line	54
	clrf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	line	58
	
i1l4806:	
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u667_21
	goto	u667_20
u667_21:
	goto	i1l4812
u667_20:
	
i1l4808:	
	btfss	(i1ADC_Sample@adldo),(2)&7
	goto	u668_21
	goto	u668_20
u668_21:
	goto	i1l4812
u668_20:
	line	60
	
i1l4810:	
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	61
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??i1_ADC_Sample+0)+0),f
	u1350_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u1350_27
opt asmopt_pop

	line	62
	goto	i1l4814
	line	64
	
i1l4812:	
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	67
	
i1l4814:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(i1ADC_Sample@adch),(4)&7
	goto	u669_21
	goto	u669_20
u669_21:
	goto	i1l464
u669_20:
	line	69
	
i1l4816:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
i1l4818:	
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(i1ADC_Sample@adch),f
	line	71
	goto	i1l4820
	line	72
	
i1l464:	
	line	73
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
i1l4820:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@i)
	
i1l4822:	
	movlw	low(022h)
	subwf	(i1ADC_Sample@i),w
	skipc
	goto	u670_21
	goto	u670_20
u670_21:
	goto	i1l4826
u670_20:
	goto	i1l4858
	line	79
	
i1l4826:	
	movf	(i1ADC_Sample@adch),w
	movwf	(??i1_ADC_Sample+0)+0
	movlw	(02h)-1
u671_25:
	clrc
	rlf	(??i1_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u671_25
	clrc
	rlf	(??i1_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
i1l4828:	
	opt asmopt_push
opt asmopt_off
	movlw	6
movwf	((??i1_ADC_Sample+0)+0),f
	u1351_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u1351_27
	nop
opt asmopt_pop

	line	81
	
i1l4830:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
i1l4832:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@j)
	line	85
	goto	i1l468
	
i1l469:	
	line	87
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(i1ADC_Sample@j),f
	goto	u672_21
	goto	u672_20
u672_21:
	goto	i1l468
u672_20:
	line	89
	
i1l4834:	
	movlw	low(0)
	goto	i1l471
	line	90
	
i1l468:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u673_21
	goto	u673_20
u673_21:
	goto	i1l469
u673_20:
	line	93
	
i1l4838:	
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	swapf	(i1ADC_Sample@ad_temp),f	;volatile
	swapf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp),f	;volatile
	
i1l4840:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(i1ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(i1ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
i1l4842:	
	movf	((i1ADC_Sample@admax)),w	;volatile
iorwf	((i1ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u674_21
	goto	u674_20
u674_21:
	goto	i1l4846
u674_20:
	line	98
	
i1l4844:	
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	line	99
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	100
	goto	i1l474
	line	102
	
i1l4846:	
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	subwf	(i1ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u675_25
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	subwf	(i1ADC_Sample@admax),w	;volatile
u675_25:
	skipnc
	goto	u675_21
	goto	u675_20
u675_21:
	goto	i1l4850
u675_20:
	line	103
	
i1l4848:	
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	goto	i1l474
	line	105
	
i1l4850:	
	movf	(i1ADC_Sample@admin+1),w	;volatile
	subwf	(i1ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u676_25
	movf	(i1ADC_Sample@admin),w	;volatile
	subwf	(i1ADC_Sample@ad_temp),w	;volatile
u676_25:
	skipnc
	goto	u676_21
	goto	u676_20
u676_21:
	goto	i1l474
u676_20:
	line	106
	
i1l4852:	
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	108
	
i1l474:	
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	addwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u677_21
	addwf	(i1ADC_Sample@adsum+1),f	;volatile
u677_21:
	movf	2+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u677_22
	addwf	(i1ADC_Sample@adsum+2),f	;volatile
u677_22:
	movf	3+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u677_23
	addwf	(i1ADC_Sample@adsum+3),f	;volatile
u677_23:

	line	76
	
i1l4854:	
	incf	(i1ADC_Sample@i),f
	goto	i1l4822
	line	112
	
i1l4858:	
	movf	(i1ADC_Sample@admax),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admax+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u678_25
	goto	u678_26
u678_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u678_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u678_27
	goto	u678_28
u678_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u678_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u678_29
	goto	u678_20
u678_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u678_20:

	line	113
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	3+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u679_25
	movf	2+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u679_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u679_25
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),w	;volatile
u679_25:
	skipc
	goto	u679_21
	goto	u679_20
u679_21:
	goto	i1l478
u679_20:
	line	114
	
i1l4860:	
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u680_25
	goto	u680_26
u680_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u680_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u680_27
	goto	u680_28
u680_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u680_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u680_29
	goto	u680_20
u680_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u680_20:

	goto	i1l4862
	line	115
	
i1l478:	
	line	116
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	118
	
i1l4862:	
	movf	(i1ADC_Sample@adsum),w	;volatile
	movwf	(??i1_ADC_Sample+0)+0
	movf	(i1ADC_Sample@adsum+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	movf	(i1ADC_Sample@adsum+2),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+2)
	movf	(i1ADC_Sample@adsum+3),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+3)
	movlw	05h
u681_25:
	clrc
	rrf	(??i1_ADC_Sample+0)+3,f
	rrf	(??i1_ADC_Sample+0)+2,f
	rrf	(??i1_ADC_Sample+0)+1,f
	rrf	(??i1_ADC_Sample+0)+0,f
u681_20:
	addlw	-1
	skipz
	goto	u681_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
i1l4864:	
	movlw	low(0A5h)
	line	120
	
i1l471:	
	return
	opt stack 0
GLOBAL	__end_ofi1_ADC_Sample
	__end_ofi1_ADC_Sample:
	signat	i1_ADC_Sample,89
	global	_Update_LED_Slot

;; *************** function _Update_LED_Slot *****************
;; Defined at:
;;		line 28 in file "led.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    3[COMMON] unsigned char 
;;  s               1    8[COMMON] unsigned char 
;;  i               1    7[COMMON] unsigned char 
;;  hasFull         1    6[COMMON] unsigned char 
;;  hasChg          1    5[COMMON] unsigned char 
;;  hasErr          1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         6       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         6       0       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	file	"led.c"
	line	28
global __ptext24
__ptext24:	;psect for function _Update_LED_Slot
psect	text24
	file	"led.c"
	line	28
	global	__size_of_Update_LED_Slot
	__size_of_Update_LED_Slot	equ	__end_of_Update_LED_Slot-_Update_LED_Slot
	
_Update_LED_Slot:	
;incstack = 0
	opt	stack 2
; Regs used in _Update_LED_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	movwf	(Update_LED_Slot@idx)
	line	31
	
i1l7024:	
	clrf	(Update_LED_Slot@hasErr)
	line	32
	clrf	(Update_LED_Slot@hasChg)
	line	33
	clrf	(Update_LED_Slot@hasFull)
	line	35
	clrf	(Update_LED_Slot@i)
	line	37
	
i1l7030:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Update_LED_Slot@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Slot@s)
	line	38
	
i1l7032:	
		movlw	7
	xorwf	((Update_LED_Slot@s)),w
	btfss	status,2
	goto	u1070_21
	goto	u1070_20
u1070_21:
	goto	i1l7036
u1070_20:
	line	39
	
i1l7034:	
	clrf	(Update_LED_Slot@hasErr)
	incf	(Update_LED_Slot@hasErr),f
	goto	i1l7046
	line	40
	
i1l7036:	
	movf	((Update_LED_Slot@s)),w
	btfsc	status,2
	goto	u1071_21
	goto	u1071_20
u1071_21:
	goto	i1l7042
u1071_20:
	
i1l7038:	
		movlw	6
	xorwf	((Update_LED_Slot@s)),w
	btfsc	status,2
	goto	u1072_21
	goto	u1072_20
u1072_21:
	goto	i1l7042
u1072_20:
	line	41
	
i1l7040:	
	clrf	(Update_LED_Slot@hasChg)
	incf	(Update_LED_Slot@hasChg),f
	goto	i1l7046
	line	42
	
i1l7042:	
		movlw	6
	xorwf	((Update_LED_Slot@s)),w
	btfss	status,2
	goto	u1073_21
	goto	u1073_20
u1073_21:
	goto	i1l7046
u1073_20:
	line	43
	
i1l7044:	
	clrf	(Update_LED_Slot@hasFull)
	incf	(Update_LED_Slot@hasFull),f
	line	35
	
i1l7046:	
	incf	(Update_LED_Slot@i),f
	
i1l7048:	
	movlw	low(0Ch)
	subwf	(Update_LED_Slot@i),w
	skipc
	goto	u1074_21
	goto	u1074_20
u1074_21:
	goto	i1l7030
u1074_20:
	line	46
	
i1l7050:	
	movf	((Update_LED_Slot@hasErr)),w
	btfsc	status,2
	goto	u1075_21
	goto	u1075_20
u1075_21:
	goto	i1l7062
u1075_20:
	line	49
	
i1l7052:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	50
	
i1l7054:	
	movf	((Update_LED_Slot@idx)),w
	btfss	status,2
	goto	u1076_21
	goto	u1076_20
u1076_21:
	goto	i1l870
u1076_20:
	line	52
	
i1l7056:	
	movlw	low(032h)
	incf	(_s_ledBlinkCnt),f	;volatile
	subwf	((_s_ledBlinkCnt)),w	;volatile
	skipc
	goto	u1077_21
	goto	u1077_20
u1077_21:
	goto	i1l7060
u1077_20:
	line	53
	
i1l7058:	
	clrf	(_s_ledBlinkCnt)	;volatile
	line	54
	
i1l7060:	
	movlw	low(019h)
	subwf	(_s_ledBlinkCnt),w	;volatile
	skipnc
	goto	u1078_21
	goto	u1078_20
	
u1078_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u1079_24
u1078_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u1079_24:
	goto	i1l870
	line	57
	
i1l7062:	
	movf	((Update_LED_Slot@hasChg)),w
	btfsc	status,2
	goto	u1080_21
	goto	u1080_20
u1080_21:
	goto	i1l7066
u1080_20:
	line	60
	
i1l7064:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	61
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	62
	goto	i1l870
	line	63
	
i1l7066:	
	movf	((Update_LED_Slot@hasFull)),w
	btfsc	status,2
	goto	u1081_21
	goto	u1081_20
u1081_21:
	goto	i1l868
u1081_20:
	line	66
	
i1l7068:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	67
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	68
	goto	i1l870
	line	69
	
i1l868:	
	line	72
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	73
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	75
	
i1l870:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Slot
	__end_of_Update_LED_Slot:
	signat	_Update_LED_Slot,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 84 in file "led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	line	84
global __ptext25
__ptext25:	;psect for function _PowerOnLedSequence
psect	text25
	file	"led.c"
	line	84
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	86
	
i1l3534:	
	incf	(_g_powerOnTimer),f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1),f	;volatile
	line	88
	
i1l3536:	
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u409_21
	goto	u409_20
u409_21:
	goto	i1l3546
u409_20:
	line	91
	
i1l3538:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	92
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	93
	
i1l3540:	
	movlw	0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u410_21
	goto	u410_20
u410_21:
	goto	i1l878
u410_20:
	line	95
	
i1l3542:	
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	96
	
i1l3544:	
	movlw	low(01h)
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l878
	line	99
	
i1l3546:	
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u411_21
	goto	u411_20
u411_21:
	goto	i1l878
u411_20:
	line	102
	
i1l3548:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	103
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	104
	
i1l3550:	
	movlw	0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u412_21
	goto	u412_20
u412_21:
	goto	i1l878
u412_20:
	line	106
	
i1l3552:	
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	107
	
i1l3554:	
	movlw	low(02h)
	movwf	(_g_powerOnPhase)	;volatile
	line	111
	
i1l878:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
	global	_Charging_Control

;; *************** function _Charging_Control *****************
;; Defined at:
;;		line 1020 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    3[COMMON] unsigned char 
;;  i               1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	1020
global __ptext26
__ptext26:	;psect for function _Charging_Control
psect	text26
	file	"charge_mgr.c"
	line	1020
	global	__size_of_Charging_Control
	__size_of_Charging_Control	equ	__end_of_Charging_Control-_Charging_Control
	
_Charging_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _Charging_Control: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1025
	
i1l7070:	
	movf	((_g_tempProtect)),w
	btfsc	status,2
	goto	u1082_21
	goto	u1082_20
u1082_21:
	goto	i1l7076
u1082_20:
	line	1027
	
i1l754:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	bsf	(1073/8)^080h,(1073)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	bsf	(50/8),(50)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	bsf	(1074/8)^080h,(1074)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	bsf	(49/8),(49)&7	;volatile
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	line	1028
	
i1l7072:	
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	goto	i1l756
	line	1035
	
i1l7076:	
	bcf	status, 5	;RP0=0, select bank0
	movf	((_g_vccProtect)),w
	btfsc	status,2
	goto	u1083_21
	goto	u1083_20
u1083_21:
	goto	i1l7086
u1083_20:
	line	1037
	
i1l7078:	
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u1084_21
	goto	u1084_20
u1084_21:
	goto	i1l7084
u1084_20:
	goto	i1l754
	line	1043
	
i1l7084:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	line	1044
	goto	i1l7094
	line	1047
	
i1l7086:	
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u1085_21
	goto	u1085_20
u1085_21:
	goto	i1l7094
u1085_20:
	line	1049
	
i1l7088:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	incf	(_g_vccProtect),f
	goto	i1l754
	line	1057
	
i1l7094:	
	clrf	(Charging_Control@i)
	line	1059
	
i1l7100:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Charging_Control@s)
	line	1064
	
i1l7102:	
		movlw	2
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1086_21
	goto	u1086_20
u1086_21:
	goto	i1l7114
u1086_20:
	
i1l7104:	
		movlw	3
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1087_21
	goto	u1087_20
u1087_21:
	goto	i1l7114
u1087_20:
	
i1l7106:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1088_21
	goto	u1088_20
u1088_21:
	goto	i1l7114
u1088_20:
	
i1l7108:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1089_21
	goto	u1089_20
u1089_21:
	goto	i1l7114
u1089_20:
	
i1l7110:	
		movlw	8
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u1090_21
	goto	u1090_20
u1090_21:
	goto	i1l7116
u1090_20:
	goto	i1l7114
	line	1066
	
i1l772:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l7126
	
i1l774:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l7126
	
i1l775:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l7126
	
i1l776:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l7126
	
i1l777:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l7126
	
i1l778:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l7126
	
i1l779:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l7126
	
i1l780:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l7126
	
i1l781:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l7126
	
i1l782:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l7126
	
i1l783:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l7126
	
i1l784:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l7126
	
i1l7114:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l772
	xorlw	1^0	; case 1
	skipnz
	goto	i1l774
	xorlw	2^1	; case 2
	skipnz
	goto	i1l775
	xorlw	3^2	; case 3
	skipnz
	goto	i1l776
	xorlw	4^3	; case 4
	skipnz
	goto	i1l777
	xorlw	5^4	; case 5
	skipnz
	goto	i1l778
	xorlw	6^5	; case 6
	skipnz
	goto	i1l779
	xorlw	7^6	; case 7
	skipnz
	goto	i1l780
	xorlw	8^7	; case 8
	skipnz
	goto	i1l781
	xorlw	9^8	; case 9
	skipnz
	goto	i1l782
	xorlw	10^9	; case 10
	skipnz
	goto	i1l783
	xorlw	11^10	; case 11
	skipnz
	goto	i1l784
	goto	i1l7126
	opt asmopt_pop

	line	1069
	
i1l7116:	
		decf	((Charging_Control@s)),w
	btfss	status,2
	goto	u1091_21
	goto	u1091_20
u1091_21:
	goto	i1l7124
u1091_20:
	line	1071
	
i1l7120:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l772
	xorlw	1^0	; case 1
	skipnz
	goto	i1l774
	xorlw	2^1	; case 2
	skipnz
	goto	i1l775
	xorlw	3^2	; case 3
	skipnz
	goto	i1l776
	xorlw	4^3	; case 4
	skipnz
	goto	i1l777
	xorlw	5^4	; case 5
	skipnz
	goto	i1l778
	xorlw	6^5	; case 6
	skipnz
	goto	i1l779
	xorlw	7^6	; case 7
	skipnz
	goto	i1l780
	xorlw	8^7	; case 8
	skipnz
	goto	i1l781
	xorlw	9^8	; case 9
	skipnz
	goto	i1l782
	xorlw	10^9	; case 10
	skipnz
	goto	i1l783
	xorlw	11^10	; case 11
	skipnz
	goto	i1l784
	goto	i1l7126
	opt asmopt_pop

	line	1075
	
i1l807:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l7126
	
i1l809:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l7126
	
i1l810:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	i1l7126
	
i1l811:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	i1l7126
	
i1l812:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l7126
	
i1l813:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l7126
	
i1l814:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l7126
	
i1l815:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l7126
	
i1l816:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	i1l7126
	
i1l817:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	i1l7126
	
i1l818:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l7126
	
i1l819:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l7126
	
i1l7124:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l807
	xorlw	1^0	; case 1
	skipnz
	goto	i1l809
	xorlw	2^1	; case 2
	skipnz
	goto	i1l810
	xorlw	3^2	; case 3
	skipnz
	goto	i1l811
	xorlw	4^3	; case 4
	skipnz
	goto	i1l812
	xorlw	5^4	; case 5
	skipnz
	goto	i1l813
	xorlw	6^5	; case 6
	skipnz
	goto	i1l814
	xorlw	7^6	; case 7
	skipnz
	goto	i1l815
	xorlw	8^7	; case 8
	skipnz
	goto	i1l816
	xorlw	9^8	; case 9
	skipnz
	goto	i1l817
	xorlw	10^9	; case 10
	skipnz
	goto	i1l818
	xorlw	11^10	; case 11
	skipnz
	goto	i1l819
	goto	i1l7126
	opt asmopt_pop

	line	1057
	
i1l7126:	
	incf	(Charging_Control@i),f
	
i1l7128:	
	movlw	low(0Ch)
	subwf	(Charging_Control@i),w
	skipc
	goto	u1092_21
	goto	u1092_20
u1092_21:
	goto	i1l7100
u1092_20:
	line	1080
	
i1l756:	
	return
	opt stack 0
GLOBAL	__end_of_Charging_Control
	__end_of_Charging_Control:
	signat	_Charging_Control,89
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 1098 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    6[BANK0 ] unsigned int 
;;  s               1   17[BANK0 ] unsigned char 
;;  duty            2   14[BANK0 ] int 
;;  error           2   10[BANK0 ] int 
;;  adjust          2    0[BANK0 ] int 
;;  duty_initial    1   13[BANK0 ] unsigned char 
;;  duty_target     1   12[BANK0 ] unsigned char 
;;  maxV            2    8[BANK0 ] unsigned int 
;;  i               1   16[BANK0 ] unsigned char 
;;  preCount        1    5[BANK0 ] unsigned char 
;;  ccCount         1    4[BANK0 ] unsigned char 
;;  cvCount         1    3[BANK0 ] unsigned char 
;;  hasCharging     1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2      18       0       0       0
;;Total ram usage:       20 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___awdiv
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=0
	line	1098
global __ptext27
__ptext27:	;psect for function _CCCV_Control
psect	text27
	file	"charge_mgr.c"
	line	1098
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1101
	
i1l7130:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	1102
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	1103
	clrf	(CCCV_Control@cvCount)
	line	1104
	clrf	(CCCV_Control@ccCount)
	line	1105
	clrf	(CCCV_Control@preCount)
	line	1108
	clrf	(CCCV_Control@i)
	line	1110
	
i1l7136:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	1114
	
i1l7138:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1093_21
	goto	u1093_20
u1093_21:
	goto	i1l827
u1093_20:
	
i1l7140:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1094_21
	goto	u1094_20
u1094_21:
	goto	i1l827
u1094_20:
	
i1l7142:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1095_21
	goto	u1095_20
u1095_21:
	goto	i1l827
u1095_20:
	
i1l7144:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1096_21
	goto	u1096_20
u1096_21:
	goto	i1l827
u1096_20:
	
i1l7146:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1097_21
	goto	u1097_20
u1097_21:
	goto	i1l825
u1097_20:
	
i1l827:	
	line	1116
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	1118
	
i1l7148:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	1119
	
i1l7150:	
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u1098_25
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u1098_25:
	skipnc
	goto	u1098_21
	goto	u1098_20
u1098_21:
	goto	i1l7154
u1098_20:
	
i1l7152:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	1121
	
i1l7154:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1099_21
	goto	u1099_20
u1099_21:
	goto	i1l7158
u1099_20:
	line	1122
	
i1l7156:	
	incf	(CCCV_Control@cvCount),f
	line	1123
	
i1l7158:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1100_21
	goto	u1100_20
u1100_21:
	goto	i1l7162
u1100_20:
	line	1124
	
i1l7160:	
	incf	(CCCV_Control@ccCount),f
	line	1125
	
i1l7162:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1101_21
	goto	u1101_20
u1101_21:
	goto	i1l7166
u1101_20:
	
i1l7164:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1102_21
	goto	u1102_20
u1102_21:
	goto	i1l825
u1102_20:
	line	1126
	
i1l7166:	
	incf	(CCCV_Control@preCount),f
	line	1127
	
i1l825:	
	line	1108
	incf	(CCCV_Control@i),f
	
i1l7168:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u1103_21
	goto	u1103_20
u1103_21:
	goto	i1l7136
u1103_20:
	line	1131
	
i1l7170:	
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u1104_21
	goto	u1104_20
u1104_21:
	goto	i1l7176
u1104_20:
	line	1133
	
i1l7172:	
	clrf	(_g_pwmDuty)	;volatile
	line	1134
	clrf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l835
	line	1142
	
i1l7176:	
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u1105_21
	goto	u1105_20
u1105_21:
	goto	i1l7206
u1105_20:
	line	1146
	
i1l7178:	
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u1106_21
	goto	u1106_20
u1106_21:
	goto	i1l7182
u1106_20:
	line	1149
	
i1l7180:	
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	1150
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	1151
	goto	i1l7190
	line	1152
	
i1l7182:	
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u1107_21
	goto	u1107_20
u1107_21:
	goto	i1l7186
u1107_20:
	line	1155
	
i1l7184:	
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	1156
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	1157
	goto	i1l7190
	line	1162
	
i1l7186:	
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l835
	line	1166
	
i1l7190:	
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u1108_21
	goto	u1108_20
u1108_21:
	goto	i1l7198
u1108_20:
	line	1169
	
i1l7192:	
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	1170
	
i1l7194:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u1109_21
	goto	u1109_20
u1109_21:
	goto	i1l835
u1109_20:
	line	1171
	
i1l7196:	
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l835
	line	1173
	
i1l7198:	
	line	1176
	
i1l7200:	
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	1177
	goto	i1l835
	line	1192
	
i1l7206:	
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	1195
	movf	(CCCV_Control@error),w
	addwf	(_g_cvIntegral),f
	skipnc
	incf	(_g_cvIntegral+1),f
	movf	(CCCV_Control@error+1),w
	addwf	(_g_cvIntegral+1),f
	line	1196
	
i1l7208:	
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u1110_25
	movlw	0C9h
	subwf	(_g_cvIntegral),w
u1110_25:

	skipc
	goto	u1110_21
	goto	u1110_20
u1110_21:
	goto	i1l7212
u1110_20:
	line	1197
	
i1l7210:	
	movlw	0C8h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l7216
	line	1198
	
i1l7212:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u1111_25
	movlw	038h
	subwf	(_g_cvIntegral),w
u1111_25:

	skipnc
	goto	u1111_21
	goto	u1111_20
u1111_21:
	goto	i1l7216
u1111_20:
	line	1199
	
i1l7214:	
	movlw	038h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	movlw	0FFh
	movwf	((_g_cvIntegral))+1
	line	1202
	
i1l7216:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	movf	(_g_cvIntegral),w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1),w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	1203
	
i1l7218:	
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
i1l7220:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	1206
	
i1l7222:	
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u1112_25
	movlw	021h
	subwf	(CCCV_Control@duty),w
u1112_25:

	skipc
	goto	u1112_21
	goto	u1112_20
u1112_21:
	goto	i1l7226
u1112_20:
	
i1l7224:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1207
	
i1l7226:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u1113_21
	goto	u1113_20
u1113_21:
	goto	i1l7230
u1113_20:
	
i1l7228:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1209
	
i1l7230:	
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	1211
	
i1l835:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	i1___bmul

;; *************** function i1___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[COMMON] unsigned char 
;;  __bmul          1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext28
__ptext28:	;psect for function i1___bmul
psect	text28
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_ofi1___bmul
	__size_ofi1___bmul	equ	__end_ofi1___bmul-i1___bmul
	
i1___bmul:	
;incstack = 0
	opt	stack 2
; Regs used in i1___bmul: [wreg+status,2+status,0]
	movwf	(i1___bmul@multiplier)
	line	6
	
i1l3450:	
	clrf	(i1___bmul@product)
	line	43
	
i1l3452:	
	btfss	(i1___bmul@multiplier),(0)&7
	goto	u406_21
	goto	u406_20
u406_21:
	goto	i1l3456
u406_20:
	line	44
	
i1l3454:	
	movf	(i1___bmul@multiplicand),w
	addwf	(i1___bmul@product),f
	line	45
	
i1l3456:	
	clrc
	rlf	(i1___bmul@multiplicand),f
	line	46
	
i1l3458:	
	clrc
	rrf	(i1___bmul@multiplier),f
	line	47
	movf	((i1___bmul@multiplier)),w
	btfss	status,2
	goto	u407_21
	goto	u407_20
u407_21:
	goto	i1l3452
u407_20:
	line	50
	
i1l3460:	
	movf	(i1___bmul@product),w
	line	51
	
i1l902:	
	return
	opt stack 0
GLOBAL	__end_ofi1___bmul
	__end_ofi1___bmul:
	signat	i1___bmul,89
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] int 
;;  dividend        2    2[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] int 
;;  sign            1    5[COMMON] unsigned char 
;;  counter         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext29
__ptext29:	;psect for function ___awdiv
psect	text29
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
i1l3406:	
	clrf	(___awdiv@sign)
	line	15
	
i1l3408:	
	btfss	(___awdiv@divisor+1),7
	goto	u399_21
	goto	u399_20
u399_21:
	goto	i1l3414
u399_20:
	line	16
	
i1l3410:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
i1l3412:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
i1l3414:	
	btfss	(___awdiv@dividend+1),7
	goto	u400_21
	goto	u400_20
u400_21:
	goto	i1l3420
u400_20:
	line	20
	
i1l3416:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
i1l3418:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
i1l3420:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
i1l3422:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u401_21
	goto	u401_20
u401_21:
	goto	i1l3442
u401_20:
	line	25
	
i1l3424:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	i1l3428
	line	27
	
i1l3426:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
i1l3428:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u402_21
	goto	u402_20
u402_21:
	goto	i1l3426
u402_20:
	line	31
	
i1l3430:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
i1l3432:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u403_25
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u403_25:
	skipc
	goto	u403_21
	goto	u403_20
u403_21:
	goto	i1l3438
u403_20:
	line	33
	
i1l3434:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
i1l3436:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
i1l3438:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
i1l3440:	
	decfsz	(___awdiv@counter),f
	goto	u404_21
	goto	u404_20
u404_21:
	goto	i1l3430
u404_20:
	line	39
	
i1l3442:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u405_21
	goto	u405_20
u405_21:
	goto	i1l3446
u405_20:
	line	40
	
i1l3444:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
i1l3446:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
i1l1014:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
