opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ChargeProcess_Slot
	FNCALL	_main,_Do_AdcSample
	FNCALL	_main,_Do_NtcRead
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_System_Init
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_Do_NtcRead,_Read_Temperature
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Do_AdcSample,_ADC_Sample
	FNCALL	_Do_AdcSample,___bmul
	FNCALL	_ChargeProcess_Slot,_Detect_BatteryType
	FNCALL	_ChargeProcess_Slot,___bmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_CCCV_Control
	FNCALL	_Isr_Timer,_Charging_Control
	FNCALL	_Isr_Timer,_Led_BlinkProcess
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Update_LED_Slot
	FNCALL	_Update_LED_Slot,i1___bmul
	FNCALL	_Led_BlinkProcess,i1___bmul
	FNCALL	_Charging_Control,i1___bmul
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,i1___bmul
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_temperature
psect	idataBANK0,class=CODE,space=0,delta=2,noexec
global __pidataBANK0
__pidataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	14

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

	global	_s_adcChannels
psect	strings,class=STRING,delta=2,noexec
global __pstrings
__pstrings:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 1 byte each
stringcode:stringdir:
movlw high(stringdir)
movwf pclath
movf fsr,w
incf fsr
	addwf pc
	global __stringbase
__stringbase:
	retlw	0
psect	strings
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	39
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_scanIndex
	global	_g_ntcPrintFlag
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_adcBusy
	global	_g_doAdcSample
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_powerOnTimer
	global	_g_cvIntegral
	global	_g_tempProtect
	global	_g_tempPhase
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_scanPhase
	global	_test_adc
	global	_adresult
	global	_g_slot1
	global	_g_slot0
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_GIE
_GIE	set	0x5F
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RC4
_RC4	set	0x834
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC5
_RC5	set	0x835
	global	_RC3
_RC3	set	0x833
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	strings
	
STR_23:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	strings
	
STR_24:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	strings
	
STR_13:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	strings
	
STR_19:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	strings
	
STR_11:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	strings
	
STR_6:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_10:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	strings
	
STR_21:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	strings
	
STR_16:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	strings
	
STR_20:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	strings
	
STR_15:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	strings
	
STR_14:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	strings
	
STR_5:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	strings
	
STR_17:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	strings
	
STR_18:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	strings
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	strings
	
STR_12:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	strings
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	strings
STR_7	equ	STR_2+0
STR_8	equ	STR_3+0
STR_9	equ	STR_24+7
STR_22	equ	STR_24+7
; #config settings
	file	"SC8P096_timer_C.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_g_ntcPrintFlag:
       ds      1

_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

_g_adcBusy:
       ds      1

_g_doAdcSample:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_g_scanIndex:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_powerOnTimer:
       ds      2

_g_cvIntegral:
       ds      2

_g_tempProtect:
       ds      1

_g_tempPhase:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_scanPhase:
       ds      1

_test_adc:
       ds      1

_adresult:
       ds      2

psect	dataBANK0,class=BANK0,space=1,noexec
global __pdataBANK0
__pdataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	14
_g_temperature:
       ds      2

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slot0:
       ds      72

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot1:
       ds      72

	file	"SC8P096_timer_C.as"
	line	#
; Initialize objects allocated to BANK0
	global __pidataBANK0
psect cinit,class=CODE,delta=2,merge=1
	fcall	__pidataBANK0+0		;fetch initializer
	movwf	__pdataBANK0+0&07fh		
	fcall	__pidataBANK0+1		;fetch initializer
	movwf	__pdataBANK0+1&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+013h)
	fcall	clear_ram0
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x0
	ds	4
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x4
	ds	1
??_Read_Temperature:	; 1 bytes @ 0x5
??_Print_SystemStatus:	; 1 bytes @ 0x5
	ds	4
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x9
	ds	4
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0xD
	global	_Print_SystemStatus$972
_Print_SystemStatus$972:	; 2 bytes @ 0xD
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0xF
	global	_Print_SystemStatus$973
_Print_SystemStatus$973:	; 2 bytes @ 0xF
	ds	2
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x11
	ds	4
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x15
	ds	1
	global	_Print_SystemStatus$321
_Print_SystemStatus$321:	; 1 bytes @ 0x16
	ds	1
	global	_Print_SystemStatus$333
_Print_SystemStatus$333:	; 1 bytes @ 0x17
	ds	1
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x18
	ds	2
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0x1A
	ds	4
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0x1E
	ds	4
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x22
	ds	2
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x24
	ds	1
??_main:	; 1 bytes @ 0x25
	ds	2
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Update_LED_Slot:	; 1 bytes @ 0x0
?_Charging_Control:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Led_BlinkProcess:	; 1 bytes @ 0x0
?_uart_send_string:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_ChargeProcess_Slot:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Do_AdcSample:	; 1 bytes @ 0x0
?_Do_NtcRead:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?i1___bmul:	; 1 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	i1___bmul@multiplicand
i1___bmul@multiplicand:	; 1 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	ds	1
??i1___bmul:	; 1 bytes @ 0x1
	global	i1___bmul@multiplier
i1___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
	global	i1___bmul@product
i1___bmul@product:	; 1 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_Update_LED_Slot:	; 1 bytes @ 0x3
??_Charging_Control:	; 1 bytes @ 0x3
??_Led_BlinkProcess:	; 1 bytes @ 0x3
	global	Charging_Control@chargeB1_6
Charging_Control@chargeB1_6:	; 1 bytes @ 0x3
	global	Update_LED_Slot@idx
Update_LED_Slot@idx:	; 1 bytes @ 0x3
	ds	1
??___awdiv:	; 1 bytes @ 0x4
	global	Charging_Control@chargeB7_12
Charging_Control@chargeB7_12:	; 1 bytes @ 0x4
	global	Update_LED_Slot@p
Update_LED_Slot@p:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	ds	1
	global	_Charging_Control$426
_Charging_Control$426:	; 1 bytes @ 0x5
	global	_Led_BlinkProcess$494
_Led_BlinkProcess$494:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	ds	1
	global	Charging_Control@s
Charging_Control@s:	; 1 bytes @ 0x6
	global	_Led_BlinkProcess$505
_Led_BlinkProcess$505:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	1
	global	Charging_Control@i
Charging_Control@i:	; 1 bytes @ 0x7
	global	_Led_BlinkProcess$516
_Led_BlinkProcess$516:	; 1 bytes @ 0x7
	ds	1
??_CCCV_Control:	; 1 bytes @ 0x8
	global	_Led_BlinkProcess$527
_Led_BlinkProcess$527:	; 1 bytes @ 0x8
	ds	1
	global	_Led_BlinkProcess$538
_Led_BlinkProcess$538:	; 1 bytes @ 0x9
	ds	1
	global	Led_BlinkProcess@i
Led_BlinkProcess@i:	; 1 bytes @ 0xA
	ds	1
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x0
	ds	2
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x2
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x3
	ds	1
	global	_CCCV_Control$443
_CCCV_Control$443:	; 1 bytes @ 0x4
	ds	1
	global	_CCCV_Control$454
_CCCV_Control$454:	; 1 bytes @ 0x5
	ds	1
	global	_CCCV_Control$465
_CCCV_Control$465:	; 1 bytes @ 0x6
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x7
	ds	2
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0x9
	ds	2
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0xB
	ds	2
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0xD
	ds	1
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0xE
	ds	1
??_Isr_Timer:	; 1 bytes @ 0xF
	ds	4
??_AD_Init:	; 1 bytes @ 0x13
??_uart_init:	; 1 bytes @ 0x13
?_ADC_Sample:	; 1 bytes @ 0x13
??_uart_send_char:	; 1 bytes @ 0x13
?_Detect_BatteryType:	; 1 bytes @ 0x13
?___bmul:	; 1 bytes @ 0x13
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x13
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x13
	global	?___lmul
?___lmul:	; 4 bytes @ 0x13
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x13
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x13
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x13
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x13
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x13
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x13
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x14
??___bmul:	; 1 bytes @ 0x14
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x14
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x14
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x15
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x15
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x15
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x15
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x15
	ds	1
??_uart_send_string:	; 1 bytes @ 0x16
??_ChargeProcess_Slot:	; 1 bytes @ 0x16
??_System_Init:	; 1 bytes @ 0x16
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x16
	global	uart_send_string@str
uart_send_string@str:	; 1 bytes @ 0x16
	ds	1
??___lwdiv:	; 1 bytes @ 0x17
??___lwmod:	; 1 bytes @ 0x17
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x17
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x17
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x17
	ds	1
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x18
	global	ChargeProcess_Slot@idx
ChargeProcess_Slot@idx:	; 1 bytes @ 0x18
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x18
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x19
	ds	1
?_uart_send_number:	; 1 bytes @ 0x1A
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x1A
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x1A
	ds	1
??___lmul:	; 1 bytes @ 0x1B
	global	ChargeProcess_Slot@v
ChargeProcess_Slot@v:	; 2 bytes @ 0x1B
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x1B
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x1B
	ds	1
??_uart_send_number:	; 1 bytes @ 0x1C
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x1C
	ds	1
	global	ChargeProcess_Slot@p
ChargeProcess_Slot@p:	; 1 bytes @ 0x1D
	ds	2
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x1F
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x1F
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x1F
	ds	2
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x21
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0x22
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x23
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0x23
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x23
	ds	1
??_Print_NtcTemp:	; 1 bytes @ 0x24
	global	_Print_NtcTemp$970
_Print_NtcTemp$970:	; 2 bytes @ 0x24
	ds	1
??_Do_AdcSample:	; 1 bytes @ 0x25
	global	Do_AdcSample@ch
Do_AdcSample@ch:	; 1 bytes @ 0x25
	ds	1
	global	_Do_AdcSample$284
_Do_AdcSample$284:	; 1 bytes @ 0x26
	global	_Print_NtcTemp$971
_Print_NtcTemp$971:	; 2 bytes @ 0x26
	ds	1
??_Do_NtcRead:	; 1 bytes @ 0x27
??___lldiv:	; 1 bytes @ 0x27
	global	_Do_AdcSample$295
_Do_AdcSample$295:	; 1 bytes @ 0x27
	ds	1
;!
;!Data Sizes:
;!    Strings     152
;!    Constant    12
;!    Data        2
;!    BSS         164
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     11      13
;!    BANK0            80     40      61
;!    BANK1            80     39      39
;!    BANK3            80      0      72
;!    BANK2            80      0      72

;!
;!Pointer List with Targets:
;!
;!    Led_BlinkProcess$538	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Led_BlinkProcess$527	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Led_BlinkProcess$516	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Led_BlinkProcess$505	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Led_BlinkProcess$494	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Update_LED_Slot@p	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    CCCV_Control$465	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    CCCV_Control$454	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    CCCV_Control$443	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Charging_Control$426	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    ChargeProcess_Slot@p	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    uart_send_string@str	PTR const unsigned char  size(1) Largest target is 29
;!		 -> STR_24(CODE[10]), STR_23(CODE[21]), STR_22(CODE[3]), STR_21(CODE[6]), 
;!		 -> STR_20(CODE[6]), STR_19(CODE[7]), STR_18(CODE[5]), STR_17(CODE[5]), 
;!		 -> STR_16(CODE[6]), STR_15(CODE[6]), STR_14(CODE[6]), STR_13(CODE[7]), 
;!		 -> STR_12(CODE[4]), STR_11(CODE[6]), STR_10(CODE[6]), STR_9(CODE[3]), 
;!		 -> STR_8(CODE[4]), STR_7(CODE[2]), STR_6(CODE[6]), STR_5(CODE[5]), 
;!		 -> STR_4(CODE[29]), STR_3(CODE[4]), STR_2(CODE[2]), STR_1(CODE[5]), 
;!
;!    Print_SystemStatus$333	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Print_SystemStatus$321	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Do_AdcSample$295	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!
;!    Do_AdcSample$284	PTR struct . size(1) Largest target is 72
;!		 -> g_slot1(BANK2[72]), g_slot0(BANK3[72]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->_Led_BlinkProcess
;!    _Update_LED_Slot->i1___bmul
;!    _Led_BlinkProcess->i1___bmul
;!    _Charging_Control->i1___bmul
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Do_AdcSample
;!    _main->_Print_NtcTemp
;!    _System_Init->___bmul
;!    _Print_SystemStatus->___lldiv
;!    _Print_NtcTemp->_uart_send_number
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _Read_Temperature->___lldiv
;!    ___lldiv->___lmul
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->___bmul
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    _Isr_Timer->_CCCV_Control
;!
;!Critical Paths under _main in BANK1
;!
;!    _main->_Print_SystemStatus
;!    _Print_SystemStatus->___lldiv
;!    _Do_NtcRead->_Read_Temperature
;!    _Read_Temperature->___lldiv
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 2     2      0   25680
;!                                             37 BANK1      2     2      0
;!                 _ChargeProcess_Slot
;!                       _Do_AdcSample
;!                         _Do_NtcRead
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                        _System_Init
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1902
;!                                             22 BANK0      1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  32    32      0    9044
;!                                              5 BANK1     32    32      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    3965
;!                                             36 BANK0      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     1     1      0     887
;!                                             22 BANK0      1     1      0
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_number                                    10     8      2    2043
;!                                             26 BANK0     10     8      2
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     102
;!                                             19 BANK0      3     3      0
;! ---------------------------------------------------------------------------------
;! (3) ___lwmod                                              5     1      4     378
;!                                             19 BANK0      5     1      4
;! ---------------------------------------------------------------------------------
;! (1) _Do_NtcRead                                           0     0      0    3892
;!                   _Read_Temperature
;! ---------------------------------------------------------------------------------
;! (2) _Read_Temperature                                    12    12      0    3892
;!                                              5 BANK1     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4     647
;!                                             19 BANK0      7     3      4
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8    1077
;!                                             19 BANK0     12     4      8
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8     800
;!                                             31 BANK0      8     0      8
;!                                              0 BANK1      5     5      0
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (1) _Do_AdcSample                                         3     3      0    2357
;!                                             37 BANK0      3     3      0
;!                         _ADC_Sample
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) _ADC_Sample                                          18    17      1     965
;!                                             19 BANK0     18    17      1
;! ---------------------------------------------------------------------------------
;! (1) _ChargeProcess_Slot                                   8     8      0    3633
;!                                             22 BANK0      8     8      0
;!                 _Detect_BatteryType
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1    1276
;!                                             19 BANK0      3     2      1
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     295
;!                                             19 BANK0      2     0      2
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 3
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            4     4      0    4720
;!                                             15 BANK0      4     4      0
;!                       _CCCV_Control
;!                   _Charging_Control
;!                   _Led_BlinkProcess
;!                 _PowerOnLedSequence
;!                    _Update_LED_Slot
;! ---------------------------------------------------------------------------------
;! (5) _Update_LED_Slot                                      2     2      0     737
;!                                              3 COMMON     2     2      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Led_BlinkProcess                                     8     8      0    1186
;!                                              3 COMMON     8     8      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _Charging_Control                                     5     5      0     944
;!                                              3 COMMON     5     5      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _CCCV_Control                                        17    17      0    1853
;!                                              8 COMMON     2     2      0
;!                                              0 BANK0     15    15      0
;!                            ___awdiv
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (6) i1___bmul                                             3     2      1     448
;!                                              0 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (6) ___awdiv                                              8     4      4     428
;!                                              0 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ChargeProcess_Slot
;!     _Detect_BatteryType
;!     ___bmul
;!   _Do_AdcSample
;!     _ADC_Sample
;!     ___bmul
;!   _Do_NtcRead
;!     _Read_Temperature
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!       ___lwdiv
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___lwdiv
;!       ___lwmod
;!       _uart_send_char
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___lwdiv
;!       ___lwmod
;!       _uart_send_char
;!     _uart_send_string
;!       _uart_send_char
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     i1___bmul
;!   _Charging_Control
;!     i1___bmul
;!   _Led_BlinkProcess
;!     i1___bmul
;!   _PowerOnLedSequence
;!   _Update_LED_Slot
;!     i1___bmul
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50      0      48       8       90.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      0      48      10       90.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50     27      27       6       48.8%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     28      3D       4       76.3%
;!BITBANK0            50      0       0       3        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      B       D       1       92.9%
;!BITCOMMON            E      0       1       0        7.1%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     101      12        0.0%
;!ABS                  0      0     101      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 405 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       2       0       0
;;      Totals:         0       0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ChargeProcess_Slot
;;		_Do_AdcSample
;;		_Do_NtcRead
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_System_Init
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	405
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	405
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	408
	
l4112:	
;main.c: 408: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_main+0)^080h+0+1),f
	movlw	241
movwf	((??_main+0)^080h+0),f
	u4627:
decfsz	((??_main+0)^080h+0),f
	goto	u4627
	decfsz	((??_main+0)^080h+0+1),f
	goto	u4627
opt asmopt_pop

	line	409
# 409 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	412
	
l4114:	
;main.c: 412: System_Init();
	fcall	_System_Init
	line	415
	
l4116:	
;main.c: 415: uart_send_string("L1211 Charger V2.1\r\n");
	movlw	(low((((STR_23)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	416
	
l4118:	
;main.c: 416: uart_send_string("Init...\r\n");
	movlw	(low((((STR_24)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	419
;main.c: 419: while(1)
	
l432:	
	line	421
# 421 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	424
	
l4120:	
;main.c: 424: if(g_doAdcSample)
	btfss	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u4581
	goto	u4580
u4581:
	goto	l4128
u4580:
	line	426
	
l4122:	
;main.c: 425: {
;main.c: 426: g_doAdcSample = 0;
	bcf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	line	427
;main.c: 427: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	428
	
l4124:	
;main.c: 428: Do_AdcSample();
	fcall	_Do_AdcSample
	line	432
;main.c: 432: ChargeProcess_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_ChargeProcess_Slot
	line	433
	
l4126:	
;main.c: 433: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	437
	
l4128:	
;main.c: 434: }
;main.c: 437: if(g_doNtcRead)
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u4591
	goto	u4590
u4591:
	goto	l4136
u4590:
	line	439
	
l4130:	
;main.c: 438: {
;main.c: 439: g_doNtcRead = 0;
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	440
;main.c: 440: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	441
	
l4132:	
;main.c: 441: Do_NtcRead();
	fcall	_Do_NtcRead
	line	442
	
l4134:	
;main.c: 442: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	446
	
l4136:	
;main.c: 443: }
;main.c: 446: if(g_printFlag)
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u4601
	goto	u4600
u4601:
	goto	l4142
u4600:
	line	448
	
l4138:	
;main.c: 447: {
;main.c: 448: g_printFlag = 0;
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	449
	
l4140:	
;main.c: 449: Print_SystemStatus();
	fcall	_Print_SystemStatus
	line	453
	
l4142:	
;main.c: 450: }
;main.c: 453: if(g_ntcPrintFlag)
	btfss	(_g_ntcPrintFlag/8),(_g_ntcPrintFlag)&7	;volatile
	goto	u4611
	goto	u4610
u4611:
	goto	l432
u4610:
	line	455
	
l4144:	
;main.c: 454: {
;main.c: 455: g_ntcPrintFlag = 0;
	bcf	(_g_ntcPrintFlag/8),(_g_ntcPrintFlag)&7	;volatile
	line	456
	
l4146:	
;main.c: 456: Print_NtcTemp();
	fcall	_Print_NtcTemp
	goto	l432
	global	start
	ljmp	start
	opt stack 0
	line	459
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 60 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   22[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	60
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	60
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	65
	
l3486:	
# 65 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	66
# 66 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text1
	line	67
	
l3488:	
;main.c: 67: OSCCON = 0x72;
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	71
;main.c: 71: TRISA = 0xF0; PORTA = 0x0F;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	72
;main.c: 72: TRISB = 0x30; PORTB = 0x4F;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	73
;main.c: 73: TRISC = 0x07; PORTC = 0x00;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l3490:	
	clrf	(262)^0100h	;volatile
	line	74
	
l3492:	
;main.c: 74: TRISD = 0xF0; PORTD = 0x0F;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l3494:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	77
	
l3496:	
;main.c: 77: WPUA = 0x00; WPDA = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l3498:	
	clrf	(135)^080h	;volatile
	line	78
	
l3500:	
;main.c: 78: WPUB = 0x00; WPDB = 0x00;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l3502:	
	clrf	(7)	;volatile
	line	79
	
l3504:	
;main.c: 79: WPUC = 0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	80
	
l3506:	
;main.c: 80: WPUD = 0x00;
	clrf	(277)^0100h	;volatile
	line	83
	
l3508:	
;main.c: 83: IOCA = 0x00; IOCB = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l3510:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	86
	
l3512:	
;main.c: 86: CC0CON = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	87
	
l3514:	
;main.c: 87: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	94
	
l3516:	
;main.c: 94: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	95
	
l3518:	
;main.c: 95: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	96
	
l3520:	
;main.c: 96: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	97
	
l3522:	
;main.c: 97: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	100
	
l3524:	
;main.c: 100: AD_Init();
	fcall	_AD_Init
	line	103
	
l3526:	
;main.c: 103: uart_init();
	fcall	_uart_init
	line	110
;main.c: 110: OPTION_REG = 0x00;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	111
	
l3528:	
;main.c: 111: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	112
	
l3530:	
;main.c: 112: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	113
	
l3532:	
;main.c: 113: INTCON = 0xE0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	116
;main.c: 116: g_pwmDuty = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	117
;main.c: 117: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	118
	
l3534:	
;main.c: 118: RC3 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	119
	
l3536:	
;main.c: 119: RC5 = 0;
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	120
	
l3538:	
;main.c: 120: RB6 = 1;
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	121
	
l3540:	
;main.c: 121: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	124
;main.c: 124: for(i = 0; i < 6; i++)
	clrf	(System_Init@i)
	line	126
	
l3546:	
;main.c: 125: {
;main.c: 126: g_slot0[i].state = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	127
;main.c: 127: g_slot0[i].type = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	128
;main.c: 128: g_slot0[i].voltage = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	129
;main.c: 129: g_slot0[i].chargeTimer = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+05h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	130
;main.c: 130: g_slot0[i].blinkTimer = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+07h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	131
;main.c: 131: g_slot0[i].blinkPhase = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+09h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	132
;main.c: 132: g_slot0[i].ledState = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	133
;main.c: 133: g_slot0[i].stableCnt = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+0Ah)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	134
;main.c: 134: g_slot0[i].activatePulseCnt = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+0Bh)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	136
;main.c: 136: g_slot1[i].state = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	137
;main.c: 137: g_slot1[i].type = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	138
;main.c: 138: g_slot1[i].voltage = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	139
;main.c: 139: g_slot1[i].chargeTimer = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+05h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	140
;main.c: 140: g_slot1[i].blinkTimer = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+07h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	141
;main.c: 141: g_slot1[i].blinkPhase = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+09h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	142
;main.c: 142: g_slot1[i].ledState = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	143
;main.c: 143: g_slot1[i].stableCnt = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0Ah)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	144
;main.c: 144: g_slot1[i].activatePulseCnt = 0;
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0Bh)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	124
	
l3548:	
	incf	(System_Init@i),f
	
l3550:	
	movlw	low(06h)
	subwf	(System_Init@i),w
	skipc
	goto	u3721
	goto	u3720
u3721:
	goto	l3546
u3720:
	line	148
	
l337:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
global __ptext2
__ptext2:	;psect for function _uart_init
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_init: []
	line	23
	
l2346:	
;uart_dbg.c: 23: TRISC &= (unsigned char)~0x10;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
;uart_dbg.c: 24: ANSEL2 &= (unsigned char)~0x10;
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
;uart_dbg.c: 25: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l469:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
global __ptext3
__ptext3:	;psect for function _AD_Init
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l2340:	
;adc_drv.c: 25: CC0CON = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
;adc_drv.c: 26: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	27
	
l2342:	
;adc_drv.c: 27: ADCON0 = 0X81;
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l2344:	
;adc_drv.c: 28: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	29
	
l446:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 314 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  bat_mv_long     4   30[BANK1 ] unsigned long 
;;  vx_mv           4   26[BANK1 ] unsigned long 
;;  v               2   24[BANK1 ] unsigned int 
;;  s               1   21[BANK1 ] unsigned char 
;;  pt              4   17[BANK1 ] unsigned long 
;;  vcc_mv          2   34[BANK1 ] unsigned int 
;;  i               1   36[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      24       0       0
;;      Temps:          0       0       8       0       0
;;      Totals:         0       0      32       0       0
;;Total ram usage:       32 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	314
global __ptext4
__ptext4:	;psect for function _Print_SystemStatus
psect	text4
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	314
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	319
	
l3798:	
;main.c: 316: unsigned char i;
;main.c: 317: unsigned int vcc_mv;
;main.c: 319: uart_send_string("\r\n== L1211 12CH CHARGER ==\r\n");
	movlw	(low((((STR_4)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	322
	
l3800:	
;main.c: 322: test_adc = ADC_Sample(31, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	323
	
l3802:	
;main.c: 323: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u4151
	goto	u4150
u4151:
	goto	l3808
u4150:
	line	325
	
l3804:	
;main.c: 324: {
;main.c: 325: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult),w	;volatile
	movwf	(___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@pt+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@pt+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@pt+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@pt)^080h

	line	326
	
l3806:	
;main.c: 326: vcc_mv = (unsigned int)pt;
	movf	(Print_SystemStatus@pt+1)^080h,w
	movwf	(Print_SystemStatus@vcc_mv+1)^080h
	movf	(Print_SystemStatus@pt)^080h,w
	movwf	(Print_SystemStatus@vcc_mv)^080h
	line	327
;main.c: 327: }
	goto	l3810
	line	329
	
l3808:	
;main.c: 328: else
;main.c: 329: vcc_mv = 5000;
	movlw	088h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vcc_mv)^080h
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv)^080h)+1
	line	331
	
l3810:	
;main.c: 331: uart_send_string("VCC=");
	movlw	(low((((STR_5)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	332
	
l3812:	
;main.c: 332: uart_send_number(vcc_mv);
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	333
	
l3814:	
;main.c: 333: uart_send_string("mV T=");
	movlw	(low((((STR_6)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	334
	
l3816:	
;main.c: 334: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$972+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$972)^080h
	
l3818:	
;main.c: 334: uart_send_number(g_temperature / 10U);
	movf	(_Print_SystemStatus$972+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_Print_SystemStatus$972)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	335
	
l3820:	
;main.c: 335: uart_send_string(".");
	movlw	(low((((STR_7)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	336
	
l3822:	
;main.c: 336: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$973+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$973)^080h
	
l3824:	
;main.c: 336: uart_send_number(g_temperature % 10U);
	movf	(_Print_SystemStatus$973+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_Print_SystemStatus$973)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	337
	
l3826:	
;main.c: 337: uart_send_string("C\r\n");
	movlw	(low((((STR_8)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	340
	
l3828:	
;main.c: 340: for(i = 0; i < 12; i++)
	bsf	status, 5	;RP0=1, select bank1
	clrf	(Print_SystemStatus@i)^080h
	line	342
	
l3834:	
;main.c: 341: {
;main.c: 342: unsigned int v = (((unsigned char)(i) < 6) ? &g_slot0[(unsigned char)(i)] : &g_slot1[(unsigned char)(i) - 6U])->voltage;
	movlw	low(06h)
	subwf	(Print_SystemStatus@i)^080h,w
	skipc
	goto	u4161
	goto	u4160
u4161:
	goto	l3838
u4160:
	
l3836:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$321)^080h
	goto	l3840
	
l3838:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$321)^080h
	
l3840:	
	movf	(_Print_SystemStatus$321)^080h,w
	addlw	03h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Print_SystemStatus@v)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)^080h
	line	343
	
l3842:	
;main.c: 343: unsigned char s = (((unsigned char)(i) < 6) ? &g_slot0[(unsigned char)(i)] : &g_slot1[(unsigned char)(i) - 6U])->state;
	movlw	low(06h)
	subwf	(Print_SystemStatus@i)^080h,w
	skipc
	goto	u4171
	goto	u4170
u4171:
	goto	l3846
u4170:
	
l3844:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$333)^080h
	goto	l3848
	
l3846:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$333)^080h
	
l3848:	
	incf	(_Print_SystemStatus$333)^080h,w
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Print_SystemStatus@s)^080h
	line	346
	
l3850:	
;main.c: 346: if(i == 6) uart_send_string("\r\n");
		movlw	6
	xorwf	((Print_SystemStatus@i)^080h),w
	btfss	status,2
	goto	u4181
	goto	u4180
u4181:
	goto	l3854
u4180:
	
l3852:	
	movlw	(low((((STR_9)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	348
	
l3854:	
;main.c: 348: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	349
	
l3856:	
;main.c: 349: uart_send_number((unsigned int)i + 1U);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	350
;main.c: 350: uart_send_char('=');
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	351
	
l3858:	
;main.c: 351: uart_send_number(v);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	357
	
l3860:	
;main.c: 356: {
;main.c: 357: unsigned long vx_mv = (unsigned long)v * (unsigned long)vcc_mv / 4096UL;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vx_mv+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vx_mv+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vx_mv+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vx_mv)^080h

	
l3862:	
	movlw	0Ch
u4195:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3)^080h,f
	rrf	(Print_SystemStatus@vx_mv+2)^080h,f
	rrf	(Print_SystemStatus@vx_mv+1)^080h,f
	rrf	(Print_SystemStatus@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u4195

	line	358
	
l3864:	
;main.c: 358: if(vx_mv + 200U >= (unsigned long)vcc_mv)
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	clrf	((??_Print_SystemStatus+0)^080h+0+2)
	clrf	((??_Print_SystemStatus+0)^080h+0+3)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+4)^080h+0)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	(Print_SystemStatus@vx_mv)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+0,f
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1)^080h,w
	goto	u4200
	goto	u4201
u4200:
	addwf	(??_Print_SystemStatus+4)^080h+1,f
u4201:
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2)^080h,w
	goto	u4202
	goto	u4203
u4202:
	addwf	(??_Print_SystemStatus+4)^080h+2,f
u4203:
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	subwf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u4215
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	subwf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u4215
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	subwf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u4215
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	subwf	0+(??_Print_SystemStatus+4)^080h+0,w
u4215:
	skipc
	goto	u4211
	goto	u4210
u4211:
	goto	l3868
u4210:
	line	360
	
l3866:	
;main.c: 359: {
;main.c: 360: uart_send_string(" OPEN");
	movlw	(low((((STR_10)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	361
;main.c: 361: }
	goto	l3878
	line	364
	
l3868:	
;main.c: 362: else
;main.c: 363: {
;main.c: 364: unsigned long bat_mv_long = 1159UL * vx_mv;
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vx_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)

	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	04h
	movwf	(___lmul@multiplicand+1)
	movlw	087h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long)^080h

	line	365
;main.c: 365: if(bat_mv_long > (647UL * (unsigned long)vcc_mv))
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	02h
	movwf	(___lmul@multiplicand+1)
	movlw	087h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(3+(?___lmul)),w
	skipz
	goto	u4225
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long+2)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(2+(?___lmul)),w
	skipz
	goto	u4225
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(1+(?___lmul)),w
	skipz
	goto	u4225
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(0+(?___lmul)),w
u4225:
	skipnc
	goto	u4221
	goto	u4220
u4221:
	goto	l3878
u4220:
	line	367
	
l3870:	
;main.c: 366: {
;main.c: 367: bat_mv_long = (bat_mv_long - 647UL * (unsigned long)vcc_mv + 1000UL/2UL) / 1000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	bsf	status, 5	;RP0=1, select bank1
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+3)
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)
	movlw	0FDh
	movwf	(___lmul@multiplicand+1)
	movlw	079h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(0+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(Print_SystemStatus@bat_mv_long)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+0)
	movlw	0
	skipnc
	movlw	1
	bcf	status, 5	;RP0=0, select bank0
	addwf	(1+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	clrf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	addwf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	((??_Print_SystemStatus+4)^080h+0+2),w
	clrf	((??_Print_SystemStatus+4)^080h+0+3)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	addwf	(Print_SystemStatus@bat_mv_long+2)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	bcf	status, 5	;RP0=0, select bank0
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	((??_Print_SystemStatus+4)^080h+0+3),w
	addwf	(Print_SystemStatus@bat_mv_long+3)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	0+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+0,f
	movf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	1+(??_Print_SystemStatus+4)^080h+0,w
	goto	u4230
	goto	u4231
u4230:
	addwf	(??_Print_SystemStatus+0)^080h+1,f
u4231:
	movf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	2+(??_Print_SystemStatus+4)^080h+0,w
	goto	u4232
	goto	u4233
u4232:
	addwf	(??_Print_SystemStatus+0)^080h+2,f
u4233:
	movf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incf	3+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long)^080h

	line	368
	
l3872:	
;main.c: 368: uart_send_string(" BAT(");
	movlw	(low((((STR_11)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	369
	
l3874:	
;main.c: 369: uart_send_number((unsigned int)bat_mv_long);
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	370
	
l3876:	
;main.c: 370: uart_send_string("mV)");
	movlw	(low((((STR_12)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	377
	
l3878:	
;main.c: 371: }
;main.c: 373: }
;main.c: 374: }
;main.c: 377: uart_send_char(' ');
	movlw	low(020h)
	fcall	_uart_send_char
	line	378
;main.c: 378: switch(s)
	goto	l3900
	line	380
	
l3880:	
	movlw	(low((((STR_13)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3902
	line	381
	
l3882:	
	movlw	(low((((STR_14)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3902
	line	382
	
l3884:	
	movlw	(low((((STR_15)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3902
	line	383
	
l3886:	
	movlw	(low((((STR_16)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3902
	line	384
	
l3888:	
	movlw	(low((((STR_17)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3902
	line	385
	
l3890:	
	movlw	(low((((STR_18)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3902
	line	386
	
l3892:	
	movlw	(low((((STR_19)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3902
	line	387
	
l3894:	
	movlw	(low((((STR_20)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3902
	line	388
	
l3896:	
	movlw	(low((((STR_21)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	goto	l3902
	line	378
	
l3900:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@s)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 8, Range of values is 0 to 7
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           25    13 (average)
; direct_byte           32     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l3880
	xorlw	1^0	; case 1
	skipnz
	goto	l3882
	xorlw	2^1	; case 2
	skipnz
	goto	l3884
	xorlw	3^2	; case 3
	skipnz
	goto	l3886
	xorlw	4^3	; case 4
	skipnz
	goto	l3888
	xorlw	5^4	; case 5
	skipnz
	goto	l3890
	xorlw	6^5	; case 6
	skipnz
	goto	l3892
	xorlw	7^6	; case 7
	skipnz
	goto	l3894
	goto	l3896
	opt asmopt_pop

	line	340
	
l3902:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(Print_SystemStatus@i)^080h,f
	
l3904:	
	movlw	low(0Ch)
	subwf	(Print_SystemStatus@i)^080h,w
	skipc
	goto	u4241
	goto	u4240
u4241:
	goto	l3834
u4240:
	line	391
	
l3906:	
;main.c: 390: }
;main.c: 391: uart_send_string("\r\n");
	movlw	(low((((STR_22)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	392
	
l427:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 299 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	299
global __ptext5
__ptext5:	;psect for function _Print_NtcTemp
psect	text5
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	299
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	301
	
l3788:	
;main.c: 301: uart_send_string("NTC=");
	movlw	(low((((STR_1)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	302
	
l3790:	
;main.c: 302: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$970+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$970)
	
l3792:	
;main.c: 302: uart_send_number(g_temperature / 10U);
	movf	(_Print_NtcTemp$970+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$970),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	303
	
l3794:	
;main.c: 303: uart_send_string(".");
	movlw	(low((((STR_2)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	304
	
l3796:	
;main.c: 304: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	movwf	(_Print_NtcTemp$971+1)
	movf	(0+(?___lwmod)),w
	movwf	(_Print_NtcTemp$971)
;main.c: 304: uart_send_number(g_temperature % 10U);
	movf	(_Print_NtcTemp$971+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$971),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	305
;main.c: 305: uart_send_string("C\r\n");
	movlw	(low((((STR_3)-__stringbase)|8000h)))&0ffh
	fcall	_uart_send_string
	line	306
	
l397:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             1    wreg     PTR const unsigned char 
;;		 -> STR_24(10), STR_23(21), STR_22(3), STR_21(6), 
;;		 -> STR_20(6), STR_19(7), STR_18(5), STR_17(5), 
;;		 -> STR_16(6), STR_15(6), STR_14(6), STR_13(7), 
;;		 -> STR_12(4), STR_11(6), STR_10(6), STR_9(3), 
;;		 -> STR_8(4), STR_7(2), STR_6(6), STR_5(5), 
;;		 -> STR_4(29), STR_3(4), STR_2(2), STR_1(5), 
;; Auto vars:     Size  Location     Type
;;  str             1   22[BANK0 ] PTR const unsigned char 
;;		 -> STR_24(10), STR_23(21), STR_22(3), STR_21(6), 
;;		 -> STR_20(6), STR_19(7), STR_18(5), STR_17(5), 
;;		 -> STR_16(6), STR_15(6), STR_14(6), STR_13(7), 
;;		 -> STR_12(4), STR_11(6), STR_10(6), STR_9(3), 
;;		 -> STR_8(4), STR_7(2), STR_6(6), STR_5(5), 
;;		 -> STR_4(29), STR_3(4), STR_2(2), STR_1(5), 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
global __ptext6
__ptext6:	;psect for function _uart_send_string
psect	text6
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;uart_send_string@str stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	line	63
	
l3436:	
;uart_dbg.c: 63: while(*str != '\0')
	goto	l3442
	line	65
	
l3438:	
;uart_dbg.c: 64: {
;uart_dbg.c: 65: uart_send_char(*str++);
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringdir
	fcall	_uart_send_char
	
l3440:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(uart_send_string@str),f
	line	66
# 66 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
clrwdt ;# 
psect	text6
	line	63
	
l3442:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringdir
	xorlw	0
	skipz
	goto	u3661
	goto	u3660
u3661:
	goto	l3438
u3660:
	line	68
	
l482:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2   26[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6   28[BANK0 ] unsigned char [6]
;;  j               1   35[BANK0 ] unsigned char 
;;  i               1   34[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      10       0       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext7
__ptext7:	;psect for function _uart_send_number
psect	text7
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 2
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l3444:	
;uart_dbg.c: 79: unsigned char buf[6];
;uart_dbg.c: 80: unsigned char i = 0;
	clrf	(uart_send_number@i)
	line	84
	
l3446:	
;uart_dbg.c: 81: unsigned char j;
;uart_dbg.c: 84: if(num == 0)
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u3671
	goto	u3670
u3671:
	goto	l3458
u3670:
	line	86
	
l3448:	
;uart_dbg.c: 85: {
;uart_dbg.c: 86: uart_send_char('0');
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l486
	line	93
	
l3452:	
;uart_dbg.c: 92: {
;uart_dbg.c: 93: buf[i++] = '0' + (num % 10);
	movf	(uart_send_number@i),w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwmod@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank0
	movwf	indf
	
l3454:	
	incf	(uart_send_number@i),f
	line	94
	
l3456:	
;uart_dbg.c: 94: num /= 10;
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(uart_send_number@num+1)
	movf	(0+(?___lwdiv)),w
	movwf	(uart_send_number@num)
	line	91
	
l3458:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u3681
	goto	u3680
u3681:
	goto	l3452
u3680:
	line	98
	
l3460:	
;uart_dbg.c: 95: }
;uart_dbg.c: 98: for(j = i; j > 0; j--)
	movf	(uart_send_number@i),w
	movwf	(uart_send_number@j)
	
l3462:	
	movf	((uart_send_number@j)),w
	btfss	status,2
	goto	u3691
	goto	u3690
u3691:
	goto	l3466
u3690:
	goto	l486
	line	99
	
l3466:	
;uart_dbg.c: 99: uart_send_char(buf[(unsigned char)(j - 1)]);
	movf	(uart_send_number@j),w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l3468:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decf	(uart_send_number@j),f
	goto	l3462
	line	100
	
l486:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1   20[BANK0 ] unsigned char 
;;  i               1   21[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext8
__ptext8:	;psect for function _uart_send_char
psect	text8
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_char: [wreg+status,2+status,0]
;uart_send_char@c stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_char@c)
	line	38
	
l3290:	
;uart_dbg.c: 37: unsigned char i;
;uart_dbg.c: 38: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	39
;uart_dbg.c: 39: RC4 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l3292:	
;uart_dbg.c: 40: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u4637:
decfsz	(??_uart_send_char+0)+0,f
	goto	u4637
	nop2
opt asmopt_pop

	line	41
	
l3294:	
;uart_dbg.c: 41: for(i = 0; i < 8; i++)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(uart_send_char@i)
	line	42
	
l472:	
	line	43
;uart_dbg.c: 42: {
;uart_dbg.c: 43: if(c & 0x01)
	btfss	(uart_send_char@c),(0)&7
	goto	u3381
	goto	u3380
u3381:
	goto	l474
u3380:
	line	44
	
l3300:	
;uart_dbg.c: 44: RC4 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l3302
	line	45
	
l474:	
	line	46
;uart_dbg.c: 45: else
;uart_dbg.c: 46: RC4 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l3302:	
;uart_dbg.c: 47: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u4647:
decfsz	(??_uart_send_char+0)+0,f
	goto	u4647
	nop2
opt asmopt_pop

	line	48
	
l3304:	
;uart_dbg.c: 48: c >>= 1;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rrf	(uart_send_char@c),f
	line	41
	
l3306:	
	incf	(uart_send_char@i),f
	
l3308:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u3391
	goto	u3390
u3391:
	goto	l472
u3390:
	
l473:	
	line	50
;uart_dbg.c: 49: }
;uart_dbg.c: 50: RC4 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l3310:	
;uart_dbg.c: 51: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u4657:
decfsz	(??_uart_send_char+0)+0,f
	goto	u4657
	nop2
opt asmopt_pop

	line	52
	
l3312:	
;uart_dbg.c: 52: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l476:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   19[BANK0 ] unsigned int 
;;  dividend        2   21[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1   23[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   19[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       5       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext9
__ptext9:	;psect for function ___lwmod
psect	text9
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l3378:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u3511
	goto	u3510
u3511:
	goto	l3394
u3510:
	line	14
	
l3380:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l3384
	line	16
	
l3382:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l3384:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u3521
	goto	u3520
u3521:
	goto	l3382
u3520:
	line	20
	
l3386:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u3535
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u3535:
	skipc
	goto	u3531
	goto	u3530
u3531:
	goto	l3390
u3530:
	line	21
	
l3388:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l3390:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l3392:	
	decfsz	(___lwmod@counter),f
	goto	u3541
	goto	u3540
u3541:
	goto	l3386
u3540:
	line	25
	
l3394:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1051:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	_Do_NtcRead

;; *************** function _Do_NtcRead *****************
;; Defined at:
;;		line 287 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Read_Temperature
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	287
global __ptext10
__ptext10:	;psect for function _Do_NtcRead
psect	text10
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	287
	global	__size_of_Do_NtcRead
	__size_of_Do_NtcRead	equ	__end_of_Do_NtcRead-_Do_NtcRead
	
_Do_NtcRead:	
;incstack = 0
	opt	stack 2
; Regs used in _Do_NtcRead: [wreg+status,2+status,0+pclath+cstack]
	line	291
	
l3786:	
;main.c: 291: Read_Temperature();
	fcall	_Read_Temperature
	line	293
	
l394:	
	return
	opt stack 0
GLOBAL	__end_of_Do_NtcRead
	__end_of_Do_NtcRead:
	signat	_Do_NtcRead,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 31 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4    9[BANK1 ] unsigned long 
;;  temp_x10        2   15[BANK1 ] unsigned int 
;;  ntcVal          2   13[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   60[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Do_NtcRead
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	31
global __ptext11
__ptext11:	;psect for function _Read_Temperature
psect	text11
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	31
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 2
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	37
	
l3398:	
;charge_mgr.c: 33: unsigned int ntcVal;
;charge_mgr.c: 34: unsigned int temp_x10;
;charge_mgr.c: 37: test_adc = ADC_Sample(18, 0);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	38
	
l3400:	
;charge_mgr.c: 38: if(0xA5 != test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u3551
	goto	u3550
u3551:
	goto	l3404
u3550:
	goto	l499
	line	41
	
l3404:	
;charge_mgr.c: 41: ntcVal = adresult;
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal)^080h
	line	44
;charge_mgr.c: 44: if(ntcVal < 100 || ntcVal > 3996)
	movlw	0
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u3561
	goto	u3560
u3561:
	goto	l499
u3560:
	
l3406:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u3571
	goto	u3570
u3571:
	goto	l3408
u3570:
	goto	l499
	line	51
	
l3408:	
;charge_mgr.c: 49: {
;charge_mgr.c: 50: unsigned long rt;
;charge_mgr.c: 51: rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	010h
	movwf	(___lldiv@divisor+1)
	movlw	0
	movwf	(___lldiv@divisor)

	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0)
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0+1)
	clrf	((??_Read_Temperature+0)^080h+0+2)
	clrf	((??_Read_Temperature+0)^080h+0+3)
	movf	0+(??_Read_Temperature+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lldiv@divisor),f
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)^080h+0,w
	goto	u3585
	goto	u3586
u3585:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lldiv@divisor+1),f
u3586:
	bsf	status, 5	;RP0=1, select bank1
	movf	2+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)^080h+0,w
	goto	u3587
	goto	u3588
u3587:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lldiv@divisor+2),f
u3588:
	bsf	status, 5	;RP0=1, select bank1
	movf	3+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)^080h+0,w
	goto	u3589
	goto	u3580
u3589:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lldiv@divisor+3),f
u3580:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 5	;RP0=0, select bank0

	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@ntcVal)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@ntcVal+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	027h
	movwf	(___lmul@multiplicand+1)
	movlw	010h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@rt+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@rt+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@rt+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@rt)^080h

	line	55
	
l3410:	
;charge_mgr.c: 55: if(rt >= 10000UL)
		movf	(Read_Temperature@rt+3)^080h,w
	btfss	status,2
	goto	u3590
	movf	(Read_Temperature@rt+2)^080h,w
	btfss	status,2
	goto	u3590
	movlw	39
	subwf	(Read_Temperature@rt+1)^080h,w
	skipz
	goto	u3593
	movlw	16
	subwf	(Read_Temperature@rt)^080h,w
	skipz
	goto	u3593
u3593:
	btfss	status,0
	goto	u3591
	goto	u3590

u3591:
	goto	l3416
u3590:
	line	56
	
l3412:	
;charge_mgr.c: 56: temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l3414:	
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0F0h
	bsf	status, 5	;RP0=1, select bank1
	movwf	((??_Read_Temperature+0)^080h+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)^080h+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+3)
	movf	(Read_Temperature@rt)^080h,w
	addwf	(??_Read_Temperature+0)^080h+0,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+1)^080h,w
	goto	u3600
	goto	u3601
u3600:
	addwf	(??_Read_Temperature+0)^080h+1,f
u3601:
	movf	(Read_Temperature@rt+2)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+2)^080h,w
	goto	u3602
	goto	u3603
u3602:
	addwf	(??_Read_Temperature+0)^080h+2,f
u3603:
	movf	(Read_Temperature@rt+3)^080h,w
	skipnc
	incf	(Read_Temperature@rt+3)^080h,w
	addwf	(??_Read_Temperature+0)^080h+3,f
	movf	3+(??_Read_Temperature+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	2+(??_Read_Temperature+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(??_Read_Temperature+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(??_Read_Temperature+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Read_Temperature@temp_x10)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	skipc
	decf	(Read_Temperature@temp_x10+1)^080h,f
	subwf	(Read_Temperature@temp_x10+1)^080h,f
	goto	l3420
	line	58
	
l3416:	
;charge_mgr.c: 57: else
;charge_mgr.c: 58: temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0
	movwf	(___lmul@multiplier+3)
	movlw	0
	movwf	(___lmul@multiplier+2)
	movlw	027h
	movwf	(___lmul@multiplier+1)
	movlw	010h
	movwf	(___lmul@multiplier)

	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@rt)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lmul@multiplier),f
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@rt+1)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+1)^080h,w
	goto	u3615
	goto	u3616
u3615:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lmul@multiplier+1),f
u3616:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@rt+2)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+2)^080h,w
	goto	u3617
	goto	u3618
u3617:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lmul@multiplier+2),f
u3618:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@rt+3)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+3)^080h,w
	goto	u3619
	goto	u3610
u3619:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lmul@multiplier+3),f
u3610:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 5	;RP0=0, select bank0

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@temp_x10+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@temp_x10)^080h
	
l3418:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10)^080h,f
	skipnc
	incf	(Read_Temperature@temp_x10+1)^080h,f
	line	61
	
l3420:	
;charge_mgr.c: 61: if(temp_x10 < 100U) temp_x10 = 100U;
	movlw	0
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipnc
	goto	u3621
	goto	u3620
u3621:
	goto	l505
u3620:
	
l3422:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l505:	
	line	62
;charge_mgr.c: 62: if(temp_x10 > 750U) temp_x10 = 750U;
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipc
	goto	u3631
	goto	u3630
u3631:
	goto	l506
u3630:
	
l3424:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)^080h
	movlw	02h
	movwf	((Read_Temperature@temp_x10)^080h)+1
	
l506:	
	line	65
;charge_mgr.c: 63: }
;charge_mgr.c: 65: g_temperature = temp_x10;
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature)
	line	68
	
l3426:	
;charge_mgr.c: 68: if((temp_x10 / 10U) >= 60)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u3641
	goto	u3640
u3641:
	goto	l3430
u3640:
	line	69
	
l3428:	
;charge_mgr.c: 69: g_tempProtect = 1;
	clrf	(_g_tempProtect)
	incf	(_g_tempProtect),f
	goto	l499
	line	70
	
l3430:	
;charge_mgr.c: 70: else if((temp_x10 / 10U) <= 50)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u3651
	goto	u3650
u3651:
	goto	l499
u3650:
	line	71
	
l3432:	
;charge_mgr.c: 71: g_tempProtect = 0;
	clrf	(_g_tempProtect)
	line	74
	
l499:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   19[BANK0 ] unsigned int 
;;  dividend        2   21[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2   24[BANK0 ] unsigned int 
;;  counter         1   23[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   19[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       7       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext12
__ptext12:	;psect for function ___lwdiv
psect	text12
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l3352:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l3354:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u3471
	goto	u3470
u3471:
	goto	l3374
u3470:
	line	16
	
l3356:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l3360
	line	18
	
l3358:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l3360:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u3481
	goto	u3480
u3481:
	goto	l3358
u3480:
	line	22
	
l3362:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l3364:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u3495
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u3495:
	skipc
	goto	u3491
	goto	u3490
u3491:
	goto	l3370
u3490:
	line	24
	
l3366:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l3368:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l3370:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l3372:	
	decfsz	(___lwdiv@counter),f
	goto	u3501
	goto	u3500
u3501:
	goto	l3362
u3500:
	line	30
	
l3374:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l1041:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4   19[BANK0 ] unsigned long 
;;  multiplicand    4   23[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4   27[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4   19[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext13
__ptext13:	;psect for function ___lmul
psect	text13
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l3314:	
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l713:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u3401
	goto	u3400
u3401:
	goto	l3318
u3400:
	line	122
	
l3316:	
	movf	(___lmul@multiplicand),w
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3411
	addwf	(___lmul@product+1),f
u3411:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3412
	addwf	(___lmul@product+2),f
u3412:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3413
	addwf	(___lmul@product+3),f
u3413:

	line	123
	
l3318:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l3320:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u3421
	goto	u3420
u3421:
	goto	l713
u3420:
	line	128
	
l3322:	
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l716:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4   31[BANK0 ] unsigned long 
;;  dividend        4   35[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4    0[BANK1 ] unsigned long 
;;  counter         1    4[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4   31[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       0       5       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       8       5       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext14
__ptext14:	;psect for function ___lldiv
psect	text14
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l3326:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___lldiv@quotient)^080h
	clrf	(___lldiv@quotient+1)^080h
	clrf	(___lldiv@quotient+2)^080h
	clrf	(___lldiv@quotient+3)^080h
	line	15
	
l3328:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u3431
	goto	u3430
u3431:
	goto	l3348
u3430:
	line	16
	
l3330:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___lldiv@counter)^080h
	incf	(___lldiv@counter)^080h,f
	line	17
	goto	l3334
	line	18
	
l3332:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	bsf	status, 5	;RP0=1, select bank1
	incf	(___lldiv@counter)^080h,f
	line	17
	
l3334:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u3441
	goto	u3440
u3441:
	goto	l3332
u3440:
	line	22
	
l3336:	
	clrc
	bsf	status, 5	;RP0=1, select bank1
	rlf	(___lldiv@quotient)^080h,f
	rlf	(___lldiv@quotient+1)^080h,f
	rlf	(___lldiv@quotient+2)^080h,f
	rlf	(___lldiv@quotient+3)^080h,f
	line	23
	
l3338:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u3455
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u3455
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u3455
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u3455:
	skipc
	goto	u3451
	goto	u3450
u3451:
	goto	l3344
u3450:
	line	24
	
l3340:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l3342:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(___lldiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l3344:	
	clrc
	bcf	status, 5	;RP0=0, select bank0
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l3346:	
	bsf	status, 5	;RP0=1, select bank1
	decfsz	(___lldiv@counter)^080h,f
	goto	u3461
	goto	u3460
u3461:
	goto	l3336
u3460:
	line	30
	
l3348:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lldiv@quotient+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lldiv+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lldiv@quotient+2)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lldiv+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lldiv@quotient+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lldiv+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lldiv@quotient)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lldiv)

	line	31
	
l988:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_Do_AdcSample

;; *************** function _Do_AdcSample *****************
;; Defined at:
;;		line 269 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  ch              1   37[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	269
global __ptext15
__ptext15:	;psect for function _Do_AdcSample
psect	text15
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	269
	global	__size_of_Do_AdcSample
	__size_of_Do_AdcSample	equ	__end_of_Do_AdcSample-_Do_AdcSample
	
_Do_AdcSample:	
;incstack = 0
	opt	stack 3
; Regs used in _Do_AdcSample: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	271
	
l3762:	
;main.c: 271: unsigned char ch = s_adcChannels[g_scanIndex];
	movf	(_g_scanIndex),w
	addlw	low((((_s_adcChannels)-__stringbase)|8000h))
	movwf	fsr0
	fcall	stringdir
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Do_AdcSample@ch)
	line	272
	
l3764:	
;main.c: 272: test_adc = ADC_Sample(ch, 0);
	clrf	(ADC_Sample@adldo)
	movf	(Do_AdcSample@ch),w
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	273
	
l3766:	
;main.c: 273: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u4121
	goto	u4120
u4121:
	goto	l3776
u4120:
	line	274
	
l3768:	
;main.c: 274: (((unsigned char)(g_scanIndex) < 6) ? &g_slot0[(unsigned char)(g_scanIndex)] : &g_slot1[(unsigned char)(g_scanIndex) - 6U])->voltage = adresult;
	movlw	low(06h)
	subwf	(_g_scanIndex),w	;volatile
	skipc
	goto	u4131
	goto	u4130
u4131:
	goto	l3772
u4130:
	
l3770:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Do_AdcSample$284)
	goto	l3774
	
l3772:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Do_AdcSample$284)
	
l3774:	
	movf	(_Do_AdcSample$284),w
	addlw	03h
	movwf	fsr0
	movf	(_adresult),w	;volatile
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_adresult+1),w	;volatile
	movwf	indf
	goto	l3784
	line	276
	
l3776:	
;main.c: 275: else
;main.c: 276: (((unsigned char)(g_scanIndex) < 6) ? &g_slot0[(unsigned char)(g_scanIndex)] : &g_slot1[(unsigned char)(g_scanIndex) - 6U])->voltage = 0;
	movlw	low(06h)
	subwf	(_g_scanIndex),w	;volatile
	skipc
	goto	u4141
	goto	u4140
u4141:
	goto	l3780
u4140:
	
l3778:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Do_AdcSample$295)
	goto	l3782
	
l3780:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Do_AdcSample$295)
	
l3782:	
	movf	(_Do_AdcSample$295),w
	addlw	03h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	278
	
l3784:	
;main.c: 278: g_scanPhase = 1;
	movlw	low(01h)
	movwf	(_g_scanPhase)	;volatile
	line	279
	
l391:	
	return
	opt stack 0
GLOBAL	__end_of_Do_AdcSample
	__end_of_Do_AdcSample:
	signat	_Do_AdcSample,89
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1   19[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1   25[BANK0 ] unsigned char 
;;  j               1   24[BANK0 ] unsigned char 
;;  adsum           4   27[BANK0 ] volatile unsigned long 
;;  ad_temp         2   35[BANK0 ] volatile unsigned int 
;;  admax           2   33[BANK0 ] volatile unsigned int 
;;  admin           2   31[BANK0 ] volatile unsigned int 
;;  i               1   26[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      18       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext16
__ptext16:	;psect for function _ADC_Sample
psect	text16
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	movwf	(ADC_Sample@adch)
	line	51
	
l3224:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	52
	
l3226:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	58
	
l3228:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u3231
	goto	u3230
u3231:
	goto	l3234
u3230:
	
l3230:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u3241
	goto	u3240
u3241:
	goto	l3234
u3240:
	line	60
	
l3232:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u4667:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u4667
	nop
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	l3236
	line	64
	
l3234:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	bcf	status, 5	;RP0=0, select bank0
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	67
	
l3236:	
;adc_drv.c: 67: if(adch & 0x10)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(ADC_Sample@adch),(4)&7
	goto	u3251
	goto	u3250
u3251:
	goto	l451
u3250:
	line	69
	
l3238:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l3240:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(ADC_Sample@adch),f
	line	71
;adc_drv.c: 71: }
	goto	l3242
	line	72
	
l451:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l3242:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@i)
	line	79
	
l3248:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(ADC_Sample@adch),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u3265:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u3265
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l3250:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	5
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u4677:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u4677
	nop2
opt asmopt_pop

	line	81
	
l3252:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l3254:	
;adc_drv.c: 84: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	l455
	
l456:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u3271
	goto	u3270
u3271:
	goto	l455
u3270:
	line	89
	
l3256:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	l458
	line	90
	
l455:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u3281
	goto	u3280
u3281:
	goto	l456
u3280:
	line	93
	
l3260:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
l3262:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
l3264:	
;adc_drv.c: 96: if(0 == admax)
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u3291
	goto	u3290
u3291:
	goto	l3268
u3290:
	line	98
	
l3266:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	100
;adc_drv.c: 100: }
	goto	l461
	line	102
	
l3268:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u3305
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u3305:
	skipnc
	goto	u3301
	goto	u3300
u3301:
	goto	l3272
u3300:
	line	103
	
l3270:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	l461
	line	105
	
l3272:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u3315
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u3315:
	skipnc
	goto	u3311
	goto	u3310
u3311:
	goto	l461
u3310:
	line	106
	
l3274:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	108
	
l461:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3321
	addwf	(ADC_Sample@adsum+1),f	;volatile
u3321:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3322
	addwf	(ADC_Sample@adsum+2),f	;volatile
u3322:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3323
	addwf	(ADC_Sample@adsum+3),f	;volatile
u3323:

	line	76
	
l3276:	
	incf	(ADC_Sample@i),f
	
l3278:	
	movlw	low(022h)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u3331
	goto	u3330
u3331:
	goto	l3248
u3330:
	line	112
	
l3280:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u3345
	goto	u3346
u3345:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u3346:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u3347
	goto	u3348
u3347:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u3348:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u3349
	goto	u3340
u3349:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u3340:

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u3355
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u3355
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u3355
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u3355:
	skipc
	goto	u3351
	goto	u3350
u3351:
	goto	l465
u3350:
	line	114
	
l3282:	
;adc_drv.c: 114: adsum -= admin;
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u3365
	goto	u3366
u3365:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u3366:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u3367
	goto	u3368
u3367:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u3368:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u3369
	goto	u3360
u3369:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u3360:

	goto	l3284
	line	115
	
l465:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	118
	
l3284:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u3375:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u3370:
	addlw	-1
	skipz
	goto	u3375
	movf	1+(??_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
l3286:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
l458:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_ChargeProcess_Slot

;; *************** function _ChargeProcess_Slot *****************
;; Defined at:
;;		line 152 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   24[BANK0 ] unsigned char 
;;  v               2   27[BANK0 ] unsigned int 
;;  tick            2    0        unsigned int 
;;  p               1   29[BANK0 ] PTR struct .
;;		 -> g_slot1(72), g_slot0(72), 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       6       0       0       0
;;      Temps:          0       2       0       0       0
;;      Totals:         0       8       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Detect_BatteryType
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	152
global __ptext17
__ptext17:	;psect for function _ChargeProcess_Slot
psect	text17
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	152
	global	__size_of_ChargeProcess_Slot
	__size_of_ChargeProcess_Slot	equ	__end_of_ChargeProcess_Slot-_ChargeProcess_Slot
	
_ChargeProcess_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _ChargeProcess_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;ChargeProcess_Slot@idx stored from wreg
	movwf	(ChargeProcess_Slot@idx)
	line	154
	
l3908:	
;charge_mgr.c: 154: BatterySlot_t *p = (((unsigned char)(idx) < 6) ? &g_slot0[(unsigned char)(idx)] : &g_slot1[(unsigned char)(idx) - 6U]);
	movlw	low(06h)
	subwf	(ChargeProcess_Slot@idx),w
	skipc
	goto	u4251
	goto	u4250
u4251:
	goto	l3912
u4250:
	
l3910:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(ChargeProcess_Slot@p)
	goto	l3914
	
l3912:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(ChargeProcess_Slot@p)
	line	156
	
l3914:	
;charge_mgr.c: 156: unsigned int v = p->voltage;
	movf	(ChargeProcess_Slot@p),w
	addlw	03h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(ChargeProcess_Slot@v)
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v+1)
	line	157
	
l3916:	
	line	159
;charge_mgr.c: 159: switch(p->state)
	goto	l4030
	line	163
	
l3918:	
;charge_mgr.c: 163: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	164
;charge_mgr.c: 164: p->stableCnt = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	0Ah
	movwf	fsr0
	clrf	indf
	line	165
	
l3920:	
;charge_mgr.c: 165: p->state = 1;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	166
;charge_mgr.c: 166: break;
	goto	l561
	line	170
	
l3922:	
;charge_mgr.c: 170: p->chargeTimer += tick;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	171
	
l3924:	
;charge_mgr.c: 171: if(p->chargeTimer < (2 * 100))
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+1
	movlw	0
	subwf	1+(??_ChargeProcess_Slot+0)+0,w
	movlw	0C8h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)+0,w
	skipnc
	goto	u4261
	goto	u4260
u4261:
	goto	l3928
u4260:
	goto	l561
	line	175
	
l3928:	
;charge_mgr.c: 175: p->type = Detect_BatteryType(v);
	movf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movf	(ChargeProcess_Slot@v+1),w
	movwf	(Detect_BatteryType@voltage+1)
	movf	(ChargeProcess_Slot@v),w
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	movwf	indf
	line	179
	
l3930:	
;charge_mgr.c: 178: if(p->type == 2 ||
;charge_mgr.c: 179: p->type == 0)
	movf	(ChargeProcess_Slot@p),w
	movwf	fsr0
		movlw	2
	xorwf	(indf),w
	btfsc	status,2
	goto	u4271
	goto	u4270
u4271:
	goto	l3934
u4270:
	
l3932:	
	movf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movf	(indf),w
	btfss	status,2
	goto	u4281
	goto	u4280
u4281:
	goto	l3936
u4280:
	line	181
	
l3934:	
;charge_mgr.c: 180: {
;charge_mgr.c: 181: p->state = 7;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	182
;charge_mgr.c: 182: break;
	goto	l561
	line	186
	
l3936:	
;charge_mgr.c: 183: }
;charge_mgr.c: 186: if(v <= 447)
	movlw	01h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	0C0h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u4291
	goto	u4290
u4291:
	goto	l3944
u4290:
	line	188
	
l3938:	
;charge_mgr.c: 187: {
;charge_mgr.c: 188: p->state = 2;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(02h)
	movwf	indf
	line	189
	
l3940:	
;charge_mgr.c: 189: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	190
	
l3942:	
;charge_mgr.c: 190: p->activatePulseCnt = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	0Bh
	movwf	fsr0
	clrf	indf
	line	191
;charge_mgr.c: 191: }
	goto	l561
	line	193
	
l3944:	
;charge_mgr.c: 193: else if(v < 745)
	movlw	02h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	0E9h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u4301
	goto	u4300
u4301:
	goto	l3950
u4300:
	line	195
	
l3946:	
;charge_mgr.c: 194: {
;charge_mgr.c: 195: p->state = 3;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	line	196
	
l3948:	
;charge_mgr.c: 196: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	197
;charge_mgr.c: 197: }
	goto	l561
	line	201
	
l3950:	
;charge_mgr.c: 199: else
;charge_mgr.c: 200: {
;charge_mgr.c: 201: p->state = 4;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(04h)
	movwf	indf
	line	202
	
l3952:	
;charge_mgr.c: 202: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l561
	line	209
	
l3954:	
;charge_mgr.c: 209: p->chargeTimer += tick;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	211
	
l3956:	
;charge_mgr.c: 211: if(p->chargeTimer > (60 * 100))
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+1
	movlw	017h
	subwf	1+(??_ChargeProcess_Slot+0)+0,w
	movlw	071h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)+0,w
	skipc
	goto	u4311
	goto	u4310
u4311:
	goto	l3960
u4310:
	line	213
	
l3958:	
;charge_mgr.c: 212: {
;charge_mgr.c: 213: p->state = 7;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	214
;charge_mgr.c: 214: break;
	goto	l561
	line	217
	
l3960:	
;charge_mgr.c: 215: }
;charge_mgr.c: 217: if(v > 447)
	movlw	01h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	0C0h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4321
	goto	u4320
u4321:
	goto	l3966
u4320:
	line	219
	
l3962:	
;charge_mgr.c: 218: {
;charge_mgr.c: 219: p->state = 3;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	line	220
	
l3964:	
;charge_mgr.c: 220: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	221
;charge_mgr.c: 221: break;
	goto	l561
	line	224
	
l3966:	
;charge_mgr.c: 222: }
;charge_mgr.c: 224: if(v >= 1564)
	movlw	06h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	01Ch
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4331
	goto	u4330
u4331:
	goto	l561
u4330:
	line	226
	
l3968:	
;charge_mgr.c: 225: {
;charge_mgr.c: 226: p->state = 7;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	227
;charge_mgr.c: 227: break;
	goto	l561
	line	233
	
l3970:	
;charge_mgr.c: 233: p->chargeTimer += tick;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	235
	
l3972:	
;charge_mgr.c: 235: if(p->chargeTimer > (300 * 100))
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+1
	movlw	075h
	subwf	1+(??_ChargeProcess_Slot+0)+0,w
	movlw	031h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)+0,w
	skipc
	goto	u4341
	goto	u4340
u4341:
	goto	l3976
u4340:
	line	237
	
l3974:	
;charge_mgr.c: 236: {
;charge_mgr.c: 237: p->state = 7;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	238
;charge_mgr.c: 238: break;
	goto	l561
	line	241
	
l3976:	
;charge_mgr.c: 239: }
;charge_mgr.c: 241: if(v >= 1564)
	movlw	06h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	01Ch
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4351
	goto	u4350
u4351:
	goto	l3980
u4350:
	line	243
	
l3978:	
;charge_mgr.c: 242: {
;charge_mgr.c: 243: p->state = 7;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	244
;charge_mgr.c: 244: break;
	goto	l561
	line	247
	
l3980:	
;charge_mgr.c: 245: }
;charge_mgr.c: 247: if(v >= 1117)
	movlw	04h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	05Dh
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4361
	goto	u4360
u4361:
	goto	l561
u4360:
	line	249
	
l3982:	
;charge_mgr.c: 248: {
;charge_mgr.c: 249: p->state = 4;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(04h)
	movwf	indf
	line	250
	
l3984:	
;charge_mgr.c: 250: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l561
	line	256
	
l3986:	
;charge_mgr.c: 256: p->chargeTimer += tick;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	264
;charge_mgr.c: 258: if(p->chargeTimer > (10800UL * 100))
	
l3990:	
;charge_mgr.c: 262: }
;charge_mgr.c: 264: if(v >= 1564)
	movlw	06h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	01Ch
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4371
	goto	u4370
u4371:
	goto	l3994
u4370:
	line	266
	
l3992:	
;charge_mgr.c: 265: {
;charge_mgr.c: 266: p->state = 7;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	267
;charge_mgr.c: 267: break;
	goto	l561
	line	270
	
l3994:	
;charge_mgr.c: 268: }
;charge_mgr.c: 270: if(v >= 1504)
	movlw	05h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	0E0h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4381
	goto	u4380
u4381:
	goto	l561
u4380:
	line	272
	
l3996:	
;charge_mgr.c: 271: {
;charge_mgr.c: 272: p->state = 5;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(05h)
	movwf	indf
	line	273
	
l3998:	
;charge_mgr.c: 273: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l561
	line	279
	
l4000:	
;charge_mgr.c: 279: p->chargeTimer += tick;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	281
	
l4002:	
;charge_mgr.c: 281: if(v >= 1564)
	movlw	06h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	01Ch
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4391
	goto	u4390
u4391:
	goto	l4006
u4390:
	line	283
	
l4004:	
;charge_mgr.c: 282: {
;charge_mgr.c: 283: p->state = 7;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	284
;charge_mgr.c: 284: break;
	goto	l561
	line	287
	
l4006:	
;charge_mgr.c: 285: }
;charge_mgr.c: 287: if(p->chargeTimer > (600 * 100))
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)+0+1
	movlw	0EAh
	subwf	1+(??_ChargeProcess_Slot+0)+0,w
	movlw	061h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)+0,w
	skipc
	goto	u4401
	goto	u4400
u4401:
	goto	l561
u4400:
	line	289
	
l4008:	
;charge_mgr.c: 288: {
;charge_mgr.c: 289: p->state = 6;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(06h)
	movwf	indf
	goto	l561
	line	296
	
l4010:	
;charge_mgr.c: 296: if(v < (1504 - 10))
	movlw	05h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	0D6h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u4411
	goto	u4410
u4411:
	goto	l561
u4410:
	line	298
	
l4012:	
;charge_mgr.c: 297: {
;charge_mgr.c: 298: p->state = 4;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movlw	low(04h)
	movwf	indf
	line	299
	
l4014:	
;charge_mgr.c: 299: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l561
	line	307
	
l4016:	
;charge_mgr.c: 306: if(v > 447 && v < 1564 &&
;charge_mgr.c: 307: p->type == 1)
	movlw	01h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	0C0h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4421
	goto	u4420
u4421:
	goto	l561
u4420:
	
l4018:	
	movlw	06h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	01Ch
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u4431
	goto	u4430
u4431:
	goto	l561
u4430:
	
l4020:	
	movf	(ChargeProcess_Slot@p),w
	movwf	fsr0
		decf	(indf),w
	btfss	status,2
	goto	u4441
	goto	u4440
u4441:
	goto	l561
u4440:
	line	309
	
l4022:	
;charge_mgr.c: 308: {
;charge_mgr.c: 309: p->state = 1;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	310
	
l4024:	
;charge_mgr.c: 310: p->chargeTimer = 0;
	movf	(ChargeProcess_Slot@p),w
	addlw	05h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l561
	line	315
	
l4026:	
;charge_mgr.c: 315: p->state = 0;
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	clrf	indf
	line	316
;charge_mgr.c: 316: break;
	goto	l561
	line	159
	
l4030:	
	incf	(ChargeProcess_Slot@p),w
	movwf	fsr0
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 8, Range of values is 0 to 7
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           25    13 (average)
; direct_byte           32     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l3918
	xorlw	1^0	; case 1
	skipnz
	goto	l3922
	xorlw	2^1	; case 2
	skipnz
	goto	l3954
	xorlw	3^2	; case 3
	skipnz
	goto	l3970
	xorlw	4^3	; case 4
	skipnz
	goto	l3986
	xorlw	5^4	; case 5
	skipnz
	goto	l4000
	xorlw	6^5	; case 6
	skipnz
	goto	l4010
	xorlw	7^6	; case 7
	skipnz
	goto	l4016
	goto	l4026
	opt asmopt_pop

	line	318
	
l561:	
	return
	opt stack 0
GLOBAL	__end_of_ChargeProcess_Slot
	__end_of_ChargeProcess_Slot:
	signat	_ChargeProcess_Slot,4217
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1   19[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1   21[BANK0 ] unsigned char 
;;  product         1   20[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;;		_Led_BlinkProcess
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext18
__ptext18:	;psect for function ___bmul
psect	text18
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplier)
	line	6
	
l3472:	
	clrf	(___bmul@product)
	line	43
	
l3474:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u3701
	goto	u3700
u3701:
	goto	l3478
u3700:
	line	44
	
l3476:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l3478:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l3480:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u3711
	goto	u3710
u3711:
	goto	l3474
u3710:
	line	50
	
l3482:	
	movf	(___bmul@product),w
	line	51
	
l722:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 92 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2   19[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	92
global __ptext19
__ptext19:	;psect for function _Detect_BatteryType
psect	text19
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	92
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	95
	
l2422:	
;charge_mgr.c: 95: if(voltage < 410)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	09Ah
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2071
	goto	u2070
u2071:
	goto	l2428
u2070:
	line	96
	
l2424:	
;charge_mgr.c: 96: return 0;
	movlw	low(0)
	goto	l513
	line	99
	
l2428:	
;charge_mgr.c: 99: if(voltage >= 1191 && voltage <= 1340)
	movlw	04h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0A7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2081
	goto	u2080
u2081:
	goto	l2436
u2080:
	
l2430:	
	movlw	05h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	03Dh
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2091
	goto	u2090
u2091:
	goto	l2436
u2090:
	line	100
	
l2432:	
;charge_mgr.c: 100: return 2;
	movlw	low(02h)
	goto	l513
	line	103
	
l2436:	
;charge_mgr.c: 103: if(voltage >= 745 && voltage <= 1504)
	movlw	02h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0E9h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2101
	goto	u2100
u2101:
	goto	l2444
u2100:
	
l2438:	
	movlw	05h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0E1h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2111
	goto	u2110
u2111:
	goto	l2444
u2110:
	line	104
	
l2440:	
;charge_mgr.c: 104: return 1;
	movlw	low(01h)
	goto	l513
	line	107
	
l2444:	
;charge_mgr.c: 107: if(voltage > 1504 && voltage < 1564)
	movlw	05h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0E1h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2121
	goto	u2120
u2121:
	goto	l2452
u2120:
	
l2446:	
	movlw	06h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	01Ch
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2131
	goto	u2130
u2131:
	goto	l2452
u2130:
	goto	l2440
	line	112
	
l2452:	
;charge_mgr.c: 112: if(voltage >= 1564 && voltage < 4095)
	movlw	06h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	01Ch
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2141
	goto	u2140
u2141:
	goto	l2460
u2140:
	
l2454:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0FFh
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2151
	goto	u2150
u2151:
	goto	l2460
u2150:
	goto	l2440
	line	116
	
l2460:	
;charge_mgr.c: 116: if(voltage >= 410 && voltage < 745)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	09Ah
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2161
	goto	u2160
u2161:
	goto	l2424
u2160:
	
l2462:	
	movlw	02h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0E9h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2171
	goto	u2170
u2171:
	goto	l2424
u2170:
	goto	l2440
	line	121
	
l513:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 160 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_CCCV_Control
;;		_Charging_Control
;;		_Led_BlinkProcess
;;		_PowerOnLedSequence
;;		_Update_LED_Slot
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	160
global __ptext20
__ptext20:	;psect for function _Isr_Timer
psect	text20
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	160
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 2
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	movf	btemp+1,w
	movwf	(??_Isr_Timer+3)
	ljmp	_Isr_Timer
psect	text20
	line	163
	
i1l4032:	
;main.c: 163: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u445_21
	goto	u445_20
u445_21:
	goto	i1l347
u445_20:
	line	165
	
i1l4034:	
;main.c: 164: {
;main.c: 165: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	166
	
i1l4036:	
;main.c: 166: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	167
# 167 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text20
	line	170
	
i1l4038:	
;main.c: 170: g_pwmCounter++;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	171
	
i1l4040:	
;main.c: 171: if(g_pwmCounter >= 32)
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u446_21
	goto	u446_20
u446_21:
	goto	i1l4044
u446_20:
	line	172
	
i1l4042:	
;main.c: 172: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	175
	
i1l4044:	
;main.c: 175: if(g_pwmDuty > 0 && g_pwmCounter < g_pwmDuty)
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u447_21
	goto	u447_20
u447_21:
	goto	i1l344
u447_20:
	
i1l4046:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u448_21
	goto	u448_20
u448_21:
	goto	i1l344
u448_20:
	line	176
	
i1l4048:	
;main.c: 176: RB7 = 1;
	bsf	(55/8),(55)&7	;volatile
	goto	i1l4050
	line	177
	
i1l344:	
	line	178
;main.c: 177: else
;main.c: 178: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	181
	
i1l4050:	
;main.c: 181: if(g_powerOnPhase < 2)
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u449_21
	goto	u449_20
u449_21:
	goto	i1l4110
u449_20:
	line	183
	
i1l4052:	
;main.c: 182: {
;main.c: 183: PowerOnLedSequence();
	fcall	_PowerOnLedSequence
	goto	i1l347
	line	190
;main.c: 189: {
;main.c: 190: case 0:
	
i1l349:	
	line	192
;main.c: 192: if(!g_adcBusy && !g_doAdcSample)
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u450_21
	goto	u450_20
u450_21:
	goto	i1l347
u450_20:
	
i1l4056:	
	btfsc	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u451_21
	goto	u451_20
u451_21:
	goto	i1l347
u451_20:
	goto	i1l4060
	line	194
	
i1l353:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l366
	
i1l355:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l366
	
i1l356:	
	bsf	(51/8),(51)&7	;volatile
	goto	i1l366
	
i1l357:	
	bsf	(50/8),(50)&7	;volatile
	goto	i1l366
	
i1l358:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l366
	
i1l359:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l366
	
i1l360:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l366
	
i1l361:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l366
	
i1l362:	
	bsf	(48/8),(48)&7	;volatile
	goto	i1l366
	
i1l363:	
	bsf	(49/8),(49)&7	;volatile
	goto	i1l366
	
i1l364:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l366
	
i1l365:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l366
	
i1l4060:	
	movf	(_g_scanIndex),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l353
	xorlw	1^0	; case 1
	skipnz
	goto	i1l355
	xorlw	2^1	; case 2
	skipnz
	goto	i1l356
	xorlw	3^2	; case 3
	skipnz
	goto	i1l357
	xorlw	4^3	; case 4
	skipnz
	goto	i1l358
	xorlw	5^4	; case 5
	skipnz
	goto	i1l359
	xorlw	6^5	; case 6
	skipnz
	goto	i1l360
	xorlw	7^6	; case 7
	skipnz
	goto	i1l361
	xorlw	8^7	; case 8
	skipnz
	goto	i1l362
	xorlw	9^8	; case 9
	skipnz
	goto	i1l363
	xorlw	10^9	; case 10
	skipnz
	goto	i1l364
	xorlw	11^10	; case 11
	skipnz
	goto	i1l365
	goto	i1l366
	opt asmopt_pop

	
i1l366:	
	line	195
;main.c: 195: g_doAdcSample = 1;
	bsf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	i1l347
	line	201
	
i1l4062:	
;main.c: 201: Update_LED_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_Update_LED_Slot
	line	203
	
i1l4064:	
;main.c: 203: g_scanPhase = 2;
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_scanPhase)	;volatile
	line	204
;main.c: 204: break;
	goto	i1l347
	line	207
	
i1l4066:	
;main.c: 207: if(g_scanIndex == 0)
	movf	((_g_scanIndex)),w	;volatile
	btfss	status,2
	goto	u452_21
	goto	u452_20
u452_21:
	goto	i1l4102
u452_20:
	line	209
	
i1l4068:	
;main.c: 208: {
;main.c: 209: Charging_Control();
	fcall	_Charging_Control
	line	210
	
i1l4070:	
;main.c: 210: CCCV_Control();
	fcall	_CCCV_Control
	line	211
	
i1l4072:	
;main.c: 215: if(!0)
	fcall	_Led_BlinkProcess
	line	217
	
i1l4074:	
;main.c: 216: {
;main.c: 217: if(g_tempPhase == 0)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_g_tempPhase)),w	;volatile
	btfss	status,2
	goto	u453_21
	goto	u453_20
u453_21:
	goto	i1l4086
u453_20:
	line	220
	
i1l4076:	
;main.c: 218: {
;main.c: 220: g_tempReadRoundCnt++;
	incf	(_g_tempReadRoundCnt),f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1),f	;volatile
	line	221
	
i1l4078:	
;main.c: 221: if(g_tempReadRoundCnt >= 200)
	movlw	0
	subwf	(_g_tempReadRoundCnt+1),w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt),w	;volatile
	skipc
	goto	u454_21
	goto	u454_20
u454_21:
	goto	i1l4094
u454_20:
	line	223
	
i1l4080:	
;main.c: 222: {
;main.c: 223: g_tempReadRoundCnt = 0;
	clrf	(_g_tempReadRoundCnt)	;volatile
	clrf	(_g_tempReadRoundCnt+1)	;volatile
	line	224
	
i1l4082:	
;main.c: 224: g_tempPhase = 1;
	movlw	low(01h)
	movwf	(_g_tempPhase)	;volatile
	line	225
	
i1l4084:	
;main.c: 225: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)	;volatile
	clrf	(_g_tempSettleCnt+1)	;volatile
	goto	i1l4094
	line	230
	
i1l4086:	
;main.c: 228: else
;main.c: 229: {
;main.c: 230: g_tempSettleCnt++;
	incf	(_g_tempSettleCnt),f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1),f	;volatile
	line	231
	
i1l4088:	
;main.c: 231: if(g_tempSettleCnt >= 60)
	movlw	0
	subwf	(_g_tempSettleCnt+1),w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt),w	;volatile
	skipc
	goto	u455_21
	goto	u455_20
u455_21:
	goto	i1l4094
u455_20:
	line	234
	
i1l4090:	
;main.c: 232: {
;main.c: 234: g_doNtcRead = 1;
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	235
	
i1l4092:	
;main.c: 235: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)	;volatile
	clrf	(_g_tempSettleCnt+1)	;volatile
	line	236
;main.c: 236: g_tempPhase = 0;
	clrf	(_g_tempPhase)	;volatile
	line	242
	
i1l4094:	
;main.c: 237: }
;main.c: 238: }
;main.c: 239: }
;main.c: 242: if(++g_printTick >= 100)
	incf	(_g_printTick),f	;volatile
	skipnz
	incf	(_g_printTick+1),f	;volatile
	movlw	0
	subwf	((_g_printTick+1)),w	;volatile
	movlw	064h
	skipnz
	subwf	((_g_printTick)),w	;volatile
	skipc
	goto	u456_21
	goto	u456_20
u456_21:
	goto	i1l4102
u456_20:
	line	244
	
i1l4096:	
;main.c: 243: {
;main.c: 244: g_printTick = 0;
	clrf	(_g_printTick)	;volatile
	clrf	(_g_printTick+1)	;volatile
	line	245
	
i1l4098:	
;main.c: 245: g_printFlag = 1;
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	246
	
i1l4100:	
;main.c: 246: g_ntcPrintFlag = 1;
	bsf	(_g_ntcPrintFlag/8),(_g_ntcPrintFlag)&7	;volatile
	line	251
	
i1l4102:	
;main.c: 247: }
;main.c: 248: }
;main.c: 251: if(++g_scanIndex >= 12)
	movlw	low(0Ch)
	incf	(_g_scanIndex),f	;volatile
	subwf	((_g_scanIndex)),w	;volatile
	skipc
	goto	u457_21
	goto	u457_20
u457_21:
	goto	i1l377
u457_20:
	line	252
	
i1l4104:	
;main.c: 252: g_scanIndex = 0;
	clrf	(_g_scanIndex)	;volatile
	
i1l377:	
	line	253
;main.c: 253: g_scanPhase = 0;
	clrf	(_g_scanPhase)	;volatile
	line	254
;main.c: 254: break;
	goto	i1l347
	line	188
	
i1l4110:	
	movf	(_g_scanPhase),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 2
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           17     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l349
	xorlw	1^0	; case 1
	skipnz
	goto	i1l4062
	xorlw	2^1	; case 2
	skipnz
	goto	i1l4066
	goto	i1l377
	opt asmopt_pop

	line	261
	
i1l347:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(??_Isr_Timer+3),w
	movwf	btemp+1
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^00h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	_Update_LED_Slot

;; *************** function _Update_LED_Slot *****************
;; Defined at:
;;		line 30 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    3[COMMON] unsigned char 
;;  p               1    4[COMMON] PTR struct .
;;		 -> g_slot1(72), g_slot0(72), 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	30
global __ptext21
__ptext21:	;psect for function _Update_LED_Slot
psect	text21
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	30
	global	__size_of_Update_LED_Slot
	__size_of_Update_LED_Slot	equ	__end_of_Update_LED_Slot-_Update_LED_Slot
	
_Update_LED_Slot:	
;incstack = 0
	opt	stack 2
; Regs used in _Update_LED_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Update_LED_Slot@idx stored from wreg
	movwf	(Update_LED_Slot@idx)
	line	32
	
i1l3552:	
;led.c: 32: BatterySlot_t *p = (((unsigned char)(idx) < 6) ? &g_slot0[(unsigned char)(idx)] : &g_slot1[(unsigned char)(idx) - 6U]);
	movlw	low(06h)
	subwf	(Update_LED_Slot@idx),w
	skipc
	goto	u373_21
	goto	u373_20
u373_21:
	goto	i1l3556
u373_20:
	
i1l3554:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Update_LED_Slot@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(Update_LED_Slot@p)
	goto	i1l3570
	
i1l3556:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Update_LED_Slot@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(Update_LED_Slot@p)
	goto	i1l3570
	line	37
	
i1l3558:	
;led.c: 37: p->ledState = 0;
	movf	(Update_LED_Slot@p),w
	addlw	02h
	movwf	fsr0
	clrf	indf
	line	38
;led.c: 38: break;
	goto	i1l663
	line	42
	
i1l658:	
	line	44
	
i1l3560:	
;led.c: 40: case 2:
;led.c: 41: case 3:
;led.c: 42: case 4:
;led.c: 43: case 5:
;led.c: 44: p->ledState = 1;
	movf	(Update_LED_Slot@p),w
	addlw	02h
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	45
;led.c: 45: break;
	goto	i1l663
	line	47
	
i1l3562:	
;led.c: 47: p->ledState = 2;
	movf	(Update_LED_Slot@p),w
	addlw	02h
	movwf	fsr0
	movlw	low(02h)
	movwf	indf
	line	48
;led.c: 48: break;
	goto	i1l663
	line	50
	
i1l3564:	
;led.c: 50: p->ledState = 3;
	movf	(Update_LED_Slot@p),w
	addlw	02h
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	line	51
;led.c: 51: break;
	goto	i1l663
	line	53
	
i1l3566:	
;led.c: 53: p->ledState = 0;
	movf	(Update_LED_Slot@p),w
	addlw	02h
	movwf	fsr0
	clrf	indf
	line	54
;led.c: 54: break;
	goto	i1l663
	line	34
	
i1l3570:	
	incf	(Update_LED_Slot@p),w
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 8, Range of values is 0 to 7
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           25    13 (average)
; direct_byte           32     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l3558
	xorlw	1^0	; case 1
	skipnz
	goto	i1l658
	xorlw	2^1	; case 2
	skipnz
	goto	i1l3560
	xorlw	3^2	; case 3
	skipnz
	goto	i1l3560
	xorlw	4^3	; case 4
	skipnz
	goto	i1l3560
	xorlw	5^4	; case 5
	skipnz
	goto	i1l3560
	xorlw	6^5	; case 6
	skipnz
	goto	i1l3562
	xorlw	7^6	; case 7
	skipnz
	goto	i1l3564
	goto	i1l3566
	opt asmopt_pop

	line	56
	
i1l663:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Slot
	__end_of_Update_LED_Slot:
	signat	_Update_LED_Slot,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 93 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	line	93
global __ptext22
__ptext22:	;psect for function _PowerOnLedSequence
psect	text22
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	93
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	95
	
i1l2610:	
;led.c: 95: g_powerOnTimer++;
	incf	(_g_powerOnTimer),f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1),f	;volatile
	line	97
	
i1l2612:	
;led.c: 97: if(g_powerOnPhase == 0)
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u230_21
	goto	u230_20
u230_21:
	goto	i1l2620
u230_20:
	line	100
	
i1l2614:	
;led.c: 98: {
;led.c: 100: if(g_powerOnTimer >= 100)
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u231_21
	goto	u231_20
u231_21:
	goto	i1l698
u231_20:
	line	102
	
i1l2616:	
;led.c: 101: {
;led.c: 102: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	103
	
i1l2618:	
;led.c: 103: g_powerOnPhase = 1;
	movlw	low(01h)
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l698
	line	106
	
i1l2620:	
;led.c: 106: else if(g_powerOnPhase == 1)
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u232_21
	goto	u232_20
u232_21:
	goto	i1l698
u232_20:
	line	109
	
i1l2622:	
;led.c: 107: {
;led.c: 109: if(g_powerOnTimer >= 100)
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u233_21
	goto	u233_20
u233_21:
	goto	i1l698
u233_20:
	line	111
	
i1l2624:	
;led.c: 110: {
;led.c: 111: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	112
	
i1l2626:	
;led.c: 112: g_powerOnPhase = 2;
	movlw	low(02h)
	movwf	(_g_powerOnPhase)	;volatile
	line	116
	
i1l698:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
	global	_Led_BlinkProcess

;; *************** function _Led_BlinkProcess *****************
;; Defined at:
;;		line 66 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   10[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         6       0       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	line	66
global __ptext23
__ptext23:	;psect for function _Led_BlinkProcess
psect	text23
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	66
	global	__size_of_Led_BlinkProcess
	__size_of_Led_BlinkProcess	equ	__end_of_Led_BlinkProcess-_Led_BlinkProcess
	
_Led_BlinkProcess:	
;incstack = 0
	opt	stack 2
; Regs used in _Led_BlinkProcess: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	69
	
i1l3712:	
;led.c: 68: unsigned char i;
;led.c: 69: for(i = 0; i < 12; i++)
	clrf	(Led_BlinkProcess@i)
	line	72
	
i1l3718:	
;led.c: 70: {
;led.c: 72: if((((unsigned char)(i) < 6) ? &g_slot0[(unsigned char)(i)] : &g_slot1[(unsigned char)(i) - 6U])->ledState == 3)
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u404_21
	goto	u404_20
u404_21:
	goto	i1l3722
u404_20:
	
i1l3720:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Led_BlinkProcess$494)
	goto	i1l3724
	
i1l3722:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Led_BlinkProcess$494)
	
i1l3724:	
	movf	(_Led_BlinkProcess$494),w
	addlw	02h
	movwf	fsr0
		movlw	3
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u405_21
	goto	u405_20
u405_21:
	goto	i1l3758
u405_20:
	line	74
	
i1l3726:	
;led.c: 73: {
;led.c: 74: (((unsigned char)(i) < 6) ? &g_slot0[(unsigned char)(i)] : &g_slot1[(unsigned char)(i) - 6U])->blinkTimer++;
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u406_21
	goto	u406_20
u406_21:
	goto	i1l3730
u406_20:
	
i1l3728:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Led_BlinkProcess$505)
	goto	i1l3732
	
i1l3730:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Led_BlinkProcess$505)
	
i1l3732:	
	movf	(_Led_BlinkProcess$505),w
	addlw	07h
	movwf	fsr0
	movlw	01h
	bsf	status, 7	;select IRP bank2
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	76
	
i1l3734:	
;led.c: 76: if((((unsigned char)(i) < 6) ? &g_slot0[(unsigned char)(i)] : &g_slot1[(unsigned char)(i) - 6U])->blinkTimer >= (100 / 2))
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u407_21
	goto	u407_20
u407_21:
	goto	i1l3738
u407_20:
	
i1l3736:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Led_BlinkProcess$516)
	goto	i1l3740
	
i1l3738:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Led_BlinkProcess$516)
	
i1l3740:	
	movf	(_Led_BlinkProcess$516),w
	addlw	07h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_BlinkProcess+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_BlinkProcess+0)+0+1
	movlw	0
	subwf	1+(??_Led_BlinkProcess+0)+0,w
	movlw	032h
	skipnz
	subwf	0+(??_Led_BlinkProcess+0)+0,w
	skipc
	goto	u408_21
	goto	u408_20
u408_21:
	goto	i1l3758
u408_20:
	line	78
	
i1l3742:	
;led.c: 77: {
;led.c: 78: (((unsigned char)(i) < 6) ? &g_slot0[(unsigned char)(i)] : &g_slot1[(unsigned char)(i) - 6U])->blinkTimer = 0;
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u409_21
	goto	u409_20
u409_21:
	goto	i1l3746
u409_20:
	
i1l3744:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Led_BlinkProcess$527)
	goto	i1l3748
	
i1l3746:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Led_BlinkProcess$527)
	
i1l3748:	
	movf	(_Led_BlinkProcess$527),w
	addlw	07h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	79
	
i1l3750:	
;led.c: 79: (((unsigned char)(i) < 6) ? &g_slot0[(unsigned char)(i)] : &g_slot1[(unsigned char)(i) - 6U])->blinkPhase ^= 1;
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u410_21
	goto	u410_20
u410_21:
	goto	i1l3754
u410_20:
	
i1l3752:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Led_BlinkProcess$538)
	goto	i1l3756
	
i1l3754:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Led_BlinkProcess$538)
	
i1l3756:	
	movf	(_Led_BlinkProcess$538),w
	addlw	09h
	movwf	fsr0
	movlw	low(01h)
	bsf	status, 7	;select IRP bank2
	xorwf	indf,f
	line	69
	
i1l3758:	
	incf	(Led_BlinkProcess@i),f
	
i1l3760:	
	movlw	low(0Ch)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u411_21
	goto	u411_20
u411_21:
	goto	i1l3718
u411_20:
	line	83
	
i1l690:	
	return
	opt stack 0
GLOBAL	__end_of_Led_BlinkProcess
	__end_of_Led_BlinkProcess:
	signat	_Led_BlinkProcess,89
	global	_Charging_Control

;; *************** function _Charging_Control *****************
;; Defined at:
;;		line 332 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    6[COMMON] unsigned char 
;;  i               1    7[COMMON] unsigned char 
;;  chargeB7_12     1    4[COMMON] unsigned char 
;;  chargeB1_6      1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 100/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         5       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	332
global __ptext24
__ptext24:	;psect for function _Charging_Control
psect	text24
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	332
	global	__size_of_Charging_Control
	__size_of_Charging_Control	equ	__end_of_Charging_Control-_Charging_Control
	
_Charging_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _Charging_Control: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	335
	
i1l3572:	
;charge_mgr.c: 334: unsigned char i;
;charge_mgr.c: 335: unsigned char chargeB1_6 = 0;
	clrf	(Charging_Control@chargeB1_6)
	line	336
;charge_mgr.c: 336: unsigned char chargeB7_12 = 0;
	clrf	(Charging_Control@chargeB7_12)
	line	339
	
i1l3574:	
;charge_mgr.c: 339: if(g_tempProtect)
	movf	((_g_tempProtect)),w
	btfsc	status,2
	goto	u374_21
	goto	u374_20
u374_21:
	goto	i1l3580
u374_20:
	line	341
;charge_mgr.c: 340: {
;charge_mgr.c: 341: do { RA0=1; RA1=1; RB3=1; RB2=1; RA3=1; RA2=1; RD1=1; RD3=1; RB0=1; RB1=1; RD2=1; RD0=1; } while(0);
	
i1l565:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	bsf	(1073/8)^080h,(1073)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	bsf	(50/8),(50)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	bsf	(1074/8)^080h,(1074)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	bsf	(49/8),(49)&7	;volatile
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	
i1l566:	
	line	342
;charge_mgr.c: 342: RC3 = 0;
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	343
;charge_mgr.c: 343: RC5 = 0;
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	344
	
i1l3576:	
;charge_mgr.c: 344: g_pwmDuty = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	goto	i1l567
	line	349
	
i1l3580:	
;charge_mgr.c: 346: }
;charge_mgr.c: 349: for(i = 0; i < 12; i++)
	clrf	(Charging_Control@i)
	line	351
	
i1l3586:	
;charge_mgr.c: 350: {
;charge_mgr.c: 351: unsigned char s = (((unsigned char)(i) < 6) ? &g_slot0[(unsigned char)(i)] : &g_slot1[(unsigned char)(i) - 6U])->state;
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipc
	goto	u375_21
	goto	u375_20
u375_21:
	goto	i1l3590
u375_20:
	
i1l3588:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	(_Charging_Control$426)
	goto	i1l3592
	
i1l3590:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	(_Charging_Control$426)
	
i1l3592:	
	incf	(_Charging_Control$426),w
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Charging_Control@s)
	line	355
	
i1l3594:	
;charge_mgr.c: 354: if(s == 2 || s == 3 ||
;charge_mgr.c: 355: s == 4 || s == 5)
		movlw	2
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u376_21
	goto	u376_20
u376_21:
	goto	i1l3604
u376_20:
	
i1l3596:	
		movlw	3
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u377_21
	goto	u377_20
u377_21:
	goto	i1l3604
u377_20:
	
i1l3598:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u378_21
	goto	u378_20
u378_21:
	goto	i1l3604
u378_20:
	
i1l3600:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u379_21
	goto	u379_20
u379_21:
	goto	i1l3612
u379_20:
	goto	i1l3604
	line	357
	
i1l579:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l3606
	
i1l581:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l3606
	
i1l582:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l3606
	
i1l583:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l3606
	
i1l584:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l3606
	
i1l585:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l3606
	
i1l586:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l3606
	
i1l587:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l3606
	
i1l588:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l3606
	
i1l589:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l3606
	
i1l590:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l3606
	
i1l591:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l3606
	
i1l3604:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l579
	xorlw	1^0	; case 1
	skipnz
	goto	i1l581
	xorlw	2^1	; case 2
	skipnz
	goto	i1l582
	xorlw	3^2	; case 3
	skipnz
	goto	i1l583
	xorlw	4^3	; case 4
	skipnz
	goto	i1l584
	xorlw	5^4	; case 5
	skipnz
	goto	i1l585
	xorlw	6^5	; case 6
	skipnz
	goto	i1l586
	xorlw	7^6	; case 7
	skipnz
	goto	i1l587
	xorlw	8^7	; case 8
	skipnz
	goto	i1l588
	xorlw	9^8	; case 9
	skipnz
	goto	i1l589
	xorlw	10^9	; case 10
	skipnz
	goto	i1l590
	xorlw	11^10	; case 11
	skipnz
	goto	i1l591
	goto	i1l3606
	opt asmopt_pop

	line	360
	
i1l3606:	
;charge_mgr.c: 360: if(i < 6)
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipnc
	goto	u380_21
	goto	u380_20
u380_21:
	goto	i1l593
u380_20:
	line	361
	
i1l3608:	
;charge_mgr.c: 361: chargeB1_6 = 1;
	clrf	(Charging_Control@chargeB1_6)
	incf	(Charging_Control@chargeB1_6),f
	goto	i1l3614
	line	362
	
i1l593:	
	line	363
;charge_mgr.c: 362: else
;charge_mgr.c: 363: chargeB7_12 = 1;
	clrf	(Charging_Control@chargeB7_12)
	incf	(Charging_Control@chargeB7_12),f
	goto	i1l3614
	line	367
	
i1l598:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l3614
	
i1l600:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l3614
	
i1l601:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	i1l3614
	
i1l602:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	i1l3614
	
i1l603:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l3614
	
i1l604:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l3614
	
i1l605:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l3614
	
i1l606:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l3614
	
i1l607:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	i1l3614
	
i1l608:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	i1l3614
	
i1l609:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l3614
	
i1l610:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l3614
	
i1l3612:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l598
	xorlw	1^0	; case 1
	skipnz
	goto	i1l600
	xorlw	2^1	; case 2
	skipnz
	goto	i1l601
	xorlw	3^2	; case 3
	skipnz
	goto	i1l602
	xorlw	4^3	; case 4
	skipnz
	goto	i1l603
	xorlw	5^4	; case 5
	skipnz
	goto	i1l604
	xorlw	6^5	; case 6
	skipnz
	goto	i1l605
	xorlw	7^6	; case 7
	skipnz
	goto	i1l606
	xorlw	8^7	; case 8
	skipnz
	goto	i1l607
	xorlw	9^8	; case 9
	skipnz
	goto	i1l608
	xorlw	10^9	; case 10
	skipnz
	goto	i1l609
	xorlw	11^10	; case 11
	skipnz
	goto	i1l610
	goto	i1l3614
	opt asmopt_pop

	line	349
	
i1l3614:	
	incf	(Charging_Control@i),f
	
i1l3616:	
	movlw	low(0Ch)
	subwf	(Charging_Control@i),w
	skipc
	goto	u381_21
	goto	u381_20
u381_21:
	goto	i1l3586
u381_20:
	
i1l569:	
	line	372
;charge_mgr.c: 368: }
;charge_mgr.c: 369: }
;charge_mgr.c: 372: RC3 = chargeB1_6;
	btfsc	(Charging_Control@chargeB1_6),0
	goto	u382_21
	goto	u382_20
	
u382_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2099/8)^0100h,(2099)&7	;volatile
	goto	u383_24
u382_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
u383_24:
	line	373
;charge_mgr.c: 373: RC5 = chargeB7_12;
	btfsc	(Charging_Control@chargeB7_12),0
	goto	u384_21
	goto	u384_20
	
u384_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u385_24
u384_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u385_24:
	line	376
	
i1l567:	
	return
	opt stack 0
GLOBAL	__end_of_Charging_Control
	__end_of_Charging_Control:
	signat	_Charging_Control,89
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 394 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1   13[BANK0 ] unsigned char 
;;  duty            2   11[BANK0 ] int 
;;  error           2    9[BANK0 ] int 
;;  adjust          2    0[BANK0 ] int 
;;  maxV            2    7[BANK0 ] unsigned int 
;;  i               1   14[BANK0 ] unsigned char 
;;  cvCount         1    3[BANK0 ] unsigned char 
;;  hasCharging     1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 100/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      15       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2      15       0       0       0
;;Total ram usage:       17 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___awdiv
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	line	394
global __ptext25
__ptext25:	;psect for function _CCCV_Control
psect	text25
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	394
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	397
	
i1l3618:	
;charge_mgr.c: 396: unsigned char i;
;charge_mgr.c: 397: unsigned char hasCharging = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	398
;charge_mgr.c: 398: unsigned int maxV = 0;
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	399
;charge_mgr.c: 399: unsigned char cvCount = 0;
	clrf	(CCCV_Control@cvCount)
	line	402
;charge_mgr.c: 402: for(i = 0; i < 12; i++)
	clrf	(CCCV_Control@i)
	line	404
	
i1l3624:	
;charge_mgr.c: 403: {
;charge_mgr.c: 404: unsigned char s = (((unsigned char)(i) < 6) ? &g_slot0[(unsigned char)(i)] : &g_slot1[(unsigned char)(i) - 6U])->state;
	movlw	low(06h)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u386_21
	goto	u386_20
u386_21:
	goto	i1l3628
u386_20:
	
i1l3626:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$443)
	goto	i1l3630
	
i1l3628:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$443)
	
i1l3630:	
	incf	(_CCCV_Control$443),w
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(CCCV_Control@s)
	line	407
	
i1l3632:	
;charge_mgr.c: 406: if(s == 2 || s == 3 ||
;charge_mgr.c: 407: s == 4 || s == 5)
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u387_21
	goto	u387_20
u387_21:
	goto	i1l622
u387_20:
	
i1l3634:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u388_21
	goto	u388_20
u388_21:
	goto	i1l622
u388_20:
	
i1l3636:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u389_21
	goto	u389_20
u389_21:
	goto	i1l622
u389_20:
	
i1l3638:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u390_21
	goto	u390_20
u390_21:
	goto	i1l620
u390_20:
	
i1l622:	
	line	409
;charge_mgr.c: 408: {
;charge_mgr.c: 409: hasCharging = 1;
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	410
	
i1l3640:	
;charge_mgr.c: 410: if((((unsigned char)(i) < 6) ? &g_slot0[(unsigned char)(i)] : &g_slot1[(unsigned char)(i) - 6U])->voltage > maxV)
	movlw	low(06h)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u391_21
	goto	u391_20
u391_21:
	goto	i1l3644
u391_20:
	
i1l3642:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$454)
	goto	i1l3646
	
i1l3644:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$454)
	
i1l3646:	
	movf	(_CCCV_Control$454),w
	addlw	03h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_CCCV_Control+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_CCCV_Control+0)+0+1
	movf	1+(??_CCCV_Control+0)+0,w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u392_25
	movf	0+(??_CCCV_Control+0)+0,w
	subwf	(CCCV_Control@maxV),w
u392_25:
	skipnc
	goto	u392_21
	goto	u392_20
u392_21:
	goto	i1l3656
u392_20:
	line	411
	
i1l3648:	
;charge_mgr.c: 411: maxV = (((unsigned char)(i) < 6) ? &g_slot0[(unsigned char)(i)] : &g_slot1[(unsigned char)(i) - 6U])->voltage;
	movlw	low(06h)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u393_21
	goto	u393_20
u393_21:
	goto	i1l3652
u393_20:
	
i1l3650:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$465)
	goto	i1l3654
	
i1l3652:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$465)
	
i1l3654:	
	movf	(_CCCV_Control$465),w
	addlw	03h
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(CCCV_Control@maxV)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@maxV+1)
	line	412
	
i1l3656:	
;charge_mgr.c: 412: if(s == 5)
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u394_21
	goto	u394_20
u394_21:
	goto	i1l620
u394_20:
	line	413
	
i1l3658:	
;charge_mgr.c: 413: cvCount++;
	incf	(CCCV_Control@cvCount),f
	line	414
	
i1l620:	
	line	402
	incf	(CCCV_Control@i),f
	
i1l3660:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u395_21
	goto	u395_20
u395_21:
	goto	i1l3624
u395_20:
	line	418
	
i1l3662:	
;charge_mgr.c: 414: }
;charge_mgr.c: 415: }
;charge_mgr.c: 418: if(!hasCharging)
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u396_21
	goto	u396_20
u396_21:
	goto	i1l3668
u396_20:
	line	420
	
i1l3664:	
;charge_mgr.c: 419: {
;charge_mgr.c: 420: g_pwmDuty = 0;
	clrf	(_g_pwmDuty)	;volatile
	line	421
;charge_mgr.c: 421: g_cvIntegral = 0;
	clrf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l634
	line	428
	
i1l3668:	
;charge_mgr.c: 423: }
;charge_mgr.c: 428: if(cvCount == 0)
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u397_21
	goto	u397_20
u397_21:
	goto	i1l3686
u397_20:
	line	430
	
i1l3670:	
;charge_mgr.c: 429: {
;charge_mgr.c: 430: if(g_pwmDuty < 25)
	movlw	low(019h)
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u398_21
	goto	u398_20
u398_21:
	goto	i1l3678
u398_20:
	line	433
	
i1l3672:	
;charge_mgr.c: 431: {
;charge_mgr.c: 433: g_pwmDuty += 3;
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	434
	
i1l3674:	
;charge_mgr.c: 434: if(g_pwmDuty > 25)
	movlw	low(01Ah)
	subwf	(_g_pwmDuty),w	;volatile
	skipc
	goto	u399_21
	goto	u399_20
u399_21:
	goto	i1l634
u399_20:
	line	435
	
i1l3676:	
;charge_mgr.c: 435: g_pwmDuty = 25;
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l634
	line	437
	
i1l3678:	
	goto	i1l3676
	line	456
	
i1l3686:	
;charge_mgr.c: 448: }
;charge_mgr.c: 455: {
;charge_mgr.c: 456: int error = (int)(1504) - (int)(maxV);
	movlw	0E0h
	movwf	(CCCV_Control@error)
	movlw	05h
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	459
;charge_mgr.c: 459: g_cvIntegral += error * 1;
	movf	(CCCV_Control@error),w
	addwf	(_g_cvIntegral),f
	skipnc
	incf	(_g_cvIntegral+1),f
	movf	(CCCV_Control@error+1),w
	addwf	(_g_cvIntegral+1),f
	line	460
	
i1l3688:	
;charge_mgr.c: 460: if(g_cvIntegral > 200)
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u400_25
	movlw	0C9h
	subwf	(_g_cvIntegral),w
u400_25:

	skipc
	goto	u400_21
	goto	u400_20
u400_21:
	goto	i1l3692
u400_20:
	line	461
	
i1l3690:	
;charge_mgr.c: 461: g_cvIntegral = 200;
	movlw	0C8h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l3696
	line	462
	
i1l3692:	
;charge_mgr.c: 462: else if(g_cvIntegral < -200)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u401_25
	movlw	038h
	subwf	(_g_cvIntegral),w
u401_25:

	skipnc
	goto	u401_21
	goto	u401_20
u401_21:
	goto	i1l3696
u401_20:
	line	463
	
i1l3694:	
;charge_mgr.c: 463: g_cvIntegral = -200;
	movlw	038h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	movlw	0FFh
	movwf	((_g_cvIntegral))+1
	line	466
	
i1l3696:	
;charge_mgr.c: 466: int adjust = (error * 4 + g_cvIntegral) / 8;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	movf	(_g_cvIntegral),w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1),w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	467
	
i1l3698:	
;charge_mgr.c: 467: int duty = (int)g_pwmDuty + adjust;
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
i1l3700:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	470
	
i1l3702:	
;charge_mgr.c: 470: if(duty > 32) duty = 32;
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u402_25
	movlw	021h
	subwf	(CCCV_Control@duty),w
u402_25:

	skipc
	goto	u402_21
	goto	u402_20
u402_21:
	goto	i1l3706
u402_20:
	
i1l3704:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	471
	
i1l3706:	
;charge_mgr.c: 471: if(duty < 0) duty = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u403_21
	goto	u403_20
u403_21:
	goto	i1l3710
u403_20:
	
i1l3708:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	473
	
i1l3710:	
;charge_mgr.c: 473: g_pwmDuty = (unsigned char)duty;
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	475
	
i1l634:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	i1___bmul

;; *************** function i1___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[COMMON] unsigned char 
;;  __bmul          1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;;		_Led_BlinkProcess
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext26
__ptext26:	;psect for function i1___bmul
psect	text26
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_ofi1___bmul
	__size_ofi1___bmul	equ	__end_ofi1___bmul-i1___bmul
	
i1___bmul:	
;incstack = 0
	opt	stack 2
; Regs used in i1___bmul: [wreg+status,2+status,0]
;i1___bmul@multiplier stored from wreg
	movwf	(i1___bmul@multiplier)
	line	6
	
i1l2530:	
	clrf	(i1___bmul@product)
	line	43
	
i1l2532:	
	btfss	(i1___bmul@multiplier),(0)&7
	goto	u227_21
	goto	u227_20
u227_21:
	goto	i1l2536
u227_20:
	line	44
	
i1l2534:	
	movf	(i1___bmul@multiplicand),w
	addwf	(i1___bmul@product),f
	line	45
	
i1l2536:	
	clrc
	rlf	(i1___bmul@multiplicand),f
	line	46
	
i1l2538:	
	clrc
	rrf	(i1___bmul@multiplier),f
	line	47
	movf	((i1___bmul@multiplier)),w
	btfss	status,2
	goto	u228_21
	goto	u228_20
u228_21:
	goto	i1l2532
u228_20:
	line	50
	
i1l2540:	
	movf	(i1___bmul@product),w
	line	51
	
i1l722:	
	return
	opt stack 0
GLOBAL	__end_ofi1___bmul
	__end_ofi1___bmul:
	signat	i1___bmul,89
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] int 
;;  dividend        2    2[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] int 
;;  sign            1    5[COMMON] unsigned char 
;;  counter         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext27
__ptext27:	;psect for function ___awdiv
psect	text27
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
i1l2486:	
	clrf	(___awdiv@sign)
	line	15
	
i1l2488:	
	btfss	(___awdiv@divisor+1),7
	goto	u220_21
	goto	u220_20
u220_21:
	goto	i1l2494
u220_20:
	line	16
	
i1l2490:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
i1l2492:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
i1l2494:	
	btfss	(___awdiv@dividend+1),7
	goto	u221_21
	goto	u221_20
u221_21:
	goto	i1l2500
u221_20:
	line	20
	
i1l2496:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
i1l2498:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
i1l2500:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
i1l2502:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u222_21
	goto	u222_20
u222_21:
	goto	i1l2522
u222_20:
	line	25
	
i1l2504:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	i1l2508
	line	27
	
i1l2506:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
i1l2508:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u223_21
	goto	u223_20
u223_21:
	goto	i1l2506
u223_20:
	line	31
	
i1l2510:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
i1l2512:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u224_25
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u224_25:
	skipc
	goto	u224_21
	goto	u224_20
u224_21:
	goto	i1l2518
u224_20:
	line	33
	
i1l2514:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
i1l2516:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
i1l2518:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
i1l2520:	
	decfsz	(___awdiv@counter),f
	goto	u225_21
	goto	u225_20
u225_21:
	goto	i1l2510
u225_20:
	line	39
	
i1l2522:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u226_21
	goto	u226_20
u226_21:
	goto	i1l2526
u226_20:
	line	40
	
i1l2524:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
i1l2526:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
i1l834:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
