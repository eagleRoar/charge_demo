/*-------------------------------------------
  L1211 12槽充电器 - 充电管理模块
-------------------------------------------*/
#include "config.h"

/*========================================================================
  全局变量
========================================================================*/
unsigned int g_temperature = 250;
unsigned char g_tempProtect = 0;
unsigned int g_impRefV[BATTERY_SLOTS];
unsigned char g_ccBlocks[12];           /* CC阶段10分钟块计数(解决16bit chargeTimer溢出) */
unsigned char g_ovCnt[12];              /* 过压消抖计数器: 连续过压次数 */
unsigned char g_detectLowCnt[12];       /* DETECT低电压消抖: 连续低ADC读数计数 */

/* LED独立字段(与充电状态结构体分离) */
unsigned char g_ledState[12];
unsigned char g_blinkPhase[12];
unsigned int  g_blinkTimer[12];

volatile bit g_detectLogFlag = 0;
volatile unsigned char g_detectLogSlot = 0;
volatile unsigned char g_detectLogType = 0;

unsigned int Read_Temperature(void)
{
	unsigned int ntcVal;
	unsigned int temp_x10;

	test_adc = ADC_Sample(ADC_CH_NTC, 0);
	if(ADC_OK != test_adc)
		return g_temperature;

	ntcVal = adresult;
	if(ntcVal < 100 || ntcVal > 3996)
		return g_temperature;

	{
		unsigned long rt;
		rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
		if(rt >= 10000UL)
			temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
		else
			temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
		if(temp_x10 < 100U) temp_x10 = 100U;
		if(temp_x10 > 750U) temp_x10 = 750U;
	}

	g_temperature = temp_x10;
	if((temp_x10 / 10U) >= TEMP_STOP)
		g_tempProtect = 1;
	else if((temp_x10 / 10U) <= TEMP_RESUME)
		g_tempProtect = 0;

	return temp_x10;
}

unsigned char Detect_BatteryType(unsigned int voltage)
{
	if(voltage >= ADC_V_OPEN)
		return BAT_TYPE_UNKNOWN;
	if(voltage < ADC_V_SHORT)
		return BAT_TYPE_UNKNOWN;

#if NIMH_DETECT_ENABLE
	if(voltage >= ADC_V_NIMH_LOW && voltage <= ADC_V_NIMH_HIGH)
		return BAT_TYPE_AMBIGUOUS;
#endif

	if(voltage >= ADC_V_PRE_MIN && voltage <= ADC_V_FULL)
		return BAT_TYPE_LI_ION;
	if(voltage > ADC_V_FULL && voltage < ADC_V_OVER)
		return BAT_TYPE_LI_ION;
	if(voltage >= ADC_V_OVER && voltage < ADC_V_OPEN)
		return BAT_TYPE_LI_ION;
	if(voltage >= ADC_V_SHORT && voltage < ADC_V_PRE_MIN)
		return BAT_TYPE_LI_ION;

	return BAT_TYPE_UNKNOWN;
}

volatile BatterySlot_t g_slot[12];

/* 槽位字段读写辅助宏 */
#define SLOT_RD_ALL(idx, st, ty, v, ct)  do { \
	st = g_slot[(idx)].state; ty = g_slot[(idx)].type; \
	v  = g_slot[(idx)].voltage; ct = g_slot[(idx)].chargeTimer; \
} while(0)

#define SLOT_WR_ALL(idx, st, ty, v, ct)  do { \
	g_slot[(idx)].state = st; g_slot[(idx)].type = ty; \
	g_slot[(idx)].voltage = v; g_slot[(idx)].chargeTimer = ct; \
} while(0)

void ChargeProcess_Slot(unsigned char idx)
{
	unsigned char st, ty;
	unsigned int  v, ct;
	unsigned int  tick = 1;
	unsigned char old_st;                  /* 调试: 保存旧状态 */

	SLOT_RD_ALL(idx, st, ty, v, ct);
	old_st = st;                           /* 记录进入状态机前的状态 */

	switch(st)
	{
	case CHG_IDLE:
		ct = 0;
		st = CHG_DETECT;
		break;

	case CHG_DETECT:
		ct += tick;
		if(ct < TIME_DETECT_WAIT)
			break;

		/* 消抖: 高内阻电池ADC读数可能跳动到极低值,
		   连续N次低值才判定为UNKNOWN, 避免单次噪点误触发ERROR */
		if(v < ADC_V_SHORT)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < DETECT_LOW_DEBOUNCE)
				break;
		}
		else
		{
			g_detectLowCnt[idx] = 0;
		}

		ty = Detect_BatteryType(v);

		if(ty == BAT_TYPE_AMBIGUOUS)
		{
			g_impRefV[idx] = v;
			st = CHG_IMP_CHECK;
			ct = 0;
			g_detectLowCnt[idx] = 0;
		}
		else if(ty == BAT_TYPE_NIMH || ty == BAT_TYPE_DRY || ty == BAT_TYPE_UNKNOWN)
		{
			st = CHG_ERROR;
			g_detectLowCnt[idx] = 0;
			if(ty == BAT_TYPE_NIMH || ty == BAT_TYPE_DRY)
			{
				g_detectLogSlot = idx;
				g_detectLogType = ty;
				g_detectLogFlag = 1;
			}
		}
		else
		{
			/* DETECT路由: 使用校准后的电池mV判断, 而非原始ADC值
			   深度过放电池(如864mV)内阻高, 直接上78%PWM会导致充电异常
			   用bat_mv判断可将低电压电池路由到PRECHARGE用小电流预充 */
			{
				unsigned long vx_mv = (unsigned long)v * (unsigned long)g_vcc_mv / 4096UL;
				unsigned long bat_mv_long = ALPHA_NUM * vx_mv;
				unsigned int  bat_mv = 0;

				if(bat_mv_long > (BETA_NUM * (unsigned long)g_vcc_mv))
				{
					bat_mv_long = (bat_mv_long - BETA_NUM * (unsigned long)g_vcc_mv + CAL_DEN/2UL) / CAL_DEN;
					bat_mv = (unsigned int)bat_mv_long;
				}

				if(bat_mv <= BAT_MV_ACTIVATE)
				{
					st = CHG_ACTIVATE;
					ct = 0;
					g_ovCnt[idx] = 0;
					g_detectLowCnt[idx] = 0;
				}
				else if(bat_mv < BAT_MV_PRECHARGE)
				{
					st = CHG_PRECHARGE;
					ct = 0;
					g_ovCnt[idx] = 0;
					g_detectLowCnt[idx] = 0;
				}
				else if(bat_mv >= BAT_MV_FULL)
				{
					st = CHG_CV_CHARGE;
					ct = 0;
					g_ovCnt[idx] = 0;
					g_detectLowCnt[idx] = 0;
				}
				else
				{
					st = CHG_CC_CHARGE;
					ct = 0;
					g_ccBlocks[idx] = 0;
					g_ovCnt[idx] = 0;
					g_detectLowCnt[idx] = 0;
				}
			}
		}
		break;

	case CHG_IMP_CHECK:
		if(v >= ADC_V_OPEN)
		{
			ty = BAT_TYPE_UNKNOWN;
			st = CHG_IDLE;
			break;
		}
		ct += tick;
		if(ct < IMP_PULSE_TICKS)
			break;

		{
			unsigned int v_before = g_impRefV[idx];
			unsigned int delta;
			if(v_before > v) delta = v_before - v;
			else             delta = 0;

			if(delta > IMP_DELTA_THRESH)
			{
				ty = BAT_TYPE_DRY;
				st = CHG_ERROR;
				g_detectLogSlot = idx;
				g_detectLogType = BAT_TYPE_DRY;
				g_detectLogFlag = 1;
			}
			else
			{
				g_impRefV[idx] = v;
				st = CHG_NIMH_WATCH;
				ct = 0;
			}
		}
		break;

	case CHG_NIMH_WATCH:
		if(v >= ADC_V_OPEN)
		{
			ty = BAT_TYPE_UNKNOWN;
			st = CHG_IDLE;
			break;
		}
		ct += tick;
		if(ct < NIMH_WATCH_TICKS)
		{
			if(v > ADC_V_NIMH_HIGH)
			{
				ty = BAT_TYPE_LI_ION;
				st = CHG_CC_CHARGE;
				ct = 0;
				g_ccBlocks[idx] = 0;
				g_ovCnt[idx] = 0;
			}
			break;
		}

		{
			unsigned int v_start = g_impRefV[idx];
			unsigned int rise;
			if(v > v_start) rise = v - v_start;
			else            rise = 0;

			if(rise >= NIMH_WATCH_RISE && v > ADC_V_NIMH_HIGH)
			{
				ty = BAT_TYPE_LI_ION;
				st = CHG_CC_CHARGE;
				ct = 0;
				g_ccBlocks[idx] = 0;
				g_ovCnt[idx] = 0;
			}
			else
			{
				ty = BAT_TYPE_NIMH;
				st = CHG_ERROR;
				g_detectLogSlot = idx;
				g_detectLogType = BAT_TYPE_NIMH;
				g_detectLogFlag = 1;
			}
		}
		break;

	case CHG_ACTIVATE:
		ct += tick;
		if(ct > TIME_ACTIVATE_MAX)
		{
			st = CHG_ERROR;
			break;
		}
		if(v > ADC_V_ACTIVATE)
		{
			st = CHG_PRECHARGE;
			ct = 0;
			break;
		}
		if(v >= ADC_V_OVER)
		{
			st = CHG_ERROR;
			break;
		}
		break;

	case CHG_PRECHARGE:
		ct += tick;
		if(ct > TIME_PRECHARGE_MAX)
		{
			st = CHG_ERROR;
			break;
		}
		if(v >= ADC_V_OVER)
		{
			g_ovCnt[idx]++;
			if(g_ovCnt[idx] >= OV_DEBOUNCE_CNT)
			{
				st = CHG_ERROR;
				break;
			}
		}
		else
		{
			g_ovCnt[idx] = 0;
		}
		if(v >= ADC_V_PRE_MAX)
		{
			st = CHG_CC_CHARGE;
			ct = 0;
			g_ccBlocks[idx] = 0;
			g_ovCnt[idx] = 0;
		}
		break;

	case CHG_CC_CHARGE:
		ct += tick;
		if(ct >= CC_BLOCK_TICKS)
		{
			ct -= CC_BLOCK_TICKS;
			g_ccBlocks[idx]++;
		}
		if(g_ccBlocks[idx] >= CC_MAX_BLOCKS)
		{
			st = CHG_ERROR;
			break;
		}
		if(v >= ADC_V_OVER)
		{
			g_ovCnt[idx]++;
			if(g_ovCnt[idx] >= OV_DEBOUNCE_CNT)
			{
				st = CHG_ERROR;
				break;
			}
		}
		else
		{
			g_ovCnt[idx] = 0;
			if(v >= ADC_V_FULL)
			{
				st = CHG_CV_CHARGE;
				ct = 0;
			}
		}
		break;

	case CHG_CV_CHARGE:
		ct += tick;
		if(ct > TIME_CV_HOLD)
			st = CHG_FULL;
		break;

	case CHG_FULL:
		if(v < (ADC_V_FULL - 10))
		{
			st = CHG_CC_CHARGE;
			ct = 0;
			g_ovCnt[idx] = 0;
		}
		break;

	case CHG_ERROR:
		if(ty == BAT_TYPE_NIMH || ty == BAT_TYPE_DRY)
		{
			if(v >= ADC_V_OPEN)
			{
				ty = BAT_TYPE_UNKNOWN;
				st = CHG_IDLE;
				ct = 0;
			}
			break;
		}
		if(v > ADC_V_ACTIVATE && v < ADC_V_OPEN)
		{
			st = CHG_DETECT;
			ct = 0;
		}
		break;

	default:
		st = CHG_IDLE;
		break;
	}

	SLOT_WR_ALL(idx, st, ty, v, ct);

	/* 调试: 追踪 slot 0 的每一次状态跳转 */
	if(idx == 0 && st != old_st)
	{
		g_dbgSlot = idx;
		g_dbgOldState = old_st;
		g_dbgNewState = st;
		g_dbgNewType = ty;
		g_dbgVoltage = v;
		g_dbgDetectFlag = 1;
	}
}

/*========================================================================
  函数: Charging_Control
  功能: 12路充电使能控制(含温度保护)
  说明: 每轮扫描结束后调用一次(在槽位0的Phase2中)
  流程:
    1. 温度保护检查: 温度>=60C则关闭所有充电
    2. 遍历12个槽位, 根据状态决定是否充电
    3. 充电状态(ACTIVATE/PRECHARGE/CC_CHARGE/CV_CHARGE): 打开MOSFET
    4. 其他状态: 关闭MOSFET
    5. 有充电则置位组控制(CD1/CD2), PWM占空比由CCCV_Control单独计算
  MOSFET控制: AO3401 P沟道, Gate=Low导通, Gate=High关闭
========================================================================*/
void Charging_Control(void)
{
	unsigned char i;
	unsigned char chargeB1_6 = 0;    /* B1-B6组是否有充电: 0=无, 1=有 */
	unsigned char chargeB7_12 = 0;   /* B7-B12组是否有充电: 0=无, 1=有 */

	/* 温度保护: 温度过高, 关闭所有充电 */
	if(g_tempProtect)
	{
		SLOT_ALL_OFF();             /* 关闭所有MOSFET(Gate=High) */
		PIN_CD1 = 0;                /* 关闭组1充电 */
		PIN_CD2 = 0;                /* 关闭组2充电 */
		g_pwmDuty = 0;              /* ISR中自动输出PWM=0 */
		return;
	}

	/* 遍历12个槽位, 根据状态控制MOSFET */
	for(i = 0; i < BATTERY_SLOTS; i++)
	{
		unsigned char s = S_STATE(i);

		/* 充电状态: 激活/预充/恒流/恒压/阻抗检测/镍氢监视 -> 打开MOSFET */
		if(s == CHG_ACTIVATE || s == CHG_PRECHARGE ||
		   s == CHG_CC_CHARGE || s == CHG_CV_CHARGE ||
		   s == CHG_IMP_CHECK || s == CHG_NIMH_WATCH)
		{
			SLOT_CHARGE_ON(i);       /* Gate=Low, MOSFET导通 */

			/* 标记所属组有充电 */
			if(i < 6)
				chargeB1_6 = 1;
			else
				chargeB7_12 = 1;
		}
		else
		{
			SLOT_CHARGE_OFF(i);      /* Gate=High, MOSFET关闭 */
		}
	}

	/* 组控制输出: 控制CD1(B1-B6组)和CD2(B7-B12组) */
	PIN_CD1 = chargeB1_6;
	PIN_CD2 = chargeB7_12;

	/* PWM占空比由CCCV_Control()计算, ISR中自动生成波形, 此处不直接操作PIN_PWM */
}

/*========================================================================
  函数: CCCV_Control
  功能: CC-CV恒流恒压PWM占空比自动调节
  说明: 每轮扫描结束后调用(在Charging_Control之后)
  控制策略:
    CC恒流阶段(ACTIVATE/PRECHARGE/CC_CHARGE):
      - 使用固定占空比(CC_DUTY_TARGET=25/32≈78%)
      - 软启动: 每次+CC_DUTY_RAMP_STEP逐步增加到目标值
      - 无电流检测硬件, 通过固定占空比近似恒流效果
    CV恒压阶段(CV_CHARGE):
      - PI闭环控制, 以ADC_V_FULL为目标电压
      - 根据电压误差动态调节PWM占空比
      - 带积分限幅防饱和
  输出: 更新全局变量 g_pwmDuty (0~PWM_MAX),
        ISR中根据g_pwmDuty自动生成PWM波形
========================================================================*/
void CCCV_Control(void)
{
	unsigned char i;
	unsigned char hasCharging = 0;
	unsigned int  maxV = 0;
	unsigned char cvCount = 0;
	unsigned char ccCount = 0;
	unsigned char preCount = 0;

	/* 遍历12槽位, 找出充电状态和最高电压 */
	for(i = 0; i < BATTERY_SLOTS; i++)
	{
		unsigned char s = S_STATE(i);

		if(s == CHG_ACTIVATE || s == CHG_PRECHARGE ||
		   s == CHG_CC_CHARGE || s == CHG_CV_CHARGE ||
		   s == CHG_IMP_CHECK || s == CHG_NIMH_WATCH)
		{
			hasCharging = 1;
			{
				unsigned int vt = S_VOLT(i);
				if(vt > maxV) maxV = vt;
			}
			if(s == CHG_CV_CHARGE)
				cvCount++;
			if(s == CHG_CC_CHARGE)
				ccCount++;
			if(s == CHG_PRECHARGE || s == CHG_ACTIVATE)
				preCount++;
		}
	}

	/* 无充电槽位: 关闭PWM, 复位积分 */
	if(!hasCharging)
	{
		g_pwmDuty = 0;
		g_cvIntegral = 0;
		return;
	}

	/* --- CC/PRECHARGE阶段: 固定占空比 + 软启动 ---
	   CC_CHARGE槽存在时: 使用CC_DUTY_TARGET(25/32=78%)
	   仅ACTIVATE/PRECHARGE时: 使用PRE_DUTY_TARGET(8/32=25%)小电流预充
	   避免78%PWM对高内阻深度过放电池造成充电异常 */
	if(cvCount == 0)
	{
		unsigned char duty_target, duty_initial;

		if(ccCount > 0)
		{
			/* 有CC槽位: 使用标准CC占空比 */
			duty_target  = CC_DUTY_TARGET;
			duty_initial = CC_DUTY_INITIAL;
		}
		else if(preCount > 0)
		{
			/* 仅预充/激活: 使用低占空比小电流激活 */
			duty_target  = PRE_DUTY_TARGET;
			duty_initial = PRE_DUTY_INITIAL;
		}
		else
		{
			duty_target  = CC_DUTY_TARGET;
			duty_initial = CC_DUTY_INITIAL;
		}

		if(g_pwmDuty < duty_initial)
		{
			/* 首次充电: 软启动 */
			g_pwmDuty += CC_DUTY_RAMP_STEP;
			if(g_pwmDuty > duty_initial)
				g_pwmDuty = duty_initial;
		}
		else if(g_pwmDuty > duty_target)
		{
			/* 从高占空比回退: 直接使用目标占空比 */
			g_pwmDuty = duty_target;
		}
		else
		{
			/* 维持目标占空比 */
			g_pwmDuty = duty_target;
		}
		return;
	}

	/* --- CV恒压阶段: PI闭环控制 ---
	   目标: 维持电池电压在ADC_V_FULL(1.52V)
	   error > 0: 电压偏低, 需加大占空比
	   error < 0: 电压偏高, 需减小占空比
	   积分项累加稳态误差, 消除静差 */
	{
		int error = (int)(ADC_V_FULL) - (int)(maxV);

		/* 积分累加(带限幅防积分饱和) */
		g_cvIntegral += error * CV_KI;
		if(g_cvIntegral > CV_KI_LIMIT)
			g_cvIntegral = CV_KI_LIMIT;
		else if(g_cvIntegral < -CV_KI_LIMIT)
			g_cvIntegral = -CV_KI_LIMIT;

		/* PI计算: duty = current_duty + (Kp*error + Ki*integral)/8 */
		int adjust = (error * CV_KP + g_cvIntegral) / 8;
		int duty = (int)g_pwmDuty + adjust;

		/* 占空比限幅 */
		if(duty > PWM_MAX) duty = PWM_MAX;
		if(duty < 0)      duty = 0;

		g_pwmDuty = (unsigned char)duty;
	}
}