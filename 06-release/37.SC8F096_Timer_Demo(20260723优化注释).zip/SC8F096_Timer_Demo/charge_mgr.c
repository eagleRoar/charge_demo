/*-------------------------------------------
  L1211 12槽充电器 - 充电管理模块
-------------------------------------------*/
#include "config.h"

/* --- 本地常量(不依赖config.h的微调参数) --- */
#define DETECT_STABLE_TICKS      20    /* 高压稳定确认tick数: 20tick=200ms无显著下跌→真锂电 */

/*========================================================================
  全局变量
========================================================================*/
unsigned int g_temperature = 250;
unsigned char g_tempProtect = 0;
unsigned char g_vccProtect  = 0;         /* VCC低压保护标志: 1=VCC过低, 关闭充电 */
unsigned int g_slotRefV[BATTERY_SLOTS];  /* 槽位参考电压: DETECT存初始值/稳定基准, CC/CV存峰值 */
unsigned char g_ccBlocks[12];           /* CC阶段10分钟块计数(解决16bit chargeTimer溢出) */
unsigned char g_ovCnt[12];              /* 过压消抖计数器: 连续过压次数 */
unsigned char g_ccCycle = 0;            /* Charging_Control调用计数: 配合槽位索引
                                           实现LINEAR_LI MOSFET占空比错相控制,
                                           (g_ccCycle+i)%(LINEAR_LI_OFF_CYCLES+1)==0
                                           时导通→每槽1/11占空比≈8%, 保护IC恢复充足 */
unsigned char g_detectLowCnt[12];       /* 通用消抖计数器(短路消抖/AMBIGUOUS消抖/LI_ION消抖) */
unsigned char g_impCheckSlot = 0xFF;    /* IMP_CHECK串行锁: 0xFF=空闲, 其他=持有锁的槽号
                                           同一时间只允许一个槽做IMP_CHECK,
                                           避免NiMH拉垮VCC导致其他槽误判 */
/* g_stableCnt已合并至g_ccBlocks(复用DETECT阶段,CC阶段互斥), 省12B RAM */
unsigned int g_capFlag;                  /* 电容虚高标记位掩码: bit[i]=1表示槽i需扩展等待电容放电 */
unsigned int g_impData;                  /* IMP_CHECK共享数据: 低12位脉冲前电压+高4位VCC编码(100mV步进)
                                           因IMP_CHECK串行化, 同一时间仅一个槽使用 */
unsigned int g_highVFlag;                /* DETECT高压确认标记: bit[i]=1表示槽i在高压稳定循环中
                                           连续≥DETECT_STABLE_TICKS维持V>2900, 用于IMP_CHECK
                                           区分恒压锂电池charger IC断开(false low)和真干电池 */

/* LED闪烁: 全局统一计数器, 所有ERROR槽共用(省35B RAM) */
unsigned char g_blinkTick = 0;

volatile bit g_detectLogFlag = 0;
volatile unsigned char g_detectLogSlot = 0;
volatile unsigned char g_detectLogType = 0;

unsigned int Read_Temperature(void)
{
	unsigned int ntcVal;
	unsigned int temp_x10;

	test_adc = ADC_Sample(ADC_CH_NTC, 0);
	if(ADC_OK != test_adc)
		return g_temperature;

	ntcVal = adresult;
	if(ntcVal < 100 || ntcVal > 3996)
		return g_temperature;

	{
		unsigned long rt;
		rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
		if(rt >= 10000UL)
			temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
		else
			temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
		if(temp_x10 < 100U) temp_x10 = 100U;
		if(temp_x10 > 750U) temp_x10 = 750U;
	}

	g_temperature = temp_x10;
	if((temp_x10 / 10U) >= TEMP_STOP)
		g_tempProtect = 1;
	else if((temp_x10 / 10U) <= TEMP_RESUME)
		g_tempProtect = 0;

	return temp_x10;
}

unsigned char Detect_BatteryType(unsigned int voltage)
{
	if(voltage >= ADC_V_OPEN)
		return BAT_TYPE_UNKNOWN;
	if(voltage < ADC_V_SHORT)
		return BAT_TYPE_UNKNOWN;

#if NIMH_DETECT_ENABLE
	/* AMBIGUOUS区间[NIMH_LOW, OPEN): 覆盖低/中/高压电池, 全部进入IMP_CHECK
	   用VCC跌落脉冲区分:
	   - VCC跌>300mV → NiMH(极低内阻拉垮VCC)
	   - VCC跌>200mV → LI_ION(charger IC拉载)
	   - VCC不塌+电压>2300 → LINEAR_LI(无charger IC)
	   - VCC不塌+电压≤2300 → DRY(干电池拒充)
	   高位碳性/碱性若漏入CC, PEAK_DROP会在数秒内纠正 */
	if(voltage >= ADC_V_NIMH_LOW && voltage < ADC_V_OPEN)
		return BAT_TYPE_AMBIGUOUS;
#endif

	/* AMBIGUOUS区间以外: SHORT~NIMH_LOW(低压/过放锂) → LI_ION
	   或 OPEN以上 → UNKNOWN(已达L69返回) */
	if(voltage >= ADC_V_SHORT && voltage < ADC_V_OPEN)
		return BAT_TYPE_LI_ION;

	return BAT_TYPE_UNKNOWN;
}

volatile BatterySlot_t g_slot[12];

/* 槽位字段读写辅助宏 */
#define SLOT_RD_ALL(idx, st, ty, v, ct)  do { \
	st = g_slot[(idx)].state; ty = g_slot[(idx)].type; \
	v  = g_slot[(idx)].voltage; ct = g_slot[(idx)].chargeTimer; \
} while(0)

#define SLOT_WR_ALL(idx, st, ty, v, ct)  do { \
	g_slot[(idx)].state = st; g_slot[(idx)].type = ty; \
	g_slot[(idx)].voltage = v; g_slot[(idx)].chargeTimer = ct; \
} while(0)

/* 锂电池DETECT后统一充电路由: 计算bat_mv→按电压档位跳转ACTIVATE/PRECHARGE/CV/CC */
#define DETECT_LI_ROUTE(idx, v, st, ct)  do { \
	unsigned long vx_mv = (unsigned long)(v) * (unsigned long)g_vcc_mv / 4096UL; \
	unsigned long bat_mv_long = ALPHA_NUM * vx_mv + BETA_NUM * (unsigned long)g_vcc_mv; \
	unsigned int  bat_mv = (unsigned int)((bat_mv_long + CAL_DEN/2UL) / CAL_DEN); \
	if(bat_mv <= BAT_MV_ACTIVATE) { \
		st = CHG_ACTIVATE; \
	} else if(bat_mv < BAT_MV_PRECHARGE) { \
		st = CHG_PRECHARGE; \
	} else if(bat_mv >= BAT_MV_FULL) { \
		st = CHG_CV_CHARGE; \
		g_slotRefV[idx] = v; \
	} else { \
		st = CHG_CC_CHARGE; \
		g_ccBlocks[idx] = 0; \
		g_slotRefV[idx] = v; \
	} \
	ct = 0; \
	g_ovCnt[idx] = 0; \
	g_detectLowCnt[idx] = 0; \
} while(0)

/* IMP_CHECK阶段VCC解码: 从g_impData高4位还原脉冲前VCC(mV), 误差≤50mV */
#define IMP_VCC_DECODE(data)  (((((data) >> 12) & 0x0FU) + 38U) * 100U)

void ChargeProcess_Slot(unsigned char idx)
{
	unsigned char st, ty;                   /* st: 充电状态, ty: 电池类型 */
	unsigned int  v, ct;                   /* v: ADC电压, ct: 充电计时器 */
	unsigned int  tick = 1;
	unsigned char old_st;                  /* 调试: 保存旧状态 */

	SLOT_RD_ALL(idx, st, ty, v, ct);
	old_st = st;                           /* 记录进入状态机前的状态 */

	switch(st)
	{
	case CHG_IDLE:
		ct = 0;
		st = CHG_DETECT;
		g_highVFlag &= ~((unsigned int)1 << idx);
		/* IDLE→DETECT: 记录初始电压作为跳变检测基准。
		   线性锂保护电路可能在DETECT前就已断开(BxAD电容经100K充电至VCC),
		   必须在IDLE阶段记录真实电压。空槽(v≥OPEN)显式清零防残留误判。 */
		if(v < ADC_V_OPEN)
			g_slotRefV[idx] = v;
		else
			g_slotRefV[idx] = 0;
		break;

	case CHG_DETECT:
		ct += tick;

		/* ct==1首次进入: 重置计数器, 保留g_slotRefV(IDLE阶段记录的跳变基准) */
		if(ct == 1)
		{
			g_ccBlocks[idx] = 0;
			g_capFlag &= ~((unsigned int)1 << idx);
		}

		/* 线性锂电池保护断开跳变检测:
		   保护IC断开→BxAD电容经100K上拉至VCC→电压跳变。
		   跳幅>500排除PWM串扰(~300), ty!=LINEAR_LI防重复触发。
		   检测到后直接进CC, g_slotRefV清零在CC阶段重建峰值跟踪。 */
		if(v >= ADC_V_OPEN && g_slotRefV[idx] > 0 && g_slotRefV[idx] < ADC_V_OPEN
		   && ty != BAT_TYPE_LINEAR_LI
		   && (unsigned int)(v - g_slotRefV[idx]) > PROTECTION_JUMP_THRESH)
		{
			ty = BAT_TYPE_LINEAR_LI;
			g_highVFlag &= ~((unsigned int)1 << idx);
			/* 保护断开→直接CC: g_slotRefV清零, CC阶段从有效读数重建峰值 */
			g_slotRefV[idx] = 0;
			st = CHG_CC_CHARGE;
			g_ccBlocks[idx] = 0;
			ct = 0;
			g_ovCnt[idx] = 0;
			g_detectLowCnt[idx] = 0;
			break;
		}

		if(ct < TIME_DETECT_WAIT)
		{
			/* ct<TIME_DETECT_WAIT: 跟踪电压(仅v<OPEN时更新, 防OPEN污染基准) */
			if(v < ADC_V_OPEN)
				g_slotRefV[idx] = v;
			break;
		}

		/* 高内阻电池电容放电: ct=TIME_DETECT_WAIT时若v>2900标记g_capFlag(可能是电容虚高) */
		if(ct == TIME_DETECT_WAIT)
		{
			g_slotRefV[idx] = v;
			if(v > ADC_V_NIMH_MAX)
				g_capFlag |= (unsigned int)1 << idx;
			break;
		}
		if(v > ADC_V_NIMH_MAX && v < ADC_V_OPEN)
		{
			/* 门禁: 仅g_capFlag已置位或ty==AMBIGUOUS才进入高压稳定路径。
			   无cap标记的异常跳升(串扰/噪声)→重置DETECT重读。 */
			if(!(g_capFlag & ((unsigned int)1 << idx)) && ty != BAT_TYPE_AMBIGUOUS)
			{
				ct = 0;
				g_slotRefV[idx] = 0;
				g_ccBlocks[idx] = 0;
				g_detectLowCnt[idx] = 0;
				break;
			}

			/* 高压区间两阶段:
			   [1] 稳定确认: 连续DETECT_STABLE_TICKS无显著下跌
			   [2] 扩展等待: 电容放电至≤2900或超时→放行 */
			unsigned int v_init = g_slotRefV[idx];

			if(g_ccBlocks[idx] >= DETECT_STABLE_TICKS)
			{
				/* 高压稳定确认: 标记g_highVFlag供IMP_CHECK区分恒压锂(charger IC断开假象) */
				g_highVFlag |= (unsigned int)1 << idx;
				/* ── 阶段[2]: 扩展等待 ── */
				if(v <= ADC_V_NIMH_MAX)
				{
					/* 电压降至安全线→电容放电确认 */
					g_capFlag &= ~((unsigned int)1 << idx);
					g_ccBlocks[idx] = 0;
					g_highVFlag &= ~((unsigned int)1 << idx);
				}
				else if(ct < TIME_DETECT_WAIT + TIME_DETECT_SETTLE)
				{
					/* 高压锂电提前放行: 稳定2秒(200tick)后→IMP_CHECK */
					if((g_highVFlag & ((unsigned int)1 << idx)) &&
					   ct >= TIME_DETECT_WAIT + 200U)
						goto amb_shortcut;
					g_slotRefV[idx] = v;
					break;
				}
				else
				{
				/* 标签 amb_shortcut: DETECT高压超时→AMBIGUOUS后跳转amb_check */
			amb_shortcut:
					/* 超时仍>2900→AMBIGUOUS→IMP_CHECK(VCC跌落区分恒压锂/线性锂) */
					g_capFlag &= ~((unsigned int)1 << idx);
					g_ccBlocks[idx] = 0;
					ty = BAT_TYPE_AMBIGUOUS;
					goto amb_check;
				}
			}
			else
			{
				/* ── 阶段[1]: 稳定确认 ── */
				if(v + DETECT_SETTLE_DROP < v_init)
				{
					/* 仍在放电→重置计数 */
					g_slotRefV[idx] = v;
					g_ccBlocks[idx] = 0;
				}
				else
				{
					/* 电压稳定→递增计数 */
					g_slotRefV[idx] = v;
					g_ccBlocks[idx]++;
				}
				if(g_ccBlocks[idx] < DETECT_STABLE_TICKS)
					break;  /* 未稳定 */
				/* 稳定确认: 有cap标记→进入阶段[2]; 无→直接放行 */
				if(g_capFlag & ((unsigned int)1 << idx))
					break;
				g_ccBlocks[idx] = 0;
			}
		}
		else if(ct < TIME_DETECT_WAIT + TIME_DETECT_SETTLE && v < ADC_V_OPEN)
		{
			unsigned int v_ref = g_slotRefV[idx];
			if(v_ref < ADC_V_OPEN && v + DETECT_SETTLE_DROP < v_ref)
			{
				g_slotRefV[idx] = v;
				break;
			}
		}

		/* 电容放电标记: 曾标记者强制AMBIGUOUS→IMP_CHECK(VCC跌落区分NiMH/锂电/干电池),
		   无标记按电压直接分类 */
		if(g_capFlag & ((unsigned int)1 << idx))
		{
			g_capFlag &= ~((unsigned int)1 << idx);
			g_detectLowCnt[idx] = 0;
			ty = BAT_TYPE_AMBIGUOUS;
		}
		else
		{
			ty = Detect_BatteryType(v);
		}

		/* 低电压消抖: 连续N次v<SHORT判UNKNOWN。
		   AMBIGUOUS/LI_ION/LINEAR_LI各自维护消抖, 不在此重置。 */
		if(v < ADC_V_SHORT)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < DETECT_LOW_DEBOUNCE)
				break;
		}
		/* 仅对UNKNOWN/NIMH/DRY重置计数器, AMBIGUOUS和LI_ION各自维护消抖计数 */
		else if(ty != BAT_TYPE_AMBIGUOUS && ty != BAT_TYPE_LI_ION && ty != BAT_TYPE_LINEAR_LI)
		{
			g_detectLowCnt[idx] = 0;
		}

	/* 标签 amb_check: DETECT电池类型统一分发(AMBIGUOUS→IMP_CHECK, 锂电→路由, 干电池→ERROR) */
	amb_check:
		if(ty == BAT_TYPE_AMBIGUOUS)
		{
			/* AMBIGUOUS→IMP_CHECK: VCC跌落脉冲区分NiMH(>300mV)/Li-ion(>200mV)/干电池。
			   2帧消抖防VCC污染误判。串行锁防多槽同时IMP_CHECK干扰VCC。 */
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			/* 等待串行锁 */
			if(g_impCheckSlot != 0xFF && g_impCheckSlot != idx)
				break;
			g_impCheckSlot = idx;
			/* 采样当前VCC并编码至g_impData高4位(100mV分辨率, 覆盖3800~5100mV) */
			if(ADC_OK == ADC_Sample(ADC_CH_VREF, 0))
				g_vcc_mv = (unsigned int)(POWER_RATIO / adresult);
			g_impData = v | ((unsigned int)(((g_vcc_mv + 50U) / 100U) - 38U) << 12);
			st = CHG_IMP_CHECK;
			ct = 0;
			g_detectLowCnt[idx] = 0;
		}
		if(ty == BAT_TYPE_LI_ION || ty == BAT_TYPE_LINEAR_LI)
		{
			/* 2帧确认后路由充电(防ADC尖峰误判) */
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			DETECT_LI_ROUTE(idx, v, st, ct);
		}
		else if(ty == BAT_TYPE_UNKNOWN)
		{
			if(v >= ADC_V_OPEN)
			{
				/* v≥OPEN: 等待电容放电, 超时走AMBIGUOUS→IMP_CHECK区分空槽/锂电池 */
				if(ct < TIME_DETECT_WAIT + TIME_DETECT_SETTLE)
					break;
				ty = BAT_TYPE_AMBIGUOUS;
				goto amb_check;
			}
			else
			{
				st = CHG_ERROR;
			}
			g_detectLowCnt[idx] = 0;
		}
		else if(ty == BAT_TYPE_NIMH || ty == BAT_TYPE_DRY)
		{
			st = CHG_ERROR;
			g_detectLowCnt[idx] = 0;
			g_detectLogSlot = idx;
			g_detectLogType = ty;
			g_detectLogFlag = 1;
		}
		break;

	case CHG_IMP_CHECK:
		ct += tick;
		if(ct < IMP_PULSE_TICKS)
			break;

		{
			/* 采样当前VCC(IMP_CHECK期间MOSFET导通~80ms),
			   与脉冲前编码值比较区分电池类型 */
			if(ADC_OK == ADC_Sample(ADC_CH_VREF, 0))
				g_vcc_mv = (unsigned int)(POWER_RATIO / adresult);

			/* ① VCC跌落>300mV → NiMH(极低内阻拉垮VCC, 优先级最高) */
			if(IMP_VCC_DECODE(g_impData) > g_vcc_mv + 300U)
			{
				ty = BAT_TYPE_NIMH;
				st = CHG_ERROR;
				g_impCheckSlot = 0xFF;
				g_highVFlag &= ~((unsigned int)1 << idx);
				g_detectLogSlot = idx;
				g_detectLogType = BAT_TYPE_NIMH;
				g_detectLogFlag = 1;
				break;
			}

			/* ② 脉冲前+脉冲后均为OPEN → 空槽/拔出 */
			if(v >= ADC_V_OPEN && (g_impData & 0x0FFFU) >= ADC_V_OPEN)
			{
				ty = BAT_TYPE_UNKNOWN;
				st = CHG_IDLE;
				g_impCheckSlot = 0xFF;
				g_highVFlag &= ~((unsigned int)1 << idx);
				break;
			}

			/* ③ VCC跌落>100mV → 恒压锂(charger IC拉载) */
			if(IMP_VCC_DECODE(g_impData) > g_vcc_mv + 100U)
				goto imp_li_ion;

			/* ④ 线性锂检测:
			   脉冲前>3500→空槽噪声回IDLE, 脉冲前>2300→DIODE_TEST体二极管验证,
			   脉冲后≥OPEN→确认线性锂(体二极管阻断), 其余→DIODE_TEST */
		if((g_impData & 0x0FFFU) > 2300U)
		{
			if((g_impData & 0x0FFFU) > 3500U)
			{
				/* 空槽噪声, 回IDLE重检 */
				ty = BAT_TYPE_UNKNOWN;
				st = CHG_IDLE;
				g_impCheckSlot = 0xFF;
				g_highVFlag &= ~((unsigned int)1 << idx);
				g_slotRefV[idx] = 0;
				break;
			}
			/* 脉冲前2300~3500: DIODE_TEST验证(保留g_highVFlag供超时分档) */
			st = CHG_IMP_DIODE_TEST;
			ct = 0;
			break;
		}
		if(v >= ADC_V_OPEN)
			goto imp_linear_li;

		/* 其余: DIODE_TEST观察电容充电爬升区分线性锂/干电池 */
		st = CHG_IMP_DIODE_TEST;
		ct = 0;
		}
		break;

	/* 标签 imp_li_ion: 恒压锂共享路由(IMP_CHECK/DIODE_TEST确认后跳入) */
	imp_li_ion:
		g_impCheckSlot = 0xFF;
		g_highVFlag &= ~((unsigned int)1 << idx);
		ty = BAT_TYPE_LI_ION;
		DETECT_LI_ROUTE(idx, v, st, ct);
		break;

	/* 标签 imp_linear_li: 线性锂共享路由(v<OPEN用当前值, v≥OPEN用脉冲前电压) */
	imp_linear_li:
		g_impCheckSlot = 0xFF;
		g_highVFlag &= ~((unsigned int)1 << idx);
		ty = BAT_TYPE_LINEAR_LI;
		if(v < ADC_V_OPEN)
			DETECT_LI_ROUTE(idx, v, st, ct);
		else
			DETECT_LI_ROUTE(idx, (unsigned int)(g_impData & 0x0FFFU), st, ct);
		break;

	/* 体二极管检测: MOSFET关断观察BxAD电容经100K充电爬升。
	   线性锂(体二极管阻断)→爬升>900ADC, 恒压锂/干电池(体二极管钳位)→无显著爬升。
	   超时按电压分档: 高压→恒压锂, 低压→干电池。 */
	case CHG_IMP_DIODE_TEST:
		ct += tick;
		{
			/* 空判断: 线性锂中途拔出v=OPEN是电容充电中, 非真拔出, 继续等待 */
			if(v >= ADC_V_OPEN && (g_impData & 0x0FFFU) < ADC_V_OPEN)
			{
			}

			/* 爬升>阈值→线性锂 */
			if(v > (g_impData & 0x0FFFU) + DIODE_RISE_THRESH)
				goto imp_linear_li;

			if(ct >= DIODE_TEST_TICKS)
			{
				if((g_highVFlag & ((unsigned int)1 << idx)) || v > ADC_V_NIMH_MAX)
				{
					/* 高压→恒压锂 */
					goto imp_li_ion;
				}
				else
				{
					ty = BAT_TYPE_DRY;
					st = CHG_ERROR;
					g_impCheckSlot = 0xFF;
					g_highVFlag &= ~((unsigned int)1 << idx);
					g_detectLowCnt[idx] = 0;
					g_detectLogSlot = idx;
					g_detectLogType = BAT_TYPE_DRY;
					g_detectLogFlag = 1;
				}
			}
		}
		break;



	case CHG_ACTIVATE:
		ct += tick;
		if(ct > TIME_ACTIVATE_MAX)
		{
			st = CHG_ERROR;
			break;
		}
		if(v > ADC_V_ACTIVATE)
		{
			st = CHG_PRECHARGE;
			ct = 0;
			break;
		}
		if(v >= ADC_V_OVER)
		{
			st = CHG_ERROR;
			break;
		}
		break;

	case CHG_PRECHARGE:
		ct += tick;
		if(ct > TIME_PRECHARGE_MAX)
		{
			st = CHG_ERROR;
			break;
		}
		if(v >= ADC_V_OVER)
		{
			g_ovCnt[idx]++;
			if(g_ovCnt[idx] >= OV_DEBOUNCE_CNT)
			{
				st = CHG_ERROR;
				break;
			}
		}
		else
		{
			g_ovCnt[idx] = 0;
		}
		if(v >= ADC_V_PRE_MAX)
		{
			st = CHG_CC_CHARGE;
			ct = 0;
			g_ccBlocks[idx] = 0;
			g_ovCnt[idx] = 0;
			g_slotRefV[idx] = v;
		}
		break;

	case CHG_CC_CHARGE:
		ct += tick;
		if(ct >= CC_BLOCK_TICKS)
		{
			ct -= CC_BLOCK_TICKS;
			g_ccBlocks[idx]++;
		}
		if(g_ccBlocks[idx] >= CC_MAX_BLOCKS)
		{
			st = CHG_ERROR;
			break;
		}

		/* 线性锂时间基准CC→CV: 保护断开时ADC不可靠, 固定块数后强制CV */
		if(ty == BAT_TYPE_LINEAR_LI && g_ccBlocks[idx] >= LINEAR_LI_CC_BLOCKS)
		{
			st = CHG_CV_CHARGE;
			ct = 0;
			break;
		}

		/* 峰值跟踪: v<OPEN且>历史峰值时更新。LINEAR_LI加v<3500门禁防电容伪OPEN污染。 */
		if(v < ADC_V_OPEN && v > g_slotRefV[idx]
		   && (ty != BAT_TYPE_LINEAR_LI || v < 3500U))
			g_slotRefV[idx] = v;

		/* PEAK_DROP跌落重判: 峰值跌落>500→接触不良/误判, 回DETECT重检。2帧消抖。 */
		if(v < g_slotRefV[idx] && g_slotRefV[idx] - v > PEAK_DROP_THRESH)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			g_detectLowCnt[idx] = 0;
			st = CHG_DETECT;
			ct = 0;
			break;
		}
		else
		{
			g_detectLowCnt[idx] = 0;
		}

		/* 恒压锂LC9203DB: CC阶段v≥OPEN→电芯已满→FULL */
		if(v >= ADC_V_OPEN && ty == BAT_TYPE_LI_ION)
		{
			st = CHG_FULL;
			ct = 0;
			break;
		}

		/* LINEAR_LI: 用g_slotRefV峰值替代v判断CC→CV, 跳过OV(伪OPEN非真过压) */
		if(ty == BAT_TYPE_LINEAR_LI)
		{
			if(g_slotRefV[idx] >= ADC_V_FULL)
			{
				st = CHG_CV_CHARGE;
				ct = 0;
			}
			break;
		}

		/* 过压保护 */
		if(v >= ADC_V_OVER)
		{
			g_ovCnt[idx]++;
			if(g_ovCnt[idx] >= OV_DEBOUNCE_CNT)
			{
				st = CHG_ERROR;
				break;
			}
		}
		else
		{
			g_ovCnt[idx] = 0;
			/* CC→CV: 电压达到满电阈值(读数可靠时优先触发) */
			if(v >= ADC_V_FULL)
			{
				st = CHG_CV_CHARGE;
				ct = 0;
			}
		}
		break;

	case CHG_CV_CHARGE:
		ct += tick;
		if(ct > TIME_CV_HOLD)
			st = CHG_FULL;

		/* 峰值追踪: 同CC阶段, LINEAR_LI加v<3500门禁。 */
		if(v < ADC_V_OPEN && v > g_slotRefV[idx]
		   && (ty != BAT_TYPE_LINEAR_LI || v < 3500U))
			g_slotRefV[idx] = v;

		/* 拔出检测: LI_ION→FULL(电芯已满), LINEAR_LI=伪OPEN不触发, 其他→IDLE */
		if(v >= ADC_V_OPEN && ty != BAT_TYPE_LINEAR_LI)
		{
			if(ty == BAT_TYPE_LI_ION)
			{
				g_detectLowCnt[idx]++;
				if(g_detectLowCnt[idx] < 2)
					break;
				g_detectLowCnt[idx] = 0;
				st = CHG_FULL;
				ct = 0;
				break;
			}
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			g_detectLowCnt[idx] = 0;
			ty = BAT_TYPE_UNKNOWN;
			st = CHG_IDLE;
			ct = 0;
			break;
		}

		/* PEAK_DROP: 捕获碳性/碱性漏入CV后电压崩溃, 2帧消抖回DETECT */
		if(v < g_slotRefV[idx] && g_slotRefV[idx] - v > PEAK_DROP_THRESH)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] >= 2)
			{
				g_detectLowCnt[idx] = 0;
				ty = BAT_TYPE_UNKNOWN;
				st = CHG_DETECT;
				ct = 0;
				break;
			}
		}
		else
		{
			g_detectLowCnt[idx] = 0;
		}

		/* 过压保护 */
		if(v >= ADC_V_OVER)
		{
			g_ovCnt[idx]++;
			if(g_ovCnt[idx] >= OV_DEBOUNCE_CNT)
			{
				st = CHG_ERROR;
				break;
			}
		}
		else
		{
			g_ovCnt[idx] = 0;
		}
		break;

	case CHG_FULL:
		/* 拔出检测: v≥OPEN连续确认后回IDLE。LINEAR_LI用50帧消抖防伪OPEN误判。 */
		if(v >= ADC_V_OPEN)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] >= (ty == BAT_TYPE_LINEAR_LI ? 50 : 2))
			{
				g_detectLowCnt[idx] = 0;
				st = CHG_IDLE;
				ct = 0;
			}
			break;
		}
		/* 补电: v<2800→电池已放电→回CC(仅LI_ION/LINEAR_LI可达FULL, 无需额外类型检查) */
		if(v < 2800U)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			g_detectLowCnt[idx] = 0;
			st = CHG_CC_CHARGE;
			ct = 0;
			g_ccBlocks[idx] = 0;
			g_ovCnt[idx] = 0;
			g_slotRefV[idx] = v;
		}
		else
		{
			g_detectLowCnt[idx] = 0;
		}
		break;

	case CHG_ERROR:
		/* 拔出检测: v≥OPEN连续2帧→回IDLE */
		if(v >= ADC_V_OPEN)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			g_detectLowCnt[idx] = 0;
			ty = BAT_TYPE_UNKNOWN;
			st = CHG_IDLE;
			ct = 0;
			break;
		}
		/* NiMH/干电池重判: v>2700且g_highVFlag标记(曾高压稳定)→可能恒压锂误判→回DETECT。
		   无g_highVFlag→确认真NiMH/干电池, 锁定ERROR。 */
		if(ty == BAT_TYPE_NIMH || ty == BAT_TYPE_DRY)
		{
			if(v > 2700U && (g_highVFlag & ((unsigned int)1 << idx)))
			{
				g_detectLowCnt[idx]++;
				if(g_detectLowCnt[idx] < 2)
					break;
				g_detectLowCnt[idx] = 0;
				st = CHG_DETECT;
				ct = 0;
			}
			else
			{
				g_detectLowCnt[idx] = 0;
			}
			break;
		}
		/* 其他类型: v>ACTIVATE→回DETECT重判, 2帧确认 */
		if(v > ADC_V_ACTIVATE)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			g_detectLowCnt[idx] = 0;
			st = CHG_DETECT;
			ct = 0;
		}
		else
		{
			g_detectLowCnt[idx] = 0;
		}
		break;

	default:
		st = CHG_IDLE;
		break;
	}

	SLOT_WR_ALL(idx, st, ty, v, ct);

	/* 调试: 追踪 slot 0~5 的每一次状态跳转(扩展至B6用于调试) */
	if(idx <= 5 && st != old_st)
	{
		g_dbgSlot = idx;
		g_dbgOldState = old_st;
		g_dbgNewState = st;
		g_dbgNewType = ty;
		g_dbgVoltage = v;
		g_dbgDetectFlag = 1;
	}
}

/*========================================================================
  函数: Charging_Control
  功能: 12路充电使能控制(含温度保护)
  说明: 每轮扫描结束后调用一次(在槽位0的Phase2中)
  流程:
    1. 温度保护检查: 温度>=60C则关闭所有充电
    2. 遍历12个槽位, 根据状态决定是否充电
    3. 充电状态(ACTIVATE/PRECHARGE/CC_CHARGE/CV_CHARGE): 打开MOSFET
    4. 其他状态: 关闭MOSFET
    5. 有充电则置位组控制(CD1/CD2), PWM占空比由CCCV_Control单独计算
  MOSFET控制: AO3401 P沟道, Gate=Low导通, Gate=High关闭
========================================================================*/
void Charging_Control(void)
{
	unsigned char i;
	unsigned char chargeB1_6 = 0;    /* B1-B6组是否有充电: 0=无, 1=有 */
	unsigned char chargeB7_12 = 0;   /* B7-B12组是否有充电: 0=无, 1=有 */

	/* 温度保护: 温度过高, 关闭所有充电 */
	if(g_tempProtect)
	{
		SLOT_ALL_OFF();             /* 关闭所有MOSFET(Gate=High) */
		PIN_CD1 = 0;                /* 关闭组1充电 */
		PIN_CD2 = 0;                /* 关闭组2充电 */
		g_pwmDuty = 0;              /* ISR中自动输出PWM=0 */
		return;
	}

	/* VCC低压保护: 电源过载时VCC跌落 → 关闭所有充电
	   防止ADC读数异常导致空槽被误判为有电池(VCC崩溃时实测ADC可从4095跌至~2700)
	   200mV回差防抖, 避免临界电压反复开关 */
	if(g_vccProtect)
	{
		if(g_vcc_mv < VCC_UVLO_RESUME)
		{
			SLOT_ALL_OFF();
			PIN_CD1 = 0;
			PIN_CD2 = 0;
			g_pwmDuty = 0;
			return;
		}
		g_vccProtect = 0;          /* VCC恢复, 解除保护 */
	}
	else
	{
		if(g_vcc_mv < VCC_UVLO_STOP)
		{
			g_vccProtect = 1;      /* VCC过低, 触发保护 */
			SLOT_ALL_OFF();
			PIN_CD1 = 0;
			PIN_CD2 = 0;
			g_pwmDuty = 0;
			return;
		}
	}

	/* 遍历12个槽位, 根据状态控制MOSFET */
	for(i = 0; i < BATTERY_SLOTS; i++)
	{
		unsigned char s = S_STATE(i);

		/* 充电状态: 激活/预充/恒流/恒压/阻抗检测 -> 打开MOSFET+CDx使能 */
		if(s == CHG_ACTIVATE || s == CHG_PRECHARGE ||
		   s == CHG_CC_CHARGE || s == CHG_CV_CHARGE ||
		   s == CHG_IMP_CHECK)
		{
			/* LINEAR_LI CC/CV占空比控制: 平衡MOSFET ON/OFF时间
			   ISR中Charging_Control仅在slot0 Phase2运行→B1 ON~66ms/OFF~6ms
			   B3 ON~6ms/OFF~66ms→保护IC恢复充足. 用错相分配:(g_ccCycle+i)%11==0
			   时导通→每槽每11次Charging_Control导通1次→OFF≥720ms→保护IC可恢复 */
			if(S_TYPE(i) == BAT_TYPE_LINEAR_LI &&
			   (s == CHG_CC_CHARGE || s == CHG_CV_CHARGE))
			{
				if(((unsigned int)g_ccCycle + i) % (LINEAR_LI_OFF_CYCLES + 1U) == 0)
				{
					SLOT_CHARGE_ON(i);
					if(i < 6) chargeB1_6 = 1;
					else      chargeB7_12 = 1;
				}
				else
				{
					SLOT_CHARGE_OFF(i);
				}
			}
			else
			{
				SLOT_CHARGE_ON(i);       /* Gate=Low, MOSFET导通 */

				/* 标记所属组有充电 */
				if(i < 6)
					chargeB1_6 = 1;
				else
					chargeB7_12 = 1;
			}
		}
		/* DETECT状态: 仅打开MOSFET(连接BxAD到电池测电压),
		   不使能CDx(避免g_pwmDuty=0时总线拉低导致电池经体二极管放电) */
		else if(s == CHG_DETECT)
		{
			SLOT_CHARGE_ON(i);       /* Gate=Low, MOSFET导通, Source浮空 */
		}
		else
		{
			SLOT_CHARGE_OFF(i);      /* Gate=High, MOSFET关闭 */
		}
	}

	g_ccCycle++;  /* Charging_Control每次调用递增, 8bit自然溢出 */

	/* 组控制输出: 控制CD1(B1-B6组)和CD2(B7-B12组) */
	PIN_CD1 = chargeB1_6;
	PIN_CD2 = chargeB7_12;

	/* PWM占空比由CCCV_Control()计算, ISR中自动生成波形, 此处不直接操作PIN_PWM */
}

/*========================================================================
  函数: CCCV_Control
  功能: CC-CV恒流恒压PWM占空比自动调节
  说明: 每轮扫描结束后调用(在Charging_Control之后)
  控制策略:
    CC恒流阶段(ACTIVATE/PRECHARGE/CC_CHARGE):
      - 使用固定占空比(CC_DUTY_TARGET=25/32≈78%)
      - 软启动: 每次+CC_DUTY_RAMP_STEP逐步增加到目标值
      - 无电流检测硬件, 通过固定占空比近似恒流效果
    CV恒压阶段(CV_CHARGE):
      - PI闭环控制, 以ADC_V_FULL为目标电压
      - 根据电压误差动态调节PWM占空比
      - 带积分限幅防饱和
  输出: 更新全局变量 g_pwmDuty (0~PWM_MAX),
        ISR中根据g_pwmDuty自动生成PWM波形
========================================================================*/
void CCCV_Control(void)
{
	unsigned char i;
	unsigned char hasCharging = 0;
	unsigned int  maxV = 0;
	unsigned char cvCount = 0;
	unsigned char ccCount = 0;
	unsigned char preCount = 0;

	/* 遍历12槽位, 找出充电状态和最高电压 */
	for(i = 0; i < BATTERY_SLOTS; i++)
	{
		unsigned char s = S_STATE(i);

		if(s == CHG_ACTIVATE || s == CHG_PRECHARGE ||
		   s == CHG_CC_CHARGE || s == CHG_CV_CHARGE ||
		   s == CHG_IMP_CHECK)
		{
			hasCharging = 1;
			{
				unsigned int vt = S_VOLT(i);
				if(vt > maxV) maxV = vt;
			}
			if(s == CHG_CV_CHARGE)
				cvCount++;
			if(s == CHG_CC_CHARGE)
				ccCount++;
			if(s == CHG_PRECHARGE || s == CHG_ACTIVATE)
				preCount++;
		}
	}

	/* 无充电槽位: 关闭PWM, 复位积分 */
	if(!hasCharging)
	{
		g_pwmDuty = 0;
		g_cvIntegral = 0;
		return;
	}

	/* --- CC/PRECHARGE阶段: 固定占空比 + 软启动 ---
	   CC_CHARGE槽存在时: 使用CC_DUTY_TARGET(25/32=78%)
	   仅ACTIVATE/PRECHARGE时: 使用PRE_DUTY_TARGET(8/32=25%)小电流预充
	   避免78%PWM对高内阻深度过放电池造成充电异常 */
	if(cvCount == 0)
	{
		unsigned char duty_target, duty_initial;

		if(ccCount > 0)
		{
			/* 有CC槽位: 使用标准CC占空比 */
			duty_target  = CC_DUTY_TARGET;
			duty_initial = CC_DUTY_INITIAL;
		}
		else if(preCount > 0)
		{
			/* 仅预充/激活: 使用低占空比小电流激活 */
			duty_target  = PRE_DUTY_TARGET;
			duty_initial = PRE_DUTY_INITIAL;
		}
		else
		{
			/* 仅IMP_CHECK槽位: 78%占空比脉冲, 跳过硬启动
			   碳性电池可能短暂进入CC, PEAK_DROP会在数秒内纠正 */
			g_pwmDuty = CC_DUTY_TARGET;
			return;
		}

		if(g_pwmDuty < duty_initial)
		{
			/* 首次充电: 软启动 */
			g_pwmDuty += CC_DUTY_RAMP_STEP;
			if(g_pwmDuty > duty_initial)
				g_pwmDuty = duty_initial;
		}
		else if(g_pwmDuty > duty_target)
		{
			/* 从高占空比回退: 直接使用目标占空比 */
			g_pwmDuty = duty_target;
		}
		else
		{
			/* 维持目标占空比 */
			g_pwmDuty = duty_target;
		}
		return;
	}

	/* --- CV恒压阶段: PI闭环控制 ---
	   目标: 维持电池电压在ADC_V_FULL(1.52V)
	   error > 0: 电压偏低, 需加大占空比
	   error < 0: 电压偏高, 需减小占空比
	   积分项累加稳态误差, 消除静差 */
	{
		int error = (int)(ADC_V_FULL) - (int)(maxV);

		/* 积分累加(带限幅防积分饱和) */
		g_cvIntegral += error * CV_KI;
		if(g_cvIntegral > CV_KI_LIMIT)
			g_cvIntegral = CV_KI_LIMIT;
		else if(g_cvIntegral < -CV_KI_LIMIT)
			g_cvIntegral = -CV_KI_LIMIT;

		/* PI计算: duty = current_duty + (Kp*error + Ki*integral)/8 */
		int adjust = (error * CV_KP + g_cvIntegral) / 8;
		int duty = (int)g_pwmDuty + adjust;

		/* 占空比限幅 */
		if(duty > PWM_MAX) duty = PWM_MAX;
		if(duty < 0)      duty = 0;

		g_pwmDuty = (unsigned char)duty;
	}
}