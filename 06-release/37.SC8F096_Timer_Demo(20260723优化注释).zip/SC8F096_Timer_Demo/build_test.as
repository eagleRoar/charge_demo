opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ChargeProcess_Slot
	FNCALL	_main,_Do_AdcSample
	FNCALL	_main,_Do_NtcRead
	FNCALL	_main,_Print_DetectLog
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_System_Init
	FNCALL	_main,_uart_send_number
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_Print_DetectLog,_uart_send_char
	FNCALL	_Print_DetectLog,_uart_send_number
	FNCALL	_Print_DetectLog,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_Do_NtcRead,_Read_Temperature
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Do_AdcSample,_ADC_Sample
	FNCALL	_Do_AdcSample,___bmul
	FNCALL	_ChargeProcess_Slot,_ADC_Sample
	FNCALL	_ChargeProcess_Slot,_Detect_BatteryType
	FNCALL	_ChargeProcess_Slot,___bmul
	FNCALL	_ChargeProcess_Slot,___lldiv
	FNCALL	_ChargeProcess_Slot,___lmul
	FNCALL	_ChargeProcess_Slot,___lwdiv
	FNCALL	_ChargeProcess_Slot,___wmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_CCCV_Control
	FNCALL	_Isr_Timer,_Charging_Control
	FNCALL	_Isr_Timer,_Led_BlinkProcess
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Update_LED_Slot
	FNCALL	_Isr_Timer,i1_ADC_Sample
	FNCALL	_Isr_Timer,i1___lldiv
	FNCALL	_Charging_Control,i1___bmul
	FNCALL	_Charging_Control,i1___lwmod
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,i1___bmul
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_temperature
	global	_g_vcc_mv
	global	_g_impCheckSlot
psect	idataBANK0,class=CODE,space=0,delta=2,noexec
global __pidataBANK0
__pidataBANK0:
	file	"charge_mgr.c"
	line	12

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	file	"main.c"
	line	15

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

	file	"charge_mgr.c"
	line	23

;initializer for _g_impCheckSlot
	retlw	0FFh
	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"main.c"
	line	47
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_powerOnTimer
	global	_g_dbgDetectFlag
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_adcBusy
	global	_g_doAdcSample
	global	_g_detectLogFlag
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_cvIntegral
	global	_g_ccCycle
	global	_g_vccProtect
	global	_g_tempProtect
	global	_g_dbgNewType
	global	_g_dbgNewState
	global	_g_dbgOldState
	global	_g_dbgSlot
	global	_g_tempPhase
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_scanPhase
	global	_g_scanIndex
	global	_g_detectLogType
	global	_g_detectLogSlot
	global	_test_adc
	global	_g_blinkTick
	global	_adresult
	global	_g_highVFlag
	global	_g_impData
	global	_g_capFlag
	global	_g_dbgVoltage
	global	_g_printTick
	global	_g_slot
	global	_g_slotRefV
	global	_g_detectLowCnt
	global	_g_ovCnt
	global	_g_ccBlocks
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_GIE
_GIE	set	0x5F
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RC4
_RC4	set	0x834
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC5
_RC5	set	0x835
	global	_RC3
_RC3	set	0x833
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_34:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_35:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_33:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_36:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	45	;'-'
	retlw	105	;'i'
	retlw	111	;'o'
	retlw	110	;'n'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_8:	
	retlw	67	;'C'
	retlw	32	;' '
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	95	;'_'
	retlw	76	;'L'
	retlw	79	;'O'
	retlw	67	;'C'
	retlw	75	;'K'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_38:	
	retlw	68	;'D'
	retlw	66	;'B'
	retlw	71	;'G'
	retlw	58	;':'
	retlw	32	;' '
	retlw	115	;'s'
	retlw	108	;'l'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_37:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_11:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_39:	
	retlw	32	;' '
	retlw	111	;'o'
	retlw	108	;'l'
	retlw	100	;'d'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_29:	
	retlw	32	;' '
	retlw	98	;'b'
	retlw	108	;'l'
	retlw	107	;'k'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_40:	
	retlw	32	;' '
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	119	;'w'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_25:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	73	;'I'
	retlw	79	;'O'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_23:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_27:	
	retlw	32	;' '
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_42:	
	retlw	32	;' '
	retlw	86	;'V'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
	
STR_30:	
	retlw	47	;'/'
	retlw	0
psect	stringtext
STR_41	equ	STR_28+0
STR_7	equ	STR_2+0
STR_9	equ	STR_37+7
STR_31	equ	STR_37+7
STR_32	equ	STR_37+7
STR_43	equ	STR_37+7
; #config settings
	file	"build_test.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_g_dbgDetectFlag:
       ds      1

_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

_g_adcBusy:
       ds      1

_g_doAdcSample:
       ds      1

_g_detectLogFlag:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_g_powerOnTimer:
       ds      2

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_cvIntegral:
       ds      2

_g_ccCycle:
       ds      1

_g_vccProtect:
       ds      1

_g_tempProtect:
       ds      1

_g_dbgNewType:
       ds      1

_g_dbgNewState:
       ds      1

_g_dbgOldState:
       ds      1

_g_dbgSlot:
       ds      1

_g_tempPhase:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_scanPhase:
       ds      1

_g_scanIndex:
       ds      1

_g_detectLogType:
       ds      1

_g_detectLogSlot:
       ds      1

_test_adc:
       ds      1

_g_blinkTick:
       ds      1

_adresult:
       ds      2

psect	dataBANK0,class=BANK0,space=1,noexec
global __pdataBANK0
__pdataBANK0:
	file	"charge_mgr.c"
	line	12
_g_temperature:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_highVFlag:
       ds      2

_g_impData:
       ds      2

_g_capFlag:
       ds      2

_g_dbgVoltage:
       ds      2

_g_printTick:
       ds      2

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"main.c"
	line	15
_g_vcc_mv:
       ds      2

psect	dataBANK1
	file	"charge_mgr.c"
	line	23
_g_impCheckSlot:
       ds      1

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slotRefV:
       ds      24

_g_detectLowCnt:
       ds      12

_g_ovCnt:
       ds      12

_g_ccBlocks:
       ds      12

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"build_test.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
	fcall	__pidataBANK1+2		;fetch initializer
	movwf	__pdataBANK1+2&07fh		
; Initialize objects allocated to BANK0
	global __pidataBANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	fcall	__pidataBANK0+0		;fetch initializer
	movwf	__pdataBANK0+0&07fh		
	fcall	__pidataBANK0+1		;fetch initializer
	movwf	__pdataBANK0+1&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+03Ch)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+0Ah)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+019h)
	fcall	clear_ram0
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
	clrf	((__pbssCOMMON)+1)&07Fh
; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK3,class=BANK3,space=1,noexec
global __pcstackBANK3
__pcstackBANK3:
	global	ChargeProcess_Slot@v_ref
ChargeProcess_Slot@v_ref:	; 2 bytes @ 0x0
	ds	2
	global	ChargeProcess_Slot@bat_mv
ChargeProcess_Slot@bat_mv:	; 2 bytes @ 0x2
	ds	2
	global	ChargeProcess_Slot@bat_mv_400
ChargeProcess_Slot@bat_mv_400:	; 2 bytes @ 0x4
	ds	2
	global	ChargeProcess_Slot@bat_mv_403
ChargeProcess_Slot@bat_mv_403:	; 2 bytes @ 0x6
	ds	2
	global	ChargeProcess_Slot@bat_mv_406
ChargeProcess_Slot@bat_mv_406:	; 2 bytes @ 0x8
	ds	4
	global	ChargeProcess_Slot@st
ChargeProcess_Slot@st:	; 1 bytes @ 0xC
	ds	1
	global	ChargeProcess_Slot@ct
ChargeProcess_Slot@ct:	; 2 bytes @ 0xD
	ds	2
	global	ChargeProcess_Slot@ty
ChargeProcess_Slot@ty:	; 1 bytes @ 0xF
	ds	1
	global	ChargeProcess_Slot@v
ChargeProcess_Slot@v:	; 2 bytes @ 0x10
	ds	2
	global	ChargeProcess_Slot@idx
ChargeProcess_Slot@idx:	; 1 bytes @ 0x12
	ds	1
psect	cstackBANK2,class=BANK2,space=1,noexec
global __pcstackBANK2
__pcstackBANK2:
??_main:	; 1 bytes @ 0x0
	ds	2
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
?_ADC_Sample:	; 1 bytes @ 0x0
?_Detect_BatteryType:	; 1 bytes @ 0x0
?___bmul:	; 1 bytes @ 0x0
	global	?___wmul
?___wmul:	; 2 bytes @ 0x0
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x0
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x0
	global	?___lmul
?___lmul:	; 4 bytes @ 0x0
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x0
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x0
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x0
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x0
	global	___wmul@multiplier
___wmul@multiplier:	; 2 bytes @ 0x0
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x0
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x0
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x0
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x1
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x1
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x1
	ds	1
?_uart_send_string:	; 1 bytes @ 0x2
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x2
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x2
	global	___wmul@multiplicand
___wmul@multiplicand:	; 2 bytes @ 0x2
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x2
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x2
	ds	2
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x4
	global	___wmul@product
___wmul@product:	; 2 bytes @ 0x4
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x4
	ds	1
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x5
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x5
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x6
	ds	1
?_uart_send_number:	; 1 bytes @ 0x7
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x7
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x7
	ds	1
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x8
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x8
	ds	1
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x9
	ds	3
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0xC
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0xC
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0xC
	ds	2
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0xE
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0xF
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x10
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0x10
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x10
	ds	1
	global	_Print_NtcTemp$765
_Print_NtcTemp$765:	; 2 bytes @ 0x11
	ds	1
	global	Do_AdcSample@ch
Do_AdcSample@ch:	; 1 bytes @ 0x12
	ds	1
	global	Do_AdcSample@ty
Do_AdcSample@ty:	; 1 bytes @ 0x13
	global	_Print_NtcTemp$766
_Print_NtcTemp$766:	; 2 bytes @ 0x13
	ds	1
	global	Do_AdcSample@dly
Do_AdcSample@dly:	; 1 bytes @ 0x14
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x14
	ds	1
	global	Do_AdcSample@st
Do_AdcSample@st:	; 1 bytes @ 0x15
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x15
	ds	4
??_Read_Temperature:	; 1 bytes @ 0x19
??_ChargeProcess_Slot:	; 1 bytes @ 0x19
??_Print_SystemStatus:	; 1 bytes @ 0x19
	ds	4
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x1D
	ds	1
	global	ChargeProcess_Slot@v_init
ChargeProcess_Slot@v_init:	; 2 bytes @ 0x1E
	ds	2
	global	ChargeProcess_Slot@vx_mv
ChargeProcess_Slot@vx_mv:	; 4 bytes @ 0x20
	ds	1
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x21
	global	_Print_SystemStatus$767
_Print_SystemStatus$767:	; 2 bytes @ 0x21
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x23
	global	_Print_SystemStatus$768
_Print_SystemStatus$768:	; 2 bytes @ 0x23
	ds	1
	global	ChargeProcess_Slot@bat_mv_long
ChargeProcess_Slot@bat_mv_long:	; 4 bytes @ 0x24
	ds	1
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x25
	ds	3
	global	ChargeProcess_Slot@vx_mv_398
ChargeProcess_Slot@vx_mv_398:	; 4 bytes @ 0x28
	ds	1
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x29
	ds	1
	global	_Print_SystemStatus$285
_Print_SystemStatus$285:	; 2 bytes @ 0x2A
	ds	2
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x2C
	global	ChargeProcess_Slot@bat_mv_long_399
ChargeProcess_Slot@bat_mv_long_399:	; 4 bytes @ 0x2C
	ds	2
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0x2E
	ds	2
	global	ChargeProcess_Slot@vx_mv_401
ChargeProcess_Slot@vx_mv_401:	; 4 bytes @ 0x30
	ds	2
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0x32
	ds	2
	global	ChargeProcess_Slot@bat_mv_long_402
ChargeProcess_Slot@bat_mv_long_402:	; 4 bytes @ 0x34
	ds	2
	global	Print_SystemStatus@t
Print_SystemStatus@t:	; 1 bytes @ 0x36
	ds	1
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x37
	ds	1
	global	ChargeProcess_Slot@vx_mv_404
ChargeProcess_Slot@vx_mv_404:	; 4 bytes @ 0x38
	ds	1
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x39
	ds	3
	global	ChargeProcess_Slot@bat_mv_long_405
ChargeProcess_Slot@bat_mv_long_405:	; 4 bytes @ 0x3C
	ds	4
	global	_ChargeProcess_Slot$407
_ChargeProcess_Slot$407:	; 2 bytes @ 0x40
	ds	2
	global	ChargeProcess_Slot@old_st
ChargeProcess_Slot@old_st:	; 1 bytes @ 0x42
	ds	1
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Update_LED_Slot:	; 1 bytes @ 0x0
??_Update_LED_Slot:	; 1 bytes @ 0x0
?_Charging_Control:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Led_BlinkProcess:	; 1 bytes @ 0x0
??_Led_BlinkProcess:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_ChargeProcess_Slot:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Do_AdcSample:	; 1 bytes @ 0x0
?_Do_NtcRead:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_Print_DetectLog:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?i1_ADC_Sample:	; 1 bytes @ 0x0
?i1___bmul:	; 1 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	?i1___lwmod
?i1___lwmod:	; 2 bytes @ 0x0
	global	?i1___lldiv
?i1___lldiv:	; 4 bytes @ 0x0
Update_LED_Slot@idx:	; 1 bytes @ 0x0
	global	i1ADC_Sample@adldo
i1ADC_Sample@adldo:	; 1 bytes @ 0x0
	global	i1___bmul@multiplicand
i1___bmul@multiplicand:	; 1 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	global	i1___lwmod@divisor
i1___lwmod@divisor:	; 2 bytes @ 0x0
	global	i1___lldiv@divisor
i1___lldiv@divisor:	; 4 bytes @ 0x0
	ds	1
??i1_ADC_Sample:	; 1 bytes @ 0x1
??i1___bmul:	; 1 bytes @ 0x1
	global	i1___bmul@multiplier
i1___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
	global	i1___bmul@product
i1___bmul@product:	; 1 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	global	i1___lwmod@dividend
i1___lwmod@dividend:	; 2 bytes @ 0x2
	ds	2
??___awdiv:	; 1 bytes @ 0x4
??i1___lwmod:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	global	i1___lwmod@counter
i1___lwmod@counter:	; 1 bytes @ 0x4
	global	i1___lldiv@dividend
i1___lldiv@dividend:	; 4 bytes @ 0x4
	ds	1
??_Charging_Control:	; 1 bytes @ 0x5
	global	Charging_Control@chargeB1_6
Charging_Control@chargeB1_6:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	ds	1
	global	Charging_Control@chargeB7_12
Charging_Control@chargeB7_12:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	1
	global	Charging_Control@s
Charging_Control@s:	; 1 bytes @ 0x7
	ds	1
??_CCCV_Control:	; 1 bytes @ 0x8
??i1___lldiv:	; 1 bytes @ 0x8
	global	Charging_Control@i
Charging_Control@i:	; 1 bytes @ 0x8
	ds	2
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	i1ADC_Sample@adch
i1ADC_Sample@adch:	; 1 bytes @ 0x0
	global	i1___lldiv@counter
i1___lldiv@counter:	; 1 bytes @ 0x0
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x0
	ds	1
	global	i1ADC_Sample@j
i1ADC_Sample@j:	; 1 bytes @ 0x1
	global	i1___lldiv@quotient
i1___lldiv@quotient:	; 4 bytes @ 0x1
	ds	1
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x2
	global	i1ADC_Sample@i
i1ADC_Sample@i:	; 1 bytes @ 0x2
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x3
	global	i1ADC_Sample@adsum
i1ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0x4
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0x5
	ds	1
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x6
	ds	1
	global	i1ADC_Sample@admin
i1ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x8
	ds	1
	global	i1ADC_Sample@admax
i1ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	1
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xA
	ds	1
	global	i1ADC_Sample@ad_temp
i1ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0xC
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0xD
	ds	1
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0xE
	ds	2
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x10
	ds	1
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x11
	ds	1
??_Isr_Timer:	; 1 bytes @ 0x12
	ds	4
	global	Isr_Timer@pt
Isr_Timer@pt:	; 4 bytes @ 0x16
	ds	4
??_AD_Init:	; 1 bytes @ 0x1A
??_uart_init:	; 1 bytes @ 0x1A
??_uart_send_char:	; 1 bytes @ 0x1A
??_System_Init:	; 1 bytes @ 0x1A
??_Do_AdcSample:	; 1 bytes @ 0x1A
??_Do_NtcRead:	; 1 bytes @ 0x1A
??_Detect_BatteryType:	; 1 bytes @ 0x1A
??___wmul:	; 1 bytes @ 0x1A
??___lmul:	; 1 bytes @ 0x1A
??___bmul:	; 1 bytes @ 0x1A
??___lldiv:	; 1 bytes @ 0x1A
??___lwdiv:	; 1 bytes @ 0x1A
??___lwmod:	; 1 bytes @ 0x1A
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x1A
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x1A
	ds	1
??_uart_send_string:	; 1 bytes @ 0x1B
??_uart_send_number:	; 1 bytes @ 0x1B
??_Print_NtcTemp:	; 1 bytes @ 0x1B
??_Print_DetectLog:	; 1 bytes @ 0x1B
;!
;!Data Sizes:
;!    Strings     369
;!    Constant    12
;!    Data        5
;!    BSS         169
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     10      13
;!    BANK0            80     27      54
;!    BANK1            80     67      80
;!    BANK3            80     19      79
;!    BANK2            80      2      74

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 37
;!		 -> STR_43(CODE[3]), STR_42(CODE[4]), STR_41(CODE[5]), STR_40(CODE[6]), 
;!		 -> STR_39(CODE[6]), STR_38(CODE[11]), STR_37(CODE[10]), STR_36(CODE[21]), 
;!		 -> STR_35(CODE[34]), STR_34(CODE[37]), STR_33(CODE[33]), STR_32(CODE[3]), 
;!		 -> STR_31(CODE[3]), STR_30(CODE[2]), STR_29(CODE[6]), STR_28(CODE[5]), 
;!		 -> STR_27(CODE[5]), STR_26(CODE[6]), STR_25(CODE[6]), STR_24(CODE[6]), 
;!		 -> STR_23(CODE[6]), STR_22(CODE[16]), STR_21(CODE[13]), STR_20(CODE[15]), 
;!		 -> STR_19(CODE[7]), STR_18(CODE[5]), STR_17(CODE[5]), STR_16(CODE[6]), 
;!		 -> STR_15(CODE[6]), STR_14(CODE[6]), STR_13(CODE[7]), STR_12(CODE[4]), 
;!		 -> STR_11(CODE[6]), STR_10(CODE[6]), STR_9(CODE[3]), STR_8(CODE[12]), 
;!		 -> STR_7(CODE[2]), STR_6(CODE[6]), STR_5(CODE[5]), STR_4(CODE[29]), 
;!		 -> STR_3(CODE[4]), STR_2(CODE[2]), STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->_CCCV_Control
;!    _Charging_Control->i1___lwmod
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Do_AdcSample
;!    _main->_System_Init
;!    _Print_SystemStatus->___lwmod
;!    _Print_SystemStatus->_uart_send_char
;!    _Print_NtcTemp->___lwmod
;!    _Print_DetectLog->_uart_send_char
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwmod
;!    _uart_send_number->_uart_send_char
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    _Isr_Timer->_CCCV_Control
;!
;!Critical Paths under _main in BANK1
;!
;!    _main->_ChargeProcess_Slot
;!    _System_Init->___bmul
;!    _Print_SystemStatus->___lldiv
;!    _Print_NtcTemp->_uart_send_number
;!    _Print_DetectLog->_uart_send_number
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _Do_NtcRead->_Read_Temperature
;!    _Read_Temperature->___lldiv
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->___lldiv
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    _main->_ChargeProcess_Slot
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 2     2      0   78471
;!                                              0 BANK2      2     2      0
;!                 _ChargeProcess_Slot
;!                       _Do_AdcSample
;!                         _Do_NtcRead
;!                    _Print_DetectLog
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                        _System_Init
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1634
;!                                             26 BANK0      1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  33    33      0   17971
;!                                             25 BANK1     33    33      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    9082
;!                                             17 BANK1      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_DetectLog                                      0     0      0    7608
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    3631
;!                                              2 BANK1      2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_number                                    10     8      2    3833
;!                                              7 BANK1     10     8      2
;!                             ___bmul (ARG)
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     144
;!                                             26 BANK0      1     1      0
;!                                              0 BANK1      2     2      0
;! ---------------------------------------------------------------------------------
;! (2) ___lwmod                                              5     1      4     584
;!                                             26 BANK0      1     1      0
;!                                              0 BANK1      4     0      4
;! ---------------------------------------------------------------------------------
;! (1) _Do_NtcRead                                           0     0      0    7643
;!                   _Read_Temperature
;! ---------------------------------------------------------------------------------
;! (2) _Read_Temperature                                    12    12      0    7643
;!                                             25 BANK1     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (1) _Do_AdcSample                                         5     5      0    2777
;!                                             26 BANK0      1     1      0
;!                                             18 BANK1      4     4      0
;!                         _ADC_Sample
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _ChargeProcess_Slot                                  61    61      0   24292
;!                                             25 BANK1     42    42      0
;!                                              0 BANK3     19    19      0
;!                         _ADC_Sample
;!                 _Detect_BatteryType
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (2) ___wmul                                               6     2      4    2458
;!                                              0 BANK1      6     2      4
;! ---------------------------------------------------------------------------------
;! (2) ___lwdiv                                              7     3      4    1010
;!                                              0 BANK1      7     3      4
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8    3236
;!                                              0 BANK1     12     4      8
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1712
;!                                             12 BANK1     13     5      8
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1    1286
;!                                              0 BANK1      3     2      1
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     331
;!                                              0 BANK1      2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _ADC_Sample                                          18    17      1    1125
;!                                              0 BANK1     18    17      1
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 2
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            8     8      0    4106
;!                                             18 BANK0      8     8      0
;!                       _CCCV_Control
;!                   _Charging_Control
;!                   _Led_BlinkProcess
;!                 _PowerOnLedSequence
;!                    _Update_LED_Slot
;!                       i1_ADC_Sample
;!                          i1___lldiv
;! ---------------------------------------------------------------------------------
;! (5) i1___lldiv                                           13     5      8      44
;!                                              0 COMMON     8     0      8
;!                                              0 BANK0      5     5      0
;! ---------------------------------------------------------------------------------
;! (5) i1_ADC_Sample                                        18    17      1     551
;!                                              0 COMMON     5     4      1
;!                                              0 BANK0     13    13      0
;! ---------------------------------------------------------------------------------
;! (5) _Update_LED_Slot                                      1     1      0       0
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Led_BlinkProcess                                     0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Charging_Control                                     4     4      0    1355
;!                                              5 COMMON     4     4      0
;!                           i1___bmul
;!                          i1___lwmod
;! ---------------------------------------------------------------------------------
;! (6) i1___lwmod                                            5     1      4     233
;!                                              0 COMMON     5     1      4
;! ---------------------------------------------------------------------------------
;! (5) _CCCV_Control                                        20    20      0    2108
;!                                              8 COMMON     2     2      0
;!                                              0 BANK0     18    18      0
;!                            ___awdiv
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (6) i1___bmul                                             3     2      1     144
;!                                              0 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (6) ___awdiv                                              8     4      4     428
;!                                              0 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ChargeProcess_Slot
;!     _ADC_Sample
;!     _Detect_BatteryType
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___wmul
;!   _Do_AdcSample
;!     _ADC_Sample
;!     ___bmul
;!   _Do_NtcRead
;!     _Read_Temperature
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!       ___lwdiv
;!   _Print_DetectLog
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _uart_send_number
;!     ___bmul (ARG)
;!     ___lwdiv (ARG)
;!     ___lwmod (ARG)
;!     _uart_send_char (ARG)
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     i1___bmul
;!   _Charging_Control
;!     i1___bmul
;!     i1___lwmod
;!   _Led_BlinkProcess
;!   _PowerOnLedSequence
;!   _Update_LED_Slot
;!   i1_ADC_Sample
;!   i1___lldiv
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50     13      4F       8       98.8%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      2      4A      10       92.5%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50     43      50       6      100.0%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     1B      36       4       67.5%
;!BITBANK0            50      0       0       3        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      A       D       1       92.9%
;!BITCOMMON            E      0       1       0        7.1%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     12C      12        0.0%
;!ABS                  0      0     12C      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 509 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       2
;;      Totals:         0       0       0       0       2
;;Total ram usage:        2 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ChargeProcess_Slot
;;		_Do_AdcSample
;;		_Do_NtcRead
;;		_Print_DetectLog
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_System_Init
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"main.c"
	line	509
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"main.c"
	line	509
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	512
	
l8265:	
	opt asmopt_push
opt asmopt_off
movlw	52
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
movwf	((??_main+0)^0100h+0+1),f
	movlw	241
movwf	((??_main+0)^0100h+0),f
	u12537:
decfsz	((??_main+0)^0100h+0),f
	goto	u12537
	decfsz	((??_main+0)^0100h+0+1),f
	goto	u12537
opt asmopt_pop

	line	513
# 513 "main.c"
clrwdt ;# 
psect	maintext
	line	516
	
l8267:	
	fcall	_System_Init
	line	519
	
l8269:	
	movlw	low(((STR_36)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_36)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	520
	
l8271:	
	movlw	low(((STR_37)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_37)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	523
	
l473:	
	line	525
# 525 "main.c"
clrwdt ;# 
psect	maintext
	line	528
	
l8273:	
	btfss	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u12481
	goto	u12480
u12481:
	goto	l8303
u12480:
	line	530
	
l8275:	
	bcf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	line	531
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	532
	
l8277:	
	fcall	_Do_AdcSample
	line	533
	
l8279:	
	movf	(_g_scanIndex),w	;volatile
	fcall	_ChargeProcess_Slot
	line	536
	
l8281:	
	btfss	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	goto	u12491
	goto	u12490
u12491:
	goto	l8301
u12490:
	line	538
	
l8283:	
	bcf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	539
	
l8285:	
	movlw	low(((STR_38)|8000h))
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_38)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	540
	
l8287:	
	movf	(_g_dbgSlot),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	541
	
l8289:	
	movlw	low(((STR_39)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_39)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	542
	movf	(_g_dbgOldState),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	543
	
l8291:	
	movlw	low(((STR_40)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_40)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	544
	
l8293:	
	movf	(_g_dbgNewState),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	545
	movlw	low(((STR_41)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_41)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	546
	
l8295:	
	movf	(_g_dbgNewType),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	547
	
l8297:	
	movlw	low(((STR_42)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_42)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	548
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_dbgVoltage+1)^080h,w	;volatile
	movwf	(uart_send_number@num+1)^080h
	movf	(_g_dbgVoltage)^080h,w	;volatile
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	549
	
l8299:	
	movlw	low(((STR_43)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_43)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	552
	
l8301:	
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	556
	
l8303:	
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u12501
	goto	u12500
u12501:
	goto	l8311
u12500:
	line	558
	
l8305:	
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	559
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	560
	
l8307:	
	fcall	_Do_NtcRead
	line	561
	
l8309:	
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	565
	
l8311:	
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u12511
	goto	u12510
u12511:
	goto	l8317
u12510:
	line	567
	
l8313:	
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	568
	
l8315:	
	fcall	_Print_SystemStatus
	line	569
	fcall	_Print_NtcTemp
	line	573
	
l8317:	
	btfss	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	goto	u12521
	goto	u12520
u12521:
	goto	l473
u12520:
	line	575
	
l8319:	
	bcf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	line	576
	
l8321:	
	fcall	_Print_DetectLog
	goto	l473
	global	start
	ljmp	start
	opt stack 0
	line	579
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 68 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   26[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	68
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"main.c"
	line	68
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	73
	
l6931:	
# 73 "main.c"
nop ;# 
	line	74
# 74 "main.c"
clrwdt ;# 
psect	text1
	line	75
	
l6933:	
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	79
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	80
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	81
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l6935:	
	clrf	(262)^0100h	;volatile
	line	82
	
l6937:	
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l6939:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	85
	
l6941:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l6943:	
	clrf	(135)^080h	;volatile
	line	86
	
l6945:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l6947:	
	clrf	(7)	;volatile
	line	87
	
l6949:	
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	88
	
l6951:	
	clrf	(277)^0100h	;volatile
	line	91
	
l6953:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l6955:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	94
	
l6957:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	95
	
l6959:	
	clrf	(406)^0180h	;volatile
	line	102
	
l6961:	
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	103
	
l6963:	
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	104
	
l6965:	
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	105
	
l6967:	
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	108
	
l6969:	
	fcall	_AD_Init
	line	111
	
l6971:	
	fcall	_uart_init
	line	118
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	119
	
l6973:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	120
	
l6975:	
	bcf	(90/8),(90)&7	;volatile
	line	121
	
l6977:	
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	124
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	125
	clrf	(_g_pwmCounter)	;volatile
	line	126
	
l6979:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	127
	
l6981:	
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	128
	
l6983:	
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	129
	
l6985:	
	bcf	(55/8),(55)&7	;volatile
	line	132
	clrf	(System_Init@i)
	line	134
	
l6991:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	135
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	136
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	137
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	138
	
l6993:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	139
	
l6995:	
	movf	(System_Init@i),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	132
	
l6997:	
	incf	(System_Init@i),f
	
l6999:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u10041
	goto	u10040
u10041:
	goto	l6991
u10040:
	line	141
	
l7001:	
	clrf	(_g_blinkTick)
	line	144
	
l361:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"uart_dbg.c"
	line	21
global __ptext2
__ptext2:	;psect for function _uart_init
psect	text2
	file	"uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_init: []
	line	23
	
l6793:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l511:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	23
global __ptext3
__ptext3:	;psect for function _AD_Init
psect	text3
	file	"adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l6787:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
	clrf	(406)^0180h	;volatile
	line	27
	
l6789:	
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l6791:	
	clrf	(150)^080h	;volatile
	line	29
	
l488:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 355 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  t               1   54[BANK1 ] unsigned char 
;;  bat_mv_long     4   50[BANK1 ] unsigned long 
;;  vx_mv           4   46[BANK1 ] unsigned long 
;;  v               2   44[BANK1 ] unsigned int 
;;  s               1   41[BANK1 ] unsigned char 
;;  pt              4   37[BANK1 ] unsigned long 
;;  vcc_mv          2   55[BANK1 ] unsigned int 
;;  i               1   57[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      25       0       0
;;      Temps:          0       0       8       0       0
;;      Totals:         0       0      33       0       0
;;Total ram usage:       33 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	355
global __ptext4
__ptext4:	;psect for function _Print_SystemStatus
psect	text4
	file	"main.c"
	line	355
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	360
	
l7255:	
	movlw	low(((STR_4)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	363
	
l7257:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(ADC_Sample@adldo)^080h
	movlw	low(01Fh)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	364
	
l7259:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u10551
	goto	u10550
u10551:
	goto	l7265
u10550:
	line	366
	
l7261:	
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt)^080h

	line	367
	
l7263:	
	movf	(Print_SystemStatus@pt+1)^080h,w
	movwf	(Print_SystemStatus@vcc_mv+1)^080h
	movf	(Print_SystemStatus@pt)^080h,w
	movwf	(Print_SystemStatus@vcc_mv)^080h
	line	368
	goto	l428
	line	370
	
l7265:	
	movlw	088h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vcc_mv)^080h
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv)^080h)+1
	
l428:	
	line	372
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	line	374
	
l7267:	
	movlw	low(((STR_5)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	375
	
l7269:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	376
	
l7271:	
	movlw	low(((STR_6)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	377
	
l7273:	
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(_Print_SystemStatus$767+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(_Print_SystemStatus$767)^080h
	
l7275:	
	movf	(_Print_SystemStatus$767+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$767)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	378
	
l7277:	
	movlw	low(((STR_7)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	379
	
l7279:	
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@divisor)^080h
	clrf	(___lwmod@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend)^080h
	fcall	___lwmod
	movf	(1+(?___lwmod))^080h,w
	movwf	(_Print_SystemStatus$768+1)^080h
	movf	(0+(?___lwmod))^080h,w
	movwf	(_Print_SystemStatus$768)^080h
	
l7281:	
	movf	(_Print_SystemStatus$768+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$768)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	380
	
l7283:	
	movlw	low(((STR_8)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	381
	
l7285:	
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u10561
	goto	u10560
u10561:
	goto	l7289
u10560:
	
l7287:	
	movf	(_g_impCheckSlot)^080h,w
	movwf	(_Print_SystemStatus$285)^080h
	clrf	(_Print_SystemStatus$285+1)^080h
	goto	l7291
	
l7289:	
	movlw	0FFh
	movwf	(_Print_SystemStatus$285)^080h
	clrf	(_Print_SystemStatus$285+1)^080h
	
l7291:	
	movf	(_Print_SystemStatus$285+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$285)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	382
	
l7293:	
	movlw	low(((STR_9)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	386
	
l7295:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(Print_SystemStatus@i)^080h
	line	395
	
l7301:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Print_SystemStatus@v)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)^080h
	line	396
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Print_SystemStatus@s)^080h
	line	403
	
l7303:	
	movlw	low(042h)
	fcall	_uart_send_char
	line	404
	
l7305:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	incf	(uart_send_number@num)^080h,f
	skipnz
	incf	(uart_send_number@num+1)^080h,f
	fcall	_uart_send_number
	line	405
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	406
	
l7307:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(Print_SystemStatus@v)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	412
	
l7309:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Print_SystemStatus@v+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(___lmul@multiplicand)^080h
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv)^080h

	
l7311:	
	movlw	0Ch
u10575:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3)^080h,f
	rrf	(Print_SystemStatus@vx_mv+2)^080h,f
	rrf	(Print_SystemStatus@vx_mv+1)^080h,f
	rrf	(Print_SystemStatus@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u10575

	line	413
	
l7313:	
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	clrf	((??_Print_SystemStatus+0)^080h+0+2)
	clrf	((??_Print_SystemStatus+0)^080h+0+3)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+4)^080h+0)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	(Print_SystemStatus@vx_mv)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+0,f
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1)^080h,w
	goto	u10580
	goto	u10581
u10580:
	addwf	(??_Print_SystemStatus+4)^080h+1,f
u10581:
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2)^080h,w
	goto	u10582
	goto	u10583
u10582:
	addwf	(??_Print_SystemStatus+4)^080h+2,f
u10583:
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	subwf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u10595
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	subwf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u10595
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	subwf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u10595
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	subwf	0+(??_Print_SystemStatus+4)^080h+0,w
u10595:
	skipc
	goto	u10591
	goto	u10590
u10591:
	goto	l7317
u10590:
	line	415
	
l7315:	
	movlw	low(((STR_10)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	416
	goto	l7327
	line	419
	
l7317:	
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(Print_SystemStatus@vx_mv)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long)^080h

	line	420
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(Print_SystemStatus@bat_mv_long+3)^080h,w
	subwf	(3+(?___lmul))^080h,w
	skipz
	goto	u10605
	movf	(Print_SystemStatus@bat_mv_long+2)^080h,w
	subwf	(2+(?___lmul))^080h,w
	skipz
	goto	u10605
	movf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	subwf	(1+(?___lmul))^080h,w
	skipz
	goto	u10605
	movf	(Print_SystemStatus@bat_mv_long)^080h,w
	subwf	(0+(?___lmul))^080h,w
u10605:
	skipnc
	goto	u10601
	goto	u10600
u10601:
	goto	l7327
u10600:
	line	422
	
l7319:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+3)
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+1)^080h
	movlw	032h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(Print_SystemStatus@bat_mv_long)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+0)
	movlw	0
	skipnc
	movlw	1
	addwf	(1+(?___lmul))^080h,w
	clrf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	addwf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	movf	(2+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+2),w
	clrf	((??_Print_SystemStatus+4)^080h+0+3)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	addwf	(Print_SystemStatus@bat_mv_long+2)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	movf	(3+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+3),w
	addwf	(Print_SystemStatus@bat_mv_long+3)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	0+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+0,f
	movf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	1+(??_Print_SystemStatus+4)^080h+0,w
	goto	u10610
	goto	u10611
u10610:
	addwf	(??_Print_SystemStatus+0)^080h+1,f
u10611:
	movf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	2+(??_Print_SystemStatus+4)^080h+0,w
	goto	u10612
	goto	u10613
u10612:
	addwf	(??_Print_SystemStatus+0)^080h+2,f
u10613:
	movf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incf	3+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long)^080h

	line	423
	
l7321:	
	movlw	low(((STR_11)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	424
	
l7323:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(Print_SystemStatus@bat_mv_long)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	425
	
l7325:	
	movlw	low(((STR_12)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	432
	
l7327:	
	movlw	low(020h)
	fcall	_uart_send_char
	line	433
	goto	l7369
	line	435
	
l7329:	
	movlw	low(((STR_13)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7371
	line	436
	
l7331:	
	movlw	low(((STR_14)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7371
	line	437
	
l7333:	
	movlw	low(((STR_15)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7371
	line	438
	
l7335:	
	movlw	low(((STR_16)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7371
	line	439
	
l7337:	
	movlw	low(((STR_17)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7371
	line	440
	
l7339:	
	movlw	low(((STR_18)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7371
	line	441
	
l7341:	
	movlw	low(((STR_19)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7371
	line	444
	
l7343:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Print_SystemStatus@t)^080h
	line	445
	
l7345:	
		movlw	2
	xorwf	((Print_SystemStatus@t)^080h),w
	btfsc	status,2
	goto	u10621
	goto	u10620
u10621:
	goto	l7349
u10620:
	
l7347:	
		movlw	3
	xorwf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u10631
	goto	u10630
u10631:
	goto	l7351
u10630:
	line	446
	
l7349:	
	movlw	low(((STR_20)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7371
	line	447
	
l7351:	
		decf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u10641
	goto	u10640
u10641:
	goto	l7355
u10640:
	line	448
	
l7353:	
	movlw	low(((STR_21)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7371
	line	449
	
l7355:	
		movlw	6
	xorwf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u10651
	goto	u10650
u10651:
	goto	l7359
u10650:
	line	450
	
l7357:	
	movlw	low(((STR_22)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7371
	line	452
	
l7359:	
	movlw	low(((STR_23)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7371
	line	455
	
l7361:	
	movlw	low(((STR_24)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7371
	line	456
	
l7363:	
	movlw	low(((STR_25)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7371
	line	457
	
l7365:	
	movlw	low(((STR_26)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7371
	line	433
	
l7369:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@s)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l7329
	xorlw	1^0	; case 1
	skipnz
	goto	l7331
	xorlw	2^1	; case 2
	skipnz
	goto	l7333
	xorlw	3^2	; case 3
	skipnz
	goto	l7335
	xorlw	4^3	; case 4
	skipnz
	goto	l7337
	xorlw	5^4	; case 5
	skipnz
	goto	l7339
	xorlw	6^5	; case 6
	skipnz
	goto	l7341
	xorlw	7^6	; case 7
	skipnz
	goto	l7343
	xorlw	8^7	; case 8
	skipnz
	goto	l7361
	xorlw	9^8	; case 9
	skipnz
	goto	l7363
	goto	l7365
	opt asmopt_pop

	line	461
	
l7371:	
	movlw	low(((STR_27)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	462
	
l7373:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(uart_send_number@num)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	463
	
l7375:	
	movlw	low(((STR_28)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	464
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	466
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
		movlw	6
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u10661
	goto	u10660
u10661:
	goto	l7385
u10660:
	
l7377:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
		movlw	4
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u10671
	goto	u10670
u10671:
	goto	l7385
u10670:
	line	468
	
l7379:	
	movlw	low(((STR_29)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	469
	
l7381:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	470
	
l7383:	
	movlw	low(((STR_30)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	471
	movlw	08h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	475
	
l7385:	
	movlw	low(((STR_31)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	386
	
l7387:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(Print_SystemStatus@i)^080h,f
	
l7389:	
	movlw	low(06h)
	subwf	(Print_SystemStatus@i)^080h,w
	skipc
	goto	u10681
	goto	u10680
u10681:
	goto	l7301
u10680:
	line	478
	
l7391:	
	movlw	low(((STR_32)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	479
	
l460:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 335 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	335
global __ptext5
__ptext5:	;psect for function _Print_NtcTemp
psect	text5
	file	"main.c"
	line	335
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	337
	
l7243:	
	movlw	low(((STR_1)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	338
	
l7245:	
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(_Print_NtcTemp$765+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(_Print_NtcTemp$765)^080h
	
l7247:	
	movf	(_Print_NtcTemp$765+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$765)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	339
	
l7249:	
	movlw	low(((STR_2)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	340
	
l7251:	
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@divisor)^080h
	clrf	(___lwmod@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend)^080h
	fcall	___lwmod
	movf	(1+(?___lwmod))^080h,w
	movwf	(_Print_NtcTemp$766+1)^080h
	movf	(0+(?___lwmod))^080h,w
	movwf	(_Print_NtcTemp$766)^080h
	movf	(_Print_NtcTemp$766+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$766)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	341
	
l7253:	
	movlw	low(((STR_3)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	342
	
l424:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_Print_DetectLog

;; *************** function _Print_DetectLog *****************
;; Defined at:
;;		line 485 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	line	485
global __ptext6
__ptext6:	;psect for function _Print_DetectLog
psect	text6
	file	"main.c"
	line	485
	global	__size_of_Print_DetectLog
	__size_of_Print_DetectLog	equ	__end_of_Print_DetectLog-_Print_DetectLog
	
_Print_DetectLog:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_DetectLog: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	487
	
l7393:	
	movlw	low(042h)
	fcall	_uart_send_char
	line	488
	
l7395:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_detectLogSlot),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	incf	(uart_send_number@num)^080h,f
	skipnz
	incf	(uart_send_number@num+1)^080h,f
	fcall	_uart_send_number
	line	490
	
l7397:	
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u10691
	goto	u10690
u10691:
	goto	l7401
u10690:
	line	491
	
l7399:	
	movlw	low(((STR_33)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l468
	line	492
	
l7401:	
		movlw	3
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u10701
	goto	u10700
u10701:
	goto	l7405
u10700:
	line	493
	
l7403:	
	movlw	low(((STR_34)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_34)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l468
	line	494
	
l7405:	
		movlw	6
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u10711
	goto	u10710
u10711:
	goto	l468
u10710:
	line	495
	
l7407:	
	movlw	low(((STR_35)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_35)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	496
	
l468:	
	return
	opt stack 0
GLOBAL	__end_of_Print_DetectLog
	__end_of_Print_DetectLog:
	signat	_Print_DetectLog,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2    2[BANK1 ] PTR const unsigned char 
;;		 -> STR_43(3), STR_42(4), STR_41(5), STR_40(6), 
;;		 -> STR_39(6), STR_38(11), STR_37(10), STR_36(21), 
;;		 -> STR_35(34), STR_34(37), STR_33(33), STR_32(3), 
;;		 -> STR_31(3), STR_30(2), STR_29(6), STR_28(5), 
;;		 -> STR_27(5), STR_26(6), STR_25(6), STR_24(6), 
;;		 -> STR_23(6), STR_22(16), STR_21(13), STR_20(15), 
;;		 -> STR_19(7), STR_18(5), STR_17(5), STR_16(6), 
;;		 -> STR_15(6), STR_14(6), STR_13(7), STR_12(4), 
;;		 -> STR_11(6), STR_10(6), STR_9(3), STR_8(12), 
;;		 -> STR_7(2), STR_6(6), STR_5(5), STR_4(29), 
;;		 -> STR_3(4), STR_2(2), STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	file	"uart_dbg.c"
	line	61
global __ptext7
__ptext7:	;psect for function _uart_send_string
psect	text7
	file	"uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l6833:	
	goto	l6839
	line	65
	
l6835:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	btemp+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str)^080h,w
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	fcall	stringtab
	fcall	_uart_send_char
	
l6837:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(uart_send_string@str)^080h,f
	skipnz
	incf	(uart_send_string@str+1)^080h,f
	line	66
# 66 "uart_dbg.c"
clrwdt ;# 
psect	text7
	line	63
	
l6839:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(uart_send_string@str+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	btemp+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str)^080h,w
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u9901
	goto	u9900
u9901:
	goto	l6835
u9900:
	line	68
	
l524:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2    7[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    9[BANK1 ] unsigned char [6]
;;  j               1   16[BANK1 ] unsigned char 
;;  i               1   15[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      10       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext8
__ptext8:	;psect for function _uart_send_number
psect	text8
	file	"uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l6841:	
	clrf	(uart_send_number@i)^080h
	line	84
	
l6843:	
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u9911
	goto	u9910
u9911:
	goto	l6855
u9910:
	line	86
	
l6845:	
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l528
	line	93
	
l6849:	
	movf	(uart_send_number@i)^080h,w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)^080h
	clrf	(___lwmod@divisor+1)^080h
	movf	(uart_send_number@num+1)^080h,w
	movwf	(___lwmod@dividend+1)^080h
	movf	(uart_send_number@num)^080h,w
	movwf	(___lwmod@dividend)^080h
	fcall	___lwmod
	movf	(0+(?___lwmod))^080h,w
	addlw	030h
	bcf	status, 7	;select IRP bank1
	movwf	indf
	
l6851:	
	incf	(uart_send_number@i)^080h,f
	line	94
	
l6853:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(uart_send_number@num+1)^080h,w
	movwf	(___lwdiv@dividend+1)^080h
	movf	(uart_send_number@num)^080h,w
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(uart_send_number@num)^080h
	line	91
	
l6855:	
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u9921
	goto	u9920
u9921:
	goto	l6849
u9920:
	line	98
	
l6857:	
	movf	(uart_send_number@i)^080h,w
	movwf	(uart_send_number@j)^080h
	
l6859:	
	movf	((uart_send_number@j)^080h),w
	btfss	status,2
	goto	u9931
	goto	u9930
u9931:
	goto	l6863
u9930:
	goto	l528
	line	99
	
l6863:	
	movf	(uart_send_number@j)^080h,w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l6865:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decf	(uart_send_number@j)^080h,f
	goto	l6859
	line	100
	
l528:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1    0[BANK1 ] unsigned char 
;;  i               1    1[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       2       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       1       2       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext9
__ptext9:	;psect for function _uart_send_char
psect	text9
	file	"uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_char: [wreg+status,2+status,0]
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_char@c)^080h
	line	38
	
l6679:	
	bcf	(95/8),(95)&7	;volatile
	line	39
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l6681:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u12547:
decfsz	(??_uart_send_char+0)+0,f
	goto	u12547
	nop2
opt asmopt_pop

	line	41
	
l6683:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(uart_send_char@i)^080h
	line	42
	
l514:	
	line	43
	btfss	(uart_send_char@c)^080h,(0)&7
	goto	u9631
	goto	u9630
u9631:
	goto	l516
u9630:
	line	44
	
l6689:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l6691
	line	45
	
l516:	
	line	46
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l6691:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u12557:
decfsz	(??_uart_send_char+0)+0,f
	goto	u12557
	nop2
opt asmopt_pop

	line	48
	
l6693:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrc
	rrf	(uart_send_char@c)^080h,f
	line	41
	
l6695:	
	incf	(uart_send_char@i)^080h,f
	
l6697:	
	movlw	low(08h)
	subwf	(uart_send_char@i)^080h,w
	skipc
	goto	u9641
	goto	u9640
u9641:
	goto	l514
u9640:
	
l515:	
	line	50
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l6699:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u12567:
decfsz	(??_uart_send_char+0)+0,f
	goto	u12567
	nop2
opt asmopt_pop

	line	52
	
l6701:	
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l518:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK1 ] unsigned int 
;;  dividend        2    2[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1   26[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK1 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       4       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       4       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext10
__ptext10:	;psect for function ___lwmod
psect	text10
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l6767:	
	movf	((___lwmod@divisor)^080h),w
iorwf	((___lwmod@divisor+1)^080h),w
	btfsc	status,2
	goto	u9761
	goto	u9760
u9761:
	goto	l6783
u9760:
	line	14
	
l6769:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l6773
	line	16
	
l6771:	
	clrc
	rlf	(___lwmod@divisor)^080h,f
	rlf	(___lwmod@divisor+1)^080h,f
	line	17
	bcf	status, 5	;RP0=0, select bank0
	incf	(___lwmod@counter),f
	line	15
	
l6773:	
	bsf	status, 5	;RP0=1, select bank1
	btfss	(___lwmod@divisor+1)^080h,(15)&7
	goto	u9771
	goto	u9770
u9771:
	goto	l6771
u9770:
	line	20
	
l6775:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lwmod@divisor+1)^080h,w
	subwf	(___lwmod@dividend+1)^080h,w
	skipz
	goto	u9785
	movf	(___lwmod@divisor)^080h,w
	subwf	(___lwmod@dividend)^080h,w
u9785:
	skipc
	goto	u9781
	goto	u9780
u9781:
	goto	l6779
u9780:
	line	21
	
l6777:	
	movf	(___lwmod@divisor)^080h,w
	subwf	(___lwmod@dividend)^080h,f
	movf	(___lwmod@divisor+1)^080h,w
	skipc
	decf	(___lwmod@dividend+1)^080h,f
	subwf	(___lwmod@dividend+1)^080h,f
	line	22
	
l6779:	
	clrc
	rrf	(___lwmod@divisor+1)^080h,f
	rrf	(___lwmod@divisor)^080h,f
	line	23
	
l6781:	
	bcf	status, 5	;RP0=0, select bank0
	decfsz	(___lwmod@counter),f
	goto	u9791
	goto	u9790
u9791:
	goto	l6775
u9790:
	line	25
	
l6783:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lwmod@dividend+1)^080h,w
	movwf	(?___lwmod+1)^080h
	movf	(___lwmod@dividend)^080h,w
	movwf	(?___lwmod)^080h
	line	26
	
l1272:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	_Do_NtcRead

;; *************** function _Do_NtcRead *****************
;; Defined at:
;;		line 326 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Read_Temperature
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	326
global __ptext11
__ptext11:	;psect for function _Do_NtcRead
psect	text11
	file	"main.c"
	line	326
	global	__size_of_Do_NtcRead
	__size_of_Do_NtcRead	equ	__end_of_Do_NtcRead-_Do_NtcRead
	
_Do_NtcRead:	
;incstack = 0
	opt	stack 2
; Regs used in _Do_NtcRead: [wreg+status,2+status,0+pclath+cstack]
	line	328
	
l7241:	
	fcall	_Read_Temperature
	line	329
	
l421:	
	return
	opt stack 0
GLOBAL	__end_of_Do_NtcRead
	__end_of_Do_NtcRead:
	signat	_Do_NtcRead,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 41 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   29[BANK1 ] unsigned long 
;;  temp_x10        2   35[BANK1 ] unsigned int 
;;  ntcVal          2   33[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   66[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Do_NtcRead
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	41
global __ptext12
__ptext12:	;psect for function _Read_Temperature
psect	text12
	file	"charge_mgr.c"
	line	41
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 2
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	46
	
l6795:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ADC_Sample@adldo)^080h
	movlw	low(012h)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	47
	
l6797:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u9801
	goto	u9800
u9801:
	goto	l6801
u9800:
	goto	l569
	line	50
	
l6801:	
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal)^080h
	line	51
	movlw	0
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u9811
	goto	u9810
u9811:
	goto	l569
u9810:
	
l6803:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u9821
	goto	u9820
u9821:
	goto	l6805
u9820:
	goto	l569
	line	56
	
l6805:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	010h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0
	movwf	(___lldiv@divisor)^080h

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0)
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0+1)
	clrf	((??_Read_Temperature+0)^080h+0+2)
	clrf	((??_Read_Temperature+0)^080h+0+3)
	movf	0+(??_Read_Temperature+0)^080h+0,w
	subwf	(___lldiv@divisor)^080h,f
	movf	1+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)^080h+0,w
	goto	u9835
	goto	u9836
u9835:
	subwf	(___lldiv@divisor+1)^080h,f
u9836:
	movf	2+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)^080h+0,w
	goto	u9837
	goto	u9838
u9837:
	subwf	(___lldiv@divisor+2)^080h,f
u9838:
	movf	3+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)^080h+0,w
	goto	u9839
	goto	u9830
u9839:
	subwf	(___lldiv@divisor+3)^080h,f
u9830:

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0
	movwf	(___lmul@multiplicand+2)^080h
	movlw	027h
	movwf	(___lmul@multiplicand+1)^080h
	movlw	010h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt)^080h

	line	57
	
l6807:	
		movf	(Read_Temperature@rt+3)^080h,w
	btfss	status,2
	goto	u9840
	movf	(Read_Temperature@rt+2)^080h,w
	btfss	status,2
	goto	u9840
	movlw	39
	subwf	(Read_Temperature@rt+1)^080h,w
	skipz
	goto	u9843
	movlw	16
	subwf	(Read_Temperature@rt)^080h,w
	skipz
	goto	u9843
u9843:
	btfss	status,0
	goto	u9841
	goto	u9840

u9841:
	goto	l6813
u9840:
	line	58
	
l6809:	
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l6811:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0F0h
	movwf	((??_Read_Temperature+0)^080h+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)^080h+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+3)
	movf	(Read_Temperature@rt)^080h,w
	addwf	(??_Read_Temperature+0)^080h+0,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+1)^080h,w
	goto	u9850
	goto	u9851
u9850:
	addwf	(??_Read_Temperature+0)^080h+1,f
u9851:
	movf	(Read_Temperature@rt+2)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+2)^080h,w
	goto	u9852
	goto	u9853
u9852:
	addwf	(??_Read_Temperature+0)^080h+2,f
u9853:
	movf	(Read_Temperature@rt+3)^080h,w
	skipnc
	incf	(Read_Temperature@rt+3)^080h,w
	addwf	(??_Read_Temperature+0)^080h+3,f
	movf	3+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+3)^080h
	movf	2+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+2)^080h
	movf	1+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+1)^080h
	movf	0+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier)^080h

	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(0+(?___lldiv))^080h,w
	subwf	(Read_Temperature@temp_x10)^080h,f
	movf	(1+(?___lldiv))^080h,w
	skipc
	decf	(Read_Temperature@temp_x10+1)^080h,f
	subwf	(Read_Temperature@temp_x10+1)^080h,f
	goto	l6817
	line	60
	
l6813:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0
	movwf	(___lmul@multiplier+3)^080h
	movlw	0
	movwf	(___lmul@multiplier+2)^080h
	movlw	027h
	movwf	(___lmul@multiplier+1)^080h
	movlw	010h
	movwf	(___lmul@multiplier)^080h

	movf	(Read_Temperature@rt)^080h,w
	subwf	(___lmul@multiplier)^080h,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+1)^080h,w
	subwf	(___lmul@multiplier+1)^080h,f
	movf	(Read_Temperature@rt+2)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+2)^080h,w
	subwf	(___lmul@multiplier+2)^080h,f
	movf	(Read_Temperature@rt+3)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+3)^080h,w
	subwf	(___lmul@multiplier+3)^080h,f
	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10)^080h
	
l6815:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10)^080h,f
	skipnc
	incf	(Read_Temperature@temp_x10+1)^080h,f
	line	61
	
l6817:	
	movlw	0
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipnc
	goto	u9861
	goto	u9860
u9861:
	goto	l575
u9860:
	
l6819:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l575:	
	line	62
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipc
	goto	u9871
	goto	u9870
u9871:
	goto	l576
u9870:
	
l6821:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)^080h
	movlw	02h
	movwf	((Read_Temperature@temp_x10)^080h)+1
	
l576:	
	line	65
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature)
	line	66
	
l6823:	
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(Read_Temperature@temp_x10+1)^080h,w
	movwf	(___lwdiv@dividend+1)^080h
	movf	(Read_Temperature@temp_x10)^080h,w
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv))^080h,w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv))^080h,w
	skipc
	goto	u9881
	goto	u9880
u9881:
	goto	l6827
u9880:
	line	67
	
l6825:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_tempProtect)
	incf	(_g_tempProtect),f
	goto	l569
	line	68
	
l6827:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(Read_Temperature@temp_x10+1)^080h,w
	movwf	(___lwdiv@dividend+1)^080h
	movf	(Read_Temperature@temp_x10)^080h,w
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv))^080h,w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv))^080h,w
	skipnc
	goto	u9891
	goto	u9890
u9891:
	goto	l569
u9890:
	line	69
	
l6829:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_tempProtect)
	line	72
	
l569:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	_Do_AdcSample

;; *************** function _Do_AdcSample *****************
;; Defined at:
;;		line 273 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  st              1   21[BANK1 ] unsigned char 
;;  dly             1   20[BANK1 ] unsigned char 
;;  ty              1   19[BANK1 ] unsigned char 
;;  ch              1   18[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       1       4       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	273
global __ptext13
__ptext13:	;psect for function _Do_AdcSample
psect	text13
	file	"main.c"
	line	273
	global	__size_of_Do_AdcSample
	__size_of_Do_AdcSample	equ	__end_of_Do_AdcSample-_Do_AdcSample
	
_Do_AdcSample:	
;incstack = 0
	opt	stack 3
; Regs used in _Do_AdcSample: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	275
	
l7197:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_scanIndex),w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@ch)^080h
	line	276
	
l7199:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Do_AdcSample@ty)^080h
	line	277
	
l7201:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Do_AdcSample@st)^080h
	line	285
	
l7203:	
		decf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10471
	goto	u10470
u10471:
	goto	l7207
u10470:
	
l7205:	
		movlw	8
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u10481
	goto	u10480
u10481:
	goto	l7219
u10480:
	line	287
	
l7207:	
	clrf	(Do_AdcSample@dly)^080h
	line	288
	
l7213:	
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Do_AdcSample+0)+0),f
	u12577:
decfsz	(??_Do_AdcSample+0)+0,f
	goto	u12577
	nop
opt asmopt_pop

	line	287
	
l7215:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(Do_AdcSample@dly)^080h,f
	
l7217:	
	movlw	low(014h)
	subwf	(Do_AdcSample@dly)^080h,w
	skipc
	goto	u10491
	goto	u10490
u10491:
	goto	l7213
u10490:
	goto	l7221
	line	292
	
l7219:	
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Do_AdcSample+0)+0),f
	u12587:
decfsz	(??_Do_AdcSample+0)+0,f
	goto	u12587
	nop
opt asmopt_pop

	line	295
	
l7221:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ADC_Sample@adldo)^080h
	movf	(Do_AdcSample@ch)^080h,w
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	297
	
l7223:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u10501
	goto	u10500
u10501:
	goto	l7237
u10500:
	line	303
	
l7225:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	((Do_AdcSample@ty)^080h),w
	btfss	status,2
	goto	u10511
	goto	u10510
u10511:
	goto	l7235
u10510:
	
l7227:	
		movlw	4
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10521
	goto	u10520
u10521:
	goto	l7231
u10520:
	
l7229:	
		movlw	5
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u10531
	goto	u10530
u10531:
	goto	l7235
u10530:
	
l7231:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_adresult+1),w	;volatile
	movlw	096h
	skipnz
	subwf	(_adresult),w	;volatile
	skipc
	goto	u10541
	goto	u10540
u10541:
	goto	l7235
u10540:
	goto	l7239
	line	309
	
l7235:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_adresult+1),w	;volatile
	movwf	indf
	goto	l7239
	line	314
	
l7237:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	317
	
l7239:	
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_scanPhase)	;volatile
	line	318
	
l418:	
	return
	opt stack 0
GLOBAL	__end_of_Do_AdcSample
	__end_of_Do_AdcSample:
	signat	_Do_AdcSample,89
	global	_ChargeProcess_Slot

;; *************** function _ChargeProcess_Slot *****************
;; Defined at:
;;		line 139 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   18[BANK3 ] unsigned char 
;;  bat_mv_long     4   36[BANK1 ] unsigned long 
;;  vx_mv           4   32[BANK1 ] unsigned long 
;;  bat_mv          2    2[BANK3 ] unsigned int 
;;  bat_mv_long     4   60[BANK1 ] unsigned long 
;;  vx_mv           4   56[BANK1 ] unsigned long 
;;  bat_mv          2    8[BANK3 ] unsigned int 
;;  bat_mv_long     4   52[BANK1 ] unsigned long 
;;  vx_mv           4   48[BANK1 ] unsigned long 
;;  bat_mv          2    6[BANK3 ] unsigned int 
;;  bat_mv_long     4   44[BANK1 ] unsigned long 
;;  vx_mv           4   40[BANK1 ] unsigned long 
;;  bat_mv          2    4[BANK3 ] unsigned int 
;;  v_ref           2    0[BANK3 ] unsigned int 
;;  v_init          2   30[BANK1 ] unsigned int 
;;  v               2   16[BANK3 ] unsigned int 
;;  ct              2   13[BANK3 ] unsigned int 
;;  tick            2    0        unsigned int 
;;  ty              1   15[BANK3 ] unsigned char 
;;  st              1   12[BANK3 ] unsigned char 
;;  old_st          1   66[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 900/900
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      37      19       0
;;      Temps:          0       0       5       0       0
;;      Totals:         0       0      42      19       0
;;Total ram usage:       61 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		_Detect_BatteryType
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___wmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	139
global __ptext14
__ptext14:	;psect for function _ChargeProcess_Slot
psect	text14
	file	"charge_mgr.c"
	line	139
	global	__size_of_ChargeProcess_Slot
	__size_of_ChargeProcess_Slot	equ	__end_of_ChargeProcess_Slot-_ChargeProcess_Slot
	
_ChargeProcess_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _ChargeProcess_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@idx)^0180h
	line	143
	
l7409:	
	line	146
	
l7411:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	
l7413:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	
l7415:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@v)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v+1)^0180h
	
l7417:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ct)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@ct+1)^0180h
	line	147
	
l7419:	
	movf	(ChargeProcess_Slot@st)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@old_st)^080h
	line	149
	goto	l8135
	line	152
	
l7421:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	153
	
l7423:	
	clrf	(ChargeProcess_Slot@st)^0180h
	incf	(ChargeProcess_Slot@st)^0180h,f
	line	154
	
l7425:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10724
u10725:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10724:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10725
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	161
	
l7427:	
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u10731
	goto	u10730
u10731:
	goto	l7431
u10730:
	line	162
	
l7429:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	goto	l8137
	line	164
	
l7431:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l8137
	line	168
	
l7433:	
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	173
	
l7435:	
		decf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u10741
	goto	u10740
u10741:
	goto	l7441
u10740:
	line	175
	
l7437:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	176
	
l7439:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10754
u10755:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10754:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10755
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	192
	
l7441:	
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u10761
	goto	u10760
u10761:
	goto	l7467
u10760:
	
l7443:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	((??_ChargeProcess_Slot+0)^080h+0),w
iorwf	((??_ChargeProcess_Slot+0)^080h+1),w
	btfsc	status,2
	goto	u10771
	goto	u10770
u10771:
	goto	l7467
u10770:
	
l7445:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movlw	0Fh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	096h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	goto	u10781
	goto	u10780
u10781:
	goto	l7467
u10780:
	
l7447:	
		movlw	6
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u10791
	goto	u10790
u10791:
	goto	l7467
u10790:
	
l7449:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	incf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u10801
	goto	u10800
u10801:
	goto	l7467
u10800:
	line	194
	
l7451:	
	movlw	low(06h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	195
	
l7453:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10814
u10815:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10814:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10815
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	202
	
l7455:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	203
	
l7457:	
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	204
	
l7459:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	205
	
l7461:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	206
	
l7463:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	207
	
l7465:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	208
	goto	l8137
	line	211
	
l7467:	
	movlw	0
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0C8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u10821
	goto	u10820
u10821:
	goto	l7473
u10820:
	line	215
	
l7469:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u10831
	goto	u10830
u10831:
	goto	l8137
u10830:
	goto	l7429
	line	226
	
l7473:	
		movlw	200
	xorwf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u10841
	goto	u10840
u10841:
	goto	l7481
u10840:
	line	228
	
l7475:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	229
	
l7477:	
	movlw	0Bh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u10851
	goto	u10850
u10851:
	goto	l8137
u10850:
	line	230
	
l7479:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10864
u10865:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10864:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10865
	
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_capFlag+1)^080h,f
	goto	l8137
	line	233
	
l7481:	
	movlw	0Bh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u10871
	goto	u10870
u10871:
	goto	l7541
u10870:
	
l7483:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u10881
	goto	u10880
u10881:
	goto	l7541
u10880:
	line	242
	
l7485:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10894
u10895:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10894:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10895
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfss	status,2
	goto	u10901
	goto	u10900
u10901:
	goto	l7497
u10900:
	
l7487:	
		movlw	5
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u10911
	goto	u10910
u10911:
	goto	l7497
u10910:
	line	244
	
l7489:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	245
	
l7491:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	246
	
l7493:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7465
	line	258
	
l7497:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@v_init)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_init+1)^080h
	line	260
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipc
	goto	u10921
	goto	u10920
u10921:
	goto	l7527
u10920:
	line	265
	
l7499:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10934
u10935:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10934:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10935
	
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_highVFlag+1)^080h,f
	line	267
	
l7501:	
	movlw	0Bh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u10941
	goto	u10940
u10941:
	goto	l7509
u10940:
	line	270
	
l7503:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10954
u10955:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10954:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10955
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	271
	
l7505:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	272
	
l7507:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10964
u10965:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10964:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10965
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	273
	goto	l7553
	line	274
	
l7509:	
	movlw	03h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0E8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u10971
	goto	u10970
u10971:
	goto	l7521
u10970:
	line	280
	
l7511:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10984
u10985:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10984:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10985
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u10991
	goto	u10990
u10991:
	goto	l7429
u10990:
	
l7513:	
	movlw	01h
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	090h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11001
	goto	u11000
u11001:
	goto	l7429
u11000:
	line	293
	
l7521:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11014
u11015:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11014:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11015
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	294
	
l7523:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	295
	
l7525:	
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	296
	goto	l7577
	line	302
	
l7527:	
	movf	(ChargeProcess_Slot@v)^0180h,w
	addlw	low(032h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(ChargeProcess_Slot@v_init+1)^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11025
	movf	(ChargeProcess_Slot@v_init)^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11025:
	skipnc
	goto	u11021
	goto	u11020
u11021:
	goto	l7531
u11020:
	line	305
	
l7529:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	306
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	307
	goto	l617
	line	311
	
l7531:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	312
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	313
	
l617:	
	line	314
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u11031
	goto	u11030
u11031:
	goto	l7535
u11030:
	goto	l8137
	line	317
	
l7535:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11044
u11045:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11044:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11045
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u11051
	goto	u11050
u11051:
	goto	l7539
u11050:
	goto	l8137
	line	319
	
l7539:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7553
	line	322
	
l7541:	
	movlw	03h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0E8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u11061
	goto	u11060
u11061:
	goto	l7553
u11060:
	
l7543:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11071
	goto	u11070
u11071:
	goto	l7553
u11070:
	line	324
	
l7545:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_ref)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_ref+1)^0180h
	line	325
	
l7547:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v_ref+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v_ref)^0180h,w
	skipnc
	goto	u11081
	goto	u11080
u11081:
	goto	l7553
u11080:
	
l7549:	
	movf	(ChargeProcess_Slot@v)^0180h,w
	addlw	low(032h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_ref+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11095
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_ref)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11095:
	skipnc
	goto	u11091
	goto	u11090
u11091:
	goto	l7553
u11090:
	goto	l7429
	line	335
	
l7553:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11104
u11105:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11104:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11105
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u11111
	goto	u11110
u11111:
	goto	l7561
u11110:
	line	337
	
l7555:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11124
u11125:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11124:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11125
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	338
	
l7557:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	339
	
l7559:	
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	340
	goto	l7563
	line	343
	
l7561:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Detect_BatteryType@voltage+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Detect_BatteryType@voltage)^080h
	fcall	_Detect_BatteryType
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	348
	
l7563:	
	movlw	01h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0F4h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11131
	goto	u11130
u11131:
	goto	l7569
u11130:
	line	350
	
l7565:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	351
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u11141
	goto	u11140
u11141:
	goto	l7577
u11140:
	goto	l8137
	line	355
	
l7569:	
		movlw	5
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11151
	goto	u11150
u11151:
	goto	l7577
u11150:
	
l7571:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11161
	goto	u11160
u11161:
	goto	l7577
u11160:
	
l7573:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11171
	goto	u11170
u11171:
	goto	l7577
u11170:
	line	357
	
l7575:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	361
	
l7577:	
		movlw	5
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11181
	goto	u11180
u11181:
	goto	l7607
u11180:
	line	368
	
l7579:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	369
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11191
	goto	u11190
u11191:
	goto	l7583
u11190:
	goto	l8137
	line	373
	
l7583:	
	bcf	status, 6	;RP1=0, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u11201
	goto	u11200
u11201:
	goto	l7589
u11200:
	
l7585:	
	movf	(_g_impCheckSlot)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	xorwf	(ChargeProcess_Slot@idx)^0180h,w
	skipnz
	goto	u11211
	goto	u11210
u11211:
	goto	l7589
u11210:
	goto	l8137
	line	375
	
l7589:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	379
	
l7591:	
	clrf	(ADC_Sample@adldo)^080h
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u11221
	goto	u11220
u11221:
	goto	l632
u11220:
	line	380
	
l7593:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(0+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	
l632:	
	line	384
	movlw	064h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(032h)
	movwf	(___lwdiv@dividend)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(_g_impData+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(_g_impData)^080h
	
l7595:	
	movlw	0Ch
	
u11235:
	clrc
	rlf	(_g_impData)^080h,f
	rlf	(_g_impData+1)^080h,f
	addlw	-1
	skipz
	goto	u11235
	
l7597:	
	movlw	(0A000h >> 8)
	addwf	(_g_impData+1)^080h,f
	
l7599:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	iorwf	(_g_impData)^080h,f
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	iorwf	(_g_impData+1)^080h,f
	line	385
	
l7601:	
	movlw	low(08h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	386
	
l7603:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	387
	
l7605:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	389
	
l7607:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11241
	goto	u11240
u11241:
	goto	l7611
u11240:
	
l7609:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11251
	goto	u11250
u11251:
	goto	l7651
u11250:
	line	392
	
l7611:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	393
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11261
	goto	u11260
u11261:
	goto	l7615
u11260:
	goto	l8137
	line	395
	
l7615:	
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv)^080h

	
l7617:	
	movlw	0Ch
u11275:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u11275

	
l7619:	
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long)^080h

	
l7621:	
	movf	(ChargeProcess_Slot@vx_mv+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11281
	addwf	(ChargeProcess_Slot@bat_mv_long+1)^080h,f
u11281:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11282
	addwf	(ChargeProcess_Slot@bat_mv_long+2)^080h,f
u11282:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11283
	addwf	(ChargeProcess_Slot@bat_mv_long+3)^080h,f
u11283:

	
l7623:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	goto	u11290
	goto	u11291
u11290:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u11291:
	movf	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	goto	u11292
	goto	u11293
u11292:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u11293:
	movf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv)^0180h
	
l7625:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u11301
	goto	u11300
u11301:
	goto	l7629
u11300:
	
l7627:	
	movlw	low(02h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l7461
	
l7629:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u11311
	goto	u11310
u11311:
	goto	l7633
u11310:
	
l7631:	
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l7461
	
l7633:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipc
	goto	u11321
	goto	u11320
u11321:
	goto	l7639
u11320:
	
l7635:	
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l7637:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	goto	l7461
	
l7639:	
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l7641:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l7637
	line	397
	
l7651:	
	movf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11331
	goto	u11330
u11331:
	goto	l7667
u11330:
	line	400
	
l7653:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11341
	goto	u11340
u11341:
	goto	l7663
u11340:
	line	404
	
l7655:	
	movlw	03h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0E8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u11351
	goto	u11350
u11351:
	goto	l7525
u11350:
	goto	l8137
	line	414
	
l7663:	
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l7465
	line	418
	
l7667:	
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11361
	goto	u11360
u11361:
	goto	l7671
u11360:
	
l7669:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11371
	goto	u11370
u11371:
	goto	l8137
u11370:
	line	420
	
l7671:	
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	421
	
l7673:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	422
	
l7675:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	423
	
l7677:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ty)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogType)	;volatile
	line	424
	
l7679:	
	bsf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	goto	l8137
	line	429
	
l7681:	
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	430
	
l7683:	
	movf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u11381
	goto	u11380
u11381:
	goto	l7687
u11380:
	goto	l8137
	line	437
	
l7687:	
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ADC_Sample@adldo)^080h
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u11391
	goto	u11390
u11391:
	goto	l656
u11390:
	line	438
	
l7689:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(0+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	
l656:	
	line	445
	bsf	status, 5	;RP0=1, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)^080h
	clrf	(___wmul@multiplier+1)^080h
	movlw	0Fh
	andwf	(___wmul@multiplier)^080h,f
	clrf	(___wmul@multiplier+1)^080h
	movlw	026h
	addwf	(___wmul@multiplier)^080h,f
	skipnc
	incf	(___wmul@multiplier+1)^080h,f
	movlw	064h
	movwf	(___wmul@multiplicand)^080h
	clrf	(___wmul@multiplicand+1)^080h
	fcall	___wmul
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(012Ch)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(012Ch)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(1+(?___wmul))^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11405
	movf	(0+(?___wmul))^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11405:
	skipnc
	goto	u11401
	goto	u11400
u11401:
	goto	l7701
u11400:
	line	447
	
l7691:	
	movlw	low(02h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	448
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	449
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	450
	
l7693:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11414
u11415:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11414:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11415
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	451
	
l7695:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	452
	
l7697:	
	movlw	low(02h)
	movwf	(_g_detectLogType)	;volatile
	goto	l7679
	line	463
	
l7701:	
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11421
	goto	u11420
u11421:
	goto	l7711
u11420:
	
l7703:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	096h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u11431
	goto	u11430
u11431:
	goto	l7711
u11430:
	line	465
	
l7705:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	466
	clrf	(ChargeProcess_Slot@st)^0180h
	line	467
	
l7707:	
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	468
	
l7709:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11444
u11445:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11444:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11445
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	469
	goto	l8137
	line	477
	
l7711:	
	bcf	status, 6	;RP1=0, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)^080h
	clrf	(___wmul@multiplier+1)^080h
	movlw	0Fh
	andwf	(___wmul@multiplier)^080h,f
	clrf	(___wmul@multiplier+1)^080h
	movlw	026h
	addwf	(___wmul@multiplier)^080h,f
	skipnc
	incf	(___wmul@multiplier+1)^080h,f
	movlw	064h
	movwf	(___wmul@multiplicand)^080h
	clrf	(___wmul@multiplicand+1)^080h
	fcall	___wmul
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(0C8h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(1+(?___wmul))^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11455
	movf	(0+(?___wmul))^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11455:
	skipnc
	goto	u11451
	goto	u11450
u11451:
	goto	l7715
u11450:
	goto	l7729
	line	485
	
l7715:	
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	08h
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u11461
	goto	u11460
u11461:
	goto	l7719
u11460:
	goto	l7769
	line	487
	
l7719:	
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11471
	goto	u11470
u11471:
	goto	l7723
u11470:
	goto	l7769
	line	497
	
l7723:	
	movlw	low(09h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	498
	
l7725:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	goto	l7709
	line	505
	
l7729:	
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	line	506
	
l7731:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11484
u11485:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11484:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11485
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	507
	
l7733:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	incf	(ChargeProcess_Slot@ty)^0180h,f
	line	508
	
l7735:	
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_398+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_398+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_398+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_398)^080h

	
l7737:	
	movlw	0Ch
u11495:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_398+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_398+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_398+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_398)^080h,f
	addlw	-1
	skipz
	goto	u11495

	
l7739:	
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_399+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_399+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_399+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_399)^080h

	
l7741:	
	movf	(ChargeProcess_Slot@vx_mv_398+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv_398+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv_398+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv_398)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long_399)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11501
	addwf	(ChargeProcess_Slot@bat_mv_long_399+1)^080h,f
u11501:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11502
	addwf	(ChargeProcess_Slot@bat_mv_long_399+2)^080h,f
u11502:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11503
	addwf	(ChargeProcess_Slot@bat_mv_long_399+3)^080h,f
u11503:

	
l7743:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long_399)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long_399+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_399+1)^080h,w
	goto	u11510
	goto	u11511
u11510:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u11511:
	movf	(ChargeProcess_Slot@bat_mv_long_399+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_399+2)^080h,w
	goto	u11512
	goto	u11513
u11512:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u11513:
	movf	(ChargeProcess_Slot@bat_mv_long_399+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_399+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_400+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_400)^0180h
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_400+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_400)^0180h,w
	skipnc
	goto	u11521
	goto	u11520
u11521:
	goto	l7747
u11520:
	goto	l7627
	
l7747:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_400+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_400)^0180h,w
	skipnc
	goto	u11531
	goto	u11530
u11531:
	goto	l7751
u11530:
	goto	l7631
	
l7751:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_400+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_400)^0180h,w
	skipc
	goto	u11541
	goto	u11540
u11541:
	goto	l7639
u11540:
	goto	l7635
	line	521
	
l7769:	
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	522
	
l7771:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11554
u11555:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11554:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11555
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	523
	
l7773:	
	movlw	low(06h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	524
	
l7775:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11561
	goto	u11560
u11561:
	goto	l7813
u11560:
	line	525
	
l7777:	
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_401+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_401+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_401+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_401)^080h

	
l7779:	
	movlw	0Ch
u11575:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_401+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_401+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_401+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_401)^080h,f
	addlw	-1
	skipz
	goto	u11575

	
l7781:	
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_402+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_402+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_402+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_402)^080h

	
l7783:	
	movf	(ChargeProcess_Slot@vx_mv_401+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv_401+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv_401+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv_401)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long_402)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11581
	addwf	(ChargeProcess_Slot@bat_mv_long_402+1)^080h,f
u11581:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11582
	addwf	(ChargeProcess_Slot@bat_mv_long_402+2)^080h,f
u11582:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11583
	addwf	(ChargeProcess_Slot@bat_mv_long_402+3)^080h,f
u11583:

	
l7785:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long_402)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long_402+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_402+1)^080h,w
	goto	u11590
	goto	u11591
u11590:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u11591:
	movf	(ChargeProcess_Slot@bat_mv_long_402+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_402+2)^080h,w
	goto	u11592
	goto	u11593
u11592:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u11593:
	movf	(ChargeProcess_Slot@bat_mv_long_402+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_402+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_403+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_403)^0180h
	
l7787:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_403+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_403)^0180h,w
	skipnc
	goto	u11601
	goto	u11600
u11601:
	goto	l7791
u11600:
	goto	l7627
	
l7791:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_403+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_403)^0180h,w
	skipnc
	goto	u11611
	goto	u11610
u11611:
	goto	l7795
u11610:
	goto	l7631
	
l7795:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_403+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_403)^0180h,w
	skipc
	goto	u11621
	goto	u11620
u11621:
	goto	l7639
u11620:
	goto	l7635
	line	527
	
l7813:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(___lmul@multiplier)^080h
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(___lmul@multiplier)^080h
	clrf	2+(___lmul@multiplier)^080h
	clrf	3+(___lmul@multiplier)^080h
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_404+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_404+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_404+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_404)^080h

	
l7815:	
	movlw	0Ch
u11635:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_404+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_404+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_404+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_404)^080h,f
	addlw	-1
	skipz
	goto	u11635

	
l7817:	
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_405+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_405+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_405+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_405)^080h

	
l7819:	
	movf	(ChargeProcess_Slot@vx_mv_404+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv_404+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv_404+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv_404)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long_405)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11641
	addwf	(ChargeProcess_Slot@bat_mv_long_405+1)^080h,f
u11641:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11642
	addwf	(ChargeProcess_Slot@bat_mv_long_405+2)^080h,f
u11642:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11643
	addwf	(ChargeProcess_Slot@bat_mv_long_405+3)^080h,f
u11643:

	
l7821:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long_405)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long_405+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_405+1)^080h,w
	goto	u11650
	goto	u11651
u11650:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u11651:
	movf	(ChargeProcess_Slot@bat_mv_long_405+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_405+2)^080h,w
	goto	u11652
	goto	u11653
u11652:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u11653:
	movf	(ChargeProcess_Slot@bat_mv_long_405+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_405+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_406+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_406)^0180h
	
l7823:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_406+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_406)^0180h,w
	skipnc
	goto	u11661
	goto	u11660
u11661:
	goto	l7827
u11660:
	goto	l7627
	
l7827:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_406+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_406)^0180h,w
	skipnc
	goto	u11671
	goto	u11670
u11671:
	goto	l7831
u11670:
	goto	l7631
	
l7831:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_406+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_406)^0180h,w
	skipc
	goto	u11681
	goto	u11680
u11681:
	goto	l7837
u11680:
	
l7833:	
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l7835:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	goto	l7461
	
l7837:	
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l7839:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l7835
	line	541
	
l7849:	
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	551
	
l7853:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(064h)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(064h)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	skipz
	goto	u11695
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
u11695:
	skipnc
	goto	u11691
	goto	u11690
u11691:
	goto	l7857
u11690:
	goto	l7769
	line	555
	
l7857:	
	movlw	0
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	064h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11701
	goto	u11700
u11701:
	goto	l8137
u11700:
	line	557
	
l7859:	
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	558
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	559
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	560
	
l7861:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11714
u11715:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11714:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11715
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	561
	
l7863:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	562
	
l7865:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	563
	
l7867:	
	movlw	low(03h)
	movwf	(_g_detectLogType)	;volatile
	goto	l7679
	line	572
	
l7871:	
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	573
	movlw	017h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	071h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11721
	goto	u11720
u11721:
	goto	l7875
u11720:
	line	575
	
l7873:	
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	576
	goto	l8137
	line	578
	
l7875:	
	movlw	02h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11731
	goto	u11730
u11731:
	goto	l7881
u11730:
	line	580
	
l7877:	
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	581
	
l7879:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	582
	goto	l8137
	line	584
	
l7881:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11741
	goto	u11740
u11741:
	goto	l8137
u11740:
	goto	l7873
	line	592
	
l7885:	
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	593
	movlw	075h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	031h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11751
	goto	u11750
u11751:
	goto	l7889
u11750:
	goto	l7873
	line	598
	
l7889:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11761
	goto	u11760
u11761:
	goto	l7895
u11760:
	line	600
	
l7891:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	601
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u11771
	goto	u11770
u11771:
	goto	l7897
u11770:
	goto	l7873
	line	609
	
l7895:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	611
	
l7897:	
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	08Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11781
	goto	u11780
u11781:
	goto	l8137
u11780:
	line	613
	
l7899:	
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	614
	
l7901:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	615
	
l7903:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	616
	
l7905:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7429
	line	622
	
l7909:	
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	623
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	060h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11791
	goto	u11790
u11791:
	goto	l7915
u11790:
	line	625
	
l7911:	
	movlw	060h
	subwf	(ChargeProcess_Slot@ct)^0180h,f
	movlw	0EAh
	skipc
	decf	(ChargeProcess_Slot@ct+1)^0180h,f
	subwf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	626
	
l7913:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	628
	
l7915:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(012h)
	subwf	indf,w
	skipc
	goto	u11801
	goto	u11800
u11801:
	goto	l7919
u11800:
	goto	l7873
	line	636
	
l7919:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11811
	goto	u11810
u11811:
	goto	l7927
u11810:
	
l7921:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(08h)
	subwf	indf,w
	skipc
	goto	u11821
	goto	u11820
u11821:
	goto	l7927
u11820:
	line	638
	
l7923:	
	movlw	low(05h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l7879
	line	650
	
l7927:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11831
	goto	u11830
u11831:
	goto	l708
u11830:
	
l7929:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11845
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11845:
	skipnc
	goto	u11841
	goto	u11840
u11841:
	goto	l708
u11840:
	
l7931:	
		movlw	6
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11851
	goto	u11850
u11851:
	goto	l7935
u11850:
	
l7933:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0ACh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11861
	goto	u11860
u11861:
	goto	l708
u11860:
	line	651
	
l7935:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	
l708:	
	line	659
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	skipz
	goto	u11875
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v)^0180h,w
u11875:
	skipnc
	goto	u11871
	goto	u11870
u11871:
	goto	l7951
u11870:
	
l7937:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u11881
	goto	u11880
u11881:
	goto	l7951
u11880:
	line	661
	
l7939:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	662
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11891
	goto	u11890
u11891:
	goto	l7943
u11890:
	goto	l8137
	line	664
	
l7943:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	665
	
l7945:	
	clrf	(ChargeProcess_Slot@st)^0180h
	incf	(ChargeProcess_Slot@st)^0180h,f
	goto	l7879
	line	671
	
l7951:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	675
	
l7953:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11901
	goto	u11900
u11901:
	goto	l7961
u11900:
	
l7955:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11911
	goto	u11910
u11911:
	goto	l7961
u11910:
	line	677
	
l7957:	
	movlw	low(06h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l7879
	line	685
	
l7961:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11921
	goto	u11920
u11921:
	goto	l7969
u11920:
	line	688
	
l7963:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movlw	0Ch
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	01Ch
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u11931
	goto	u11930
u11931:
	goto	l8137
u11930:
	goto	l7923
	line	697
	
l7969:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11941
	goto	u11940
u11941:
	goto	l7975
u11940:
	line	699
	
l7971:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	700
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u11951
	goto	u11950
u11951:
	goto	l597
u11950:
	goto	l7873
	line	708
	
l7975:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	710
	
l7977:	
	movlw	0Ch
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	01Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11961
	goto	u11960
u11961:
	goto	l597
u11960:
	goto	l7923
	line	719
	
l7983:	
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	720
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	061h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11971
	goto	u11970
u11971:
	goto	l722
u11970:
	line	721
	
l7985:	
	movlw	low(06h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l722:	
	line	727
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11981
	goto	u11980
u11981:
	goto	l7995
u11980:
	
l7987:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11995
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11995:
	skipnc
	goto	u11991
	goto	u11990
u11991:
	goto	l7995
u11990:
	
l7989:	
		movlw	6
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12001
	goto	u12000
u12001:
	goto	l7993
u12000:
	
l7991:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0ACh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u12011
	goto	u12010
u12011:
	goto	l7995
u12010:
	line	728
	
l7993:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	734
	
l7995:	
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12021
	goto	u12020
u12021:
	goto	l8023
u12020:
	
l7997:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12031
	goto	u12030
u12031:
	goto	l8023
u12030:
	line	736
	
l7999:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12041
	goto	u12040
u12041:
	goto	l8011
u12040:
	line	738
	
l8001:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	739
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12051
	goto	u12050
u12051:
	goto	l8005
u12050:
	goto	l8137
	line	741
	
l8005:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7957
	line	746
	
l8011:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	747
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12061
	goto	u12060
u12061:
	goto	l8015
u12060:
	goto	l8137
	line	749
	
l8015:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	750
	
l8017:	
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	751
	
l8019:	
	clrf	(ChargeProcess_Slot@st)^0180h
	goto	l7879
	line	760
	
l8023:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	skipz
	goto	u12075
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v)^0180h,w
u12075:
	skipnc
	goto	u12071
	goto	u12070
u12071:
	goto	l8037
u12070:
	
l8025:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u12081
	goto	u12080
u12081:
	goto	l8037
u12080:
	line	762
	
l8027:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	763
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipc
	goto	u12091
	goto	u12090
u12091:
	goto	l8039
u12090:
	line	765
	
l8029:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	766
	
l8031:	
	clrf	(ChargeProcess_Slot@ty)^0180h
	goto	l7945
	line	774
	
l8037:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	778
	
l8039:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12101
	goto	u12100
u12101:
	goto	l8045
u12100:
	line	780
	
l8041:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	781
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u12111
	goto	u12110
u12111:
	goto	l597
u12110:
	goto	l7873
	line	789
	
l8045:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8137
	line	797
	
l8047:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12121
	goto	u12120
u12121:
	goto	l8065
u12120:
	line	799
	
l8049:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	800
	
l8051:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12131
	goto	u12130
u12131:
	goto	l8055
u12130:
	
l8053:	
	movlw	02h
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_ChargeProcess_Slot$407)^080h
	clrf	(_ChargeProcess_Slot$407+1)^080h
	goto	l8057
	
l8055:	
	movlw	032h
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_ChargeProcess_Slot$407)^080h
	clrf	(_ChargeProcess_Slot$407+1)^080h
	
l8057:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 6	;RP1=0, select bank1
	movf	(_ChargeProcess_Slot$407+1)^080h,w
	xorlw	80h
	sublw	080h
	skipz
	goto	u12145
	movf	(_ChargeProcess_Slot$407)^080h,w
	subwf	indf,w
u12145:

	skipc
	goto	u12141
	goto	u12140
u12141:
	goto	l8137
u12140:
	line	802
	
l8059:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l8019
	line	811
	
l8065:	
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u12151
	goto	u12150
u12151:
	goto	l7465
u12150:
	line	813
	
l8067:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	814
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12161
	goto	u12160
u12161:
	goto	l8071
u12160:
	goto	l8137
	line	816
	
l8071:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	817
	
l8073:	
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	818
	
l8075:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	goto	l7905
	line	830
	
l8083:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12171
	goto	u12170
u12171:
	goto	l8097
u12170:
	line	832
	
l8085:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	833
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12181
	goto	u12180
u12181:
	goto	l8015
u12180:
	goto	l8137
	line	849
	
l8097:	
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12191
	goto	u12190
u12191:
	goto	l8101
u12190:
	
l8099:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12201
	goto	u12200
u12201:
	goto	l8117
u12200:
	line	851
	
l8101:	
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	08Dh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12211
	goto	u12210
u12211:
	goto	l7465
u12210:
	
l8103:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12224
u12225:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12224:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12225
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u12231
	goto	u12230
u12231:
	goto	l7465
u12230:
	line	853
	
l8105:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	854
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12241
	goto	u12240
u12241:
	goto	l7943
u12240:
	goto	l8137
	line	867
	
l8117:	
	movlw	02h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12251
	goto	u12250
u12251:
	goto	l7465
u12250:
	line	869
	
l8119:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	870
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12261
	goto	u12260
u12261:
	goto	l7943
u12260:
	goto	l8137
	line	883
	
l8131:	
	clrf	(ChargeProcess_Slot@st)^0180h
	line	884
	goto	l8137
	line	149
	
l8135:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@st)^0180h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l7421
	xorlw	1^0	; case 1
	skipnz
	goto	l7433
	xorlw	2^1	; case 2
	skipnz
	goto	l7871
	xorlw	3^2	; case 3
	skipnz
	goto	l7885
	xorlw	4^3	; case 4
	skipnz
	goto	l7909
	xorlw	5^4	; case 5
	skipnz
	goto	l7983
	xorlw	6^5	; case 6
	skipnz
	goto	l8047
	xorlw	7^6	; case 7
	skipnz
	goto	l8083
	xorlw	8^7	; case 8
	skipnz
	goto	l7681
	xorlw	9^8	; case 9
	skipnz
	goto	l7849
	goto	l8131
	opt asmopt_pop

	line	885
	
l597:	
	line	887
	
l8137:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@st)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ty)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ct)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@ct+1)^0180h,w
	movwf	indf
	line	890
	
l8139:	
	movlw	low(06h)
	subwf	(ChargeProcess_Slot@idx)^0180h,w
	skipnc
	goto	u12271
	goto	u12270
u12271:
	goto	l762
u12270:
	
l8141:	
	movf	(ChargeProcess_Slot@st)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	xorwf	(ChargeProcess_Slot@old_st)^080h,w
	skipnz
	goto	u12281
	goto	u12280
u12281:
	goto	l762
u12280:
	line	892
	
l8143:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_dbgSlot)	;volatile
	line	893
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@old_st)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_dbgOldState)	;volatile
	line	894
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@st)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_dbgNewState)	;volatile
	line	895
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ty)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_dbgNewType)	;volatile
	line	896
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_dbgVoltage+1)^080h	;volatile
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_dbgVoltage)^080h	;volatile
	line	897
	
l8145:	
	bsf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	899
	
l762:	
	return
	opt stack 0
GLOBAL	__end_of_ChargeProcess_Slot
	__end_of_ChargeProcess_Slot:
	signat	_ChargeProcess_Slot,4217
	global	___wmul

;; *************** function ___wmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
;; Parameters:    Size  Location     Type
;;  multiplier      2    0[BANK1 ] unsigned int 
;;  multiplicand    2    2[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  product         2    4[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2    0[BANK1 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       4       0       0
;;      Locals:         0       0       2       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       6       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
global __ptext15
__ptext15:	;psect for function ___wmul
psect	text15
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
	global	__size_of___wmul
	__size_of___wmul	equ	__end_of___wmul-___wmul
	
___wmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___wmul: [wreg+status,2+status,0]
	line	43
	
l6901:	
	clrf	(___wmul@product)^080h
	clrf	(___wmul@product+1)^080h
	line	45
	
l6903:	
	btfss	(___wmul@multiplier)^080h,(0)&7
	goto	u10001
	goto	u10000
u10001:
	goto	l6907
u10000:
	line	46
	
l6905:	
	movf	(___wmul@multiplicand)^080h,w
	addwf	(___wmul@product)^080h,f
	skipnc
	incf	(___wmul@product+1)^080h,f
	movf	(___wmul@multiplicand+1)^080h,w
	addwf	(___wmul@product+1)^080h,f
	line	47
	
l6907:	
	clrc
	rlf	(___wmul@multiplicand)^080h,f
	rlf	(___wmul@multiplicand+1)^080h,f
	line	48
	
l6909:	
	clrc
	rrf	(___wmul@multiplier+1)^080h,f
	rrf	(___wmul@multiplier)^080h,f
	line	49
	
l6911:	
	movf	((___wmul@multiplier)^080h),w
iorwf	((___wmul@multiplier+1)^080h),w
	btfss	status,2
	goto	u10011
	goto	u10010
u10011:
	goto	l6903
u10010:
	line	52
	
l6913:	
	movf	(___wmul@product+1)^080h,w
	movwf	(?___wmul+1)^080h
	movf	(___wmul@product)^080h,w
	movwf	(?___wmul)^080h
	line	53
	
l925:	
	return
	opt stack 0
GLOBAL	__end_of___wmul
	__end_of___wmul:
	signat	___wmul,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK1 ] unsigned int 
;;  dividend        2    2[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    5[BANK1 ] unsigned int 
;;  counter         1    4[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK1 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       4       0       0
;;      Locals:         0       0       3       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       7       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext16
__ptext16:	;psect for function ___lwdiv
psect	text16
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l6741:	
	clrf	(___lwdiv@quotient)^080h
	clrf	(___lwdiv@quotient+1)^080h
	line	15
	
l6743:	
	movf	((___lwdiv@divisor)^080h),w
iorwf	((___lwdiv@divisor+1)^080h),w
	btfsc	status,2
	goto	u9721
	goto	u9720
u9721:
	goto	l6763
u9720:
	line	16
	
l6745:	
	clrf	(___lwdiv@counter)^080h
	incf	(___lwdiv@counter)^080h,f
	line	17
	goto	l6749
	line	18
	
l6747:	
	clrc
	rlf	(___lwdiv@divisor)^080h,f
	rlf	(___lwdiv@divisor+1)^080h,f
	line	19
	incf	(___lwdiv@counter)^080h,f
	line	17
	
l6749:	
	btfss	(___lwdiv@divisor+1)^080h,(15)&7
	goto	u9731
	goto	u9730
u9731:
	goto	l6747
u9730:
	line	22
	
l6751:	
	clrc
	rlf	(___lwdiv@quotient)^080h,f
	rlf	(___lwdiv@quotient+1)^080h,f
	line	23
	
l6753:	
	movf	(___lwdiv@divisor+1)^080h,w
	subwf	(___lwdiv@dividend+1)^080h,w
	skipz
	goto	u9745
	movf	(___lwdiv@divisor)^080h,w
	subwf	(___lwdiv@dividend)^080h,w
u9745:
	skipc
	goto	u9741
	goto	u9740
u9741:
	goto	l6759
u9740:
	line	24
	
l6755:	
	movf	(___lwdiv@divisor)^080h,w
	subwf	(___lwdiv@dividend)^080h,f
	movf	(___lwdiv@divisor+1)^080h,w
	skipc
	decf	(___lwdiv@dividend+1)^080h,f
	subwf	(___lwdiv@dividend+1)^080h,f
	line	25
	
l6757:	
	bsf	(___lwdiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l6759:	
	clrc
	rrf	(___lwdiv@divisor+1)^080h,f
	rrf	(___lwdiv@divisor)^080h,f
	line	28
	
l6761:	
	decfsz	(___lwdiv@counter)^080h,f
	goto	u9751
	goto	u9750
u9751:
	goto	l6751
u9750:
	line	30
	
l6763:	
	movf	(___lwdiv@quotient+1)^080h,w
	movwf	(?___lwdiv+1)^080h
	movf	(___lwdiv@quotient)^080h,w
	movwf	(?___lwdiv)^080h
	line	31
	
l1262:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    0[BANK1 ] unsigned long 
;;  multiplicand    4    4[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    8[BANK1 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    0[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext17
__ptext17:	;psect for function ___lmul
psect	text17
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l6703:	
	clrf	(___lmul@product)^080h
	clrf	(___lmul@product+1)^080h
	clrf	(___lmul@product+2)^080h
	clrf	(___lmul@product+3)^080h
	line	120
	
l934:	
	line	121
	btfss	(___lmul@multiplier)^080h,(0)&7
	goto	u9651
	goto	u9650
u9651:
	goto	l6707
u9650:
	line	122
	
l6705:	
	movf	(___lmul@multiplicand)^080h,w
	addwf	(___lmul@product)^080h,f
	movf	(___lmul@multiplicand+1)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9661
	addwf	(___lmul@product+1)^080h,f
u9661:
	movf	(___lmul@multiplicand+2)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9662
	addwf	(___lmul@product+2)^080h,f
u9662:
	movf	(___lmul@multiplicand+3)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9663
	addwf	(___lmul@product+3)^080h,f
u9663:

	line	123
	
l6707:	
	clrc
	rlf	(___lmul@multiplicand)^080h,f
	rlf	(___lmul@multiplicand+1)^080h,f
	rlf	(___lmul@multiplicand+2)^080h,f
	rlf	(___lmul@multiplicand+3)^080h,f
	line	124
	
l6709:	
	clrc
	rrf	(___lmul@multiplier+3)^080h,f
	rrf	(___lmul@multiplier+2)^080h,f
	rrf	(___lmul@multiplier+1)^080h,f
	rrf	(___lmul@multiplier)^080h,f
	line	125
	movf	(___lmul@multiplier+3)^080h,w
	iorwf	(___lmul@multiplier+2)^080h,w
	iorwf	(___lmul@multiplier+1)^080h,w
	iorwf	(___lmul@multiplier)^080h,w
	skipz
	goto	u9671
	goto	u9670
u9671:
	goto	l934
u9670:
	line	128
	
l6711:	
	movf	(___lmul@product+3)^080h,w
	movwf	(?___lmul+3)^080h
	movf	(___lmul@product+2)^080h,w
	movwf	(?___lmul+2)^080h
	movf	(___lmul@product+1)^080h,w
	movwf	(?___lmul+1)^080h
	movf	(___lmul@product)^080h,w
	movwf	(?___lmul)^080h

	line	129
	
l937:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4   12[BANK1 ] unsigned long 
;;  dividend        4   16[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   21[BANK1 ] unsigned long 
;;  counter         1   20[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4   12[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       0       5       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext18
__ptext18:	;psect for function ___lldiv
psect	text18
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l6715:	
	clrf	(___lldiv@quotient)^080h
	clrf	(___lldiv@quotient+1)^080h
	clrf	(___lldiv@quotient+2)^080h
	clrf	(___lldiv@quotient+3)^080h
	line	15
	
l6717:	
	movf	(___lldiv@divisor+3)^080h,w
	iorwf	(___lldiv@divisor+2)^080h,w
	iorwf	(___lldiv@divisor+1)^080h,w
	iorwf	(___lldiv@divisor)^080h,w
	skipnz
	goto	u9681
	goto	u9680
u9681:
	goto	l6737
u9680:
	line	16
	
l6719:	
	clrf	(___lldiv@counter)^080h
	incf	(___lldiv@counter)^080h,f
	line	17
	goto	l6723
	line	18
	
l6721:	
	clrc
	rlf	(___lldiv@divisor)^080h,f
	rlf	(___lldiv@divisor+1)^080h,f
	rlf	(___lldiv@divisor+2)^080h,f
	rlf	(___lldiv@divisor+3)^080h,f
	line	19
	incf	(___lldiv@counter)^080h,f
	line	17
	
l6723:	
	btfss	(___lldiv@divisor+3)^080h,(31)&7
	goto	u9691
	goto	u9690
u9691:
	goto	l6721
u9690:
	line	22
	
l6725:	
	clrc
	rlf	(___lldiv@quotient)^080h,f
	rlf	(___lldiv@quotient+1)^080h,f
	rlf	(___lldiv@quotient+2)^080h,f
	rlf	(___lldiv@quotient+3)^080h,f
	line	23
	
l6727:	
	movf	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,w
	skipz
	goto	u9705
	movf	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,w
	skipz
	goto	u9705
	movf	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,w
	skipz
	goto	u9705
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,w
u9705:
	skipc
	goto	u9701
	goto	u9700
u9701:
	goto	l6733
u9700:
	line	24
	
l6729:	
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,f
	movf	(___lldiv@divisor+1)^080h,w
	skipc
	incfsz	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,f
	movf	(___lldiv@divisor+2)^080h,w
	skipc
	incfsz	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,f
	movf	(___lldiv@divisor+3)^080h,w
	skipc
	incfsz	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,f
	line	25
	
l6731:	
	bsf	(___lldiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l6733:	
	clrc
	rrf	(___lldiv@divisor+3)^080h,f
	rrf	(___lldiv@divisor+2)^080h,f
	rrf	(___lldiv@divisor+1)^080h,f
	rrf	(___lldiv@divisor)^080h,f
	line	28
	
l6735:	
	decfsz	(___lldiv@counter)^080h,f
	goto	u9711
	goto	u9710
u9711:
	goto	l6725
u9710:
	line	30
	
l6737:	
	movf	(___lldiv@quotient+3)^080h,w
	movwf	(?___lldiv+3)^080h
	movf	(___lldiv@quotient+2)^080h,w
	movwf	(?___lldiv+2)^080h
	movf	(___lldiv@quotient+1)^080h,w
	movwf	(?___lldiv+1)^080h
	movf	(___lldiv@quotient)^080h,w
	movwf	(?___lldiv)^080h

	line	31
	
l1209:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[BANK1 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    2[BANK1 ] unsigned char 
;;  product         1    1[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       1       0       0
;;      Locals:         0       0       2       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext19
__ptext19:	;psect for function ___bmul
psect	text19
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___bmul: [wreg+status,2+status,0]
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplier)^080h
	line	6
	
l6917:	
	clrf	(___bmul@product)^080h
	line	43
	
l6919:	
	btfss	(___bmul@multiplier)^080h,(0)&7
	goto	u10021
	goto	u10020
u10021:
	goto	l6923
u10020:
	line	44
	
l6921:	
	movf	(___bmul@multiplicand)^080h,w
	addwf	(___bmul@product)^080h,f
	line	45
	
l6923:	
	clrc
	rlf	(___bmul@multiplicand)^080h,f
	line	46
	
l6925:	
	clrc
	rrf	(___bmul@multiplier)^080h,f
	line	47
	movf	((___bmul@multiplier)^080h),w
	btfss	status,2
	goto	u10031
	goto	u10030
u10031:
	goto	l6919
u10030:
	line	50
	
l6927:	
	movf	(___bmul@product)^080h,w
	line	51
	
l943:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 74 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2    0[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	74
global __ptext20
__ptext20:	;psect for function _Detect_BatteryType
psect	text20
	file	"charge_mgr.c"
	line	74
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	76
	
l6869:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipc
	goto	u9941
	goto	u9940
u9941:
	goto	l6875
u9940:
	line	77
	
l6871:	
	movlw	low(0)
	goto	l583
	line	78
	
l6875:	
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipnc
	goto	u9951
	goto	u9950
u9951:
	goto	l6881
u9950:
	goto	l6871
	line	89
	
l6881:	
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipc
	goto	u9961
	goto	u9960
u9961:
	goto	l6889
u9960:
	
l6883:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipnc
	goto	u9971
	goto	u9970
u9971:
	goto	l6889
u9970:
	line	90
	
l6885:	
	movlw	low(05h)
	goto	l583
	line	95
	
l6889:	
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipc
	goto	u9981
	goto	u9980
u9981:
	goto	l6871
u9980:
	
l6891:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipnc
	goto	u9991
	goto	u9990
u9991:
	goto	l6871
u9990:
	line	96
	
l6893:	
	movlw	low(01h)
	line	99
	
l583:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    0[BANK1 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    6[BANK1 ] unsigned char 
;;  j               1    5[BANK1 ] unsigned char 
;;  adsum           4    8[BANK1 ] volatile unsigned long 
;;  ad_temp         2   16[BANK1 ] volatile unsigned int 
;;  admax           2   14[BANK1 ] volatile unsigned int 
;;  admin           2   12[BANK1 ] volatile unsigned int 
;;  i               1    7[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       1       0       0
;;      Locals:         0       0      13       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       0      18       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	49
global __ptext21
__ptext21:	;psect for function _ADC_Sample
psect	text21
	file	"adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
	movwf	(ADC_Sample@adch)^080h
	line	51
	
l4969:	
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	52
	
l4971:	
	clrf	(ADC_Sample@admin)^080h	;volatile
	clrf	(ADC_Sample@admin+1)^080h	;volatile
	line	53
	clrf	(ADC_Sample@admax)^080h	;volatile
	clrf	(ADC_Sample@admax+1)^080h	;volatile
	line	54
	clrf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	line	58
	
l4973:	
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u6581
	goto	u6580
u6581:
	goto	l4979
u6580:
	
l4975:	
	btfss	(ADC_Sample@adldo)^080h,(2)&7
	goto	u6591
	goto	u6590
u6591:
	goto	l4979
u6590:
	line	60
	
l4977:	
	movf	(ADC_Sample@adldo)^080h,w
	movwf	(150)^080h	;volatile
	line	61
	opt asmopt_push
opt asmopt_off
	movlw	132
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_ADC_Sample+0)^080h+0),f
	u12597:
decfsz	(??_ADC_Sample+0)^080h+0,f
	goto	u12597
	nop
opt asmopt_pop

	line	62
	goto	l4981
	line	64
	
l4979:	
	movf	(ADC_Sample@adldo)^080h,w
	movwf	(150)^080h	;volatile
	line	67
	
l4981:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	btfss	(ADC_Sample@adch)^080h,(4)&7
	goto	u6601
	goto	u6600
u6601:
	goto	l493
u6600:
	line	69
	
l4983:	
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l4985:	
	movlw	low(0Fh)
	andwf	(ADC_Sample@adch)^080h,f
	line	71
	goto	l4987
	line	72
	
l493:	
	line	73
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l4987:	
	clrf	(ADC_Sample@i)^080h
	line	79
	
l4993:	
	movf	(ADC_Sample@adch)^080h,w
	movwf	(??_ADC_Sample+0)^080h+0
	movlw	(02h)-1
u6615:
	clrc
	rlf	(??_ADC_Sample+0)^080h+0,f
	addlw	-1
	skipz
	goto	u6615
	clrc
	rlf	(??_ADC_Sample+0)^080h+0,w
	iorlw	081h
	movwf	(149)^080h	;volatile
	line	80
	
l4995:	
	opt asmopt_push
opt asmopt_off
	movlw	5
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_ADC_Sample+0)^080h+0),f
	u12607:
decfsz	(??_ADC_Sample+0)^080h+0,f
	goto	u12607
	nop2
opt asmopt_pop

	line	81
	
l4997:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l4999:	
	clrf	(ADC_Sample@j)^080h
	line	85
	goto	l497
	
l498:	
	line	87
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decfsz	(ADC_Sample@j)^080h,f
	goto	u6621
	goto	u6620
u6621:
	goto	l497
u6620:
	line	89
	
l5001:	
	movlw	low(0)
	goto	l500
	line	90
	
l497:	
	line	85
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u6631
	goto	u6630
u6631:
	goto	l498
u6630:
	line	93
	
l5005:	
	movf	(153)^080h,w	;volatile
	movwf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	swapf	(ADC_Sample@ad_temp)^080h,f	;volatile
	swapf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	
l5007:	
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	addwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	line	96
	
l5009:	
	movf	((ADC_Sample@admax)^080h),w	;volatile
iorwf	((ADC_Sample@admax+1)^080h),w	;volatile
	btfss	status,2
	goto	u6641
	goto	u6640
u6641:
	goto	l5013
u6640:
	line	98
	
l5011:	
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	line	99
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	100
	goto	l503
	line	102
	
l5013:	
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	subwf	(ADC_Sample@admax+1)^080h,w	;volatile
	skipz
	goto	u6655
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	subwf	(ADC_Sample@admax)^080h,w	;volatile
u6655:
	skipnc
	goto	u6651
	goto	u6650
u6651:
	goto	l5017
u6650:
	line	103
	
l5015:	
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	goto	l503
	line	105
	
l5017:	
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	skipz
	goto	u6665
	movf	(ADC_Sample@admin)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp)^080h,w	;volatile
u6665:
	skipnc
	goto	u6661
	goto	u6660
u6661:
	goto	l503
u6660:
	line	106
	
l5019:	
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	108
	
l503:	
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	0+(??_ADC_Sample+0)^080h+0,w
	addwf	(ADC_Sample@adsum)^080h,f	;volatile
	movf	1+(??_ADC_Sample+0)^080h+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u6671
	addwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u6671:
	movf	2+(??_ADC_Sample+0)^080h+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u6672
	addwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u6672:
	movf	3+(??_ADC_Sample+0)^080h+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u6673
	addwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u6673:

	line	76
	
l5021:	
	incf	(ADC_Sample@i)^080h,f
	
l5023:	
	movlw	low(022h)
	subwf	(ADC_Sample@i)^080h,w
	skipc
	goto	u6681
	goto	u6680
u6681:
	goto	l4993
u6680:
	line	112
	
l5025:	
	movf	(ADC_Sample@admax)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@admax+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	0+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	movf	1+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)^080h+0,w
	goto	u6695
	goto	u6696
u6695:
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u6696:
	movf	2+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)^080h+0,w
	goto	u6697
	goto	u6698
u6697:
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u6698:
	movf	3+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)^080h+0,w
	goto	u6699
	goto	u6690
u6699:
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u6690:

	line	113
	movf	(ADC_Sample@admin)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	3+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum+3)^080h,w	;volatile
	skipz
	goto	u6705
	movf	2+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum+2)^080h,w	;volatile
	skipz
	goto	u6705
	movf	1+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum+1)^080h,w	;volatile
	skipz
	goto	u6705
	movf	0+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum)^080h,w	;volatile
u6705:
	skipc
	goto	u6701
	goto	u6700
u6701:
	goto	l507
u6700:
	line	114
	
l5027:	
	movf	(ADC_Sample@admin)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	0+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	movf	1+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)^080h+0,w
	goto	u6715
	goto	u6716
u6715:
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u6716:
	movf	2+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)^080h+0,w
	goto	u6717
	goto	u6718
u6717:
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u6718:
	movf	3+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)^080h+0,w
	goto	u6719
	goto	u6710
u6719:
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u6710:

	goto	l5029
	line	115
	
l507:	
	line	116
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	118
	
l5029:	
	movf	(ADC_Sample@adsum)^080h,w	;volatile
	movwf	(??_ADC_Sample+0)^080h+0
	movf	(ADC_Sample@adsum+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	movf	(ADC_Sample@adsum+2)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+2)
	movf	(ADC_Sample@adsum+3)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+3)
	movlw	05h
u6725:
	clrc
	rrf	(??_ADC_Sample+0)^080h+3,f
	rrf	(??_ADC_Sample+0)^080h+2,f
	rrf	(??_ADC_Sample+0)^080h+1,f
	rrf	(??_ADC_Sample+0)^080h+0,f
u6720:
	addlw	-1
	skipz
	goto	u6725
	movf	1+(??_ADC_Sample+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_adresult+1)	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(??_ADC_Sample+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_adresult)	;volatile
	line	119
	
l5031:	
	movlw	low(0A5h)
	line	120
	
l500:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 156 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   22[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0       8       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_CCCV_Control
;;		_Charging_Control
;;		_Led_BlinkProcess
;;		_PowerOnLedSequence
;;		_Update_LED_Slot
;;		i1_ADC_Sample
;;		i1___lldiv
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	156
global __ptext22
__ptext22:	;psect for function _Isr_Timer
psect	text22
	file	"main.c"
	line	156
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 2
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	movf	btemp+1,w
	movwf	(??_Isr_Timer+3)
	ljmp	_Isr_Timer
psect	text22
	line	159
	
i1l8173:	
	btfss	(90/8),(90)&7	;volatile
	goto	u1233_21
	goto	u1233_20
u1233_21:
	goto	i1l371
u1233_20:
	line	161
	
i1l8175:	
	bcf	(90/8),(90)&7	;volatile
	line	162
	
i1l8177:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	163
# 163 "main.c"
clrwdt ;# 
psect	text22
	line	166
	
i1l8179:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	167
	
i1l8181:	
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u1234_21
	goto	u1234_20
u1234_21:
	goto	i1l8185
u1234_20:
	line	168
	
i1l8183:	
	clrf	(_g_pwmCounter)	;volatile
	line	171
	
i1l8185:	
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u1235_21
	goto	u1235_20
u1235_21:
	goto	i1l368
u1235_20:
	
i1l8187:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u1236_21
	goto	u1236_20
u1236_21:
	goto	i1l368
u1236_20:
	line	172
	
i1l8189:	
	bsf	(55/8),(55)&7	;volatile
	goto	i1l8191
	line	173
	
i1l368:	
	line	174
	bcf	(55/8),(55)&7	;volatile
	line	177
	
i1l8191:	
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u1237_21
	goto	u1237_20
u1237_21:
	goto	i1l8263
u1237_20:
	line	179
	
i1l8193:	
	fcall	_PowerOnLedSequence
	goto	i1l371
	line	186
	
i1l373:	
	line	188
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u1238_21
	goto	u1238_20
u1238_21:
	goto	i1l371
u1238_20:
	
i1l8197:	
	btfsc	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u1239_21
	goto	u1239_20
u1239_21:
	goto	i1l371
u1239_20:
	goto	i1l8201
	line	190
	
i1l377:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l390
	
i1l379:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l390
	
i1l380:	
	bsf	(51/8),(51)&7	;volatile
	goto	i1l390
	
i1l381:	
	bsf	(50/8),(50)&7	;volatile
	goto	i1l390
	
i1l382:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l390
	
i1l383:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l390
	
i1l384:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l390
	
i1l385:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l390
	
i1l386:	
	bsf	(48/8),(48)&7	;volatile
	goto	i1l390
	
i1l387:	
	bsf	(49/8),(49)&7	;volatile
	goto	i1l390
	
i1l388:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l390
	
i1l389:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l390
	
i1l8201:	
	movf	(_g_scanIndex),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l377
	xorlw	1^0	; case 1
	skipnz
	goto	i1l379
	xorlw	2^1	; case 2
	skipnz
	goto	i1l380
	xorlw	3^2	; case 3
	skipnz
	goto	i1l381
	xorlw	4^3	; case 4
	skipnz
	goto	i1l382
	xorlw	5^4	; case 5
	skipnz
	goto	i1l383
	xorlw	6^5	; case 6
	skipnz
	goto	i1l384
	xorlw	7^6	; case 7
	skipnz
	goto	i1l385
	xorlw	8^7	; case 8
	skipnz
	goto	i1l386
	xorlw	9^8	; case 9
	skipnz
	goto	i1l387
	xorlw	10^9	; case 10
	skipnz
	goto	i1l388
	xorlw	11^10	; case 11
	skipnz
	goto	i1l389
	goto	i1l390
	opt asmopt_pop

	
i1l390:	
	line	191
	bsf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	i1l371
	line	197
	
i1l8203:	
	movf	(_g_scanIndex),w	;volatile
	fcall	_Update_LED_Slot
	line	199
	
i1l8205:	
	movlw	low(02h)
	movwf	(_g_scanPhase)	;volatile
	line	200
	goto	i1l371
	line	203
	
i1l8207:	
	movf	((_g_scanIndex)),w	;volatile
	btfss	status,2
	goto	u1240_21
	goto	u1240_20
u1240_21:
	goto	i1l8255
u1240_20:
	line	206
	
i1l8209:	
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u1241_21
	goto	u1241_20
u1241_21:
	goto	i1l8223
u1241_20:
	line	208
	
i1l8211:	
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	209
	
i1l8213:	
	clrf	(i1ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	i1_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	210
	
i1l8215:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u1242_21
	goto	u1242_20
u1242_21:
	goto	i1l8221
u1242_20:
	line	212
	
i1l8217:	
	movf	(_adresult),w	;volatile
	movwf	(i1___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((i1___lldiv@divisor))+1
	clrf	2+((i1___lldiv@divisor))
	clrf	3+((i1___lldiv@divisor))
	movlw	0
	movwf	(i1___lldiv@dividend+3)
	movlw	04Bh
	movwf	(i1___lldiv@dividend+2)
	movlw	0
	movwf	(i1___lldiv@dividend+1)
	movlw	0
	movwf	(i1___lldiv@dividend)

	fcall	i1___lldiv
	movf	(3+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+3)
	movf	(2+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+2)
	movf	(1+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+1)
	movf	(0+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt)

	line	213
	
i1l8219:	
	movf	(Isr_Timer@pt+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv+1)^080h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(Isr_Timer@pt),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv)^080h	;volatile
	line	215
	
i1l8221:	
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	218
	
i1l8223:	
	fcall	_Charging_Control
	line	219
	
i1l8225:	
	fcall	_CCCV_Control
	line	220
	
i1l8227:	
	fcall	_Led_BlinkProcess
	line	224
	
i1l8229:	
	movf	((_g_tempPhase)),w	;volatile
	btfss	status,2
	goto	u1243_21
	goto	u1243_20
u1243_21:
	goto	i1l8241
u1243_20:
	line	226
	
i1l8231:	
	incf	(_g_tempReadRoundCnt),f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1),f	;volatile
	line	227
	
i1l8233:	
	movlw	0
	subwf	(_g_tempReadRoundCnt+1),w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt),w	;volatile
	skipc
	goto	u1244_21
	goto	u1244_20
u1244_21:
	goto	i1l8249
u1244_20:
	line	229
	
i1l8235:	
	clrf	(_g_tempReadRoundCnt)	;volatile
	clrf	(_g_tempReadRoundCnt+1)	;volatile
	line	230
	
i1l8237:	
	movlw	low(01h)
	movwf	(_g_tempPhase)	;volatile
	line	231
	
i1l8239:	
	clrf	(_g_tempSettleCnt)	;volatile
	clrf	(_g_tempSettleCnt+1)	;volatile
	goto	i1l8249
	line	236
	
i1l8241:	
	incf	(_g_tempSettleCnt),f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1),f	;volatile
	line	237
	
i1l8243:	
	movlw	0
	subwf	(_g_tempSettleCnt+1),w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt),w	;volatile
	skipc
	goto	u1245_21
	goto	u1245_20
u1245_21:
	goto	i1l8249
u1245_20:
	line	239
	
i1l8245:	
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	240
	
i1l8247:	
	clrf	(_g_tempSettleCnt)	;volatile
	clrf	(_g_tempSettleCnt+1)	;volatile
	line	241
	clrf	(_g_tempPhase)	;volatile
	line	247
	
i1l8249:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_printTick)^080h,f	;volatile
	skipnz
	incf	(_g_printTick+1)^080h,f	;volatile
	movlw	0
	subwf	((_g_printTick+1)^080h),w	;volatile
	movlw	064h
	skipnz
	subwf	((_g_printTick)^080h),w	;volatile
	skipc
	goto	u1246_21
	goto	u1246_20
u1246_21:
	goto	i1l8255
u1246_20:
	line	249
	
i1l8251:	
	clrf	(_g_printTick)^080h	;volatile
	clrf	(_g_printTick+1)^080h	;volatile
	line	250
	
i1l8253:	
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	255
	
i1l8255:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	incf	(_g_scanIndex),f	;volatile
	subwf	((_g_scanIndex)),w	;volatile
	skipc
	goto	u1247_21
	goto	u1247_20
u1247_21:
	goto	i1l402
u1247_20:
	line	256
	
i1l8257:	
	clrf	(_g_scanIndex)	;volatile
	
i1l402:	
	line	257
	clrf	(_g_scanPhase)	;volatile
	line	258
	goto	i1l371
	line	184
	
i1l8263:	
	movf	(_g_scanPhase),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 2
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           17     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l373
	xorlw	1^0	; case 1
	skipnz
	goto	i1l8203
	xorlw	2^1	; case 2
	skipnz
	goto	i1l8207
	goto	i1l402
	opt asmopt_pop

	line	265
	
i1l371:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(??_Isr_Timer+3),w
	movwf	btemp+1
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^00h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	i1___lldiv

;; *************** function i1___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    0[COMMON] unsigned long 
;;  dividend        4    4[COMMON] unsigned long 
;; Auto vars:     Size  Location     Type
;;  __lldiv         4    1[BANK0 ] unsigned long 
;;  __lldiv         1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    0[COMMON] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         8       0       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       5       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext23
__ptext23:	;psect for function i1___lldiv
psect	text23
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_ofi1___lldiv
	__size_ofi1___lldiv	equ	__end_ofi1___lldiv-i1___lldiv
	
i1___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in i1___lldiv: [wreg+status,2+status,0]
	line	14
	
i1l8147:	
	clrf	(i1___lldiv@quotient)
	clrf	(i1___lldiv@quotient+1)
	clrf	(i1___lldiv@quotient+2)
	clrf	(i1___lldiv@quotient+3)
	line	15
	
i1l8149:	
	movf	(i1___lldiv@divisor+3),w
	iorwf	(i1___lldiv@divisor+2),w
	iorwf	(i1___lldiv@divisor+1),w
	iorwf	(i1___lldiv@divisor),w
	skipnz
	goto	u1229_21
	goto	u1229_20
u1229_21:
	goto	i1l8169
u1229_20:
	line	16
	
i1l8151:	
	clrf	(i1___lldiv@counter)
	incf	(i1___lldiv@counter),f
	line	17
	goto	i1l8155
	line	18
	
i1l8153:	
	clrc
	rlf	(i1___lldiv@divisor),f
	rlf	(i1___lldiv@divisor+1),f
	rlf	(i1___lldiv@divisor+2),f
	rlf	(i1___lldiv@divisor+3),f
	line	19
	incf	(i1___lldiv@counter),f
	line	17
	
i1l8155:	
	btfss	(i1___lldiv@divisor+3),(31)&7
	goto	u1230_21
	goto	u1230_20
u1230_21:
	goto	i1l8153
u1230_20:
	line	22
	
i1l8157:	
	clrc
	rlf	(i1___lldiv@quotient),f
	rlf	(i1___lldiv@quotient+1),f
	rlf	(i1___lldiv@quotient+2),f
	rlf	(i1___lldiv@quotient+3),f
	line	23
	
i1l8159:	
	movf	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),w
	skipz
	goto	u1231_25
	movf	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),w
	skipz
	goto	u1231_25
	movf	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),w
	skipz
	goto	u1231_25
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),w
u1231_25:
	skipc
	goto	u1231_21
	goto	u1231_20
u1231_21:
	goto	i1l8165
u1231_20:
	line	24
	
i1l8161:	
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),f
	movf	(i1___lldiv@divisor+1),w
	skipc
	incfsz	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),f
	movf	(i1___lldiv@divisor+2),w
	skipc
	incfsz	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),f
	movf	(i1___lldiv@divisor+3),w
	skipc
	incfsz	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),f
	line	25
	
i1l8163:	
	bsf	(i1___lldiv@quotient)+(0/8),(0)&7
	line	27
	
i1l8165:	
	clrc
	rrf	(i1___lldiv@divisor+3),f
	rrf	(i1___lldiv@divisor+2),f
	rrf	(i1___lldiv@divisor+1),f
	rrf	(i1___lldiv@divisor),f
	line	28
	
i1l8167:	
	decfsz	(i1___lldiv@counter),f
	goto	u1232_21
	goto	u1232_20
u1232_21:
	goto	i1l8157
u1232_20:
	line	30
	
i1l8169:	
	movf	(i1___lldiv@quotient+3),w
	movwf	(?i1___lldiv+3)
	movf	(i1___lldiv@quotient+2),w
	movwf	(?i1___lldiv+2)
	movf	(i1___lldiv@quotient+1),w
	movwf	(?i1___lldiv+1)
	movf	(i1___lldiv@quotient),w
	movwf	(?i1___lldiv)

	line	31
	
i1l1209:	
	return
	opt stack 0
GLOBAL	__end_ofi1___lldiv
	__end_ofi1___lldiv:
	signat	i1___lldiv,92
	global	i1_ADC_Sample

;; *************** function i1_ADC_Sample *****************
;; Defined at:
;;		line 49 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    0[BANK0 ] unsigned char 
;;  ADC_Sample      4    3[BANK0 ] volatile unsigned long 
;;  ADC_Sample      2   11[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    9[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    7[BANK0 ] volatile unsigned int 
;;  ADC_Sample      1    2[BANK0 ] unsigned char 
;;  ADC_Sample      1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      13       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	49
global __ptext24
__ptext24:	;psect for function i1_ADC_Sample
psect	text24
	file	"adc_drv.c"
	line	49
	global	__size_ofi1_ADC_Sample
	__size_ofi1_ADC_Sample	equ	__end_ofi1_ADC_Sample-i1_ADC_Sample
	
i1_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in i1_ADC_Sample: [wreg+status,2+status,0]
	movwf	(i1ADC_Sample@adch)
	line	51
	
i1l4753:	
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	52
	
i1l4755:	
	clrf	(i1ADC_Sample@admin)	;volatile
	clrf	(i1ADC_Sample@admin+1)	;volatile
	line	53
	clrf	(i1ADC_Sample@admax)	;volatile
	clrf	(i1ADC_Sample@admax+1)	;volatile
	line	54
	clrf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	line	58
	
i1l4757:	
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u623_21
	goto	u623_20
u623_21:
	goto	i1l4763
u623_20:
	
i1l4759:	
	btfss	(i1ADC_Sample@adldo),(2)&7
	goto	u624_21
	goto	u624_20
u624_21:
	goto	i1l4763
u624_20:
	line	60
	
i1l4761:	
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	61
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??i1_ADC_Sample+0)+0),f
	u1261_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u1261_27
opt asmopt_pop

	line	62
	goto	i1l4765
	line	64
	
i1l4763:	
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	67
	
i1l4765:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(i1ADC_Sample@adch),(4)&7
	goto	u625_21
	goto	u625_20
u625_21:
	goto	i1l493
u625_20:
	line	69
	
i1l4767:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
i1l4769:	
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(i1ADC_Sample@adch),f
	line	71
	goto	i1l4771
	line	72
	
i1l493:	
	line	73
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
i1l4771:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@i)
	
i1l4773:	
	movlw	low(022h)
	subwf	(i1ADC_Sample@i),w
	skipc
	goto	u626_21
	goto	u626_20
u626_21:
	goto	i1l4777
u626_20:
	goto	i1l4809
	line	79
	
i1l4777:	
	movf	(i1ADC_Sample@adch),w
	movwf	(??i1_ADC_Sample+0)+0
	movlw	(02h)-1
u627_25:
	clrc
	rlf	(??i1_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u627_25
	clrc
	rlf	(??i1_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
i1l4779:	
	opt asmopt_push
opt asmopt_off
	movlw	6
movwf	((??i1_ADC_Sample+0)+0),f
	u1262_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u1262_27
	nop
opt asmopt_pop

	line	81
	
i1l4781:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
i1l4783:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@j)
	line	85
	goto	i1l497
	
i1l498:	
	line	87
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(i1ADC_Sample@j),f
	goto	u628_21
	goto	u628_20
u628_21:
	goto	i1l497
u628_20:
	line	89
	
i1l4785:	
	movlw	low(0)
	goto	i1l500
	line	90
	
i1l497:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u629_21
	goto	u629_20
u629_21:
	goto	i1l498
u629_20:
	line	93
	
i1l4789:	
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	swapf	(i1ADC_Sample@ad_temp),f	;volatile
	swapf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp),f	;volatile
	
i1l4791:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(i1ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(i1ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
i1l4793:	
	movf	((i1ADC_Sample@admax)),w	;volatile
iorwf	((i1ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u630_21
	goto	u630_20
u630_21:
	goto	i1l4797
u630_20:
	line	98
	
i1l4795:	
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	line	99
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	100
	goto	i1l503
	line	102
	
i1l4797:	
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	subwf	(i1ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u631_25
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	subwf	(i1ADC_Sample@admax),w	;volatile
u631_25:
	skipnc
	goto	u631_21
	goto	u631_20
u631_21:
	goto	i1l4801
u631_20:
	line	103
	
i1l4799:	
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	goto	i1l503
	line	105
	
i1l4801:	
	movf	(i1ADC_Sample@admin+1),w	;volatile
	subwf	(i1ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u632_25
	movf	(i1ADC_Sample@admin),w	;volatile
	subwf	(i1ADC_Sample@ad_temp),w	;volatile
u632_25:
	skipnc
	goto	u632_21
	goto	u632_20
u632_21:
	goto	i1l503
u632_20:
	line	106
	
i1l4803:	
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	108
	
i1l503:	
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	addwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u633_21
	addwf	(i1ADC_Sample@adsum+1),f	;volatile
u633_21:
	movf	2+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u633_22
	addwf	(i1ADC_Sample@adsum+2),f	;volatile
u633_22:
	movf	3+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u633_23
	addwf	(i1ADC_Sample@adsum+3),f	;volatile
u633_23:

	line	76
	
i1l4805:	
	incf	(i1ADC_Sample@i),f
	goto	i1l4773
	line	112
	
i1l4809:	
	movf	(i1ADC_Sample@admax),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admax+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u634_25
	goto	u634_26
u634_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u634_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u634_27
	goto	u634_28
u634_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u634_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u634_29
	goto	u634_20
u634_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u634_20:

	line	113
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	3+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u635_25
	movf	2+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u635_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u635_25
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),w	;volatile
u635_25:
	skipc
	goto	u635_21
	goto	u635_20
u635_21:
	goto	i1l507
u635_20:
	line	114
	
i1l4811:	
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u636_25
	goto	u636_26
u636_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u636_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u636_27
	goto	u636_28
u636_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u636_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u636_29
	goto	u636_20
u636_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u636_20:

	goto	i1l4813
	line	115
	
i1l507:	
	line	116
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	118
	
i1l4813:	
	movf	(i1ADC_Sample@adsum),w	;volatile
	movwf	(??i1_ADC_Sample+0)+0
	movf	(i1ADC_Sample@adsum+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	movf	(i1ADC_Sample@adsum+2),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+2)
	movf	(i1ADC_Sample@adsum+3),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+3)
	movlw	05h
u637_25:
	clrc
	rrf	(??i1_ADC_Sample+0)+3,f
	rrf	(??i1_ADC_Sample+0)+2,f
	rrf	(??i1_ADC_Sample+0)+1,f
	rrf	(??i1_ADC_Sample+0)+0,f
u637_20:
	addlw	-1
	skipz
	goto	u637_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
i1l4815:	
	movlw	low(0A5h)
	line	120
	
i1l500:	
	return
	opt stack 0
GLOBAL	__end_ofi1_ADC_Sample
	__end_ofi1_ADC_Sample:
	signat	i1_ADC_Sample,89
	global	_Update_LED_Slot

;; *************** function _Update_LED_Slot *****************
;; Defined at:
;;		line 31 in file "led.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    0[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	file	"led.c"
	line	31
global __ptext25
__ptext25:	;psect for function _Update_LED_Slot
psect	text25
	file	"led.c"
	line	31
	global	__size_of_Update_LED_Slot
	__size_of_Update_LED_Slot	equ	__end_of_Update_LED_Slot-_Update_LED_Slot
	
_Update_LED_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _Update_LED_Slot: [wreg]
	line	36
	
i1l907:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Slot
	__end_of_Update_LED_Slot:
	signat	_Update_LED_Slot,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 63 in file "led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=0
	line	63
global __ptext26
__ptext26:	;psect for function _PowerOnLedSequence
psect	text26
	file	"led.c"
	line	63
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	65
	
i1l3559:	
	incf	(_g_powerOnTimer),f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1),f	;volatile
	line	67
	
i1l3561:	
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u390_21
	goto	u390_20
u390_21:
	goto	i1l3569
u390_20:
	line	70
	
i1l3563:	
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u391_21
	goto	u391_20
u391_21:
	goto	i1l919
u391_20:
	line	72
	
i1l3565:	
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	73
	
i1l3567:	
	movlw	low(01h)
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l919
	line	76
	
i1l3569:	
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u392_21
	goto	u392_20
u392_21:
	goto	i1l919
u392_20:
	line	79
	
i1l3571:	
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u393_21
	goto	u393_20
u393_21:
	goto	i1l919
u393_20:
	line	81
	
i1l3573:	
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	82
	
i1l3575:	
	movlw	low(02h)
	movwf	(_g_powerOnPhase)	;volatile
	line	86
	
i1l919:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
	global	_Led_BlinkProcess

;; *************** function _Led_BlinkProcess *****************
;; Defined at:
;;		line 48 in file "led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=0
	line	48
global __ptext27
__ptext27:	;psect for function _Led_BlinkProcess
psect	text27
	file	"led.c"
	line	48
	global	__size_of_Led_BlinkProcess
	__size_of_Led_BlinkProcess	equ	__end_of_Led_BlinkProcess-_Led_BlinkProcess
	
_Led_BlinkProcess:	
;incstack = 0
	opt	stack 3
; Regs used in _Led_BlinkProcess: [wreg+status,2+status,0]
	line	50
	
i1l3771:	
	incf	(_g_blinkTick),f
	line	51
	
i1l3773:	
	movlw	low(064h)
	subwf	(_g_blinkTick),w
	skipc
	goto	u436_21
	goto	u436_20
u436_21:
	goto	i1l911
u436_20:
	line	52
	
i1l3775:	
	clrf	(_g_blinkTick)
	line	53
	
i1l911:	
	return
	opt stack 0
GLOBAL	__end_of_Led_BlinkProcess
	__end_of_Led_BlinkProcess:
	signat	_Led_BlinkProcess,89
	global	_Charging_Control

;; *************** function _Charging_Control *****************
;; Defined at:
;;		line 913 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    7[COMMON] unsigned char 
;;  i               1    8[COMMON] unsigned char 
;;  chargeB7_12     1    6[COMMON] unsigned char 
;;  chargeB1_6      1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 100/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;;		i1___lwmod
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	913
global __ptext28
__ptext28:	;psect for function _Charging_Control
psect	text28
	file	"charge_mgr.c"
	line	913
	global	__size_of_Charging_Control
	__size_of_Charging_Control	equ	__end_of_Charging_Control-_Charging_Control
	
_Charging_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _Charging_Control: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	916
	
i1l7003:	
	clrf	(Charging_Control@chargeB1_6)
	line	917
	clrf	(Charging_Control@chargeB7_12)
	line	920
	
i1l7005:	
	bcf	status, 5	;RP0=0, select bank0
	movf	((_g_tempProtect)),w
	btfsc	status,2
	goto	u1005_21
	goto	u1005_20
u1005_21:
	goto	i1l7011
u1005_20:
	line	922
	
i1l766:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	bsf	(1073/8)^080h,(1073)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	bsf	(50/8),(50)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	bsf	(1074/8)^080h,(1074)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	bsf	(49/8),(49)&7	;volatile
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	
i1l767:	
	line	923
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	924
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	925
	
i1l7007:	
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	goto	i1l768
	line	932
	
i1l7011:	
	movf	((_g_vccProtect)),w
	btfsc	status,2
	goto	u1006_21
	goto	u1006_20
u1006_21:
	goto	i1l7021
u1006_20:
	line	934
	
i1l7013:	
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u1007_21
	goto	u1007_20
u1007_21:
	goto	i1l7019
u1007_20:
	goto	i1l766
	line	942
	
i1l7019:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	line	943
	goto	i1l7029
	line	946
	
i1l7021:	
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u1008_21
	goto	u1008_20
u1008_21:
	goto	i1l7029
u1008_20:
	line	948
	
i1l7023:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	incf	(_g_vccProtect),f
	goto	i1l766
	line	958
	
i1l7029:	
	clrf	(Charging_Control@i)
	line	960
	
i1l7035:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Charging_Control@s)
	line	965
	
i1l7037:	
		movlw	2
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1009_21
	goto	u1009_20
u1009_21:
	goto	i1l7047
u1009_20:
	
i1l7039:	
		movlw	3
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1010_21
	goto	u1010_20
u1010_21:
	goto	i1l7047
u1010_20:
	
i1l7041:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1011_21
	goto	u1011_20
u1011_21:
	goto	i1l7047
u1011_20:
	
i1l7043:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1012_21
	goto	u1012_20
u1012_21:
	goto	i1l7047
u1012_20:
	
i1l7045:	
		movlw	8
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u1013_21
	goto	u1013_20
u1013_21:
	goto	i1l7075
u1013_20:
	line	972
	
i1l7047:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
		movlw	6
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u1014_21
	goto	u1014_20
u1014_21:
	goto	i1l7069
u1014_20:
	
i1l7049:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1015_21
	goto	u1015_20
u1015_21:
	goto	i1l7053
u1015_20:
	
i1l7051:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u1016_21
	goto	u1016_20
u1016_21:
	goto	i1l7069
u1016_20:
	line	974
	
i1l7053:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_ccCycle),w
	movwf	(i1___lwmod@dividend)
	clrf	(i1___lwmod@dividend+1)
	movf	(Charging_Control@i),w
	addwf	(i1___lwmod@dividend),f
	skipnc
	incf	(i1___lwmod@dividend+1),f
	movlw	0Bh
	movwf	(i1___lwmod@divisor)
	clrf	(i1___lwmod@divisor+1)
	fcall	i1___lwmod
	movf	((0+(?i1___lwmod))),w
iorwf	((1+(?i1___lwmod))),w
	btfss	status,2
	goto	u1017_21
	goto	u1017_20
u1017_21:
	goto	i1l7065
u1017_20:
	goto	i1l7057
	line	976
	
i1l788:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l7059
	
i1l790:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l7059
	
i1l791:	
	bcf	(51/8),(51)&7	;volatile
	goto	i1l7059
	
i1l792:	
	bcf	(50/8),(50)&7	;volatile
	goto	i1l7059
	
i1l793:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l7059
	
i1l794:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l7059
	
i1l795:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l7059
	
i1l796:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l7059
	
i1l797:	
	bcf	(48/8),(48)&7	;volatile
	goto	i1l7059
	
i1l798:	
	bcf	(49/8),(49)&7	;volatile
	goto	i1l7059
	
i1l799:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l7059
	
i1l800:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l7059
	
i1l7057:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l788
	xorlw	1^0	; case 1
	skipnz
	goto	i1l790
	xorlw	2^1	; case 2
	skipnz
	goto	i1l791
	xorlw	3^2	; case 3
	skipnz
	goto	i1l792
	xorlw	4^3	; case 4
	skipnz
	goto	i1l793
	xorlw	5^4	; case 5
	skipnz
	goto	i1l794
	xorlw	6^5	; case 6
	skipnz
	goto	i1l795
	xorlw	7^6	; case 7
	skipnz
	goto	i1l796
	xorlw	8^7	; case 8
	skipnz
	goto	i1l797
	xorlw	9^8	; case 9
	skipnz
	goto	i1l798
	xorlw	10^9	; case 10
	skipnz
	goto	i1l799
	xorlw	11^10	; case 11
	skipnz
	goto	i1l800
	goto	i1l7059
	opt asmopt_pop

	line	977
	
i1l7059:	
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipnc
	goto	u1018_21
	goto	u1018_20
u1018_21:
	goto	i1l802
u1018_20:
	
i1l7061:	
	clrf	(Charging_Control@chargeB1_6)
	incf	(Charging_Control@chargeB1_6),f
	goto	i1l7085
	line	978
	
i1l802:	
	clrf	(Charging_Control@chargeB7_12)
	incf	(Charging_Control@chargeB7_12),f
	goto	i1l7085
	line	982
	
i1l807:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l7085
	
i1l809:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l7085
	
i1l810:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	i1l7085
	
i1l811:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	i1l7085
	
i1l812:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l7085
	
i1l813:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l7085
	
i1l814:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l7085
	
i1l815:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l7085
	
i1l816:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	i1l7085
	
i1l817:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	i1l7085
	
i1l818:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l7085
	
i1l819:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l7085
	
i1l7065:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l807
	xorlw	1^0	; case 1
	skipnz
	goto	i1l809
	xorlw	2^1	; case 2
	skipnz
	goto	i1l810
	xorlw	3^2	; case 3
	skipnz
	goto	i1l811
	xorlw	4^3	; case 4
	skipnz
	goto	i1l812
	xorlw	5^4	; case 5
	skipnz
	goto	i1l813
	xorlw	6^5	; case 6
	skipnz
	goto	i1l814
	xorlw	7^6	; case 7
	skipnz
	goto	i1l815
	xorlw	8^7	; case 8
	skipnz
	goto	i1l816
	xorlw	9^8	; case 9
	skipnz
	goto	i1l817
	xorlw	10^9	; case 10
	skipnz
	goto	i1l818
	xorlw	11^10	; case 11
	skipnz
	goto	i1l819
	goto	i1l821
	opt asmopt_pop

	line	987
	
i1l824:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l7071
	
i1l826:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l7071
	
i1l827:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l7071
	
i1l828:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l7071
	
i1l829:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l7071
	
i1l830:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l7071
	
i1l831:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l7071
	
i1l832:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l7071
	
i1l833:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l7071
	
i1l834:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l7071
	
i1l835:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l7071
	
i1l836:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l7071
	
i1l7069:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l824
	xorlw	1^0	; case 1
	skipnz
	goto	i1l826
	xorlw	2^1	; case 2
	skipnz
	goto	i1l827
	xorlw	3^2	; case 3
	skipnz
	goto	i1l828
	xorlw	4^3	; case 4
	skipnz
	goto	i1l829
	xorlw	5^4	; case 5
	skipnz
	goto	i1l830
	xorlw	6^5	; case 6
	skipnz
	goto	i1l831
	xorlw	7^6	; case 7
	skipnz
	goto	i1l832
	xorlw	8^7	; case 8
	skipnz
	goto	i1l833
	xorlw	9^8	; case 9
	skipnz
	goto	i1l834
	xorlw	10^9	; case 10
	skipnz
	goto	i1l835
	xorlw	11^10	; case 11
	skipnz
	goto	i1l836
	goto	i1l7071
	opt asmopt_pop

	line	990
	
i1l7071:	
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipnc
	goto	u1019_21
	goto	u1019_20
u1019_21:
	goto	i1l802
u1019_20:
	goto	i1l7061
	line	994
	
i1l821:	
	line	995
	goto	i1l7085
	line	998
	
i1l7075:	
		decf	((Charging_Control@s)),w
	btfss	status,2
	goto	u1020_21
	goto	u1020_20
u1020_21:
	goto	i1l7083
u1020_20:
	goto	i1l7079
	line	1000
	
i1l844:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l7085
	
i1l846:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l7085
	
i1l847:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l7085
	
i1l848:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l7085
	
i1l849:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l7085
	
i1l850:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l7085
	
i1l851:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l7085
	
i1l852:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l7085
	
i1l853:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l7085
	
i1l854:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l7085
	
i1l855:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l7085
	
i1l856:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l7085
	
i1l7079:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l844
	xorlw	1^0	; case 1
	skipnz
	goto	i1l846
	xorlw	2^1	; case 2
	skipnz
	goto	i1l847
	xorlw	3^2	; case 3
	skipnz
	goto	i1l848
	xorlw	4^3	; case 4
	skipnz
	goto	i1l849
	xorlw	5^4	; case 5
	skipnz
	goto	i1l850
	xorlw	6^5	; case 6
	skipnz
	goto	i1l851
	xorlw	7^6	; case 7
	skipnz
	goto	i1l852
	xorlw	8^7	; case 8
	skipnz
	goto	i1l853
	xorlw	9^8	; case 9
	skipnz
	goto	i1l854
	xorlw	10^9	; case 10
	skipnz
	goto	i1l855
	xorlw	11^10	; case 11
	skipnz
	goto	i1l856
	goto	i1l7085
	opt asmopt_pop

	line	1004
	
i1l7083:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l807
	xorlw	1^0	; case 1
	skipnz
	goto	i1l809
	xorlw	2^1	; case 2
	skipnz
	goto	i1l810
	xorlw	3^2	; case 3
	skipnz
	goto	i1l811
	xorlw	4^3	; case 4
	skipnz
	goto	i1l812
	xorlw	5^4	; case 5
	skipnz
	goto	i1l813
	xorlw	6^5	; case 6
	skipnz
	goto	i1l814
	xorlw	7^6	; case 7
	skipnz
	goto	i1l815
	xorlw	8^7	; case 8
	skipnz
	goto	i1l816
	xorlw	9^8	; case 9
	skipnz
	goto	i1l817
	xorlw	10^9	; case 10
	skipnz
	goto	i1l818
	xorlw	11^10	; case 11
	skipnz
	goto	i1l819
	goto	i1l7085
	opt asmopt_pop

	line	958
	
i1l7085:	
	incf	(Charging_Control@i),f
	
i1l7087:	
	movlw	low(0Ch)
	subwf	(Charging_Control@i),w
	skipc
	goto	u1021_21
	goto	u1021_20
u1021_21:
	goto	i1l7035
u1021_20:
	line	1008
	
i1l7089:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_ccCycle),f
	line	1011
	
i1l7091:	
	btfsc	(Charging_Control@chargeB1_6),0
	goto	u1022_21
	goto	u1022_20
	
u1022_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2099/8)^0100h,(2099)&7	;volatile
	goto	u1023_24
u1022_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
u1023_24:
	line	1012
	
i1l7093:	
	btfsc	(Charging_Control@chargeB7_12),0
	goto	u1024_21
	goto	u1024_20
	
u1024_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u1025_24
u1024_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u1025_24:
	line	1015
	
i1l768:	
	return
	opt stack 0
GLOBAL	__end_of_Charging_Control
	__end_of_Charging_Control:
	signat	_Charging_Control,89
	global	i1___lwmod

;; *************** function i1___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] unsigned int 
;;  dividend        2    2[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  __lwmod         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: B00/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Charging_Control
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext29
__ptext29:	;psect for function i1___lwmod
psect	text29
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_ofi1___lwmod
	__size_ofi1___lwmod	equ	__end_ofi1___lwmod-i1___lwmod
	
i1___lwmod:	
;incstack = 0
	opt	stack 2
; Regs used in i1___lwmod: [wreg+status,2+status,0]
	line	13
	
i1l3453:	
	movf	((i1___lwmod@divisor)),w
iorwf	((i1___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u383_21
	goto	u383_20
u383_21:
	goto	i1l3469
u383_20:
	line	14
	
i1l3455:	
	clrf	(i1___lwmod@counter)
	incf	(i1___lwmod@counter),f
	line	15
	goto	i1l3459
	line	16
	
i1l3457:	
	clrc
	rlf	(i1___lwmod@divisor),f
	rlf	(i1___lwmod@divisor+1),f
	line	17
	incf	(i1___lwmod@counter),f
	line	15
	
i1l3459:	
	btfss	(i1___lwmod@divisor+1),(15)&7
	goto	u384_21
	goto	u384_20
u384_21:
	goto	i1l3457
u384_20:
	line	20
	
i1l3461:	
	movf	(i1___lwmod@divisor+1),w
	subwf	(i1___lwmod@dividend+1),w
	skipz
	goto	u385_25
	movf	(i1___lwmod@divisor),w
	subwf	(i1___lwmod@dividend),w
u385_25:
	skipc
	goto	u385_21
	goto	u385_20
u385_21:
	goto	i1l3465
u385_20:
	line	21
	
i1l3463:	
	movf	(i1___lwmod@divisor),w
	subwf	(i1___lwmod@dividend),f
	movf	(i1___lwmod@divisor+1),w
	skipc
	decf	(i1___lwmod@dividend+1),f
	subwf	(i1___lwmod@dividend+1),f
	line	22
	
i1l3465:	
	clrc
	rrf	(i1___lwmod@divisor+1),f
	rrf	(i1___lwmod@divisor),f
	line	23
	
i1l3467:	
	decfsz	(i1___lwmod@counter),f
	goto	u386_21
	goto	u386_20
u386_21:
	goto	i1l3461
u386_20:
	line	25
	
i1l3469:	
	movf	(i1___lwmod@dividend+1),w
	movwf	(?i1___lwmod+1)
	movf	(i1___lwmod@dividend),w
	movwf	(?i1___lwmod)
	line	26
	
i1l1272:	
	return
	opt stack 0
GLOBAL	__end_ofi1___lwmod
	__end_ofi1___lwmod:
	signat	i1___lwmod,90
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 1033 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    6[BANK0 ] unsigned int 
;;  s               1   17[BANK0 ] unsigned char 
;;  duty            2   14[BANK0 ] int 
;;  error           2   10[BANK0 ] int 
;;  adjust          2    0[BANK0 ] int 
;;  duty_initial    1   13[BANK0 ] unsigned char 
;;  duty_target     1   12[BANK0 ] unsigned char 
;;  maxV            2    8[BANK0 ] unsigned int 
;;  i               1   16[BANK0 ] unsigned char 
;;  preCount        1    5[BANK0 ] unsigned char 
;;  ccCount         1    4[BANK0 ] unsigned char 
;;  cvCount         1    3[BANK0 ] unsigned char 
;;  hasCharging     1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 100/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2      18       0       0       0
;;Total ram usage:       20 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___awdiv
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text30,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	1033
global __ptext30
__ptext30:	;psect for function _CCCV_Control
psect	text30
	file	"charge_mgr.c"
	line	1033
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1036
	
i1l7095:	
	bcf	status, 6	;RP1=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	1037
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	1038
	clrf	(CCCV_Control@cvCount)
	line	1039
	clrf	(CCCV_Control@ccCount)
	line	1040
	clrf	(CCCV_Control@preCount)
	line	1043
	clrf	(CCCV_Control@i)
	line	1045
	
i1l7101:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	1049
	
i1l7103:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1026_21
	goto	u1026_20
u1026_21:
	goto	i1l881
u1026_20:
	
i1l7105:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1027_21
	goto	u1027_20
u1027_21:
	goto	i1l881
u1027_20:
	
i1l7107:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1028_21
	goto	u1028_20
u1028_21:
	goto	i1l881
u1028_20:
	
i1l7109:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1029_21
	goto	u1029_20
u1029_21:
	goto	i1l881
u1029_20:
	
i1l7111:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1030_21
	goto	u1030_20
u1030_21:
	goto	i1l879
u1030_20:
	
i1l881:	
	line	1051
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	1053
	
i1l7113:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	1054
	
i1l7115:	
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u1031_25
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u1031_25:
	skipnc
	goto	u1031_21
	goto	u1031_20
u1031_21:
	goto	i1l7119
u1031_20:
	
i1l7117:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	1056
	
i1l7119:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1032_21
	goto	u1032_20
u1032_21:
	goto	i1l7123
u1032_20:
	line	1057
	
i1l7121:	
	incf	(CCCV_Control@cvCount),f
	line	1058
	
i1l7123:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1033_21
	goto	u1033_20
u1033_21:
	goto	i1l7127
u1033_20:
	line	1059
	
i1l7125:	
	incf	(CCCV_Control@ccCount),f
	line	1060
	
i1l7127:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1034_21
	goto	u1034_20
u1034_21:
	goto	i1l7131
u1034_20:
	
i1l7129:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1035_21
	goto	u1035_20
u1035_21:
	goto	i1l879
u1035_20:
	line	1061
	
i1l7131:	
	incf	(CCCV_Control@preCount),f
	line	1062
	
i1l879:	
	line	1043
	incf	(CCCV_Control@i),f
	
i1l7133:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u1036_21
	goto	u1036_20
u1036_21:
	goto	i1l7101
u1036_20:
	line	1066
	
i1l7135:	
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u1037_21
	goto	u1037_20
u1037_21:
	goto	i1l7141
u1037_20:
	line	1068
	
i1l7137:	
	clrf	(_g_pwmDuty)	;volatile
	line	1069
	clrf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l889
	line	1077
	
i1l7141:	
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u1038_21
	goto	u1038_20
u1038_21:
	goto	i1l7171
u1038_20:
	line	1081
	
i1l7143:	
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u1039_21
	goto	u1039_20
u1039_21:
	goto	i1l7147
u1039_20:
	line	1084
	
i1l7145:	
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	1085
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	1086
	goto	i1l7155
	line	1087
	
i1l7147:	
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u1040_21
	goto	u1040_20
u1040_21:
	goto	i1l7151
u1040_20:
	line	1090
	
i1l7149:	
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	1091
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	1092
	goto	i1l7155
	line	1097
	
i1l7151:	
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l889
	line	1101
	
i1l7155:	
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u1041_21
	goto	u1041_20
u1041_21:
	goto	i1l7163
u1041_20:
	line	1104
	
i1l7157:	
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	1105
	
i1l7159:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u1042_21
	goto	u1042_20
u1042_21:
	goto	i1l889
u1042_20:
	line	1106
	
i1l7161:	
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l889
	line	1108
	
i1l7163:	
	line	1111
	
i1l7165:	
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	1112
	goto	i1l889
	line	1127
	
i1l7171:	
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	1130
	movf	(CCCV_Control@error),w
	addwf	(_g_cvIntegral),f
	skipnc
	incf	(_g_cvIntegral+1),f
	movf	(CCCV_Control@error+1),w
	addwf	(_g_cvIntegral+1),f
	line	1131
	
i1l7173:	
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u1043_25
	movlw	0C9h
	subwf	(_g_cvIntegral),w
u1043_25:

	skipc
	goto	u1043_21
	goto	u1043_20
u1043_21:
	goto	i1l7177
u1043_20:
	line	1132
	
i1l7175:	
	movlw	0C8h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l7181
	line	1133
	
i1l7177:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u1044_25
	movlw	038h
	subwf	(_g_cvIntegral),w
u1044_25:

	skipnc
	goto	u1044_21
	goto	u1044_20
u1044_21:
	goto	i1l7181
u1044_20:
	line	1134
	
i1l7179:	
	movlw	038h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	movlw	0FFh
	movwf	((_g_cvIntegral))+1
	line	1137
	
i1l7181:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	movf	(_g_cvIntegral),w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1),w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	1138
	
i1l7183:	
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
i1l7185:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	1141
	
i1l7187:	
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u1045_25
	movlw	021h
	subwf	(CCCV_Control@duty),w
u1045_25:

	skipc
	goto	u1045_21
	goto	u1045_20
u1045_21:
	goto	i1l7191
u1045_20:
	
i1l7189:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1142
	
i1l7191:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u1046_21
	goto	u1046_20
u1046_21:
	goto	i1l7195
u1046_20:
	
i1l7193:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1144
	
i1l7195:	
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	1146
	
i1l889:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	i1___bmul

;; *************** function i1___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[COMMON] unsigned char 
;;  __bmul          1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Charging_Control
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text31,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext31
__ptext31:	;psect for function i1___bmul
psect	text31
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_ofi1___bmul
	__size_ofi1___bmul	equ	__end_ofi1___bmul-i1___bmul
	
i1___bmul:	
;incstack = 0
	opt	stack 2
; Regs used in i1___bmul: [wreg+status,2+status,0]
	movwf	(i1___bmul@multiplier)
	line	6
	
i1l3473:	
	clrf	(i1___bmul@product)
	line	43
	
i1l3475:	
	btfss	(i1___bmul@multiplier),(0)&7
	goto	u387_21
	goto	u387_20
u387_21:
	goto	i1l3479
u387_20:
	line	44
	
i1l3477:	
	movf	(i1___bmul@multiplicand),w
	addwf	(i1___bmul@product),f
	line	45
	
i1l3479:	
	clrc
	rlf	(i1___bmul@multiplicand),f
	line	46
	
i1l3481:	
	clrc
	rrf	(i1___bmul@multiplier),f
	line	47
	movf	((i1___bmul@multiplier)),w
	btfss	status,2
	goto	u388_21
	goto	u388_20
u388_21:
	goto	i1l3475
u388_20:
	line	50
	
i1l3483:	
	movf	(i1___bmul@product),w
	line	51
	
i1l943:	
	return
	opt stack 0
GLOBAL	__end_ofi1___bmul
	__end_ofi1___bmul:
	signat	i1___bmul,89
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] int 
;;  dividend        2    2[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] int 
;;  sign            1    5[COMMON] unsigned char 
;;  counter         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text32,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext32
__ptext32:	;psect for function ___awdiv
psect	text32
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
i1l3409:	
	clrf	(___awdiv@sign)
	line	15
	
i1l3411:	
	btfss	(___awdiv@divisor+1),7
	goto	u376_21
	goto	u376_20
u376_21:
	goto	i1l3417
u376_20:
	line	16
	
i1l3413:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
i1l3415:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
i1l3417:	
	btfss	(___awdiv@dividend+1),7
	goto	u377_21
	goto	u377_20
u377_21:
	goto	i1l3423
u377_20:
	line	20
	
i1l3419:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
i1l3421:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
i1l3423:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
i1l3425:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u378_21
	goto	u378_20
u378_21:
	goto	i1l3445
u378_20:
	line	25
	
i1l3427:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	i1l3431
	line	27
	
i1l3429:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
i1l3431:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u379_21
	goto	u379_20
u379_21:
	goto	i1l3429
u379_20:
	line	31
	
i1l3433:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
i1l3435:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u380_25
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u380_25:
	skipc
	goto	u380_21
	goto	u380_20
u380_21:
	goto	i1l3441
u380_20:
	line	33
	
i1l3437:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
i1l3439:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
i1l3441:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
i1l3443:	
	decfsz	(___awdiv@counter),f
	goto	u381_21
	goto	u381_20
u381_21:
	goto	i1l3433
u381_20:
	line	39
	
i1l3445:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u382_21
	goto	u382_20
u382_21:
	goto	i1l3449
u382_20:
	line	40
	
i1l3447:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
i1l3449:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
i1l1055:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
