opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ChargeProcess_Slot
	FNCALL	_main,_Do_AdcSample
	FNCALL	_main,_Do_NtcRead
	FNCALL	_main,_Print_DetectLog
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_System_Init
	FNCALL	_main,___bmul
	FNCALL	_main,_uart_send_number
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_Print_DetectLog,_uart_send_char
	FNCALL	_Print_DetectLog,_uart_send_number
	FNCALL	_Print_DetectLog,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_Do_NtcRead,_Read_Temperature
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Do_AdcSample,_ADC_Sample
	FNCALL	_Do_AdcSample,___bmul
	FNCALL	_ChargeProcess_Slot,_Detect_BatteryType
	FNCALL	_ChargeProcess_Slot,___bmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_CCCV_Control
	FNCALL	_Isr_Timer,_Charging_Control
	FNCALL	_Isr_Timer,_Led_BlinkProcess
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Update_LED_Slot
	FNCALL	_Update_LED_Slot,i1___bmul
	FNCALL	_Led_BlinkProcess,i1___bmul
	FNCALL	_Charging_Control,i1___bmul
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,i1___bmul
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_temperature
psect	idataBANK0,class=CODE,space=0,delta=2,noexec
global __pidataBANK0
__pidataBANK0:
	file	"charge_mgr.c"
	line	14

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"main.c"
	line	46
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_dbgDetectFlag
	global	_g_ntcPrintFlag
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_adcBusy
	global	_g_doAdcSample
	global	_g_detectLogFlag
	global	_g_powerOnTimer
	global	_g_tempProtect
	global	_g_dbgNewType
	global	_g_dbgNewState
	global	_g_dbgSlot
	global	_g_tempPhase
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_scanPhase
	global	_g_scanIndex
	global	_g_detectLogType
	global	_g_detectLogSlot
	global	_test_adc
	global	_adresult
	global	_g_impRefV
	global	_g_dbgVoltage
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_cvIntegral
	global	_g_slot1
	global	_g_slot0
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_GIE
_GIE	set	0x5F
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RC4
_RC4	set	0x834
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC5
_RC5	set	0x835
	global	_RC3
_RC3	set	0x833
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_25:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	101	;'e'
	retlw	108	;'l'
	retlw	108	;'l'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	68	;'D'
	retlw	66	;'B'
	retlw	71	;'G'
	retlw	58	;':'
	retlw	32	;' '
	retlw	115	;'s'
	retlw	108	;'l'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_27:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	87	;'W'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_32:	
	retlw	32	;' '
	retlw	118	;'v'
	retlw	114	;'r'
	retlw	102	;'f'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_9:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_29:	
	retlw	32	;' '
	retlw	115	;'s'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_30:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_11:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_31:	
	retlw	32	;' '
	retlw	86	;'V'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
STR_7	equ	STR_2+0
STR_8	equ	STR_3+0
STR_23	equ	STR_27+7
STR_33	equ	STR_27+7
; #config settings
	file	"main.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_g_dbgDetectFlag:
       ds      1

_g_ntcPrintFlag:
       ds      1

_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

_g_adcBusy:
       ds      1

_g_doAdcSample:
       ds      1

_g_detectLogFlag:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_powerOnTimer:
       ds      2

_g_tempProtect:
       ds      1

_g_dbgNewType:
       ds      1

_g_dbgNewState:
       ds      1

_g_dbgSlot:
       ds      1

_g_tempPhase:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_scanPhase:
       ds      1

_g_scanIndex:
       ds      1

_g_detectLogType:
       ds      1

_g_detectLogSlot:
       ds      1

_test_adc:
       ds      1

_adresult:
       ds      2

psect	dataBANK0,class=BANK0,space=1,noexec
global __pdataBANK0
__pdataBANK0:
	file	"charge_mgr.c"
	line	14
_g_temperature:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_impRefV:
       ds      24

_g_dbgVoltage:
       ds      2

_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_cvIntegral:
       ds      2

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slot0:
       ds      72

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot1:
       ds      72

	file	"main.as"
	line	#
; Initialize objects allocated to BANK0
	global __pidataBANK0
psect cinit,class=CODE,delta=2,merge=1
	fcall	__pidataBANK0+0		;fetch initializer
	movwf	__pdataBANK0+0&07fh		
	fcall	__pidataBANK0+1		;fetch initializer
	movwf	__pdataBANK0+1&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+022h)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+011h)
	fcall	clear_ram0
; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
	global	ChargeProcess_Slot@delta
ChargeProcess_Slot@delta:	; 2 bytes @ 0x0
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x0
	ds	2
	global	ChargeProcess_Slot@rise
ChargeProcess_Slot@rise:	; 2 bytes @ 0x2
	ds	2
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x4
	global	ChargeProcess_Slot@v_before
ChargeProcess_Slot@v_before:	; 2 bytes @ 0x4
	ds	1
??_Read_Temperature:	; 1 bytes @ 0x5
??_Print_SystemStatus:	; 1 bytes @ 0x5
	ds	1
	global	ChargeProcess_Slot@v_after
ChargeProcess_Slot@v_after:	; 2 bytes @ 0x6
	ds	2
	global	ChargeProcess_Slot@v_start
ChargeProcess_Slot@v_start:	; 2 bytes @ 0x8
	ds	1
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x9
	ds	1
	global	ChargeProcess_Slot@v_now
ChargeProcess_Slot@v_now:	; 2 bytes @ 0xA
	ds	3
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0xD
	global	_Print_SystemStatus$741
_Print_SystemStatus$741:	; 2 bytes @ 0xD
	ds	1
	global	ChargeProcess_Slot@idx
ChargeProcess_Slot@idx:	; 1 bytes @ 0xE
	ds	1
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0xF
	global	ChargeProcess_Slot@v
ChargeProcess_Slot@v:	; 2 bytes @ 0xF
	global	_Print_SystemStatus$742
_Print_SystemStatus$742:	; 2 bytes @ 0xF
	ds	2
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x11
	global	ChargeProcess_Slot@slot
ChargeProcess_Slot@slot:	; 12 bytes @ 0x11
	ds	4
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x15
	ds	1
	global	_Print_SystemStatus$298
_Print_SystemStatus$298:	; 2 bytes @ 0x16
	ds	2
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0x18
	ds	4
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x1C
	ds	2
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0x1E
	ds	4
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x22
	ds	2
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x24
	ds	1
??_main:	; 1 bytes @ 0x25
	ds	2
	global	main@vrfy
main@vrfy:	; 1 bytes @ 0x27
	ds	1
	global	main@slot
main@slot:	; 1 bytes @ 0x28
	ds	1
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Update_LED_Slot:	; 1 bytes @ 0x0
?_Charging_Control:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Led_BlinkProcess:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_ChargeProcess_Slot:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Do_AdcSample:	; 1 bytes @ 0x0
?_Do_NtcRead:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_Print_DetectLog:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?i1___bmul:	; 1 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	i1___bmul@multiplicand
i1___bmul@multiplicand:	; 1 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	ds	1
??i1___bmul:	; 1 bytes @ 0x1
	global	i1___bmul@multiplier
i1___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
	global	i1___bmul@product
i1___bmul@product:	; 1 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_Update_LED_Slot:	; 1 bytes @ 0x3
??_Charging_Control:	; 1 bytes @ 0x3
??_Led_BlinkProcess:	; 1 bytes @ 0x3
	global	Update_LED_Slot@s
Update_LED_Slot@s:	; 1 bytes @ 0x3
	global	_Charging_Control$403
_Charging_Control$403:	; 2 bytes @ 0x3
	global	Led_BlinkProcess@bt
Led_BlinkProcess@bt:	; 2 bytes @ 0x3
	ds	1
??___awdiv:	; 1 bytes @ 0x4
	global	Update_LED_Slot@led
Update_LED_Slot@led:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	ds	1
	global	Charging_Control@chargeB1_6
Charging_Control@chargeB1_6:	; 1 bytes @ 0x5
	global	Update_LED_Slot@idx
Update_LED_Slot@idx:	; 1 bytes @ 0x5
	global	Led_BlinkProcess@led
Led_BlinkProcess@led:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	ds	1
	global	Charging_Control@chargeB7_12
Charging_Control@chargeB7_12:	; 1 bytes @ 0x6
	global	Led_BlinkProcess@i
Led_BlinkProcess@i:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	1
	global	Charging_Control@s
Charging_Control@s:	; 1 bytes @ 0x7
	ds	1
??_CCCV_Control:	; 1 bytes @ 0x8
	global	Charging_Control@i
Charging_Control@i:	; 1 bytes @ 0x8
	ds	2
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x0
	ds	2
	global	_CCCV_Control$410
_CCCV_Control$410:	; 2 bytes @ 0x2
	ds	2
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x4
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x5
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x6
	ds	2
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x8
	ds	2
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xA
	ds	2
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0xC
	ds	2
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0xE
	ds	1
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0xF
	ds	1
??_Isr_Timer:	; 1 bytes @ 0x10
	ds	4
??_AD_Init:	; 1 bytes @ 0x14
??_uart_init:	; 1 bytes @ 0x14
?_ADC_Sample:	; 1 bytes @ 0x14
??_uart_send_char:	; 1 bytes @ 0x14
?_Detect_BatteryType:	; 1 bytes @ 0x14
?___bmul:	; 1 bytes @ 0x14
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x14
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x14
	global	?___lmul
?___lmul:	; 4 bytes @ 0x14
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x14
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x14
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x14
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x14
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x14
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x14
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x15
??___bmul:	; 1 bytes @ 0x15
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x15
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x15
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x16
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x16
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x16
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x16
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x16
	ds	1
?_uart_send_string:	; 1 bytes @ 0x17
??_ChargeProcess_Slot:	; 1 bytes @ 0x17
??_System_Init:	; 1 bytes @ 0x17
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x17
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x17
	ds	1
??___lwdiv:	; 1 bytes @ 0x18
??___lwmod:	; 1 bytes @ 0x18
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x18
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x18
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x18
	ds	1
??_uart_send_string:	; 1 bytes @ 0x19
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x19
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x19
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x1A
	ds	1
?_uart_send_number:	; 1 bytes @ 0x1B
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x1B
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x1B
	ds	1
??___lmul:	; 1 bytes @ 0x1C
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x1C
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x1C
	ds	1
??_uart_send_number:	; 1 bytes @ 0x1D
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x1D
	ds	3
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x20
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x20
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x20
	ds	2
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x22
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0x23
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x24
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0x24
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x24
	ds	1
??_Print_NtcTemp:	; 1 bytes @ 0x25
??_Print_DetectLog:	; 1 bytes @ 0x25
	global	_Print_NtcTemp$739
_Print_NtcTemp$739:	; 2 bytes @ 0x25
	ds	1
??_Do_AdcSample:	; 1 bytes @ 0x26
	global	Do_AdcSample@ch
Do_AdcSample@ch:	; 1 bytes @ 0x26
	ds	1
	global	_Print_NtcTemp$740
_Print_NtcTemp$740:	; 2 bytes @ 0x27
	ds	1
??_Do_NtcRead:	; 1 bytes @ 0x28
??___lldiv:	; 1 bytes @ 0x28
	ds	1
;!
;!Data Sizes:
;!    Strings     268
;!    Constant    12
;!    Data        2
;!    BSS         195
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     10      11
;!    BANK0            80     41      60
;!    BANK1            80     41      75
;!    BANK3            80      0      72
;!    BANK2            80      0      72

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 37
;!		 -> STR_33(CODE[3]), STR_32(CODE[7]), STR_31(CODE[4]), STR_30(CODE[5]), 
;!		 -> STR_29(CODE[5]), STR_28(CODE[11]), STR_27(CODE[10]), STR_26(CODE[21]), 
;!		 -> STR_25(CODE[37]), STR_24(CODE[33]), STR_23(CODE[3]), STR_22(CODE[6]), 
;!		 -> STR_21(CODE[8]), STR_20(CODE[6]), STR_19(CODE[6]), STR_18(CODE[7]), 
;!		 -> STR_17(CODE[5]), STR_16(CODE[5]), STR_15(CODE[6]), STR_14(CODE[6]), 
;!		 -> STR_13(CODE[6]), STR_12(CODE[7]), STR_11(CODE[4]), STR_10(CODE[6]), 
;!		 -> STR_9(CODE[6]), STR_8(CODE[4]), STR_7(CODE[2]), STR_6(CODE[6]), 
;!		 -> STR_5(CODE[5]), STR_4(CODE[29]), STR_3(CODE[4]), STR_2(CODE[2]), 
;!		 -> STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->_CCCV_Control
;!    _Update_LED_Slot->i1___bmul
;!    _Led_BlinkProcess->i1___bmul
;!    _Charging_Control->i1___bmul
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Print_NtcTemp
;!    _System_Init->___bmul
;!    _Print_SystemStatus->___lldiv
;!    _Print_NtcTemp->_uart_send_number
;!    _Print_DetectLog->_uart_send_number
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _Read_Temperature->___lldiv
;!    ___lldiv->___lmul
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->___bmul
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    _Isr_Timer->_CCCV_Control
;!
;!Critical Paths under _main in BANK1
;!
;!    _main->_Print_SystemStatus
;!    _Print_SystemStatus->___lldiv
;!    _Do_NtcRead->_Read_Temperature
;!    _Read_Temperature->___lldiv
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 4     4      0   42567
;!                                             37 BANK1      4     4      0
;!                 _ChargeProcess_Slot
;!                       _Do_AdcSample
;!                         _Do_NtcRead
;!                    _Print_DetectLog
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                        _System_Init
;!                             ___bmul
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    2042
;!                                             23 BANK0      1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  32    32      0   10957
;!                                              5 BANK1     32    32      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    5811
;!                                             37 BANK0      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_DetectLog                                      0     0      0    4878
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    2312
;!                                             23 BANK0      2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_number                                    10     8      2    2464
;!                                             27 BANK0     10     8      2
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     102
;!                                             20 BANK0      3     3      0
;! ---------------------------------------------------------------------------------
;! (2) ___lwmod                                              5     1      4     378
;!                                             20 BANK0      5     1      4
;! ---------------------------------------------------------------------------------
;! (1) _Do_NtcRead                                           0     0      0    3892
;!                   _Read_Temperature
;! ---------------------------------------------------------------------------------
;! (2) _Read_Temperature                                    12    12      0    3892
;!                                              5 BANK1     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (2) ___lwdiv                                              7     3      4     647
;!                                             20 BANK0      7     3      4
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8    1077
;!                                             20 BANK0     12     4      8
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8     800
;!                                             32 BANK0      8     0      8
;!                                              0 BANK1      5     5      0
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (1) _Do_AdcSample                                         1     1      0    2415
;!                                             38 BANK0      1     1      0
;!                         _ADC_Sample
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) _ADC_Sample                                          18    17      1     965
;!                                             20 BANK0     18    17      1
;! ---------------------------------------------------------------------------------
;! (1) _ChargeProcess_Slot                                  33    33      0    6216
;!                                             23 BANK0      4     4      0
;!                                              0 BANK1     29    29      0
;!                 _Detect_BatteryType
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) ___bmul                                               3     2      1    1416
;!                                             20 BANK0      3     2      1
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     437
;!                                             20 BANK0      2     0      2
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 2
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            4     4      0    4547
;!                                             16 BANK0      4     4      0
;!                       _CCCV_Control
;!                   _Charging_Control
;!                   _Led_BlinkProcess
;!                 _PowerOnLedSequence
;!                    _Update_LED_Slot
;! ---------------------------------------------------------------------------------
;! (5) _Update_LED_Slot                                      3     3      0     748
;!                                              3 COMMON     3     3      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Led_BlinkProcess                                     4     4      0     993
;!                                              3 COMMON     4     4      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _Charging_Control                                     6     6      0    1002
;!                                              3 COMMON     6     6      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _CCCV_Control                                        18    18      0    1804
;!                                              8 COMMON     2     2      0
;!                                              0 BANK0     16    16      0
;!                            ___awdiv
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (6) i1___bmul                                             3     2      1     448
;!                                              0 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (6) ___awdiv                                              8     4      4     428
;!                                              0 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ChargeProcess_Slot
;!     _Detect_BatteryType
;!     ___bmul
;!   _Do_AdcSample
;!     _ADC_Sample
;!     ___bmul
;!   _Do_NtcRead
;!     _Read_Temperature
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!       ___lwdiv
;!   _Print_DetectLog
;!     _uart_send_char
;!     _uart_send_number
;!       ___lwdiv
;!       ___lwmod
;!       _uart_send_char
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___lwdiv
;!       ___lwmod
;!       _uart_send_char
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___lwdiv
;!       ___lwmod
;!       _uart_send_char
;!     _uart_send_string
;!       _uart_send_char
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   ___bmul
;!   _uart_send_number
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     i1___bmul
;!   _Charging_Control
;!     i1___bmul
;!   _Led_BlinkProcess
;!     i1___bmul
;!   _PowerOnLedSequence
;!   _Update_LED_Slot
;!     i1___bmul
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50      0      48       8       90.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      0      48      10       90.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50     29      4B       6       93.8%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     29      3C       4       75.0%
;!BITBANK0            50      0       0       3        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      A       B       1       78.6%
;!BITCOMMON            E      0       1       0        7.1%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     122      12        0.0%
;!ABS                  0      0     122      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 447 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vrfy            1   39[BANK1 ] unsigned char 
;;  slot            1   40[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       2       0       0
;;      Temps:          0       0       2       0       0
;;      Totals:         0       0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ChargeProcess_Slot
;;		_Do_AdcSample
;;		_Do_NtcRead
;;		_Print_DetectLog
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_System_Init
;;		___bmul
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"main.c"
	line	447
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"main.c"
	line	447
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	450
	
l4564:	
	opt asmopt_push
opt asmopt_off
movlw	52
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_main+0)^080h+0+1),f
	movlw	241
movwf	((??_main+0)^080h+0),f
	u5547:
decfsz	((??_main+0)^080h+0),f
	goto	u5547
	decfsz	((??_main+0)^080h+0+1),f
	goto	u5547
opt asmopt_pop

	line	451
# 451 "main.c"
clrwdt ;# 
psect	maintext
	line	454
	
l4566:	
	fcall	_System_Init
	line	457
	
l4568:	
	movlw	low(((STR_26)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	458
	
l4570:	
	movlw	low(((STR_27)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	461
	
l451:	
	line	463
# 463 "main.c"
clrwdt ;# 
psect	maintext
	line	466
	
l4572:	
	btfss	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u5471
	goto	u5470
u5471:
	goto	l4612
u5470:
	line	468
	
l4574:	
	bcf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	line	469
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	470
	
l4576:	
	fcall	_Do_AdcSample
	line	474
	
l4578:	
	movf	(_g_scanIndex),w	;volatile
	fcall	_ChargeProcess_Slot
	line	477
	
l4580:	
	btfss	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	goto	u5481
	goto	u5480
u5481:
	goto	l4610
u5480:
	line	479
	
l4582:	
	movf	(_g_dbgSlot),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(main@slot)^080h
	line	480
	
l4584:	
	bcf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	483
	
l4586:	
	movlw	low(((STR_28)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	484
	
l4588:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(main@slot)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	485
	
l4590:	
	movlw	low(((STR_29)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	486
	
l4592:	
	movf	(_g_dbgNewState),w	;volatile
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	487
	
l4594:	
	movlw	low(((STR_30)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	488
	
l4596:	
	movf	(_g_dbgNewType),w	;volatile
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	489
	
l4598:	
	movlw	low(((STR_31)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	490
	
l4600:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_dbgVoltage+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_dbgVoltage)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	494
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	(main@slot)^080h,w
	skipnc
	goto	u5491
	goto	u5490
u5491:
	goto	l4604
u5490:
	
l4602:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(main@slot)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(main@vrfy)^080h
	goto	l4606
	line	495
	
l4604:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(main@slot)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B9h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(main@vrfy)^080h
	line	496
	
l4606:	
	movlw	low(((STR_32)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	497
	
l4608:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(main@vrfy)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	499
	movlw	low(((STR_33)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	502
	
l4610:	
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	506
	
l4612:	
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u5501
	goto	u5500
u5501:
	goto	l4620
u5500:
	line	508
	
l4614:	
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	509
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	510
	
l4616:	
	fcall	_Do_NtcRead
	line	511
	
l4618:	
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	515
	
l4620:	
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u5511
	goto	u5510
u5511:
	goto	l4626
u5510:
	line	517
	
l4622:	
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	518
	
l4624:	
	fcall	_Print_SystemStatus
	line	522
	
l4626:	
	btfss	(_g_ntcPrintFlag/8),(_g_ntcPrintFlag)&7	;volatile
	goto	u5521
	goto	u5520
u5521:
	goto	l4632
u5520:
	line	524
	
l4628:	
	bcf	(_g_ntcPrintFlag/8),(_g_ntcPrintFlag)&7	;volatile
	line	525
	
l4630:	
	fcall	_Print_NtcTemp
	line	529
	
l4632:	
	btfss	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	goto	u5531
	goto	u5530
u5531:
	goto	l451
u5530:
	line	531
	
l4634:	
	bcf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	line	532
	
l4636:	
	fcall	_Print_DetectLog
	goto	l451
	global	start
	ljmp	start
	opt stack 0
	line	535
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 67 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   23[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	67
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"main.c"
	line	67
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	72
	
l3838:	
# 72 "main.c"
nop ;# 
	line	73
# 73 "main.c"
clrwdt ;# 
psect	text1
	line	74
	
l3840:	
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	78
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	79
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	80
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l3842:	
	clrf	(262)^0100h	;volatile
	line	81
	
l3844:	
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l3846:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	84
	
l3848:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l3850:	
	clrf	(135)^080h	;volatile
	line	85
	
l3852:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l3854:	
	clrf	(7)	;volatile
	line	86
	
l3856:	
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	87
	
l3858:	
	clrf	(277)^0100h	;volatile
	line	90
	
l3860:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l3862:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	93
	
l3864:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	94
	
l3866:	
	clrf	(406)^0180h	;volatile
	line	101
	
l3868:	
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	102
	
l3870:	
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	103
	
l3872:	
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	104
	
l3874:	
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	107
	
l3876:	
	fcall	_AD_Init
	line	110
	
l3878:	
	fcall	_uart_init
	line	117
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	118
	
l3880:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	119
	
l3882:	
	bcf	(90/8),(90)&7	;volatile
	line	120
	
l3884:	
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	123
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	124
	clrf	(_g_pwmCounter)	;volatile
	line	125
	
l3886:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	126
	
l3888:	
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	127
	
l3890:	
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	128
	
l3892:	
	bcf	(55/8),(55)&7	;volatile
	line	131
	clrf	(System_Init@i)
	line	133
	
l3898:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	134
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	135
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	136
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+05h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	137
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+07h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	138
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+09h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	139
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	140
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+0Ah)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	141
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+0Bh)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	143
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	144
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	145
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	146
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+05h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	147
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+07h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	148
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+09h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	149
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	150
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0Ah)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	151
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0Bh)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	131
	
l3900:	
	incf	(System_Init@i),f
	
l3902:	
	movlw	low(06h)
	subwf	(System_Init@i),w
	skipc
	goto	u4371
	goto	u4370
u4371:
	goto	l3898
u4370:
	line	155
	
l353:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"uart_dbg.c"
	line	21
global __ptext2
__ptext2:	;psect for function _uart_init
psect	text2
	file	"uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_init: []
	line	23
	
l3692:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l492:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	23
global __ptext3
__ptext3:	;psect for function _AD_Init
psect	text3
	file	"adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l3686:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
	clrf	(406)^0180h	;volatile
	line	27
	
l3688:	
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l3690:	
	clrf	(150)^080h	;volatile
	line	29
	
l469:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 332 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  bat_mv_long     4   30[BANK1 ] unsigned long 
;;  vx_mv           4   24[BANK1 ] unsigned long 
;;  v               2   28[BANK1 ] unsigned int 
;;  s               1   21[BANK1 ] unsigned char 
;;  pt              4   17[BANK1 ] unsigned long 
;;  vcc_mv          2   34[BANK1 ] unsigned int 
;;  i               1   36[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      24       0       0
;;      Temps:          0       0       8       0       0
;;      Totals:         0       0      32       0       0
;;Total ram usage:       32 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	332
global __ptext4
__ptext4:	;psect for function _Print_SystemStatus
psect	text4
	file	"main.c"
	line	332
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	337
	
l4136:	
	movlw	low(((STR_4)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	340
	
l4138:	
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	341
	
l4140:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u4821
	goto	u4820
u4821:
	goto	l4146
u4820:
	line	343
	
l4142:	
	movf	(_adresult),w	;volatile
	movwf	(___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@pt+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@pt+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@pt+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@pt)^080h

	line	344
	
l4144:	
	movf	(Print_SystemStatus@pt+1)^080h,w
	movwf	(Print_SystemStatus@vcc_mv+1)^080h
	movf	(Print_SystemStatus@pt)^080h,w
	movwf	(Print_SystemStatus@vcc_mv)^080h
	line	345
	goto	l4148
	line	347
	
l4146:	
	movlw	088h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vcc_mv)^080h
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv)^080h)+1
	line	349
	
l4148:	
	movlw	low(((STR_5)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	350
	
l4150:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	351
	
l4152:	
	movlw	low(((STR_6)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	352
	
l4154:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$741+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$741)^080h
	
l4156:	
	movf	(_Print_SystemStatus$741+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_Print_SystemStatus$741)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	353
	
l4158:	
	movlw	low(((STR_7)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	354
	
l4160:	
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$742+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$742)^080h
	
l4162:	
	movf	(_Print_SystemStatus$742+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_Print_SystemStatus$742)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	355
	
l4164:	
	movlw	low(((STR_8)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	362
	
l4166:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(Print_SystemStatus@i)^080h
	line	365
	
l4172:	
	movlw	low(06h)
	subwf	(Print_SystemStatus@i)^080h,w
	skipc
	goto	u4831
	goto	u4830
u4831:
	goto	l4176
u4830:
	
l4174:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0BBh)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@v)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)^080h
	goto	l4178
	
l4176:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@v)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)^080h
	line	366
	
l4178:	
	movlw	low(06h)
	subwf	(Print_SystemStatus@i)^080h,w
	skipc
	goto	u4841
	goto	u4840
u4841:
	goto	l4182
u4840:
	
l4180:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B9h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$298)^080h
	clrf	(_Print_SystemStatus$298+1)^080h
	goto	l4184
	
l4182:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$298)^080h
	clrf	(_Print_SystemStatus$298+1)^080h
	
l4184:	
	movf	(_Print_SystemStatus$298)^080h,w
	movwf	(Print_SystemStatus@s)^080h
	line	373
	
l4186:	
	movlw	low(042h)
	fcall	_uart_send_char
	line	374
	
l4188:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	375
	
l4190:	
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	376
	
l4192:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	382
	
l4194:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vx_mv+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vx_mv+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vx_mv+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vx_mv)^080h

	
l4196:	
	movlw	0Ch
u4855:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3)^080h,f
	rrf	(Print_SystemStatus@vx_mv+2)^080h,f
	rrf	(Print_SystemStatus@vx_mv+1)^080h,f
	rrf	(Print_SystemStatus@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u4855

	line	383
	
l4198:	
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	clrf	((??_Print_SystemStatus+0)^080h+0+2)
	clrf	((??_Print_SystemStatus+0)^080h+0+3)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+4)^080h+0)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	(Print_SystemStatus@vx_mv)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+0,f
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1)^080h,w
	goto	u4860
	goto	u4861
u4860:
	addwf	(??_Print_SystemStatus+4)^080h+1,f
u4861:
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2)^080h,w
	goto	u4862
	goto	u4863
u4862:
	addwf	(??_Print_SystemStatus+4)^080h+2,f
u4863:
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	subwf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u4875
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	subwf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u4875
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	subwf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u4875
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	subwf	0+(??_Print_SystemStatus+4)^080h+0,w
u4875:
	skipc
	goto	u4871
	goto	u4870
u4871:
	goto	l4202
u4870:
	line	385
	
l4200:	
	movlw	low(((STR_9)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	386
	goto	l4212
	line	389
	
l4202:	
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vx_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)

	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	04h
	movwf	(___lmul@multiplicand+1)
	movlw	087h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long)^080h

	line	390
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	02h
	movwf	(___lmul@multiplicand+1)
	movlw	087h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(3+(?___lmul)),w
	skipz
	goto	u4885
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long+2)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(2+(?___lmul)),w
	skipz
	goto	u4885
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(1+(?___lmul)),w
	skipz
	goto	u4885
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(0+(?___lmul)),w
u4885:
	skipnc
	goto	u4881
	goto	u4880
u4881:
	goto	l4212
u4880:
	line	392
	
l4204:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	bsf	status, 5	;RP0=1, select bank1
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+3)
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)
	movlw	0FDh
	movwf	(___lmul@multiplicand+1)
	movlw	079h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(0+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(Print_SystemStatus@bat_mv_long)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+0)
	movlw	0
	skipnc
	movlw	1
	bcf	status, 5	;RP0=0, select bank0
	addwf	(1+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	clrf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	addwf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	((??_Print_SystemStatus+4)^080h+0+2),w
	clrf	((??_Print_SystemStatus+4)^080h+0+3)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	addwf	(Print_SystemStatus@bat_mv_long+2)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	bcf	status, 5	;RP0=0, select bank0
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	((??_Print_SystemStatus+4)^080h+0+3),w
	addwf	(Print_SystemStatus@bat_mv_long+3)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	0+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+0,f
	movf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	1+(??_Print_SystemStatus+4)^080h+0,w
	goto	u4890
	goto	u4891
u4890:
	addwf	(??_Print_SystemStatus+0)^080h+1,f
u4891:
	movf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	2+(??_Print_SystemStatus+4)^080h+0,w
	goto	u4892
	goto	u4893
u4892:
	addwf	(??_Print_SystemStatus+0)^080h+2,f
u4893:
	movf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incf	3+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@bat_mv_long)^080h

	line	393
	
l4206:	
	movlw	low(((STR_10)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	394
	
l4208:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	395
	
l4210:	
	movlw	low(((STR_11)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	402
	
l4212:	
	movlw	low(020h)
	fcall	_uart_send_char
	line	403
	goto	l4238
	line	405
	
l4214:	
	movlw	low(((STR_12)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4240
	line	406
	
l4216:	
	movlw	low(((STR_13)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4240
	line	407
	
l4218:	
	movlw	low(((STR_14)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4240
	line	408
	
l4220:	
	movlw	low(((STR_15)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4240
	line	409
	
l4222:	
	movlw	low(((STR_16)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4240
	line	410
	
l4224:	
	movlw	low(((STR_17)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4240
	line	411
	
l4226:	
	movlw	low(((STR_18)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4240
	line	412
	
l4228:	
	movlw	low(((STR_19)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4240
	line	413
	
l4230:	
	movlw	low(((STR_20)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4240
	line	414
	
l4232:	
	movlw	low(((STR_21)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4240
	line	415
	
l4234:	
	movlw	low(((STR_22)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l4240
	line	403
	
l4238:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@s)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l4214
	xorlw	1^0	; case 1
	skipnz
	goto	l4216
	xorlw	2^1	; case 2
	skipnz
	goto	l4218
	xorlw	3^2	; case 3
	skipnz
	goto	l4220
	xorlw	4^3	; case 4
	skipnz
	goto	l4222
	xorlw	5^4	; case 5
	skipnz
	goto	l4224
	xorlw	6^5	; case 6
	skipnz
	goto	l4226
	xorlw	7^6	; case 7
	skipnz
	goto	l4228
	xorlw	8^7	; case 8
	skipnz
	goto	l4230
	xorlw	9^8	; case 9
	skipnz
	goto	l4232
	goto	l4234
	opt asmopt_pop

	line	362
	
l4240:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(Print_SystemStatus@i)^080h,f
	
l4242:	
	movf	((Print_SystemStatus@i)^080h),w
	btfsc	status,2
	goto	u4901
	goto	u4900
u4901:
	goto	l4172
u4900:
	line	418
	
l4244:	
	movlw	low(((STR_23)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	419
	
l440:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 314 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	314
global __ptext5
__ptext5:	;psect for function _Print_NtcTemp
psect	text5
	file	"main.c"
	line	314
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	316
	
l4124:	
	movlw	low(((STR_1)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	317
	
l4126:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$739+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$739)
	
l4128:	
	movf	(_Print_NtcTemp$739+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$739),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	318
	
l4130:	
	movlw	low(((STR_2)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	319
	
l4132:	
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	movwf	(_Print_NtcTemp$740+1)
	movf	(0+(?___lwmod)),w
	movwf	(_Print_NtcTemp$740)
	movf	(_Print_NtcTemp$740+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$740),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	320
	
l4134:	
	movlw	low(((STR_3)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	321
	
l409:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_Print_DetectLog

;; *************** function _Print_DetectLog *****************
;; Defined at:
;;		line 425 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	line	425
global __ptext6
__ptext6:	;psect for function _Print_DetectLog
psect	text6
	file	"main.c"
	line	425
	global	__size_of_Print_DetectLog
	__size_of_Print_DetectLog	equ	__end_of_Print_DetectLog-_Print_DetectLog
	
_Print_DetectLog:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_DetectLog: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	427
	
l4246:	
	movlw	low(042h)
	fcall	_uart_send_char
	line	428
	
l4248:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_detectLogSlot),w	;volatile
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	430
	
l4250:	
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u4911
	goto	u4910
u4911:
	goto	l4254
u4910:
	line	431
	
l4252:	
	movlw	low(((STR_24)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l446
	line	432
	
l4254:	
		movlw	3
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u4921
	goto	u4920
u4921:
	goto	l446
u4920:
	line	433
	
l4256:	
	movlw	low(((STR_25)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	434
	
l446:	
	return
	opt stack 0
GLOBAL	__end_of_Print_DetectLog
	__end_of_Print_DetectLog:
	signat	_Print_DetectLog,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2   23[BANK0 ] PTR const unsigned char 
;;		 -> STR_33(3), STR_32(7), STR_31(4), STR_30(5), 
;;		 -> STR_29(5), STR_28(11), STR_27(10), STR_26(21), 
;;		 -> STR_25(37), STR_24(33), STR_23(3), STR_22(6), 
;;		 -> STR_21(8), STR_20(6), STR_19(6), STR_18(7), 
;;		 -> STR_17(5), STR_16(5), STR_15(6), STR_14(6), 
;;		 -> STR_13(6), STR_12(7), STR_11(4), STR_10(6), 
;;		 -> STR_9(6), STR_8(4), STR_7(2), STR_6(6), 
;;		 -> STR_5(5), STR_4(29), STR_3(4), STR_2(2), 
;;		 -> STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	file	"uart_dbg.c"
	line	61
global __ptext7
__ptext7:	;psect for function _uart_send_string
psect	text7
	file	"uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l3732:	
	goto	l3738
	line	65
	
l3734:	
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	fcall	_uart_send_char
	
l3736:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(uart_send_string@str),f
	skipnz
	incf	(uart_send_string@str+1),f
	line	66
# 66 "uart_dbg.c"
clrwdt ;# 
psect	text7
	line	63
	
l3738:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u4191
	goto	u4190
u4191:
	goto	l3734
u4190:
	line	68
	
l505:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2   27[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6   29[BANK0 ] unsigned char [6]
;;  j               1   36[BANK0 ] unsigned char 
;;  i               1   35[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      10       0       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext8
__ptext8:	;psect for function _uart_send_number
psect	text8
	file	"uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l3740:	
	clrf	(uart_send_number@i)
	line	84
	
l3742:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u4201
	goto	u4200
u4201:
	goto	l3754
u4200:
	line	86
	
l3744:	
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l509
	line	93
	
l3748:	
	movf	(uart_send_number@i),w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwmod@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank0
	movwf	indf
	
l3750:	
	incf	(uart_send_number@i),f
	line	94
	
l3752:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(uart_send_number@num+1)
	movf	(0+(?___lwdiv)),w
	movwf	(uart_send_number@num)
	line	91
	
l3754:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u4211
	goto	u4210
u4211:
	goto	l3748
u4210:
	line	98
	
l3756:	
	movf	(uart_send_number@i),w
	movwf	(uart_send_number@j)
	
l3758:	
	movf	((uart_send_number@j)),w
	btfss	status,2
	goto	u4221
	goto	u4220
u4221:
	goto	l3762
u4220:
	goto	l509
	line	99
	
l3762:	
	movf	(uart_send_number@j),w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l3764:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decf	(uart_send_number@j),f
	goto	l3758
	line	100
	
l509:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1   21[BANK0 ] unsigned char 
;;  i               1   22[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext9
__ptext9:	;psect for function _uart_send_char
psect	text9
	file	"uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_char: [wreg+status,2+status,0]
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_char@c)
	line	38
	
l3578:	
	bcf	(95/8),(95)&7	;volatile
	line	39
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l3580:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u5557:
decfsz	(??_uart_send_char+0)+0,f
	goto	u5557
	nop2
opt asmopt_pop

	line	41
	
l3582:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(uart_send_char@i)
	line	42
	
l495:	
	line	43
	btfss	(uart_send_char@c),(0)&7
	goto	u3911
	goto	u3910
u3911:
	goto	l497
u3910:
	line	44
	
l3588:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l3590
	line	45
	
l497:	
	line	46
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l3590:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u5567:
decfsz	(??_uart_send_char+0)+0,f
	goto	u5567
	nop2
opt asmopt_pop

	line	48
	
l3592:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rrf	(uart_send_char@c),f
	line	41
	
l3594:	
	incf	(uart_send_char@i),f
	
l3596:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u3921
	goto	u3920
u3921:
	goto	l495
u3920:
	
l496:	
	line	50
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l3598:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u5577:
decfsz	(??_uart_send_char+0)+0,f
	goto	u5577
	nop2
opt asmopt_pop

	line	52
	
l3600:	
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l499:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   20[BANK0 ] unsigned int 
;;  dividend        2   22[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1   24[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   20[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       5       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext10
__ptext10:	;psect for function ___lwmod
psect	text10
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l3666:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u4041
	goto	u4040
u4041:
	goto	l3682
u4040:
	line	14
	
l3668:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l3672
	line	16
	
l3670:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l3672:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u4051
	goto	u4050
u4051:
	goto	l3670
u4050:
	line	20
	
l3674:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u4065
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u4065:
	skipc
	goto	u4061
	goto	u4060
u4061:
	goto	l3678
u4060:
	line	21
	
l3676:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l3678:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l3680:	
	decfsz	(___lwmod@counter),f
	goto	u4071
	goto	u4070
u4071:
	goto	l3674
u4070:
	line	25
	
l3682:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1093:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	_Do_NtcRead

;; *************** function _Do_NtcRead *****************
;; Defined at:
;;		line 302 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Read_Temperature
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	302
global __ptext11
__ptext11:	;psect for function _Do_NtcRead
psect	text11
	file	"main.c"
	line	302
	global	__size_of_Do_NtcRead
	__size_of_Do_NtcRead	equ	__end_of_Do_NtcRead-_Do_NtcRead
	
_Do_NtcRead:	
;incstack = 0
	opt	stack 2
; Regs used in _Do_NtcRead: [wreg+status,2+status,0+pclath+cstack]
	line	306
	
l4122:	
	fcall	_Read_Temperature
	line	308
	
l406:	
	return
	opt stack 0
GLOBAL	__end_of_Do_NtcRead
	__end_of_Do_NtcRead:
	signat	_Do_NtcRead,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 40 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4    9[BANK1 ] unsigned long 
;;  temp_x10        2   15[BANK1 ] unsigned int 
;;  ntcVal          2   13[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   60[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Do_NtcRead
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	40
global __ptext12
__ptext12:	;psect for function _Read_Temperature
psect	text12
	file	"charge_mgr.c"
	line	40
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 2
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	46
	
l3694:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	47
	
l3696:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u4081
	goto	u4080
u4081:
	goto	l3700
u4080:
	goto	l530
	line	50
	
l3700:	
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal)^080h
	line	53
	movlw	0
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u4091
	goto	u4090
u4091:
	goto	l530
u4090:
	
l3702:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u4101
	goto	u4100
u4101:
	goto	l3704
u4100:
	goto	l530
	line	60
	
l3704:	
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	010h
	movwf	(___lldiv@divisor+1)
	movlw	0
	movwf	(___lldiv@divisor)

	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0)
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0+1)
	clrf	((??_Read_Temperature+0)^080h+0+2)
	clrf	((??_Read_Temperature+0)^080h+0+3)
	movf	0+(??_Read_Temperature+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lldiv@divisor),f
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)^080h+0,w
	goto	u4115
	goto	u4116
u4115:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lldiv@divisor+1),f
u4116:
	bsf	status, 5	;RP0=1, select bank1
	movf	2+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)^080h+0,w
	goto	u4117
	goto	u4118
u4117:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lldiv@divisor+2),f
u4118:
	bsf	status, 5	;RP0=1, select bank1
	movf	3+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)^080h+0,w
	goto	u4119
	goto	u4110
u4119:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lldiv@divisor+3),f
u4110:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 5	;RP0=0, select bank0

	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@ntcVal)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@ntcVal+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	027h
	movwf	(___lmul@multiplicand+1)
	movlw	010h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@rt+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@rt+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@rt+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@rt)^080h

	line	64
	
l3706:	
		movf	(Read_Temperature@rt+3)^080h,w
	btfss	status,2
	goto	u4120
	movf	(Read_Temperature@rt+2)^080h,w
	btfss	status,2
	goto	u4120
	movlw	39
	subwf	(Read_Temperature@rt+1)^080h,w
	skipz
	goto	u4123
	movlw	16
	subwf	(Read_Temperature@rt)^080h,w
	skipz
	goto	u4123
u4123:
	btfss	status,0
	goto	u4121
	goto	u4120

u4121:
	goto	l3712
u4120:
	line	65
	
l3708:	
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l3710:	
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0F0h
	bsf	status, 5	;RP0=1, select bank1
	movwf	((??_Read_Temperature+0)^080h+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)^080h+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+3)
	movf	(Read_Temperature@rt)^080h,w
	addwf	(??_Read_Temperature+0)^080h+0,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+1)^080h,w
	goto	u4130
	goto	u4131
u4130:
	addwf	(??_Read_Temperature+0)^080h+1,f
u4131:
	movf	(Read_Temperature@rt+2)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+2)^080h,w
	goto	u4132
	goto	u4133
u4132:
	addwf	(??_Read_Temperature+0)^080h+2,f
u4133:
	movf	(Read_Temperature@rt+3)^080h,w
	skipnc
	incf	(Read_Temperature@rt+3)^080h,w
	addwf	(??_Read_Temperature+0)^080h+3,f
	movf	3+(??_Read_Temperature+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	2+(??_Read_Temperature+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(??_Read_Temperature+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(??_Read_Temperature+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Read_Temperature@temp_x10)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	skipc
	decf	(Read_Temperature@temp_x10+1)^080h,f
	subwf	(Read_Temperature@temp_x10+1)^080h,f
	goto	l3716
	line	67
	
l3712:	
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0
	movwf	(___lmul@multiplier+3)
	movlw	0
	movwf	(___lmul@multiplier+2)
	movlw	027h
	movwf	(___lmul@multiplier+1)
	movlw	010h
	movwf	(___lmul@multiplier)

	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@rt)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lmul@multiplier),f
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@rt+1)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+1)^080h,w
	goto	u4145
	goto	u4146
u4145:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lmul@multiplier+1),f
u4146:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@rt+2)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+2)^080h,w
	goto	u4147
	goto	u4148
u4147:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lmul@multiplier+2),f
u4148:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@rt+3)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+3)^080h,w
	goto	u4149
	goto	u4140
u4149:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(___lmul@multiplier+3),f
u4140:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 5	;RP0=0, select bank0

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@temp_x10+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@temp_x10)^080h
	
l3714:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10)^080h,f
	skipnc
	incf	(Read_Temperature@temp_x10+1)^080h,f
	line	70
	
l3716:	
	movlw	0
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipnc
	goto	u4151
	goto	u4150
u4151:
	goto	l536
u4150:
	
l3718:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l536:	
	line	71
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipc
	goto	u4161
	goto	u4160
u4161:
	goto	l537
u4160:
	
l3720:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)^080h
	movlw	02h
	movwf	((Read_Temperature@temp_x10)^080h)+1
	
l537:	
	line	74
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature)
	line	77
	
l3722:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u4171
	goto	u4170
u4171:
	goto	l3726
u4170:
	line	78
	
l3724:	
	clrf	(_g_tempProtect)
	incf	(_g_tempProtect),f
	goto	l530
	line	79
	
l3726:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u4181
	goto	u4180
u4181:
	goto	l530
u4180:
	line	80
	
l3728:	
	clrf	(_g_tempProtect)
	line	83
	
l530:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   20[BANK0 ] unsigned int 
;;  dividend        2   22[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2   25[BANK0 ] unsigned int 
;;  counter         1   24[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   20[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       7       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext13
__ptext13:	;psect for function ___lwdiv
psect	text13
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l3640:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l3642:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u4001
	goto	u4000
u4001:
	goto	l3662
u4000:
	line	16
	
l3644:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l3648
	line	18
	
l3646:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l3648:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u4011
	goto	u4010
u4011:
	goto	l3646
u4010:
	line	22
	
l3650:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l3652:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u4025
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u4025:
	skipc
	goto	u4021
	goto	u4020
u4021:
	goto	l3658
u4020:
	line	24
	
l3654:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l3656:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l3658:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l3660:	
	decfsz	(___lwdiv@counter),f
	goto	u4031
	goto	u4030
u4031:
	goto	l3650
u4030:
	line	30
	
l3662:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l1083:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4   20[BANK0 ] unsigned long 
;;  multiplicand    4   24[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4   28[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4   20[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext14
__ptext14:	;psect for function ___lmul
psect	text14
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l3602:	
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l755:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u3931
	goto	u3930
u3931:
	goto	l3606
u3930:
	line	122
	
l3604:	
	movf	(___lmul@multiplicand),w
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3941
	addwf	(___lmul@product+1),f
u3941:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3942
	addwf	(___lmul@product+2),f
u3942:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3943
	addwf	(___lmul@product+3),f
u3943:

	line	123
	
l3606:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l3608:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u3951
	goto	u3950
u3951:
	goto	l755
u3950:
	line	128
	
l3610:	
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l758:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4   32[BANK0 ] unsigned long 
;;  dividend        4   36[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4    0[BANK1 ] unsigned long 
;;  counter         1    4[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4   32[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       0       5       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       8       5       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext15
__ptext15:	;psect for function ___lldiv
psect	text15
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l3614:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___lldiv@quotient)^080h
	clrf	(___lldiv@quotient+1)^080h
	clrf	(___lldiv@quotient+2)^080h
	clrf	(___lldiv@quotient+3)^080h
	line	15
	
l3616:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u3961
	goto	u3960
u3961:
	goto	l3636
u3960:
	line	16
	
l3618:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___lldiv@counter)^080h
	incf	(___lldiv@counter)^080h,f
	line	17
	goto	l3622
	line	18
	
l3620:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	bsf	status, 5	;RP0=1, select bank1
	incf	(___lldiv@counter)^080h,f
	line	17
	
l3622:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u3971
	goto	u3970
u3971:
	goto	l3620
u3970:
	line	22
	
l3624:	
	clrc
	bsf	status, 5	;RP0=1, select bank1
	rlf	(___lldiv@quotient)^080h,f
	rlf	(___lldiv@quotient+1)^080h,f
	rlf	(___lldiv@quotient+2)^080h,f
	rlf	(___lldiv@quotient+3)^080h,f
	line	23
	
l3626:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u3985
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u3985
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u3985
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u3985:
	skipc
	goto	u3981
	goto	u3980
u3981:
	goto	l3632
u3980:
	line	24
	
l3628:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l3630:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(___lldiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l3632:	
	clrc
	bcf	status, 5	;RP0=0, select bank0
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l3634:	
	bsf	status, 5	;RP0=1, select bank1
	decfsz	(___lldiv@counter)^080h,f
	goto	u3991
	goto	u3990
u3991:
	goto	l3624
u3990:
	line	30
	
l3636:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lldiv@quotient+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lldiv+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lldiv@quotient+2)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lldiv+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lldiv@quotient+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lldiv+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lldiv@quotient)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lldiv)

	line	31
	
l1030:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_Do_AdcSample

;; *************** function _Do_AdcSample *****************
;; Defined at:
;;		line 276 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  ch              1   38[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	276
global __ptext16
__ptext16:	;psect for function _Do_AdcSample
psect	text16
	file	"main.c"
	line	276
	global	__size_of_Do_AdcSample
	__size_of_Do_AdcSample	equ	__end_of_Do_AdcSample-_Do_AdcSample
	
_Do_AdcSample:	
;incstack = 0
	opt	stack 3
; Regs used in _Do_AdcSample: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	278
	
l4102:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_scanIndex),w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(Do_AdcSample@ch)
	line	279
	
l4104:	
	clrf	(ADC_Sample@adldo)
	movf	(Do_AdcSample@ch),w
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	282
	
l4106:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u4791
	goto	u4790
u4791:
	goto	l4114
u4790:
	line	284
	
l4108:	
	movlw	low(06h)
	subwf	(_g_scanIndex),w	;volatile
	skipnc
	goto	u4801
	goto	u4800
u4801:
	goto	l4112
u4800:
	
l4110:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	movf	(_adresult),w	;volatile
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(_adresult+1),w	;volatile
	movwf	indf
	goto	l4120
	line	285
	
l4112:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0BBh)&0ffh
	movwf	fsr0
	movf	(_adresult),w	;volatile
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_adresult+1),w	;volatile
	movwf	indf
	goto	l4120
	line	289
	
l4114:	
	movlw	low(06h)
	subwf	(_g_scanIndex),w	;volatile
	skipnc
	goto	u4811
	goto	u4810
u4811:
	goto	l4118
u4810:
	
l4116:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l4120
	line	290
	
l4118:	
	movlw	low(0Ch)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0BBh)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	293
	
l4120:	
	movlw	low(01h)
	movwf	(_g_scanPhase)	;volatile
	line	294
	
l403:	
	return
	opt stack 0
GLOBAL	__end_of_Do_AdcSample
	__end_of_Do_AdcSample:
	signat	_Do_AdcSample,89
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1   20[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1   26[BANK0 ] unsigned char 
;;  j               1   25[BANK0 ] unsigned char 
;;  adsum           4   28[BANK0 ] volatile unsigned long 
;;  ad_temp         2   36[BANK0 ] volatile unsigned int 
;;  admax           2   34[BANK0 ] volatile unsigned int 
;;  admin           2   32[BANK0 ] volatile unsigned int 
;;  i               1   27[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      18       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	49
global __ptext17
__ptext17:	;psect for function _ADC_Sample
psect	text17
	file	"adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
	movwf	(ADC_Sample@adch)
	line	51
	
l3512:	
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	52
	
l3514:	
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	53
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	54
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	58
	
l3516:	
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u3761
	goto	u3760
u3761:
	goto	l3522
u3760:
	
l3518:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u3771
	goto	u3770
u3771:
	goto	l3522
u3770:
	line	60
	
l3520:	
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	61
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u5587:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u5587
	nop
opt asmopt_pop

	line	62
	goto	l3524
	line	64
	
l3522:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	67
	
l3524:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(ADC_Sample@adch),(4)&7
	goto	u3781
	goto	u3780
u3781:
	goto	l474
u3780:
	line	69
	
l3526:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l3528:	
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(ADC_Sample@adch),f
	line	71
	goto	l3530
	line	72
	
l474:	
	line	73
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l3530:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@i)
	line	79
	
l3536:	
	movf	(ADC_Sample@adch),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u3795:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u3795
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l3538:	
	opt asmopt_push
opt asmopt_off
	movlw	5
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u5597:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u5597
	nop2
opt asmopt_pop

	line	81
	
l3540:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l3542:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	85
	goto	l478
	
l479:	
	line	87
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u3801
	goto	u3800
u3801:
	goto	l478
u3800:
	line	89
	
l3544:	
	movlw	low(0)
	goto	l481
	line	90
	
l478:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u3811
	goto	u3810
u3811:
	goto	l479
u3810:
	line	93
	
l3548:	
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
l3550:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
l3552:	
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u3821
	goto	u3820
u3821:
	goto	l3556
u3820:
	line	98
	
l3554:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	99
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	100
	goto	l484
	line	102
	
l3556:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u3835
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u3835:
	skipnc
	goto	u3831
	goto	u3830
u3831:
	goto	l3560
u3830:
	line	103
	
l3558:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	l484
	line	105
	
l3560:	
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u3845
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u3845:
	skipnc
	goto	u3841
	goto	u3840
u3841:
	goto	l484
u3840:
	line	106
	
l3562:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	108
	
l484:	
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3851
	addwf	(ADC_Sample@adsum+1),f	;volatile
u3851:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3852
	addwf	(ADC_Sample@adsum+2),f	;volatile
u3852:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3853
	addwf	(ADC_Sample@adsum+3),f	;volatile
u3853:

	line	76
	
l3564:	
	incf	(ADC_Sample@i),f
	
l3566:	
	movlw	low(022h)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u3861
	goto	u3860
u3861:
	goto	l3536
u3860:
	line	112
	
l3568:	
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u3875
	goto	u3876
u3875:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u3876:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u3877
	goto	u3878
u3877:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u3878:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u3879
	goto	u3870
u3879:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u3870:

	line	113
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u3885
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u3885
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u3885
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u3885:
	skipc
	goto	u3881
	goto	u3880
u3881:
	goto	l488
u3880:
	line	114
	
l3570:	
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u3895
	goto	u3896
u3895:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u3896:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u3897
	goto	u3898
u3897:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u3898:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u3899
	goto	u3890
u3899:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u3890:

	goto	l3572
	line	115
	
l488:	
	line	116
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	118
	
l3572:	
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u3905:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u3900:
	addlw	-1
	skipz
	goto	u3905
	movf	1+(??_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
l3574:	
	movlw	low(0A5h)
	line	120
	
l481:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_ChargeProcess_Slot

;; *************** function _ChargeProcess_Slot *****************
;; Defined at:
;;		line 169 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   14[BANK1 ] unsigned char 
;;  v_now           2   10[BANK1 ] unsigned int 
;;  v_start         2    8[BANK1 ] unsigned int 
;;  rise            2    2[BANK1 ] unsigned int 
;;  v_after         2    6[BANK1 ] unsigned int 
;;  v_before        2    4[BANK1 ] unsigned int 
;;  delta           2    0[BANK1 ] unsigned int 
;;  slot           12   17[BANK1 ] struct .
;;  v               2   15[BANK1 ] unsigned int 
;;  tick            2    0        unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      29       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0       4      29       0       0
;;Total ram usage:       33 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Detect_BatteryType
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	169
global __ptext18
__ptext18:	;psect for function _ChargeProcess_Slot
psect	text18
	file	"charge_mgr.c"
	line	169
	global	__size_of_ChargeProcess_Slot
	__size_of_ChargeProcess_Slot	equ	__end_of_ChargeProcess_Slot-_ChargeProcess_Slot
	
_ChargeProcess_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _ChargeProcess_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@idx)^080h
	line	175
	
l4258:	
	movlw	low(06h)
	subwf	(ChargeProcess_Slot@idx)^080h,w
	skipnc
	goto	u4931
	goto	u4930
u4931:
	goto	l4262
u4930:
	
l4260:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(ChargeProcess_Slot@slot)
	movwf	(??_ChargeProcess_Slot+0)+0
	movlw	12
	movwf	((??_ChargeProcess_Slot+0)+0+1)
u4940:
	
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	((??_ChargeProcess_Slot+0)+0+2)
	incf	fsr,w
	movwf	((??_ChargeProcess_Slot+0)+0+3)
	movf	(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr
	bcf	status, 7	;select IRP bank1
	
	movf	((??_ChargeProcess_Slot+0)+0+2),w
	movwf	indf
	incf	fsr,w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	((??_ChargeProcess_Slot+0)+0+3),w
	movwf	fsr
	decfsz	((??_ChargeProcess_Slot+0)+0+1),f
	goto	u4940
	
	goto	l4264
	line	176
	
l4262:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	fsr0
	movlw	low(ChargeProcess_Slot@slot)
	movwf	(??_ChargeProcess_Slot+0)+0
	movlw	12
	movwf	((??_ChargeProcess_Slot+0)+0+1)
u4950:
	
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	((??_ChargeProcess_Slot+0)+0+2)
	incf	fsr,w
	movwf	((??_ChargeProcess_Slot+0)+0+3)
	movf	(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr
	bcf	status, 7	;select IRP bank1
	
	movf	((??_ChargeProcess_Slot+0)+0+2),w
	movwf	indf
	incf	fsr,w
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	((??_ChargeProcess_Slot+0)+0+3),w
	movwf	fsr
	decfsz	((??_ChargeProcess_Slot+0)+0+1),f
	goto	u4950
	
	line	178
	
l4264:	
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(ChargeProcess_Slot@slot)^080h+03h,w
	movwf	(ChargeProcess_Slot@v+1)^080h
	movf	0+(ChargeProcess_Slot@slot)^080h+03h,w
	movwf	(ChargeProcess_Slot@v)^080h
	line	179
	
l4266:	
	line	181
	goto	l4476
	line	185
	
l4268:	
	clrf	0+(ChargeProcess_Slot@slot)^080h+05h
	clrf	1+(ChargeProcess_Slot@slot)^080h+05h
	line	186
	clrf	0+(ChargeProcess_Slot@slot)^080h+0Ah
	line	187
	
l4270:	
	clrf	0+(ChargeProcess_Slot@slot)^080h+01h
	incf	0+(ChargeProcess_Slot@slot)^080h+01h,f
	line	188
	goto	l4478
	line	192
	
l4272:	
	incf	0+(ChargeProcess_Slot@slot)^080h+05h,f
	skipnz
	incf	1+(ChargeProcess_Slot@slot)^080h+05h,f
	line	193
	movlw	0
	subwf	1+(ChargeProcess_Slot@slot)^080h+05h,w
	movlw	0C8h
	skipnz
	subwf	0+(ChargeProcess_Slot@slot)^080h+05h,w
	skipnc
	goto	u4961
	goto	u4960
u4961:
	goto	l4276
u4960:
	goto	l4478
	line	198
	
l4276:	
	movf	(ChargeProcess_Slot@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Detect_BatteryType@voltage+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@slot)^080h
	line	201
	
l4278:	
		movlw	5
	xorwf	((ChargeProcess_Slot@slot)^080h),w
	btfss	status,2
	goto	u4971
	goto	u4970
u4971:
	goto	l4286
u4970:
	line	203
	
l4280:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_impRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^080h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^080h,w
	movwf	indf
	line	204
	
l4282:	
	movlw	low(08h)
	movwf	0+(ChargeProcess_Slot@slot)^080h+01h
	line	205
	
l4284:	
	clrf	0+(ChargeProcess_Slot@slot)^080h+05h
	clrf	1+(ChargeProcess_Slot@slot)^080h+05h
	line	206
	goto	l4326
	line	210
	
l4286:	
		movlw	2
	xorwf	((ChargeProcess_Slot@slot)^080h),w
	btfsc	status,2
	goto	u4981
	goto	u4980
u4981:
	goto	l4292
u4980:
	
l4288:	
		movlw	3
	xorwf	((ChargeProcess_Slot@slot)^080h),w
	btfsc	status,2
	goto	u4991
	goto	u4990
u4991:
	goto	l4292
u4990:
	
l4290:	
	movf	((ChargeProcess_Slot@slot)^080h),w
	btfss	status,2
	goto	u5001
	goto	u5000
u5001:
	goto	l4302
u5000:
	line	212
	
l4292:	
	movlw	low(07h)
	movwf	0+(ChargeProcess_Slot@slot)^080h+01h
	line	214
	
l4294:	
		movlw	2
	xorwf	((ChargeProcess_Slot@slot)^080h),w
	btfsc	status,2
	goto	u5011
	goto	u5010
u5011:
	goto	l4298
u5010:
	
l4296:	
		movlw	3
	xorwf	((ChargeProcess_Slot@slot)^080h),w
	btfss	status,2
	goto	u5021
	goto	u5020
u5021:
	goto	l4326
u5020:
	line	216
	
l4298:	
	movf	(ChargeProcess_Slot@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	217
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@slot)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_detectLogType)	;volatile
	line	218
	
l4300:	
	bsf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	goto	l4326
	line	225
	
l4302:	
	movlw	09h
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	036h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipnc
	goto	u5031
	goto	u5030
u5031:
	goto	l4310
u5030:
	line	227
	
l4304:	
	movlw	low(02h)
	movwf	0+(ChargeProcess_Slot@slot)^080h+01h
	line	228
	
l4306:	
	clrf	0+(ChargeProcess_Slot@slot)^080h+05h
	clrf	1+(ChargeProcess_Slot@slot)^080h+05h
	line	229
	
l4308:	
	clrf	0+(ChargeProcess_Slot@slot)^080h+0Bh
	line	230
	goto	l4326
	line	232
	
l4310:	
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	050h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipnc
	goto	u5041
	goto	u5040
u5041:
	goto	l4316
u5040:
	line	234
	
l4312:	
	movlw	low(03h)
	movwf	0+(ChargeProcess_Slot@slot)^080h+01h
	goto	l4284
	line	238
	
l4316:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	021h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5051
	goto	u5050
u5051:
	goto	l4322
u5050:
	line	240
	
l4318:	
	movlw	low(05h)
	movwf	0+(ChargeProcess_Slot@slot)^080h+01h
	goto	l4284
	line	246
	
l4322:	
	movlw	low(04h)
	movwf	0+(ChargeProcess_Slot@slot)^080h+01h
	goto	l4284
	line	252
	
l4326:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_dbgSlot)	;volatile
	line	253
	
l4328:	
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(ChargeProcess_Slot@slot)^080h+01h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_dbgNewState)	;volatile
	line	254
	
l4330:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@slot)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_dbgNewType)	;volatile
	line	255
	
l4332:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@v+1)^080h,w
	movwf	(_g_dbgVoltage+1)^080h	;volatile
	movf	(ChargeProcess_Slot@v)^080h,w
	movwf	(_g_dbgVoltage)^080h	;volatile
	line	256
	
l4334:	
	bsf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	257
	goto	l4478
	line	267
	
l4336:	
	movlw	0Fh
	subwf	1+(ChargeProcess_Slot@slot)^080h+03h,w
	movlw	096h
	skipnz
	subwf	0+(ChargeProcess_Slot@slot)^080h+03h,w
	skipc
	goto	u5061
	goto	u5060
u5061:
	goto	l4340
u5060:
	line	269
	
l4338:	
	clrf	(ChargeProcess_Slot@slot)^080h
	line	270
	clrf	0+(ChargeProcess_Slot@slot)^080h+01h
	line	271
	goto	l4478
	line	273
	
l4340:	
	incf	0+(ChargeProcess_Slot@slot)^080h+05h,f
	skipnz
	incf	1+(ChargeProcess_Slot@slot)^080h+05h,f
	line	274
	movlw	0
	subwf	1+(ChargeProcess_Slot@slot)^080h+05h,w
	movlw	03h
	skipnz
	subwf	0+(ChargeProcess_Slot@slot)^080h+05h,w
	skipnc
	goto	u5071
	goto	u5070
u5071:
	goto	l4344
u5070:
	goto	l4478
	line	279
	
l4344:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_impRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_before)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_before+1)^080h
	line	280
	
l4346:	
	movf	1+(ChargeProcess_Slot@slot)^080h+03h,w
	movwf	(ChargeProcess_Slot@v_after+1)^080h
	movf	0+(ChargeProcess_Slot@slot)^080h+03h,w
	movwf	(ChargeProcess_Slot@v_after)^080h
	line	284
	
l4348:	
	movf	(ChargeProcess_Slot@v_before+1)^080h,w
	subwf	(ChargeProcess_Slot@v_after+1)^080h,w
	skipz
	goto	u5085
	movf	(ChargeProcess_Slot@v_before)^080h,w
	subwf	(ChargeProcess_Slot@v_after)^080h,w
u5085:
	skipnc
	goto	u5081
	goto	u5080
u5081:
	goto	l4352
u5080:
	line	285
	
l4350:	
	movf	(ChargeProcess_Slot@v_before+1)^080h,w
	movwf	(ChargeProcess_Slot@delta+1)^080h
	movf	(ChargeProcess_Slot@v_before)^080h,w
	movwf	(ChargeProcess_Slot@delta)^080h
	movf	(ChargeProcess_Slot@v_after)^080h,w
	subwf	(ChargeProcess_Slot@delta)^080h,f
	movf	(ChargeProcess_Slot@v_after+1)^080h,w
	skipc
	decf	(ChargeProcess_Slot@delta+1)^080h,f
	subwf	(ChargeProcess_Slot@delta+1)^080h,f
	goto	l4354
	line	287
	
l4352:	
	clrf	(ChargeProcess_Slot@delta)^080h
	clrf	(ChargeProcess_Slot@delta+1)^080h
	line	289
	
l4354:	
	movlw	0
	subwf	(ChargeProcess_Slot@delta+1)^080h,w
	movlw	051h
	skipnz
	subwf	(ChargeProcess_Slot@delta)^080h,w
	skipc
	goto	u5091
	goto	u5090
u5091:
	goto	l4360
u5090:
	line	292
	
l4356:	
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@slot)^080h
	line	293
	movlw	low(07h)
	movwf	0+(ChargeProcess_Slot@slot)^080h+01h
	line	294
	movf	(ChargeProcess_Slot@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	295
	movlw	low(03h)
	movwf	(_g_detectLogType)	;volatile
	line	296
	
l4358:	
	bsf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	line	297
	goto	l4478
	line	301
	
l4360:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_impRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	0+(ChargeProcess_Slot@slot)^080h+03h,w
	movwf	indf
	incf	fsr0,f
	movf	1+(ChargeProcess_Slot@slot)^080h+03h,w
	movwf	indf
	line	302
	
l4362:	
	movlw	low(09h)
	movwf	0+(ChargeProcess_Slot@slot)^080h+01h
	line	303
	
l4364:	
	clrf	0+(ChargeProcess_Slot@slot)^080h+05h
	clrf	1+(ChargeProcess_Slot@slot)^080h+05h
	goto	l4478
	line	313
	
l4366:	
	movlw	0Fh
	subwf	1+(ChargeProcess_Slot@slot)^080h+03h,w
	movlw	096h
	skipnz
	subwf	0+(ChargeProcess_Slot@slot)^080h+03h,w
	skipc
	goto	u5101
	goto	u5100
u5101:
	goto	l4370
u5100:
	goto	l4338
	line	319
	
l4370:	
	incf	0+(ChargeProcess_Slot@slot)^080h+05h,f
	skipnz
	incf	1+(ChargeProcess_Slot@slot)^080h+05h,f
	line	320
	movlw	0Bh
	subwf	1+(ChargeProcess_Slot@slot)^080h+05h,w
	movlw	0B8h
	skipnz
	subwf	0+(ChargeProcess_Slot@slot)^080h+05h,w
	skipnc
	goto	u5111
	goto	u5110
u5111:
	goto	l4380
u5110:
	line	323
	
l4372:	
	movlw	0Ch
	subwf	1+(ChargeProcess_Slot@slot)^080h+03h,w
	movlw	085h
	skipnz
	subwf	0+(ChargeProcess_Slot@slot)^080h+03h,w
	skipc
	goto	u5121
	goto	u5120
u5121:
	goto	l4478
u5120:
	line	325
	
l4374:	
	clrf	(ChargeProcess_Slot@slot)^080h
	incf	(ChargeProcess_Slot@slot)^080h,f
	line	326
	
l4376:	
	movlw	low(04h)
	movwf	0+(ChargeProcess_Slot@slot)^080h+01h
	goto	l4364
	line	334
	
l4380:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^080h,w
	addlw	low(_g_impRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_start)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_start+1)^080h
	line	335
	
l4382:	
	movf	1+(ChargeProcess_Slot@slot)^080h+03h,w
	movwf	(ChargeProcess_Slot@v_now+1)^080h
	movf	0+(ChargeProcess_Slot@slot)^080h+03h,w
	movwf	(ChargeProcess_Slot@v_now)^080h
	line	338
	
l4384:	
	movf	(ChargeProcess_Slot@v_now+1)^080h,w
	subwf	(ChargeProcess_Slot@v_start+1)^080h,w
	skipz
	goto	u5135
	movf	(ChargeProcess_Slot@v_now)^080h,w
	subwf	(ChargeProcess_Slot@v_start)^080h,w
u5135:
	skipnc
	goto	u5131
	goto	u5130
u5131:
	goto	l4388
u5130:
	line	339
	
l4386:	
	movf	(ChargeProcess_Slot@v_now+1)^080h,w
	movwf	(ChargeProcess_Slot@rise+1)^080h
	movf	(ChargeProcess_Slot@v_now)^080h,w
	movwf	(ChargeProcess_Slot@rise)^080h
	movf	(ChargeProcess_Slot@v_start)^080h,w
	subwf	(ChargeProcess_Slot@rise)^080h,f
	movf	(ChargeProcess_Slot@v_start+1)^080h,w
	skipc
	decf	(ChargeProcess_Slot@rise+1)^080h,f
	subwf	(ChargeProcess_Slot@rise+1)^080h,f
	goto	l4390
	line	341
	
l4388:	
	clrf	(ChargeProcess_Slot@rise)^080h
	clrf	(ChargeProcess_Slot@rise+1)^080h
	line	344
	
l4390:	
	movlw	0
	subwf	(ChargeProcess_Slot@rise+1)^080h,w
	movlw	014h
	skipnz
	subwf	(ChargeProcess_Slot@rise)^080h,w
	skipc
	goto	u5141
	goto	u5140
u5141:
	goto	l4400
u5140:
	
l4392:	
	movlw	0Ch
	subwf	(ChargeProcess_Slot@v_now+1)^080h,w
	movlw	085h
	skipnz
	subwf	(ChargeProcess_Slot@v_now)^080h,w
	skipc
	goto	u5151
	goto	u5150
u5151:
	goto	l4400
u5150:
	goto	l4374
	line	353
	
l4400:	
	movlw	low(02h)
	movwf	(ChargeProcess_Slot@slot)^080h
	line	354
	movlw	low(07h)
	movwf	0+(ChargeProcess_Slot@slot)^080h+01h
	line	355
	movf	(ChargeProcess_Slot@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	356
	movlw	low(02h)
	movwf	(_g_detectLogType)	;volatile
	goto	l4358
	line	365
	
l4404:	
	incf	0+(ChargeProcess_Slot@slot)^080h+05h,f
	skipnz
	incf	1+(ChargeProcess_Slot@slot)^080h+05h,f
	line	367
	movlw	017h
	subwf	1+(ChargeProcess_Slot@slot)^080h+05h,w
	movlw	071h
	skipnz
	subwf	0+(ChargeProcess_Slot@slot)^080h+05h,w
	skipc
	goto	u5161
	goto	u5160
u5161:
	goto	l4408
u5160:
	line	369
	
l4406:	
	movlw	low(07h)
	movwf	0+(ChargeProcess_Slot@slot)^080h+01h
	line	370
	goto	l4478
	line	373
	
l4408:	
	movlw	09h
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	036h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5171
	goto	u5170
u5171:
	goto	l4414
u5170:
	line	375
	
l4410:	
	movlw	low(03h)
	movwf	0+(ChargeProcess_Slot@slot)^080h+01h
	goto	l4364
	line	380
	
l4414:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	05Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5181
	goto	u5180
u5181:
	goto	l4478
u5180:
	goto	l4406
	line	389
	
l4418:	
	incf	0+(ChargeProcess_Slot@slot)^080h+05h,f
	skipnz
	incf	1+(ChargeProcess_Slot@slot)^080h+05h,f
	line	391
	movlw	075h
	subwf	1+(ChargeProcess_Slot@slot)^080h+05h,w
	movlw	031h
	skipnz
	subwf	0+(ChargeProcess_Slot@slot)^080h+05h,w
	skipc
	goto	u5191
	goto	u5190
u5191:
	goto	l4422
u5190:
	goto	l4406
	line	397
	
l4422:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	05Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5201
	goto	u5200
u5201:
	goto	l4426
u5200:
	goto	l4406
	line	403
	
l4426:	
	movlw	0Bh
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	0B1h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5211
	goto	u5210
u5211:
	goto	l4478
u5210:
	goto	l4376
	line	412
	
l4432:	
	incf	0+(ChargeProcess_Slot@slot)^080h+05h,f
	skipnz
	incf	1+(ChargeProcess_Slot@slot)^080h+05h,f
	line	420
	
l4436:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	05Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5221
	goto	u5220
u5221:
	goto	l4440
u5220:
	goto	l4406
	line	426
	
l4440:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	021h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5231
	goto	u5230
u5231:
	goto	l4478
u5230:
	line	428
	
l4442:	
	movlw	low(05h)
	movwf	0+(ChargeProcess_Slot@slot)^080h+01h
	goto	l4364
	line	435
	
l4446:	
	incf	0+(ChargeProcess_Slot@slot)^080h+05h,f
	skipnz
	incf	1+(ChargeProcess_Slot@slot)^080h+05h,f
	line	437
	movlw	0EAh
	subwf	1+(ChargeProcess_Slot@slot)^080h+05h,w
	movlw	061h
	skipnz
	subwf	0+(ChargeProcess_Slot@slot)^080h+05h,w
	skipc
	goto	u5241
	goto	u5240
u5241:
	goto	l4478
u5240:
	line	439
	
l4448:	
	movlw	low(06h)
	movwf	0+(ChargeProcess_Slot@slot)^080h+01h
	goto	l4478
	line	446
	
l4450:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	017h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipnc
	goto	u5251
	goto	u5250
u5251:
	goto	l4478
u5250:
	goto	l4376
	line	456
	
l4456:	
		movlw	2
	xorwf	((ChargeProcess_Slot@slot)^080h),w
	btfsc	status,2
	goto	u5261
	goto	u5260
u5261:
	goto	l4460
u5260:
	
l4458:	
		movlw	3
	xorwf	((ChargeProcess_Slot@slot)^080h),w
	btfss	status,2
	goto	u5271
	goto	u5270
u5271:
	goto	l4464
u5270:
	line	458
	
l4460:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5281
	goto	u5280
u5281:
	goto	l4478
u5280:
	line	461
	
l4462:	
	clrf	(ChargeProcess_Slot@slot)^080h
	line	462
	clrf	0+(ChargeProcess_Slot@slot)^080h+01h
	line	463
	clrf	0+(ChargeProcess_Slot@slot)^080h+05h
	clrf	1+(ChargeProcess_Slot@slot)^080h+05h
	goto	l4478
	line	468
	
l4464:	
	movlw	09h
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	036h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipc
	goto	u5291
	goto	u5290
u5291:
	goto	l4478
u5290:
	
l4466:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^080h,w
	skipnc
	goto	u5301
	goto	u5300
u5301:
	goto	l4478
u5300:
	line	470
	
l4468:	
	clrf	0+(ChargeProcess_Slot@slot)^080h+01h
	incf	0+(ChargeProcess_Slot@slot)^080h+01h,f
	goto	l4364
	line	476
	
l4472:	
	clrf	0+(ChargeProcess_Slot@slot)^080h+01h
	line	477
	goto	l4478
	line	181
	
l4476:	
	movf	0+(ChargeProcess_Slot@slot)^080h+01h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l4268
	xorlw	1^0	; case 1
	skipnz
	goto	l4272
	xorlw	2^1	; case 2
	skipnz
	goto	l4404
	xorlw	3^2	; case 3
	skipnz
	goto	l4418
	xorlw	4^3	; case 4
	skipnz
	goto	l4432
	xorlw	5^4	; case 5
	skipnz
	goto	l4446
	xorlw	6^5	; case 6
	skipnz
	goto	l4450
	xorlw	7^6	; case 7
	skipnz
	goto	l4456
	xorlw	8^7	; case 8
	skipnz
	goto	l4336
	xorlw	9^8	; case 9
	skipnz
	goto	l4366
	goto	l4472
	opt asmopt_pop

	line	481
	
l4478:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ChargeProcess_Slot@idx)^080h,w
	skipnc
	goto	u5311
	goto	u5310
u5311:
	goto	l4482
u5310:
	
l4480:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot0|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(ChargeProcess_Slot@slot)
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	fsr0,w
	movwf	((??_ChargeProcess_Slot+0)+0+1)
	movlw	12
	movwf	((??_ChargeProcess_Slot+0)+0+2)
u5320:
	movf	(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	
	movf	indf,w
	movwf	((??_ChargeProcess_Slot+0)+0+3)
	incf	(??_ChargeProcess_Slot+0)+0,f
	movf	((??_ChargeProcess_Slot+0)+0+1),w
	movwf	fsr0
	
	movf	((??_ChargeProcess_Slot+0)+0+3),w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	((??_ChargeProcess_Slot+0)+0+1),f
	decfsz	((??_ChargeProcess_Slot+0)+0+2),f
	goto	u5320
	
	goto	l619
	line	482
	
l4482:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B8h)&0ffh
	movwf	fsr0
	movlw	low(ChargeProcess_Slot@slot)
	movwf	(??_ChargeProcess_Slot+0)+0
	movf	fsr0,w
	movwf	((??_ChargeProcess_Slot+0)+0+1)
	movlw	12
	movwf	((??_ChargeProcess_Slot+0)+0+2)
u5330:
	movf	(??_ChargeProcess_Slot+0)+0,w
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	
	movf	indf,w
	movwf	((??_ChargeProcess_Slot+0)+0+3)
	incf	(??_ChargeProcess_Slot+0)+0,f
	movf	((??_ChargeProcess_Slot+0)+0+1),w
	movwf	fsr0
	
	movf	((??_ChargeProcess_Slot+0)+0+3),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	((??_ChargeProcess_Slot+0)+0+1),f
	decfsz	((??_ChargeProcess_Slot+0)+0+2),f
	goto	u5330
	
	line	483
	
l619:	
	return
	opt stack 0
GLOBAL	__end_of_ChargeProcess_Slot
	__end_of_ChargeProcess_Slot:
	signat	_ChargeProcess_Slot,4217
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1   20[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1   22[BANK0 ] unsigned char 
;;  product         1   21[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/900
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_main
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;;		_Led_BlinkProcess
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext19
__ptext19:	;psect for function ___bmul
psect	text19
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___bmul: [wreg+status,2+status,0]
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplier)
	line	6
	
l3824:	
	clrf	(___bmul@product)
	line	43
	
l3826:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u4351
	goto	u4350
u4351:
	goto	l3830
u4350:
	line	44
	
l3828:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l3830:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l3832:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u4361
	goto	u4360
u4361:
	goto	l3826
u4360:
	line	50
	
l3834:	
	movf	(___bmul@product),w
	line	51
	
l764:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 103 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2   20[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	103
global __ptext20
__ptext20:	;psect for function _Detect_BatteryType
psect	text20
	file	"charge_mgr.c"
	line	103
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	106
	
l3768:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u4231
	goto	u4230
u4231:
	goto	l3774
u4230:
	line	107
	
l3770:	
	movlw	low(0)
	goto	l544
	line	110
	
l3774:	
	movlw	09h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0Ah
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u4241
	goto	u4240
u4241:
	goto	l3780
u4240:
	goto	l3770
	line	116
	
l3780:	
	movlw	0Bh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u4251
	goto	u4250
u4251:
	goto	l3788
u4250:
	
l3782:	
	movlw	0Ch
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	085h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u4261
	goto	u4260
u4261:
	goto	l3788
u4260:
	line	117
	
l3784:	
	movlw	low(05h)
	goto	l544
	line	121
	
l3788:	
	movlw	0Ah
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	050h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u4271
	goto	u4270
u4271:
	goto	l3796
u4270:
	
l3790:	
	movlw	0Dh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	022h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u4281
	goto	u4280
u4281:
	goto	l3796
u4280:
	line	122
	
l3792:	
	movlw	low(01h)
	goto	l544
	line	125
	
l3796:	
	movlw	0Dh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	022h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u4291
	goto	u4290
u4291:
	goto	l3804
u4290:
	
l3798:	
	movlw	0Dh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	05Ah
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u4301
	goto	u4300
u4301:
	goto	l3804
u4300:
	goto	l3792
	line	129
	
l3804:	
	movlw	0Dh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	05Ah
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u4311
	goto	u4310
u4311:
	goto	l3812
u4310:
	
l3806:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u4321
	goto	u4320
u4321:
	goto	l3812
u4320:
	goto	l3792
	line	133
	
l3812:	
	movlw	09h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0Ah
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u4331
	goto	u4330
u4331:
	goto	l3770
u4330:
	
l3814:	
	movlw	0Ah
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	050h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u4341
	goto	u4340
u4341:
	goto	l3770
u4340:
	goto	l3792
	line	138
	
l544:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 167 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_CCCV_Control
;;		_Charging_Control
;;		_Led_BlinkProcess
;;		_PowerOnLedSequence
;;		_Update_LED_Slot
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	167
global __ptext21
__ptext21:	;psect for function _Isr_Timer
psect	text21
	file	"main.c"
	line	167
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 2
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	movf	btemp+1,w
	movwf	(??_Isr_Timer+3)
	ljmp	_Isr_Timer
psect	text21
	line	170
	
i1l4484:	
	btfss	(90/8),(90)&7	;volatile
	goto	u534_21
	goto	u534_20
u534_21:
	goto	i1l363
u534_20:
	line	172
	
i1l4486:	
	bcf	(90/8),(90)&7	;volatile
	line	173
	
i1l4488:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	174
# 174 "main.c"
clrwdt ;# 
psect	text21
	line	177
	
i1l4490:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	178
	
i1l4492:	
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u535_21
	goto	u535_20
u535_21:
	goto	i1l4496
u535_20:
	line	179
	
i1l4494:	
	clrf	(_g_pwmCounter)	;volatile
	line	182
	
i1l4496:	
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u536_21
	goto	u536_20
u536_21:
	goto	i1l360
u536_20:
	
i1l4498:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u537_21
	goto	u537_20
u537_21:
	goto	i1l360
u537_20:
	line	183
	
i1l4500:	
	bsf	(55/8),(55)&7	;volatile
	goto	i1l4502
	line	184
	
i1l360:	
	line	185
	bcf	(55/8),(55)&7	;volatile
	line	188
	
i1l4502:	
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u538_21
	goto	u538_20
u538_21:
	goto	i1l4562
u538_20:
	line	190
	
i1l4504:	
	fcall	_PowerOnLedSequence
	goto	i1l363
	line	197
	
i1l365:	
	line	199
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u539_21
	goto	u539_20
u539_21:
	goto	i1l363
u539_20:
	
i1l4508:	
	btfsc	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u540_21
	goto	u540_20
u540_21:
	goto	i1l363
u540_20:
	goto	i1l4512
	line	201
	
i1l369:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l382
	
i1l371:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l382
	
i1l372:	
	bsf	(51/8),(51)&7	;volatile
	goto	i1l382
	
i1l373:	
	bsf	(50/8),(50)&7	;volatile
	goto	i1l382
	
i1l374:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l382
	
i1l375:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l382
	
i1l376:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l382
	
i1l377:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l382
	
i1l378:	
	bsf	(48/8),(48)&7	;volatile
	goto	i1l382
	
i1l379:	
	bsf	(49/8),(49)&7	;volatile
	goto	i1l382
	
i1l380:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l382
	
i1l381:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l382
	
i1l4512:	
	movf	(_g_scanIndex),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l369
	xorlw	1^0	; case 1
	skipnz
	goto	i1l371
	xorlw	2^1	; case 2
	skipnz
	goto	i1l372
	xorlw	3^2	; case 3
	skipnz
	goto	i1l373
	xorlw	4^3	; case 4
	skipnz
	goto	i1l374
	xorlw	5^4	; case 5
	skipnz
	goto	i1l375
	xorlw	6^5	; case 6
	skipnz
	goto	i1l376
	xorlw	7^6	; case 7
	skipnz
	goto	i1l377
	xorlw	8^7	; case 8
	skipnz
	goto	i1l378
	xorlw	9^8	; case 9
	skipnz
	goto	i1l379
	xorlw	10^9	; case 10
	skipnz
	goto	i1l380
	xorlw	11^10	; case 11
	skipnz
	goto	i1l381
	goto	i1l382
	opt asmopt_pop

	
i1l382:	
	line	202
	bsf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	i1l363
	line	208
	
i1l4514:	
	movf	(_g_scanIndex),w	;volatile
	fcall	_Update_LED_Slot
	line	210
	
i1l4516:	
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_scanPhase)	;volatile
	line	211
	goto	i1l363
	line	214
	
i1l4518:	
	movf	((_g_scanIndex)),w	;volatile
	btfss	status,2
	goto	u541_21
	goto	u541_20
u541_21:
	goto	i1l4554
u541_20:
	line	216
	
i1l4520:	
	fcall	_Charging_Control
	line	217
	
i1l4522:	
	fcall	_CCCV_Control
	line	218
	
i1l4524:	
	fcall	_Led_BlinkProcess
	line	224
	
i1l4526:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_g_tempPhase)),w	;volatile
	btfss	status,2
	goto	u542_21
	goto	u542_20
u542_21:
	goto	i1l4538
u542_20:
	line	227
	
i1l4528:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_tempReadRoundCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1)^080h,f	;volatile
	line	228
	
i1l4530:	
	movlw	0
	subwf	(_g_tempReadRoundCnt+1)^080h,w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt)^080h,w	;volatile
	skipc
	goto	u543_21
	goto	u543_20
u543_21:
	goto	i1l4546
u543_20:
	line	230
	
i1l4532:	
	clrf	(_g_tempReadRoundCnt)^080h	;volatile
	clrf	(_g_tempReadRoundCnt+1)^080h	;volatile
	line	231
	
i1l4534:	
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_tempPhase)	;volatile
	line	232
	
i1l4536:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	goto	i1l4546
	line	237
	
i1l4538:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_tempSettleCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1)^080h,f	;volatile
	line	238
	
i1l4540:	
	movlw	0
	subwf	(_g_tempSettleCnt+1)^080h,w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt)^080h,w	;volatile
	skipc
	goto	u544_21
	goto	u544_20
u544_21:
	goto	i1l4546
u544_20:
	line	241
	
i1l4542:	
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	242
	
i1l4544:	
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	line	243
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_tempPhase)	;volatile
	line	249
	
i1l4546:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_printTick)^080h,f	;volatile
	skipnz
	incf	(_g_printTick+1)^080h,f	;volatile
	movlw	0
	subwf	((_g_printTick+1)^080h),w	;volatile
	movlw	064h
	skipnz
	subwf	((_g_printTick)^080h),w	;volatile
	skipc
	goto	u545_21
	goto	u545_20
u545_21:
	goto	i1l4554
u545_20:
	line	251
	
i1l4548:	
	clrf	(_g_printTick)^080h	;volatile
	clrf	(_g_printTick+1)^080h	;volatile
	line	252
	
i1l4550:	
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	253
	
i1l4552:	
	bsf	(_g_ntcPrintFlag/8),(_g_ntcPrintFlag)&7	;volatile
	line	258
	
i1l4554:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	incf	(_g_scanIndex),f	;volatile
	subwf	((_g_scanIndex)),w	;volatile
	skipc
	goto	u546_21
	goto	u546_20
u546_21:
	goto	i1l393
u546_20:
	line	259
	
i1l4556:	
	clrf	(_g_scanIndex)	;volatile
	
i1l393:	
	line	260
	clrf	(_g_scanPhase)	;volatile
	line	261
	goto	i1l363
	line	195
	
i1l4562:	
	movf	(_g_scanPhase),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 2
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           17     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l365
	xorlw	1^0	; case 1
	skipnz
	goto	i1l4514
	xorlw	2^1	; case 2
	skipnz
	goto	i1l4518
	goto	i1l393
	opt asmopt_pop

	line	268
	
i1l363:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(??_Isr_Timer+3),w
	movwf	btemp+1
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^00h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	_Update_LED_Slot

;; *************** function _Update_LED_Slot *****************
;; Defined at:
;;		line 30 in file "led.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    5[COMMON] unsigned char 
;;  led             1    4[COMMON] unsigned char 
;;  s               1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         3       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	file	"led.c"
	line	30
global __ptext22
__ptext22:	;psect for function _Update_LED_Slot
psect	text22
	file	"led.c"
	line	30
	global	__size_of_Update_LED_Slot
	__size_of_Update_LED_Slot	equ	__end_of_Update_LED_Slot-_Update_LED_Slot
	
_Update_LED_Slot:	
;incstack = 0
	opt	stack 2
; Regs used in _Update_LED_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	movwf	(Update_LED_Slot@idx)
	line	36
	
i1l3904:	
	movlw	low(06h)
	subwf	(Update_LED_Slot@idx),w
	skipnc
	goto	u438_21
	goto	u438_20
u438_21:
	goto	i1l3908
u438_20:
	
i1l3906:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Update_LED_Slot@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(Update_LED_Slot@s)
	goto	i1l3920
	line	37
	
i1l3908:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Update_LED_Slot@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B9h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Slot@s)
	goto	i1l3920
	line	42
	
i1l3910:	
	clrf	(Update_LED_Slot@led)
	line	43
	goto	i1l3922
	line	47
	
i1l710:	
	line	50
	
i1l713:	
	line	51
	clrf	(Update_LED_Slot@led)
	incf	(Update_LED_Slot@led),f
	line	52
	goto	i1l3922
	line	54
	
i1l3912:	
	movlw	low(02h)
	movwf	(Update_LED_Slot@led)
	line	55
	goto	i1l3922
	line	57
	
i1l3914:	
	movlw	low(03h)
	movwf	(Update_LED_Slot@led)
	line	58
	goto	i1l3922
	line	39
	
i1l3920:	
	movf	(Update_LED_Slot@s),w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l3910
	xorlw	1^0	; case 1
	skipnz
	goto	i1l710
	xorlw	2^1	; case 2
	skipnz
	goto	i1l713
	xorlw	3^2	; case 3
	skipnz
	goto	i1l713
	xorlw	4^3	; case 4
	skipnz
	goto	i1l713
	xorlw	5^4	; case 5
	skipnz
	goto	i1l713
	xorlw	6^5	; case 6
	skipnz
	goto	i1l3912
	xorlw	7^6	; case 7
	skipnz
	goto	i1l3914
	xorlw	8^7	; case 8
	skipnz
	goto	i1l713
	xorlw	9^8	; case 9
	skipnz
	goto	i1l713
	goto	i1l3910
	opt asmopt_pop

	line	65
	
i1l3922:	
	movlw	low(06h)
	subwf	(Update_LED_Slot@idx),w
	skipnc
	goto	u439_21
	goto	u439_20
u439_21:
	goto	i1l3926
u439_20:
	
i1l3924:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Update_LED_Slot@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	movf	(Update_LED_Slot@led),w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	goto	i1l719
	line	66
	
i1l3926:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Update_LED_Slot@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0BAh)&0ffh
	movwf	fsr0
	movf	(Update_LED_Slot@led),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	line	67
	
i1l719:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Slot
	__end_of_Update_LED_Slot:
	signat	_Update_LED_Slot,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 128 in file "led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	line	128
global __ptext23
__ptext23:	;psect for function _PowerOnLedSequence
psect	text23
	file	"led.c"
	line	128
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	130
	
i1l2760:	
	incf	(_g_powerOnTimer),f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1),f	;volatile
	line	132
	
i1l2762:	
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u256_21
	goto	u256_20
u256_21:
	goto	i1l2770
u256_20:
	line	135
	
i1l2764:	
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u257_21
	goto	u257_20
u257_21:
	goto	i1l740
u257_20:
	line	137
	
i1l2766:	
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	138
	
i1l2768:	
	movlw	low(01h)
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l740
	line	141
	
i1l2770:	
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u258_21
	goto	u258_20
u258_21:
	goto	i1l740
u258_20:
	line	144
	
i1l2772:	
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u259_21
	goto	u259_20
u259_21:
	goto	i1l740
u259_20:
	line	146
	
i1l2774:	
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	147
	
i1l2776:	
	movlw	low(02h)
	movwf	(_g_powerOnPhase)	;volatile
	line	151
	
i1l740:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
	global	_Led_BlinkProcess

;; *************** function _Led_BlinkProcess *****************
;; Defined at:
;;		line 77 in file "led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  bt              2    3[COMMON] unsigned int 
;;  led             1    5[COMMON] unsigned char 
;;  i               1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext24
__ptext24:	;psect for function _Led_BlinkProcess
psect	text24
	file	"led.c"
	line	77
	global	__size_of_Led_BlinkProcess
	__size_of_Led_BlinkProcess	equ	__end_of_Led_BlinkProcess-_Led_BlinkProcess
	
_Led_BlinkProcess:	
;incstack = 0
	opt	stack 2
; Regs used in _Led_BlinkProcess: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	81
	
i1l4070:	
	clrf	(Led_BlinkProcess@i)
	line	87
	
i1l4076:	
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipnc
	goto	u473_21
	goto	u473_20
u473_21:
	goto	i1l4080
u473_20:
	line	88
	
i1l4078:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(Led_BlinkProcess@led)
	line	89
	goto	i1l4082
	line	90
	
i1l4080:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0BAh)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Led_BlinkProcess@led)
	line	94
	
i1l4082:	
		movlw	3
	xorwf	((Led_BlinkProcess@led)),w
	btfss	status,2
	goto	u474_21
	goto	u474_20
u474_21:
	goto	i1l4098
u474_20:
	line	97
	
i1l4084:	
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipnc
	goto	u475_21
	goto	u475_20
u475_21:
	goto	i1l4088
u475_20:
	line	98
	
i1l4086:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8)+07h)&0ffh
	movwf	fsr0
	movlw	01h
	bsf	status, 7	;select IRP bank3
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	99
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8)+07h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(Led_BlinkProcess@bt)
	incf	fsr0,f
	movf	indf,w
	movwf	(Led_BlinkProcess@bt+1)
	line	100
	goto	i1l4090
	line	101
	
i1l4088:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0BFh)&0ffh
	movwf	fsr0
	movlw	01h
	bsf	status, 7	;select IRP bank2
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	102
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0BFh)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Led_BlinkProcess@bt)
	incf	fsr0,f
	movf	indf,w
	movwf	(Led_BlinkProcess@bt+1)
	line	106
	
i1l4090:	
	movlw	0
	subwf	(Led_BlinkProcess@bt+1),w
	movlw	032h
	skipnz
	subwf	(Led_BlinkProcess@bt),w
	skipc
	goto	u476_21
	goto	u476_20
u476_21:
	goto	i1l4098
u476_20:
	line	108
	
i1l4092:	
	movlw	low(06h)
	subwf	(Led_BlinkProcess@i),w
	skipnc
	goto	u477_21
	goto	u477_20
u477_21:
	goto	i1l4096
u477_20:
	line	109
	
i1l4094:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8)+07h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	110
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8)+09h)&0ffh
	movwf	fsr0
	movlw	low(01h)
	bsf	status, 7	;select IRP bank3
	xorwf	indf,f
	line	111
	goto	i1l4098
	line	112
	
i1l4096:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0BFh)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	113
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Led_BlinkProcess@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0C1h)&0ffh
	movwf	fsr0
	movlw	low(01h)
	bsf	status, 7	;select IRP bank2
	xorwf	indf,f
	line	81
	
i1l4098:	
	incf	(Led_BlinkProcess@i),f
	
i1l4100:	
	movlw	low(0Ch)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u478_21
	goto	u478_20
u478_21:
	goto	i1l4076
u478_20:
	line	118
	
i1l732:	
	return
	opt stack 0
GLOBAL	__end_of_Led_BlinkProcess
	__end_of_Led_BlinkProcess:
	signat	_Led_BlinkProcess,89
	global	_Charging_Control

;; *************** function _Charging_Control *****************
;; Defined at:
;;		line 497 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    7[COMMON] unsigned char 
;;  i               1    8[COMMON] unsigned char 
;;  chargeB7_12     1    6[COMMON] unsigned char 
;;  chargeB1_6      1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 100/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         6       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         6       0       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	497
global __ptext25
__ptext25:	;psect for function _Charging_Control
psect	text25
	file	"charge_mgr.c"
	line	497
	global	__size_of_Charging_Control
	__size_of_Charging_Control	equ	__end_of_Charging_Control-_Charging_Control
	
_Charging_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _Charging_Control: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	500
	
i1l3928:	
	clrf	(Charging_Control@chargeB1_6)
	line	501
	clrf	(Charging_Control@chargeB7_12)
	line	504
	
i1l3930:	
	movf	((_g_tempProtect)),w
	btfsc	status,2
	goto	u440_21
	goto	u440_20
u440_21:
	goto	i1l3936
u440_20:
	line	506
	
i1l623:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	bsf	(1073/8)^080h,(1073)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	bsf	(50/8),(50)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	bsf	(1074/8)^080h,(1074)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	bsf	(49/8),(49)&7	;volatile
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	
i1l624:	
	line	507
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	508
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	509
	
i1l3932:	
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	goto	i1l625
	line	514
	
i1l3936:	
	clrf	(Charging_Control@i)
	line	516
	
i1l3942:	
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipc
	goto	u441_21
	goto	u441_20
u441_21:
	goto	i1l3946
u441_20:
	
i1l3944:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B9h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(_Charging_Control$403)
	clrf	(_Charging_Control$403+1)
	goto	i1l3948
	
i1l3946:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(_Charging_Control$403)
	clrf	(_Charging_Control$403+1)
	
i1l3948:	
	movf	(_Charging_Control$403),w
	movwf	(Charging_Control@s)
	line	521
	
i1l3950:	
		movlw	2
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u442_21
	goto	u442_20
u442_21:
	goto	i1l3964
u442_20:
	
i1l3952:	
		movlw	3
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u443_21
	goto	u443_20
u443_21:
	goto	i1l3964
u443_20:
	
i1l3954:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u444_21
	goto	u444_20
u444_21:
	goto	i1l3964
u444_20:
	
i1l3956:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u445_21
	goto	u445_20
u445_21:
	goto	i1l3964
u445_20:
	
i1l3958:	
		movlw	8
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u446_21
	goto	u446_20
u446_21:
	goto	i1l3964
u446_20:
	
i1l3960:	
		movlw	9
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u447_21
	goto	u447_20
u447_21:
	goto	i1l3972
u447_20:
	goto	i1l3964
	line	523
	
i1l637:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l3966
	
i1l639:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l3966
	
i1l640:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l3966
	
i1l641:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l3966
	
i1l642:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l3966
	
i1l643:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l3966
	
i1l644:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l3966
	
i1l645:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l3966
	
i1l646:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l3966
	
i1l647:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l3966
	
i1l648:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l3966
	
i1l649:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l3966
	
i1l3964:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l637
	xorlw	1^0	; case 1
	skipnz
	goto	i1l639
	xorlw	2^1	; case 2
	skipnz
	goto	i1l640
	xorlw	3^2	; case 3
	skipnz
	goto	i1l641
	xorlw	4^3	; case 4
	skipnz
	goto	i1l642
	xorlw	5^4	; case 5
	skipnz
	goto	i1l643
	xorlw	6^5	; case 6
	skipnz
	goto	i1l644
	xorlw	7^6	; case 7
	skipnz
	goto	i1l645
	xorlw	8^7	; case 8
	skipnz
	goto	i1l646
	xorlw	9^8	; case 9
	skipnz
	goto	i1l647
	xorlw	10^9	; case 10
	skipnz
	goto	i1l648
	xorlw	11^10	; case 11
	skipnz
	goto	i1l649
	goto	i1l3966
	opt asmopt_pop

	line	526
	
i1l3966:	
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipnc
	goto	u448_21
	goto	u448_20
u448_21:
	goto	i1l651
u448_20:
	line	527
	
i1l3968:	
	clrf	(Charging_Control@chargeB1_6)
	incf	(Charging_Control@chargeB1_6),f
	goto	i1l3974
	line	528
	
i1l651:	
	line	529
	clrf	(Charging_Control@chargeB7_12)
	incf	(Charging_Control@chargeB7_12),f
	goto	i1l3974
	line	533
	
i1l656:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l3974
	
i1l658:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l3974
	
i1l659:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	i1l3974
	
i1l660:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	i1l3974
	
i1l661:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l3974
	
i1l662:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l3974
	
i1l663:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l3974
	
i1l664:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l3974
	
i1l665:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	i1l3974
	
i1l666:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	i1l3974
	
i1l667:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l3974
	
i1l668:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l3974
	
i1l3972:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l656
	xorlw	1^0	; case 1
	skipnz
	goto	i1l658
	xorlw	2^1	; case 2
	skipnz
	goto	i1l659
	xorlw	3^2	; case 3
	skipnz
	goto	i1l660
	xorlw	4^3	; case 4
	skipnz
	goto	i1l661
	xorlw	5^4	; case 5
	skipnz
	goto	i1l662
	xorlw	6^5	; case 6
	skipnz
	goto	i1l663
	xorlw	7^6	; case 7
	skipnz
	goto	i1l664
	xorlw	8^7	; case 8
	skipnz
	goto	i1l665
	xorlw	9^8	; case 9
	skipnz
	goto	i1l666
	xorlw	10^9	; case 10
	skipnz
	goto	i1l667
	xorlw	11^10	; case 11
	skipnz
	goto	i1l668
	goto	i1l3974
	opt asmopt_pop

	line	514
	
i1l3974:	
	incf	(Charging_Control@i),f
	
i1l3976:	
	movlw	low(0Ch)
	subwf	(Charging_Control@i),w
	skipc
	goto	u449_21
	goto	u449_20
u449_21:
	goto	i1l3942
u449_20:
	
i1l627:	
	line	538
	btfsc	(Charging_Control@chargeB1_6),0
	goto	u450_21
	goto	u450_20
	
u450_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2099/8)^0100h,(2099)&7	;volatile
	goto	u451_24
u450_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
u451_24:
	line	539
	btfsc	(Charging_Control@chargeB7_12),0
	goto	u452_21
	goto	u452_20
	
u452_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u453_24
u452_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u453_24:
	line	542
	
i1l625:	
	return
	opt stack 0
GLOBAL	__end_of_Charging_Control
	__end_of_Charging_Control:
	signat	_Charging_Control,89
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 560 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    8[BANK0 ] unsigned int 
;;  s               1   14[BANK0 ] unsigned char 
;;  duty            2   12[BANK0 ] int 
;;  error           2   10[BANK0 ] int 
;;  adjust          2    0[BANK0 ] int 
;;  maxV            2    6[BANK0 ] unsigned int 
;;  i               1   15[BANK0 ] unsigned char 
;;  cvCount         1    5[BANK0 ] unsigned char 
;;  hasCharging     1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 100/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      16       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2      16       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___awdiv
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=0
	line	560
global __ptext26
__ptext26:	;psect for function _CCCV_Control
psect	text26
	file	"charge_mgr.c"
	line	560
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	563
	
i1l3978:	
	bcf	status, 6	;RP1=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	564
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	565
	clrf	(CCCV_Control@cvCount)
	line	568
	clrf	(CCCV_Control@i)
	line	570
	
i1l3984:	
	movlw	low(06h)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u454_21
	goto	u454_20
u454_21:
	goto	i1l3988
u454_20:
	
i1l3986:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0B9h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$410)
	clrf	(_CCCV_Control$410+1)
	goto	i1l3990
	
i1l3988:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_CCCV_Control$410)
	clrf	(_CCCV_Control$410+1)
	
i1l3990:	
	movf	(_CCCV_Control$410),w
	movwf	(CCCV_Control@s)
	line	574
	
i1l3992:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u455_21
	goto	u455_20
u455_21:
	goto	i1l680
u455_20:
	
i1l3994:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u456_21
	goto	u456_20
u456_21:
	goto	i1l680
u456_20:
	
i1l3996:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u457_21
	goto	u457_20
u457_21:
	goto	i1l680
u457_20:
	
i1l3998:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u458_21
	goto	u458_20
u458_21:
	goto	i1l680
u458_20:
	
i1l4000:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u459_21
	goto	u459_20
u459_21:
	goto	i1l680
u459_20:
	
i1l4002:	
		movlw	9
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u460_21
	goto	u460_20
u460_21:
	goto	i1l678
u460_20:
	
i1l680:	
	line	576
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	578
	
i1l4004:	
	movlw	low(06h)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u461_21
	goto	u461_20
u461_21:
	goto	i1l4008
u461_20:
	
i1l4006:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot1|((0x1)<<8)+0BBh)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	goto	i1l4010
	
i1l4008:	
	movlw	low(0Ch)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot0|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	579
	
i1l4010:	
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u462_25
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u462_25:
	skipnc
	goto	u462_21
	goto	u462_20
u462_21:
	goto	i1l4014
u462_20:
	
i1l4012:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	581
	
i1l4014:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u463_21
	goto	u463_20
u463_21:
	goto	i1l678
u463_20:
	line	582
	
i1l4016:	
	incf	(CCCV_Control@cvCount),f
	line	583
	
i1l678:	
	line	568
	incf	(CCCV_Control@i),f
	
i1l4018:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u464_21
	goto	u464_20
u464_21:
	goto	i1l3984
u464_20:
	line	587
	
i1l4020:	
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u465_21
	goto	u465_20
u465_21:
	goto	i1l4026
u465_20:
	line	589
	
i1l4022:	
	clrf	(_g_pwmDuty)	;volatile
	line	590
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	i1l688
	line	597
	
i1l4026:	
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u466_21
	goto	u466_20
u466_21:
	goto	i1l4044
u466_20:
	line	599
	
i1l4028:	
	movlw	low(019h)
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u467_21
	goto	u467_20
u467_21:
	goto	i1l4036
u467_20:
	line	602
	
i1l4030:	
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	603
	
i1l4032:	
	movlw	low(01Ah)
	subwf	(_g_pwmDuty),w	;volatile
	skipc
	goto	u468_21
	goto	u468_20
u468_21:
	goto	i1l688
u468_20:
	line	604
	
i1l4034:	
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l688
	line	606
	
i1l4036:	
	goto	i1l4034
	line	625
	
i1l4044:	
	movlw	021h
	movwf	(CCCV_Control@error)
	movlw	0Dh
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	628
	movf	(CCCV_Control@error),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral)^080h,f
	skipnc
	incf	(_g_cvIntegral+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(CCCV_Control@error+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral+1)^080h,f
	line	629
	
i1l4046:	
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u469_25
	movlw	0C9h
	subwf	(_g_cvIntegral)^080h,w
u469_25:

	skipc
	goto	u469_21
	goto	u469_20
u469_21:
	goto	i1l4050
u469_20:
	line	630
	
i1l4048:	
	movlw	0C8h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	i1l4054
	line	631
	
i1l4050:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u470_25
	movlw	038h
	subwf	(_g_cvIntegral)^080h,w
u470_25:

	skipnc
	goto	u470_21
	goto	u470_20
u470_21:
	goto	i1l4054
u470_20:
	line	632
	
i1l4052:	
	movlw	038h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	movlw	0FFh
	movwf	((_g_cvIntegral)^080h)+1
	line	635
	
i1l4054:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_cvIntegral)^080h,w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1)^080h,w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	636
	
i1l4056:	
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
i1l4058:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	639
	
i1l4060:	
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u471_25
	movlw	021h
	subwf	(CCCV_Control@duty),w
u471_25:

	skipc
	goto	u471_21
	goto	u471_20
u471_21:
	goto	i1l4064
u471_20:
	
i1l4062:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	640
	
i1l4064:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u472_21
	goto	u472_20
u472_21:
	goto	i1l4068
u472_20:
	
i1l4066:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	642
	
i1l4068:	
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	644
	
i1l688:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	i1___bmul

;; *************** function i1___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[COMMON] unsigned char 
;;  __bmul          1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;;		_Led_BlinkProcess
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext27
__ptext27:	;psect for function i1___bmul
psect	text27
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_ofi1___bmul
	__size_ofi1___bmul	equ	__end_ofi1___bmul-i1___bmul
	
i1___bmul:	
;incstack = 0
	opt	stack 2
; Regs used in i1___bmul: [wreg+status,2+status,0]
	movwf	(i1___bmul@multiplier)
	line	6
	
i1l2680:	
	clrf	(i1___bmul@product)
	line	43
	
i1l2682:	
	btfss	(i1___bmul@multiplier),(0)&7
	goto	u253_21
	goto	u253_20
u253_21:
	goto	i1l2686
u253_20:
	line	44
	
i1l2684:	
	movf	(i1___bmul@multiplicand),w
	addwf	(i1___bmul@product),f
	line	45
	
i1l2686:	
	clrc
	rlf	(i1___bmul@multiplicand),f
	line	46
	
i1l2688:	
	clrc
	rrf	(i1___bmul@multiplier),f
	line	47
	movf	((i1___bmul@multiplier)),w
	btfss	status,2
	goto	u254_21
	goto	u254_20
u254_21:
	goto	i1l2682
u254_20:
	line	50
	
i1l2690:	
	movf	(i1___bmul@product),w
	line	51
	
i1l764:	
	return
	opt stack 0
GLOBAL	__end_ofi1___bmul
	__end_ofi1___bmul:
	signat	i1___bmul,89
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] int 
;;  dividend        2    2[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] int 
;;  sign            1    5[COMMON] unsigned char 
;;  counter         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext28
__ptext28:	;psect for function ___awdiv
psect	text28
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
i1l2636:	
	clrf	(___awdiv@sign)
	line	15
	
i1l2638:	
	btfss	(___awdiv@divisor+1),7
	goto	u246_21
	goto	u246_20
u246_21:
	goto	i1l2644
u246_20:
	line	16
	
i1l2640:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
i1l2642:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
i1l2644:	
	btfss	(___awdiv@dividend+1),7
	goto	u247_21
	goto	u247_20
u247_21:
	goto	i1l2650
u247_20:
	line	20
	
i1l2646:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
i1l2648:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
i1l2650:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
i1l2652:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u248_21
	goto	u248_20
u248_21:
	goto	i1l2672
u248_20:
	line	25
	
i1l2654:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	i1l2658
	line	27
	
i1l2656:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
i1l2658:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u249_21
	goto	u249_20
u249_21:
	goto	i1l2656
u249_20:
	line	31
	
i1l2660:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
i1l2662:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u250_25
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u250_25:
	skipc
	goto	u250_21
	goto	u250_20
u250_21:
	goto	i1l2668
u250_20:
	line	33
	
i1l2664:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
i1l2666:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
i1l2668:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
i1l2670:	
	decfsz	(___awdiv@counter),f
	goto	u251_21
	goto	u251_20
u251_21:
	goto	i1l2660
u251_20:
	line	39
	
i1l2672:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u252_21
	goto	u252_20
u252_21:
	goto	i1l2676
u252_20:
	line	40
	
i1l2674:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
i1l2676:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
i1l876:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
