opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ChargeProcess_Slot
	FNCALL	_main,_Do_AdcSample
	FNCALL	_main,_Do_NtcRead
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_System_Init
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_Do_NtcRead,_Read_Temperature
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Do_AdcSample,_ADC_Sample
	FNCALL	_Do_AdcSample,___bmul
	FNCALL	_ChargeProcess_Slot,_ADC_Sample
	FNCALL	_ChargeProcess_Slot,_Detect_BatteryType
	FNCALL	_ChargeProcess_Slot,___bmul
	FNCALL	_ChargeProcess_Slot,___lldiv
	FNCALL	_ChargeProcess_Slot,___lmul
	FNCALL	_ChargeProcess_Slot,___lwdiv
	FNCALL	_ChargeProcess_Slot,___wmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_CCCV_Control
	FNCALL	_Isr_Timer,_Charging_Control
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Update_LED_Slot
	FNCALL	_Isr_Timer,i1_ADC_Sample
	FNCALL	_Isr_Timer,i1___lldiv
	FNCALL	_Update_LED_Slot,i1___bmul
	FNCALL	_Charging_Control,i1___bmul
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,i1___bmul
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_temperature
	global	_g_vcc_mv
	global	_g_impCheckSlot
psect	idataBANK0,class=CODE,space=0,delta=2,noexec
global __pidataBANK0
__pidataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	18

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	24

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	26

;initializer for _g_impCheckSlot
	retlw	0FFh
	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	50
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_s_ledBlinkCnt
	global	_g_tempProtect
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_adcBusy
	global	_g_doAdcSample
	global	_g_diodeTrace
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_powerOnTimer
	global	_g_cvIntegral
	global	_g_vccProtect
	global	_g_tempPhase
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_scanPhase
	global	_g_scanIndex
	global	_test_adc
	global	_adresult
	global	_g_detectLowCnt
	global	_g_highVFlag
	global	_g_capFlag
	global	_g_impData
	global	_g_diodeTraceSlot
	global	_g_diodeTraceCnt
	global	_g_slot
	global	_g_slotRefV
	global	_g_stableCnt
	global	_g_ovCnt
	global	_g_ccBlocks
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_GIE
_GIE	set	0x5F
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC4
_RC4	set	0x834
	global	_RC5
_RC5	set	0x835
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	0
psect	stringtext
	
STR_37:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_25:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_23:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	45	;'-'
	retlw	105	;'i'
	retlw	111	;'o'
	retlw	110	;'n'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	67	;'C'
	retlw	32	;' '
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	95	;'_'
	retlw	76	;'L'
	retlw	79	;'O'
	retlw	67	;'C'
	retlw	75	;'K'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_38:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_8:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_30:	
	retlw	32	;' '
	retlw	112	;'p'
	retlw	114	;'r'
	retlw	101	;'e'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	32	;' '
	retlw	114	;'r'
	retlw	101	;'e'
	retlw	102	;'f'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_31:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_29:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	73	;'I'
	retlw	79	;'O'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_7:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_34:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	114	;'r'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_32:	
	retlw	32	;' '
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_33:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	53	;'5'
	retlw	52	;'4'
	retlw	77	;'M'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
STR_27	equ	STR_17+0
STR_9	equ	STR_2+0
STR_11	equ	STR_38+7
STR_35	equ	STR_38+7
STR_36	equ	STR_38+7
; #config settings
	file	"SC8F096_Timer_Demo.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

_g_adcBusy:
       ds      1

_g_doAdcSample:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_s_ledBlinkCnt:
       ds      1

_g_tempProtect:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_diodeTrace:
       ds      4

_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_powerOnTimer:
       ds      2

_g_cvIntegral:
       ds      2

_g_vccProtect:
       ds      1

_g_tempPhase:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_scanPhase:
       ds      1

_g_scanIndex:
       ds      1

_test_adc:
       ds      1

_adresult:
       ds      2

psect	dataBANK0,class=BANK0,space=1,noexec
global __pdataBANK0
__pdataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	18
_g_temperature:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_detectLowCnt:
       ds      12

_g_highVFlag:
       ds      2

_g_capFlag:
       ds      2

_g_impData:
       ds      2

_g_diodeTraceSlot:
       ds      1

_g_diodeTraceCnt:
       ds      1

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	24
_g_vcc_mv:
       ds      2

psect	dataBANK1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	26
_g_impCheckSlot:
       ds      1

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slotRefV:
       ds      24

_g_stableCnt:
       ds      12

_g_ovCnt:
       ds      12

_g_ccBlocks:
       ds      12

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"SC8F096_Timer_Demo.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
	fcall	__pidataBANK1+2		;fetch initializer
	movwf	__pdataBANK1+2&07fh		
; Initialize objects allocated to BANK0
	global __pidataBANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	fcall	__pidataBANK0+0		;fetch initializer
	movwf	__pdataBANK0+0&07fh		
	fcall	__pidataBANK0+1		;fetch initializer
	movwf	__pdataBANK0+1&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+03Ch)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+014h)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+018h)
	fcall	clear_ram0
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
	clrf	((__pbssCOMMON)+1)&07Fh
; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK3,class=BANK3,space=1,noexec
global __pcstackBANK3
__pcstackBANK3:
	global	Print_SystemStatus@d
Print_SystemStatus@d:	; 2 bytes @ 0x0
	global	_ChargeProcess_Slot$389
_ChargeProcess_Slot$389:	; 2 bytes @ 0x0
	ds	2
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x2
	global	ChargeProcess_Slot@v_ref
ChargeProcess_Slot@v_ref:	; 2 bytes @ 0x2
	ds	2
	global	ChargeProcess_Slot@bat_mv
ChargeProcess_Slot@bat_mv:	; 2 bytes @ 0x4
	ds	2
	global	ChargeProcess_Slot@bat_mv_383
ChargeProcess_Slot@bat_mv_383:	; 2 bytes @ 0x6
	ds	2
	global	ChargeProcess_Slot@bat_mv_386
ChargeProcess_Slot@bat_mv_386:	; 2 bytes @ 0x8
	ds	2
	global	ChargeProcess_Slot@diff
ChargeProcess_Slot@diff:	; 2 bytes @ 0xA
	ds	2
	global	ChargeProcess_Slot@pre
ChargeProcess_Slot@pre:	; 2 bytes @ 0xC
	ds	4
	global	ChargeProcess_Slot@ty
ChargeProcess_Slot@ty:	; 1 bytes @ 0x10
	ds	1
	global	ChargeProcess_Slot@ct
ChargeProcess_Slot@ct:	; 2 bytes @ 0x11
	ds	2
	global	ChargeProcess_Slot@idx
ChargeProcess_Slot@idx:	; 1 bytes @ 0x13
	ds	1
psect	cstackBANK2,class=BANK2,space=1,noexec
global __pcstackBANK2
__pcstackBANK2:
	global	ChargeProcess_Slot@v
ChargeProcess_Slot@v:	; 2 bytes @ 0x0
	ds	2
??_main:	; 1 bytes @ 0x2
	ds	2
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
?_ADC_Sample:	; 1 bytes @ 0x0
?_Detect_BatteryType:	; 1 bytes @ 0x0
?___bmul:	; 1 bytes @ 0x0
	global	?___wmul
?___wmul:	; 2 bytes @ 0x0
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x0
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x0
	global	?___lmul
?___lmul:	; 4 bytes @ 0x0
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x0
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x0
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x0
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x0
	global	___wmul@multiplier
___wmul@multiplier:	; 2 bytes @ 0x0
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x0
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x0
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x0
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x1
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x1
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x1
	ds	1
?_uart_send_string:	; 1 bytes @ 0x2
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x2
	global	___wmul@multiplicand
___wmul@multiplicand:	; 2 bytes @ 0x2
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x2
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x2
	ds	2
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x4
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x4
	ds	1
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x5
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x5
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x6
	ds	1
?_uart_send_number:	; 1 bytes @ 0x7
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x7
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x7
	ds	1
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x8
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x8
	ds	1
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x9
	ds	3
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0xC
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0xC
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0xC
	ds	2
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0xE
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0xF
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x10
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0x10
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x10
	ds	1
	global	_Print_NtcTemp$741
_Print_NtcTemp$741:	; 2 bytes @ 0x11
	ds	1
??_Do_AdcSample:	; 1 bytes @ 0x12
	ds	1
	global	Do_AdcSample@ch
Do_AdcSample@ch:	; 1 bytes @ 0x13
	global	_Print_NtcTemp$742
_Print_NtcTemp$742:	; 2 bytes @ 0x13
	ds	1
	global	Do_AdcSample@ty
Do_AdcSample@ty:	; 1 bytes @ 0x14
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x14
	ds	1
	global	Do_AdcSample@dly
Do_AdcSample@dly:	; 1 bytes @ 0x15
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x15
	ds	1
	global	Do_AdcSample@st
Do_AdcSample@st:	; 1 bytes @ 0x16
	ds	3
??_Read_Temperature:	; 1 bytes @ 0x19
??_ChargeProcess_Slot:	; 1 bytes @ 0x19
??_Print_SystemStatus:	; 1 bytes @ 0x19
	ds	4
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x1D
	ds	1
	global	ChargeProcess_Slot@v_init
ChargeProcess_Slot@v_init:	; 2 bytes @ 0x1E
	ds	2
	global	ChargeProcess_Slot@vx_mv
ChargeProcess_Slot@vx_mv:	; 4 bytes @ 0x20
	ds	1
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x21
	global	_Print_SystemStatus$743
_Print_SystemStatus$743:	; 2 bytes @ 0x21
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x23
	global	_Print_SystemStatus$744
_Print_SystemStatus$744:	; 2 bytes @ 0x23
	ds	1
	global	ChargeProcess_Slot@bat_mv_long
ChargeProcess_Slot@bat_mv_long:	; 4 bytes @ 0x24
	ds	1
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x25
	ds	3
	global	ChargeProcess_Slot@vx_mv_381
ChargeProcess_Slot@vx_mv_381:	; 4 bytes @ 0x28
	ds	1
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x29
	ds	1
	global	_Print_SystemStatus$277
_Print_SystemStatus$277:	; 2 bytes @ 0x2A
	ds	2
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x2C
	global	ChargeProcess_Slot@bat_mv_long_382
ChargeProcess_Slot@bat_mv_long_382:	; 4 bytes @ 0x2C
	ds	2
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0x2E
	ds	2
	global	ChargeProcess_Slot@vx_mv_384
ChargeProcess_Slot@vx_mv_384:	; 4 bytes @ 0x30
	ds	2
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0x32
	ds	2
	global	ChargeProcess_Slot@bat_mv_long_385
ChargeProcess_Slot@bat_mv_long_385:	; 4 bytes @ 0x34
	ds	2
	global	Print_SystemStatus@tc
Print_SystemStatus@tc:	; 1 bytes @ 0x36
	ds	1
	global	Print_SystemStatus@t
Print_SystemStatus@t:	; 1 bytes @ 0x37
	ds	1
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x38
	global	ChargeProcess_Slot@st
ChargeProcess_Slot@st:	; 1 bytes @ 0x38
	ds	1
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Update_LED_Slot:	; 1 bytes @ 0x0
?_Charging_Control:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_ChargeProcess_Slot:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Do_AdcSample:	; 1 bytes @ 0x0
?_Do_NtcRead:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?i1_ADC_Sample:	; 1 bytes @ 0x0
?i1___bmul:	; 1 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	?i1___lldiv
?i1___lldiv:	; 4 bytes @ 0x0
	global	i1ADC_Sample@adldo
i1ADC_Sample@adldo:	; 1 bytes @ 0x0
	global	i1___bmul@multiplicand
i1___bmul@multiplicand:	; 1 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	global	i1___lldiv@divisor
i1___lldiv@divisor:	; 4 bytes @ 0x0
	ds	1
??i1_ADC_Sample:	; 1 bytes @ 0x1
??i1___bmul:	; 1 bytes @ 0x1
	global	i1___bmul@multiplier
i1___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
	global	i1___bmul@product
i1___bmul@product:	; 1 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_Update_LED_Slot:	; 1 bytes @ 0x3
??_Charging_Control:	; 1 bytes @ 0x3
	global	Charging_Control@s
Charging_Control@s:	; 1 bytes @ 0x3
	global	Update_LED_Slot@idx
Update_LED_Slot@idx:	; 1 bytes @ 0x3
	ds	1
??___awdiv:	; 1 bytes @ 0x4
	global	Charging_Control@i
Charging_Control@i:	; 1 bytes @ 0x4
	global	Update_LED_Slot@hasErr
Update_LED_Slot@hasErr:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	global	i1___lldiv@dividend
i1___lldiv@dividend:	; 4 bytes @ 0x4
	ds	1
	global	Update_LED_Slot@hasChg
Update_LED_Slot@hasChg:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	ds	1
	global	Update_LED_Slot@hasFull
Update_LED_Slot@hasFull:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	1
	global	Update_LED_Slot@i
Update_LED_Slot@i:	; 1 bytes @ 0x7
	ds	1
??_CCCV_Control:	; 1 bytes @ 0x8
??i1___lldiv:	; 1 bytes @ 0x8
	global	Update_LED_Slot@s
Update_LED_Slot@s:	; 1 bytes @ 0x8
	ds	2
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	i1ADC_Sample@adch
i1ADC_Sample@adch:	; 1 bytes @ 0x0
	global	i1___lldiv@counter
i1___lldiv@counter:	; 1 bytes @ 0x0
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x0
	ds	1
	global	i1ADC_Sample@j
i1ADC_Sample@j:	; 1 bytes @ 0x1
	global	i1___lldiv@quotient
i1___lldiv@quotient:	; 4 bytes @ 0x1
	ds	1
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x2
	global	i1ADC_Sample@i
i1ADC_Sample@i:	; 1 bytes @ 0x2
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x3
	global	i1ADC_Sample@adsum
i1ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0x4
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0x5
	ds	1
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x6
	ds	1
	global	i1ADC_Sample@admin
i1ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x8
	ds	1
	global	i1ADC_Sample@admax
i1ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	1
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xA
	ds	1
	global	i1ADC_Sample@ad_temp
i1ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0xC
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0xD
	ds	1
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0xE
	ds	2
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x10
	ds	1
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x11
	ds	1
??_Isr_Timer:	; 1 bytes @ 0x12
	ds	4
	global	Isr_Timer@pt
Isr_Timer@pt:	; 4 bytes @ 0x16
	ds	4
??_AD_Init:	; 1 bytes @ 0x1A
??_uart_init:	; 1 bytes @ 0x1A
??_uart_send_char:	; 1 bytes @ 0x1A
??_Do_NtcRead:	; 1 bytes @ 0x1A
??_Detect_BatteryType:	; 1 bytes @ 0x1A
??___wmul:	; 1 bytes @ 0x1A
??___lmul:	; 1 bytes @ 0x1A
??___bmul:	; 1 bytes @ 0x1A
??___lldiv:	; 1 bytes @ 0x1A
??___lwdiv:	; 1 bytes @ 0x1A
??___lwmod:	; 1 bytes @ 0x1A
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x1A
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x1A
	global	___wmul@product
___wmul@product:	; 2 bytes @ 0x1A
	ds	1
??_uart_send_string:	; 1 bytes @ 0x1B
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x1B
	ds	1
??_uart_send_number:	; 1 bytes @ 0x1C
??_System_Init:	; 1 bytes @ 0x1C
??_Print_NtcTemp:	; 1 bytes @ 0x1C
;!
;!Data Sizes:
;!    Strings     254
;!    Constant    12
;!    Data        5
;!    BSS         178
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     10      13
;!    BANK0            80     28      54
;!    BANK1            80     57      80
;!    BANK3            80     20      80
;!    BANK2            80      4      76

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 25
;!		 -> STR_38(CODE[10]), STR_37(CODE[21]), STR_36(CODE[3]), STR_35(CODE[3]), 
;!		 -> STR_34(CODE[5]), STR_33(CODE[5]), STR_32(CODE[5]), STR_31(CODE[6]), 
;!		 -> STR_30(CODE[6]), STR_29(CODE[6]), STR_28(CODE[6]), STR_27(CODE[6]), 
;!		 -> STR_26(CODE[6]), STR_25(CODE[16]), STR_24(CODE[13]), STR_23(CODE[15]), 
;!		 -> STR_22(CODE[7]), STR_21(CODE[5]), STR_20(CODE[5]), STR_19(CODE[6]), 
;!		 -> STR_18(CODE[6]), STR_17(CODE[6]), STR_16(CODE[6]), STR_15(CODE[7]), 
;!		 -> STR_14(CODE[4]), STR_13(CODE[6]), STR_12(CODE[6]), STR_11(CODE[3]), 
;!		 -> STR_10(CODE[12]), STR_9(CODE[2]), STR_8(CODE[6]), STR_7(CODE[5]), 
;!		 -> STR_6(CODE[6]), STR_5(CODE[5]), STR_4(CODE[25]), STR_3(CODE[4]), 
;!		 -> STR_2(CODE[2]), STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->_CCCV_Control
;!    _Update_LED_Slot->i1___bmul
;!    _Charging_Control->i1___bmul
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _main in BANK0
;!
;!    _System_Init->___bmul
;!    _Print_SystemStatus->___bmul
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___bmul
;!    _Do_AdcSample->___bmul
;!    _ChargeProcess_Slot->___bmul
;!    _ChargeProcess_Slot->___wmul
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    _Isr_Timer->_CCCV_Control
;!
;!Critical Paths under _main in BANK1
;!
;!    _main->_ChargeProcess_Slot
;!    _main->_Print_SystemStatus
;!    _System_Init->___bmul
;!    _Print_SystemStatus->___lldiv
;!    _Print_NtcTemp->_uart_send_number
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _Do_NtcRead->_Read_Temperature
;!    _Read_Temperature->___lldiv
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->___lldiv
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    _main->_ChargeProcess_Slot
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    _main->_ChargeProcess_Slot
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 2     2      0   65671
;!                                              2 BANK2      2     2      0
;!                 _ChargeProcess_Slot
;!                       _Do_AdcSample
;!                         _Do_NtcRead
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                        _System_Init
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1542
;!                                              1 BANK1      1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  36    36      0   16630
;!                                             25 BANK1     32    32      0
;!                                              0 BANK3      4     4      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    8197
;!                                             17 BANK1      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    3236
;!                                              2 BANK1      2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_number                                    10     8      2    3409
;!                                              7 BANK1     10     8      2
;!                             ___bmul (ARG)
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     144
;!                                             26 BANK0      1     1      0
;!                                              0 BANK1      2     2      0
;! ---------------------------------------------------------------------------------
;! (3) ___lwmod                                              5     1      4     518
;!                                             26 BANK0      1     1      0
;!                                              0 BANK1      4     0      4
;! ---------------------------------------------------------------------------------
;! (1) _Do_NtcRead                                           0     0      0    6871
;!                   _Read_Temperature
;! ---------------------------------------------------------------------------------
;! (2) _Read_Temperature                                    12    12      0    6871
;!                                             25 BANK1     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (1) _Do_AdcSample                                         5     5      0    3063
;!                                             18 BANK1      5     5      0
;!                         _ADC_Sample
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _ChargeProcess_Slot                                  54    54      0   26132
;!                                             25 BANK1     32    32      0
;!                                              0 BANK3     20    20      0
;!                                              0 BANK2      2     2      0
;!                         _ADC_Sample
;!                 _Detect_BatteryType
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (2) ___wmul                                               6     2      4    2810
;!                                             26 BANK0      2     2      0
;!                                              0 BANK1      4     0      4
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4    1010
;!                                              0 BANK1      7     3      4
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8    2622
;!                                              0 BANK1     12     4      8
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1554
;!                                             12 BANK1     13     5      8
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1    1194
;!                                             26 BANK0      2     2      0
;!                                              0 BANK1      1     0      1
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     331
;!                                              0 BANK1      2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _ADC_Sample                                          18    17      1    1125
;!                                              0 BANK1     18    17      1
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 3
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            8     8      0    4077
;!                                             18 BANK0      8     8      0
;!                       _CCCV_Control
;!                   _Charging_Control
;!                 _PowerOnLedSequence
;!                    _Update_LED_Slot
;!                       i1_ADC_Sample
;!                          i1___lldiv
;! ---------------------------------------------------------------------------------
;! (5) i1___lldiv                                           13     5      8      44
;!                                              0 COMMON     8     0      8
;!                                              0 BANK0      5     5      0
;! ---------------------------------------------------------------------------------
;! (5) i1_ADC_Sample                                        18    17      1     551
;!                                              0 COMMON     5     4      1
;!                                              0 BANK0     13    13      0
;! ---------------------------------------------------------------------------------
;! (5) _Update_LED_Slot                                      6     6      0     660
;!                                              3 COMMON     6     6      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Charging_Control                                     2     2      0     666
;!                                              3 COMMON     2     2      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _CCCV_Control                                        20    20      0    2108
;!                                              8 COMMON     2     2      0
;!                                              0 BANK0     18    18      0
;!                            ___awdiv
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (6) i1___bmul                                             3     2      1     144
;!                                              0 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (6) ___awdiv                                              8     4      4     428
;!                                              0 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ChargeProcess_Slot
;!     _ADC_Sample
;!     _Detect_BatteryType
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___wmul
;!   _Do_AdcSample
;!     _ADC_Sample
;!     ___bmul
;!   _Do_NtcRead
;!     _Read_Temperature
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!       ___lwdiv
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     i1___bmul
;!   _Charging_Control
;!     i1___bmul
;!   _PowerOnLedSequence
;!   _Update_LED_Slot
;!     i1___bmul
;!   i1_ADC_Sample
;!   i1___lldiv
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50     14      50       8      100.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      4      4C      10       95.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50     39      50       6      100.0%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     1C      36       4       67.5%
;!BITBANK0            50      0       0       3        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      A       D       1       92.9%
;!BITCOMMON            E      0       1       0        7.1%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     12F      12        0.0%
;!ABS                  0      0     12F      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 556 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       2
;;      Totals:         0       0       0       0       2
;;Total ram usage:        2 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ChargeProcess_Slot
;;		_Do_AdcSample
;;		_Do_NtcRead
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_System_Init
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	556
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	556
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	559
	
l8883:	
;main.c: 559: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
movwf	((??_main+0)^0100h+0+1),f
	movlw	241
movwf	((??_main+0)^0100h+0),f
	u14427:
decfsz	((??_main+0)^0100h+0),f
	goto	u14427
	decfsz	((??_main+0)^0100h+0+1),f
	goto	u14427
opt asmopt_pop

	line	560
# 560 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	563
	
l8885:	
;main.c: 563: System_Init();
	fcall	_System_Init
	line	567
	
l8887:	
;main.c: 567: uart_send_string("L1211 Charger V2.1\r\n");
	movlw	low(((STR_37)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_37)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	568
	
l8889:	
;main.c: 568: uart_send_string("Init...\r\n");
	movlw	low(((STR_38)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_38)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	572
;main.c: 572: while(1)
	
l466:	
	line	574
# 574 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	577
	
l8891:	
;main.c: 577: if(g_doAdcSample)
	btfss	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u14391
	goto	u14390
u14391:
	goto	l8899
u14390:
	line	579
	
l8893:	
;main.c: 578: {
;main.c: 579: g_doAdcSample = 0;
	bcf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	line	580
;main.c: 580: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	581
	
l8895:	
;main.c: 581: Do_AdcSample();
	fcall	_Do_AdcSample
	line	582
;main.c: 582: ChargeProcess_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_ChargeProcess_Slot
	line	584
	
l8897:	
;main.c: 584: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	588
	
l8899:	
;main.c: 585: }
;main.c: 588: if(g_doNtcRead)
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u14401
	goto	u14400
u14401:
	goto	l8907
u14400:
	line	590
	
l8901:	
;main.c: 589: {
;main.c: 590: g_doNtcRead = 0;
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	591
;main.c: 591: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	592
	
l8903:	
;main.c: 592: Do_NtcRead();
	fcall	_Do_NtcRead
	line	593
	
l8905:	
;main.c: 593: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	598
	
l8907:	
;main.c: 594: }
;main.c: 598: if(g_printFlag)
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u14411
	goto	u14410
u14411:
	goto	l466
u14410:
	line	600
	
l8909:	
;main.c: 599: {
;main.c: 600: g_printFlag = 0;
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	601
	
l8911:	
;main.c: 601: Print_SystemStatus();
	fcall	_Print_SystemStatus
	line	602
;main.c: 602: Print_NtcTemp();
	fcall	_Print_NtcTemp
	goto	l466
	global	start
	ljmp	start
	opt stack 0
	line	606
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 71 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1    1[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/900
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       1       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	71
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	71
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	76
	
l7361:	
# 76 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	77
# 77 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text1
	line	78
	
l7363:	
;main.c: 78: OSCCON = 0x72;
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	82
;main.c: 82: TRISA = 0xF0; PORTA = 0x0F;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	83
;main.c: 83: TRISB = 0x30; PORTB = 0x4F;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	84
;main.c: 84: TRISC = 0x07; PORTC = 0x00;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l7365:	
	clrf	(262)^0100h	;volatile
	line	86
	
l7367:	
;main.c: 86: TRISD = 0xF0; PORTD = 0x0F;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l7369:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	89
	
l7371:	
;main.c: 89: WPUA = 0x00; WPDA = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l7373:	
	clrf	(135)^080h	;volatile
	line	90
	
l7375:	
;main.c: 90: WPUB = 0x00; WPDB = 0x00;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l7377:	
	clrf	(7)	;volatile
	line	91
	
l7379:	
;main.c: 91: WPUC = 0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	92
	
l7381:	
;main.c: 92: WPUD = 0x00;
	clrf	(277)^0100h	;volatile
	line	95
	
l7383:	
;main.c: 95: IOCA = 0x00; IOCB = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l7385:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	98
	
l7387:	
;main.c: 98: CC0CON = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	99
	
l7389:	
;main.c: 99: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	106
	
l7391:	
;main.c: 106: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	107
	
l7393:	
;main.c: 107: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	108
	
l7395:	
;main.c: 108: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	109
	
l7397:	
;main.c: 109: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	112
	
l7399:	
;main.c: 112: AD_Init();
	fcall	_AD_Init
	line	116
	
l7401:	
;main.c: 116: uart_init();
	fcall	_uart_init
	line	124
;main.c: 124: OPTION_REG = 0x00;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	125
	
l7403:	
;main.c: 125: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	126
	
l7405:	
;main.c: 126: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	127
	
l7407:	
;main.c: 127: INTCON = 0xE0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	131
;main.c: 131: g_pwmDuty = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	132
;main.c: 132: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	133
	
l7409:	
;main.c: 133: RC5 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	134
	
l7411:	
;main.c: 134: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	135
	
l7413:	
;main.c: 135: RB6 = 1;
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	136
	
l7415:	
;main.c: 136: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	139
;main.c: 139: for(i = 0; i < 12; i++)
	bsf	status, 5	;RP0=1, select bank1
	clrf	(System_Init@i)^080h
	line	141
	
l7421:	
;main.c: 140: {
;main.c: 141: g_slot[i].state = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	142
;main.c: 142: g_slot[i].type = 0;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	143
;main.c: 143: g_slot[i].voltage = 0;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	144
;main.c: 144: g_slot[i].chargeTimer = 0;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	145
	
l7423:	
;main.c: 145: g_ccBlocks[i] = 0;
	bsf	status, 5	;RP0=1, select bank1
	movf	(System_Init@i)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	146
	
l7425:	
;main.c: 146: g_ovCnt[i] = 0;
	movf	(System_Init@i)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	139
	
l7427:	
	incf	(System_Init@i)^080h,f
	
l7429:	
	movlw	low(0Ch)
	subwf	(System_Init@i)^080h,w
	skipc
	goto	u11391
	goto	u11390
u11391:
	goto	l7421
u11390:
	line	150
	
l347:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
global __ptext2
__ptext2:	;psect for function _uart_init
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_init: []
	line	23
	
l7223:	
;uart_dbg.c: 23: TRISC &= (unsigned char)~0x10;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
;uart_dbg.c: 24: ANSEL2 &= (unsigned char)~0x10;
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
;uart_dbg.c: 25: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l502:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
global __ptext3
__ptext3:	;psect for function _AD_Init
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l7217:	
;adc_drv.c: 25: CC0CON = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
;adc_drv.c: 26: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	27
	
l7219:	
;adc_drv.c: 27: ADCON0 = 0X81;
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l7221:	
;adc_drv.c: 28: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	29
	
l479:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 382 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  d               2    0[BANK3 ] int 
;;  t               1   55[BANK1 ] unsigned char 
;;  bat_mv_long     4   50[BANK1 ] unsigned long 
;;  tc              1   54[BANK1 ] unsigned char 
;;  vx_mv           4   46[BANK1 ] unsigned long 
;;  v               2   44[BANK1 ] unsigned int 
;;  s               1   41[BANK1 ] unsigned char 
;;  pt              4   37[BANK1 ] unsigned long 
;;  vcc_mv          2    2[BANK3 ] unsigned int 
;;  i               1   56[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      24       4       0
;;      Temps:          0       0       8       0       0
;;      Totals:         0       0      32       4       0
;;Total ram usage:       36 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	382
global __ptext4
__ptext4:	;psect for function _Print_SystemStatus
psect	text4
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	382
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	387
	
l7717:	
;main.c: 384: unsigned char i;
;main.c: 385: unsigned int vcc_mv;
;main.c: 387: uart_send_string("\r\n== L1211 12CH CHARGER ");
	movlw	low(((STR_4)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	388
;main.c: 388: uart_send_string("V54M");
	movlw	low(((STR_5)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	389
;main.c: 389: uart_send_string(" ==\r\n");
	movlw	low(((STR_6)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	392
	
l7719:	
;main.c: 392: test_adc = ADC_Sample(31, 0);
	bsf	status, 5	;RP0=1, select bank1
	clrf	(ADC_Sample@adldo)^080h
	movlw	low(01Fh)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	393
	
l7721:	
;main.c: 393: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u12011
	goto	u12010
u12011:
	goto	l7727
u12010:
	line	395
	
l7723:	
;main.c: 394: {
;main.c: 395: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt)^080h

	line	396
	
l7725:	
;main.c: 396: vcc_mv = (unsigned int)pt;
	movf	(Print_SystemStatus@pt+1)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@vcc_mv+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@pt)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@vcc_mv)^0180h
	line	397
;main.c: 397: }
	goto	l420
	line	399
	
l7727:	
;main.c: 398: else
;main.c: 399: vcc_mv = 5000;
	movlw	088h
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@vcc_mv)^0180h
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv)^0180h)+1
	
l420:	
	line	401
;main.c: 401: g_vcc_mv = vcc_mv;
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_vcc_mv+1)^080h	;volatile
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_vcc_mv)^080h	;volatile
	line	403
	
l7729:	
;main.c: 403: uart_send_string("VCC=");
	movlw	low(((STR_7)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	404
	
l7731:	
;main.c: 404: uart_send_number(vcc_mv);
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	405
	
l7733:	
;main.c: 405: uart_send_string("mV T=");
	movlw	low(((STR_8)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	406
	
l7735:	
;main.c: 406: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(_Print_SystemStatus$743+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(_Print_SystemStatus$743)^080h
	
l7737:	
;main.c: 406: uart_send_number(g_temperature / 10U);
	movf	(_Print_SystemStatus$743+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$743)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	407
	
l7739:	
;main.c: 407: uart_send_string(".");
	movlw	low(((STR_9)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	408
	
l7741:	
;main.c: 408: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@divisor)^080h
	clrf	(___lwmod@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend)^080h
	fcall	___lwmod
	movf	(1+(?___lwmod))^080h,w
	movwf	(_Print_SystemStatus$744+1)^080h
	movf	(0+(?___lwmod))^080h,w
	movwf	(_Print_SystemStatus$744)^080h
	
l7743:	
;main.c: 408: uart_send_number(g_temperature % 10U);
	movf	(_Print_SystemStatus$744+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$744)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	409
	
l7745:	
;main.c: 409: uart_send_string("C IMP_LOCK=");
	movlw	low(((STR_10)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	410
	
l7747:	
;main.c: 410: uart_send_number(g_impCheckSlot == 0xFF ? 0xFFU : (unsigned int)g_impCheckSlot);
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u12021
	goto	u12020
u12021:
	goto	l7751
u12020:
	
l7749:	
	movf	(_g_impCheckSlot)^080h,w
	movwf	(_Print_SystemStatus$277)^080h
	clrf	(_Print_SystemStatus$277+1)^080h
	goto	l7753
	
l7751:	
	movlw	0FFh
	movwf	(_Print_SystemStatus$277)^080h
	clrf	(_Print_SystemStatus$277+1)^080h
	
l7753:	
	movf	(_Print_SystemStatus$277+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$277)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	411
	
l7755:	
;main.c: 411: uart_send_string("\r\n");
	movlw	low(((STR_11)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	418
	
l7757:	
;main.c: 418: for(i = 0; i < 12; i++)
	bsf	status, 5	;RP0=1, select bank1
	clrf	(Print_SystemStatus@i)^080h
	line	424
	
l7763:	
;main.c: 423: {
;main.c: 424: unsigned int v = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@v)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)^080h
	line	425
;main.c: 425: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@s)^080h
	line	427
	
l7765:	
;main.c: 427: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	428
	
l7767:	
;main.c: 428: uart_send_number((unsigned int)i + 1U);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	incf	(uart_send_number@num)^080h,f
	skipnz
	incf	(uart_send_number@num+1)^080h,f
	fcall	_uart_send_number
	line	429
;main.c: 429: uart_send_char('=');
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	430
	
l7769:	
;main.c: 430: uart_send_number(v);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(Print_SystemStatus@v)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	436
	
l7771:	
;main.c: 435: {
;main.c: 436: unsigned long vx_mv = (unsigned long)v * (unsigned long)vcc_mv / 4096UL;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Print_SystemStatus@v+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv)^080h

	
l7773:	
	movlw	0Ch
u12035:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3)^080h,f
	rrf	(Print_SystemStatus@vx_mv+2)^080h,f
	rrf	(Print_SystemStatus@vx_mv+1)^080h,f
	rrf	(Print_SystemStatus@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u12035

	line	437
	
l7775:	
;main.c: 437: if(vx_mv + 200U >= (unsigned long)vcc_mv)
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+0)^080h+0)
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	clrf	((??_Print_SystemStatus+0)^080h+0+2)
	clrf	((??_Print_SystemStatus+0)^080h+0+3)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+4)^080h+0)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	(Print_SystemStatus@vx_mv)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+0,f
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1)^080h,w
	goto	u12040
	goto	u12041
u12040:
	addwf	(??_Print_SystemStatus+4)^080h+1,f
u12041:
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2)^080h,w
	goto	u12042
	goto	u12043
u12042:
	addwf	(??_Print_SystemStatus+4)^080h+2,f
u12043:
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	subwf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u12055
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	subwf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u12055
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	subwf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u12055
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	subwf	0+(??_Print_SystemStatus+4)^080h+0,w
u12055:
	skipc
	goto	u12051
	goto	u12050
u12051:
	goto	l7779
u12050:
	line	439
	
l7777:	
;main.c: 438: {
;main.c: 439: uart_send_string(" OPEN");
	movlw	low(((STR_12)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	440
;main.c: 440: }
	goto	l7789
	line	443
	
l7779:	
;main.c: 441: else
;main.c: 442: {
;main.c: 443: unsigned long bat_mv_long = 124UL * vx_mv;
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(Print_SystemStatus@vx_mv)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long)^080h

	line	444
;main.c: 444: if(bat_mv_long > (206UL * (unsigned long)vcc_mv))
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(Print_SystemStatus@bat_mv_long+3)^080h,w
	subwf	(3+(?___lmul))^080h,w
	skipz
	goto	u12065
	movf	(Print_SystemStatus@bat_mv_long+2)^080h,w
	subwf	(2+(?___lmul))^080h,w
	skipz
	goto	u12065
	movf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	subwf	(1+(?___lmul))^080h,w
	skipz
	goto	u12065
	movf	(Print_SystemStatus@bat_mv_long)^080h,w
	subwf	(0+(?___lmul))^080h,w
u12065:
	skipnc
	goto	u12061
	goto	u12060
u12061:
	goto	l7789
u12060:
	line	446
	
l7781:	
;main.c: 445: {
;main.c: 446: bat_mv_long = (bat_mv_long - 206UL * (unsigned long)vcc_mv + 1000UL/2UL) / 1000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+3)
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+1)^080h
	movlw	032h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(Print_SystemStatus@bat_mv_long)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+0)
	movlw	0
	skipnc
	movlw	1
	addwf	(1+(?___lmul))^080h,w
	clrf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	addwf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	movf	(2+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+2),w
	clrf	((??_Print_SystemStatus+4)^080h+0+3)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	addwf	(Print_SystemStatus@bat_mv_long+2)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	movf	(3+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+3),w
	addwf	(Print_SystemStatus@bat_mv_long+3)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	0+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+0,f
	movf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	1+(??_Print_SystemStatus+4)^080h+0,w
	goto	u12070
	goto	u12071
u12070:
	addwf	(??_Print_SystemStatus+0)^080h+1,f
u12071:
	movf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	2+(??_Print_SystemStatus+4)^080h+0,w
	goto	u12072
	goto	u12073
u12072:
	addwf	(??_Print_SystemStatus+0)^080h+2,f
u12073:
	movf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incf	3+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long)^080h

	line	447
	
l7783:	
;main.c: 447: uart_send_string(" BAT(");
	movlw	low(((STR_13)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	448
	
l7785:	
;main.c: 448: uart_send_number((unsigned int)bat_mv_long);
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(Print_SystemStatus@bat_mv_long)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	449
	
l7787:	
;main.c: 449: uart_send_string("mV)");
	movlw	low(((STR_14)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	456
	
l7789:	
;main.c: 450: }
;main.c: 452: }
;main.c: 453: }
;main.c: 456: uart_send_char(' ');
	movlw	low(020h)
	fcall	_uart_send_char
	line	457
;main.c: 457: switch(s)
	goto	l7845
	line	459
	
l7791:	
	movlw	low(((STR_15)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7847
	line	461
	
l7793:	
;main.c: 461: uart_send_string("[DET]");
	movlw	low(((STR_16)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	464
	
l7795:	
;main.c: 464: if(g_slotRefV[i] > 0U)
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Print_SystemStatus@i)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)^080h+0+1
	movf	((??_Print_SystemStatus+0)^080h+0),w
iorwf	((??_Print_SystemStatus+0)^080h+1),w
	btfsc	status,2
	goto	u12081
	goto	u12080
u12081:
	goto	l7847
u12080:
	line	466
	
l7797:	
;main.c: 465: {
;main.c: 466: uart_send_string(" ref=");
	movlw	low(((STR_17)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	467
	
l7799:	
;main.c: 467: uart_send_number(g_slotRefV[i]);
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Print_SystemStatus@i)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(uart_send_number@num)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	goto	l7847
	line	470
	
l7801:	
	movlw	low(((STR_18)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7847
	line	471
	
l7803:	
	movlw	low(((STR_19)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7847
	line	472
	
l7805:	
	movlw	low(((STR_20)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7847
	line	473
	
l7807:	
	movlw	low(((STR_21)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7847
	line	474
	
l7809:	
	movlw	low(((STR_22)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7847
	line	477
	
l7811:	
;main.c: 476: {
;main.c: 477: unsigned char t = g_slot[(unsigned char)(i)].type;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@t)^080h
	line	478
	
l7813:	
;main.c: 478: if(t == 2 || t == 3)
		movlw	2
	xorwf	((Print_SystemStatus@t)^080h),w
	btfsc	status,2
	goto	u12091
	goto	u12090
u12091:
	goto	l7817
u12090:
	
l7815:	
		movlw	3
	xorwf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u12101
	goto	u12100
u12101:
	goto	l7819
u12100:
	line	479
	
l7817:	
;main.c: 479: uart_send_string("[Dry/NiMH ERR]");
	movlw	low(((STR_23)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7829
	line	480
	
l7819:	
;main.c: 480: else if(t == 1)
		decf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u12111
	goto	u12110
u12111:
	goto	l7823
u12110:
	line	481
	
l7821:	
;main.c: 481: uart_send_string("[Li-ion ERR]");
	movlw	low(((STR_24)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7829
	line	482
	
l7823:	
;main.c: 482: else if(t == 6)
		movlw	6
	xorwf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u12121
	goto	u12120
u12121:
	goto	l7827
u12120:
	line	483
	
l7825:	
;main.c: 483: uart_send_string("[Linear Li ERR]");
	movlw	low(((STR_25)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7829
	line	485
	
l7827:	
;main.c: 484: else
;main.c: 485: uart_send_string("[ERR]");
	movlw	low(((STR_26)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	488
	
l7829:	
;main.c: 488: if(g_slotRefV[i] > 0U)
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Print_SystemStatus@i)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)^080h+0+1
	movf	((??_Print_SystemStatus+0)^080h+0),w
iorwf	((??_Print_SystemStatus+0)^080h+1),w
	btfsc	status,2
	goto	u12131
	goto	u12130
u12131:
	goto	l7847
u12130:
	line	490
	
l7831:	
;main.c: 489: {
;main.c: 490: uart_send_string(" ref=");
	movlw	low(((STR_27)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7799
	line	495
	
l7835:	
	movlw	low(((STR_28)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7847
	line	497
	
l7837:	
;main.c: 497: uart_send_string("[DIO]");
	movlw	low(((STR_29)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	499
;main.c: 499: uart_send_string(" pre=");
	movlw	low(((STR_30)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	500
	
l7839:	
;main.c: 500: uart_send_number(g_impData & 0x0FFFU);
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(uart_send_number@num)^080h
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	501
;main.c: 501: break;
	goto	l7847
	line	502
	
l7841:	
	movlw	low(((STR_31)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7847
	line	457
	
l7845:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@s)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l7791
	xorlw	1^0	; case 1
	skipnz
	goto	l7793
	xorlw	2^1	; case 2
	skipnz
	goto	l7801
	xorlw	3^2	; case 3
	skipnz
	goto	l7803
	xorlw	4^3	; case 4
	skipnz
	goto	l7805
	xorlw	5^4	; case 5
	skipnz
	goto	l7807
	xorlw	6^5	; case 6
	skipnz
	goto	l7809
	xorlw	7^6	; case 7
	skipnz
	goto	l7811
	xorlw	8^7	; case 8
	skipnz
	goto	l7835
	xorlw	9^8	; case 9
	skipnz
	goto	l7837
	goto	l7841
	opt asmopt_pop

	line	506
	
l7847:	
;main.c: 506: uart_send_string(" ct=");
	movlw	low(((STR_32)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	507
	
l7849:	
;main.c: 507: uart_send_number(g_slot[(unsigned char)(i)].chargeTimer);
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	508
	
l7851:	
;main.c: 508: uart_send_string(" ty=");
	movlw	low(((STR_33)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	509
;main.c: 509: uart_send_number(g_slot[(unsigned char)(i)].type);
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	514
	
l7853:	
;main.c: 514: if(g_diodeTraceCnt > 0U && g_diodeTraceSlot == i)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	((_g_diodeTraceCnt)^080h),w
	btfsc	status,2
	goto	u12141
	goto	u12140
u12141:
	goto	l7889
u12140:
	
l7855:	
	movf	(_g_diodeTraceSlot)^080h,w
	xorwf	(Print_SystemStatus@i)^080h,w
	skipz
	goto	u12151
	goto	u12150
u12151:
	goto	l7889
u12150:
	line	517
	
l7857:	
;main.c: 515: {
;main.c: 516: unsigned char tc;
;main.c: 517: uart_send_string(" tr=");
	movlw	low(((STR_34)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_34)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	518
	
l7859:	
;main.c: 518: for(tc = 0; tc < g_diodeTraceCnt; tc++)
	bsf	status, 5	;RP0=1, select bank1
	clrf	(Print_SystemStatus@tc)^080h
	goto	l7883
	line	520
	
l7861:	
;main.c: 519: {
;main.c: 520: signed int d = (signed int)g_diodeTrace[tc] - 128;
	movf	(Print_SystemStatus@tc)^080h,w
	addlw	low(_g_diodeTrace|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@d)^0180h
	clrf	(Print_SystemStatus@d+1)^0180h
	
l7863:	
	movlw	-128
	addwf	(Print_SystemStatus@d)^0180h,f
	skipc
	decf	(Print_SystemStatus@d+1)^0180h,f
	line	521
	
l7865:	
;main.c: 521: if(d < 0)
	btfss	(Print_SystemStatus@d+1)^0180h,7
	goto	u12161
	goto	u12160
u12161:
	goto	l7871
u12160:
	line	523
	
l7867:	
;main.c: 522: {
;main.c: 523: uart_send_char('-');
	movlw	low(02Dh)
	fcall	_uart_send_char
	line	524
	
l7869:	
;main.c: 524: d = -d;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	comf	(Print_SystemStatus@d)^0180h,f
	comf	(Print_SystemStatus@d+1)^0180h,f
	incf	(Print_SystemStatus@d)^0180h,f
	skipnz
	incf	(Print_SystemStatus@d+1)^0180h,f
	line	525
;main.c: 525: }
	goto	l7875
	line	526
	
l7871:	
;main.c: 526: else if(d > 0)
	movf	(Print_SystemStatus@d+1)^0180h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u12175
	movlw	01h
	subwf	(Print_SystemStatus@d)^0180h,w
u12175:

	skipc
	goto	u12171
	goto	u12170
u12171:
	goto	l7875
u12170:
	line	527
	
l7873:	
;main.c: 527: uart_send_char('+');
	movlw	low(02Bh)
	fcall	_uart_send_char
	line	528
	
l7875:	
;main.c: 528: uart_send_number((unsigned int)d * 4U);
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@d+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_Print_SystemStatus+0)^080h+0+1
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@d)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_Print_SystemStatus+0)^080h+0
	clrc
	rlf	(??_Print_SystemStatus+0)^080h+0,f
	rlf	(??_Print_SystemStatus+0)^080h+1,f
	clrc
	rlf	(??_Print_SystemStatus+0)^080h+0,f
	rlf	(??_Print_SystemStatus+0)^080h+1,f
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(uart_send_number@num)^080h
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	529
	
l7877:	
;main.c: 529: if(tc + 1U < g_diodeTraceCnt)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_diodeTraceCnt)^080h,w
	movwf	(??_Print_SystemStatus+0)^080h+0
	clrf	(??_Print_SystemStatus+0)^080h+0+1
	movf	(Print_SystemStatus@tc)^080h,w
	addlw	low(01h)
	movwf	(??_Print_SystemStatus+2)^080h+0
	movlw	high(01h)
	skipnc
	movlw	(high(01h)+1)&0ffh
	movwf	((??_Print_SystemStatus+2)^080h+0)+1
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	subwf	1+(??_Print_SystemStatus+2)^080h+0,w
	skipz
	goto	u12185
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	subwf	0+(??_Print_SystemStatus+2)^080h+0,w
u12185:
	skipnc
	goto	u12181
	goto	u12180
u12181:
	goto	l7881
u12180:
	line	530
	
l7879:	
;main.c: 530: uart_send_char(',');
	movlw	low(02Ch)
	fcall	_uart_send_char
	line	518
	
l7881:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(Print_SystemStatus@tc)^080h,f
	
l7883:	
	movf	(_g_diodeTraceCnt)^080h,w
	subwf	(Print_SystemStatus@tc)^080h,w
	skipc
	goto	u12191
	goto	u12190
u12191:
	goto	l7861
u12190:
	line	532
	
l7885:	
;main.c: 531: }
;main.c: 532: g_diodeTraceCnt = 0;
	clrf	(_g_diodeTraceCnt)^080h
	line	533
	
l7887:	
;main.c: 533: g_diodeTraceSlot = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_diodeTraceSlot)^080h
	line	537
	
l7889:	
;main.c: 534: }
;main.c: 537: uart_send_string("\r\n");
	movlw	low(((STR_35)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_35)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	418
	
l7891:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(Print_SystemStatus@i)^080h,f
	
l7893:	
	movlw	low(0Ch)
	subwf	(Print_SystemStatus@i)^080h,w
	skipc
	goto	u12201
	goto	u12200
u12201:
	goto	l7763
u12200:
	line	540
	
l7895:	
;main.c: 539: }
;main.c: 540: uart_send_string("\r\n");
	movlw	low(((STR_36)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_36)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	541
	
l461:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 362 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	362
global __ptext5
__ptext5:	;psect for function _Print_NtcTemp
psect	text5
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	362
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	364
	
l7705:	
;main.c: 364: uart_send_string("NTC=");
	movlw	low(((STR_1)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	365
	
l7707:	
;main.c: 365: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(_Print_NtcTemp$741+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(_Print_NtcTemp$741)^080h
	
l7709:	
;main.c: 365: uart_send_number(g_temperature / 10U);
	movf	(_Print_NtcTemp$741+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$741)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	366
	
l7711:	
;main.c: 366: uart_send_string(".");
	movlw	low(((STR_2)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	367
	
l7713:	
;main.c: 367: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@divisor)^080h
	clrf	(___lwmod@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend)^080h
	fcall	___lwmod
	movf	(1+(?___lwmod))^080h,w
	movwf	(_Print_NtcTemp$742+1)^080h
	movf	(0+(?___lwmod))^080h,w
	movwf	(_Print_NtcTemp$742)^080h
;main.c: 367: uart_send_number(g_temperature % 10U);
	movf	(_Print_NtcTemp$742+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$742)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	368
	
l7715:	
;main.c: 368: uart_send_string("C\r\n");
	movlw	low(((STR_3)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	369
	
l416:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2    2[BANK1 ] PTR const unsigned char 
;;		 -> STR_38(10), STR_37(21), STR_36(3), STR_35(3), 
;;		 -> STR_34(5), STR_33(5), STR_32(5), STR_31(6), 
;;		 -> STR_30(6), STR_29(6), STR_28(6), STR_27(6), 
;;		 -> STR_26(6), STR_25(16), STR_24(13), STR_23(15), 
;;		 -> STR_22(7), STR_21(5), STR_20(5), STR_19(6), 
;;		 -> STR_18(6), STR_17(6), STR_16(6), STR_15(7), 
;;		 -> STR_14(4), STR_13(6), STR_12(6), STR_11(3), 
;;		 -> STR_10(12), STR_9(2), STR_8(6), STR_7(5), 
;;		 -> STR_6(6), STR_5(5), STR_4(25), STR_3(4), 
;;		 -> STR_2(2), STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
global __ptext6
__ptext6:	;psect for function _uart_send_string
psect	text6
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l7263:	
;uart_dbg.c: 63: while(*str != '\0')
	goto	l7269
	line	65
	
l7265:	
;uart_dbg.c: 64: {
;uart_dbg.c: 65: uart_send_char(*str++);
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	btemp+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str)^080h,w
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	fcall	stringtab
	fcall	_uart_send_char
	
l7267:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(uart_send_string@str)^080h,f
	skipnz
	incf	(uart_send_string@str+1)^080h,f
	line	66
# 66 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
clrwdt ;# 
psect	text6
	line	63
	
l7269:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(uart_send_string@str+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	btemp+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str)^080h,w
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u11251
	goto	u11250
u11251:
	goto	l7265
u11250:
	line	68
	
l515:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2    7[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    9[BANK1 ] unsigned char [6]
;;  j               1   16[BANK1 ] unsigned char 
;;  i               1   15[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      10       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext7
__ptext7:	;psect for function _uart_send_number
psect	text7
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 2
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l7271:	
;uart_dbg.c: 79: unsigned char buf[6];
;uart_dbg.c: 80: unsigned char i = 0;
	clrf	(uart_send_number@i)^080h
	line	84
	
l7273:	
;uart_dbg.c: 81: unsigned char j;
;uart_dbg.c: 84: if(num == 0)
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u11261
	goto	u11260
u11261:
	goto	l7285
u11260:
	line	86
	
l7275:	
;uart_dbg.c: 85: {
;uart_dbg.c: 86: uart_send_char('0');
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l519
	line	93
	
l7279:	
;uart_dbg.c: 92: {
;uart_dbg.c: 93: buf[i++] = '0' + (num % 10);
	movf	(uart_send_number@i)^080h,w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)^080h
	clrf	(___lwmod@divisor+1)^080h
	movf	(uart_send_number@num+1)^080h,w
	movwf	(___lwmod@dividend+1)^080h
	movf	(uart_send_number@num)^080h,w
	movwf	(___lwmod@dividend)^080h
	fcall	___lwmod
	movf	(0+(?___lwmod))^080h,w
	addlw	030h
	bcf	status, 7	;select IRP bank1
	movwf	indf
	
l7281:	
	incf	(uart_send_number@i)^080h,f
	line	94
	
l7283:	
;uart_dbg.c: 94: num /= 10;
	movlw	0Ah
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(uart_send_number@num+1)^080h,w
	movwf	(___lwdiv@dividend+1)^080h
	movf	(uart_send_number@num)^080h,w
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(uart_send_number@num)^080h
	line	91
	
l7285:	
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u11271
	goto	u11270
u11271:
	goto	l7279
u11270:
	line	98
	
l7287:	
;uart_dbg.c: 95: }
;uart_dbg.c: 98: for(j = i; j > 0; j--)
	movf	(uart_send_number@i)^080h,w
	movwf	(uart_send_number@j)^080h
	
l7289:	
	movf	((uart_send_number@j)^080h),w
	btfss	status,2
	goto	u11281
	goto	u11280
u11281:
	goto	l7293
u11280:
	goto	l519
	line	99
	
l7293:	
;uart_dbg.c: 99: uart_send_char(buf[(unsigned char)(j - 1)]);
	movf	(uart_send_number@j)^080h,w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l7295:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decf	(uart_send_number@j)^080h,f
	goto	l7289
	line	100
	
l519:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1    0[BANK1 ] unsigned char 
;;  i               1    1[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       2       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       1       2       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext8
__ptext8:	;psect for function _uart_send_char
psect	text8
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_char: [wreg+status,2+status,0]
;uart_send_char@c stored from wreg
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_char@c)^080h
	line	38
	
l7109:	
;uart_dbg.c: 37: unsigned char i;
;uart_dbg.c: 38: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	39
;uart_dbg.c: 39: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l7111:	
;uart_dbg.c: 40: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u14437:
decfsz	(??_uart_send_char+0)+0,f
	goto	u14437
	nop2
opt asmopt_pop

	line	41
	
l7113:	
;uart_dbg.c: 41: for(i = 0; i < 8; i++)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(uart_send_char@i)^080h
	line	42
	
l505:	
	line	43
;uart_dbg.c: 42: {
;uart_dbg.c: 43: if(c & 0x01)
	btfss	(uart_send_char@c)^080h,(0)&7
	goto	u10981
	goto	u10980
u10981:
	goto	l507
u10980:
	line	44
	
l7119:	
;uart_dbg.c: 44: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l7121
	line	45
	
l507:	
	line	46
;uart_dbg.c: 45: else
;uart_dbg.c: 46: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l7121:	
;uart_dbg.c: 47: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u14447:
decfsz	(??_uart_send_char+0)+0,f
	goto	u14447
	nop2
opt asmopt_pop

	line	48
	
l7123:	
;uart_dbg.c: 48: c >>= 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrc
	rrf	(uart_send_char@c)^080h,f
	line	41
	
l7125:	
	incf	(uart_send_char@i)^080h,f
	
l7127:	
	movlw	low(08h)
	subwf	(uart_send_char@i)^080h,w
	skipc
	goto	u10991
	goto	u10990
u10991:
	goto	l505
u10990:
	
l506:	
	line	50
;uart_dbg.c: 49: }
;uart_dbg.c: 50: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l7129:	
;uart_dbg.c: 51: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u14457:
decfsz	(??_uart_send_char+0)+0,f
	goto	u14457
	nop2
opt asmopt_pop

	line	52
	
l7131:	
;uart_dbg.c: 52: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l509:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK1 ] unsigned int 
;;  dividend        2    2[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1   26[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK1 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       4       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       4       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext9
__ptext9:	;psect for function ___lwmod
psect	text9
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l7197:	
	movf	((___lwmod@divisor)^080h),w
iorwf	((___lwmod@divisor+1)^080h),w
	btfsc	status,2
	goto	u11111
	goto	u11110
u11111:
	goto	l7213
u11110:
	line	14
	
l7199:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l7203
	line	16
	
l7201:	
	clrc
	rlf	(___lwmod@divisor)^080h,f
	rlf	(___lwmod@divisor+1)^080h,f
	line	17
	bcf	status, 5	;RP0=0, select bank0
	incf	(___lwmod@counter),f
	line	15
	
l7203:	
	bsf	status, 5	;RP0=1, select bank1
	btfss	(___lwmod@divisor+1)^080h,(15)&7
	goto	u11121
	goto	u11120
u11121:
	goto	l7201
u11120:
	line	20
	
l7205:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lwmod@divisor+1)^080h,w
	subwf	(___lwmod@dividend+1)^080h,w
	skipz
	goto	u11135
	movf	(___lwmod@divisor)^080h,w
	subwf	(___lwmod@dividend)^080h,w
u11135:
	skipc
	goto	u11131
	goto	u11130
u11131:
	goto	l7209
u11130:
	line	21
	
l7207:	
	movf	(___lwmod@divisor)^080h,w
	subwf	(___lwmod@dividend)^080h,f
	movf	(___lwmod@divisor+1)^080h,w
	skipc
	decf	(___lwmod@dividend+1)^080h,f
	subwf	(___lwmod@dividend+1)^080h,f
	line	22
	
l7209:	
	clrc
	rrf	(___lwmod@divisor+1)^080h,f
	rrf	(___lwmod@divisor)^080h,f
	line	23
	
l7211:	
	bcf	status, 5	;RP0=0, select bank0
	decfsz	(___lwmod@counter),f
	goto	u11141
	goto	u11140
u11141:
	goto	l7205
u11140:
	line	25
	
l7213:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lwmod@dividend+1)^080h,w
	movwf	(?___lwmod+1)^080h
	movf	(___lwmod@dividend)^080h,w
	movwf	(?___lwmod)^080h
	line	26
	
l1270:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	_Do_NtcRead

;; *************** function _Do_NtcRead *****************
;; Defined at:
;;		line 352 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Read_Temperature
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	352
global __ptext10
__ptext10:	;psect for function _Do_NtcRead
psect	text10
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	352
	global	__size_of_Do_NtcRead
	__size_of_Do_NtcRead	equ	__end_of_Do_NtcRead-_Do_NtcRead
	
_Do_NtcRead:	
;incstack = 0
	opt	stack 2
; Regs used in _Do_NtcRead: [wreg+status,2+status,0+pclath+cstack]
	line	354
	
l7703:	
;main.c: 354: Read_Temperature();
	fcall	_Read_Temperature
	line	355
	
l413:	
	return
	opt stack 0
GLOBAL	__end_of_Do_NtcRead
	__end_of_Do_NtcRead:
	signat	_Do_NtcRead,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 43 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   29[BANK1 ] unsigned long 
;;  temp_x10        2   35[BANK1 ] unsigned int 
;;  ntcVal          2   33[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   62[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Do_NtcRead
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	43
global __ptext11
__ptext11:	;psect for function _Read_Temperature
psect	text11
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	43
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 2
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	48
	
l7225:	
;charge_mgr.c: 45: unsigned int ntcVal;
;charge_mgr.c: 46: unsigned int temp_x10;
;charge_mgr.c: 48: test_adc = ADC_Sample(18, 0);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ADC_Sample@adldo)^080h
	movlw	low(012h)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	49
	
l7227:	
;charge_mgr.c: 49: if(0xA5 != test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u11151
	goto	u11150
u11151:
	goto	l7231
u11150:
	goto	l558
	line	52
	
l7231:	
;charge_mgr.c: 52: ntcVal = adresult;
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal)^080h
	line	53
;charge_mgr.c: 53: if(ntcVal < 100 || ntcVal > 3996)
	movlw	0
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u11161
	goto	u11160
u11161:
	goto	l558
u11160:
	
l7233:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u11171
	goto	u11170
u11171:
	goto	l7235
u11170:
	goto	l558
	line	58
	
l7235:	
;charge_mgr.c: 56: {
;charge_mgr.c: 57: unsigned long rt;
;charge_mgr.c: 58: rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	010h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0
	movwf	(___lldiv@divisor)^080h

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0)
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0+1)
	clrf	((??_Read_Temperature+0)^080h+0+2)
	clrf	((??_Read_Temperature+0)^080h+0+3)
	movf	0+(??_Read_Temperature+0)^080h+0,w
	subwf	(___lldiv@divisor)^080h,f
	movf	1+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)^080h+0,w
	goto	u11185
	goto	u11186
u11185:
	subwf	(___lldiv@divisor+1)^080h,f
u11186:
	movf	2+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)^080h+0,w
	goto	u11187
	goto	u11188
u11187:
	subwf	(___lldiv@divisor+2)^080h,f
u11188:
	movf	3+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)^080h+0,w
	goto	u11189
	goto	u11180
u11189:
	subwf	(___lldiv@divisor+3)^080h,f
u11180:

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0
	movwf	(___lmul@multiplicand+2)^080h
	movlw	027h
	movwf	(___lmul@multiplicand+1)^080h
	movlw	010h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt)^080h

	line	59
	
l7237:	
;charge_mgr.c: 59: if(rt >= 10000UL)
		movf	(Read_Temperature@rt+3)^080h,w
	btfss	status,2
	goto	u11190
	movf	(Read_Temperature@rt+2)^080h,w
	btfss	status,2
	goto	u11190
	movlw	39
	subwf	(Read_Temperature@rt+1)^080h,w
	skipz
	goto	u11193
	movlw	16
	subwf	(Read_Temperature@rt)^080h,w
	skipz
	goto	u11193
u11193:
	btfss	status,0
	goto	u11191
	goto	u11190

u11191:
	goto	l7243
u11190:
	line	60
	
l7239:	
;charge_mgr.c: 60: temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l7241:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0F0h
	movwf	((??_Read_Temperature+0)^080h+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)^080h+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+3)
	movf	(Read_Temperature@rt)^080h,w
	addwf	(??_Read_Temperature+0)^080h+0,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+1)^080h,w
	goto	u11200
	goto	u11201
u11200:
	addwf	(??_Read_Temperature+0)^080h+1,f
u11201:
	movf	(Read_Temperature@rt+2)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+2)^080h,w
	goto	u11202
	goto	u11203
u11202:
	addwf	(??_Read_Temperature+0)^080h+2,f
u11203:
	movf	(Read_Temperature@rt+3)^080h,w
	skipnc
	incf	(Read_Temperature@rt+3)^080h,w
	addwf	(??_Read_Temperature+0)^080h+3,f
	movf	3+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+3)^080h
	movf	2+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+2)^080h
	movf	1+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+1)^080h
	movf	0+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier)^080h

	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(0+(?___lldiv))^080h,w
	subwf	(Read_Temperature@temp_x10)^080h,f
	movf	(1+(?___lldiv))^080h,w
	skipc
	decf	(Read_Temperature@temp_x10+1)^080h,f
	subwf	(Read_Temperature@temp_x10+1)^080h,f
	goto	l7247
	line	62
	
l7243:	
;charge_mgr.c: 61: else
;charge_mgr.c: 62: temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0
	movwf	(___lmul@multiplier+3)^080h
	movlw	0
	movwf	(___lmul@multiplier+2)^080h
	movlw	027h
	movwf	(___lmul@multiplier+1)^080h
	movlw	010h
	movwf	(___lmul@multiplier)^080h

	movf	(Read_Temperature@rt)^080h,w
	subwf	(___lmul@multiplier)^080h,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+1)^080h,w
	subwf	(___lmul@multiplier+1)^080h,f
	movf	(Read_Temperature@rt+2)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+2)^080h,w
	subwf	(___lmul@multiplier+2)^080h,f
	movf	(Read_Temperature@rt+3)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+3)^080h,w
	subwf	(___lmul@multiplier+3)^080h,f
	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10)^080h
	
l7245:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10)^080h,f
	skipnc
	incf	(Read_Temperature@temp_x10+1)^080h,f
	line	63
	
l7247:	
;charge_mgr.c: 63: if(temp_x10 < 100U) temp_x10 = 100U;
	movlw	0
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipnc
	goto	u11211
	goto	u11210
u11211:
	goto	l564
u11210:
	
l7249:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l564:	
	line	64
;charge_mgr.c: 64: if(temp_x10 > 750U) temp_x10 = 750U;
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipc
	goto	u11221
	goto	u11220
u11221:
	goto	l565
u11220:
	
l7251:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)^080h
	movlw	02h
	movwf	((Read_Temperature@temp_x10)^080h)+1
	
l565:	
	line	67
;charge_mgr.c: 65: }
;charge_mgr.c: 67: g_temperature = temp_x10;
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature)
	line	68
	
l7253:	
;charge_mgr.c: 68: if((temp_x10 / 10U) >= 60)
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(Read_Temperature@temp_x10+1)^080h,w
	movwf	(___lwdiv@dividend+1)^080h
	movf	(Read_Temperature@temp_x10)^080h,w
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv))^080h,w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv))^080h,w
	skipc
	goto	u11231
	goto	u11230
u11231:
	goto	l7257
u11230:
	line	69
	
l7255:	
;charge_mgr.c: 69: g_tempProtect = 1;
	clrf	(_g_tempProtect)
	incf	(_g_tempProtect),f
	goto	l558
	line	70
	
l7257:	
;charge_mgr.c: 70: else if((temp_x10 / 10U) <= 50)
	movlw	0Ah
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(Read_Temperature@temp_x10+1)^080h,w
	movwf	(___lwdiv@dividend+1)^080h
	movf	(Read_Temperature@temp_x10)^080h,w
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv))^080h,w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv))^080h,w
	skipnc
	goto	u11241
	goto	u11240
u11241:
	goto	l558
u11240:
	line	71
	
l7259:	
;charge_mgr.c: 71: g_tempProtect = 0;
	clrf	(_g_tempProtect)
	line	74
	
l558:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	_Do_AdcSample

;; *************** function _Do_AdcSample *****************
;; Defined at:
;;		line 280 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  st              1   22[BANK1 ] unsigned char 
;;  dly             1   21[BANK1 ] unsigned char 
;;  ty              1   20[BANK1 ] unsigned char 
;;  ch              1   19[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       0       1       0       0
;;      Totals:         0       0       5       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	280
global __ptext12
__ptext12:	;psect for function _Do_AdcSample
psect	text12
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	280
	global	__size_of_Do_AdcSample
	__size_of_Do_AdcSample	equ	__end_of_Do_AdcSample-_Do_AdcSample
	
_Do_AdcSample:	
;incstack = 0
	opt	stack 3
; Regs used in _Do_AdcSample: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	282
	
l7639:	
;main.c: 282: unsigned char ch = s_adcChannels[g_scanIndex];
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_scanIndex),w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@ch)^080h
	line	283
	
l7641:	
;main.c: 283: unsigned char ty = g_slot[(unsigned char)(g_scanIndex)].type;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@ty)^080h
	line	284
	
l7643:	
;main.c: 284: unsigned char st = g_slot[(unsigned char)(g_scanIndex)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@st)^080h
	line	305
	
l7645:	
;main.c: 285: unsigned char dly;
;main.c: 300: if((ty == 6 &&
;main.c: 301: (st == 2 || st == 3 ||
;main.c: 302: st == 4 || st == 5)) ||
;main.c: 303: st == 1 ||
;main.c: 304: st == 8 ||
;main.c: 305: st == 9)
		movlw	6
	xorwf	((Do_AdcSample@ty)^080h),w
	btfss	status,2
	goto	u11841
	goto	u11840
u11841:
	goto	l7655
u11840:
	
l7647:	
		movlw	2
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11851
	goto	u11850
u11851:
	goto	l7661
u11850:
	
l7649:	
		movlw	3
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11861
	goto	u11860
u11861:
	goto	l7661
u11860:
	
l7651:	
		movlw	4
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11871
	goto	u11870
u11871:
	goto	l7661
u11870:
	
l7653:	
		movlw	5
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11881
	goto	u11880
u11881:
	goto	l7661
u11880:
	
l7655:	
		decf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11891
	goto	u11890
u11891:
	goto	l7661
u11890:
	
l7657:	
		movlw	8
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11901
	goto	u11900
u11901:
	goto	l7661
u11900:
	
l7659:	
		movlw	9
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u11911
	goto	u11910
u11911:
	goto	l7679
u11910:
	line	309
	
l7661:	
;main.c: 306: {
;main.c: 309: if(st == 1 || st == 8 || st == 9)
		decf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11921
	goto	u11920
u11921:
	goto	l7667
u11920:
	
l7663:	
		movlw	8
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11931
	goto	u11930
u11931:
	goto	l7667
u11930:
	
l7665:	
		movlw	9
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u11941
	goto	u11940
u11941:
	goto	l7679
u11940:
	line	311
	
l7667:	
;main.c: 310: {
;main.c: 311: for(dly = 0; dly < 20; dly++)
	clrf	(Do_AdcSample@dly)^080h
	line	312
	
l7673:	
;main.c: 312: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_Do_AdcSample+0)^080h+0),f
	u14467:
decfsz	(??_Do_AdcSample+0)^080h+0,f
	goto	u14467
	nop
opt asmopt_pop

	line	311
	
l7675:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(Do_AdcSample@dly)^080h,f
	
l7677:	
	movlw	low(014h)
	subwf	(Do_AdcSample@dly)^080h,w
	skipc
	goto	u11951
	goto	u11950
u11951:
	goto	l7673
u11950:
	goto	l7683
	line	316
	
l7679:	
;main.c: 314: else
;main.c: 315: {
;main.c: 316: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_Do_AdcSample+0)^080h+0),f
	u14477:
decfsz	(??_Do_AdcSample+0)^080h+0,f
	goto	u14477
	nop
opt asmopt_pop

	line	324
	
l7683:	
;main.c: 322: }
;main.c: 324: test_adc = ADC_Sample(ch, 0);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ADC_Sample@adldo)^080h
	movf	(Do_AdcSample@ch)^080h,w
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	326
	
l7685:	
;main.c: 326: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u11961
	goto	u11960
u11961:
	goto	l7699
u11960:
	line	331
	
l7687:	
;main.c: 327: {
;main.c: 330: if(ty == 6 && (st == 4 || st == 5)
;main.c: 331: && adresult >= 3990)
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	((Do_AdcSample@ty)^080h),w
	btfss	status,2
	goto	u11971
	goto	u11970
u11971:
	goto	l7697
u11970:
	
l7689:	
		movlw	4
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11981
	goto	u11980
u11981:
	goto	l7693
u11980:
	
l7691:	
		movlw	5
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u11991
	goto	u11990
u11991:
	goto	l7697
u11990:
	
l7693:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_adresult+1),w	;volatile
	movlw	096h
	skipnz
	subwf	(_adresult),w	;volatile
	skipc
	goto	u12001
	goto	u12000
u12001:
	goto	l7697
u12000:
	goto	l7701
	line	337
	
l7697:	
;main.c: 335: else
;main.c: 336: {
;main.c: 337: g_slot[g_scanIndex].voltage = adresult;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	movf	(_adresult),w	;volatile
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_adresult+1),w	;volatile
	movwf	indf
	goto	l7701
	line	341
	
l7699:	
;main.c: 340: else
;main.c: 341: g_slot[g_scanIndex].voltage = 0;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	343
	
l7701:	
;main.c: 343: g_scanPhase = 1;
	movlw	low(01h)
	movwf	(_g_scanPhase)	;volatile
	line	344
	
l410:	
	return
	opt stack 0
GLOBAL	__end_of_Do_AdcSample
	__end_of_Do_AdcSample:
	signat	_Do_AdcSample,89
	global	_ChargeProcess_Slot

;; *************** function _ChargeProcess_Slot *****************
;; Defined at:
;;		line 153 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   19[BANK3 ] unsigned char 
;;  pre             2   12[BANK3 ] unsigned int 
;;  bat_mv_long     4   36[BANK1 ] unsigned long 
;;  vx_mv           4   32[BANK1 ] unsigned long 
;;  bat_mv          2    4[BANK3 ] unsigned int 
;;  diff            2   10[BANK3 ] int 
;;  bat_mv_long     4   52[BANK1 ] unsigned long 
;;  vx_mv           4   48[BANK1 ] unsigned long 
;;  bat_mv          2    8[BANK3 ] unsigned int 
;;  bat_mv_long     4   44[BANK1 ] unsigned long 
;;  vx_mv           4   40[BANK1 ] unsigned long 
;;  bat_mv          2    6[BANK3 ] unsigned int 
;;  v_ref           2    2[BANK3 ] unsigned int 
;;  v_init          2   30[BANK1 ] unsigned int 
;;  v               2    0[BANK2 ] unsigned int 
;;  ct              2   17[BANK3 ] unsigned int 
;;  tick            2    0        unsigned int 
;;  ty              1   16[BANK3 ] unsigned char 
;;  st              1   56[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/B00
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      27      20       2
;;      Temps:          0       0       5       0       0
;;      Totals:         0       0      32      20       2
;;Total ram usage:       54 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		_Detect_BatteryType
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___wmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	153
global __ptext13
__ptext13:	;psect for function _ChargeProcess_Slot
psect	text13
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	153
	global	__size_of_ChargeProcess_Slot
	__size_of_ChargeProcess_Slot	equ	__end_of_ChargeProcess_Slot-_ChargeProcess_Slot
	
_ChargeProcess_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _ChargeProcess_Slot: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
;ChargeProcess_Slot@idx stored from wreg
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@idx)^0180h
	line	157
	
l7897:	
	line	159
	
l7899:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l7901:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	
l7903:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(ChargeProcess_Slot@v)^0100h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v+1)^0100h
	
l7905:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ct)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@ct+1)^0180h
	goto	l8763
	line	168
	
l7907:	
;charge_mgr.c: 168: if(v >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12211
	goto	u12210
u12211:
	goto	l7913
u12210:
	line	170
	
l7909:	
;charge_mgr.c: 169: {
;charge_mgr.c: 170: if(ct < (300))
	movlw	01h
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	02Ch
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u12221
	goto	u12220
u12221:
	goto	l7913
u12220:
	line	172
	
l7911:	
;charge_mgr.c: 171: {
;charge_mgr.c: 172: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	173
;charge_mgr.c: 173: break;
	goto	l8765
	line	176
	
l7913:	
;charge_mgr.c: 174: }
;charge_mgr.c: 175: }
;charge_mgr.c: 176: ct = 0;
	bsf	status, 5	;RP0=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	177
	
l7915:	
;charge_mgr.c: 177: st = 1;
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@st)^080h
	incf	(ChargeProcess_Slot@st)^080h,f
	line	178
	
l7917:	
;charge_mgr.c: 178: g_ccBlocks[idx] = 0;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	180
	
l7919:	
;charge_mgr.c: 180: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12234
u12235:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12234:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12235
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	183
	
l7921:	
;charge_mgr.c: 183: if(v < 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12241
	goto	u12240
u12241:
	goto	l7925
u12240:
	line	184
	
l7923:	
;charge_mgr.c: 184: g_slotRefV[idx] = v;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	goto	l8765
	line	186
	
l7925:	
;charge_mgr.c: 185: else
;charge_mgr.c: 186: g_slotRefV[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l8765
	line	190
	
l7927:	
;charge_mgr.c: 190: ct += tick;
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	193
	
l7929:	
;charge_mgr.c: 193: if(ct == 1)
		decf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u12251
	goto	u12250
u12251:
	goto	l7935
u12250:
	line	195
	
l7931:	
;charge_mgr.c: 194: {
;charge_mgr.c: 195: g_stableCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	196
	
l7933:	
;charge_mgr.c: 196: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12264
u12265:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12264:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12265
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	199
	
l7935:	
;charge_mgr.c: 197: }
;charge_mgr.c: 199: if(ct < (30))
	movlw	0
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	01Eh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u12271
	goto	u12270
u12271:
	goto	l7939
u12270:
	goto	l8765
	line	217
	
l7939:	
;charge_mgr.c: 209: }
;charge_mgr.c: 217: if(ct == (30))
		movlw	30
	xorwf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u12281
	goto	u12280
u12281:
	goto	l7947
u12280:
	line	219
	
l7941:	
;charge_mgr.c: 218: {
;charge_mgr.c: 219: g_slotRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	220
	
l7943:	
;charge_mgr.c: 220: if(v > 2900)
	movlw	0Bh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12291
	goto	u12290
u12291:
	goto	l8765
u12290:
	line	221
	
l7945:	
;charge_mgr.c: 221: g_capFlag |= (unsigned int)1 << idx;
	bsf	status, 5	;RP0=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12304
u12305:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12304:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12305
	
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_capFlag+1)^080h,f
	goto	l8765
	line	224
	
l7947:	
;charge_mgr.c: 223: }
;charge_mgr.c: 224: if(v > 2900 && v < 3990)
	movlw	0Bh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12311
	goto	u12310
u12311:
	goto	l8009
u12310:
	
l7949:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12321
	goto	u12320
u12321:
	goto	l8009
u12320:
	line	236
	
l7951:	
;charge_mgr.c: 225: {
;charge_mgr.c: 235: if(!(g_capFlag & ((unsigned int)1 << idx)) && ty != 5 &&
;charge_mgr.c: 236: v <= 3500)
	bsf	status, 5	;RP0=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12334
u12335:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12334:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12335
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfss	status,2
	goto	u12341
	goto	u12340
u12341:
	goto	l7965
u12340:
	
l7953:	
		movlw	5
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12351
	goto	u12350
u12351:
	goto	l7965
u12350:
	
l7955:	
	movlw	0Dh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0ADh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12361
	goto	u12360
u12361:
	goto	l7965
u12360:
	line	238
	
l7957:	
;charge_mgr.c: 237: {
;charge_mgr.c: 238: ct = 0;
	bsf	status, 5	;RP0=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	239
	
l7959:	
;charge_mgr.c: 239: g_slotRefV[idx] = 0;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	240
	
l7961:	
;charge_mgr.c: 240: g_stableCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	241
	
l7963:	
;charge_mgr.c: 241: g_detectLowCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	242
;charge_mgr.c: 242: break;
	goto	l8765
	line	252
	
l7965:	
;charge_mgr.c: 243: }
;charge_mgr.c: 252: unsigned int v_init = g_slotRefV[idx];
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@v_init)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_init+1)^080h
	line	254
;charge_mgr.c: 254: if(g_stableCnt[idx] >= 20)
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipc
	goto	u12371
	goto	u12370
u12371:
	goto	l7995
u12370:
	line	259
	
l7967:	
;charge_mgr.c: 255: {
;charge_mgr.c: 259: g_highVFlag |= (unsigned int)1 << idx;
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12384
u12385:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12384:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12385
	
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_highVFlag+1)^080h,f
	line	261
	
l7969:	
;charge_mgr.c: 261: if(v <= 2900)
	movlw	0Bh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12391
	goto	u12390
u12391:
	goto	l7977
u12390:
	line	264
	
l7971:	
;charge_mgr.c: 262: {
;charge_mgr.c: 264: g_capFlag &= ~((unsigned int)1 << idx);
	bsf	status, 5	;RP0=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12404
u12405:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12404:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12405
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	265
	
l7973:	
;charge_mgr.c: 265: g_stableCnt[idx] = 0;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	266
	
l7975:	
;charge_mgr.c: 266: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12414
u12415:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12414:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12415
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	267
;charge_mgr.c: 267: }
	goto	l8021
	line	268
	
l7977:	
;charge_mgr.c: 268: else if(ct < (30) + (100))
	movlw	0
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	082h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u12421
	goto	u12420
u12421:
	goto	l7989
u12420:
	line	277
	
l7979:	
;charge_mgr.c: 269: {
;charge_mgr.c: 276: if((g_highVFlag & ((unsigned int)1 << idx)) &&
;charge_mgr.c: 277: ct >= (30) + 25U)
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12434
u12435:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12434:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12435
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u12441
	goto	u12440
u12441:
	goto	l7923
u12440:
	
l7981:	
	movlw	0
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	037h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12451
	goto	u12450
u12451:
	goto	l7923
u12450:
	line	290
	
l7989:	
;charge_mgr.c: 290: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12464
u12465:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12464:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12465
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	291
	
l7991:	
;charge_mgr.c: 291: g_stableCnt[idx] = 0;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	292
	
l7993:	
;charge_mgr.c: 292: ty = 5;
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	293
;charge_mgr.c: 293: goto amb_check;
	goto	l8051
	line	299
	
l7995:	
;charge_mgr.c: 296: else
;charge_mgr.c: 297: {
;charge_mgr.c: 299: if(v + 50 < v_init)
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	addlw	low(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(ChargeProcess_Slot@v_init+1)^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u12475
	movf	(ChargeProcess_Slot@v_init)^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u12475:
	skipnc
	goto	u12471
	goto	u12470
u12471:
	goto	l7999
u12470:
	line	302
	
l7997:	
;charge_mgr.c: 300: {
;charge_mgr.c: 302: g_slotRefV[idx] = v;
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	303
;charge_mgr.c: 303: g_stableCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	304
;charge_mgr.c: 304: }
	goto	l606
	line	308
	
l7999:	
;charge_mgr.c: 305: else
;charge_mgr.c: 306: {
;charge_mgr.c: 308: g_slotRefV[idx] = v;
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	309
;charge_mgr.c: 309: g_stableCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	310
	
l606:	
	line	311
;charge_mgr.c: 310: }
;charge_mgr.c: 311: if(g_stableCnt[idx] < 20)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u12481
	goto	u12480
u12481:
	goto	l8003
u12480:
	goto	l8765
	line	314
	
l8003:	
;charge_mgr.c: 314: if(g_capFlag & ((unsigned int)1 << idx))
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12494
u12495:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12494:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12495
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u12501
	goto	u12500
u12501:
	goto	l8007
u12500:
	goto	l8765
	line	316
	
l8007:	
;charge_mgr.c: 316: g_stableCnt[idx] = 0;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8021
	line	319
	
l8009:	
;charge_mgr.c: 319: else if(ct < (30) + (100) && v < 3990)
	movlw	0
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	082h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u12511
	goto	u12510
u12511:
	goto	l8021
u12510:
	
l8011:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12521
	goto	u12520
u12521:
	goto	l8021
u12520:
	line	321
	
l8013:	
;charge_mgr.c: 320: {
;charge_mgr.c: 321: unsigned int v_ref = g_slotRefV[idx];
	bsf	status, 5	;RP0=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_ref)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_ref+1)^0180h
	line	322
	
l8015:	
;charge_mgr.c: 322: if(v_ref < 3990 && v + 50 < v_ref)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v_ref+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v_ref)^0180h,w
	skipnc
	goto	u12531
	goto	u12530
u12531:
	goto	l8021
u12530:
	
l8017:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	addlw	low(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_ref+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u12545
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_ref)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u12545:
	skipnc
	goto	u12541
	goto	u12540
u12541:
	goto	l8021
u12540:
	goto	l7923
	line	332
	
l8021:	
;charge_mgr.c: 326: }
;charge_mgr.c: 327: }
;charge_mgr.c: 332: if(g_capFlag & ((unsigned int)1 << idx))
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12554
u12555:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12554:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12555
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u12561
	goto	u12560
u12561:
	goto	l8029
u12560:
	line	334
	
l8023:	
;charge_mgr.c: 333: {
;charge_mgr.c: 334: g_capFlag &= ~((unsigned int)1 << idx);
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12574
u12575:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12574:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12575
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	335
	
l8025:	
;charge_mgr.c: 335: g_detectLowCnt[idx] = 0;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	336
	
l8027:	
;charge_mgr.c: 336: ty = 5;
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	337
;charge_mgr.c: 337: }
	goto	l613
	line	340
	
l8029:	
;charge_mgr.c: 338: else
;charge_mgr.c: 339: {
;charge_mgr.c: 340: ty = Detect_BatteryType(v);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Detect_BatteryType@voltage+1)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Detect_BatteryType@voltage)^080h
	fcall	_Detect_BatteryType
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	348
	
l8031:	
;charge_mgr.c: 347: if(ty == 0 && v >= 3990 &&
;charge_mgr.c: 348: ct >= (30) + (100))
	movf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12581
	goto	u12580
u12581:
	goto	l613
u12580:
	
l8033:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12591
	goto	u12590
u12591:
	goto	l613
u12590:
	
l8035:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	082h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12601
	goto	u12600
u12601:
	goto	l613
u12600:
	goto	l8027
	line	350
	
l613:	
	line	354
;charge_mgr.c: 350: }
;charge_mgr.c: 354: if(v < 500)
	movlw	01h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0F4h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12611
	goto	u12610
u12611:
	goto	l8043
u12610:
	line	356
	
l8039:	
;charge_mgr.c: 355: {
;charge_mgr.c: 356: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	357
;charge_mgr.c: 357: if(g_detectLowCnt[idx] < 5)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u12621
	goto	u12620
u12621:
	goto	l8051
u12620:
	goto	l8765
	line	361
	
l8043:	
;charge_mgr.c: 361: else if(ty != 5 && ty != 1 && ty != 6)
		movlw	5
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12631
	goto	u12630
u12631:
	goto	l8051
u12630:
	
l8045:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12641
	goto	u12640
u12641:
	goto	l8051
u12640:
	
l8047:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12651
	goto	u12650
u12651:
	goto	l8051
u12650:
	line	363
	
l8049:	
;charge_mgr.c: 362: {
;charge_mgr.c: 363: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	367
	
l8051:	
;charge_mgr.c: 367: if(ty == 5)
		movlw	5
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12661
	goto	u12660
u12661:
	goto	l8081
u12660:
	line	374
	
l8053:	
;charge_mgr.c: 368: {
;charge_mgr.c: 374: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	375
;charge_mgr.c: 375: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12671
	goto	u12670
u12671:
	goto	l8057
u12670:
	goto	l8765
	line	379
	
l8057:	
;charge_mgr.c: 379: if(g_impCheckSlot != 0xFF && g_impCheckSlot != idx)
	bcf	status, 6	;RP1=0, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u12681
	goto	u12680
u12681:
	goto	l8063
u12680:
	
l8059:	
	movf	(_g_impCheckSlot)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	xorwf	(ChargeProcess_Slot@idx)^0180h,w
	skipnz
	goto	u12691
	goto	u12690
u12691:
	goto	l8063
u12690:
	goto	l8765
	line	381
	
l8063:	
;charge_mgr.c: 381: g_impCheckSlot = idx;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	385
	
l8065:	
;charge_mgr.c: 385: if(0xA5 == ADC_Sample(31, 0))
	clrf	(ADC_Sample@adldo)^080h
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u12701
	goto	u12700
u12701:
	goto	l622
u12700:
	line	386
	
l8067:	
;charge_mgr.c: 386: g_vcc_mv = (unsigned int)((4096UL * 1200UL) / adresult);
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(0+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	
l622:	
	line	390
;charge_mgr.c: 390: g_impData = v | ((unsigned int)(((g_vcc_mv + 50U) / 100U) - 38U) << 12);
	movlw	064h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(032h)
	movwf	(___lwdiv@dividend)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(_g_impData+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(_g_impData)^080h
	
l8069:	
	movlw	0Ch
	
u12715:
	clrc
	rlf	(_g_impData)^080h,f
	rlf	(_g_impData+1)^080h,f
	addlw	-1
	skipz
	goto	u12715
	
l8071:	
	movlw	(0A000h >> 8)
	addwf	(_g_impData+1)^080h,f
	
l8073:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	iorwf	(_g_impData)^080h,f
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	iorwf	(_g_impData+1)^080h,f
	line	391
	
l8075:	
;charge_mgr.c: 391: st = 8;
	movlw	low(08h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	392
	
l8077:	
;charge_mgr.c: 392: ct = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	393
	
l8079:	
;charge_mgr.c: 393: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	395
	
l8081:	
;charge_mgr.c: 394: }
;charge_mgr.c: 395: if(ty == 1 || ty == 6)
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12721
	goto	u12720
u12721:
	goto	l8085
u12720:
	
l8083:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12731
	goto	u12730
u12731:
	goto	l8137
u12730:
	line	398
	
l8085:	
;charge_mgr.c: 396: {
;charge_mgr.c: 398: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	399
;charge_mgr.c: 399: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12741
	goto	u12740
u12741:
	goto	l8089
u12740:
	goto	l8765
	line	401
	
l8089:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv)^080h

	
l8091:	
	movlw	0Ch
u12755:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u12755

	
l8093:	
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long)^080h

	
l8095:	
	movf	(ChargeProcess_Slot@vx_mv+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12761
	addwf	(ChargeProcess_Slot@bat_mv_long+1)^080h,f
u12761:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12762
	addwf	(ChargeProcess_Slot@bat_mv_long+2)^080h,f
u12762:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12763
	addwf	(ChargeProcess_Slot@bat_mv_long+3)^080h,f
u12763:

	
l8097:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	goto	u12770
	goto	u12771
u12770:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u12771:
	movf	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	goto	u12772
	goto	u12773
u12772:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u12773:
	movf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv)^0180h
	
l8099:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u12781
	goto	u12780
u12781:
	goto	l8103
u12780:
	
l8101:	
	movlw	low(02h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l8129
	
l8103:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u12791
	goto	u12790
u12791:
	goto	l8107
u12790:
	
l8105:	
	movlw	low(03h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l8129
	
l8107:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipc
	goto	u12801
	goto	u12800
u12801:
	goto	l8121
u12800:
	
l8109:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u12811
	goto	u12810
u12811:
	goto	l8113
u12810:
	
l8111:	
	movlw	low(07h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l8129
	
l8113:	
	movlw	low(05h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l8115:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	
l8117:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l8119:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8129
	
l8121:	
	movlw	low(04h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l8123:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l8125:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	goto	l8119
	
l8129:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	
l8131:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l8133:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	
l8135:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	bcf	indf+(7/8),(7)&7
	goto	l8765
	line	403
	
l8137:	
;charge_mgr.c: 403: else if(ty == 0)
	movf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12821
	goto	u12820
u12821:
	goto	l8147
u12820:
	line	408
	
l8139:	
;charge_mgr.c: 404: {
;charge_mgr.c: 408: if(v >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12831
	goto	u12830
u12831:
	goto	l8143
u12830:
	goto	l8765
	line	410
	
l8143:	
;charge_mgr.c: 410: st = 7;
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7963
	line	413
	
l8147:	
;charge_mgr.c: 413: else if(ty == 2 || ty == 3)
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12841
	goto	u12840
u12841:
	goto	l8143
u12840:
	
l8149:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12851
	goto	u12850
u12851:
	goto	l8765
u12850:
	goto	l8143
	line	421
	
l8155:	
;charge_mgr.c: 421: ct += tick;
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	422
;charge_mgr.c: 422: if(ct < 5)
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	05h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u12861
	goto	u12860
u12861:
	goto	l8159
u12860:
	goto	l8765
	line	427
	
l8159:	
;charge_mgr.c: 425: {
;charge_mgr.c: 427: if(0xA5 == ADC_Sample(31, 0))
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ADC_Sample@adldo)^080h
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u12871
	goto	u12870
u12871:
	goto	l8163
u12870:
	line	428
	
l8161:	
;charge_mgr.c: 428: g_vcc_mv = (unsigned int)((4096UL * 1200UL) / adresult);
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(0+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	line	434
	
l8163:	
;charge_mgr.c: 434: if(v >= 4050U && (g_impData & 0x0FFFU) >= 4050U)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0D2h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12881
	goto	u12880
u12881:
	goto	l8173
u12880:
	
l8165:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0D2h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u12891
	goto	u12890
u12891:
	goto	l8173
u12890:
	line	436
	
l8167:	
;charge_mgr.c: 435: {
;charge_mgr.c: 436: ty = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	437
;charge_mgr.c: 437: st = 0;
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@st)^080h
	line	438
	
l8169:	
;charge_mgr.c: 438: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	line	439
	
l8171:	
;charge_mgr.c: 439: g_highVFlag &= ~((unsigned int)1 << idx);
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12904
u12905:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12904:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12905
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	440
;charge_mgr.c: 440: break;
	goto	l8765
	line	446
	
l8173:	
;charge_mgr.c: 441: }
;charge_mgr.c: 446: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 300U && v >= 3990)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)^080h
	clrf	(___wmul@multiplier+1)^080h
	movlw	0Fh
	andwf	(___wmul@multiplier)^080h,f
	clrf	(___wmul@multiplier+1)^080h
	movlw	026h
	addwf	(___wmul@multiplier)^080h,f
	skipnc
	incf	(___wmul@multiplier+1)^080h,f
	movlw	064h
	movwf	(___wmul@multiplicand)^080h
	clrf	(___wmul@multiplicand+1)^080h
	fcall	___wmul
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(012Ch)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(012Ch)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(1+(?___wmul))^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u12915
	movf	(0+(?___wmul))^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u12915:
	skipnc
	goto	u12911
	goto	u12910
u12911:
	goto	l8181
u12910:
	
l8175:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12921
	goto	u12920
u12921:
	goto	l8181
u12920:
	line	448
	
l8177:	
;charge_mgr.c: 447: {
;charge_mgr.c: 448: ty = 2;
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	449
;charge_mgr.c: 449: st = 7;
	movlw	low(07h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	450
;charge_mgr.c: 450: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	goto	l8171
	line	456
	
l8181:	
;charge_mgr.c: 453: }
;charge_mgr.c: 456: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 200U)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)^080h
	clrf	(___wmul@multiplier+1)^080h
	movlw	0Fh
	andwf	(___wmul@multiplier)^080h,f
	clrf	(___wmul@multiplier+1)^080h
	movlw	026h
	addwf	(___wmul@multiplier)^080h,f
	skipnc
	incf	(___wmul@multiplier+1)^080h,f
	movlw	064h
	movwf	(___wmul@multiplicand)^080h
	clrf	(___wmul@multiplicand+1)^080h
	fcall	___wmul
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(0C8h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(1+(?___wmul))^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u12935
	movf	(0+(?___wmul))^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u12935:
	skipnc
	goto	u12931
	goto	u12930
u12931:
	goto	l8185
u12930:
	goto	l8215
	line	467
	
l8185:	
;charge_mgr.c: 465: if(!(g_highVFlag & ((unsigned int)1 << idx)) &&
;charge_mgr.c: 466: ((g_impData & 0x0FFFU) > v) &&
;charge_mgr.c: 467: ((g_impData & 0x0FFFU) - v) > 1000U)
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12944
u12945:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12944:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12945
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfss	status,2
	goto	u12951
	goto	u12950
u12951:
	goto	l8197
u12950:
	
l8187:	
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	skipz
	goto	u12965
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v)^0100h,w
u12965:
	skipnc
	goto	u12961
	goto	u12960
u12961:
	goto	l8197
u12960:
	
l8189:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	03h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0E9h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u12971
	goto	u12970
u12971:
	goto	l8197
u12970:
	line	469
	
l8191:	
;charge_mgr.c: 468: {
;charge_mgr.c: 469: ty = 3;
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	470
;charge_mgr.c: 470: st = 7;
	movlw	low(07h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	471
;charge_mgr.c: 471: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	line	472
	
l8193:	
;charge_mgr.c: 472: g_highVFlag &= ~((unsigned int)1 << idx);
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12984
u12985:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12984:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12985
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	goto	l7963
	line	481
	
l8197:	
;charge_mgr.c: 475: }
;charge_mgr.c: 480: if(((g_impData & 0x0FFFU) > 3500) &&
;charge_mgr.c: 481: ((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) <= g_vcc_mv + 200U))
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Dh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0ADh
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u12991
	goto	u12990
u12991:
	goto	l8203
u12990:
	
l8199:	
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)^080h
	clrf	(___wmul@multiplier+1)^080h
	movlw	0Fh
	andwf	(___wmul@multiplier)^080h,f
	clrf	(___wmul@multiplier+1)^080h
	movlw	026h
	addwf	(___wmul@multiplier)^080h,f
	skipnc
	incf	(___wmul@multiplier+1)^080h,f
	movlw	064h
	movwf	(___wmul@multiplicand)^080h
	clrf	(___wmul@multiplicand+1)^080h
	fcall	___wmul
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(0C8h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(1+(?___wmul))^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u13005
	movf	(0+(?___wmul))^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u13005:
	skipc
	goto	u13001
	goto	u13000
u13001:
	goto	l8203
u13000:
	goto	l8207
	line	488
	
l8203:	
	line	494
	
l8207:	
;charge_mgr.c: 494: st = 9;
	movlw	low(09h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	495
	
l8209:	
;charge_mgr.c: 495: ct = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	496
	
l8211:	
;charge_mgr.c: 496: g_diodeTraceCnt = 0;
	bcf	status, 6	;RP1=0, select bank1
	clrf	(_g_diodeTraceCnt)^080h
	line	497
;charge_mgr.c: 497: g_diodeTraceSlot = (unsigned char)idx;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_diodeTraceSlot)^080h
	goto	l8171
	line	504
	
l8215:	
;charge_mgr.c: 504: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	line	505
	
l8217:	
;charge_mgr.c: 505: g_highVFlag &= ~((unsigned int)1 << idx);
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u13014
u13015:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u13014:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u13015
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	506
	
l8219:	
;charge_mgr.c: 506: ty = 1;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	incf	(ChargeProcess_Slot@ty)^0180h,f
	line	507
	
l8221:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_381+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_381+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_381+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_381)^080h

	
l8223:	
	movlw	0Ch
u13025:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_381+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_381+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_381+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_381)^080h,f
	addlw	-1
	skipz
	goto	u13025

	
l8225:	
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_382+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_382+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_382+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_382)^080h

	
l8227:	
	movf	(ChargeProcess_Slot@vx_mv_381+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv_381+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv_381+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv_381)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long_382)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u13031
	addwf	(ChargeProcess_Slot@bat_mv_long_382+1)^080h,f
u13031:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u13032
	addwf	(ChargeProcess_Slot@bat_mv_long_382+2)^080h,f
u13032:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u13033
	addwf	(ChargeProcess_Slot@bat_mv_long_382+3)^080h,f
u13033:

	
l8229:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long_382)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long_382+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_382+1)^080h,w
	goto	u13040
	goto	u13041
u13040:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u13041:
	movf	(ChargeProcess_Slot@bat_mv_long_382+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_382+2)^080h,w
	goto	u13042
	goto	u13043
u13042:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u13043:
	movf	(ChargeProcess_Slot@bat_mv_long_382+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_382+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_383+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_383)^0180h
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_383+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_383)^0180h,w
	skipnc
	goto	u13051
	goto	u13050
u13051:
	goto	l8233
u13050:
	goto	l8101
	
l8233:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_383+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_383)^0180h,w
	skipnc
	goto	u13061
	goto	u13060
u13061:
	goto	l8237
u13060:
	goto	l8105
	
l8237:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_383+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_383)^0180h,w
	skipc
	goto	u13071
	goto	u13070
u13071:
	goto	l8121
u13070:
	
l8239:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u13081
	goto	u13080
u13081:
	goto	l8113
u13080:
	goto	l8111
	line	518
	
l8267:	
;charge_mgr.c: 518: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	519
	
l8269:	
;charge_mgr.c: 519: g_highVFlag &= ~((unsigned int)1 << idx);
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u13094
u13095:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u13094:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u13095
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	520
	
l8271:	
;charge_mgr.c: 520: ty = 6;
	movlw	low(06h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	521
	
l8273:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(___lmul@multiplier)^080h
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(___lmul@multiplier)^080h
	clrf	2+(___lmul@multiplier)^080h
	clrf	3+(___lmul@multiplier)^080h
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_384+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_384+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_384+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_384)^080h

	
l8275:	
	movlw	0Ch
u13105:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_384+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_384+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_384+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_384)^080h,f
	addlw	-1
	skipz
	goto	u13105

	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_385+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_385+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_385+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_385)^080h

	movf	(ChargeProcess_Slot@vx_mv_384+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv_384+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv_384+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv_384)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long_385)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u13111
	addwf	(ChargeProcess_Slot@bat_mv_long_385+1)^080h,f
u13111:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u13112
	addwf	(ChargeProcess_Slot@bat_mv_long_385+2)^080h,f
u13112:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u13113
	addwf	(ChargeProcess_Slot@bat_mv_long_385+3)^080h,f
u13113:

	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long_385)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long_385+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_385+1)^080h,w
	goto	u13120
	goto	u13121
u13120:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u13121:
	movf	(ChargeProcess_Slot@bat_mv_long_385+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_385+2)^080h,w
	goto	u13122
	goto	u13123
u13122:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u13123:
	movf	(ChargeProcess_Slot@bat_mv_long_385+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_385+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_386+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_386)^0180h
	
l8277:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_386+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_386)^0180h,w
	skipnc
	goto	u13131
	goto	u13130
u13131:
	goto	l8281
u13130:
	goto	l8101
	
l8281:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_386+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_386)^0180h,w
	skipnc
	goto	u13141
	goto	u13140
u13141:
	goto	l8285
u13140:
	goto	l8105
	
l8285:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_386+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_386)^0180h,w
	skipc
	goto	u13151
	goto	u13150
u13151:
	goto	l8299
u13150:
	
l8287:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u13161
	goto	u13160
u13161:
	goto	l8291
u13160:
	goto	l8111
	
l8291:	
	movlw	low(05h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l8293:	
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	goto	l8117
	
l8299:	
	movlw	low(04h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l8301:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l8303:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	goto	l8119
	line	531
	
l8315:	
;charge_mgr.c: 531: ct += tick;
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	537
	
l8317:	
;charge_mgr.c: 536: if((ct == 7U || ct == 14U || ct == 21U || ct == 28U) &&
;charge_mgr.c: 537: g_diodeTraceCnt < 4U)
		movlw	7
	xorwf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfsc	status,2
	goto	u13171
	goto	u13170
u13171:
	goto	l8325
u13170:
	
l8319:	
		movlw	14
	xorwf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfsc	status,2
	goto	u13181
	goto	u13180
u13181:
	goto	l8325
u13180:
	
l8321:	
		movlw	21
	xorwf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfsc	status,2
	goto	u13191
	goto	u13190
u13191:
	goto	l8325
u13190:
	
l8323:	
		movlw	28
	xorwf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u13201
	goto	u13200
u13201:
	goto	l8341
u13200:
	
l8325:	
	movlw	low(04h)
	bcf	status, 6	;RP1=0, select bank1
	subwf	(_g_diodeTraceCnt)^080h,w
	skipnc
	goto	u13211
	goto	u13210
u13211:
	goto	l8341
u13210:
	line	539
	
l8327:	
;charge_mgr.c: 538: {
;charge_mgr.c: 539: signed int diff = (signed int)v - (signed int)(g_impData & 0x0FFFU);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@diff+1)^0180h
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@diff)^0180h
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@diff)^0180h,f
	bcf	status, 6	;RP1=0, select bank1
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	skipc
	decf	(ChargeProcess_Slot@diff+1)^0180h,f
	subwf	(ChargeProcess_Slot@diff+1)^0180h,f
	line	540
;charge_mgr.c: 540: diff >>= 2;
	rlf	(ChargeProcess_Slot@diff+1)^0180h,w
	rrf	(ChargeProcess_Slot@diff+1)^0180h,f
	rrf	(ChargeProcess_Slot@diff)^0180h,f
	rlf	(ChargeProcess_Slot@diff+1)^0180h,w
	rrf	(ChargeProcess_Slot@diff+1)^0180h,f
	rrf	(ChargeProcess_Slot@diff)^0180h,f
	line	541
	
l8329:	
;charge_mgr.c: 541: if(diff > 127) diff = 127;
	movf	(ChargeProcess_Slot@diff+1)^0180h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u13225
	movlw	080h
	subwf	(ChargeProcess_Slot@diff)^0180h,w
u13225:

	skipc
	goto	u13221
	goto	u13220
u13221:
	goto	l8333
u13220:
	
l8331:	
	movlw	07Fh
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@diff)^0180h
	clrf	(ChargeProcess_Slot@diff+1)^0180h
	line	542
	
l8333:	
;charge_mgr.c: 542: if(diff < -128) diff = -128;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@diff+1)^0180h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u13235
	movlw	080h
	subwf	(ChargeProcess_Slot@diff)^0180h,w
u13235:

	skipnc
	goto	u13231
	goto	u13230
u13231:
	goto	l8337
u13230:
	
l8335:	
	movlw	080h
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@diff)^0180h
	movlw	0FFh
	movwf	((ChargeProcess_Slot@diff)^0180h)+1
	line	543
	
l8337:	
;charge_mgr.c: 543: g_diodeTrace[g_diodeTraceCnt++] = (unsigned char)(diff + 128);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_diodeTraceCnt)^080h,w
	addlw	low(_g_diodeTrace|((0x0)<<8))&0ffh
	movwf	fsr0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@diff)^0180h,w
	addlw	080h
	bcf	status, 7	;select IRP bank0
	movwf	indf
	
l8339:	
	bcf	status, 6	;RP1=0, select bank1
	incf	(_g_diodeTraceCnt)^080h,f
	goto	l8345
	line	547
	
l8341:	
	line	553
	
l8345:	
;charge_mgr.c: 550: }
;charge_mgr.c: 553: if(v > (g_impData & 0x0FFFU) + 900)
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(0384h)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(0384h)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	skipz
	goto	u13245
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
u13245:
	skipnc
	goto	u13241
	goto	u13240
u13241:
	goto	l8353
u13240:
	line	557
	
l8347:	
;charge_mgr.c: 554: {
;charge_mgr.c: 557: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150U)
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)^080h
	clrf	(___wmul@multiplier+1)^080h
	movlw	0Fh
	andwf	(___wmul@multiplier)^080h,f
	clrf	(___wmul@multiplier+1)^080h
	movlw	026h
	addwf	(___wmul@multiplier)^080h,f
	skipnc
	incf	(___wmul@multiplier+1)^080h,f
	movlw	064h
	movwf	(___wmul@multiplicand)^080h
	clrf	(___wmul@multiplicand+1)^080h
	fcall	___wmul
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(096h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(1+(?___wmul))^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u13255
	movf	(0+(?___wmul))^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u13255:
	skipnc
	goto	u13251
	goto	u13250
u13251:
	goto	l8267
u13250:
	goto	l8215
	line	574
	
l8353:	
;charge_mgr.c: 561: }
;charge_mgr.c: 572: if(((g_impData & 0x0FFFU) > 3000U) &&
;charge_mgr.c: 573: (v > 2900) &&
;charge_mgr.c: 574: (v < (g_impData & 0x0FFFU)))
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Bh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0B9h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u13261
	goto	u13260
u13261:
	goto	l8361
u13260:
	
l8355:	
	movlw	0Bh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13271
	goto	u13270
u13271:
	goto	l8361
u13270:
	
l8357:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	skipz
	goto	u13285
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v)^0100h,w
u13285:
	skipnc
	goto	u13281
	goto	u13280
u13281:
	goto	l8361
u13280:
	goto	l8267
	line	581
	
l8361:	
;charge_mgr.c: 580: if((v > 2900) &&
;charge_mgr.c: 581: ((g_impData & 0x0FFFU) <= 2300U))
	movlw	0Bh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13291
	goto	u13290
u13291:
	goto	l8371
u13290:
	
l8363:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	08h
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	goto	u13301
	goto	u13300
u13301:
	goto	l8371
u13300:
	goto	l8191
	line	607
	
l8371:	
;charge_mgr.c: 589: }
;charge_mgr.c: 604: if(ct >= 20U && v > 2100U &&
;charge_mgr.c: 605: (g_impData & 0x0FFFU) <= 2300U &&
;charge_mgr.c: 606: v + 100U >= (g_impData & 0x0FFFU) &&
;charge_mgr.c: 607: v <= (g_impData & 0x0FFFU) + 150)
	movlw	0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	014h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u13311
	goto	u13310
u13311:
	goto	l8383
u13310:
	
l8373:	
	movlw	08h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	035h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13321
	goto	u13320
u13321:
	goto	l8383
u13320:
	
l8375:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	08h
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	goto	u13331
	goto	u13330
u13331:
	goto	l8383
u13330:
	
l8377:	
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	addlw	low(064h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipnc
	addlw	1
	addlw	high(064h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	skipz
	goto	u13345
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
u13345:
	skipc
	goto	u13341
	goto	u13340
u13341:
	goto	l8383
u13340:
	
l8379:	
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(096h)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	skipz
	goto	u13355
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
u13355:
	skipc
	goto	u13351
	goto	u13350
u13351:
	goto	l8383
u13350:
	goto	l8267
	line	617
	
l8383:	
;charge_mgr.c: 617: if(ct >= 30)
	movlw	0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	01Eh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u13361
	goto	u13360
u13361:
	goto	l8765
u13360:
	line	619
	
l8385:	
;charge_mgr.c: 618: {
;charge_mgr.c: 619: unsigned int pre = (unsigned int)(g_impData & 0x0FFFU);
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@pre)^0180h
	movlw	0Fh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData+1)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	1+(ChargeProcess_Slot@pre)^0180h
	line	621
;charge_mgr.c: 620: if((pre > 3500 && pre < 3990) ||
;charge_mgr.c: 621: (v > 3500 && v < 3990))
	movlw	0Dh
	subwf	(ChargeProcess_Slot@pre+1)^0180h,w
	movlw	0ADh
	skipnz
	subwf	(ChargeProcess_Slot@pre)^0180h,w
	skipc
	goto	u13371
	goto	u13370
u13371:
	goto	l8389
u13370:
	
l8387:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@pre+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@pre)^0180h,w
	skipc
	goto	u13381
	goto	u13380
u13381:
	goto	l8267
u13380:
	
l8389:	
	movlw	0Dh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0ADh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13391
	goto	u13390
u13391:
	goto	l8393
u13390:
	
l8391:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u13401
	goto	u13400
u13401:
	goto	l8393
u13400:
	goto	l8267
	line	626
	
l8393:	
;charge_mgr.c: 624: }
;charge_mgr.c: 625: if(v > 2800U && v < 3990 && pre < 3990 &&
;charge_mgr.c: 626: v + 150U >= pre && pre + 150U >= v)
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0F1h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13411
	goto	u13410
u13411:
	goto	l8191
u13410:
	
l8395:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u13421
	goto	u13420
u13421:
	goto	l8191
u13420:
	
l8397:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@pre+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@pre)^0180h,w
	skipnc
	goto	u13431
	goto	u13430
u13431:
	goto	l8191
u13430:
	
l8399:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	addlw	low(096h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@pre+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u13445
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@pre)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u13445:
	skipc
	goto	u13441
	goto	u13440
u13441:
	goto	l8191
u13440:
	
l8401:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@pre)^0180h,w
	addlw	low(096h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@pre+1)^0180h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u13455
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u13455:
	skipc
	goto	u13451
	goto	u13450
u13451:
	goto	l8191
u13450:
	goto	l8267
	line	640
	
l8411:	
;charge_mgr.c: 640: ct += tick;
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	641
;charge_mgr.c: 641: if(ct > (60 * 100))
	movlw	017h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	071h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u13461
	goto	u13460
u13461:
	goto	l8415
u13460:
	line	643
	
l8413:	
;charge_mgr.c: 642: {
;charge_mgr.c: 643: st = 7;
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	644
;charge_mgr.c: 644: break;
	goto	l8765
	line	646
	
l8415:	
;charge_mgr.c: 645: }
;charge_mgr.c: 646: if(v > 750)
	movlw	02h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13471
	goto	u13470
u13471:
	goto	l8421
u13470:
	line	648
	
l8417:	
;charge_mgr.c: 647: {
;charge_mgr.c: 648: st = 3;
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	649
	
l8419:	
;charge_mgr.c: 649: ct = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	650
;charge_mgr.c: 650: break;
	goto	l8765
	line	652
	
l8421:	
;charge_mgr.c: 651: }
;charge_mgr.c: 652: if(v >= 3850)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13481
	goto	u13480
u13481:
	goto	l8765
u13480:
	goto	l8413
	line	660
	
l8425:	
;charge_mgr.c: 660: ct += tick;
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	661
;charge_mgr.c: 661: if(ct > (300 * 100))
	movlw	075h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	031h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u13491
	goto	u13490
u13491:
	goto	l8429
u13490:
	goto	l8413
	line	666
	
l8429:	
;charge_mgr.c: 665: }
;charge_mgr.c: 666: if(v >= 3850)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13501
	goto	u13500
u13501:
	goto	l8435
u13500:
	line	668
	
l8431:	
;charge_mgr.c: 667: {
;charge_mgr.c: 668: g_ovCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	669
;charge_mgr.c: 669: if(g_ovCnt[idx] >= 5)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u13511
	goto	u13510
u13511:
	goto	l8437
u13510:
	goto	l8413
	line	677
	
l8435:	
;charge_mgr.c: 675: else
;charge_mgr.c: 676: {
;charge_mgr.c: 677: g_ovCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	679
	
l8437:	
;charge_mgr.c: 678: }
;charge_mgr.c: 679: if(v >= 2700)
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	08Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13521
	goto	u13520
u13521:
	goto	l8765
u13520:
	line	681
	
l8439:	
;charge_mgr.c: 680: {
;charge_mgr.c: 681: st = 4;
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	682
	
l8441:	
;charge_mgr.c: 682: ct = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	683
	
l8443:	
;charge_mgr.c: 683: g_ccBlocks[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	684
	
l8445:	
;charge_mgr.c: 684: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	685
	
l8447:	
;charge_mgr.c: 685: g_slotRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	686
	
l8449:	
;charge_mgr.c: 686: g_stableCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8765
	line	691
	
l8451:	
;charge_mgr.c: 691: ct += tick;
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	692
;charge_mgr.c: 692: if(ct >= (600 * 100))
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	060h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u13531
	goto	u13530
u13531:
	goto	l8457
u13530:
	line	694
	
l8453:	
;charge_mgr.c: 693: {
;charge_mgr.c: 694: ct -= (600 * 100);
	movlw	060h
	subwf	(ChargeProcess_Slot@ct)^0180h,f
	movlw	0EAh
	skipc
	decf	(ChargeProcess_Slot@ct+1)^0180h,f
	subwf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	695
	
l8455:	
;charge_mgr.c: 695: g_ccBlocks[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	697
	
l8457:	
;charge_mgr.c: 696: }
;charge_mgr.c: 697: if(g_ccBlocks[idx] >= 18)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(012h)
	subwf	indf,w
	skipc
	goto	u13541
	goto	u13540
u13541:
	goto	l8461
u13540:
	goto	l8413
	line	706
	
l8461:	
;charge_mgr.c: 701: }
;charge_mgr.c: 706: if(v >= 3990 && ty == 6)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13551
	goto	u13550
u13551:
	goto	l8467
u13550:
	
l8463:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u13561
	goto	u13560
u13561:
	goto	l8467
u13560:
	goto	l8477
	line	710
	
l8467:	
;charge_mgr.c: 710: else if(ty == 1 && ct <= (750))
	bsf	status, 5	;RP0=1, select bank3
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u13571
	goto	u13570
u13571:
	goto	l8473
u13570:
	
l8469:	
	movlw	02h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u13581
	goto	u13580
u13581:
	goto	l8473
u13580:
	goto	l8477
	line	718
	
l8473:	
;charge_mgr.c: 716: else
;charge_mgr.c: 717: {
;charge_mgr.c: 718: if(v > g_slotRefV[idx]) g_slotRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u13595
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u13595:
	skipnc
	goto	u13591
	goto	u13590
u13591:
	goto	l8477
u13590:
	
l8475:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	728
	
l8477:	
;charge_mgr.c: 719: }
;charge_mgr.c: 728: if(ty == 6)
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u13601
	goto	u13600
u13601:
	goto	l8503
u13600:
	line	730
	
l8479:	
;charge_mgr.c: 729: {
;charge_mgr.c: 730: if(v < 2000U)
	movlw	07h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0D0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u13611
	goto	u13610
u13611:
	goto	l8489
u13610:
	line	732
	
l8481:	
;charge_mgr.c: 731: {
;charge_mgr.c: 732: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	733
;charge_mgr.c: 733: if(g_detectLowCnt[idx] >= 33U)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u13621
	goto	u13620
u13621:
	goto	l8491
u13620:
	line	735
	
l8483:	
;charge_mgr.c: 734: {
;charge_mgr.c: 735: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	736
	
l8485:	
;charge_mgr.c: 736: st = 7;
	movlw	low(07h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l8419
	line	743
	
l8489:	
;charge_mgr.c: 741: else
;charge_mgr.c: 742: {
;charge_mgr.c: 743: g_detectLowCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	751
	
l8491:	
;charge_mgr.c: 744: }
;charge_mgr.c: 751: if(ct >= 200U)
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0C8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u13631
	goto	u13630
u13631:
	goto	l8537
u13630:
	line	753
	
l8493:	
;charge_mgr.c: 752: {
;charge_mgr.c: 753: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	754
	
l8495:	
;charge_mgr.c: 754: if(g_ccBlocks[idx] & 0x80)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	btfss	indf,(7)&7
	goto	u13641
	goto	u13640
u13641:
	goto	l8499
u13640:
	goto	l8413
	line	760
	
l8499:	
;charge_mgr.c: 758: else
;charge_mgr.c: 759: {
;charge_mgr.c: 760: g_ccBlocks[idx] |= 0x80;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(7/8),(7)&7
	line	761
	
l8501:	
;charge_mgr.c: 761: st = 1;
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@st)^080h
	incf	(ChargeProcess_Slot@st)^080h,f
	line	762
;charge_mgr.c: 762: g_slotRefV[idx] = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	763
;charge_mgr.c: 763: g_stableCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8765
	line	773
	
l8503:	
;charge_mgr.c: 768: else
;charge_mgr.c: 769: {
;charge_mgr.c: 773: if((v < g_slotRefV[idx] && g_slotRefV[idx] - v > 500) || v < 2000U)
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	skipz
	goto	u13655
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v)^0100h,w
u13655:
	skipnc
	goto	u13651
	goto	u13650
u13651:
	goto	l8507
u13650:
	
l8505:	
	bsf	status, 5	;RP0=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipnc
	goto	u13661
	goto	u13660
u13661:
	goto	l8509
u13660:
	
l8507:	
	movlw	07h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0D0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u13671
	goto	u13670
u13671:
	goto	l8521
u13670:
	line	775
	
l8509:	
;charge_mgr.c: 774: {
;charge_mgr.c: 775: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	776
;charge_mgr.c: 776: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u13681
	goto	u13680
u13681:
	goto	l8513
u13680:
	goto	l8765
	line	778
	
l8513:	
;charge_mgr.c: 778: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	779
	
l8515:	
;charge_mgr.c: 779: st = 1;
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@st)^080h
	incf	(ChargeProcess_Slot@st)^080h,f
	goto	l8419
	line	785
	
l8521:	
;charge_mgr.c: 783: else
;charge_mgr.c: 784: {
;charge_mgr.c: 785: g_detectLowCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	797
	
l8523:	
;charge_mgr.c: 786: }
;charge_mgr.c: 797: if(ct <= (750))
	movlw	02h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u13691
	goto	u13690
u13691:
	goto	l8529
u13690:
	line	799
	
l8525:	
;charge_mgr.c: 798: {
;charge_mgr.c: 799: if(v >= g_slotRefV[idx] + (30))
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(01Eh)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	skipz
	goto	u13705
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v)^0100h,w
u13705:
	skipc
	goto	u13701
	goto	u13700
u13701:
	goto	l8529
u13700:
	line	800
	
l8527:	
;charge_mgr.c: 800: g_stableCnt[idx] = 1;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	802
	
l8529:	
;charge_mgr.c: 801: }
;charge_mgr.c: 802: if(ct > (750) && g_stableCnt[idx] == 0)
	movlw	02h
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u13711
	goto	u13710
u13711:
	goto	l8537
u13710:
	
l8531:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfss	status,2
	goto	u13721
	goto	u13720
u13721:
	goto	l8537
u13720:
	goto	l8485
	line	816
	
l8537:	
;charge_mgr.c: 807: }
;charge_mgr.c: 808: }
;charge_mgr.c: 816: if(v >= 3990 && ty == 1)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13731
	goto	u13730
u13731:
	goto	l8545
u13730:
	
l8539:	
	bsf	status, 5	;RP0=1, select bank3
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u13741
	goto	u13740
u13741:
	goto	l8545
u13740:
	line	818
	
l8541:	
;charge_mgr.c: 817: {
;charge_mgr.c: 818: st = 6;
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l8419
	line	826
	
l8545:	
;charge_mgr.c: 821: }
;charge_mgr.c: 826: if(v >= 3850 && ty != 6)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13751
	goto	u13750
u13751:
	goto	l8553
u13750:
	
l8547:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u13761
	goto	u13760
u13761:
	goto	l8553
u13760:
	line	828
	
l8549:	
;charge_mgr.c: 827: {
;charge_mgr.c: 828: g_ovCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	829
;charge_mgr.c: 829: if(g_ovCnt[idx] >= 5)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u13771
	goto	u13770
u13771:
	goto	l586
u13770:
	goto	l8413
	line	837
	
l8553:	
;charge_mgr.c: 835: else
;charge_mgr.c: 836: {
;charge_mgr.c: 837: g_ovCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	839
	
l8555:	
;charge_mgr.c: 839: if(v >= 3100 && !(v >= 3990 && ty == 6))
	movlw	0Ch
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	01Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13781
	goto	u13780
u13781:
	goto	l586
u13780:
	
l8557:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13791
	goto	u13790
u13791:
	goto	l8561
u13790:
	
l8559:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u13801
	goto	u13800
u13801:
	goto	l586
u13800:
	line	841
	
l8561:	
;charge_mgr.c: 840: {
;charge_mgr.c: 841: st = 5;
	movlw	low(05h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	842
	
l8563:	
;charge_mgr.c: 842: ct = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	843
	
l8565:	
;charge_mgr.c: 843: g_ccBlocks[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l8765
	line	850
	
l8567:	
;charge_mgr.c: 850: ct += tick;
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	851
;charge_mgr.c: 851: if(ct > (600 * 100))
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	061h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u13811
	goto	u13810
u13811:
	goto	l740
u13810:
	line	852
	
l8569:	
;charge_mgr.c: 852: st = 6;
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l740:	
	line	860
;charge_mgr.c: 860: if(v >= 3990 && ty == 6)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13821
	goto	u13820
u13821:
	goto	l8575
u13820:
	
l8571:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u13831
	goto	u13830
u13831:
	goto	l8575
u13830:
	goto	l8765
	line	873
	
l8575:	
;charge_mgr.c: 873: if(v < 3990 && ct <= (750) && ty == 1)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u13841
	goto	u13840
u13841:
	goto	l8597
u13840:
	
l8577:	
	movlw	02h
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u13851
	goto	u13850
u13851:
	goto	l8597
u13850:
	
l8579:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u13861
	goto	u13860
u13861:
	goto	l8597
u13860:
	line	875
	
l8581:	
;charge_mgr.c: 874: {
;charge_mgr.c: 875: if(g_ccBlocks[idx] == 0)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(indf),w
	btfss	status,2
	goto	u13871
	goto	u13870
u13871:
	goto	l8585
u13870:
	line	877
	
l8583:	
;charge_mgr.c: 876: {
;charge_mgr.c: 877: g_slotRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	878
;charge_mgr.c: 878: g_ccBlocks[idx] = 1;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	879
;charge_mgr.c: 879: }
	goto	l8597
	line	880
	
l8585:	
;charge_mgr.c: 880: else if(v >= g_slotRefV[idx] + (50))
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(032h)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	skipz
	goto	u13885
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v)^0100h,w
u13885:
	skipc
	goto	u13881
	goto	u13880
u13881:
	goto	l8595
u13880:
	line	882
	
l8587:	
;charge_mgr.c: 881: {
;charge_mgr.c: 882: if(++g_stableCnt[idx] >= 3)
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	movlw	low(03h)
	subwf	(indf),w
	skipc
	goto	u13891
	goto	u13890
u13891:
	goto	l744
u13890:
	line	884
	
l8589:	
;charge_mgr.c: 883: {
;charge_mgr.c: 884: g_stableCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8485
	line	892
	
l8595:	
;charge_mgr.c: 890: else
;charge_mgr.c: 891: {
;charge_mgr.c: 892: g_stableCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8597
	line	893
	
l744:	
	line	901
	
l8597:	
;charge_mgr.c: 893: }
;charge_mgr.c: 894: }
;charge_mgr.c: 901: if(v >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13901
	goto	u13900
u13901:
	goto	l8629
u13900:
	line	903
	
l8599:	
;charge_mgr.c: 902: {
;charge_mgr.c: 903: if(ty == 1)
	bsf	status, 5	;RP0=1, select bank3
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u13911
	goto	u13910
u13911:
	goto	l8611
u13910:
	line	905
	
l8601:	
;charge_mgr.c: 904: {
;charge_mgr.c: 905: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	906
;charge_mgr.c: 906: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u13921
	goto	u13920
u13921:
	goto	l8605
u13920:
	goto	l8765
	line	908
	
l8605:	
;charge_mgr.c: 908: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8541
	line	913
	
l8611:	
;charge_mgr.c: 912: }
;charge_mgr.c: 913: if(ty == 6 && v < 4050U)
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u13931
	goto	u13930
u13931:
	goto	l8617
u13930:
	
l8613:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0D2h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u13941
	goto	u13940
u13941:
	goto	l8617
u13940:
	goto	l8765
	line	917
	
l8617:	
;charge_mgr.c: 916: }
;charge_mgr.c: 917: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	918
;charge_mgr.c: 918: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u13951
	goto	u13950
u13951:
	goto	l8621
u13950:
	goto	l8765
	line	920
	
l8621:	
;charge_mgr.c: 920: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	921
	
l8623:	
;charge_mgr.c: 921: ty = 0;
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	922
	
l8625:	
;charge_mgr.c: 922: st = 0;
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@st)^080h
	goto	l8419
	line	933
	
l8629:	
;charge_mgr.c: 925: }
;charge_mgr.c: 933: if(ty == 6)
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u13961
	goto	u13960
u13961:
	goto	l8643
u13960:
	line	935
	
l8631:	
;charge_mgr.c: 934: {
;charge_mgr.c: 935: if(v < 2000U)
	movlw	07h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0D0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u13971
	goto	u13970
u13971:
	goto	l8641
u13970:
	line	937
	
l8633:	
;charge_mgr.c: 936: {
;charge_mgr.c: 937: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	938
;charge_mgr.c: 938: if(g_detectLowCnt[idx] >= 33U)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u13981
	goto	u13980
u13981:
	goto	l8659
u13980:
	goto	l8483
	line	948
	
l8641:	
;charge_mgr.c: 946: else
;charge_mgr.c: 947: {
;charge_mgr.c: 948: g_detectLowCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l8659
	line	953
	
l8643:	
;charge_mgr.c: 951: else
;charge_mgr.c: 952: {
;charge_mgr.c: 953: if(v < g_slotRefV[idx] && g_slotRefV[idx] - v > 500)
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	skipz
	goto	u13995
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v)^0100h,w
u13995:
	skipnc
	goto	u13991
	goto	u13990
u13991:
	goto	l8641
u13990:
	
l8645:	
	bsf	status, 5	;RP0=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u14001
	goto	u14000
u14001:
	goto	l8641
u14000:
	line	955
	
l8647:	
;charge_mgr.c: 954: {
;charge_mgr.c: 955: g_detectLowCnt[idx]++;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	956
;charge_mgr.c: 956: if(g_detectLowCnt[idx] >= 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipc
	goto	u14011
	goto	u14010
u14011:
	goto	l8659
u14010:
	line	958
	
l8649:	
;charge_mgr.c: 957: {
;charge_mgr.c: 958: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	959
;charge_mgr.c: 959: g_ccBlocks[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	962
	
l8651:	
;charge_mgr.c: 962: ty = 0;
	clrf	(ChargeProcess_Slot@ty)^0180h
	goto	l8515
	line	978
	
l8659:	
;charge_mgr.c: 971: }
;charge_mgr.c: 972: }
;charge_mgr.c: 978: if(v >= 3850 && ty == 1)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u14021
	goto	u14020
u14021:
	goto	l8667
u14020:
	
l8661:	
	bsf	status, 5	;RP0=1, select bank3
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u14031
	goto	u14030
u14031:
	goto	l8667
u14030:
	line	980
	
l8663:	
;charge_mgr.c: 979: {
;charge_mgr.c: 980: g_ovCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	981
;charge_mgr.c: 981: if(g_ovCnt[idx] >= 5)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u14041
	goto	u14040
u14041:
	goto	l586
u14040:
	goto	l8413
	line	989
	
l8667:	
;charge_mgr.c: 987: else
;charge_mgr.c: 988: {
;charge_mgr.c: 989: g_ovCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l8765
	line	1000
	
l8669:	
;charge_mgr.c: 1000: if(v >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u14051
	goto	u14050
u14051:
	goto	l8687
u14050:
	line	1002
	
l8671:	
;charge_mgr.c: 1001: {
;charge_mgr.c: 1002: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1003
	
l8673:	
;charge_mgr.c: 1003: if(g_detectLowCnt[idx] >= (ty == 6 ? 50 : 2))
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u14061
	goto	u14060
u14061:
	goto	l8677
u14060:
	
l8675:	
	movlw	02h
	movwf	(_ChargeProcess_Slot$389)^0180h
	clrf	(_ChargeProcess_Slot$389+1)^0180h
	goto	l8679
	
l8677:	
	movlw	032h
	movwf	(_ChargeProcess_Slot$389)^0180h
	clrf	(_ChargeProcess_Slot$389+1)^0180h
	
l8679:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(_ChargeProcess_Slot$389+1)^0180h,w
	xorlw	80h
	sublw	080h
	skipz
	goto	u14075
	movf	(_ChargeProcess_Slot$389)^0180h,w
	subwf	indf,w
u14075:

	skipc
	goto	u14071
	goto	u14070
u14071:
	goto	l8765
u14070:
	line	1005
	
l8681:	
;charge_mgr.c: 1004: {
;charge_mgr.c: 1005: g_detectLowCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l8625
	line	1014
	
l8687:	
;charge_mgr.c: 1010: }
;charge_mgr.c: 1014: if(v < 2800U)
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u14081
	goto	u14080
u14081:
	goto	l7963
u14080:
	line	1016
	
l8689:	
;charge_mgr.c: 1015: {
;charge_mgr.c: 1016: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1017
;charge_mgr.c: 1017: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u14091
	goto	u14090
u14091:
	goto	l8693
u14090:
	goto	l8765
	line	1019
	
l8693:	
;charge_mgr.c: 1019: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1020
	
l8695:	
;charge_mgr.c: 1020: st = 4;
	movlw	low(04h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	1021
	
l8697:	
;charge_mgr.c: 1021: ct = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	1022
	
l8699:	
;charge_mgr.c: 1022: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	1023
	
l8701:	
;charge_mgr.c: 1023: g_ccBlocks[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8447
	line	1036
	
l8709:	
;charge_mgr.c: 1036: if(v >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u14101
	goto	u14100
u14101:
	goto	l8725
u14100:
	line	1038
	
l8711:	
;charge_mgr.c: 1037: {
;charge_mgr.c: 1038: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1039
;charge_mgr.c: 1039: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u14111
	goto	u14110
u14111:
	goto	l8715
u14110:
	goto	l8765
	line	1041
	
l8715:	
;charge_mgr.c: 1041: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1042
	
l8717:	
;charge_mgr.c: 1042: ty = 0;
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	1043
	
l8719:	
;charge_mgr.c: 1043: st = 0;
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@st)^080h
	goto	l8563
	line	1056
	
l8725:	
;charge_mgr.c: 1047: }
;charge_mgr.c: 1056: if(ty == 2 || ty == 3)
		movlw	2
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u14121
	goto	u14120
u14121:
	goto	l8729
u14120:
	
l8727:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u14131
	goto	u14130
u14131:
	goto	l8745
u14130:
	line	1058
	
l8729:	
;charge_mgr.c: 1057: {
;charge_mgr.c: 1058: if(v > 2700U && (g_highVFlag & ((unsigned int)1 << idx)))
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	08Dh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u14141
	goto	u14140
u14141:
	goto	l7963
u14140:
	
l8731:	
	bsf	status, 5	;RP0=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u14154
u14155:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u14154:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u14155
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u14161
	goto	u14160
u14161:
	goto	l7963
u14160:
	line	1060
	
l8733:	
;charge_mgr.c: 1059: {
;charge_mgr.c: 1060: g_detectLowCnt[idx]++;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1061
;charge_mgr.c: 1061: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u14171
	goto	u14170
u14171:
	goto	l8513
u14170:
	goto	l8765
	line	1074
	
l8745:	
;charge_mgr.c: 1072: }
;charge_mgr.c: 1074: if(v > 750)
	movlw	02h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u14181
	goto	u14180
u14181:
	goto	l7963
u14180:
	line	1076
	
l8747:	
;charge_mgr.c: 1075: {
;charge_mgr.c: 1076: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1077
;charge_mgr.c: 1077: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u14191
	goto	u14190
u14191:
	goto	l8513
u14190:
	goto	l8765
	line	1090
	
l8759:	
;charge_mgr.c: 1090: st = 0;
	clrf	(ChargeProcess_Slot@st)^080h
	line	1091
;charge_mgr.c: 1091: break;
	goto	l8765
	line	161
	
l8763:	
	bcf	status, 6	;RP1=0, select bank1
	movf	(ChargeProcess_Slot@st)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l7907
	xorlw	1^0	; case 1
	skipnz
	goto	l7927
	xorlw	2^1	; case 2
	skipnz
	goto	l8411
	xorlw	3^2	; case 3
	skipnz
	goto	l8425
	xorlw	4^3	; case 4
	skipnz
	goto	l8451
	xorlw	5^4	; case 5
	skipnz
	goto	l8567
	xorlw	6^5	; case 6
	skipnz
	goto	l8669
	xorlw	7^6	; case 7
	skipnz
	goto	l8709
	xorlw	8^7	; case 8
	skipnz
	goto	l8155
	xorlw	9^8	; case 9
	skipnz
	goto	l8315
	goto	l8759
	opt asmopt_pop

	line	1092
	
l586:	
	line	1094
	
l8765:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@st)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ty)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ct)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@ct+1)^0180h,w
	movwf	indf
	line	1095
	
l789:	
	return
	opt stack 0
GLOBAL	__end_of_ChargeProcess_Slot
	__end_of_ChargeProcess_Slot:
	signat	_ChargeProcess_Slot,4217
	global	___wmul

;; *************** function ___wmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
;; Parameters:    Size  Location     Type
;;  multiplier      2    0[BANK1 ] unsigned int 
;;  multiplicand    2    2[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  product         2   26[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2    0[BANK1 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       4       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       4       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
global __ptext14
__ptext14:	;psect for function ___wmul
psect	text14
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
	global	__size_of___wmul
	__size_of___wmul	equ	__end_of___wmul-___wmul
	
___wmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___wmul: [wreg+status,2+status,0]
	line	43
	
l7331:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___wmul@product)
	clrf	(___wmul@product+1)
	line	45
	
l7333:	
	bsf	status, 5	;RP0=1, select bank1
	btfss	(___wmul@multiplier)^080h,(0)&7
	goto	u11351
	goto	u11350
u11351:
	goto	l7337
u11350:
	line	46
	
l7335:	
	movf	(___wmul@multiplicand)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___wmul@product),f
	skipnc
	incf	(___wmul@product+1),f
	bsf	status, 5	;RP0=1, select bank1
	movf	(___wmul@multiplicand+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___wmul@product+1),f
	line	47
	
l7337:	
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(___wmul@multiplicand)^080h,f
	rlf	(___wmul@multiplicand+1)^080h,f
	line	48
	
l7339:	
	clrc
	rrf	(___wmul@multiplier+1)^080h,f
	rrf	(___wmul@multiplier)^080h,f
	line	49
	
l7341:	
	movf	((___wmul@multiplier)^080h),w
iorwf	((___wmul@multiplier+1)^080h),w
	btfss	status,2
	goto	u11361
	goto	u11360
u11361:
	goto	l7333
u11360:
	line	52
	
l7343:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___wmul@product+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___wmul+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___wmul@product),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___wmul)^080h
	line	53
	
l923:	
	return
	opt stack 0
GLOBAL	__end_of___wmul
	__end_of___wmul:
	signat	___wmul,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK1 ] unsigned int 
;;  dividend        2    2[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    5[BANK1 ] unsigned int 
;;  counter         1    4[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK1 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       4       0       0
;;      Locals:         0       0       3       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       7       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext15
__ptext15:	;psect for function ___lwdiv
psect	text15
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l7171:	
	clrf	(___lwdiv@quotient)^080h
	clrf	(___lwdiv@quotient+1)^080h
	line	15
	
l7173:	
	movf	((___lwdiv@divisor)^080h),w
iorwf	((___lwdiv@divisor+1)^080h),w
	btfsc	status,2
	goto	u11071
	goto	u11070
u11071:
	goto	l7193
u11070:
	line	16
	
l7175:	
	clrf	(___lwdiv@counter)^080h
	incf	(___lwdiv@counter)^080h,f
	line	17
	goto	l7179
	line	18
	
l7177:	
	clrc
	rlf	(___lwdiv@divisor)^080h,f
	rlf	(___lwdiv@divisor+1)^080h,f
	line	19
	incf	(___lwdiv@counter)^080h,f
	line	17
	
l7179:	
	btfss	(___lwdiv@divisor+1)^080h,(15)&7
	goto	u11081
	goto	u11080
u11081:
	goto	l7177
u11080:
	line	22
	
l7181:	
	clrc
	rlf	(___lwdiv@quotient)^080h,f
	rlf	(___lwdiv@quotient+1)^080h,f
	line	23
	
l7183:	
	movf	(___lwdiv@divisor+1)^080h,w
	subwf	(___lwdiv@dividend+1)^080h,w
	skipz
	goto	u11095
	movf	(___lwdiv@divisor)^080h,w
	subwf	(___lwdiv@dividend)^080h,w
u11095:
	skipc
	goto	u11091
	goto	u11090
u11091:
	goto	l7189
u11090:
	line	24
	
l7185:	
	movf	(___lwdiv@divisor)^080h,w
	subwf	(___lwdiv@dividend)^080h,f
	movf	(___lwdiv@divisor+1)^080h,w
	skipc
	decf	(___lwdiv@dividend+1)^080h,f
	subwf	(___lwdiv@dividend+1)^080h,f
	line	25
	
l7187:	
	bsf	(___lwdiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l7189:	
	clrc
	rrf	(___lwdiv@divisor+1)^080h,f
	rrf	(___lwdiv@divisor)^080h,f
	line	28
	
l7191:	
	decfsz	(___lwdiv@counter)^080h,f
	goto	u11101
	goto	u11100
u11101:
	goto	l7181
u11100:
	line	30
	
l7193:	
	movf	(___lwdiv@quotient+1)^080h,w
	movwf	(?___lwdiv+1)^080h
	movf	(___lwdiv@quotient)^080h,w
	movwf	(?___lwdiv)^080h
	line	31
	
l1260:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    0[BANK1 ] unsigned long 
;;  multiplicand    4    4[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    8[BANK1 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    0[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext16
__ptext16:	;psect for function ___lmul
psect	text16
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l7133:	
	clrf	(___lmul@product)^080h
	clrf	(___lmul@product+1)^080h
	clrf	(___lmul@product+2)^080h
	clrf	(___lmul@product+3)^080h
	line	120
	
l932:	
	line	121
	btfss	(___lmul@multiplier)^080h,(0)&7
	goto	u11001
	goto	u11000
u11001:
	goto	l7137
u11000:
	line	122
	
l7135:	
	movf	(___lmul@multiplicand)^080h,w
	addwf	(___lmul@product)^080h,f
	movf	(___lmul@multiplicand+1)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11011
	addwf	(___lmul@product+1)^080h,f
u11011:
	movf	(___lmul@multiplicand+2)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11012
	addwf	(___lmul@product+2)^080h,f
u11012:
	movf	(___lmul@multiplicand+3)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11013
	addwf	(___lmul@product+3)^080h,f
u11013:

	line	123
	
l7137:	
	clrc
	rlf	(___lmul@multiplicand)^080h,f
	rlf	(___lmul@multiplicand+1)^080h,f
	rlf	(___lmul@multiplicand+2)^080h,f
	rlf	(___lmul@multiplicand+3)^080h,f
	line	124
	
l7139:	
	clrc
	rrf	(___lmul@multiplier+3)^080h,f
	rrf	(___lmul@multiplier+2)^080h,f
	rrf	(___lmul@multiplier+1)^080h,f
	rrf	(___lmul@multiplier)^080h,f
	line	125
	movf	(___lmul@multiplier+3)^080h,w
	iorwf	(___lmul@multiplier+2)^080h,w
	iorwf	(___lmul@multiplier+1)^080h,w
	iorwf	(___lmul@multiplier)^080h,w
	skipz
	goto	u11021
	goto	u11020
u11021:
	goto	l932
u11020:
	line	128
	
l7141:	
	movf	(___lmul@product+3)^080h,w
	movwf	(?___lmul+3)^080h
	movf	(___lmul@product+2)^080h,w
	movwf	(?___lmul+2)^080h
	movf	(___lmul@product+1)^080h,w
	movwf	(?___lmul+1)^080h
	movf	(___lmul@product)^080h,w
	movwf	(?___lmul)^080h

	line	129
	
l935:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4   12[BANK1 ] unsigned long 
;;  dividend        4   16[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   21[BANK1 ] unsigned long 
;;  counter         1   20[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4   12[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       0       5       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext17
__ptext17:	;psect for function ___lldiv
psect	text17
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l7145:	
	clrf	(___lldiv@quotient)^080h
	clrf	(___lldiv@quotient+1)^080h
	clrf	(___lldiv@quotient+2)^080h
	clrf	(___lldiv@quotient+3)^080h
	line	15
	
l7147:	
	movf	(___lldiv@divisor+3)^080h,w
	iorwf	(___lldiv@divisor+2)^080h,w
	iorwf	(___lldiv@divisor+1)^080h,w
	iorwf	(___lldiv@divisor)^080h,w
	skipnz
	goto	u11031
	goto	u11030
u11031:
	goto	l7167
u11030:
	line	16
	
l7149:	
	clrf	(___lldiv@counter)^080h
	incf	(___lldiv@counter)^080h,f
	line	17
	goto	l7153
	line	18
	
l7151:	
	clrc
	rlf	(___lldiv@divisor)^080h,f
	rlf	(___lldiv@divisor+1)^080h,f
	rlf	(___lldiv@divisor+2)^080h,f
	rlf	(___lldiv@divisor+3)^080h,f
	line	19
	incf	(___lldiv@counter)^080h,f
	line	17
	
l7153:	
	btfss	(___lldiv@divisor+3)^080h,(31)&7
	goto	u11041
	goto	u11040
u11041:
	goto	l7151
u11040:
	line	22
	
l7155:	
	clrc
	rlf	(___lldiv@quotient)^080h,f
	rlf	(___lldiv@quotient+1)^080h,f
	rlf	(___lldiv@quotient+2)^080h,f
	rlf	(___lldiv@quotient+3)^080h,f
	line	23
	
l7157:	
	movf	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,w
	skipz
	goto	u11055
	movf	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,w
	skipz
	goto	u11055
	movf	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,w
	skipz
	goto	u11055
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,w
u11055:
	skipc
	goto	u11051
	goto	u11050
u11051:
	goto	l7163
u11050:
	line	24
	
l7159:	
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,f
	movf	(___lldiv@divisor+1)^080h,w
	skipc
	incfsz	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,f
	movf	(___lldiv@divisor+2)^080h,w
	skipc
	incfsz	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,f
	movf	(___lldiv@divisor+3)^080h,w
	skipc
	incfsz	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,f
	line	25
	
l7161:	
	bsf	(___lldiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l7163:	
	clrc
	rrf	(___lldiv@divisor+3)^080h,f
	rrf	(___lldiv@divisor+2)^080h,f
	rrf	(___lldiv@divisor+1)^080h,f
	rrf	(___lldiv@divisor)^080h,f
	line	28
	
l7165:	
	decfsz	(___lldiv@counter)^080h,f
	goto	u11061
	goto	u11060
u11061:
	goto	l7155
u11060:
	line	30
	
l7167:	
	movf	(___lldiv@quotient+3)^080h,w
	movwf	(?___lldiv+3)^080h
	movf	(___lldiv@quotient+2)^080h,w
	movwf	(?___lldiv+2)^080h
	movf	(___lldiv@quotient+1)^080h,w
	movwf	(?___lldiv+1)^080h
	movf	(___lldiv@quotient)^080h,w
	movwf	(?___lldiv)^080h

	line	31
	
l1207:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[BANK1 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1   27[BANK0 ] unsigned char 
;;  product         1   26[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/100
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       1       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       1       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext18
__ptext18:	;psect for function ___bmul
psect	text18
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplier)
	line	6
	
l7347:	
	clrf	(___bmul@product)
	line	43
	
l7349:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u11371
	goto	u11370
u11371:
	goto	l7353
u11370:
	line	44
	
l7351:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___bmul@multiplicand)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___bmul@product),f
	line	45
	
l7353:	
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(___bmul@multiplicand)^080h,f
	line	46
	
l7355:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u11381
	goto	u11380
u11381:
	goto	l7349
u11380:
	line	50
	
l7357:	
	movf	(___bmul@product),w
	line	51
	
l941:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 76 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2    0[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	76
global __ptext19
__ptext19:	;psect for function _Detect_BatteryType
psect	text19
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	76
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	78
	
l7299:	
;charge_mgr.c: 78: if(voltage >= 3990)
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipc
	goto	u11291
	goto	u11290
u11291:
	goto	l7305
u11290:
	line	79
	
l7301:	
;charge_mgr.c: 79: return 0;
	movlw	low(0)
	goto	l572
	line	80
	
l7305:	
;charge_mgr.c: 80: if(voltage < 500)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipnc
	goto	u11301
	goto	u11300
u11301:
	goto	l7311
u11300:
	goto	l7301
	line	95
	
l7311:	
;charge_mgr.c: 95: if(voltage >= 1015 && voltage < 3990)
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipc
	goto	u11311
	goto	u11310
u11311:
	goto	l7319
u11310:
	
l7313:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipnc
	goto	u11321
	goto	u11320
u11321:
	goto	l7319
u11320:
	line	96
	
l7315:	
;charge_mgr.c: 96: return 5;
	movlw	low(05h)
	goto	l572
	line	101
	
l7319:	
;charge_mgr.c: 101: if(voltage >= 500 && voltage < 3990)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipc
	goto	u11331
	goto	u11330
u11331:
	goto	l7301
u11330:
	
l7321:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipnc
	goto	u11341
	goto	u11340
u11341:
	goto	l7301
u11340:
	line	102
	
l7323:	
;charge_mgr.c: 102: return 1;
	movlw	low(01h)
	line	105
	
l572:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    0[BANK1 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    6[BANK1 ] unsigned char 
;;  j               1    5[BANK1 ] unsigned char 
;;  adsum           4    8[BANK1 ] volatile unsigned long 
;;  ad_temp         2   16[BANK1 ] volatile unsigned int 
;;  admax           2   14[BANK1 ] volatile unsigned int 
;;  admin           2   12[BANK1 ] volatile unsigned int 
;;  i               1    7[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       1       0       0
;;      Locals:         0       0      13       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       0      18       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext20
__ptext20:	;psect for function _ADC_Sample
psect	text20
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	movwf	(ADC_Sample@adch)^080h
	line	51
	
l5239:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	52
	
l5241:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(ADC_Sample@admin)^080h	;volatile
	clrf	(ADC_Sample@admin+1)^080h	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(ADC_Sample@admax)^080h	;volatile
	clrf	(ADC_Sample@admax+1)^080h	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	line	58
	
l5243:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u7391
	goto	u7390
u7391:
	goto	l5249
u7390:
	
l5245:	
	btfss	(ADC_Sample@adldo)^080h,(2)&7
	goto	u7401
	goto	u7400
u7401:
	goto	l5249
u7400:
	line	60
	
l5247:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(ADC_Sample@adldo)^080h,w
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_ADC_Sample+0)^080h+0),f
	u14487:
decfsz	(??_ADC_Sample+0)^080h+0,f
	goto	u14487
	nop
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	l5251
	line	64
	
l5249:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	movf	(ADC_Sample@adldo)^080h,w
	movwf	(150)^080h	;volatile
	line	67
	
l5251:	
;adc_drv.c: 67: if(adch & 0x10)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	btfss	(ADC_Sample@adch)^080h,(4)&7
	goto	u7411
	goto	u7410
u7411:
	goto	l484
u7410:
	line	69
	
l5253:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l5255:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	andwf	(ADC_Sample@adch)^080h,f
	line	71
;adc_drv.c: 71: }
	goto	l5257
	line	72
	
l484:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l5257:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	clrf	(ADC_Sample@i)^080h
	line	79
	
l5263:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(ADC_Sample@adch)^080h,w
	movwf	(??_ADC_Sample+0)^080h+0
	movlw	(02h)-1
u7425:
	clrc
	rlf	(??_ADC_Sample+0)^080h+0,f
	addlw	-1
	skipz
	goto	u7425
	clrc
	rlf	(??_ADC_Sample+0)^080h+0,w
	iorlw	081h
	movwf	(149)^080h	;volatile
	line	80
	
l5265:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	5
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_ADC_Sample+0)^080h+0),f
	u14497:
decfsz	(??_ADC_Sample+0)^080h+0,f
	goto	u14497
	nop2
opt asmopt_pop

	line	81
	
l5267:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l5269:	
;adc_drv.c: 84: unsigned char j = 0;
	clrf	(ADC_Sample@j)^080h
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	l488
	
l489:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decfsz	(ADC_Sample@j)^080h,f
	goto	u7431
	goto	u7430
u7431:
	goto	l488
u7430:
	line	89
	
l5271:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	l491
	line	90
	
l488:	
	line	85
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u7441
	goto	u7440
u7441:
	goto	l489
u7440:
	line	93
	
l5275:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	movwf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	swapf	(ADC_Sample@ad_temp)^080h,f	;volatile
	swapf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	
l5277:	
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	addwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	line	96
	
l5279:	
;adc_drv.c: 96: if(0 == admax)
	movf	((ADC_Sample@admax)^080h),w	;volatile
iorwf	((ADC_Sample@admax+1)^080h),w	;volatile
	btfss	status,2
	goto	u7451
	goto	u7450
u7451:
	goto	l5283
u7450:
	line	98
	
l5281:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	100
;adc_drv.c: 100: }
	goto	l494
	line	102
	
l5283:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	subwf	(ADC_Sample@admax+1)^080h,w	;volatile
	skipz
	goto	u7465
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	subwf	(ADC_Sample@admax)^080h,w	;volatile
u7465:
	skipnc
	goto	u7461
	goto	u7460
u7461:
	goto	l5287
u7460:
	line	103
	
l5285:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	goto	l494
	line	105
	
l5287:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	skipz
	goto	u7475
	movf	(ADC_Sample@admin)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp)^080h,w	;volatile
u7475:
	skipnc
	goto	u7471
	goto	u7470
u7471:
	goto	l494
u7470:
	line	106
	
l5289:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	108
	
l494:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	0+(??_ADC_Sample+0)^080h+0,w
	addwf	(ADC_Sample@adsum)^080h,f	;volatile
	movf	1+(??_ADC_Sample+0)^080h+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7481
	addwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u7481:
	movf	2+(??_ADC_Sample+0)^080h+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7482
	addwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u7482:
	movf	3+(??_ADC_Sample+0)^080h+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7483
	addwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u7483:

	line	76
	
l5291:	
	incf	(ADC_Sample@i)^080h,f
	
l5293:	
	movlw	low(022h)
	subwf	(ADC_Sample@i)^080h,w
	skipc
	goto	u7491
	goto	u7490
u7491:
	goto	l5263
u7490:
	line	112
	
l5295:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(ADC_Sample@admax)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@admax+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	0+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	movf	1+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)^080h+0,w
	goto	u7505
	goto	u7506
u7505:
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u7506:
	movf	2+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)^080h+0,w
	goto	u7507
	goto	u7508
u7507:
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u7508:
	movf	3+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)^080h+0,w
	goto	u7509
	goto	u7500
u7509:
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u7500:

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(ADC_Sample@admin)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	3+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum+3)^080h,w	;volatile
	skipz
	goto	u7515
	movf	2+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum+2)^080h,w	;volatile
	skipz
	goto	u7515
	movf	1+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum+1)^080h,w	;volatile
	skipz
	goto	u7515
	movf	0+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum)^080h,w	;volatile
u7515:
	skipc
	goto	u7511
	goto	u7510
u7511:
	goto	l498
u7510:
	line	114
	
l5297:	
;adc_drv.c: 114: adsum -= admin;
	movf	(ADC_Sample@admin)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	0+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	movf	1+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)^080h+0,w
	goto	u7525
	goto	u7526
u7525:
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u7526:
	movf	2+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)^080h+0,w
	goto	u7527
	goto	u7528
u7527:
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u7528:
	movf	3+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)^080h+0,w
	goto	u7529
	goto	u7520
u7529:
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u7520:

	goto	l5299
	line	115
	
l498:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	118
	
l5299:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(ADC_Sample@adsum)^080h,w	;volatile
	movwf	(??_ADC_Sample+0)^080h+0
	movf	(ADC_Sample@adsum+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	movf	(ADC_Sample@adsum+2)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+2)
	movf	(ADC_Sample@adsum+3)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+3)
	movlw	05h
u7535:
	clrc
	rrf	(??_ADC_Sample+0)^080h+3,f
	rrf	(??_ADC_Sample+0)^080h+2,f
	rrf	(??_ADC_Sample+0)^080h+1,f
	rrf	(??_ADC_Sample+0)^080h+0,f
u7530:
	addlw	-1
	skipz
	goto	u7535
	movf	1+(??_ADC_Sample+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_adresult+1)	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(??_ADC_Sample+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_adresult)	;volatile
	line	119
	
l5301:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
l491:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 162 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   22[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0       8       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_CCCV_Control
;;		_Charging_Control
;;		_PowerOnLedSequence
;;		_Update_LED_Slot
;;		i1_ADC_Sample
;;		i1___lldiv
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	162
global __ptext21
__ptext21:	;psect for function _Isr_Timer
psect	text21
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	162
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 2
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	movf	btemp+1,w
	movwf	(??_Isr_Timer+3)
	ljmp	_Isr_Timer
psect	text21
	line	165
	
i1l8793:	
;main.c: 165: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u1424_21
	goto	u1424_20
u1424_21:
	goto	i1l357
u1424_20:
	line	167
	
i1l8795:	
;main.c: 166: {
;main.c: 167: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	168
	
i1l8797:	
;main.c: 168: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	169
# 169 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text21
	line	172
	
i1l8799:	
;main.c: 172: g_pwmCounter++;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	173
	
i1l8801:	
;main.c: 173: if(g_pwmCounter >= 32)
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u1425_21
	goto	u1425_20
u1425_21:
	goto	i1l8805
u1425_20:
	line	174
	
i1l8803:	
;main.c: 174: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	177
	
i1l8805:	
;main.c: 177: if(g_pwmDuty > 0 && g_pwmCounter < g_pwmDuty)
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u1426_21
	goto	u1426_20
u1426_21:
	goto	i1l354
u1426_20:
	
i1l8807:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u1427_21
	goto	u1427_20
u1427_21:
	goto	i1l354
u1427_20:
	line	178
	
i1l8809:	
;main.c: 178: RB7 = 1;
	bsf	(55/8),(55)&7	;volatile
	goto	i1l8811
	line	179
	
i1l354:	
	line	180
;main.c: 179: else
;main.c: 180: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	183
	
i1l8811:	
;main.c: 183: if(g_powerOnPhase < 2)
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u1428_21
	goto	u1428_20
u1428_21:
	goto	i1l8881
u1428_20:
	line	185
	
i1l8813:	
;main.c: 184: {
;main.c: 185: PowerOnLedSequence();
	fcall	_PowerOnLedSequence
	goto	i1l357
	line	192
;main.c: 191: {
;main.c: 192: case 0:
	
i1l359:	
	line	194
;main.c: 194: if(!g_adcBusy && !g_doAdcSample)
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u1429_21
	goto	u1429_20
u1429_21:
	goto	i1l357
u1429_20:
	
i1l8817:	
	btfsc	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u1430_21
	goto	u1430_20
u1430_21:
	goto	i1l357
u1430_20:
	goto	i1l8821
	line	196
	
i1l363:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l376
	
i1l365:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l376
	
i1l366:	
	bsf	(51/8),(51)&7	;volatile
	goto	i1l376
	
i1l367:	
	bsf	(50/8),(50)&7	;volatile
	goto	i1l376
	
i1l368:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l376
	
i1l369:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l376
	
i1l370:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l376
	
i1l371:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l376
	
i1l372:	
	bsf	(48/8),(48)&7	;volatile
	goto	i1l376
	
i1l373:	
	bsf	(49/8),(49)&7	;volatile
	goto	i1l376
	
i1l374:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l376
	
i1l375:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l376
	
i1l8821:	
	movf	(_g_scanIndex),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l363
	xorlw	1^0	; case 1
	skipnz
	goto	i1l365
	xorlw	2^1	; case 2
	skipnz
	goto	i1l366
	xorlw	3^2	; case 3
	skipnz
	goto	i1l367
	xorlw	4^3	; case 4
	skipnz
	goto	i1l368
	xorlw	5^4	; case 5
	skipnz
	goto	i1l369
	xorlw	6^5	; case 6
	skipnz
	goto	i1l370
	xorlw	7^6	; case 7
	skipnz
	goto	i1l371
	xorlw	8^7	; case 8
	skipnz
	goto	i1l372
	xorlw	9^8	; case 9
	skipnz
	goto	i1l373
	xorlw	10^9	; case 10
	skipnz
	goto	i1l374
	xorlw	11^10	; case 11
	skipnz
	goto	i1l375
	goto	i1l376
	opt asmopt_pop

	
i1l376:	
	line	197
;main.c: 197: g_doAdcSample = 1;
	bsf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	i1l357
	line	203
	
i1l8823:	
;main.c: 203: Update_LED_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_Update_LED_Slot
	line	205
	
i1l8825:	
;main.c: 205: g_scanPhase = 2;
	movlw	low(02h)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_scanPhase)	;volatile
	line	206
;main.c: 206: break;
	goto	i1l357
	line	209
	
i1l8827:	
;main.c: 209: if(g_scanIndex == 0)
	movf	((_g_scanIndex)),w	;volatile
	btfss	status,2
	goto	u1431_21
	goto	u1431_20
u1431_21:
	goto	i1l8873
u1431_20:
	line	212
	
i1l8829:	
;main.c: 210: {
;main.c: 212: if(!g_adcBusy)
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u1432_21
	goto	u1432_20
u1432_21:
	goto	i1l8843
u1432_20:
	line	214
	
i1l8831:	
;main.c: 213: {
;main.c: 214: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	215
	
i1l8833:	
;main.c: 215: test_adc = ADC_Sample(31, 0);
	clrf	(i1ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	i1_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	216
	
i1l8835:	
;main.c: 216: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u1433_21
	goto	u1433_20
u1433_21:
	goto	i1l8841
u1433_20:
	line	218
	
i1l8837:	
;main.c: 217: {
;main.c: 218: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult),w	;volatile
	movwf	(i1___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((i1___lldiv@divisor))+1
	clrf	2+((i1___lldiv@divisor))
	clrf	3+((i1___lldiv@divisor))
	movlw	0
	movwf	(i1___lldiv@dividend+3)
	movlw	04Bh
	movwf	(i1___lldiv@dividend+2)
	movlw	0
	movwf	(i1___lldiv@dividend+1)
	movlw	0
	movwf	(i1___lldiv@dividend)

	fcall	i1___lldiv
	movf	(3+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+3)
	movf	(2+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+2)
	movf	(1+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+1)
	movf	(0+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt)

	line	219
	
i1l8839:	
;main.c: 219: g_vcc_mv = (unsigned int)pt;
	movf	(Isr_Timer@pt+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv+1)^080h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(Isr_Timer@pt),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv)^080h	;volatile
	line	221
	
i1l8841:	
;main.c: 220: }
;main.c: 221: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	224
	
i1l8843:	
;main.c: 222: }
;main.c: 224: Charging_Control();
	fcall	_Charging_Control
	line	225
	
i1l8845:	
;main.c: 225: CCCV_Control();
	fcall	_CCCV_Control
	line	229
	
i1l8847:	
;main.c: 228: {
;main.c: 229: if(g_tempPhase == 0)
	movf	((_g_tempPhase)),w	;volatile
	btfss	status,2
	goto	u1434_21
	goto	u1434_20
u1434_21:
	goto	i1l8859
u1434_20:
	line	231
	
i1l8849:	
;main.c: 230: {
;main.c: 231: g_tempReadRoundCnt++;
	incf	(_g_tempReadRoundCnt),f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1),f	;volatile
	line	232
	
i1l8851:	
;main.c: 232: if(g_tempReadRoundCnt >= 200)
	movlw	0
	subwf	(_g_tempReadRoundCnt+1),w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt),w	;volatile
	skipc
	goto	u1435_21
	goto	u1435_20
u1435_21:
	goto	i1l8867
u1435_20:
	line	234
	
i1l8853:	
;main.c: 233: {
;main.c: 234: g_tempReadRoundCnt = 0;
	clrf	(_g_tempReadRoundCnt)	;volatile
	clrf	(_g_tempReadRoundCnt+1)	;volatile
	line	235
	
i1l8855:	
;main.c: 235: g_tempPhase = 1;
	movlw	low(01h)
	movwf	(_g_tempPhase)	;volatile
	line	236
	
i1l8857:	
;main.c: 236: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)	;volatile
	clrf	(_g_tempSettleCnt+1)	;volatile
	goto	i1l8867
	line	241
	
i1l8859:	
;main.c: 239: else
;main.c: 240: {
;main.c: 241: g_tempSettleCnt++;
	incf	(_g_tempSettleCnt),f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1),f	;volatile
	line	242
	
i1l8861:	
;main.c: 242: if(g_tempSettleCnt >= 60)
	movlw	0
	subwf	(_g_tempSettleCnt+1),w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt),w	;volatile
	skipc
	goto	u1436_21
	goto	u1436_20
u1436_21:
	goto	i1l8867
u1436_20:
	line	244
	
i1l8863:	
;main.c: 243: {
;main.c: 244: g_doNtcRead = 1;
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	245
	
i1l8865:	
;main.c: 245: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)	;volatile
	clrf	(_g_tempSettleCnt+1)	;volatile
	line	246
;main.c: 246: g_tempPhase = 0;
	clrf	(_g_tempPhase)	;volatile
	line	253
	
i1l8867:	
;main.c: 247: }
;main.c: 248: }
;main.c: 249: }
;main.c: 253: if(++g_printTick >= 100)
	incf	(_g_printTick),f	;volatile
	skipnz
	incf	(_g_printTick+1),f	;volatile
	movlw	0
	subwf	((_g_printTick+1)),w	;volatile
	movlw	064h
	skipnz
	subwf	((_g_printTick)),w	;volatile
	skipc
	goto	u1437_21
	goto	u1437_20
u1437_21:
	goto	i1l8873
u1437_20:
	line	255
	
i1l8869:	
;main.c: 254: {
;main.c: 255: g_printTick = 0;
	clrf	(_g_printTick)	;volatile
	clrf	(_g_printTick+1)	;volatile
	line	256
	
i1l8871:	
;main.c: 256: g_printFlag = 1;
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	262
	
i1l8873:	
;main.c: 257: }
;main.c: 259: }
;main.c: 262: if(++g_scanIndex >= 12)
	movlw	low(0Ch)
	incf	(_g_scanIndex),f	;volatile
	subwf	((_g_scanIndex)),w	;volatile
	skipc
	goto	u1438_21
	goto	u1438_20
u1438_21:
	goto	i1l388
u1438_20:
	line	263
	
i1l8875:	
;main.c: 263: g_scanIndex = 0;
	clrf	(_g_scanIndex)	;volatile
	
i1l388:	
	line	264
;main.c: 264: g_scanPhase = 0;
	clrf	(_g_scanPhase)	;volatile
	line	265
;main.c: 265: break;
	goto	i1l357
	line	190
	
i1l8881:	
	movf	(_g_scanPhase),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 2
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           17     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l359
	xorlw	1^0	; case 1
	skipnz
	goto	i1l8823
	xorlw	2^1	; case 2
	skipnz
	goto	i1l8827
	goto	i1l388
	opt asmopt_pop

	line	272
	
i1l357:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(??_Isr_Timer+3),w
	movwf	btemp+1
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^00h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	i1___lldiv

;; *************** function i1___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    0[COMMON] unsigned long 
;;  dividend        4    4[COMMON] unsigned long 
;; Auto vars:     Size  Location     Type
;;  __lldiv         4    1[BANK0 ] unsigned long 
;;  __lldiv         1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    0[COMMON] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         8       0       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       5       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext22
__ptext22:	;psect for function i1___lldiv
psect	text22
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_ofi1___lldiv
	__size_ofi1___lldiv	equ	__end_ofi1___lldiv-i1___lldiv
	
i1___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in i1___lldiv: [wreg+status,2+status,0]
	line	14
	
i1l8767:	
	clrf	(i1___lldiv@quotient)
	clrf	(i1___lldiv@quotient+1)
	clrf	(i1___lldiv@quotient+2)
	clrf	(i1___lldiv@quotient+3)
	line	15
	
i1l8769:	
	movf	(i1___lldiv@divisor+3),w
	iorwf	(i1___lldiv@divisor+2),w
	iorwf	(i1___lldiv@divisor+1),w
	iorwf	(i1___lldiv@divisor),w
	skipnz
	goto	u1420_21
	goto	u1420_20
u1420_21:
	goto	i1l8789
u1420_20:
	line	16
	
i1l8771:	
	clrf	(i1___lldiv@counter)
	incf	(i1___lldiv@counter),f
	line	17
	goto	i1l8775
	line	18
	
i1l8773:	
	clrc
	rlf	(i1___lldiv@divisor),f
	rlf	(i1___lldiv@divisor+1),f
	rlf	(i1___lldiv@divisor+2),f
	rlf	(i1___lldiv@divisor+3),f
	line	19
	incf	(i1___lldiv@counter),f
	line	17
	
i1l8775:	
	btfss	(i1___lldiv@divisor+3),(31)&7
	goto	u1421_21
	goto	u1421_20
u1421_21:
	goto	i1l8773
u1421_20:
	line	22
	
i1l8777:	
	clrc
	rlf	(i1___lldiv@quotient),f
	rlf	(i1___lldiv@quotient+1),f
	rlf	(i1___lldiv@quotient+2),f
	rlf	(i1___lldiv@quotient+3),f
	line	23
	
i1l8779:	
	movf	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),w
	skipz
	goto	u1422_25
	movf	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),w
	skipz
	goto	u1422_25
	movf	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),w
	skipz
	goto	u1422_25
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),w
u1422_25:
	skipc
	goto	u1422_21
	goto	u1422_20
u1422_21:
	goto	i1l8785
u1422_20:
	line	24
	
i1l8781:	
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),f
	movf	(i1___lldiv@divisor+1),w
	skipc
	incfsz	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),f
	movf	(i1___lldiv@divisor+2),w
	skipc
	incfsz	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),f
	movf	(i1___lldiv@divisor+3),w
	skipc
	incfsz	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),f
	line	25
	
i1l8783:	
	bsf	(i1___lldiv@quotient)+(0/8),(0)&7
	line	27
	
i1l8785:	
	clrc
	rrf	(i1___lldiv@divisor+3),f
	rrf	(i1___lldiv@divisor+2),f
	rrf	(i1___lldiv@divisor+1),f
	rrf	(i1___lldiv@divisor),f
	line	28
	
i1l8787:	
	decfsz	(i1___lldiv@counter),f
	goto	u1423_21
	goto	u1423_20
u1423_21:
	goto	i1l8777
u1423_20:
	line	30
	
i1l8789:	
	movf	(i1___lldiv@quotient+3),w
	movwf	(?i1___lldiv+3)
	movf	(i1___lldiv@quotient+2),w
	movwf	(?i1___lldiv+2)
	movf	(i1___lldiv@quotient+1),w
	movwf	(?i1___lldiv+1)
	movf	(i1___lldiv@quotient),w
	movwf	(?i1___lldiv)

	line	31
	
i1l1207:	
	return
	opt stack 0
GLOBAL	__end_ofi1___lldiv
	__end_ofi1___lldiv:
	signat	i1___lldiv,92
	global	i1_ADC_Sample

;; *************** function i1_ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    0[BANK0 ] unsigned char 
;;  ADC_Sample      4    3[BANK0 ] volatile unsigned long 
;;  ADC_Sample      2   11[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    9[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    7[BANK0 ] volatile unsigned int 
;;  ADC_Sample      1    2[BANK0 ] unsigned char 
;;  ADC_Sample      1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      13       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext23
__ptext23:	;psect for function i1_ADC_Sample
psect	text23
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_ofi1_ADC_Sample
	__size_ofi1_ADC_Sample	equ	__end_ofi1_ADC_Sample-i1_ADC_Sample
	
i1_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in i1_ADC_Sample: [wreg+status,2+status,0]
;i1ADC_Sample@adch stored from wreg
	movwf	(i1ADC_Sample@adch)
	line	51
	
i1l5053:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	52
	
i1l5055:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(i1ADC_Sample@admin)	;volatile
	clrf	(i1ADC_Sample@admin+1)	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(i1ADC_Sample@admax)	;volatile
	clrf	(i1ADC_Sample@admax+1)	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	line	58
	
i1l5057:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u706_21
	goto	u706_20
u706_21:
	goto	i1l5063
u706_20:
	
i1l5059:	
	btfss	(i1ADC_Sample@adldo),(2)&7
	goto	u707_21
	goto	u707_20
u707_21:
	goto	i1l5063
u707_20:
	line	60
	
i1l5061:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??i1_ADC_Sample+0)+0),f
	u1450_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u1450_27
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	i1l5065
	line	64
	
i1l5063:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	67
	
i1l5065:	
;adc_drv.c: 67: if(adch & 0x10)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(i1ADC_Sample@adch),(4)&7
	goto	u708_21
	goto	u708_20
u708_21:
	goto	i1l484
u708_20:
	line	69
	
i1l5067:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
i1l5069:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(i1ADC_Sample@adch),f
	line	71
;adc_drv.c: 71: }
	goto	i1l5071
	line	72
	
i1l484:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
i1l5071:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@i)
	
i1l5073:	
	movlw	low(022h)
	subwf	(i1ADC_Sample@i),w
	skipc
	goto	u709_21
	goto	u709_20
u709_21:
	goto	i1l5077
u709_20:
	goto	i1l5109
	line	79
	
i1l5077:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(i1ADC_Sample@adch),w
	movwf	(??i1_ADC_Sample+0)+0
	movlw	(02h)-1
u710_25:
	clrc
	rlf	(??i1_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u710_25
	clrc
	rlf	(??i1_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
i1l5079:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	6
movwf	((??i1_ADC_Sample+0)+0),f
	u1451_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u1451_27
	nop
opt asmopt_pop

	line	81
	
i1l5081:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
i1l5083:	
;adc_drv.c: 84: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@j)
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	i1l488
	
i1l489:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(i1ADC_Sample@j),f
	goto	u711_21
	goto	u711_20
u711_21:
	goto	i1l488
u711_20:
	line	89
	
i1l5085:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	i1l491
	line	90
	
i1l488:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u712_21
	goto	u712_20
u712_21:
	goto	i1l489
u712_20:
	line	93
	
i1l5089:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	swapf	(i1ADC_Sample@ad_temp),f	;volatile
	swapf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp),f	;volatile
	
i1l5091:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(i1ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(i1ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
i1l5093:	
;adc_drv.c: 96: if(0 == admax)
	movf	((i1ADC_Sample@admax)),w	;volatile
iorwf	((i1ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u713_21
	goto	u713_20
u713_21:
	goto	i1l5097
u713_20:
	line	98
	
i1l5095:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	100
;adc_drv.c: 100: }
	goto	i1l494
	line	102
	
i1l5097:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	subwf	(i1ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u714_25
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	subwf	(i1ADC_Sample@admax),w	;volatile
u714_25:
	skipnc
	goto	u714_21
	goto	u714_20
u714_21:
	goto	i1l5101
u714_20:
	line	103
	
i1l5099:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	goto	i1l494
	line	105
	
i1l5101:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	subwf	(i1ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u715_25
	movf	(i1ADC_Sample@admin),w	;volatile
	subwf	(i1ADC_Sample@ad_temp),w	;volatile
u715_25:
	skipnc
	goto	u715_21
	goto	u715_20
u715_21:
	goto	i1l494
u715_20:
	line	106
	
i1l5103:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	108
	
i1l494:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	addwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u716_21
	addwf	(i1ADC_Sample@adsum+1),f	;volatile
u716_21:
	movf	2+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u716_22
	addwf	(i1ADC_Sample@adsum+2),f	;volatile
u716_22:
	movf	3+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u716_23
	addwf	(i1ADC_Sample@adsum+3),f	;volatile
u716_23:

	line	76
	
i1l5105:	
	incf	(i1ADC_Sample@i),f
	goto	i1l5073
	line	112
	
i1l5109:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(i1ADC_Sample@admax),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admax+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u717_25
	goto	u717_26
u717_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u717_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u717_27
	goto	u717_28
u717_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u717_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u717_29
	goto	u717_20
u717_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u717_20:

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	3+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u718_25
	movf	2+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u718_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u718_25
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),w	;volatile
u718_25:
	skipc
	goto	u718_21
	goto	u718_20
u718_21:
	goto	i1l498
u718_20:
	line	114
	
i1l5111:	
;adc_drv.c: 114: adsum -= admin;
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u719_25
	goto	u719_26
u719_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u719_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u719_27
	goto	u719_28
u719_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u719_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u719_29
	goto	u719_20
u719_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u719_20:

	goto	i1l5113
	line	115
	
i1l498:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	118
	
i1l5113:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(i1ADC_Sample@adsum),w	;volatile
	movwf	(??i1_ADC_Sample+0)+0
	movf	(i1ADC_Sample@adsum+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	movf	(i1ADC_Sample@adsum+2),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+2)
	movf	(i1ADC_Sample@adsum+3),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+3)
	movlw	05h
u720_25:
	clrc
	rrf	(??i1_ADC_Sample+0)+3,f
	rrf	(??i1_ADC_Sample+0)+2,f
	rrf	(??i1_ADC_Sample+0)+1,f
	rrf	(??i1_ADC_Sample+0)+0,f
u720_20:
	addlw	-1
	skipz
	goto	u720_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
i1l5115:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
i1l491:	
	return
	opt stack 0
GLOBAL	__end_ofi1_ADC_Sample
	__end_ofi1_ADC_Sample:
	signat	i1_ADC_Sample,89
	global	_Update_LED_Slot

;; *************** function _Update_LED_Slot *****************
;; Defined at:
;;		line 28 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    3[COMMON] unsigned char 
;;  s               1    8[COMMON] unsigned char 
;;  i               1    7[COMMON] unsigned char 
;;  hasFull         1    6[COMMON] unsigned char 
;;  hasChg          1    5[COMMON] unsigned char 
;;  hasErr          1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         6       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         6       0       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	28
global __ptext24
__ptext24:	;psect for function _Update_LED_Slot
psect	text24
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	28
	global	__size_of_Update_LED_Slot
	__size_of_Update_LED_Slot	equ	__end_of_Update_LED_Slot-_Update_LED_Slot
	
_Update_LED_Slot:	
;incstack = 0
	opt	stack 2
; Regs used in _Update_LED_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Update_LED_Slot@idx stored from wreg
	movwf	(Update_LED_Slot@idx)
	line	31
	
i1l7431:	
;led.c: 30: unsigned char i;
;led.c: 31: unsigned char hasErr = 0;
	clrf	(Update_LED_Slot@hasErr)
	line	32
;led.c: 32: unsigned char hasChg = 0;
	clrf	(Update_LED_Slot@hasChg)
	line	33
;led.c: 33: unsigned char hasFull = 0;
	clrf	(Update_LED_Slot@hasFull)
	line	35
;led.c: 35: for(i = 0; i < 12; i++)
	clrf	(Update_LED_Slot@i)
	line	37
	
i1l7437:	
;led.c: 36: {
;led.c: 37: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Update_LED_Slot@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Slot@s)
	line	38
	
i1l7439:	
;led.c: 38: if(s == 7)
		movlw	7
	xorwf	((Update_LED_Slot@s)),w
	btfss	status,2
	goto	u1140_21
	goto	u1140_20
u1140_21:
	goto	i1l7443
u1140_20:
	line	39
	
i1l7441:	
;led.c: 39: hasErr = 1;
	clrf	(Update_LED_Slot@hasErr)
	incf	(Update_LED_Slot@hasErr),f
	goto	i1l7453
	line	40
	
i1l7443:	
;led.c: 40: else if(s != 0 && s != 6)
	movf	((Update_LED_Slot@s)),w
	btfsc	status,2
	goto	u1141_21
	goto	u1141_20
u1141_21:
	goto	i1l7449
u1141_20:
	
i1l7445:	
		movlw	6
	xorwf	((Update_LED_Slot@s)),w
	btfsc	status,2
	goto	u1142_21
	goto	u1142_20
u1142_21:
	goto	i1l7449
u1142_20:
	line	41
	
i1l7447:	
;led.c: 41: hasChg = 1;
	clrf	(Update_LED_Slot@hasChg)
	incf	(Update_LED_Slot@hasChg),f
	goto	i1l7453
	line	42
	
i1l7449:	
;led.c: 42: else if(s == 6)
		movlw	6
	xorwf	((Update_LED_Slot@s)),w
	btfss	status,2
	goto	u1143_21
	goto	u1143_20
u1143_21:
	goto	i1l7453
u1143_20:
	line	43
	
i1l7451:	
;led.c: 43: hasFull = 1;
	clrf	(Update_LED_Slot@hasFull)
	incf	(Update_LED_Slot@hasFull),f
	line	35
	
i1l7453:	
	incf	(Update_LED_Slot@i),f
	
i1l7455:	
	movlw	low(0Ch)
	subwf	(Update_LED_Slot@i),w
	skipc
	goto	u1144_21
	goto	u1144_20
u1144_21:
	goto	i1l7437
u1144_20:
	line	46
	
i1l7457:	
;led.c: 44: }
;led.c: 46: if(hasErr)
	movf	((Update_LED_Slot@hasErr)),w
	btfsc	status,2
	goto	u1145_21
	goto	u1145_20
u1145_21:
	goto	i1l7469
u1145_20:
	line	49
	
i1l7459:	
;led.c: 47: {
;led.c: 49: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	50
	
i1l7461:	
;led.c: 50: if(idx == 0)
	movf	((Update_LED_Slot@idx)),w
	btfss	status,2
	goto	u1146_21
	goto	u1146_20
u1146_21:
	goto	i1l909
u1146_20:
	line	52
	
i1l7463:	
;led.c: 51: {
;led.c: 52: if(++s_ledBlinkCnt >= (100 / 2))
	movlw	low(032h)
	incf	(_s_ledBlinkCnt),f	;volatile
	subwf	((_s_ledBlinkCnt)),w	;volatile
	skipc
	goto	u1147_21
	goto	u1147_20
u1147_21:
	goto	i1l7467
u1147_20:
	line	53
	
i1l7465:	
;led.c: 53: s_ledBlinkCnt = 0;
	clrf	(_s_ledBlinkCnt)	;volatile
	line	54
	
i1l7467:	
;led.c: 54: RC5 = (s_ledBlinkCnt < ((100 / 2) / 2)) ? 0 : 1;
	movlw	low(019h)
	subwf	(_s_ledBlinkCnt),w	;volatile
	skipnc
	goto	u1148_21
	goto	u1148_20
	
u1148_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u1149_24
u1148_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u1149_24:
	goto	i1l909
	line	57
	
i1l7469:	
;led.c: 57: else if(hasChg)
	movf	((Update_LED_Slot@hasChg)),w
	btfsc	status,2
	goto	u1150_21
	goto	u1150_20
u1150_21:
	goto	i1l7473
u1150_20:
	line	60
	
i1l7471:	
;led.c: 58: {
;led.c: 60: RC5 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	61
;led.c: 61: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	62
;led.c: 62: }
	goto	i1l909
	line	63
	
i1l7473:	
;led.c: 63: else if(hasFull)
	movf	((Update_LED_Slot@hasFull)),w
	btfsc	status,2
	goto	u1151_21
	goto	u1151_20
u1151_21:
	goto	i1l907
u1151_20:
	line	66
	
i1l7475:	
;led.c: 64: {
;led.c: 66: RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	67
;led.c: 67: RC4 = 0;
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	68
;led.c: 68: }
	goto	i1l909
	line	69
	
i1l907:	
	line	72
;led.c: 69: else
;led.c: 70: {
;led.c: 72: RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	73
;led.c: 73: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	75
	
i1l909:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Slot
	__end_of_Update_LED_Slot:
	signat	_Update_LED_Slot,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 84 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	line	84
global __ptext25
__ptext25:	;psect for function _PowerOnLedSequence
psect	text25
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	84
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	86
	
i1l3669:	
;led.c: 86: g_powerOnTimer++;
	incf	(_g_powerOnTimer),f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1),f	;volatile
	line	88
	
i1l3671:	
;led.c: 88: if(g_powerOnPhase == 0)
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u418_21
	goto	u418_20
u418_21:
	goto	i1l3681
u418_20:
	line	91
	
i1l3673:	
;led.c: 89: {
;led.c: 91: RC5 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	92
;led.c: 92: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	93
	
i1l3675:	
;led.c: 93: if(g_powerOnTimer >= 100)
	movlw	0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u419_21
	goto	u419_20
u419_21:
	goto	i1l917
u419_20:
	line	95
	
i1l3677:	
;led.c: 94: {
;led.c: 95: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	96
	
i1l3679:	
;led.c: 96: g_powerOnPhase = 1;
	movlw	low(01h)
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l917
	line	99
	
i1l3681:	
;led.c: 99: else if(g_powerOnPhase == 1)
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u420_21
	goto	u420_20
u420_21:
	goto	i1l917
u420_20:
	line	102
	
i1l3683:	
;led.c: 100: {
;led.c: 102: RC5 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	103
;led.c: 103: RC4 = 0;
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	104
	
i1l3685:	
;led.c: 104: if(g_powerOnTimer >= 100)
	movlw	0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u421_21
	goto	u421_20
u421_21:
	goto	i1l917
u421_20:
	line	106
	
i1l3687:	
;led.c: 105: {
;led.c: 106: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	107
	
i1l3689:	
;led.c: 107: g_powerOnPhase = 2;
	movlw	low(02h)
	movwf	(_g_powerOnPhase)	;volatile
	line	111
	
i1l917:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
	global	_Charging_Control

;; *************** function _Charging_Control *****************
;; Defined at:
;;		line 1111 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    3[COMMON] unsigned char 
;;  i               1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1111
global __ptext26
__ptext26:	;psect for function _Charging_Control
psect	text26
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1111
	global	__size_of_Charging_Control
	__size_of_Charging_Control	equ	__end_of_Charging_Control-_Charging_Control
	
_Charging_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _Charging_Control: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1116
	
i1l7477:	
;charge_mgr.c: 1113: unsigned char i;
;charge_mgr.c: 1116: if(g_tempProtect)
	movf	((_g_tempProtect)),w
	btfsc	status,2
	goto	u1152_21
	goto	u1152_20
u1152_21:
	goto	i1l7483
u1152_20:
	line	1118
;charge_mgr.c: 1117: {
;charge_mgr.c: 1118: do { RA0=1; RA1=1; RB3=1; RB2=1; RA3=1; RA2=1; RD1=1; RD3=1; RB0=1; RB1=1; RD2=1; RD0=1; } while(0);
	
i1l793:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	bsf	(1073/8)^080h,(1073)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	bsf	(50/8),(50)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	bsf	(1074/8)^080h,(1074)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	bsf	(49/8),(49)&7	;volatile
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	line	1119
	
i1l7479:	
;charge_mgr.c: 1119: g_pwmDuty = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	goto	i1l795
	line	1126
	
i1l7483:	
;charge_mgr.c: 1121: }
;charge_mgr.c: 1126: if(g_vccProtect)
	bcf	status, 5	;RP0=0, select bank0
	movf	((_g_vccProtect)),w
	btfsc	status,2
	goto	u1153_21
	goto	u1153_20
u1153_21:
	goto	i1l7493
u1153_20:
	line	1128
	
i1l7485:	
;charge_mgr.c: 1127: {
;charge_mgr.c: 1128: if(g_vcc_mv < 4600)
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u1154_21
	goto	u1154_20
u1154_21:
	goto	i1l7491
u1154_20:
	goto	i1l793
	line	1134
	
i1l7491:	
;charge_mgr.c: 1133: }
;charge_mgr.c: 1134: g_vccProtect = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	line	1135
;charge_mgr.c: 1135: }
	goto	i1l7501
	line	1138
	
i1l7493:	
;charge_mgr.c: 1136: else
;charge_mgr.c: 1137: {
;charge_mgr.c: 1138: if(g_vcc_mv < 4400)
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u1155_21
	goto	u1155_20
u1155_21:
	goto	i1l7501
u1155_20:
	line	1140
	
i1l7495:	
;charge_mgr.c: 1139: {
;charge_mgr.c: 1140: g_vccProtect = 1;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	incf	(_g_vccProtect),f
	goto	i1l793
	line	1148
	
i1l7501:	
;charge_mgr.c: 1144: }
;charge_mgr.c: 1145: }
;charge_mgr.c: 1148: for(i = 0; i < 12; i++)
	clrf	(Charging_Control@i)
	line	1150
	
i1l7507:	
;charge_mgr.c: 1149: {
;charge_mgr.c: 1150: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Charging_Control@s)
	line	1155
	
i1l7509:	
;charge_mgr.c: 1153: if(s == 2 || s == 3 ||
;charge_mgr.c: 1154: s == 4 || s == 5 ||
;charge_mgr.c: 1155: s == 8)
		movlw	2
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1156_21
	goto	u1156_20
u1156_21:
	goto	i1l7521
u1156_20:
	
i1l7511:	
		movlw	3
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1157_21
	goto	u1157_20
u1157_21:
	goto	i1l7521
u1157_20:
	
i1l7513:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1158_21
	goto	u1158_20
u1158_21:
	goto	i1l7521
u1158_20:
	
i1l7515:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1159_21
	goto	u1159_20
u1159_21:
	goto	i1l7521
u1159_20:
	
i1l7517:	
		movlw	8
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u1160_21
	goto	u1160_20
u1160_21:
	goto	i1l7523
u1160_20:
	goto	i1l7521
	line	1157
	
i1l811:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l7533
	
i1l813:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l7533
	
i1l814:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l7533
	
i1l815:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l7533
	
i1l816:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l7533
	
i1l817:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l7533
	
i1l818:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l7533
	
i1l819:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l7533
	
i1l820:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l7533
	
i1l821:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l7533
	
i1l822:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l7533
	
i1l823:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l7533
	
i1l7521:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l811
	xorlw	1^0	; case 1
	skipnz
	goto	i1l813
	xorlw	2^1	; case 2
	skipnz
	goto	i1l814
	xorlw	3^2	; case 3
	skipnz
	goto	i1l815
	xorlw	4^3	; case 4
	skipnz
	goto	i1l816
	xorlw	5^4	; case 5
	skipnz
	goto	i1l817
	xorlw	6^5	; case 6
	skipnz
	goto	i1l818
	xorlw	7^6	; case 7
	skipnz
	goto	i1l819
	xorlw	8^7	; case 8
	skipnz
	goto	i1l820
	xorlw	9^8	; case 9
	skipnz
	goto	i1l821
	xorlw	10^9	; case 10
	skipnz
	goto	i1l822
	xorlw	11^10	; case 11
	skipnz
	goto	i1l823
	goto	i1l7533
	opt asmopt_pop

	line	1160
	
i1l7523:	
;charge_mgr.c: 1160: else if(s == 1)
		decf	((Charging_Control@s)),w
	btfss	status,2
	goto	u1161_21
	goto	u1161_20
u1161_21:
	goto	i1l7531
u1161_20:
	line	1162
	
i1l7527:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l811
	xorlw	1^0	; case 1
	skipnz
	goto	i1l813
	xorlw	2^1	; case 2
	skipnz
	goto	i1l814
	xorlw	3^2	; case 3
	skipnz
	goto	i1l815
	xorlw	4^3	; case 4
	skipnz
	goto	i1l816
	xorlw	5^4	; case 5
	skipnz
	goto	i1l817
	xorlw	6^5	; case 6
	skipnz
	goto	i1l818
	xorlw	7^6	; case 7
	skipnz
	goto	i1l819
	xorlw	8^7	; case 8
	skipnz
	goto	i1l820
	xorlw	9^8	; case 9
	skipnz
	goto	i1l821
	xorlw	10^9	; case 10
	skipnz
	goto	i1l822
	xorlw	11^10	; case 11
	skipnz
	goto	i1l823
	goto	i1l7533
	opt asmopt_pop

	line	1166
	
i1l846:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l7533
	
i1l848:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l7533
	
i1l849:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	i1l7533
	
i1l850:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	i1l7533
	
i1l851:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l7533
	
i1l852:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l7533
	
i1l853:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l7533
	
i1l854:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l7533
	
i1l855:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	i1l7533
	
i1l856:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	i1l7533
	
i1l857:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l7533
	
i1l858:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l7533
	
i1l7531:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l846
	xorlw	1^0	; case 1
	skipnz
	goto	i1l848
	xorlw	2^1	; case 2
	skipnz
	goto	i1l849
	xorlw	3^2	; case 3
	skipnz
	goto	i1l850
	xorlw	4^3	; case 4
	skipnz
	goto	i1l851
	xorlw	5^4	; case 5
	skipnz
	goto	i1l852
	xorlw	6^5	; case 6
	skipnz
	goto	i1l853
	xorlw	7^6	; case 7
	skipnz
	goto	i1l854
	xorlw	8^7	; case 8
	skipnz
	goto	i1l855
	xorlw	9^8	; case 9
	skipnz
	goto	i1l856
	xorlw	10^9	; case 10
	skipnz
	goto	i1l857
	xorlw	11^10	; case 11
	skipnz
	goto	i1l858
	goto	i1l7533
	opt asmopt_pop

	line	1148
	
i1l7533:	
	incf	(Charging_Control@i),f
	
i1l7535:	
	movlw	low(0Ch)
	subwf	(Charging_Control@i),w
	skipc
	goto	u1162_21
	goto	u1162_20
u1162_21:
	goto	i1l7507
u1162_20:
	line	1171
	
i1l795:	
	return
	opt stack 0
GLOBAL	__end_of_Charging_Control
	__end_of_Charging_Control:
	signat	_Charging_Control,89
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 1189 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    6[BANK0 ] unsigned int 
;;  s               1   17[BANK0 ] unsigned char 
;;  duty            2   14[BANK0 ] int 
;;  error           2   10[BANK0 ] int 
;;  adjust          2    0[BANK0 ] int 
;;  duty_initial    1   13[BANK0 ] unsigned char 
;;  duty_target     1   12[BANK0 ] unsigned char 
;;  maxV            2    8[BANK0 ] unsigned int 
;;  i               1   16[BANK0 ] unsigned char 
;;  preCount        1    5[BANK0 ] unsigned char 
;;  ccCount         1    4[BANK0 ] unsigned char 
;;  cvCount         1    3[BANK0 ] unsigned char 
;;  hasCharging     1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2      18       0       0       0
;;Total ram usage:       20 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___awdiv
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=0
	line	1189
global __ptext27
__ptext27:	;psect for function _CCCV_Control
psect	text27
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1189
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1192
	
i1l7537:	
;charge_mgr.c: 1191: unsigned char i;
;charge_mgr.c: 1192: unsigned char hasCharging = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	1193
;charge_mgr.c: 1193: unsigned int maxV = 0;
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	1194
;charge_mgr.c: 1194: unsigned char cvCount = 0;
	clrf	(CCCV_Control@cvCount)
	line	1195
;charge_mgr.c: 1195: unsigned char ccCount = 0;
	clrf	(CCCV_Control@ccCount)
	line	1196
;charge_mgr.c: 1196: unsigned char preCount = 0;
	clrf	(CCCV_Control@preCount)
	line	1199
;charge_mgr.c: 1199: for(i = 0; i < 12; i++)
	clrf	(CCCV_Control@i)
	line	1201
	
i1l7543:	
;charge_mgr.c: 1200: {
;charge_mgr.c: 1201: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	1205
	
i1l7545:	
;charge_mgr.c: 1203: if(s == 2 || s == 3 ||
;charge_mgr.c: 1204: s == 4 || s == 5 ||
;charge_mgr.c: 1205: s == 8)
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1163_21
	goto	u1163_20
u1163_21:
	goto	i1l866
u1163_20:
	
i1l7547:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1164_21
	goto	u1164_20
u1164_21:
	goto	i1l866
u1164_20:
	
i1l7549:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1165_21
	goto	u1165_20
u1165_21:
	goto	i1l866
u1165_20:
	
i1l7551:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1166_21
	goto	u1166_20
u1166_21:
	goto	i1l866
u1166_20:
	
i1l7553:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1167_21
	goto	u1167_20
u1167_21:
	goto	i1l864
u1167_20:
	
i1l866:	
	line	1207
;charge_mgr.c: 1206: {
;charge_mgr.c: 1207: hasCharging = 1;
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	1209
	
i1l7555:	
;charge_mgr.c: 1208: {
;charge_mgr.c: 1209: unsigned int vt = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	1210
	
i1l7557:	
;charge_mgr.c: 1210: if(vt > maxV) maxV = vt;
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u1168_25
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u1168_25:
	skipnc
	goto	u1168_21
	goto	u1168_20
u1168_21:
	goto	i1l7561
u1168_20:
	
i1l7559:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	1212
	
i1l7561:	
;charge_mgr.c: 1211: }
;charge_mgr.c: 1212: if(s == 5)
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1169_21
	goto	u1169_20
u1169_21:
	goto	i1l7565
u1169_20:
	line	1213
	
i1l7563:	
;charge_mgr.c: 1213: cvCount++;
	incf	(CCCV_Control@cvCount),f
	line	1214
	
i1l7565:	
;charge_mgr.c: 1214: if(s == 4)
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1170_21
	goto	u1170_20
u1170_21:
	goto	i1l7569
u1170_20:
	line	1215
	
i1l7567:	
;charge_mgr.c: 1215: ccCount++;
	incf	(CCCV_Control@ccCount),f
	line	1216
	
i1l7569:	
;charge_mgr.c: 1216: if(s == 3 || s == 2)
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1171_21
	goto	u1171_20
u1171_21:
	goto	i1l7573
u1171_20:
	
i1l7571:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1172_21
	goto	u1172_20
u1172_21:
	goto	i1l864
u1172_20:
	line	1217
	
i1l7573:	
;charge_mgr.c: 1217: preCount++;
	incf	(CCCV_Control@preCount),f
	line	1218
	
i1l864:	
	line	1199
	incf	(CCCV_Control@i),f
	
i1l7575:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u1173_21
	goto	u1173_20
u1173_21:
	goto	i1l7543
u1173_20:
	line	1222
	
i1l7577:	
;charge_mgr.c: 1218: }
;charge_mgr.c: 1219: }
;charge_mgr.c: 1222: if(!hasCharging)
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u1174_21
	goto	u1174_20
u1174_21:
	goto	i1l7583
u1174_20:
	line	1224
	
i1l7579:	
;charge_mgr.c: 1223: {
;charge_mgr.c: 1224: g_pwmDuty = 0;
	clrf	(_g_pwmDuty)	;volatile
	line	1225
;charge_mgr.c: 1225: g_cvIntegral = 0;
	clrf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l874
	line	1233
	
i1l7583:	
;charge_mgr.c: 1227: }
;charge_mgr.c: 1233: if(cvCount == 0)
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u1175_21
	goto	u1175_20
u1175_21:
	goto	i1l7613
u1175_20:
	line	1237
	
i1l7585:	
;charge_mgr.c: 1234: {
;charge_mgr.c: 1235: unsigned char duty_target, duty_initial;
;charge_mgr.c: 1237: if(ccCount > 0)
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u1176_21
	goto	u1176_20
u1176_21:
	goto	i1l7589
u1176_20:
	line	1240
	
i1l7587:	
;charge_mgr.c: 1238: {
;charge_mgr.c: 1240: duty_target = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	1241
;charge_mgr.c: 1241: duty_initial = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	1242
;charge_mgr.c: 1242: }
	goto	i1l7597
	line	1243
	
i1l7589:	
;charge_mgr.c: 1243: else if(preCount > 0)
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u1177_21
	goto	u1177_20
u1177_21:
	goto	i1l7593
u1177_20:
	line	1246
	
i1l7591:	
;charge_mgr.c: 1244: {
;charge_mgr.c: 1246: duty_target = 8;
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	1247
;charge_mgr.c: 1247: duty_initial = 5;
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	1248
;charge_mgr.c: 1248: }
	goto	i1l7597
	line	1253
	
i1l7593:	
;charge_mgr.c: 1249: else
;charge_mgr.c: 1250: {
;charge_mgr.c: 1253: g_pwmDuty = 25;
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l874
	line	1257
	
i1l7597:	
;charge_mgr.c: 1255: }
;charge_mgr.c: 1257: if(g_pwmDuty < duty_initial)
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u1178_21
	goto	u1178_20
u1178_21:
	goto	i1l7605
u1178_20:
	line	1260
	
i1l7599:	
;charge_mgr.c: 1258: {
;charge_mgr.c: 1260: g_pwmDuty += 3;
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	1261
	
i1l7601:	
;charge_mgr.c: 1261: if(g_pwmDuty > duty_initial)
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u1179_21
	goto	u1179_20
u1179_21:
	goto	i1l874
u1179_20:
	line	1262
	
i1l7603:	
;charge_mgr.c: 1262: g_pwmDuty = duty_initial;
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l874
	line	1264
	
i1l7605:	
	line	1267
	
i1l7607:	
;charge_mgr.c: 1265: {
;charge_mgr.c: 1267: g_pwmDuty = duty_target;
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	1268
;charge_mgr.c: 1268: }
	goto	i1l874
	line	1283
	
i1l7613:	
;charge_mgr.c: 1275: }
;charge_mgr.c: 1282: {
;charge_mgr.c: 1283: int error = (int)(3100) - (int)(maxV);
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	1286
;charge_mgr.c: 1286: g_cvIntegral += error * 1;
	movf	(CCCV_Control@error),w
	addwf	(_g_cvIntegral),f
	skipnc
	incf	(_g_cvIntegral+1),f
	movf	(CCCV_Control@error+1),w
	addwf	(_g_cvIntegral+1),f
	line	1287
	
i1l7615:	
;charge_mgr.c: 1287: if(g_cvIntegral > 200)
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u1180_25
	movlw	0C9h
	subwf	(_g_cvIntegral),w
u1180_25:

	skipc
	goto	u1180_21
	goto	u1180_20
u1180_21:
	goto	i1l7619
u1180_20:
	line	1288
	
i1l7617:	
;charge_mgr.c: 1288: g_cvIntegral = 200;
	movlw	0C8h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l7623
	line	1289
	
i1l7619:	
;charge_mgr.c: 1289: else if(g_cvIntegral < -200)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u1181_25
	movlw	038h
	subwf	(_g_cvIntegral),w
u1181_25:

	skipnc
	goto	u1181_21
	goto	u1181_20
u1181_21:
	goto	i1l7623
u1181_20:
	line	1290
	
i1l7621:	
;charge_mgr.c: 1290: g_cvIntegral = -200;
	movlw	038h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	movlw	0FFh
	movwf	((_g_cvIntegral))+1
	line	1293
	
i1l7623:	
;charge_mgr.c: 1293: int adjust = (error * 4 + g_cvIntegral) / 8;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	movf	(_g_cvIntegral),w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1),w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	1294
	
i1l7625:	
;charge_mgr.c: 1294: int duty = (int)g_pwmDuty + adjust;
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
i1l7627:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	1297
	
i1l7629:	
;charge_mgr.c: 1297: if(duty > 32) duty = 32;
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u1182_25
	movlw	021h
	subwf	(CCCV_Control@duty),w
u1182_25:

	skipc
	goto	u1182_21
	goto	u1182_20
u1182_21:
	goto	i1l7633
u1182_20:
	
i1l7631:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1298
	
i1l7633:	
;charge_mgr.c: 1298: if(duty < 0) duty = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u1183_21
	goto	u1183_20
u1183_21:
	goto	i1l7637
u1183_20:
	
i1l7635:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1300
	
i1l7637:	
;charge_mgr.c: 1300: g_pwmDuty = (unsigned char)duty;
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	1302
	
i1l874:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	i1___bmul

;; *************** function i1___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[COMMON] unsigned char 
;;  __bmul          1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext28
__ptext28:	;psect for function i1___bmul
psect	text28
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_ofi1___bmul
	__size_ofi1___bmul	equ	__end_ofi1___bmul-i1___bmul
	
i1___bmul:	
;incstack = 0
	opt	stack 2
; Regs used in i1___bmul: [wreg+status,2+status,0]
;i1___bmul@multiplier stored from wreg
	movwf	(i1___bmul@multiplier)
	line	6
	
i1l3585:	
	clrf	(i1___bmul@product)
	line	43
	
i1l3587:	
	btfss	(i1___bmul@multiplier),(0)&7
	goto	u415_21
	goto	u415_20
u415_21:
	goto	i1l3591
u415_20:
	line	44
	
i1l3589:	
	movf	(i1___bmul@multiplicand),w
	addwf	(i1___bmul@product),f
	line	45
	
i1l3591:	
	clrc
	rlf	(i1___bmul@multiplicand),f
	line	46
	
i1l3593:	
	clrc
	rrf	(i1___bmul@multiplier),f
	line	47
	movf	((i1___bmul@multiplier)),w
	btfss	status,2
	goto	u416_21
	goto	u416_20
u416_21:
	goto	i1l3587
u416_20:
	line	50
	
i1l3595:	
	movf	(i1___bmul@product),w
	line	51
	
i1l941:	
	return
	opt stack 0
GLOBAL	__end_ofi1___bmul
	__end_ofi1___bmul:
	signat	i1___bmul,89
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] int 
;;  dividend        2    2[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] int 
;;  sign            1    5[COMMON] unsigned char 
;;  counter         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext29
__ptext29:	;psect for function ___awdiv
psect	text29
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
i1l3541:	
	clrf	(___awdiv@sign)
	line	15
	
i1l3543:	
	btfss	(___awdiv@divisor+1),7
	goto	u408_21
	goto	u408_20
u408_21:
	goto	i1l3549
u408_20:
	line	16
	
i1l3545:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
i1l3547:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
i1l3549:	
	btfss	(___awdiv@dividend+1),7
	goto	u409_21
	goto	u409_20
u409_21:
	goto	i1l3555
u409_20:
	line	20
	
i1l3551:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
i1l3553:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
i1l3555:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
i1l3557:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u410_21
	goto	u410_20
u410_21:
	goto	i1l3577
u410_20:
	line	25
	
i1l3559:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	i1l3563
	line	27
	
i1l3561:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
i1l3563:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u411_21
	goto	u411_20
u411_21:
	goto	i1l3561
u411_20:
	line	31
	
i1l3565:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
i1l3567:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u412_25
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u412_25:
	skipc
	goto	u412_21
	goto	u412_20
u412_21:
	goto	i1l3573
u412_20:
	line	33
	
i1l3569:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
i1l3571:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
i1l3573:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
i1l3575:	
	decfsz	(___awdiv@counter),f
	goto	u413_21
	goto	u413_20
u413_21:
	goto	i1l3565
u413_20:
	line	39
	
i1l3577:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u414_21
	goto	u414_20
u414_21:
	goto	i1l3581
u414_20:
	line	40
	
i1l3579:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
i1l3581:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
i1l1053:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
