/*-------------------------------------------
  L1211 12槽充电器 - 充电管理模块
-------------------------------------------*/
#include "config.h"

/*========================================================================
  全局变量
========================================================================*/
unsigned int g_temperature = 250;
unsigned char g_tempProtect = 0;
unsigned char g_vccProtect  = 0;         /* VCC低压保护标志: 1=VCC过低, 关闭充电 */
unsigned int g_impRefV[BATTERY_SLOTS];
unsigned char g_ccBlocks[12];           /* CC阶段10分钟块计数(解决16bit chargeTimer溢出) */
unsigned char g_ovCnt[12];              /* 过压消抖计数器: 连续过压次数 */
unsigned char g_detectLowCnt[12];       /* DETECT低电压消抖: 连续低ADC读数计数 */
unsigned char g_impCheckSlot = 0xFF;    /* IMP_CHECK串行锁: 0xFF=空闲, 其他=持有锁的槽号
                                           同一时间只允许一个槽做IMP_CHECK,
                                           避免NiMH拉垮VCC导致其他槽误判 */
/* 注: g_impRefV[12] 在退出 IMP_CHECK 后被复用为 CC/CV 入口电压峰值 */

/* LED闪烁: 全局统一计数器, 所有ERROR槽共用(省35B RAM) */
unsigned char g_blinkTick = 0;

volatile bit g_detectLogFlag = 0;
volatile unsigned char g_detectLogSlot = 0;
volatile unsigned char g_detectLogType = 0;

unsigned int Read_Temperature(void)
{
	unsigned int ntcVal;
	unsigned int temp_x10;

	test_adc = ADC_Sample(ADC_CH_NTC, 0);
	if(ADC_OK != test_adc)
		return g_temperature;

	ntcVal = adresult;
	if(ntcVal < 100 || ntcVal > 3996)
		return g_temperature;

	{
		unsigned long rt;
		rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
		if(rt >= 10000UL)
			temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
		else
			temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
		if(temp_x10 < 100U) temp_x10 = 100U;
		if(temp_x10 > 750U) temp_x10 = 750U;
	}

	g_temperature = temp_x10;
	if((temp_x10 / 10U) >= TEMP_STOP)
		g_tempProtect = 1;
	else if((temp_x10 / 10U) <= TEMP_RESUME)
		g_tempProtect = 0;

	return temp_x10;
}

unsigned char Detect_BatteryType(unsigned int voltage)
{
	if(voltage >= ADC_V_OPEN)
		return BAT_TYPE_UNKNOWN;
	if(voltage < ADC_V_SHORT)
		return BAT_TYPE_UNKNOWN;

#if NIMH_DETECT_ENABLE
	/* AMBIGUOUS区间[1015,2900]: 1.20V~1.45V, 包含NiMH/碳性/碱性/低压锂电池
	   全部进入IMP_CHECK用脉冲方向+VCC塌陷检测区分
	   (2900,3620]区间: NiMH无法达到, 直接归为LI_ION
	   碳性/碱性若漏入CC, PEAK_DROP会在数秒内纠正 */
	if(voltage >= ADC_V_NIMH_LOW && voltage <= ADC_V_NIMH_MAX)
		return BAT_TYPE_AMBIGUOUS;
#endif

	/* AMBIGUOUS区间以外均为锂电池或空槽
	   [SHORT, NIMH_LOW):     低压/过放锂电池(~0.0V~1.20V)
	   (NIMH_MAX, OPEN):      中高压锂电池(>1.45V) 或 高压碳性/碱性(PEAK_DROP兜底) */
	if(voltage >= ADC_V_SHORT && voltage < ADC_V_OPEN)
		return BAT_TYPE_LI_ION;

	return BAT_TYPE_UNKNOWN;
}

volatile BatterySlot_t g_slot[12];

/* 槽位字段读写辅助宏 */
#define SLOT_RD_ALL(idx, st, ty, v, ct)  do { \
	st = g_slot[(idx)].state; ty = g_slot[(idx)].type; \
	v  = g_slot[(idx)].voltage; ct = g_slot[(idx)].chargeTimer; \
} while(0)

#define SLOT_WR_ALL(idx, st, ty, v, ct)  do { \
	g_slot[(idx)].state = st; g_slot[(idx)].type = ty; \
	g_slot[(idx)].voltage = v; g_slot[(idx)].chargeTimer = ct; \
} while(0)

void ChargeProcess_Slot(unsigned char idx)
{
	unsigned char st, ty;
	unsigned int  v, ct;
	unsigned int  tick = 1;
	unsigned char old_st;                  /* 调试: 保存旧状态 */

	SLOT_RD_ALL(idx, st, ty, v, ct);
	old_st = st;                           /* 记录进入状态机前的状态 */

	switch(st)
	{
	case CHG_IDLE:
		ct = 0;
		st = CHG_DETECT;
		break;

	case CHG_DETECT:
		ct += tick;
		if(ct < TIME_DETECT_WAIT)
			break;

		/* 高内阻电池(碳性/碱性)开槽放电稳定检测:
		   OPEN→DETECT时槽位电容充满近VCC电荷, 高内阻电池放电慢,
		   初始ADC读数偏高(碳性R6P实测: 3745→1972需约8秒)
		   稳定性检测: 到达DETECT_WAIT后保存基准, 每tick对比,
		   若ADC仍在下跌(>DETECT_SETTLE_DROP)则延长等待 */
		if(ct == TIME_DETECT_WAIT)
		{
			g_impRefV[idx] = v;
			break;
		}
		if(ct < TIME_DETECT_WAIT + TIME_DETECT_SETTLE && v < ADC_V_OPEN)
		{
			unsigned int v_ref = g_impRefV[idx];
			if(v_ref < ADC_V_OPEN && v + DETECT_SETTLE_DROP < v_ref)
			{
				g_impRefV[idx] = v;
				break;
			}
		}

		ty = Detect_BatteryType(v);

		/* 消抖: 高内阻电池ADC读数可能跳动到极低值,
		   连续N次低值才判定为UNKNOWN, 避免单次噪点误触发ERROR */
		if(v < ADC_V_SHORT)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < DETECT_LOW_DEBOUNCE)
				break;
		}
		/* 仅对UNKNOWN/NIMH/DRY重置计数器, AMBIGUOUS和LI_ION各自维护消抖计数 */
		else if(ty != BAT_TYPE_AMBIGUOUS && ty != BAT_TYPE_LI_ION)
		{
			g_detectLowCnt[idx] = 0;
		}

		if(ty == BAT_TYPE_AMBIGUOUS)
		{
			/* AMBIGUOUS电压段(1.20V~1.45V): 短脉冲方向检测区分
			   恒压/线性锂电池: 接PWM后芯片切充电模式→电压上升
			   NiMH: 极低内阻等效短路→VCC塌陷(>300mV)
			   干电池: 高内阻限流→电压不升, VCC不塌
			   消抖: 单帧VCC污染可能让空槽(4093)误读为~2243, 需连续2帧确认 */
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			/* 串行化: 同一时间只允许一个槽做IMP_CHECK,
			   避免NiMH极低内阻拉垮整个VCC导致其他槽同时误判 */
			if(g_impCheckSlot != 0xFF && g_impCheckSlot != idx)
				break;                /* 等待其他槽完成IMP_CHECK */
			g_impCheckSlot = idx;
			/* VCC打包: 低12位=脉冲前电压v(0~4095), 高4位=脉冲前VCC编码
			   VCC编码 = (g_vcc_mv+50)/100 - 38, 四舍五入到100mV, 覆盖3800~5100mV范围 */
			g_impRefV[idx] = v | ((unsigned int)(((g_vcc_mv + 50U) / 100U) - 38U) << 12);
			st = CHG_IMP_CHECK;
			ct = 0;
			g_detectLowCnt[idx] = 0;
		}
		else if(ty == BAT_TYPE_LI_ION)
		{
			/* LI_ION: 连续2帧确认, 防止碳性/碱性电池ADC尖峰越过NIMH_HIGH误判 */
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;

			/* DETECT路由: 使用校准后的电池mV判断, 而非原始ADC值
			   深度过放电池(如864mV)内阻高, 直接上78%PWM会导致充电异常
			   用bat_mv判断可将低电压电池路由到PRECHARGE用小电流预充 */
			{
				unsigned long vx_mv = (unsigned long)v * (unsigned long)g_vcc_mv / 4096UL;
				unsigned long bat_mv_long = ALPHA_NUM * vx_mv + BETA_NUM * (unsigned long)g_vcc_mv;
				unsigned int  bat_mv = (unsigned int)((bat_mv_long + CAL_DEN/2UL) / CAL_DEN);

				if(bat_mv <= BAT_MV_ACTIVATE)
				{
					st = CHG_ACTIVATE;
					ct = 0;
					g_ovCnt[idx] = 0;
					g_detectLowCnt[idx] = 0;
				}
				else if(bat_mv < BAT_MV_PRECHARGE)
				{
					st = CHG_PRECHARGE;
					ct = 0;
					g_ovCnt[idx] = 0;
					g_detectLowCnt[idx] = 0;
				}
				else if(bat_mv >= BAT_MV_FULL)
				{
					st = CHG_CV_CHARGE;
					ct = 0;
					g_ovCnt[idx] = 0;
					g_detectLowCnt[idx] = 0;
					g_impRefV[idx] = v;
				}
				else
				{
					st = CHG_CC_CHARGE;
					ct = 0;
					g_ccBlocks[idx] = 0;
					g_ovCnt[idx] = 0;
					g_detectLowCnt[idx] = 0;
					g_impRefV[idx] = v;
				}
			}
		}
		else if(ty == BAT_TYPE_UNKNOWN)
		{
			/* UNKNOWN: 分辨空槽(OPEN)和不可识别电池(SHORT/异常) */
			if(v >= ADC_V_OPEN)
			{
				/* 扩展稳定等待: 恒压锂电池等插入后B1AD电容需放电,
				   初始电压≥OPEN, 延长TIME_DETECT_SETTLE让电容放电到正常值 */
				if(ct < TIME_DETECT_WAIT + TIME_DETECT_SETTLE)
					break;                /* 继续等待电压下降 */
				st = CHG_IDLE;            /* 长时间仍OPEN → 确认空槽 */
				ct = 0;
			}
			else
			{
				st = CHG_ERROR;           /* 电压异常或无法识别 → 报错 */
			}
			g_detectLowCnt[idx] = 0;
		}
		else if(ty == BAT_TYPE_NIMH || ty == BAT_TYPE_DRY)
		{
			st = CHG_ERROR;
			g_detectLowCnt[idx] = 0;
			g_detectLogSlot = idx;
			g_detectLogType = ty;
			g_detectLogFlag = 1;
		}
		break;

	case CHG_IMP_CHECK:
		ct += tick;
		if(ct < IMP_PULSE_TICKS)
			break;

		{
			/* 实时VCC采样: IMP_CHECK期间MOSFET已导通~80ms,
			   NiMH极低内阻会拉低VCC, 此处采样获取当前真实VCC
			   不声明局部变量, 用内联计算节省RAM */
			if(ADC_OK == ADC_Sample(ADC_CH_VREF, 0))
				g_vcc_mv = (unsigned int)(POWER_RATIO / adresult);

			/* ── NiMH VCC塌陷检测(优先级最高) ──
			   g_impRefV[idx]编码: 低12位=脉冲前电压v, 高4位=脉冲前VCC编码(100mV分辨率)
			   还原公式: (解码值+38)*100
			   NiMH极低内阻(0.02~0.1Ω)在78%PWM下等效短路, VCC跌落>300mV
			   碳性/碱性高内阻不会导致VCC塌陷, 杜绝误判 */
			if(((((g_impRefV[idx] >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 300U)
			{
				ty = BAT_TYPE_NIMH;
				st = CHG_ERROR;
				g_impCheckSlot = 0xFF;
				g_detectLogSlot = idx;
				g_detectLogType = BAT_TYPE_NIMH;
				g_detectLogFlag = 1;
				break;
			}

			/* ── 电池拔出检测 ──
			   脉冲前后都是OPEN且VCC未塌(已排除NiMH ADC参考崩塌) → 确实被拔出
			   78%PWM下碳性电池BAT pin电容电荷保留导致伪OPEN读数,
			   但VCC未塌证明非NiMH, 安全判为拔出 */
			if(v >= ADC_V_OPEN)
			{
				ty = BAT_TYPE_UNKNOWN;
				st = CHG_IDLE;
				g_impCheckSlot = 0xFF;
				break;
			}

			/* ── VCC跌落>200mV → Li-ion(充电管理芯片拉载) ──
			   恒压锂电池内部TP4056类charger IC在78%PWM下启动充电,
			   拉载电流导致VCC跌落200~300mV(远小于NiMH的>300mV)
			   碳性/碱性无charger IC, 不会拉载VCC
			   VCC分辨率100mV, 200mV阈值有足够噪声裕量 */
			if(((((g_impRefV[idx] >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 200U)
				goto imp_li_ion;

			/* ── 高压区间(VCC不塌 → NiMH物理不可达) → Li-ion ──
			   恒压锂电池charger IC未激活时VCC不塌, 但电压>2300排除NiMH
			   (NiMH物理上限~2775≈1.45V留余量, 2300对应~1.25V)
			   同时检查脉冲前后电压: 高内阻电池入口读数可能瞬时跌落,
			   取max覆盖瞬态波动, 碳性最高~2243安全被2300排除 */
			if((g_impRefV[idx] & 0x0FFFU) > 2300U || v > 2300U)
				goto imp_li_ion;

			/* ── VCC不塌 + 低压 → 干电池(碳性/碱性) ──
			   不依赖电压上升判断(碳性去极化会产生200+真实上升),
			   纯凭VCC sag区分: 无sag=高内阻=DRY
			   注: 线性锂电池在此区间与碱性电特性高度相似
			   (均无charger IC, VCC不塌, 电压稳定),
			   当前硬件(无电流检测)暂无法可靠区分,
			   保守判为DRY拒充, 避免碱性误充 */
			ty = BAT_TYPE_DRY;
			st = CHG_ERROR;
			g_impCheckSlot = 0xFF;
			g_detectLowCnt[idx] = 0;
			g_detectLogSlot = idx;
			g_detectLogType = BAT_TYPE_DRY;
			g_detectLogFlag = 1;
		}
		break;

		/* ── Li-ion路由(共用代码, goto跳转节省RAM) ── */
		imp_li_ion:
		{
			g_impCheckSlot = 0xFF;
			ty = BAT_TYPE_LI_ION;
			{
				unsigned long vx_mv = (unsigned long)v * (unsigned long)g_vcc_mv / 4096UL;
				unsigned long bat_mv_long = ALPHA_NUM * vx_mv + BETA_NUM * (unsigned long)g_vcc_mv;
				unsigned int  bat_mv = (unsigned int)((bat_mv_long + CAL_DEN/2UL) / CAL_DEN);

				if(bat_mv <= BAT_MV_ACTIVATE)
					st = CHG_ACTIVATE;
				else if(bat_mv < BAT_MV_PRECHARGE)
					st = CHG_PRECHARGE;
				else if(bat_mv >= BAT_MV_FULL)
				{
					st = CHG_CV_CHARGE;
					g_impRefV[idx] = v;
				}
				else
				{
					st = CHG_CC_CHARGE;
					g_ccBlocks[idx] = 0;
					g_impRefV[idx] = v;
				}
				ct = 0;
				g_ovCnt[idx] = 0;
			}
		}
		break;



	case CHG_ACTIVATE:
		ct += tick;
		if(ct > TIME_ACTIVATE_MAX)
		{
			st = CHG_ERROR;
			break;
		}
		if(v > ADC_V_ACTIVATE)
		{
			st = CHG_PRECHARGE;
			ct = 0;
			break;
		}
		if(v >= ADC_V_OVER)
		{
			st = CHG_ERROR;
			break;
		}
		break;

	case CHG_PRECHARGE:
		ct += tick;
		if(ct > TIME_PRECHARGE_MAX)
		{
			st = CHG_ERROR;
			break;
		}
		if(v >= ADC_V_OVER)
		{
			g_ovCnt[idx]++;
			if(g_ovCnt[idx] >= OV_DEBOUNCE_CNT)
			{
				st = CHG_ERROR;
				break;
			}
		}
		else
		{
			g_ovCnt[idx] = 0;
		}
		if(v >= ADC_V_PRE_MAX)
		{
			st = CHG_CC_CHARGE;
			ct = 0;
			g_ccBlocks[idx] = 0;
			g_ovCnt[idx] = 0;
			g_impRefV[idx] = v;
		}
		break;

	case CHG_CC_CHARGE:
		ct += tick;
		if(ct >= CC_BLOCK_TICKS)
		{
			ct -= CC_BLOCK_TICKS;
			g_ccBlocks[idx]++;
		}
		if(g_ccBlocks[idx] >= CC_MAX_BLOCKS)
		{
			st = CHG_ERROR;
			break;
		}

		/* 电压跌落重判: 接触不良导致误判为LI_ION时, 电压会从虚高值跌回真实值
		   例: B1 NiMH接触不良→ADC=3949→误判LI_ION→CV, 接触恢复后ADC=1899(跌落2050)
		   复用 g_impRefV[idx] 追踪CC/CV阶段电压峰值, 退出IMP_CHECK后不再需要原值
		   消抖: 连续2帧跌落才触发, 防单帧VCC污染误中断充电 */
		if(v > g_impRefV[idx]) g_impRefV[idx] = v;
		if(g_impRefV[idx] - v > PEAK_DROP_THRESH)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			g_detectLowCnt[idx] = 0;
			st = CHG_DETECT;
			ct = 0;
			break;
		}
		else
		{
			g_detectLowCnt[idx] = 0;
		}

		if(v >= ADC_V_OVER)
		{
			g_ovCnt[idx]++;
			if(g_ovCnt[idx] >= OV_DEBOUNCE_CNT)
			{
				st = CHG_ERROR;
				break;
			}
		}
		else
		{
			g_ovCnt[idx] = 0;
			if(v >= ADC_V_FULL)
			{
				st = CHG_CV_CHARGE;
				ct = 0;
			}
		}
		break;

	case CHG_CV_CHARGE:
		ct += tick;
		if(ct > TIME_CV_HOLD)
			st = CHG_FULL;

		/* 电池拔出检测: 2帧消抖 */
		if(v >= ADC_V_OPEN)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			g_detectLowCnt[idx] = 0;
			ty = BAT_TYPE_UNKNOWN;
			st = CHG_IDLE;
			ct = 0;
			break;
		}
		g_detectLowCnt[idx] = 0;

		/* 过压保护: CV阶段电压不应超过ADC_V_OVER */
		if(v >= ADC_V_OVER)
		{
			g_ovCnt[idx]++;
			if(g_ovCnt[idx] >= OV_DEBOUNCE_CNT)
			{
				st = CHG_ERROR;
				break;
			}
		}
		else
		{
			g_ovCnt[idx] = 0;
		}
		/* 注意: CV阶段不触发PEAK_DROP重判,
		   VCC瞬降和充电芯片调压波动属正常现象 */
		break;

	case CHG_FULL:
		/* 补电触发: 电压回落至FULL以下, 需连续2帧确认, 防单帧VCC污染误触发 */
		if(v < (ADC_V_FULL - 10))
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			g_detectLowCnt[idx] = 0;
			st = CHG_CC_CHARGE;
			ct = 0;
			g_ovCnt[idx] = 0;
			g_impRefV[idx] = v;
		}
		else
		{
			g_detectLowCnt[idx] = 0;
		}
		break;

	case CHG_ERROR:
		/* 恢复路径: ADC回OPEN → 电池被拔出 → IDLE, 需连续2帧确认 */
		if(v >= ADC_V_OPEN)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			g_detectLowCnt[idx] = 0;
			ty = BAT_TYPE_UNKNOWN;
			st = CHG_IDLE;
			ct = 0;
			break;
		}
		/* NiMH/干电池: 唯一恢复方式是被拔出(上方已处理), 永久锁定
		   串行化IMP_CHECK + >2500 fallback确保碳性/碱性不会被误判,
		   恒压锂电池也不会漏判为DRY, 无需定时重判 */
		if(ty == BAT_TYPE_NIMH || ty == BAT_TYPE_DRY)
		{
			g_detectLowCnt[idx] = 0;
			break;
		}
		/* LI_ION/LINEAR_LI/UNKNOWN: 有电压 → 回DETECT重判, 需连续2帧确认 */
		if(v > ADC_V_ACTIVATE)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			g_detectLowCnt[idx] = 0;
			st = CHG_DETECT;
			ct = 0;
		}
		else
		{
			g_detectLowCnt[idx] = 0;
		}
		break;

	default:
		st = CHG_IDLE;
		break;
	}

	SLOT_WR_ALL(idx, st, ty, v, ct);

	/* 调试: 追踪 slot 0~4 的每一次状态跳转 */
	if(idx <= 4 && st != old_st)
	{
		g_dbgSlot = idx;
		g_dbgOldState = old_st;
		g_dbgNewState = st;
		g_dbgNewType = ty;
		g_dbgVoltage = v;
		g_dbgDetectFlag = 1;
	}
}

/*========================================================================
  函数: Charging_Control
  功能: 12路充电使能控制(含温度保护)
  说明: 每轮扫描结束后调用一次(在槽位0的Phase2中)
  流程:
    1. 温度保护检查: 温度>=60C则关闭所有充电
    2. 遍历12个槽位, 根据状态决定是否充电
    3. 充电状态(ACTIVATE/PRECHARGE/CC_CHARGE/CV_CHARGE): 打开MOSFET
    4. 其他状态: 关闭MOSFET
    5. 有充电则置位组控制(CD1/CD2), PWM占空比由CCCV_Control单独计算
  MOSFET控制: AO3401 P沟道, Gate=Low导通, Gate=High关闭
========================================================================*/
void Charging_Control(void)
{
	unsigned char i;
	unsigned char chargeB1_6 = 0;    /* B1-B6组是否有充电: 0=无, 1=有 */
	unsigned char chargeB7_12 = 0;   /* B7-B12组是否有充电: 0=无, 1=有 */

	/* 温度保护: 温度过高, 关闭所有充电 */
	if(g_tempProtect)
	{
		SLOT_ALL_OFF();             /* 关闭所有MOSFET(Gate=High) */
		PIN_CD1 = 0;                /* 关闭组1充电 */
		PIN_CD2 = 0;                /* 关闭组2充电 */
		g_pwmDuty = 0;              /* ISR中自动输出PWM=0 */
		return;
	}

	/* VCC低压保护: 电源过载时VCC跌落 → 关闭所有充电
	   防止ADC读数异常导致空槽被误判为有电池(VCC崩溃时实测ADC可从4095跌至~2700)
	   200mV回差防抖, 避免临界电压反复开关 */
	if(g_vccProtect)
	{
		if(g_vcc_mv < VCC_UVLO_RESUME)
		{
			SLOT_ALL_OFF();
			PIN_CD1 = 0;
			PIN_CD2 = 0;
			g_pwmDuty = 0;
			return;
		}
		g_vccProtect = 0;          /* VCC恢复, 解除保护 */
	}
	else
	{
		if(g_vcc_mv < VCC_UVLO_STOP)
		{
			g_vccProtect = 1;      /* VCC过低, 触发保护 */
			SLOT_ALL_OFF();
			PIN_CD1 = 0;
			PIN_CD2 = 0;
			g_pwmDuty = 0;
			return;
		}
	}

	/* 遍历12个槽位, 根据状态控制MOSFET */
	for(i = 0; i < BATTERY_SLOTS; i++)
	{
		unsigned char s = S_STATE(i);

		/* 充电状态: 激活/预充/恒流/恒压/阻抗检测 -> 打开MOSFET */
		if(s == CHG_ACTIVATE || s == CHG_PRECHARGE ||
		   s == CHG_CC_CHARGE || s == CHG_CV_CHARGE ||
		   s == CHG_IMP_CHECK)
		{
			SLOT_CHARGE_ON(i);       /* Gate=Low, MOSFET导通 */

			/* 标记所属组有充电 */
			if(i < 6)
				chargeB1_6 = 1;
			else
				chargeB7_12 = 1;
		}
		else
		{
			SLOT_CHARGE_OFF(i);      /* Gate=High, MOSFET关闭 */
		}
	}

	/* 组控制输出: 控制CD1(B1-B6组)和CD2(B7-B12组) */
	PIN_CD1 = chargeB1_6;
	PIN_CD2 = chargeB7_12;

	/* PWM占空比由CCCV_Control()计算, ISR中自动生成波形, 此处不直接操作PIN_PWM */
}

/*========================================================================
  函数: CCCV_Control
  功能: CC-CV恒流恒压PWM占空比自动调节
  说明: 每轮扫描结束后调用(在Charging_Control之后)
  控制策略:
    CC恒流阶段(ACTIVATE/PRECHARGE/CC_CHARGE):
      - 使用固定占空比(CC_DUTY_TARGET=25/32≈78%)
      - 软启动: 每次+CC_DUTY_RAMP_STEP逐步增加到目标值
      - 无电流检测硬件, 通过固定占空比近似恒流效果
    CV恒压阶段(CV_CHARGE):
      - PI闭环控制, 以ADC_V_FULL为目标电压
      - 根据电压误差动态调节PWM占空比
      - 带积分限幅防饱和
  输出: 更新全局变量 g_pwmDuty (0~PWM_MAX),
        ISR中根据g_pwmDuty自动生成PWM波形
========================================================================*/
void CCCV_Control(void)
{
	unsigned char i;
	unsigned char hasCharging = 0;
	unsigned int  maxV = 0;
	unsigned char cvCount = 0;
	unsigned char ccCount = 0;
	unsigned char preCount = 0;

	/* 遍历12槽位, 找出充电状态和最高电压 */
	for(i = 0; i < BATTERY_SLOTS; i++)
	{
		unsigned char s = S_STATE(i);

		if(s == CHG_ACTIVATE || s == CHG_PRECHARGE ||
		   s == CHG_CC_CHARGE || s == CHG_CV_CHARGE ||
		   s == CHG_IMP_CHECK)
		{
			hasCharging = 1;
			{
				unsigned int vt = S_VOLT(i);
				if(vt > maxV) maxV = vt;
			}
			if(s == CHG_CV_CHARGE)
				cvCount++;
			if(s == CHG_CC_CHARGE)
				ccCount++;
			if(s == CHG_PRECHARGE || s == CHG_ACTIVATE)
				preCount++;
		}
	}

	/* 无充电槽位: 关闭PWM, 复位积分 */
	if(!hasCharging)
	{
		g_pwmDuty = 0;
		g_cvIntegral = 0;
		return;
	}

	/* --- CC/PRECHARGE阶段: 固定占空比 + 软启动 ---
	   CC_CHARGE槽存在时: 使用CC_DUTY_TARGET(25/32=78%)
	   仅ACTIVATE/PRECHARGE时: 使用PRE_DUTY_TARGET(8/32=25%)小电流预充
	   避免78%PWM对高内阻深度过放电池造成充电异常 */
	if(cvCount == 0)
	{
		unsigned char duty_target, duty_initial;

		if(ccCount > 0)
		{
			/* 有CC槽位: 使用标准CC占空比 */
			duty_target  = CC_DUTY_TARGET;
			duty_initial = CC_DUTY_INITIAL;
		}
		else if(preCount > 0)
		{
			/* 仅预充/激活: 使用低占空比小电流激活 */
			duty_target  = PRE_DUTY_TARGET;
			duty_initial = PRE_DUTY_INITIAL;
		}
		else
		{
			/* 仅IMP_CHECK槽位: 78%占空比脉冲, 跳过硬启动
			   碳性电池可能短暂进入CC, PEAK_DROP会在数秒内纠正 */
			g_pwmDuty = CC_DUTY_TARGET;
			return;
		}

		if(g_pwmDuty < duty_initial)
		{
			/* 首次充电: 软启动 */
			g_pwmDuty += CC_DUTY_RAMP_STEP;
			if(g_pwmDuty > duty_initial)
				g_pwmDuty = duty_initial;
		}
		else if(g_pwmDuty > duty_target)
		{
			/* 从高占空比回退: 直接使用目标占空比 */
			g_pwmDuty = duty_target;
		}
		else
		{
			/* 维持目标占空比 */
			g_pwmDuty = duty_target;
		}
		return;
	}

	/* --- CV恒压阶段: PI闭环控制 ---
	   目标: 维持电池电压在ADC_V_FULL(1.52V)
	   error > 0: 电压偏低, 需加大占空比
	   error < 0: 电压偏高, 需减小占空比
	   积分项累加稳态误差, 消除静差 */
	{
		int error = (int)(ADC_V_FULL) - (int)(maxV);

		/* 积分累加(带限幅防积分饱和) */
		g_cvIntegral += error * CV_KI;
		if(g_cvIntegral > CV_KI_LIMIT)
			g_cvIntegral = CV_KI_LIMIT;
		else if(g_cvIntegral < -CV_KI_LIMIT)
			g_cvIntegral = -CV_KI_LIMIT;

		/* PI计算: duty = current_duty + (Kp*error + Ki*integral)/8 */
		int adjust = (error * CV_KP + g_cvIntegral) / 8;
		int duty = (int)g_pwmDuty + adjust;

		/* 占空比限幅 */
		if(duty > PWM_MAX) duty = PWM_MAX;
		if(duty < 0)      duty = 0;

		g_pwmDuty = (unsigned char)duty;
	}
}