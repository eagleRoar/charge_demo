#ifndef __CONFIG_H__
#define __CONFIG_H__

#include <sc.h>

#ifndef _XTAL_FREQ
#define _XTAL_FREQ 16000000
#endif

#define POWER_RATIO        (4096UL*1.2*1000)
#define UART_PRINT_EN      1

#define BATTERY_SLOTS      12

#define CHG_IDLE           0
#define CHG_DETECT         1
#define CHG_ACTIVATE       2
#define CHG_PRECHARGE      3
#define CHG_CC_CHARGE      4
#define CHG_CV_CHARGE      5
#define CHG_FULL           6
#define CHG_ERROR          7

#define BAT_TYPE_UNKNOWN   0
#define BAT_TYPE_LI_ION    1
#define BAT_TYPE_NIMH      2
#define BAT_TYPE_DRY       3
#define BAT_TYPE_SHORT     4

#define LED_OFF            0
#define LED_RED_ON         1
#define LED_GREEN_ON       2
#define LED_RED_FLASH      3

#define ADC_V_FULL          188
#define ADC_V_OVER          198
#define ADC_V_PRE_MIN       62
#define ADC_V_PRE_MAX       124
#define ADC_V_ACTIVATE      12
#define ADC_V_SHORT         5
#define ADC_V_NIMH_LOW      136
#define ADC_V_NIMH_HIGH     161

#define TICK_PER_SEC        4000
#define TIME_ACTIVATE_MAX   (60 * TICK_PER_SEC)
#define TIME_PRECHARGE_MAX  (300 * TICK_PER_SEC)
#define TIME_CHARGE_MAX     (10800 * TICK_PER_SEC)
#define TIME_DETECT_WAIT    (2 * TICK_PER_SEC)
#define TIME_CV_HOLD        (600 * TICK_PER_SEC)

#define TEMP_STOP           60
#define TEMP_RESUME         50

#define ADC_CH_B1           0
#define ADC_CH_B2           1
#define ADC_CH_B3           11
#define ADC_CH_B4           10
#define ADC_CH_B5           3
#define ADC_CH_B6           2
#define ADC_CH_B7           23
#define ADC_CH_B8           25
#define ADC_CH_B9           8
#define ADC_CH_B10          9
#define ADC_CH_B11          24
#define ADC_CH_B12          22
#define ADC_CH_NTC          21
#define ADC_CH_VREF         31

#define PIN_PWM             RA6
#define PIN_CD1             RA4
#define PIN_CD2             RA5
#define PIN_LED_IO1         RC5
#define PIN_LED_IO2         RC4
#define PIN_EN              RA7
#define PIN_VCC_SW          RC0

#define PIN_B1_CTRL         RA0
#define PIN_B2_CTRL         RA1
#define PIN_B3_CTRL         RB3
#define PIN_B4_CTRL         RB2
#define PIN_B5_CTRL         RA3
#define PIN_B6_CTRL         RA2
#define PIN_B7_CTRL         RD1
#define PIN_B8_CTRL         RD3
#define PIN_B9_CTRL         RB0
#define PIN_B10_CTRL        RB1
#define PIN_B11_CTRL        RD2
#define PIN_B12_CTRL        RD0

#define SLOT_CHARGE_ON(idx)    do { \
	switch(idx) { \
	case 0: PIN_B1_CTRL=0; break;  case 1: PIN_B2_CTRL=0; break; \
	case 2: PIN_B3_CTRL=0; break;  case 3: PIN_B4_CTRL=0; break; \
	case 4: PIN_B5_CTRL=0; break;  case 5: PIN_B6_CTRL=0; break; \
	case 6: PIN_B7_CTRL=0; break;  case 7: PIN_B8_CTRL=0; break; \
	case 8: PIN_B9_CTRL=0; break;  case 9: PIN_B10_CTRL=0; break; \
	case 10: PIN_B11_CTRL=0; break; case 11: PIN_B12_CTRL=0; break; \
	} \
} while(0)

#define SLOT_CHARGE_OFF(idx)   do { \
	switch(idx) { \
	case 0: PIN_B1_CTRL=1; break;  case 1: PIN_B2_CTRL=1; break; \
	case 2: PIN_B3_CTRL=1; break;  case 3: PIN_B4_CTRL=1; break; \
	case 4: PIN_B5_CTRL=1; break;  case 5: PIN_B6_CTRL=1; break; \
	case 6: PIN_B7_CTRL=1; break;  case 7: PIN_B8_CTRL=1; break; \
	case 8: PIN_B9_CTRL=1; break;  case 9: PIN_B10_CTRL=1; break; \
	case 10: PIN_B11_CTRL=1; break; case 11: PIN_B12_CTRL=1; break; \
	} \
} while(0)

#define SLOT_ALL_OFF()  do { \
	PIN_B1_CTRL=1; PIN_B2_CTRL=1; PIN_B3_CTRL=1; PIN_B4_CTRL=1; \
	PIN_B5_CTRL=1; PIN_B6_CTRL=1; PIN_B7_CTRL=1; PIN_B8_CTRL=1; \
	PIN_B9_CTRL=1; PIN_B10_CTRL=1; PIN_B11_CTRL=1; PIN_B12_CTRL=1; \
} while(0)

typedef struct {
	unsigned char type;
	unsigned char state;
	unsigned char ledState;
	unsigned int  voltage;
	unsigned int  chargeTimer;
	unsigned int  blinkTimer;
	unsigned char blinkPhase;
	unsigned char stableCnt;
	unsigned char activatePulseCnt;
} BatterySlot_t;

typedef struct {
	volatile unsigned char *tris_reg;
	volatile unsigned char *port_reg;
	unsigned char pin_mask;
	volatile unsigned char *ansel_reg;
	unsigned char ansel_mask;
} SlotPinConfig_t;

extern volatile unsigned int adresult;
extern volatile unsigned int power_ad;
extern volatile unsigned char test_adc;

extern BatterySlot_t g_slot0[6];
extern BatterySlot_t g_slot1[6];

#define GSLOT(idx) (((idx) < 6) ? &g_slot0[(idx)] : &g_slot1[(idx)-6])

extern unsigned int  g_timerTick;
extern unsigned int  g_systemTick;
extern unsigned int  g_ntcAdc;
extern unsigned char g_temperature;
extern unsigned char g_tempProtect;
extern unsigned char g_scanIndex;
extern unsigned char g_scanPhase;
extern unsigned int  g_powerOnTimer;
extern unsigned char g_powerOnPhase;

extern unsigned char RxTable[10];
extern bit RXOK_f;

extern const unsigned char s_adcChannels[BATTERY_SLOTS];
extern const SlotPinConfig_t s_slotPins[BATTERY_SLOTS];

void System_Init(void);
void SlotPin_ToAnalog(unsigned char idx);
void SlotPin_ToDigital(unsigned char idx);

void AD_Init(void);
unsigned char ADC_Sample(unsigned char adch, unsigned char adldo);
unsigned int  ADC_ReadChannel(unsigned char ch);

unsigned char Read_Temperature(void);
unsigned char Detect_BatteryType(unsigned int voltage);
void ChargeProcess_Slot(unsigned char idx);
void Charging_Control(void);

void Update_LED_Slot(unsigned char idx);
void Led_BlinkProcess(void);
void PowerOnLedSequence(void);

#if UART_PRINT_EN
void uart_send_char(unsigned char c);
void uart_send_string(const unsigned char *str);
void uart_send_number(unsigned int num);
void Print_Status(void);
#endif

#endif