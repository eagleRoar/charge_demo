#include "config.h"

unsigned char RxTable[10];
bit RXOK_f;

#if UART_PRINT_EN
void uart_send_char(unsigned char c)
{
	while(TRMT1 == 0);
	TXREG1 = c;
}

void uart_send_string(const unsigned char *str)
{
	while(*str != '\0')
		uart_send_char(*str++);
}

void uart_send_number(unsigned int num)
{
	unsigned char buf[6];
	unsigned char i = 0;
	unsigned char j;

	if(num == 0)
	{
		uart_send_char('0');
		return;
	}

	while(num > 0)
	{
		buf[i++] = '0' + (num % 10);
		num /= 10;
	}

	for(j = i; j > 0; j--)
		uart_send_char(buf[j-1]);
}

void Print_Status(void)
{
	unsigned char i;

	uart_send_string("T:");
	uart_send_number(g_temperature);
	uart_send_string("C VDD:");
	uart_send_number(power_ad);
	uart_send_string("mV\r\n");

	for(i = 0; i < BATTERY_SLOTS; i++)
	{
		uart_send_string("B");
		uart_send_number(i + 1);
		uart_send_string(":V=");
		uart_send_number(GSLOT(i)->voltage);
		uart_send_string(" S=");
		uart_send_number(GSLOT(i)->state);
		uart_send_string(" T=");
		uart_send_number(GSLOT(i)->type);

		if(GSLOT(i)->state == CHG_ERROR)
			uart_send_string(" ERR");
		else if(GSLOT(i)->state == CHG_FULL)
			uart_send_string(" FULL");
		else if(GSLOT(i)->state == CHG_CC_CHARGE || 
		        GSLOT(i)->state == CHG_CV_CHARGE)
			uart_send_string(" CHG");

		uart_send_string("\r\n");
	}
}
#endif