#include "config.h"

volatile unsigned int adresult;
volatile unsigned char test_adc;

void AD_Init(void)
{
	CC0CON = 0;
	CC1CON = 0;
	ADCON0 = 0X41;
	ADCON1 = 0;
}

unsigned char ADC_Sample(unsigned char adch, unsigned char adldo)
{
	volatile unsigned long adsum = 0;
	volatile unsigned int admin = 0, admax = 0;
	volatile unsigned int ad_temp = 0;

	if ((!LDO_EN) && (adldo & 0x04))
	{
		ADCON1 = adldo;
		__delay_us(100);
	}
	else
		ADCON1 = adldo;

	if(adch & 0x10)
	{
		CHS4 = 1;
		adch &= 0x0f;
	}
	else
		CHS4 = 0;

	unsigned char i = 0;
	for (i = 0; i < 10; i++)
	{
		ADCON0 = (unsigned char)(0X41 | (adch << 2));
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		GODONE = 1;

		unsigned char j = 0;
		while (GODONE)
		{
			__delay_us(2);
			if (0 == (--j))
				return 0;
		}

		ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));

		if (0 == admax)
		{
			admax = ad_temp;
			admin = ad_temp;
		}
		else if (ad_temp > admax)
			admax = ad_temp;
		else if (ad_temp < admin)
			admin = ad_temp;

		adsum += ad_temp;
	}

	adsum -= admax;
	if (adsum >= admin)
		adsum -= admin;
	else
		adsum = 0;

	adresult = adsum >> 3;

	adsum = 0;
	admin = 0;
	admax = 0;
	return 0xA5;
}

unsigned int ADC_ReadChannel(unsigned char ch)
{
	test_adc = ADC_Sample(ch, 7);
	if (0xA5 == test_adc)
		return adresult;

	ADCON0 = 0;
	ADCON1 = 0;
	__delay_us(100);
	return 0;
}