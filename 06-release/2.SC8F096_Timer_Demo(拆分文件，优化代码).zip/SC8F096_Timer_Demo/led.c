#include "config.h"

void Update_LED_Slot(unsigned char idx)
{
	BatterySlot_t *p = GSLOT(idx);

	switch(p->state)
	{
	case CHG_IDLE:
		p->ledState = LED_OFF;
		break;
	case CHG_DETECT:
	case CHG_ACTIVATE:
	case CHG_PRECHARGE:
	case CHG_CC_CHARGE:
	case CHG_CV_CHARGE:
		p->ledState = LED_RED_ON;
		break;
	case CHG_FULL:
		p->ledState = LED_GREEN_ON;
		break;
	case CHG_ERROR:
		p->ledState = LED_RED_FLASH;
		break;
	default:
		p->ledState = LED_OFF;
		break;
	}
}

void Led_BlinkProcess(void)
{
	unsigned char i;
	for(i = 0; i < BATTERY_SLOTS; i++)
	{
		if(GSLOT(i)->ledState == LED_RED_FLASH)
		{
			GSLOT(i)->blinkTimer++;
			if(GSLOT(i)->blinkTimer >= (TICK_PER_SEC / 2))
			{
				GSLOT(i)->blinkTimer = 0;
				GSLOT(i)->blinkPhase ^= 1;
			}
		}
	}
}

void PowerOnLedSequence(void)
{
	g_powerOnTimer++;

	if(g_powerOnPhase == 0)
	{
		PIN_LED_IO1 = 1;
		PIN_LED_IO2 = 1;
		if(g_powerOnTimer >= TICK_PER_SEC)
		{
			g_powerOnTimer = 0;
			g_powerOnPhase = 1;
		}
	}
	else if(g_powerOnPhase == 1)
	{
		if(g_powerOnTimer >= TICK_PER_SEC)
		{
			g_powerOnTimer = 0;
			g_powerOnPhase = 2;
			PIN_LED_IO1 = 0;
			PIN_LED_IO2 = 0;
		}
	}
}