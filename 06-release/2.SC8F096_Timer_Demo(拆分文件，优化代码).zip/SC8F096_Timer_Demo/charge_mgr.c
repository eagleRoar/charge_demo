#include "config.h"

unsigned int  g_ntcAdc = 0;
unsigned char g_temperature = 25;
unsigned char g_tempProtect = 0;

unsigned char Read_Temperature(void)
{
	unsigned int ntcVal = ADC_ReadChannel(ADC_CH_NTC);
	unsigned int ntcR;
	unsigned char temp = 25;

	g_ntcAdc = ntcVal;

	if(ntcVal == 0 || ntcVal >= 4095)
		return g_temperature;

	ntcR = (unsigned int)((unsigned long)ntcVal * 10000UL / (4096UL - ntcVal));

	     if(ntcR > 32950) temp = 10;
	else if(ntcR > 27330) temp = 15;
	else if(ntcR > 22060) temp = 20;
	else if(ntcR > 17950) temp = 25;
	else if(ntcR > 14710) temp = 30;
	else if(ntcR > 12120) temp = 35;
	else if(ntcR > 10000) temp = 40;
	else if(ntcR > 8330)  temp = 45;
	else if(ntcR > 6970)  temp = 50;
	else if(ntcR > 5860)  temp = 55;
	else if(ntcR > 4950)  temp = 60;
	else if(ntcR > 4200)  temp = 65;
	else if(ntcR > 3580)  temp = 70;
	else                  temp = 75;

	g_temperature = temp;

	if(temp >= TEMP_STOP)
		g_tempProtect = 1;
	else if(temp <= TEMP_RESUME)
		g_tempProtect = 0;

	return temp;
}

unsigned char Detect_BatteryType(unsigned int voltage)
{
	if(voltage <= ADC_V_SHORT)
		return BAT_TYPE_SHORT;

	if(voltage <= ADC_V_ACTIVATE)
		return BAT_TYPE_LI_ION;

	if(voltage >= ADC_V_NIMH_LOW && voltage <= ADC_V_NIMH_HIGH)
		return BAT_TYPE_NIMH;

	if(voltage >= ADC_V_PRE_MIN && voltage <= ADC_V_FULL)
		return BAT_TYPE_LI_ION;

	if(voltage > ADC_V_FULL && voltage < ADC_V_OVER)
		return BAT_TYPE_LI_ION;

	return BAT_TYPE_UNKNOWN;
}

BatterySlot_t g_slot0[6];
BatterySlot_t g_slot1[6];

void ChargeProcess_Slot(unsigned char idx)
{
	BatterySlot_t *p = GSLOT(idx);
	unsigned int v = p->voltage;
	unsigned int tick = 1;

	switch(p->state)
	{
	case CHG_IDLE:
		p->chargeTimer = 0;
		p->stableCnt = 0;
		p->state = CHG_DETECT;
		break;

	case CHG_DETECT:
		p->chargeTimer += tick;
		if(p->chargeTimer < TIME_DETECT_WAIT)
			break;

		p->type = Detect_BatteryType(v);

		if(p->type == BAT_TYPE_SHORT || 
		   p->type == BAT_TYPE_NIMH || 
		   p->type == BAT_TYPE_UNKNOWN)
		{
			p->state = CHG_ERROR;
			break;
		}

		if(v <= ADC_V_ACTIVATE)
		{
			p->state = CHG_ACTIVATE;
			p->chargeTimer = 0;
			p->activatePulseCnt = 0;
		}
		else if(v < ADC_V_PRE_MIN)
		{
			p->state = CHG_PRECHARGE;
			p->chargeTimer = 0;
		}
		else
		{
			p->state = CHG_CC_CHARGE;
			p->chargeTimer = 0;
		}
		break;

	case CHG_ACTIVATE:
		p->chargeTimer += tick;
		if(p->chargeTimer > TIME_ACTIVATE_MAX)
		{
			p->state = CHG_ERROR;
			break;
		}
		if(v > ADC_V_ACTIVATE)
		{
			p->state = CHG_PRECHARGE;
			p->chargeTimer = 0;
			break;
		}
		if(v >= ADC_V_OVER)
		{
			p->state = CHG_ERROR;
			break;
		}
		break;

	case CHG_PRECHARGE:
		p->chargeTimer += tick;
		if(p->chargeTimer > TIME_PRECHARGE_MAX)
		{
			p->state = CHG_ERROR;
			break;
		}
		if(v >= ADC_V_OVER)
		{
			p->state = CHG_ERROR;
			break;
		}
		if(v >= ADC_V_PRE_MAX)
		{
			p->state = CHG_CC_CHARGE;
			p->chargeTimer = 0;
		}
		break;

	case CHG_CC_CHARGE:
		p->chargeTimer += tick;
		if(p->chargeTimer > TIME_CHARGE_MAX)
		{
			p->state = CHG_ERROR;
			break;
		}
		if(v >= ADC_V_OVER)
		{
			p->state = CHG_ERROR;
			break;
		}
		if(v >= ADC_V_FULL)
		{
			p->state = CHG_CV_CHARGE;
			p->chargeTimer = 0;
		}
		break;

	case CHG_CV_CHARGE:
		p->chargeTimer += tick;
		if(v >= ADC_V_OVER)
		{
			p->state = CHG_ERROR;
			break;
		}
		if(p->chargeTimer > TIME_CV_HOLD)
		{
			p->state = CHG_FULL;
		}
		break;

	case CHG_FULL:
		if(v < (ADC_V_FULL - 10))
		{
			p->state = CHG_CC_CHARGE;
			p->chargeTimer = 0;
		}
		break;

	case CHG_ERROR:
		if(v > ADC_V_ACTIVATE && v < ADC_V_OVER && 
		   p->type == BAT_TYPE_LI_ION)
		{
			p->state = CHG_DETECT;
			p->chargeTimer = 0;
		}
		break;

	default:
		p->state = CHG_IDLE;
		break;
	}
}

void Charging_Control(void)
{
	unsigned char i;
	unsigned char chargeB1_6 = 0;
	unsigned char chargeB7_12 = 0;

	if(g_tempProtect)
	{
		SLOT_ALL_OFF();
		PIN_CD1 = 0;
		PIN_CD2 = 0;
		PIN_PWM = 0;
		return;
	}

	for(i = 0; i < BATTERY_SLOTS; i++)
	{
		unsigned char s = GSLOT(i)->state;

		if(s == CHG_ACTIVATE || s == CHG_PRECHARGE ||
		   s == CHG_CC_CHARGE || s == CHG_CV_CHARGE)
		{
			SLOT_CHARGE_ON(i);

			if(i < 6)
				chargeB1_6 = 1;
			else
				chargeB7_12 = 1;
		}
		else
		{
			SLOT_CHARGE_OFF(i);
		}
	}

	PIN_CD1 = chargeB1_6;
	PIN_CD2 = chargeB7_12;

	if(chargeB1_6 || chargeB7_12)
		PIN_PWM = 1;
	else
		PIN_PWM = 0;
}