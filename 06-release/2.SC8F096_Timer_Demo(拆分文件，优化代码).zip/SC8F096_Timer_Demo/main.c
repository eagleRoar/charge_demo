#include "config.h"
#pragma warning disable 752
#pragma warning disable 373

volatile unsigned int power_ad;

unsigned int  g_timerTick = 0;
unsigned int  g_systemTick = 0;
unsigned char g_scanIndex = 0;
unsigned char g_scanPhase = 0;
unsigned int  g_powerOnTimer = 0;
unsigned char g_powerOnPhase = 0;

const unsigned char s_adcChannels[BATTERY_SLOTS] = {
	ADC_CH_B1, ADC_CH_B2, ADC_CH_B3, ADC_CH_B4,
	ADC_CH_B5, ADC_CH_B6, ADC_CH_B7, ADC_CH_B8,
	ADC_CH_B9, ADC_CH_B10, ADC_CH_B11, ADC_CH_B12
};

const SlotPinConfig_t s_slotPins[BATTERY_SLOTS] = {
	{ &TRISA, &PORTA, 0x01, &ANSEL0, 0x01 },
	{ &TRISA, &PORTA, 0x02, &ANSEL0, 0x02 },
	{ &TRISB, &PORTB, 0x08, &ANSEL1, 0x08 },
	{ &TRISB, &PORTB, 0x04, &ANSEL1, 0x04 },
	{ &TRISA, &PORTA, 0x08, &ANSEL0, 0x08 },
	{ &TRISA, &PORTA, 0x04, &ANSEL0, 0x04 },
	{ &TRISD, &PORTD, 0x02, &ANSEL3, 0x02 },
	{ &TRISD, &PORTD, 0x08, &ANSEL3, 0x08 },
	{ &TRISB, &PORTB, 0x01, &ANSEL1, 0x01 },
	{ &TRISB, &PORTB, 0x02, &ANSEL1, 0x02 },
	{ &TRISD, &PORTD, 0x04, &ANSEL3, 0x04 },
	{ &TRISD, &PORTD, 0x01, &ANSEL3, 0x01 }
};

void SlotPin_ToAnalog(unsigned char idx)
{
	const SlotPinConfig_t *cfg = &s_slotPins[idx];
	*cfg->ansel_reg |= cfg->ansel_mask;
	*cfg->tris_reg |= cfg->pin_mask;
}

void SlotPin_ToDigital(unsigned char idx)
{
	const SlotPinConfig_t *cfg = &s_slotPins[idx];
	*cfg->ansel_reg &= ~cfg->ansel_mask;
	*cfg->tris_reg &= ~cfg->pin_mask;
}

void System_Init(void)
{
	unsigned char i;

	asm("nop");
	asm("clrwdt");
	OSCCON = 0x72;
	OPTION_REG = 0x00;
	asm("clrwdt");

	TRISA = 0B00000000;
	PORTA = 0B10001111;
	WPUA = 0B00000000;
	WPDA = 0B00000000;
	IOCA = 0B00000000;

	TRISB = 0B11110000;
	PORTB = 0B00001111;
	WPUB = 0B00000000;
	WPDB = 0B00000000;
	IOCB = 0B00000000;

	TRISC = 0B00001000;
	PORTC = 0B00000001;
	WPUC = 0B00000000;

	TRISD = 0B00000000;
	PORTD = 0B00001111;
	WPUD = 0B00000000;

	ANSEL0 = 0x00;
	ANSEL1 = 0x00;
	ANSEL2 = 0x00;
	ANSEL3 = 0x00;

	CC0CON = 0;
	CC1CON = 0;
	ADCON0 = 0X41;
	ADCON1 = 0;

	TXSTA1 = 0B10100000;
	RCSTA1 = 0B10010000;
	SPBRG1 = 103;

	TMR0 = 6;
	T0IF = 0;
	T0IE = 1;

	PEIE = 1;
	RC1IE = 1;
	GIE = 1;

	PIN_EN = 1;
	PIN_PWM = 0;
	PIN_CD1 = 0;
	PIN_CD2 = 0;
	PIN_LED_IO1 = 0;
	PIN_LED_IO2 = 0;
	PIN_VCC_SW = 1;

	for(i = 0; i < BATTERY_SLOTS; i++)
	{
		GSLOT(i)->state = CHG_IDLE;
		GSLOT(i)->type = BAT_TYPE_UNKNOWN;
		GSLOT(i)->voltage = 0;
		GSLOT(i)->chargeTimer = 0;
		GSLOT(i)->ledState = LED_OFF;
		GSLOT(i)->blinkTimer = 0;
		GSLOT(i)->blinkPhase = 0;
		GSLOT(i)->stableCnt = 0;
		GSLOT(i)->activatePulseCnt = 0;
	}

	g_scanIndex = 0;
	g_scanPhase = 0;
	g_systemTick = 0;
	g_timerTick = 0;
	g_powerOnTimer = 0;
	g_powerOnPhase = 0;
	g_tempProtect = 0;
	g_temperature = 25;
	RXOK_f = 0;
}

void main(void)
{
	System_Init();

	TXREG1 = 0x55;
	while(TRMT1 == 0);
	TXREG1 = 0xAA;
	while(TRMT1 == 0);

	while(1)
	{
		asm("clrwdt");

		if(RXOK_f == 1)
		{
#if UART_PRINT_EN
			unsigned char i;
			for(i = 0; i < 10; i++)
			{
				while(TRMT1 == 0);
				TXREG1 = RxTable[i];
			}
#endif
			RXOK_f = 0;
		}
	}
}

void interrupt Interrupt_Isr(void)
{
	if(T0IF)
	{
		TMR0 += 6;
		T0IF = 0;

		g_timerTick++;

		if(g_powerOnPhase < 2)
		{
			PowerOnLedSequence();
		}
		else
		{
			switch(g_scanPhase)
			{
			case 0:
				SlotPin_ToAnalog(g_scanIndex);
				GSLOT(g_scanIndex)->voltage = 
					ADC_ReadChannel(s_adcChannels[g_scanIndex]);
				SlotPin_ToDigital(g_scanIndex);
				g_scanPhase = 1;
				break;

			case 1:
				ChargeProcess_Slot(g_scanIndex);
				Update_LED_Slot(g_scanIndex);
				g_scanPhase = 2;
				break;

			case 2:
				if(g_scanIndex == 0)
				{
					ANSEL2 |= 0x20;
					TRISC |= 0x20;
					Read_Temperature();
					ANSEL2 &= ~0x20;
					TRISC &= ~0x20;

					Led_BlinkProcess();
					Charging_Control();
				}

				g_scanIndex++;
				if(g_scanIndex >= BATTERY_SLOTS)
				{
					g_scanIndex = 0;
					g_systemTick++;
				}
				g_scanPhase = 0;

				if(g_systemTick >= 4000)
				{
					g_systemTick = 0;

					test_adc = ADC_Sample(ADC_CH_VREF, 0);
					if(0xA5 == test_adc)
					{
						volatile unsigned long power_temp;
						power_temp = (unsigned long)((POWER_RATIO)/adresult);
						power_ad = (unsigned int)(power_temp);
					}
					else
					{
						ADCON0 = 0;
						ADCON1 = 0;
						__delay_us(100);
					}

#if UART_PRINT_EN
					Print_Status();
#endif
				}
				break;

			default:
				g_scanPhase = 0;
				break;
			}
		}
	}

	if(RC1IF == 1)
	{
		static unsigned char RxNum = 0, TEMP;
		RC1IF = 0;

		if(RXOK_f == 0)
		{
			RxTable[RxNum] = RCREG1;
			RxNum++;
			if(RxNum > 9)
			{
				RxNum = 0;
				RXOK_f = 1;
			}
		}
		else
		{
			TEMP = RCREG1;
		}
	}
}

#include "adc_drv.c"
#include "charge_mgr.c"
#include "led.c"
#include "uart_dbg.c"