opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_CCCV_Control
	FNCALL	_main,_Get_Vcc
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_Read_Temperature
	FNCALL	_main,_Slot_Charge_Ctrl
	FNCALL	_main,_System_Init
	FNCALL	_main,_Update_LED_Global
	FNCALL	_main,_uart_send_string
	FNCALL	_Update_LED_Global,___bmul
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Slot_Charge_Ctrl,_Adc_Norm
	FNCALL	_Slot_Charge_Ctrl,_Detect_BatteryType
	FNCALL	_Slot_Charge_Ctrl,_Get_Vcc
	FNCALL	_Slot_Charge_Ctrl,___bmul
	FNCALL	_Slot_Charge_Ctrl,___lldiv
	FNCALL	_Slot_Charge_Ctrl,___lmul
	FNCALL	_Slot_Charge_Ctrl,___lwdiv
	FNCALL	_Slot_Charge_Ctrl,___wmul
	FNCALL	_Get_Vcc,_ADC_Sample
	FNCALL	_Get_Vcc,___lldiv
	FNCALL	_Adc_Norm,_ADC_Sample
	FNCALL	_Adc_Norm,___lldiv
	FNCALL	_Adc_Norm,___lmul
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,___bmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_vcc_mv
	global	_g_temperature
	global	_g_impCheckSlot
psect	idataBANK0,class=CODE,space=0,delta=2,noexec
global __pidataBANK0
__pidataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	17

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	18

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

	line	26

;initializer for _g_impCheckSlot
	retlw	0FFh
	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	39
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_powerOnPhase
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_diodeTrace
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_powerOnTimer
	global	_g_cvIntegral
	global	_g_impData
	global	_s_ledBlinkCnt
	global	_g_tempPhase
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_diodeTraceSlot
	global	_g_diodeTraceCnt
	global	_test_adc
	global	_adresult
	global	_g_detectLowCnt
	global	_g_highVFlag
	global	_g_capFlag
	global	_g_vccProtect
	global	_g_tempProtect
	global	_g_slot
	global	_g_slotRefV
	global	_g_stableCnt
	global	_g_ovCnt
	global	_g_ccBlocks
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_GIE
_GIE	set	0x5F
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC4
_RC4	set	0x834
	global	_RC5
_RC5	set	0x835
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	0
psect	stringtext
	
STR_37:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_25:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_23:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	45	;'-'
	retlw	105	;'i'
	retlw	111	;'o'
	retlw	110	;'n'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	67	;'C'
	retlw	32	;' '
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	95	;'_'
	retlw	76	;'L'
	retlw	79	;'O'
	retlw	67	;'C'
	retlw	75	;'K'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_38:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_8:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_30:	
	retlw	32	;' '
	retlw	112	;'p'
	retlw	114	;'r'
	retlw	101	;'e'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	32	;' '
	retlw	114	;'r'
	retlw	101	;'e'
	retlw	102	;'f'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_31:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_29:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	73	;'I'
	retlw	79	;'O'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_7:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_34:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	114	;'r'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_32:	
	retlw	32	;' '
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_33:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	53	;'5'
	retlw	53	;'5'
	retlw	65	;'A'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
STR_27	equ	STR_17+0
STR_9	equ	STR_2+0
STR_11	equ	STR_38+7
STR_35	equ	STR_38+7
STR_36	equ	STR_38+7
; #config settings
	file	"SC8F096_Timer_Demo.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_g_powerOnPhase:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_diodeTrace:
       ds      4

_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_powerOnTimer:
       ds      2

_g_cvIntegral:
       ds      2

_g_impData:
       ds      2

_s_ledBlinkCnt:
       ds      1

_g_tempPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_diodeTraceSlot:
       ds      1

_g_diodeTraceCnt:
       ds      1

_test_adc:
       ds      1

_adresult:
       ds      2

psect	dataBANK0,class=BANK0,space=1,noexec
global __pdataBANK0
__pdataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	17
_g_vcc_mv:
       ds      2

psect	dataBANK0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	18
_g_temperature:
       ds      2

psect	dataBANK0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	26
_g_impCheckSlot:
       ds      1

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_detectLowCnt:
       ds      12

_g_highVFlag:
       ds      2

_g_capFlag:
       ds      2

_g_vccProtect:
       ds      1

_g_tempProtect:
       ds      1

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slotRefV:
       ds      24

_g_stableCnt:
       ds      12

_g_ovCnt:
       ds      12

_g_ccBlocks:
       ds      12

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"SC8F096_Timer_Demo.as"
	line	#
; Initialize objects allocated to BANK0
	global __pidataBANK0
psect cinit,class=CODE,delta=2,merge=1
	fcall	__pidataBANK0+0		;fetch initializer
	movwf	__pdataBANK0+0&07fh		
	fcall	__pidataBANK0+1		;fetch initializer
	movwf	__pdataBANK0+1&07fh		
	fcall	__pidataBANK0+2		;fetch initializer
	movwf	__pdataBANK0+2&07fh		
	fcall	__pidataBANK0+3		;fetch initializer
	movwf	__pdataBANK0+3&07fh		
	fcall	__pidataBANK0+4		;fetch initializer
	movwf	__pdataBANK0+4&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+03Ch)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+012h)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+019h)
	fcall	clear_ram0
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
	global	Slot_Charge_Ctrl@v_init
Slot_Charge_Ctrl@v_init:	; 2 bytes @ 0x0
	ds	2
	global	Slot_Charge_Ctrl@vx_mv
Slot_Charge_Ctrl@vx_mv:	; 4 bytes @ 0x2
	ds	4
	global	Slot_Charge_Ctrl@bat_mv_long
Slot_Charge_Ctrl@bat_mv_long:	; 4 bytes @ 0x6
	ds	4
	global	Slot_Charge_Ctrl@vx_mv_375
Slot_Charge_Ctrl@vx_mv_375:	; 4 bytes @ 0xA
	ds	4
	global	Slot_Charge_Ctrl@bat_mv_long_376
Slot_Charge_Ctrl@bat_mv_long_376:	; 4 bytes @ 0xE
	ds	4
	global	Slot_Charge_Ctrl@vx_mv_378
Slot_Charge_Ctrl@vx_mv_378:	; 4 bytes @ 0x12
	ds	4
	global	Slot_Charge_Ctrl@bat_mv_long_379
Slot_Charge_Ctrl@bat_mv_long_379:	; 4 bytes @ 0x16
	ds	4
	global	_Slot_Charge_Ctrl$385
_Slot_Charge_Ctrl$385:	; 2 bytes @ 0x1A
	ds	2
	global	Slot_Charge_Ctrl@hasRise
Slot_Charge_Ctrl@hasRise:	; 1 bytes @ 0x1C
	ds	1
	global	Slot_Charge_Ctrl@newv
Slot_Charge_Ctrl@newv:	; 2 bytes @ 0x1D
	ds	2
	global	Slot_Charge_Ctrl@v_ref
Slot_Charge_Ctrl@v_ref:	; 2 bytes @ 0x1F
	ds	2
	global	Slot_Charge_Ctrl@dly
Slot_Charge_Ctrl@dly:	; 1 bytes @ 0x21
	ds	1
	global	Slot_Charge_Ctrl@tc
Slot_Charge_Ctrl@tc:	; 1 bytes @ 0x22
	ds	1
	global	Slot_Charge_Ctrl@bat_mv
Slot_Charge_Ctrl@bat_mv:	; 2 bytes @ 0x23
	ds	2
	global	Slot_Charge_Ctrl@bat_mv_377
Slot_Charge_Ctrl@bat_mv_377:	; 2 bytes @ 0x25
	ds	2
	global	Slot_Charge_Ctrl@bat_mv_380
Slot_Charge_Ctrl@bat_mv_380:	; 2 bytes @ 0x27
	ds	2
	global	Slot_Charge_Ctrl@diff
Slot_Charge_Ctrl@diff:	; 2 bytes @ 0x29
	ds	2
	global	Slot_Charge_Ctrl@pre
Slot_Charge_Ctrl@pre:	; 2 bytes @ 0x2B
	ds	2
	global	Slot_Charge_Ctrl@st
Slot_Charge_Ctrl@st:	; 1 bytes @ 0x2D
	ds	1
	global	Slot_Charge_Ctrl@ty
Slot_Charge_Ctrl@ty:	; 1 bytes @ 0x2E
	ds	1
	global	Slot_Charge_Ctrl@ct
Slot_Charge_Ctrl@ct:	; 2 bytes @ 0x2F
	ds	2
	global	Slot_Charge_Ctrl@v
Slot_Charge_Ctrl@v:	; 2 bytes @ 0x31
	ds	2
	global	Slot_Charge_Ctrl@idx
Slot_Charge_Ctrl@idx:	; 1 bytes @ 0x33
	ds	1
??_main:	; 1 bytes @ 0x34
	ds	2
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_Slot_Charge_Ctrl:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Update_LED_Global:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
??_Isr_Timer:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?_Get_Vcc:	; 2 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	ds	2
??_AD_Init:	; 1 bytes @ 0x2
??_uart_init:	; 1 bytes @ 0x2
?_ADC_Sample:	; 1 bytes @ 0x2
??_uart_send_char:	; 1 bytes @ 0x2
?_Detect_BatteryType:	; 1 bytes @ 0x2
?___bmul:	; 1 bytes @ 0x2
	global	?___wmul
?___wmul:	; 2 bytes @ 0x2
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x2
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x2
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x2
	global	?___lmul
?___lmul:	; 4 bytes @ 0x2
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x2
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x2
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x2
	global	___wmul@multiplier
___wmul@multiplier:	; 2 bytes @ 0x2
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x2
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x2
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x2
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x2
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x3
??___bmul:	; 1 bytes @ 0x3
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x3
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x3
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x4
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x4
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x4
	global	___wmul@multiplicand
___wmul@multiplicand:	; 2 bytes @ 0x4
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x4
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x4
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x4
	ds	1
?_uart_send_string:	; 1 bytes @ 0x5
??_Update_LED_Global:	; 1 bytes @ 0x5
??_System_Init:	; 1 bytes @ 0x5
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x5
	global	Update_LED_Global@hasErr
Update_LED_Global@hasErr:	; 1 bytes @ 0x5
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x5
	ds	1
??___wmul:	; 1 bytes @ 0x6
??___awdiv:	; 1 bytes @ 0x6
??___lwdiv:	; 1 bytes @ 0x6
??___lwmod:	; 1 bytes @ 0x6
	global	Update_LED_Global@hasChg
Update_LED_Global@hasChg:	; 1 bytes @ 0x6
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x6
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x6
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x6
	global	___wmul@product
___wmul@product:	; 2 bytes @ 0x6
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x6
	ds	1
??_uart_send_string:	; 1 bytes @ 0x7
	global	Update_LED_Global@hasFull
Update_LED_Global@hasFull:	; 1 bytes @ 0x7
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x7
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x7
	ds	1
	global	Update_LED_Global@i
Update_LED_Global@i:	; 1 bytes @ 0x8
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x8
	ds	1
??_uart_send_number:	; 1 bytes @ 0x9
??_Print_NtcTemp:	; 1 bytes @ 0x9
	global	Update_LED_Global@s
Update_LED_Global@s:	; 1 bytes @ 0x9
	ds	1
??_Get_Vcc:	; 1 bytes @ 0xA
??_Adc_Norm:	; 1 bytes @ 0xA
??___lmul:	; 1 bytes @ 0xA
??___lldiv:	; 1 bytes @ 0xA
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
?_uart_send_number:	; 1 bytes @ 0x0
??_CCCV_Control:	; 1 bytes @ 0x0
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x0
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x0
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x0
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x1
	ds	1
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x2
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x2
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x2
	ds	1
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x4
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x4
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x4
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x5
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0x6
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0x7
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0x8
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x8
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x8
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x9
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0xA
	global	_Print_NtcTemp$705
_Print_NtcTemp$705:	; 2 bytes @ 0xA
	ds	1
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xC
	global	_Print_NtcTemp$706
_Print_NtcTemp$706:	; 2 bytes @ 0xC
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0xC
	ds	2
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0xE
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0xF
	ds	1
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x10
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0x10
	ds	1
??_Read_Temperature:	; 1 bytes @ 0x11
??_Print_SystemStatus:	; 1 bytes @ 0x11
	global	?_Adc_Norm
?_Adc_Norm:	; 2 bytes @ 0x11
	global	Get_Vcc@pt
Get_Vcc@pt:	; 4 bytes @ 0x11
	ds	1
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x12
	ds	1
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x13
	ds	1
	global	Adc_Norm@ch
Adc_Norm@ch:	; 1 bytes @ 0x14
	ds	1
	global	Adc_Norm@raw
Adc_Norm@raw:	; 2 bytes @ 0x15
	global	_Print_SystemStatus$707
_Print_SystemStatus$707:	; 2 bytes @ 0x15
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x15
	ds	2
??_Slot_Charge_Ctrl:	; 1 bytes @ 0x17
	global	_Print_SystemStatus$708
_Print_SystemStatus$708:	; 2 bytes @ 0x17
	ds	2
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x19
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x19
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x1B
	ds	2
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x1D
	ds	1
	global	_Print_SystemStatus$265
_Print_SystemStatus$265:	; 2 bytes @ 0x1E
	ds	2
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x20
	ds	2
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0x22
	ds	4
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x26
	ds	2
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0x28
	ds	4
	global	Print_SystemStatus@tc
Print_SystemStatus@tc:	; 1 bytes @ 0x2C
	ds	1
	global	Print_SystemStatus@t
Print_SystemStatus@t:	; 1 bytes @ 0x2D
	ds	1
	global	Print_SystemStatus@d
Print_SystemStatus@d:	; 2 bytes @ 0x2E
	ds	2
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x30
	ds	1
	global	main@i
main@i:	; 1 bytes @ 0x31
	ds	1
;!
;!Data Sizes:
;!    Strings     254
;!    Constant    12
;!    Data        5
;!    BSS         176
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     10      12
;!    BANK0            80     50      80
;!    BANK1            80     54      72
;!    BANK3            80      0      60
;!    BANK2            80      0      72

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 25
;!		 -> STR_38(CODE[10]), STR_37(CODE[21]), STR_36(CODE[3]), STR_35(CODE[3]), 
;!		 -> STR_34(CODE[5]), STR_33(CODE[5]), STR_32(CODE[5]), STR_31(CODE[6]), 
;!		 -> STR_30(CODE[6]), STR_29(CODE[6]), STR_28(CODE[6]), STR_27(CODE[6]), 
;!		 -> STR_26(CODE[6]), STR_25(CODE[16]), STR_24(CODE[13]), STR_23(CODE[15]), 
;!		 -> STR_22(CODE[7]), STR_21(CODE[5]), STR_20(CODE[5]), STR_19(CODE[6]), 
;!		 -> STR_18(CODE[6]), STR_17(CODE[6]), STR_16(CODE[6]), STR_15(CODE[7]), 
;!		 -> STR_14(CODE[4]), STR_13(CODE[6]), STR_12(CODE[6]), STR_11(CODE[3]), 
;!		 -> STR_10(CODE[12]), STR_9(CODE[2]), STR_8(CODE[6]), STR_7(CODE[5]), 
;!		 -> STR_6(CODE[6]), STR_5(CODE[5]), STR_4(CODE[25]), STR_3(CODE[4]), 
;!		 -> STR_2(CODE[2]), STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    _main->_Update_LED_Global
;!    _Update_LED_Global->___bmul
;!    _System_Init->___bmul
;!    _Slot_Charge_Ctrl->___lmul
;!    _Adc_Norm->___lmul
;!    _Read_Temperature->___lmul
;!    _Print_SystemStatus->___lmul
;!    ___lldiv->___lmul
;!    _Print_NtcTemp->___lwdiv
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    None.
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Print_SystemStatus
;!    _Slot_Charge_Ctrl->_Adc_Norm
;!    _Get_Vcc->___lldiv
;!    _Adc_Norm->___lldiv
;!    _Read_Temperature->___lldiv
;!    _Print_SystemStatus->___lldiv
;!    ___lldiv->___lmul
;!    _Print_NtcTemp->_uart_send_number
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    None.
;!
;!Critical Paths under _main in BANK1
;!
;!    _main->_Slot_Charge_Ctrl
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 3     3      0   58985
;!                                             49 BANK0      1     1      0
;!                                             52 BANK1      2     2      0
;!                       _CCCV_Control
;!                            _Get_Vcc
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                   _Read_Temperature
;!                   _Slot_Charge_Ctrl
;!                        _System_Init
;!                  _Update_LED_Global
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Update_LED_Global                                    5     5      0    1173
;!                                              5 COMMON     5     5      0
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1090
;!                                              5 COMMON     1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Slot_Charge_Ctrl                                    57    57      0   25183
;!                                             23 BANK0      5     5      0
;!                                              0 BANK1     52    52      0
;!                           _Adc_Norm
;!                 _Detect_BatteryType
;!                            _Get_Vcc
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (2) ___wmul                                               6     2      4    1922
;!                                              2 COMMON     6     2      4
;! ---------------------------------------------------------------------------------
;! (2) _Get_Vcc                                              4     4      0    2392
;!                                             17 BANK0      4     4      0
;!                         _ADC_Sample
;!                            ___lldiv
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     185
;!                                              2 COMMON     2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _Adc_Norm                                             6     3      3    4059
;!                                             17 BANK0      6     3      3
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (1) _Read_Temperature                                    12    12      0    5143
;!                                             17 BANK0     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  32    32      0   12476
;!                                             17 BANK0     32    32      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8    1605
;!                                              2 COMMON     8     0      8
;!                                              0 BANK0      4     4      0
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1328
;!                                              4 BANK0     13     5      8
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (3) _ADC_Sample                                          18    17      1    1030
;!                                              2 COMMON     5     4      1
;!                                              0 BANK0     13    13      0
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    6430
;!                                             10 BANK0      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    2637
;!                                              5 COMMON     2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_number                                    10     8      2    2628
;!                                              0 BANK0     10     8      2
;!                             ___bmul (ARG)
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     102
;!                                              2 COMMON     3     3      0
;! ---------------------------------------------------------------------------------
;! (3) ___lwmod                                              5     1      4     378
;!                                              2 COMMON     5     1      4
;! ---------------------------------------------------------------------------------
;! (2) ___lwdiv                                              7     3      4     777
;!                                              2 COMMON     7     3      4
;! ---------------------------------------------------------------------------------
;! (1) _CCCV_Control                                        20    20      0    2362
;!                                              0 BANK0     20    20      0
;!                            ___awdiv
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1     836
;!                                              2 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (2) ___awdiv                                              8     4      4     428
;!                                              2 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 3
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            2     2      0       0
;!                                              0 COMMON     2     2      0
;!                 _PowerOnLedSequence
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 5
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     ___bmul
;!   _Get_Vcc
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Read_Temperature
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!   _Slot_Charge_Ctrl
;!     _Adc_Norm
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!     _Detect_BatteryType
;!     _Get_Vcc
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___wmul
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _Update_LED_Global
;!     ___bmul
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _PowerOnLedSequence
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50      0      3C       8       75.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      0      48      10       90.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50     36      48       6       90.0%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     32      50       4      100.0%
;!BITBANK0            50      0       0       3        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      A       C       1       85.7%
;!BITCOMMON            E      0       1       0        7.1%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     128      12        0.0%
;!ABS                  0      0     128      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 398 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   49[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       2       0       0
;;      Totals:         0       1       2       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_CCCV_Control
;;		_Get_Vcc
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_Slot_Charge_Ctrl
;;		_System_Init
;;		_Update_LED_Global
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	398
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	398
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 3
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	403
	
l6689:	
;main.c: 400: unsigned char i;
;main.c: 403: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_main+0)^080h+0+1),f
	movlw	241
movwf	((??_main+0)^080h+0),f
	u10147:
decfsz	((??_main+0)^080h+0),f
	goto	u10147
	decfsz	((??_main+0)^080h+0+1),f
	goto	u10147
opt asmopt_pop

	line	404
# 404 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	407
	
l6691:	
;main.c: 407: System_Init();
	fcall	_System_Init
	line	410
	
l6693:	
;main.c: 410: uart_send_string("L1211 Charger V2.1\r\n");
	movlw	low(((STR_37)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_37)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	411
	
l6695:	
;main.c: 411: uart_send_string("Init...\r\n");
	movlw	low(((STR_38)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_38)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	415
;main.c: 415: while(1)
	
l406:	
	line	417
# 417 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	420
	
l6697:	
;main.c: 420: Get_Vcc();
	fcall	_Get_Vcc
	line	423
	
l6699:	
;main.c: 423: for(i = 0; i < 12; i++)
	clrf	(main@i)
	line	425
	
l6705:	
;main.c: 424: {
;main.c: 425: Slot_Charge_Ctrl(i);
	movf	(main@i),w
	fcall	_Slot_Charge_Ctrl
	line	423
	
l6707:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(main@i),f
	
l6709:	
	movlw	low(0Ch)
	subwf	(main@i),w
	skipc
	goto	u10111
	goto	u10110
u10111:
	goto	l6705
u10110:
	line	429
	
l6711:	
;main.c: 426: }
;main.c: 429: CCCV_Control();
	fcall	_CCCV_Control
	line	432
	
l6713:	
;main.c: 432: Update_LED_Global();
	fcall	_Update_LED_Global
	line	435
	
l6715:	
;main.c: 435: if(g_doNtcRead)
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u10121
	goto	u10120
u10121:
	goto	l6721
u10120:
	line	437
	
l6717:	
;main.c: 436: {
;main.c: 437: g_doNtcRead = 0;
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	438
	
l6719:	
;main.c: 438: Read_Temperature();
	fcall	_Read_Temperature
	line	443
	
l6721:	
;main.c: 439: }
;main.c: 443: if(g_printFlag)
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u10131
	goto	u10130
u10131:
	goto	l406
u10130:
	line	445
	
l6723:	
;main.c: 444: {
;main.c: 445: g_printFlag = 0;
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	446
	
l6725:	
;main.c: 446: Print_SystemStatus();
	fcall	_Print_SystemStatus
	line	447
;main.c: 447: Print_NtcTemp();
	fcall	_Print_NtcTemp
	goto	l406
	global	start
	ljmp	start
	opt stack 0
	line	451
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_Update_LED_Global

;; *************** function _Update_LED_Global *****************
;; Defined at:
;;		line 27 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    9[COMMON] unsigned char 
;;  i               1    8[COMMON] unsigned char 
;;  hasFull         1    7[COMMON] unsigned char 
;;  hasChg          1    6[COMMON] unsigned char 
;;  hasErr          1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         5       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	27
global __ptext1
__ptext1:	;psect for function _Update_LED_Global
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	27
	global	__size_of_Update_LED_Global
	__size_of_Update_LED_Global	equ	__end_of_Update_LED_Global-_Update_LED_Global
	
_Update_LED_Global:	
;incstack = 0
	opt	stack 4
; Regs used in _Update_LED_Global: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	30
	
l6607:	
;led.c: 29: unsigned char i;
;led.c: 30: unsigned char hasErr = 0;
	clrf	(Update_LED_Global@hasErr)
	line	31
;led.c: 31: unsigned char hasChg = 0;
	clrf	(Update_LED_Global@hasChg)
	line	32
;led.c: 32: unsigned char hasFull = 0;
	clrf	(Update_LED_Global@hasFull)
	line	34
;led.c: 34: for(i = 0; i < 12; i++)
	clrf	(Update_LED_Global@i)
	line	36
	
l6613:	
;led.c: 35: {
;led.c: 36: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Global@s)
	line	37
	
l6615:	
;led.c: 37: if(s == 7)
		movlw	7
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u9891
	goto	u9890
u9891:
	goto	l6619
u9890:
	line	38
	
l6617:	
;led.c: 38: hasErr = 1;
	clrf	(Update_LED_Global@hasErr)
	incf	(Update_LED_Global@hasErr),f
	goto	l6629
	line	39
	
l6619:	
;led.c: 39: else if(s != 0 && s != 6)
	movf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u9901
	goto	u9900
u9901:
	goto	l6625
u9900:
	
l6621:	
		movlw	6
	xorwf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u9911
	goto	u9910
u9911:
	goto	l6625
u9910:
	line	40
	
l6623:	
;led.c: 40: hasChg = 1;
	clrf	(Update_LED_Global@hasChg)
	incf	(Update_LED_Global@hasChg),f
	goto	l6629
	line	41
	
l6625:	
;led.c: 41: else if(s == 6)
		movlw	6
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u9921
	goto	u9920
u9921:
	goto	l6629
u9920:
	line	42
	
l6627:	
;led.c: 42: hasFull = 1;
	clrf	(Update_LED_Global@hasFull)
	incf	(Update_LED_Global@hasFull),f
	line	34
	
l6629:	
	incf	(Update_LED_Global@i),f
	
l6631:	
	movlw	low(0Ch)
	subwf	(Update_LED_Global@i),w
	skipc
	goto	u9931
	goto	u9930
u9931:
	goto	l6613
u9930:
	line	45
	
l6633:	
;led.c: 43: }
;led.c: 45: if(hasErr)
	movf	((Update_LED_Global@hasErr)),w
	btfsc	status,2
	goto	u9941
	goto	u9940
u9941:
	goto	l6643
u9940:
	line	48
	
l6635:	
;led.c: 46: {
;led.c: 48: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	49
	
l6637:	
;led.c: 49: if(++s_ledBlinkCnt >= (100 / 2))
	movlw	low(032h)
	bcf	status, 6	;RP1=0, select bank0
	incf	(_s_ledBlinkCnt),f	;volatile
	subwf	((_s_ledBlinkCnt)),w	;volatile
	skipc
	goto	u9951
	goto	u9950
u9951:
	goto	l6641
u9950:
	line	50
	
l6639:	
;led.c: 50: s_ledBlinkCnt = 0;
	clrf	(_s_ledBlinkCnt)	;volatile
	line	51
	
l6641:	
;led.c: 51: RC5 = (s_ledBlinkCnt < ((100 / 2) / 2)) ? 0 : 1;
	movlw	low(019h)
	subwf	(_s_ledBlinkCnt),w	;volatile
	skipnc
	goto	u9961
	goto	u9960
	
u9961:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u9974
u9960:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u9974:
	line	52
;led.c: 52: }
	goto	l865
	line	53
	
l6643:	
;led.c: 53: else if(hasChg)
	movf	((Update_LED_Global@hasChg)),w
	btfsc	status,2
	goto	u9981
	goto	u9980
u9981:
	goto	l6647
u9980:
	line	56
	
l6645:	
;led.c: 54: {
;led.c: 56: RC5 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	57
;led.c: 57: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	58
;led.c: 58: }
	goto	l865
	line	59
	
l6647:	
;led.c: 59: else if(hasFull)
	movf	((Update_LED_Global@hasFull)),w
	btfsc	status,2
	goto	u9991
	goto	u9990
u9991:
	goto	l863
u9990:
	line	62
	
l6649:	
;led.c: 60: {
;led.c: 62: RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	63
;led.c: 63: RC4 = 0;
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	64
;led.c: 64: }
	goto	l865
	line	65
	
l863:	
	line	68
;led.c: 65: else
;led.c: 66: {
;led.c: 68: RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	69
;led.c: 69: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	71
	
l865:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Global
	__end_of_Update_LED_Global:
	signat	_Update_LED_Global,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 60 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         1       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	60
global __ptext2
__ptext2:	;psect for function _System_Init
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	60
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 4
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	65
	
l5261:	
# 65 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	66
# 66 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text2
	line	67
	
l5263:	
;main.c: 67: OSCCON = 0x72;
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	71
;main.c: 71: TRISA = 0xF0; PORTA = 0x0F;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	72
;main.c: 72: TRISB = 0x30; PORTB = 0x4F;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	73
;main.c: 73: TRISC = 0x07; PORTC = 0x00;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l5265:	
	clrf	(262)^0100h	;volatile
	line	75
	
l5267:	
;main.c: 75: TRISD = 0xF0; PORTD = 0x0F;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l5269:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	78
	
l5271:	
;main.c: 78: WPUA = 0x00; WPDA = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l5273:	
	clrf	(135)^080h	;volatile
	line	79
	
l5275:	
;main.c: 79: WPUB = 0x00; WPDB = 0x00;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l5277:	
	clrf	(7)	;volatile
	line	80
	
l5279:	
;main.c: 80: WPUC = 0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	81
	
l5281:	
;main.c: 81: WPUD = 0x00;
	clrf	(277)^0100h	;volatile
	line	84
	
l5283:	
;main.c: 84: IOCA = 0x00; IOCB = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l5285:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	87
	
l5287:	
;main.c: 87: CC0CON = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	88
	
l5289:	
;main.c: 88: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	95
	
l5291:	
;main.c: 95: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	96
	
l5293:	
;main.c: 96: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	97
	
l5295:	
;main.c: 97: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	98
	
l5297:	
;main.c: 98: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	101
	
l5299:	
;main.c: 101: AD_Init();
	fcall	_AD_Init
	line	105
	
l5301:	
;main.c: 105: uart_init();
	fcall	_uart_init
	line	112
;main.c: 112: OPTION_REG = 0x00;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	113
	
l5303:	
;main.c: 113: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	114
	
l5305:	
;main.c: 114: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	115
	
l5307:	
;main.c: 115: INTCON = 0xE0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	119
;main.c: 119: g_pwmDuty = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	120
;main.c: 120: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	121
	
l5309:	
;main.c: 121: RC5 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	122
	
l5311:	
;main.c: 122: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	123
	
l5313:	
;main.c: 123: RB6 = 1;
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	124
	
l5315:	
;main.c: 124: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	127
;main.c: 127: for(i = 0; i < 12; i++)
	clrf	(System_Init@i)
	line	129
	
l5321:	
;main.c: 128: {
;main.c: 129: g_slot[i].state = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	130
;main.c: 130: g_slot[i].type = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	131
;main.c: 131: g_slot[i].voltage = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	132
;main.c: 132: g_slot[i].chargeTimer = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	133
	
l5323:	
;main.c: 133: g_ccBlocks[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	134
	
l5325:	
;main.c: 134: g_ovCnt[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	127
	
l5327:	
	incf	(System_Init@i),f
	
l5329:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u7261
	goto	u7260
u7261:
	goto	l5321
u7260:
	line	138
	
l339:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
global __ptext3
__ptext3:	;psect for function _uart_init
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 4
; Regs used in _uart_init: []
	line	23
	
l3303:	
;uart_dbg.c: 23: TRISC &= (unsigned char)~0x10;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
;uart_dbg.c: 24: ANSEL2 &= (unsigned char)~0x10;
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
;uart_dbg.c: 25: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l443:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
global __ptext4
__ptext4:	;psect for function _AD_Init
psect	text4
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 4
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l3297:	
;adc_drv.c: 25: CC0CON = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
;adc_drv.c: 26: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	27
	
l3299:	
;adc_drv.c: 27: ADCON0 = 0X81;
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l3301:	
;adc_drv.c: 28: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	29
	
l420:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Slot_Charge_Ctrl

;; *************** function _Slot_Charge_Ctrl *****************
;; Defined at:
;;		line 187 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   51[BANK1 ] unsigned char 
;;  tc              1   34[BANK1 ] unsigned char 
;;  hasRise         1   28[BANK1 ] unsigned char 
;;  pre             2   43[BANK1 ] unsigned int 
;;  bat_mv_long     4    6[BANK1 ] unsigned long 
;;  vx_mv           4    2[BANK1 ] unsigned long 
;;  bat_mv          2   35[BANK1 ] unsigned int 
;;  diff            2   41[BANK1 ] int 
;;  bat_mv_long     4   22[BANK1 ] unsigned long 
;;  vx_mv           4   18[BANK1 ] unsigned long 
;;  bat_mv          2   39[BANK1 ] unsigned int 
;;  bat_mv_long     4   14[BANK1 ] unsigned long 
;;  vx_mv           4   10[BANK1 ] unsigned long 
;;  bat_mv          2   37[BANK1 ] unsigned int 
;;  v_ref           2   31[BANK1 ] unsigned int 
;;  v_init          2    0[BANK1 ] unsigned int 
;;  newv            2   29[BANK1 ] unsigned int 
;;  v               2   49[BANK1 ] unsigned int 
;;  ct              2   47[BANK1 ] unsigned int 
;;  ty              1   46[BANK1 ] unsigned char 
;;  st              1   45[BANK1 ] unsigned char 
;;  dly             1   33[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      52       0       0
;;      Temps:          0       5       0       0       0
;;      Totals:         0       5      52       0       0
;;Total ram usage:       57 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Adc_Norm
;;		_Detect_BatteryType
;;		_Get_Vcc
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___wmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	187
global __ptext5
__ptext5:	;psect for function _Slot_Charge_Ctrl
psect	text5
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	187
	global	__size_of_Slot_Charge_Ctrl
	__size_of_Slot_Charge_Ctrl	equ	__end_of_Slot_Charge_Ctrl-_Slot_Charge_Ctrl
	
_Slot_Charge_Ctrl:	
;incstack = 0
	opt	stack 3
; Regs used in _Slot_Charge_Ctrl: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
;Slot_Charge_Ctrl@idx stored from wreg
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@idx)^080h
	line	193
;charge_mgr.c: 189: unsigned char st, ty;
;charge_mgr.c: 190: unsigned int v, ct;
;charge_mgr.c: 191: unsigned char dly;
;charge_mgr.c: 193: do { st = g_slot[(idx)].state; ty = g_slot[(idx)].type; v = g_slot[(idx)].voltage; ct = g_slot[(idx)].chargeTimer; } while(0);
	
l530:	
	
l5525:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Slot_Charge_Ctrl@st)^080h
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Slot_Charge_Ctrl@ty)^080h
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Slot_Charge_Ctrl@v)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v+1)^080h
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Slot_Charge_Ctrl@ct)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@ct+1)^080h
	goto	l5529
	line	196
	
l534:	
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l5531
	
l536:	
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l5531
	
l537:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	l5531
	
l538:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	l5531
	
l539:	
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l5531
	
l540:	
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l5531
	
l541:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l5531
	
l542:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l5531
	
l543:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	l5531
	
l544:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	l5531
	
l545:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l5531
	
l546:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l5531
	
l5529:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l534
	xorlw	1^0	; case 1
	skipnz
	goto	l536
	xorlw	2^1	; case 2
	skipnz
	goto	l537
	xorlw	3^2	; case 3
	skipnz
	goto	l538
	xorlw	4^3	; case 4
	skipnz
	goto	l539
	xorlw	5^4	; case 5
	skipnz
	goto	l540
	xorlw	6^5	; case 6
	skipnz
	goto	l541
	xorlw	7^6	; case 7
	skipnz
	goto	l542
	xorlw	8^7	; case 8
	skipnz
	goto	l543
	xorlw	9^8	; case 9
	skipnz
	goto	l544
	xorlw	10^9	; case 10
	skipnz
	goto	l545
	xorlw	11^10	; case 11
	skipnz
	goto	l546
	goto	l5531
	opt asmopt_pop

	line	197
	
l5531:	
;charge_mgr.c: 197: if(st == 1 || st == 8 || st == 9)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
		decf	((Slot_Charge_Ctrl@st)^080h),w
	btfsc	status,2
	goto	u7461
	goto	u7460
u7461:
	goto	l5537
u7460:
	
l5533:	
		movlw	8
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfsc	status,2
	goto	u7471
	goto	u7470
u7471:
	goto	l5537
u7470:
	
l5535:	
		movlw	9
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfss	status,2
	goto	u7481
	goto	u7480
u7481:
	goto	l5549
u7480:
	line	200
	
l5537:	
;charge_mgr.c: 198: {
;charge_mgr.c: 200: for(dly = 0; dly < 20; dly++)
	clrf	(Slot_Charge_Ctrl@dly)^080h
	
l5539:	
	movlw	low(014h)
	subwf	(Slot_Charge_Ctrl@dly)^080h,w
	skipc
	goto	u7491
	goto	u7490
u7491:
	goto	l5543
u7490:
	goto	l5551
	line	201
	
l5543:	
;charge_mgr.c: 201: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u10157:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u10157
	nop
opt asmopt_pop

	line	200
	
l5545:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(Slot_Charge_Ctrl@dly)^080h,f
	goto	l5539
	line	205
	
l5549:	
;charge_mgr.c: 203: else
;charge_mgr.c: 204: {
;charge_mgr.c: 205: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u10167:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u10167
	nop
opt asmopt_pop

	line	209
	
l5551:	
;charge_mgr.c: 206: }
;charge_mgr.c: 208: {
;charge_mgr.c: 209: unsigned int newv = Adc_Norm(s_adcChannels[idx]);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	fcall	_Adc_Norm
	movf	(1+(?_Adc_Norm)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@newv+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?_Adc_Norm)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@newv)^080h
	line	213
	
l5553:	
;charge_mgr.c: 211: if(!(ty == 6 &&
;charge_mgr.c: 212: (st == 4 || st == 5) &&
;charge_mgr.c: 213: newv >= 3990))
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u7501
	goto	u7500
u7501:
	goto	l5561
u7500:
	
l5555:	
		movlw	4
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfsc	status,2
	goto	u7511
	goto	u7510
u7511:
	goto	l5559
u7510:
	
l5557:	
		movlw	5
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfss	status,2
	goto	u7521
	goto	u7520
u7521:
	goto	l5561
u7520:
	
l5559:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@newv+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@newv)^080h,w
	skipnc
	goto	u7531
	goto	u7530
u7531:
	goto	l6457
u7530:
	line	215
	
l5561:	
;charge_mgr.c: 214: {
;charge_mgr.c: 215: v = newv;
	movf	(Slot_Charge_Ctrl@newv+1)^080h,w
	movwf	(Slot_Charge_Ctrl@v+1)^080h
	movf	(Slot_Charge_Ctrl@newv)^080h,w
	movwf	(Slot_Charge_Ctrl@v)^080h
	goto	l6457
	line	226
	
l5563:	
;charge_mgr.c: 226: if(v >= 3990)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u7541
	goto	u7540
u7541:
	goto	l5569
u7540:
	line	228
	
l5565:	
;charge_mgr.c: 227: {
;charge_mgr.c: 228: if(ct < (300))
	movlw	01h
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	02Ch
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipnc
	goto	u7551
	goto	u7550
u7551:
	goto	l5569
u7550:
	line	230
	
l5567:	
;charge_mgr.c: 229: {
;charge_mgr.c: 230: ct++;
	incf	(Slot_Charge_Ctrl@ct)^080h,f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	231
;charge_mgr.c: 231: break;
	goto	l6459
	line	234
	
l5569:	
;charge_mgr.c: 232: }
;charge_mgr.c: 233: }
;charge_mgr.c: 234: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	235
	
l5571:	
;charge_mgr.c: 235: st = 1;
	clrf	(Slot_Charge_Ctrl@st)^080h
	incf	(Slot_Charge_Ctrl@st)^080h,f
	line	236
	
l5573:	
;charge_mgr.c: 236: g_ccBlocks[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	238
	
l5575:	
;charge_mgr.c: 238: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7564
u7565:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7564:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7565
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	241
	
l5577:	
;charge_mgr.c: 241: if(v < 3990)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u7571
	goto	u7570
u7571:
	goto	l5581
u7570:
	line	242
	
l5579:	
;charge_mgr.c: 242: g_slotRefV[idx] = v;
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	goto	l6459
	line	244
	
l5581:	
;charge_mgr.c: 243: else
;charge_mgr.c: 244: g_slotRefV[idx] = 0;
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l6459
	line	248
	
l5583:	
;charge_mgr.c: 248: ct++;
	incf	(Slot_Charge_Ctrl@ct)^080h,f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	251
	
l5585:	
;charge_mgr.c: 251: if(ct == 1)
		decf	((Slot_Charge_Ctrl@ct)^080h),w
iorwf	((Slot_Charge_Ctrl@ct+1)^080h),w
	btfss	status,2
	goto	u7581
	goto	u7580
u7581:
	goto	l5591
u7580:
	line	253
	
l5587:	
;charge_mgr.c: 252: {
;charge_mgr.c: 253: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	254
	
l5589:	
;charge_mgr.c: 254: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7594
u7595:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7594:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7595
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	257
	
l5591:	
;charge_mgr.c: 255: }
;charge_mgr.c: 257: if(ct < (30))
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	01Eh
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipnc
	goto	u7601
	goto	u7600
u7601:
	goto	l5595
u7600:
	goto	l6459
	line	275
	
l5595:	
;charge_mgr.c: 267: }
;charge_mgr.c: 275: if(ct == (30))
		movlw	30
	xorwf	((Slot_Charge_Ctrl@ct)^080h),w
iorwf	((Slot_Charge_Ctrl@ct+1)^080h),w
	btfss	status,2
	goto	u7611
	goto	u7610
u7611:
	goto	l5603
u7610:
	line	277
	
l5597:	
;charge_mgr.c: 276: {
;charge_mgr.c: 277: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	line	278
	
l5599:	
;charge_mgr.c: 278: if(v > 2900)
	movlw	0Bh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	055h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u7621
	goto	u7620
u7621:
	goto	l6459
u7620:
	line	279
	
l5601:	
;charge_mgr.c: 279: g_capFlag |= (unsigned int)1 << idx;
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7634
u7635:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7634:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7635
	
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag+1)^080h,f
	goto	l6459
	line	282
	
l5603:	
;charge_mgr.c: 281: }
;charge_mgr.c: 282: if(v > 2900 && v < 3990)
	movlw	0Bh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	055h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u7641
	goto	u7640
u7641:
	goto	l5665
u7640:
	
l5605:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u7651
	goto	u7650
u7651:
	goto	l5665
u7650:
	line	294
	
l5607:	
;charge_mgr.c: 283: {
;charge_mgr.c: 293: if(!(g_capFlag & ((unsigned int)1 << idx)) && ty != 5 &&
;charge_mgr.c: 294: v <= 3500)
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7664
u7665:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7664:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7665
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfss	status,2
	goto	u7671
	goto	u7670
u7671:
	goto	l5621
u7670:
	
l5609:	
		movlw	5
	bsf	status, 5	;RP0=1, select bank1
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u7681
	goto	u7680
u7681:
	goto	l5621
u7680:
	
l5611:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0ADh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u7691
	goto	u7690
u7691:
	goto	l5621
u7690:
	line	296
	
l5613:	
;charge_mgr.c: 295: {
;charge_mgr.c: 296: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	297
	
l5615:	
;charge_mgr.c: 297: g_slotRefV[idx] = 0;
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	298
	
l5617:	
;charge_mgr.c: 298: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	299
	
l5619:	
;charge_mgr.c: 299: g_detectLowCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	300
;charge_mgr.c: 300: break;
	goto	l6459
	line	310
	
l5621:	
;charge_mgr.c: 301: }
;charge_mgr.c: 310: unsigned int v_init = g_slotRefV[idx];
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_init)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_init+1)^080h
	line	312
;charge_mgr.c: 312: if(g_stableCnt[idx] >= 20)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipc
	goto	u7701
	goto	u7700
u7701:
	goto	l5651
u7700:
	line	317
	
l5623:	
;charge_mgr.c: 313: {
;charge_mgr.c: 317: g_highVFlag |= (unsigned int)1 << idx;
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7714
u7715:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7714:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7715
	
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag+1)^080h,f
	line	319
	
l5625:	
;charge_mgr.c: 319: if(v <= 2900)
	movlw	0Bh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	055h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u7721
	goto	u7720
u7721:
	goto	l5633
u7720:
	line	322
	
l5627:	
;charge_mgr.c: 320: {
;charge_mgr.c: 322: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7734
u7735:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7734:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7735
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	323
	
l5629:	
;charge_mgr.c: 323: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	324
	
l5631:	
;charge_mgr.c: 324: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7744
u7745:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7744:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7745
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	325
;charge_mgr.c: 325: }
	goto	l5677
	line	326
	
l5633:	
;charge_mgr.c: 326: else if(ct < (30) + (100))
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	082h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipnc
	goto	u7751
	goto	u7750
u7751:
	goto	l5645
u7750:
	line	335
	
l5635:	
;charge_mgr.c: 327: {
;charge_mgr.c: 334: if((g_highVFlag & ((unsigned int)1 << idx)) &&
;charge_mgr.c: 335: ct >= (30) + 25U)
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7764
u7765:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7764:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7765
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u7771
	goto	u7770
u7771:
	goto	l5579
u7770:
	
l5637:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	037h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u7781
	goto	u7780
u7781:
	goto	l5579
u7780:
	line	348
	
l5645:	
;charge_mgr.c: 348: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7794
u7795:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7794:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7795
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	349
	
l5647:	
;charge_mgr.c: 349: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	350
	
l5649:	
;charge_mgr.c: 350: ty = 5;
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@ty)^080h
	line	351
;charge_mgr.c: 351: goto amb_check;
	goto	l5707
	line	357
	
l5651:	
;charge_mgr.c: 354: else
;charge_mgr.c: 355: {
;charge_mgr.c: 357: if(v + 50 < v_init)
	movf	(Slot_Charge_Ctrl@v)^080h,w
	addlw	low(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v_init+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u7805
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v_init)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u7805:
	skipnc
	goto	u7801
	goto	u7800
u7801:
	goto	l5655
u7800:
	line	360
	
l5653:	
;charge_mgr.c: 358: {
;charge_mgr.c: 360: g_slotRefV[idx] = v;
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	line	361
;charge_mgr.c: 361: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	362
;charge_mgr.c: 362: }
	goto	l583
	line	366
	
l5655:	
;charge_mgr.c: 363: else
;charge_mgr.c: 364: {
;charge_mgr.c: 366: g_slotRefV[idx] = v;
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	line	367
;charge_mgr.c: 367: g_stableCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	368
	
l583:	
	line	369
;charge_mgr.c: 368: }
;charge_mgr.c: 369: if(g_stableCnt[idx] < 20)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u7811
	goto	u7810
u7811:
	goto	l5659
u7810:
	goto	l6459
	line	372
	
l5659:	
;charge_mgr.c: 372: if(g_capFlag & ((unsigned int)1 << idx))
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7824
u7825:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7824:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7825
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u7831
	goto	u7830
u7831:
	goto	l5663
u7830:
	goto	l6459
	line	374
	
l5663:	
;charge_mgr.c: 374: g_stableCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l5677
	line	377
	
l5665:	
;charge_mgr.c: 377: else if(ct < (30) + (100) && v < 3990)
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	082h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipnc
	goto	u7841
	goto	u7840
u7841:
	goto	l5677
u7840:
	
l5667:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u7851
	goto	u7850
u7851:
	goto	l5677
u7850:
	line	379
	
l5669:	
;charge_mgr.c: 378: {
;charge_mgr.c: 379: unsigned int v_ref = g_slotRefV[idx];
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_ref)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_ref+1)^080h
	line	380
	
l5671:	
;charge_mgr.c: 380: if(v_ref < 3990 && v + 50 < v_ref)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v_ref+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v_ref)^080h,w
	skipnc
	goto	u7861
	goto	u7860
u7861:
	goto	l5677
u7860:
	
l5673:	
	movf	(Slot_Charge_Ctrl@v)^080h,w
	addlw	low(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v_ref+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u7875
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v_ref)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u7875:
	skipnc
	goto	u7871
	goto	u7870
u7871:
	goto	l5677
u7870:
	goto	l5579
	line	390
	
l5677:	
;charge_mgr.c: 384: }
;charge_mgr.c: 385: }
;charge_mgr.c: 390: if(g_capFlag & ((unsigned int)1 << idx))
	bsf	status, 5	;RP0=1, select bank1
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7884
u7885:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7884:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7885
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u7891
	goto	u7890
u7891:
	goto	l5685
u7890:
	line	392
	
l5679:	
;charge_mgr.c: 391: {
;charge_mgr.c: 392: g_capFlag &= ~((unsigned int)1 << idx);
	bsf	status, 5	;RP0=1, select bank1
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7904
u7905:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7904:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7905
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	393
	
l5681:	
;charge_mgr.c: 393: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	394
	
l5683:	
;charge_mgr.c: 394: ty = 5;
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@ty)^080h
	line	395
;charge_mgr.c: 395: }
	goto	l590
	line	398
	
l5685:	
;charge_mgr.c: 396: else
;charge_mgr.c: 397: {
;charge_mgr.c: 398: ty = Detect_BatteryType(v);
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	(Detect_BatteryType@voltage+1)
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	movwf	(Slot_Charge_Ctrl@ty)^080h
	line	406
	
l5687:	
;charge_mgr.c: 405: if(ty == 0 && v >= 3990 &&
;charge_mgr.c: 406: ct >= (30) + (100))
	movf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u7911
	goto	u7910
u7911:
	goto	l590
u7910:
	
l5689:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u7921
	goto	u7920
u7921:
	goto	l590
u7920:
	
l5691:	
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	082h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u7931
	goto	u7930
u7931:
	goto	l590
u7930:
	goto	l5683
	line	408
	
l590:	
	line	412
;charge_mgr.c: 408: }
;charge_mgr.c: 412: if(v < 500)
	movlw	01h
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0F4h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u7941
	goto	u7940
u7941:
	goto	l5699
u7940:
	line	414
	
l5695:	
;charge_mgr.c: 413: {
;charge_mgr.c: 414: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	415
;charge_mgr.c: 415: if(g_detectLowCnt[idx] < 5)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u7951
	goto	u7950
u7951:
	goto	l5707
u7950:
	goto	l6459
	line	419
	
l5699:	
;charge_mgr.c: 419: else if(ty != 5 && ty != 1 && ty != 6)
		movlw	5
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u7961
	goto	u7960
u7961:
	goto	l5707
u7960:
	
l5701:	
		decf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u7971
	goto	u7970
u7971:
	goto	l5707
u7970:
	
l5703:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u7981
	goto	u7980
u7981:
	goto	l5707
u7980:
	line	421
	
l5705:	
;charge_mgr.c: 420: {
;charge_mgr.c: 421: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	425
	
l5707:	
;charge_mgr.c: 425: if(ty == 5)
		movlw	5
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u7991
	goto	u7990
u7991:
	goto	l5729
u7990:
	line	432
	
l5709:	
;charge_mgr.c: 426: {
;charge_mgr.c: 432: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	433
;charge_mgr.c: 433: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8001
	goto	u8000
u8001:
	goto	l5713
u8000:
	goto	l6459
	line	437
	
l5713:	
;charge_mgr.c: 437: if(g_impCheckSlot != 0xFF && g_impCheckSlot != idx)
	bcf	status, 5	;RP0=0, select bank0
		incf	((_g_impCheckSlot)),w
	btfsc	status,2
	goto	u8011
	goto	u8010
u8011:
	goto	l5719
u8010:
	
l5715:	
	movf	(_g_impCheckSlot),w
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(Slot_Charge_Ctrl@idx)^080h,w
	skipnz
	goto	u8021
	goto	u8020
u8021:
	goto	l5719
u8020:
	goto	l6459
	line	439
	
l5719:	
;charge_mgr.c: 439: g_impCheckSlot = idx;
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_impCheckSlot)
	line	443
	
l5721:	
;charge_mgr.c: 443: Get_Vcc();
	fcall	_Get_Vcc
	line	447
	
l5723:	
;charge_mgr.c: 447: g_impData = v | ((unsigned int)(((g_vcc_mv + 50U) / 100U) - 38U) << 12);
	movlw	064h
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(032h)
	movwf	(___lwdiv@dividend)
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(_g_impData+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_g_impData)
	movlw	0Ch
	
u8035:
	clrc
	rlf	(_g_impData),f
	rlf	(_g_impData+1),f
	addlw	-1
	skipz
	goto	u8035
	movlw	(0A000h >> 8)
	addwf	(_g_impData+1),f
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(_g_impData),f
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(_g_impData+1),f
	line	448
;charge_mgr.c: 448: st = 8;
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	449
	
l5725:	
;charge_mgr.c: 449: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	450
	
l5727:	
;charge_mgr.c: 450: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	452
	
l5729:	
;charge_mgr.c: 451: }
;charge_mgr.c: 452: if(ty == 1 || ty == 6)
		decf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u8041
	goto	u8040
u8041:
	goto	l5733
u8040:
	
l5731:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u8051
	goto	u8050
u8051:
	goto	l5783
u8050:
	line	455
	
l5733:	
;charge_mgr.c: 453: {
;charge_mgr.c: 455: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	456
;charge_mgr.c: 456: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8061
	goto	u8060
u8061:
	goto	l5737
u8060:
	goto	l6459
	line	458
	
l5737:	
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	(___lmul@multiplier)
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@vx_mv+3)^080h
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv+2)^080h
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv+1)^080h
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv)^080h

	
l5739:	
	movlw	0Ch
u8075:
	clrc
	rrf	(Slot_Charge_Ctrl@vx_mv+3)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv+2)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv+1)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u8075

	
l5741:	
	movf	(Slot_Charge_Ctrl@vx_mv+3)^080h,w
	movwf	(___lmul@multiplier+3)
	movf	(Slot_Charge_Ctrl@vx_mv+2)^080h,w
	movwf	(___lmul@multiplier+2)
	movf	(Slot_Charge_Ctrl@vx_mv+1)^080h,w
	movwf	(___lmul@multiplier+1)
	movf	(Slot_Charge_Ctrl@vx_mv)^080h,w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv_long+3)^080h
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long+2)^080h
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long+1)^080h
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long)^080h

	
l5743:	
	movlw	070h
	addwf	(Slot_Charge_Ctrl@bat_mv_long)^080h,f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Slot_Charge_Ctrl@bat_mv_long+1)^080h,f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Slot_Charge_Ctrl@bat_mv_long+2)^080h,f
	movlw	0
	skipnc
movlw 1
	addwf	(Slot_Charge_Ctrl@bat_mv_long+3)^080h,f
	
l5745:	
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Slot_Charge_Ctrl+0)+0)
	movlw	01h
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+2)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+0,f
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long+1)^080h,w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long+1)^080h,w
	goto	u8080
	goto	u8081
u8080:
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+1,f
u8081:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long+2)^080h,w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long+2)^080h,w
	goto	u8082
	goto	u8083
u8082:
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+2,f
u8083:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long+3)^080h,w
	skipnc
	incf	(Slot_Charge_Ctrl@bat_mv_long+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+3,f
	movf	3+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv)^080h
	
l5747:	
	movlw	0
	subwf	(Slot_Charge_Ctrl@bat_mv+1)^080h,w
	movlw	065h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv)^080h,w
	skipnc
	goto	u8091
	goto	u8090
u8091:
	goto	l5751
u8090:
	
l5749:	
	movlw	low(02h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	goto	l5777
	
l5751:	
	movlw	03h
	subwf	(Slot_Charge_Ctrl@bat_mv+1)^080h,w
	movlw	084h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv)^080h,w
	skipnc
	goto	u8101
	goto	u8100
u8101:
	goto	l5755
u8100:
	
l5753:	
	movlw	low(03h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	goto	l5777
	
l5755:	
	movlw	05h
	subwf	(Slot_Charge_Ctrl@bat_mv+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv)^080h,w
	skipc
	goto	u8111
	goto	u8110
u8111:
	goto	l5769
u8110:
	
l5757:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u8121
	goto	u8120
u8121:
	goto	l5761
u8120:
	
l5759:	
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	goto	l5777
	
l5761:	
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	
l5763:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	
l5765:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l5767:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l5777
	
l5769:	
	movlw	low(04h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	
l5771:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(080h)
	bsf	status, 7	;select IRP bank3
	andwf	indf,f
	
l5773:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	goto	l5767
	
l5777:	
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	
l5779:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l5619
	line	460
	
l5783:	
;charge_mgr.c: 460: else if(ty == 0)
	movf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u8131
	goto	u8130
u8131:
	goto	l5793
u8130:
	line	465
	
l5785:	
;charge_mgr.c: 461: {
;charge_mgr.c: 465: if(v >= 3990)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8141
	goto	u8140
u8141:
	goto	l5789
u8140:
	goto	l6459
	line	467
	
l5789:	
;charge_mgr.c: 467: st = 7;
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	goto	l5619
	line	470
	
l5793:	
;charge_mgr.c: 470: else if(ty == 2 || ty == 3)
		movlw	2
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u8151
	goto	u8150
u8151:
	goto	l5789
u8150:
	
l5795:	
		movlw	3
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u8161
	goto	u8160
u8161:
	goto	l6459
u8160:
	goto	l5789
	line	478
	
l5801:	
;charge_mgr.c: 478: ct++;
	incf	(Slot_Charge_Ctrl@ct)^080h,f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	479
	
l5803:	
;charge_mgr.c: 479: if(ct < 5)
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	05h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipnc
	goto	u8171
	goto	u8170
u8171:
	goto	l5807
u8170:
	goto	l6459
	line	484
	
l5807:	
;charge_mgr.c: 482: {
;charge_mgr.c: 484: Get_Vcc();
	fcall	_Get_Vcc
	line	490
	
l5809:	
;charge_mgr.c: 490: if(v >= 4050U && (g_impData & 0x0FFFU) >= 4050U)
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0D2h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8181
	goto	u8180
u8181:
	goto	l5819
u8180:
	
l5811:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0D2h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u8191
	goto	u8190
u8191:
	goto	l5819
u8190:
	line	492
	
l5813:	
;charge_mgr.c: 491: {
;charge_mgr.c: 492: ty = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(Slot_Charge_Ctrl@ty)^080h
	line	493
;charge_mgr.c: 493: st = 0;
	clrf	(Slot_Charge_Ctrl@st)^080h
	line	494
	
l5815:	
;charge_mgr.c: 494: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_impCheckSlot)
	line	495
	
l5817:	
;charge_mgr.c: 495: g_highVFlag &= ~((unsigned int)1 << idx);
	bsf	status, 5	;RP0=1, select bank1
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8204
u8205:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8204:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8205
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	496
;charge_mgr.c: 496: break;
	goto	l6459
	line	502
	
l5819:	
;charge_mgr.c: 497: }
;charge_mgr.c: 502: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 300U && v >= 3990)
	bcf	status, 5	;RP0=0, select bank0
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(012Ch)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(012Ch)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8215
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8215:
	skipnc
	goto	u8211
	goto	u8210
u8211:
	goto	l5827
u8210:
	
l5821:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8221
	goto	u8220
u8221:
	goto	l5827
u8220:
	line	504
	
l5823:	
;charge_mgr.c: 503: {
;charge_mgr.c: 504: ty = 2;
	movlw	low(02h)
	movwf	(Slot_Charge_Ctrl@ty)^080h
	line	505
;charge_mgr.c: 505: st = 7;
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	506
;charge_mgr.c: 506: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_impCheckSlot)
	goto	l5817
	line	517
	
l5827:	
;charge_mgr.c: 509: }
;charge_mgr.c: 516: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 200U &&
;charge_mgr.c: 517: (g_impData & 0x0FFFU) < 3100U)
	bcf	status, 5	;RP0=0, select bank0
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(0C8h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8235
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8235:
	skipnc
	goto	u8231
	goto	u8230
u8231:
	goto	l5833
u8230:
	
l5829:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Ch
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	01Ch
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u8241
	goto	u8240
u8241:
	goto	l5833
u8240:
	goto	l5863
	line	528
	
l5833:	
;charge_mgr.c: 526: if(!(g_highVFlag & ((unsigned int)1 << idx)) &&
;charge_mgr.c: 527: ((g_impData & 0x0FFFU) > v) &&
;charge_mgr.c: 528: ((g_impData & 0x0FFFU) - v) > 1000U)
	bsf	status, 5	;RP0=1, select bank1
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8254
u8255:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8254:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8255
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfss	status,2
	goto	u8261
	goto	u8260
u8261:
	goto	l5845
u8260:
	
l5835:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipz
	goto	u8275
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v)^080h,w
u8275:
	skipnc
	goto	u8271
	goto	u8270
u8271:
	goto	l5845
u8270:
	
l5837:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipc
	incf	(Slot_Charge_Ctrl@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	03h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0E9h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipc
	goto	u8281
	goto	u8280
u8281:
	goto	l5845
u8280:
	line	530
	
l5839:	
;charge_mgr.c: 529: {
;charge_mgr.c: 530: ty = 3;
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@ty)^080h
	line	531
;charge_mgr.c: 531: st = 7;
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	532
;charge_mgr.c: 532: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_impCheckSlot)
	line	533
	
l5841:	
;charge_mgr.c: 533: g_highVFlag &= ~((unsigned int)1 << idx);
	bsf	status, 5	;RP0=1, select bank1
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8294
u8295:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8294:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8295
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	goto	l5619
	line	542
	
l5845:	
;charge_mgr.c: 536: }
;charge_mgr.c: 541: if(((g_impData & 0x0FFFU) > 3500) &&
;charge_mgr.c: 542: ((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) <= g_vcc_mv + 200U))
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Dh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0ADh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u8301
	goto	u8300
u8301:
	goto	l5851
u8300:
	
l5847:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(0C8h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8315
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8315:
	skipc
	goto	u8311
	goto	u8310
u8311:
	goto	l5851
u8310:
	goto	l5855
	line	549
	
l5851:	
	line	555
	
l5855:	
;charge_mgr.c: 555: st = 9;
	movlw	low(09h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	556
	
l5857:	
;charge_mgr.c: 556: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	557
	
l5859:	
;charge_mgr.c: 557: g_diodeTraceCnt = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_diodeTraceCnt)
	line	558
;charge_mgr.c: 558: g_diodeTraceSlot = (unsigned char)idx;
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_diodeTraceSlot)
	goto	l5817
	line	565
	
l5863:	
;charge_mgr.c: 565: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)
	line	566
	
l5865:	
;charge_mgr.c: 566: g_highVFlag &= ~((unsigned int)1 << idx);
	bsf	status, 5	;RP0=1, select bank1
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8324
u8325:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8324:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8325
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	567
	
l5867:	
;charge_mgr.c: 567: ty = 1;
	clrf	(Slot_Charge_Ctrl@ty)^080h
	incf	(Slot_Charge_Ctrl@ty)^080h,f
	line	568
	
l5869:	
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	(___lmul@multiplier)
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@vx_mv_375+3)^080h
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv_375+2)^080h
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv_375+1)^080h
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv_375)^080h

	
l5871:	
	movlw	0Ch
u8335:
	clrc
	rrf	(Slot_Charge_Ctrl@vx_mv_375+3)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv_375+2)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv_375+1)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv_375)^080h,f
	addlw	-1
	skipz
	goto	u8335

	
l5873:	
	movf	(Slot_Charge_Ctrl@vx_mv_375+3)^080h,w
	movwf	(___lmul@multiplier+3)
	movf	(Slot_Charge_Ctrl@vx_mv_375+2)^080h,w
	movwf	(___lmul@multiplier+2)
	movf	(Slot_Charge_Ctrl@vx_mv_375+1)^080h,w
	movwf	(___lmul@multiplier+1)
	movf	(Slot_Charge_Ctrl@vx_mv_375)^080h,w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv_long_376+3)^080h
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long_376+2)^080h
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long_376+1)^080h
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long_376)^080h

	movlw	070h
	addwf	(Slot_Charge_Ctrl@bat_mv_long_376)^080h,f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Slot_Charge_Ctrl@bat_mv_long_376+1)^080h,f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Slot_Charge_Ctrl@bat_mv_long_376+2)^080h,f
	movlw	0
	skipnc
movlw 1
	addwf	(Slot_Charge_Ctrl@bat_mv_long_376+3)^080h,f
	
l5875:	
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Slot_Charge_Ctrl+0)+0)
	movlw	01h
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+2)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long_376)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+0,f
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long_376+1)^080h,w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long_376+1)^080h,w
	goto	u8340
	goto	u8341
u8340:
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+1,f
u8341:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long_376+2)^080h,w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long_376+2)^080h,w
	goto	u8342
	goto	u8343
u8342:
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+2,f
u8343:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long_376+3)^080h,w
	skipnc
	incf	(Slot_Charge_Ctrl@bat_mv_long_376+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+3,f
	movf	3+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv_377+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv_377)^080h
	
l5877:	
	movlw	0
	subwf	(Slot_Charge_Ctrl@bat_mv_377+1)^080h,w
	movlw	065h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv_377)^080h,w
	skipnc
	goto	u8351
	goto	u8350
u8351:
	goto	l5881
u8350:
	goto	l5749
	
l5881:	
	movlw	03h
	subwf	(Slot_Charge_Ctrl@bat_mv_377+1)^080h,w
	movlw	084h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv_377)^080h,w
	skipnc
	goto	u8361
	goto	u8360
u8361:
	goto	l5885
u8360:
	goto	l5753
	
l5885:	
	movlw	05h
	subwf	(Slot_Charge_Ctrl@bat_mv_377+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv_377)^080h,w
	skipc
	goto	u8371
	goto	u8370
u8371:
	goto	l5769
u8370:
	
l5887:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u8381
	goto	u8380
u8381:
	goto	l5761
u8380:
	goto	l5759
	line	579
	
l5913:	
;charge_mgr.c: 579: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_impCheckSlot)
	line	580
	
l5915:	
;charge_mgr.c: 580: g_highVFlag &= ~((unsigned int)1 << idx);
	bsf	status, 5	;RP0=1, select bank1
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8394
u8395:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8394:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8395
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	581
	
l5917:	
;charge_mgr.c: 581: ty = 6;
	movlw	low(06h)
	movwf	(Slot_Charge_Ctrl@ty)^080h
	line	582
	
l5919:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(___lmul@multiplier)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(___lmul@multiplier)
	clrf	2+(___lmul@multiplier)
	clrf	3+(___lmul@multiplier)
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@vx_mv_378+3)^080h
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv_378+2)^080h
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv_378+1)^080h
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv_378)^080h

	
l5921:	
	movlw	0Ch
u8405:
	clrc
	rrf	(Slot_Charge_Ctrl@vx_mv_378+3)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv_378+2)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv_378+1)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv_378)^080h,f
	addlw	-1
	skipz
	goto	u8405

	movf	(Slot_Charge_Ctrl@vx_mv_378+3)^080h,w
	movwf	(___lmul@multiplier+3)
	movf	(Slot_Charge_Ctrl@vx_mv_378+2)^080h,w
	movwf	(___lmul@multiplier+2)
	movf	(Slot_Charge_Ctrl@vx_mv_378+1)^080h,w
	movwf	(___lmul@multiplier+1)
	movf	(Slot_Charge_Ctrl@vx_mv_378)^080h,w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv_long_379+3)^080h
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long_379+2)^080h
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long_379+1)^080h
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long_379)^080h

	
l5923:	
	movlw	070h
	addwf	(Slot_Charge_Ctrl@bat_mv_long_379)^080h,f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Slot_Charge_Ctrl@bat_mv_long_379+1)^080h,f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Slot_Charge_Ctrl@bat_mv_long_379+2)^080h,f
	movlw	0
	skipnc
movlw 1
	addwf	(Slot_Charge_Ctrl@bat_mv_long_379+3)^080h,f
	
l5925:	
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Slot_Charge_Ctrl+0)+0)
	movlw	01h
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+2)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long_379)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+0,f
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long_379+1)^080h,w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long_379+1)^080h,w
	goto	u8410
	goto	u8411
u8410:
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+1,f
u8411:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long_379+2)^080h,w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long_379+2)^080h,w
	goto	u8412
	goto	u8413
u8412:
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+2,f
u8413:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long_379+3)^080h,w
	skipnc
	incf	(Slot_Charge_Ctrl@bat_mv_long_379+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+3,f
	movf	3+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv_380+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv_380)^080h
	movlw	0
	subwf	(Slot_Charge_Ctrl@bat_mv_380+1)^080h,w
	movlw	065h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv_380)^080h,w
	skipnc
	goto	u8421
	goto	u8420
u8421:
	goto	l5929
u8420:
	goto	l5749
	
l5929:	
	movlw	03h
	subwf	(Slot_Charge_Ctrl@bat_mv_380+1)^080h,w
	movlw	084h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv_380)^080h,w
	skipnc
	goto	u8431
	goto	u8430
u8431:
	goto	l5933
u8430:
	goto	l5753
	
l5933:	
	movlw	05h
	subwf	(Slot_Charge_Ctrl@bat_mv_380+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv_380)^080h,w
	skipc
	goto	u8441
	goto	u8440
u8441:
	goto	l5947
u8440:
	
l5935:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u8451
	goto	u8450
u8451:
	goto	l5939
u8450:
	goto	l5759
	
l5939:	
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	
l5941:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	indf
	goto	l5765
	
l5947:	
	movlw	low(04h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	
l5949:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(080h)
	bsf	status, 7	;select IRP bank3
	andwf	indf,f
	
l5951:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	indf
	goto	l5767
	line	592
	
l5961:	
;charge_mgr.c: 592: ct++;
	incf	(Slot_Charge_Ctrl@ct)^080h,f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	598
	
l5963:	
;charge_mgr.c: 597: if((ct == 7U || ct == 14U || ct == 21U || ct == 28U) &&
;charge_mgr.c: 598: g_diodeTraceCnt < 4U)
		movlw	7
	xorwf	((Slot_Charge_Ctrl@ct)^080h),w
iorwf	((Slot_Charge_Ctrl@ct+1)^080h),w
	btfsc	status,2
	goto	u8461
	goto	u8460
u8461:
	goto	l5971
u8460:
	
l5965:	
		movlw	14
	xorwf	((Slot_Charge_Ctrl@ct)^080h),w
iorwf	((Slot_Charge_Ctrl@ct+1)^080h),w
	btfsc	status,2
	goto	u8471
	goto	u8470
u8471:
	goto	l5971
u8470:
	
l5967:	
		movlw	21
	xorwf	((Slot_Charge_Ctrl@ct)^080h),w
iorwf	((Slot_Charge_Ctrl@ct+1)^080h),w
	btfsc	status,2
	goto	u8481
	goto	u8480
u8481:
	goto	l5971
u8480:
	
l5969:	
		movlw	28
	xorwf	((Slot_Charge_Ctrl@ct)^080h),w
iorwf	((Slot_Charge_Ctrl@ct+1)^080h),w
	btfss	status,2
	goto	u8491
	goto	u8490
u8491:
	goto	l5987
u8490:
	
l5971:	
	movlw	low(04h)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_g_diodeTraceCnt),w
	skipnc
	goto	u8501
	goto	u8500
u8501:
	goto	l5987
u8500:
	line	600
	
l5973:	
;charge_mgr.c: 599: {
;charge_mgr.c: 600: signed int diff = (signed int)v - (signed int)(g_impData & 0x0FFFU);
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	(Slot_Charge_Ctrl@diff+1)^080h
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	(Slot_Charge_Ctrl@diff)^080h
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@diff)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	skipc
	decf	(Slot_Charge_Ctrl@diff+1)^080h,f
	subwf	(Slot_Charge_Ctrl@diff+1)^080h,f
	line	601
;charge_mgr.c: 601: diff >>= 2;
	rlf	(Slot_Charge_Ctrl@diff+1)^080h,w
	rrf	(Slot_Charge_Ctrl@diff+1)^080h,f
	rrf	(Slot_Charge_Ctrl@diff)^080h,f
	rlf	(Slot_Charge_Ctrl@diff+1)^080h,w
	rrf	(Slot_Charge_Ctrl@diff+1)^080h,f
	rrf	(Slot_Charge_Ctrl@diff)^080h,f
	line	602
	
l5975:	
;charge_mgr.c: 602: if(diff > 127) diff = 127;
	movf	(Slot_Charge_Ctrl@diff+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u8515
	movlw	080h
	subwf	(Slot_Charge_Ctrl@diff)^080h,w
u8515:

	skipc
	goto	u8511
	goto	u8510
u8511:
	goto	l5979
u8510:
	
l5977:	
	movlw	07Fh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Slot_Charge_Ctrl@diff)^080h
	clrf	(Slot_Charge_Ctrl@diff+1)^080h
	line	603
	
l5979:	
;charge_mgr.c: 603: if(diff < -128) diff = -128;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Slot_Charge_Ctrl@diff+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u8525
	movlw	080h
	subwf	(Slot_Charge_Ctrl@diff)^080h,w
u8525:

	skipnc
	goto	u8521
	goto	u8520
u8521:
	goto	l5983
u8520:
	
l5981:	
	movlw	080h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Slot_Charge_Ctrl@diff)^080h
	movlw	0FFh
	movwf	((Slot_Charge_Ctrl@diff)^080h)+1
	line	604
	
l5983:	
;charge_mgr.c: 604: g_diodeTrace[g_diodeTraceCnt++] = (unsigned char)(diff + 128);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_diodeTraceCnt),w
	addlw	low(_g_diodeTrace|((0x0)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@diff)^080h,w
	addlw	080h
	bcf	status, 7	;select IRP bank0
	movwf	indf
	
l5985:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(_g_diodeTraceCnt),f
	goto	l5991
	line	608
	
l5987:	
	line	614
	
l5991:	
;charge_mgr.c: 611: }
;charge_mgr.c: 614: if(v > (g_impData & 0x0FFFU) + 900)
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(0384h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(0384h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u8535
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u8535:
	skipnc
	goto	u8531
	goto	u8530
u8531:
	goto	l5999
u8530:
	line	618
	
l5993:	
;charge_mgr.c: 615: {
;charge_mgr.c: 618: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150U)
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8545
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8545:
	skipnc
	goto	u8541
	goto	u8540
u8541:
	goto	l5913
u8540:
	goto	l5863
	line	635
	
l5999:	
;charge_mgr.c: 622: }
;charge_mgr.c: 633: if(((g_impData & 0x0FFFU) > 3000U) &&
;charge_mgr.c: 634: (v > 2900) &&
;charge_mgr.c: 635: (v < (g_impData & 0x0FFFU)))
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Bh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0B9h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u8551
	goto	u8550
u8551:
	goto	l6007
u8550:
	
l6001:	
	movlw	0Bh
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	055h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8561
	goto	u8560
u8561:
	goto	l6007
u8560:
	
l6003:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipz
	goto	u8575
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v)^080h,w
u8575:
	skipnc
	goto	u8571
	goto	u8570
u8571:
	goto	l6007
u8570:
	goto	l5913
	line	642
	
l6007:	
;charge_mgr.c: 641: if((v > 2900) &&
;charge_mgr.c: 642: ((g_impData & 0x0FFFU) <= 2300U))
	movlw	0Bh
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	055h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8581
	goto	u8580
u8581:
	goto	l6017
u8580:
	
l6009:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u8591
	goto	u8590
u8591:
	goto	l6017
u8590:
	goto	l5839
	line	670
	
l6017:	
;charge_mgr.c: 650: }
;charge_mgr.c: 667: if(ct >= 20U && v > 2100U &&
;charge_mgr.c: 668: (g_impData & 0x0FFFU) <= 2300U &&
;charge_mgr.c: 669: v + 160U >= (g_impData & 0x0FFFU) &&
;charge_mgr.c: 670: v <= (g_impData & 0x0FFFU) + 150)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	014h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u8601
	goto	u8600
u8601:
	goto	l6029
u8600:
	
l6019:	
	movlw	08h
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	035h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8611
	goto	u8610
u8611:
	goto	l6029
u8610:
	
l6021:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u8621
	goto	u8620
u8621:
	goto	l6029
u8620:
	
l6023:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	addlw	low(0A0h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipnc
	addlw	1
	addlw	high(0A0h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u8635
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u8635:
	skipc
	goto	u8631
	goto	u8630
u8631:
	goto	l6029
u8630:
	
l6025:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u8645
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u8645:
	skipc
	goto	u8641
	goto	u8640
u8641:
	goto	l6029
u8640:
	goto	l5913
	line	680
	
l6029:	
;charge_mgr.c: 680: if(ct >= 30)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	01Eh
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u8651
	goto	u8650
u8651:
	goto	l6459
u8650:
	line	682
	
l6031:	
;charge_mgr.c: 681: {
;charge_mgr.c: 682: unsigned int pre = (unsigned int)(g_impData & 0x0FFFU);
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@pre)^080h
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	1+(Slot_Charge_Ctrl@pre)^080h
	line	688
;charge_mgr.c: 688: if(pre > 3500 && pre < 3990)
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1)^080h,w
	movlw	0ADh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre)^080h,w
	skipc
	goto	u8661
	goto	u8660
u8661:
	goto	l6057
u8660:
	
l6033:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@pre+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre)^080h,w
	skipnc
	goto	u8671
	goto	u8670
u8671:
	goto	l6057
u8670:
	line	691
	
l6035:	
;charge_mgr.c: 689: {
;charge_mgr.c: 690: unsigned char tc;
;charge_mgr.c: 691: unsigned char hasRise = 0;
	clrf	(Slot_Charge_Ctrl@hasRise)^080h
	line	692
;charge_mgr.c: 692: for(tc = 0; tc < g_diodeTraceCnt; tc++)
	clrf	(Slot_Charge_Ctrl@tc)^080h
	goto	l6043
	line	694
	
l6037:	
;charge_mgr.c: 693: {
;charge_mgr.c: 694: if(g_diodeTrace[tc] >= 136U)
	movf	(Slot_Charge_Ctrl@tc)^080h,w
	addlw	low(_g_diodeTrace|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(088h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipc
	goto	u8681
	goto	u8680
u8681:
	goto	l6041
u8680:
	line	696
	
l6039:	
;charge_mgr.c: 695: {
;charge_mgr.c: 696: hasRise = 1;
	clrf	(Slot_Charge_Ctrl@hasRise)^080h
	incf	(Slot_Charge_Ctrl@hasRise)^080h,f
	line	697
;charge_mgr.c: 697: break;
	goto	l6045
	line	692
	
l6041:	
	incf	(Slot_Charge_Ctrl@tc)^080h,f
	
l6043:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_diodeTraceCnt),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@tc)^080h,w
	skipc
	goto	u8691
	goto	u8690
u8691:
	goto	l6037
u8690:
	line	700
	
l6045:	
;charge_mgr.c: 698: }
;charge_mgr.c: 699: }
;charge_mgr.c: 700: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150U)
	bcf	status, 5	;RP0=0, select bank0
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8705
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8705:
	skipnc
	goto	u8701
	goto	u8700
u8701:
	goto	l6049
u8700:
	goto	l5863
	line	702
	
l6049:	
;charge_mgr.c: 702: if(!hasRise)
	bsf	status, 5	;RP0=1, select bank1
	movf	((Slot_Charge_Ctrl@hasRise)^080h),w
	btfss	status,2
	goto	u8711
	goto	u8710
u8711:
	goto	l5913
u8710:
	goto	l5839
	line	713
	
l6057:	
;charge_mgr.c: 712: }
;charge_mgr.c: 713: if(v > 3500 && v < 3990)
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0ADh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8721
	goto	u8720
u8721:
	goto	l6063
u8720:
	
l6059:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u8731
	goto	u8730
u8731:
	goto	l6063
u8730:
	goto	l5913
	line	726
	
l6063:	
;charge_mgr.c: 716: }
;charge_mgr.c: 725: if(v > 2300U && v < 3500U && pre < 3500U &&
;charge_mgr.c: 726: v + 150U >= pre && pre + 150U >= v)
	movlw	08h
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FDh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8741
	goto	u8740
u8741:
	goto	l5839
u8740:
	
l6065:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0ACh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u8751
	goto	u8750
u8751:
	goto	l5839
u8750:
	
l6067:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1)^080h,w
	movlw	0ACh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre)^080h,w
	skipnc
	goto	u8761
	goto	u8760
u8761:
	goto	l5839
u8760:
	
l6069:	
	movf	(Slot_Charge_Ctrl@v)^080h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@pre+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8775
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@pre)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8775:
	skipc
	goto	u8771
	goto	u8770
u8771:
	goto	l5839
u8770:
	
l6071:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@pre)^080h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@pre+1)^080h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8785
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8785:
	skipc
	goto	u8781
	goto	u8780
u8781:
	goto	l5839
u8780:
	goto	l5913
	line	740
	
l6081:	
;charge_mgr.c: 740: ct++;
	incf	(Slot_Charge_Ctrl@ct)^080h,f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	741
	
l6083:	
;charge_mgr.c: 741: if(ct > (60 * 100))
	movlw	017h
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	071h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u8791
	goto	u8790
u8791:
	goto	l6087
u8790:
	line	743
	
l6085:	
;charge_mgr.c: 742: {
;charge_mgr.c: 743: st = 7;
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	744
;charge_mgr.c: 744: break;
	goto	l6459
	line	746
	
l6087:	
;charge_mgr.c: 745: }
;charge_mgr.c: 746: if(v > 750)
	movlw	02h
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8801
	goto	u8800
u8801:
	goto	l6093
u8800:
	line	748
	
l6089:	
;charge_mgr.c: 747: {
;charge_mgr.c: 748: st = 3;
	movlw	low(03h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	749
	
l6091:	
;charge_mgr.c: 749: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	750
;charge_mgr.c: 750: break;
	goto	l6459
	line	752
	
l6093:	
;charge_mgr.c: 751: }
;charge_mgr.c: 752: if(v >= 3850)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0Ah
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8811
	goto	u8810
u8811:
	goto	l6459
u8810:
	goto	l6085
	line	760
	
l6097:	
;charge_mgr.c: 760: ct++;
	incf	(Slot_Charge_Ctrl@ct)^080h,f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	761
	
l6099:	
;charge_mgr.c: 761: if(ct > (300 * 100))
	movlw	075h
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	031h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u8821
	goto	u8820
u8821:
	goto	l6103
u8820:
	goto	l6085
	line	766
	
l6103:	
;charge_mgr.c: 765: }
;charge_mgr.c: 766: if(v >= 3850)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0Ah
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8831
	goto	u8830
u8831:
	goto	l6109
u8830:
	line	768
	
l6105:	
;charge_mgr.c: 767: {
;charge_mgr.c: 768: g_ovCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	769
;charge_mgr.c: 769: if(g_ovCnt[idx] >= 5)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u8841
	goto	u8840
u8841:
	goto	l6111
u8840:
	goto	l6085
	line	777
	
l6109:	
;charge_mgr.c: 775: else
;charge_mgr.c: 776: {
;charge_mgr.c: 777: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	779
	
l6111:	
;charge_mgr.c: 778: }
;charge_mgr.c: 779: if(v >= 2700)
	movlw	0Ah
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	08Ch
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8851
	goto	u8850
u8851:
	goto	l6459
u8850:
	line	781
	
l6113:	
;charge_mgr.c: 780: {
;charge_mgr.c: 781: st = 4;
	movlw	low(04h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	782
	
l6115:	
;charge_mgr.c: 782: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	783
	
l6117:	
;charge_mgr.c: 783: g_ccBlocks[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	784
	
l6119:	
;charge_mgr.c: 784: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	785
	
l6121:	
;charge_mgr.c: 785: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	line	786
	
l6123:	
;charge_mgr.c: 786: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6459
	line	791
	
l6125:	
;charge_mgr.c: 791: ct++;
	incf	(Slot_Charge_Ctrl@ct)^080h,f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	792
	
l6127:	
;charge_mgr.c: 792: if(ct >= (600 * 100))
	movlw	0EAh
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	060h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u8861
	goto	u8860
u8861:
	goto	l6133
u8860:
	line	794
	
l6129:	
;charge_mgr.c: 793: {
;charge_mgr.c: 794: ct -= (600 * 100);
	movlw	060h
	subwf	(Slot_Charge_Ctrl@ct)^080h,f
	movlw	0EAh
	skipc
	decf	(Slot_Charge_Ctrl@ct+1)^080h,f
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	795
	
l6131:	
;charge_mgr.c: 795: g_ccBlocks[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	797
	
l6133:	
;charge_mgr.c: 796: }
;charge_mgr.c: 797: if(g_ccBlocks[idx] >= 18)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(012h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u8871
	goto	u8870
u8871:
	goto	l6137
u8870:
	goto	l6085
	line	806
	
l6137:	
;charge_mgr.c: 801: }
;charge_mgr.c: 806: if(v >= 3990 && ty == 6)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8881
	goto	u8880
u8881:
	goto	l6143
u8880:
	
l6139:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u8891
	goto	u8890
u8891:
	goto	l6143
u8890:
	goto	l6151
	line	810
	
l6143:	
;charge_mgr.c: 810: else if(ct <= (750))
	movlw	02h
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipnc
	goto	u8901
	goto	u8900
u8901:
	goto	l6147
u8900:
	goto	l6151
	line	820
	
l6147:	
;charge_mgr.c: 818: else
;charge_mgr.c: 819: {
;charge_mgr.c: 820: if(v > g_slotRefV[idx]) g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8915
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8915:
	skipnc
	goto	u8911
	goto	u8910
u8911:
	goto	l6151
u8910:
	
l6149:	
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	line	830
	
l6151:	
;charge_mgr.c: 821: }
;charge_mgr.c: 830: if(ty == 6)
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u8921
	goto	u8920
u8921:
	goto	l6197
u8920:
	line	832
	
l6153:	
;charge_mgr.c: 831: {
;charge_mgr.c: 832: if(v < 2000U)
	movlw	07h
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0D0h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u8931
	goto	u8930
u8931:
	goto	l6163
u8930:
	line	834
	
l6155:	
;charge_mgr.c: 833: {
;charge_mgr.c: 834: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	835
;charge_mgr.c: 835: if(g_detectLowCnt[idx] >= 33U)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u8941
	goto	u8940
u8941:
	goto	l6165
u8940:
	line	837
	
l6157:	
;charge_mgr.c: 836: {
;charge_mgr.c: 837: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	838
	
l6159:	
;charge_mgr.c: 838: st = 7;
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	goto	l6091
	line	845
	
l6163:	
;charge_mgr.c: 843: else
;charge_mgr.c: 844: {
;charge_mgr.c: 845: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	864
	
l6165:	
;charge_mgr.c: 846: }
;charge_mgr.c: 864: if(ct >= 200U)
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	0C8h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u8951
	goto	u8950
u8951:
	goto	l6231
u8950:
	line	866
	
l6167:	
;charge_mgr.c: 865: {
;charge_mgr.c: 866: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	867
	
l6169:	
;charge_mgr.c: 867: if(v >= 2800U && v < 3990)
	movlw	0Ah
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8961
	goto	u8960
u8961:
	goto	l6181
u8960:
	
l6171:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u8971
	goto	u8970
u8971:
	goto	l6181
u8970:
	line	869
	
l6173:	
;charge_mgr.c: 868: {
;charge_mgr.c: 869: st = 5;
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	870
	
l6175:	
;charge_mgr.c: 870: g_ccBlocks[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6121
	line	874
	
l6181:	
;charge_mgr.c: 874: else if(v >= g_slotRefV[idx] + (30))
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipz
	goto	u8985
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v)^080h,w
u8985:
	skipc
	goto	u8981
	goto	u8980
u8981:
	goto	l6185
u8980:
	line	876
	
l6183:	
;charge_mgr.c: 875: {
;charge_mgr.c: 876: g_stableCnt[idx] = 1;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	877
;charge_mgr.c: 877: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	line	878
;charge_mgr.c: 878: }
	goto	l6459
	line	879
	
l6185:	
;charge_mgr.c: 879: else if(g_stableCnt[idx] != 0)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(indf),w
	btfsc	status,2
	goto	u8991
	goto	u8990
u8991:
	goto	l6189
u8990:
	goto	l5579
	line	883
	
l6189:	
;charge_mgr.c: 883: else if(g_ccBlocks[idx] & 0x80)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	btfss	indf,(7)&7
	goto	u9001
	goto	u9000
u9001:
	goto	l6193
u9000:
	goto	l6085
	line	889
	
l6193:	
;charge_mgr.c: 887: else
;charge_mgr.c: 888: {
;charge_mgr.c: 889: g_ccBlocks[idx] |= 0x80;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(7/8),(7)&7
	line	890
	
l6195:	
;charge_mgr.c: 890: st = 1;
	clrf	(Slot_Charge_Ctrl@st)^080h
	incf	(Slot_Charge_Ctrl@st)^080h,f
	line	891
;charge_mgr.c: 891: g_slotRefV[idx] = 0;
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	892
;charge_mgr.c: 892: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6459
	line	902
	
l6197:	
;charge_mgr.c: 897: else
;charge_mgr.c: 898: {
;charge_mgr.c: 902: if((v < g_slotRefV[idx] && g_slotRefV[idx] - v > 500) || v < 2000U)
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipz
	goto	u9015
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v)^080h,w
u9015:
	skipnc
	goto	u9011
	goto	u9010
u9011:
	goto	l6201
u9010:
	
l6199:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipc
	incf	(Slot_Charge_Ctrl@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	01h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipnc
	goto	u9021
	goto	u9020
u9021:
	goto	l6203
u9020:
	
l6201:	
	movlw	07h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0D0h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u9031
	goto	u9030
u9031:
	goto	l6215
u9030:
	line	904
	
l6203:	
;charge_mgr.c: 903: {
;charge_mgr.c: 904: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	905
;charge_mgr.c: 905: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9041
	goto	u9040
u9041:
	goto	l6207
u9040:
	goto	l6459
	line	907
	
l6207:	
;charge_mgr.c: 907: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	908
	
l6209:	
;charge_mgr.c: 908: st = 1;
	clrf	(Slot_Charge_Ctrl@st)^080h
	incf	(Slot_Charge_Ctrl@st)^080h,f
	goto	l6091
	line	914
	
l6215:	
;charge_mgr.c: 912: else
;charge_mgr.c: 913: {
;charge_mgr.c: 914: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	926
	
l6217:	
;charge_mgr.c: 915: }
;charge_mgr.c: 926: if(ct <= (750))
	movlw	02h
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipnc
	goto	u9051
	goto	u9050
u9051:
	goto	l6223
u9050:
	line	928
	
l6219:	
;charge_mgr.c: 927: {
;charge_mgr.c: 928: if(v >= g_slotRefV[idx] + (30))
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipz
	goto	u9065
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v)^080h,w
u9065:
	skipc
	goto	u9061
	goto	u9060
u9061:
	goto	l6223
u9060:
	line	929
	
l6221:	
;charge_mgr.c: 929: g_stableCnt[idx] = 1;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	931
	
l6223:	
;charge_mgr.c: 930: }
;charge_mgr.c: 931: if(ct > (750) && g_stableCnt[idx] == 0)
	movlw	02h
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u9071
	goto	u9070
u9071:
	goto	l6231
u9070:
	
l6225:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfss	status,2
	goto	u9081
	goto	u9080
u9081:
	goto	l6231
u9080:
	goto	l6159
	line	945
	
l6231:	
;charge_mgr.c: 936: }
;charge_mgr.c: 937: }
;charge_mgr.c: 945: if(v >= 3990 && ty == 1)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9091
	goto	u9090
u9091:
	goto	l6239
u9090:
	
l6233:	
		decf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9101
	goto	u9100
u9101:
	goto	l6239
u9100:
	line	947
	
l6235:	
;charge_mgr.c: 946: {
;charge_mgr.c: 947: st = 6;
	movlw	low(06h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	goto	l6091
	line	955
	
l6239:	
;charge_mgr.c: 950: }
;charge_mgr.c: 955: if(v >= 3850 && ty != 6)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0Ah
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9111
	goto	u9110
u9111:
	goto	l6247
u9110:
	
l6241:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u9121
	goto	u9120
u9121:
	goto	l6247
u9120:
	line	957
	
l6243:	
;charge_mgr.c: 956: {
;charge_mgr.c: 957: g_ovCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	958
;charge_mgr.c: 958: if(g_ovCnt[idx] >= 5)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u9131
	goto	u9130
u9131:
	goto	l563
u9130:
	goto	l6085
	line	966
	
l6247:	
;charge_mgr.c: 964: else
;charge_mgr.c: 965: {
;charge_mgr.c: 966: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	968
	
l6249:	
;charge_mgr.c: 968: if(v >= 3100 && !(v >= 3990 && ty == 6))
	movlw	0Ch
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	01Ch
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9141
	goto	u9140
u9141:
	goto	l563
u9140:
	
l6251:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9151
	goto	u9150
u9151:
	goto	l6255
u9150:
	
l6253:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u9161
	goto	u9160
u9161:
	goto	l563
u9160:
	line	970
	
l6255:	
;charge_mgr.c: 969: {
;charge_mgr.c: 970: st = 5;
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	971
	
l6257:	
;charge_mgr.c: 971: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	972
	
l6259:	
;charge_mgr.c: 972: g_ccBlocks[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6459
	line	979
	
l6261:	
;charge_mgr.c: 979: ct++;
	incf	(Slot_Charge_Ctrl@ct)^080h,f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	980
	
l6263:	
;charge_mgr.c: 980: if(ct > (600 * 100))
	movlw	0EAh
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	061h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u9171
	goto	u9170
u9171:
	goto	l724
u9170:
	line	981
	
l6265:	
;charge_mgr.c: 981: st = 6;
	movlw	low(06h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	
l724:	
	line	989
;charge_mgr.c: 989: if(v >= 3990 && ty == 6)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9181
	goto	u9180
u9181:
	goto	l6271
u9180:
	
l6267:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9191
	goto	u9190
u9191:
	goto	l6271
u9190:
	goto	l6459
	line	1002
	
l6271:	
;charge_mgr.c: 1002: if(v < 3990 && ct <= (750) && ty == 1)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u9201
	goto	u9200
u9201:
	goto	l6293
u9200:
	
l6273:	
	movlw	02h
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipnc
	goto	u9211
	goto	u9210
u9211:
	goto	l6293
u9210:
	
l6275:	
		decf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9221
	goto	u9220
u9221:
	goto	l6293
u9220:
	line	1004
	
l6277:	
;charge_mgr.c: 1003: {
;charge_mgr.c: 1004: if(g_ccBlocks[idx] == 0)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfss	status,2
	goto	u9231
	goto	u9230
u9231:
	goto	l6281
u9230:
	line	1006
	
l6279:	
;charge_mgr.c: 1005: {
;charge_mgr.c: 1006: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	line	1007
;charge_mgr.c: 1007: g_ccBlocks[idx] = 1;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	1008
;charge_mgr.c: 1008: }
	goto	l6293
	line	1009
	
l6281:	
;charge_mgr.c: 1009: else if(v >= g_slotRefV[idx] + (50))
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipz
	goto	u9245
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v)^080h,w
u9245:
	skipc
	goto	u9241
	goto	u9240
u9241:
	goto	l6291
u9240:
	line	1011
	
l6283:	
;charge_mgr.c: 1010: {
;charge_mgr.c: 1011: if(++g_stableCnt[idx] >= 3)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	movlw	low(03h)
	subwf	(indf),w
	skipc
	goto	u9251
	goto	u9250
u9251:
	goto	l728
u9250:
	line	1013
	
l6285:	
;charge_mgr.c: 1012: {
;charge_mgr.c: 1013: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6159
	line	1021
	
l6291:	
;charge_mgr.c: 1019: else
;charge_mgr.c: 1020: {
;charge_mgr.c: 1021: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6293
	line	1022
	
l728:	
	line	1030
	
l6293:	
;charge_mgr.c: 1022: }
;charge_mgr.c: 1023: }
;charge_mgr.c: 1030: if(v >= 3990)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9261
	goto	u9260
u9261:
	goto	l6323
u9260:
	line	1032
	
l6295:	
;charge_mgr.c: 1031: {
;charge_mgr.c: 1032: if(ty == 1)
		decf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9271
	goto	u9270
u9271:
	goto	l6307
u9270:
	line	1034
	
l6297:	
;charge_mgr.c: 1033: {
;charge_mgr.c: 1034: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1035
;charge_mgr.c: 1035: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9281
	goto	u9280
u9281:
	goto	l6301
u9280:
	goto	l6459
	line	1037
	
l6301:	
;charge_mgr.c: 1037: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6235
	line	1042
	
l6307:	
;charge_mgr.c: 1041: }
;charge_mgr.c: 1042: if(ty == 6)
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9291
	goto	u9290
u9291:
	goto	l6311
u9290:
	goto	l6459
	line	1047
	
l6311:	
;charge_mgr.c: 1046: }
;charge_mgr.c: 1047: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1048
;charge_mgr.c: 1048: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9301
	goto	u9300
u9301:
	goto	l6315
u9300:
	goto	l6459
	line	1050
	
l6315:	
;charge_mgr.c: 1050: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1051
	
l6317:	
;charge_mgr.c: 1051: ty = 0;
	clrf	(Slot_Charge_Ctrl@ty)^080h
	line	1052
	
l6319:	
;charge_mgr.c: 1052: st = 0;
	clrf	(Slot_Charge_Ctrl@st)^080h
	goto	l6091
	line	1063
	
l6323:	
;charge_mgr.c: 1055: }
;charge_mgr.c: 1063: if(ty == 6)
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9311
	goto	u9310
u9311:
	goto	l6337
u9310:
	line	1065
	
l6325:	
;charge_mgr.c: 1064: {
;charge_mgr.c: 1065: if(v < 2000U)
	movlw	07h
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0D0h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u9321
	goto	u9320
u9321:
	goto	l6335
u9320:
	line	1067
	
l6327:	
;charge_mgr.c: 1066: {
;charge_mgr.c: 1067: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1068
;charge_mgr.c: 1068: if(g_detectLowCnt[idx] >= 33U)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u9331
	goto	u9330
u9331:
	goto	l6353
u9330:
	goto	l6157
	line	1078
	
l6335:	
;charge_mgr.c: 1076: else
;charge_mgr.c: 1077: {
;charge_mgr.c: 1078: g_detectLowCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l6353
	line	1083
	
l6337:	
;charge_mgr.c: 1081: else
;charge_mgr.c: 1082: {
;charge_mgr.c: 1083: if(v < g_slotRefV[idx] && g_slotRefV[idx] - v > 500)
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipz
	goto	u9345
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v)^080h,w
u9345:
	skipnc
	goto	u9341
	goto	u9340
u9341:
	goto	l6335
u9340:
	
l6339:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipc
	incf	(Slot_Charge_Ctrl@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	01h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipc
	goto	u9351
	goto	u9350
u9351:
	goto	l6335
u9350:
	line	1085
	
l6341:	
;charge_mgr.c: 1084: {
;charge_mgr.c: 1085: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1086
;charge_mgr.c: 1086: if(g_detectLowCnt[idx] >= 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipc
	goto	u9361
	goto	u9360
u9361:
	goto	l6353
u9360:
	line	1088
	
l6343:	
;charge_mgr.c: 1087: {
;charge_mgr.c: 1088: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1089
;charge_mgr.c: 1089: g_ccBlocks[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1092
	
l6345:	
;charge_mgr.c: 1092: ty = 0;
	clrf	(Slot_Charge_Ctrl@ty)^080h
	goto	l6209
	line	1108
	
l6353:	
;charge_mgr.c: 1101: }
;charge_mgr.c: 1102: }
;charge_mgr.c: 1108: if(v >= 3850 && ty == 1)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0Ah
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9371
	goto	u9370
u9371:
	goto	l6361
u9370:
	
l6355:	
		decf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9381
	goto	u9380
u9381:
	goto	l6361
u9380:
	line	1110
	
l6357:	
;charge_mgr.c: 1109: {
;charge_mgr.c: 1110: g_ovCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1111
;charge_mgr.c: 1111: if(g_ovCnt[idx] >= 5)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u9391
	goto	u9390
u9391:
	goto	l563
u9390:
	goto	l6085
	line	1119
	
l6361:	
;charge_mgr.c: 1117: else
;charge_mgr.c: 1118: {
;charge_mgr.c: 1119: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6459
	line	1130
	
l6363:	
;charge_mgr.c: 1130: if(v >= 3990)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9401
	goto	u9400
u9401:
	goto	l6381
u9400:
	line	1132
	
l6365:	
;charge_mgr.c: 1131: {
;charge_mgr.c: 1132: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1133
	
l6367:	
;charge_mgr.c: 1133: if(g_detectLowCnt[idx] >= (ty == 6 ? 50 : 2))
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u9411
	goto	u9410
u9411:
	goto	l6371
u9410:
	
l6369:	
	movlw	02h
	movwf	(_Slot_Charge_Ctrl$385)^080h
	clrf	(_Slot_Charge_Ctrl$385+1)^080h
	goto	l6373
	
l6371:	
	movlw	032h
	movwf	(_Slot_Charge_Ctrl$385)^080h
	clrf	(_Slot_Charge_Ctrl$385+1)^080h
	
l6373:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(_Slot_Charge_Ctrl$385+1)^080h,w
	xorlw	80h
	sublw	080h
	skipz
	goto	u9425
	movf	(_Slot_Charge_Ctrl$385)^080h,w
	subwf	indf,w
u9425:

	skipc
	goto	u9421
	goto	u9420
u9421:
	goto	l6459
u9420:
	line	1135
	
l6375:	
;charge_mgr.c: 1134: {
;charge_mgr.c: 1135: g_detectLowCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l6319
	line	1144
	
l6381:	
;charge_mgr.c: 1140: }
;charge_mgr.c: 1144: if(v < 2800U)
	movlw	0Ah
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u9431
	goto	u9430
u9431:
	goto	l5619
u9430:
	line	1146
	
l6383:	
;charge_mgr.c: 1145: {
;charge_mgr.c: 1146: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1147
;charge_mgr.c: 1147: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9441
	goto	u9440
u9441:
	goto	l6387
u9440:
	goto	l6459
	line	1149
	
l6387:	
;charge_mgr.c: 1149: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1150
	
l6389:	
;charge_mgr.c: 1150: st = 4;
	movlw	low(04h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	1151
	
l6391:	
;charge_mgr.c: 1151: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	1152
	
l6393:	
;charge_mgr.c: 1152: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6175
	line	1166
	
l6403:	
;charge_mgr.c: 1166: if(v >= 3990)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9451
	goto	u9450
u9451:
	goto	l6419
u9450:
	line	1168
	
l6405:	
;charge_mgr.c: 1167: {
;charge_mgr.c: 1168: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1169
;charge_mgr.c: 1169: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9461
	goto	u9460
u9461:
	goto	l6409
u9460:
	goto	l6459
	line	1171
	
l6409:	
;charge_mgr.c: 1171: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1172
	
l6411:	
;charge_mgr.c: 1172: ty = 0;
	clrf	(Slot_Charge_Ctrl@ty)^080h
	line	1173
	
l6413:	
;charge_mgr.c: 1173: st = 0;
	clrf	(Slot_Charge_Ctrl@st)^080h
	goto	l6257
	line	1186
	
l6419:	
;charge_mgr.c: 1177: }
;charge_mgr.c: 1186: if(ty == 2 || ty == 3)
		movlw	2
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u9471
	goto	u9470
u9471:
	goto	l6423
u9470:
	
l6421:	
		movlw	3
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9481
	goto	u9480
u9481:
	goto	l6439
u9480:
	line	1188
	
l6423:	
;charge_mgr.c: 1187: {
;charge_mgr.c: 1188: if(v > 2700U && (g_highVFlag & ((unsigned int)1 << idx)))
	movlw	0Ah
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	08Dh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9491
	goto	u9490
u9491:
	goto	l5619
u9490:
	
l6425:	
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9504
u9505:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9504:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9505
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u9511
	goto	u9510
u9511:
	goto	l5619
u9510:
	line	1190
	
l6427:	
;charge_mgr.c: 1189: {
;charge_mgr.c: 1190: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1191
;charge_mgr.c: 1191: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9521
	goto	u9520
u9521:
	goto	l6207
u9520:
	goto	l6459
	line	1204
	
l6439:	
;charge_mgr.c: 1202: }
;charge_mgr.c: 1204: if(v > 750)
	movlw	02h
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9531
	goto	u9530
u9531:
	goto	l5619
u9530:
	line	1206
	
l6441:	
;charge_mgr.c: 1205: {
;charge_mgr.c: 1206: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1207
;charge_mgr.c: 1207: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9541
	goto	u9540
u9541:
	goto	l6207
u9540:
	goto	l6459
	line	1220
	
l6453:	
;charge_mgr.c: 1220: st = 0;
	clrf	(Slot_Charge_Ctrl@st)^080h
	line	1221
;charge_mgr.c: 1221: break;
	goto	l6459
	line	219
	
l6457:	
	movf	(Slot_Charge_Ctrl@st)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l5563
	xorlw	1^0	; case 1
	skipnz
	goto	l5583
	xorlw	2^1	; case 2
	skipnz
	goto	l6081
	xorlw	3^2	; case 3
	skipnz
	goto	l6097
	xorlw	4^3	; case 4
	skipnz
	goto	l6125
	xorlw	5^4	; case 5
	skipnz
	goto	l6261
	xorlw	6^5	; case 6
	skipnz
	goto	l6363
	xorlw	7^6	; case 7
	skipnz
	goto	l6403
	xorlw	8^7	; case 8
	skipnz
	goto	l5801
	xorlw	9^8	; case 9
	skipnz
	goto	l5961
	goto	l6453
	opt asmopt_pop

	line	1222
	
l563:	
	line	1224
	
l6459:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Slot_Charge_Ctrl@st)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Slot_Charge_Ctrl@ty)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Slot_Charge_Ctrl@ct)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movwf	indf
	line	1230
	
l6461:	
;charge_mgr.c: 1227: if((st == 2 || st == 3 ||
;charge_mgr.c: 1228: st == 4 || st == 5 ||
;charge_mgr.c: 1229: st == 8 || st == 1) &&
;charge_mgr.c: 1230: !g_tempProtect && !g_vccProtect)
		movlw	2
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfsc	status,2
	goto	u9551
	goto	u9550
u9551:
	goto	l6473
u9550:
	
l6463:	
		movlw	3
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfsc	status,2
	goto	u9561
	goto	u9560
u9561:
	goto	l6473
u9560:
	
l6465:	
		movlw	4
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfsc	status,2
	goto	u9571
	goto	u9570
u9571:
	goto	l6473
u9570:
	
l6467:	
		movlw	5
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfsc	status,2
	goto	u9581
	goto	u9580
u9581:
	goto	l6473
u9580:
	
l6469:	
		movlw	8
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfsc	status,2
	goto	u9591
	goto	u9590
u9591:
	goto	l6473
u9590:
	
l6471:	
		decf	((Slot_Charge_Ctrl@st)^080h),w
	btfss	status,2
	goto	u9601
	goto	u9600
u9601:
	goto	l6483
u9600:
	
l6473:	
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u9611
	goto	u9610
u9611:
	goto	l6483
u9610:
	
l6475:	
	movf	((_g_vccProtect)^080h),w
	btfss	status,2
	goto	u9621
	goto	u9620
u9621:
	goto	l6483
u9620:
	goto	l6479
	line	1232
	
l778:	
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	l809
	
l780:	
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	l809
	
l781:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	l809
	
l782:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	l809
	
l783:	
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	l809
	
l784:	
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	l809
	
l785:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l809
	
l786:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l809
	
l787:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	l809
	
l788:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	l809
	
l789:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l809
	
l790:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l809
	
l6479:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l778
	xorlw	1^0	; case 1
	skipnz
	goto	l780
	xorlw	2^1	; case 2
	skipnz
	goto	l781
	xorlw	3^2	; case 3
	skipnz
	goto	l782
	xorlw	4^3	; case 4
	skipnz
	goto	l783
	xorlw	5^4	; case 5
	skipnz
	goto	l784
	xorlw	6^5	; case 6
	skipnz
	goto	l785
	xorlw	7^6	; case 7
	skipnz
	goto	l786
	xorlw	8^7	; case 8
	skipnz
	goto	l787
	xorlw	9^8	; case 9
	skipnz
	goto	l788
	xorlw	10^9	; case 10
	skipnz
	goto	l789
	xorlw	11^10	; case 11
	skipnz
	goto	l790
	goto	l809
	opt asmopt_pop

	line	1236
	
l795:	
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l809
	
l797:	
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l809
	
l798:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	l809
	
l799:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	l809
	
l800:	
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l809
	
l801:	
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l809
	
l802:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l809
	
l803:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l809
	
l804:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	l809
	
l805:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	l809
	
l806:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l809
	
l807:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l809
	
l6483:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l795
	xorlw	1^0	; case 1
	skipnz
	goto	l797
	xorlw	2^1	; case 2
	skipnz
	goto	l798
	xorlw	3^2	; case 3
	skipnz
	goto	l799
	xorlw	4^3	; case 4
	skipnz
	goto	l800
	xorlw	5^4	; case 5
	skipnz
	goto	l801
	xorlw	6^5	; case 6
	skipnz
	goto	l802
	xorlw	7^6	; case 7
	skipnz
	goto	l803
	xorlw	8^7	; case 8
	skipnz
	goto	l804
	xorlw	9^8	; case 9
	skipnz
	goto	l805
	xorlw	10^9	; case 10
	skipnz
	goto	l806
	xorlw	11^10	; case 11
	skipnz
	goto	l807
	goto	l809
	opt asmopt_pop

	line	1238
	
l809:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_Charge_Ctrl
	__end_of_Slot_Charge_Ctrl:
	signat	_Slot_Charge_Ctrl,4217
	global	___wmul

;; *************** function ___wmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
;; Parameters:    Size  Location     Type
;;  multiplier      2    2[COMMON] unsigned int 
;;  multiplicand    2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  product         2    6[COMMON] unsigned int 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         6       0       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
global __ptext6
__ptext6:	;psect for function ___wmul
psect	text6
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
	global	__size_of___wmul
	__size_of___wmul	equ	__end_of___wmul-___wmul
	
___wmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___wmul: [wreg+status,2+status,0]
	line	43
	
l3399:	
	clrf	(___wmul@product)
	clrf	(___wmul@product+1)
	line	45
	
l3401:	
	btfss	(___wmul@multiplier),(0)&7
	goto	u3731
	goto	u3730
u3731:
	goto	l3405
u3730:
	line	46
	
l3403:	
	movf	(___wmul@multiplicand),w
	addwf	(___wmul@product),f
	skipnc
	incf	(___wmul@product+1),f
	movf	(___wmul@multiplicand+1),w
	addwf	(___wmul@product+1),f
	line	47
	
l3405:	
	clrc
	rlf	(___wmul@multiplicand),f
	rlf	(___wmul@multiplicand+1),f
	line	48
	
l3407:	
	clrc
	rrf	(___wmul@multiplier+1),f
	rrf	(___wmul@multiplier),f
	line	49
	
l3409:	
	movf	((___wmul@multiplier)),w
iorwf	((___wmul@multiplier+1)),w
	btfss	status,2
	goto	u3741
	goto	u3740
u3741:
	goto	l3401
u3740:
	line	52
	
l3411:	
	movf	(___wmul@product+1),w
	movwf	(?___wmul+1)
	movf	(___wmul@product),w
	movwf	(?___wmul)
	line	53
	
l879:	
	return
	opt stack 0
GLOBAL	__end_of___wmul
	__end_of___wmul:
	signat	___wmul,8314
	global	_Get_Vcc

;; *************** function _Get_Vcc *****************
;; Defined at:
;;		line 47 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   17[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  2   52[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;; This function is called by:
;;		_main
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	47
global __ptext7
__ptext7:	;psect for function _Get_Vcc
psect	text7
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	47
	global	__size_of_Get_Vcc
	__size_of_Get_Vcc	equ	__end_of_Get_Vcc-_Get_Vcc
	
_Get_Vcc:	
;incstack = 0
	opt	stack 3
; Regs used in _Get_Vcc: [wreg+status,2+status,0+pclath+cstack]
	line	49
	
l5221:	
;charge_mgr.c: 49: if(0xA5 == ADC_Sample(31, 0))
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u7211
	goto	u7210
u7211:
	goto	l499
u7210:
	line	51
	
l5223:	
;charge_mgr.c: 50: {
;charge_mgr.c: 51: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult),w	;volatile
	movwf	(___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Get_Vcc@pt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Get_Vcc@pt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Get_Vcc@pt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Get_Vcc@pt)

	line	52
	
l5225:	
;charge_mgr.c: 52: g_vcc_mv = (unsigned int)pt;
	movf	(Get_Vcc@pt+1),w
	movwf	(_g_vcc_mv+1)	;volatile
	movf	(Get_Vcc@pt),w
	movwf	(_g_vcc_mv)	;volatile
	line	55
	
l499:	
	return
	opt stack 0
GLOBAL	__end_of_Get_Vcc
	__end_of_Get_Vcc:
	signat	_Get_Vcc,90
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 108 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2    2[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         2       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	108
global __ptext8
__ptext8:	;psect for function _Detect_BatteryType
psect	text8
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	108
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 4
; Regs used in _Detect_BatteryType: [wreg]
	line	110
	
l3367:	
;charge_mgr.c: 110: if(voltage >= 3990)
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u3671
	goto	u3670
u3671:
	goto	l3373
u3670:
	line	111
	
l3369:	
;charge_mgr.c: 111: return 0;
	movlw	low(0)
	goto	l522
	line	112
	
l3373:	
;charge_mgr.c: 112: if(voltage < 500)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u3681
	goto	u3680
u3681:
	goto	l3379
u3680:
	goto	l3369
	line	127
	
l3379:	
;charge_mgr.c: 127: if(voltage >= 1015 && voltage < 3990)
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u3691
	goto	u3690
u3691:
	goto	l3387
u3690:
	
l3381:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u3701
	goto	u3700
u3701:
	goto	l3387
u3700:
	line	128
	
l3383:	
;charge_mgr.c: 128: return 5;
	movlw	low(05h)
	goto	l522
	line	133
	
l3387:	
;charge_mgr.c: 133: if(voltage >= 500 && voltage < 3990)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u3711
	goto	u3710
u3711:
	goto	l3369
u3710:
	
l3389:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u3721
	goto	u3720
u3721:
	goto	l3369
u3720:
	line	134
	
l3391:	
;charge_mgr.c: 134: return 1;
	movlw	low(01h)
	line	137
	
l522:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_Adc_Norm

;; *************** function _Adc_Norm *****************
;; Defined at:
;;		line 64 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  ch              1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  ch              1   20[BANK0 ] unsigned char 
;;  raw             2   21[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   17[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       3       0       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       6       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	64
global __ptext9
__ptext9:	;psect for function _Adc_Norm
psect	text9
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	64
	global	__size_of_Adc_Norm
	__size_of_Adc_Norm	equ	__end_of_Adc_Norm-_Adc_Norm
	
_Adc_Norm:	
;incstack = 0
	opt	stack 3
; Regs used in _Adc_Norm: [wreg+status,2+status,0+pclath+cstack]
;Adc_Norm@ch stored from wreg
	movwf	(Adc_Norm@ch)
	line	67
	
l5229:	
;charge_mgr.c: 66: unsigned int raw;
;charge_mgr.c: 67: if(0xA5 != ADC_Sample(ch, 0))
	clrf	(ADC_Sample@adldo)
	movf	(Adc_Norm@ch),w
	fcall	_ADC_Sample
	xorlw	0A5h
	skipnz
	goto	u7221
	goto	u7220
u7221:
	goto	l5235
u7220:
	line	68
	
l5231:	
;charge_mgr.c: 68: return 0;
	clrf	(?_Adc_Norm)
	clrf	(?_Adc_Norm+1)
	goto	l503
	line	69
	
l5235:	
;charge_mgr.c: 69: raw = adresult;
	movf	(_adresult+1),w	;volatile
	movwf	(Adc_Norm@raw+1)
	movf	(_adresult),w	;volatile
	movwf	(Adc_Norm@raw)
	line	70
	
l5237:	
;charge_mgr.c: 70: if(g_vcc_mv == 0)
	movf	((_g_vcc_mv)),w	;volatile
iorwf	((_g_vcc_mv+1)),w	;volatile
	btfss	status,2
	goto	u7231
	goto	u7230
u7231:
	goto	l5243
u7230:
	line	71
	
l5239:	
;charge_mgr.c: 71: return raw;
	movf	(Adc_Norm@raw+1),w
	movwf	(?_Adc_Norm+1)
	movf	(Adc_Norm@raw),w
	movwf	(?_Adc_Norm)
	goto	l503
	line	72
	
l5243:	
;charge_mgr.c: 72: return (unsigned int)(((unsigned long)raw * 5000UL) / (unsigned long)g_vcc_mv);
	movf	(_g_vcc_mv),w	;volatile
	movwf	(___lldiv@divisor)
	movf	(_g_vcc_mv+1),w	;volatile
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movf	(Adc_Norm@raw),w
	movwf	(___lmul@multiplier)
	movf	(Adc_Norm@raw+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(?_Adc_Norm+1)
	movf	(0+(?___lldiv)),w
	movwf	(?_Adc_Norm)
	line	73
	
l503:	
	return
	opt stack 0
GLOBAL	__end_of_Adc_Norm
	__end_of_Adc_Norm:
	signat	_Adc_Norm,4218
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 75 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   21[BANK0 ] unsigned long 
;;  temp_x10        2   27[BANK0 ] unsigned int 
;;  ntcVal          2   25[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   60[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/A00
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=0
	line	75
global __ptext10
__ptext10:	;psect for function _Read_Temperature
psect	text10
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	75
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 4
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	80
	
l6651:	
;charge_mgr.c: 77: unsigned int ntcVal;
;charge_mgr.c: 78: unsigned int temp_x10;
;charge_mgr.c: 80: test_adc = ADC_Sample(18, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	81
	
l6653:	
;charge_mgr.c: 81: if(0xA5 != test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u10001
	goto	u10000
u10001:
	goto	l6657
u10000:
	goto	l508
	line	84
	
l6657:	
;charge_mgr.c: 84: ntcVal = adresult;
	movf	(_adresult+1),w	;volatile
	movwf	(Read_Temperature@ntcVal+1)
	movf	(_adresult),w	;volatile
	movwf	(Read_Temperature@ntcVal)
	line	85
;charge_mgr.c: 85: if(ntcVal < 100 || ntcVal > 3996)
	movlw	0
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u10011
	goto	u10010
u10011:
	goto	l508
u10010:
	
l6659:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u10021
	goto	u10020
u10021:
	goto	l6661
u10020:
	goto	l508
	line	90
	
l6661:	
;charge_mgr.c: 88: {
;charge_mgr.c: 89: unsigned long rt;
;charge_mgr.c: 90: rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	010h
	movwf	(___lldiv@divisor+1)
	movlw	0
	movwf	(___lldiv@divisor)

	movf	(Read_Temperature@ntcVal),w
	movwf	((??_Read_Temperature+0)+0)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((??_Read_Temperature+0)+0+1)
	clrf	((??_Read_Temperature+0)+0+2)
	clrf	((??_Read_Temperature+0)+0+3)
	movf	0+(??_Read_Temperature+0)+0,w
	subwf	(___lldiv@divisor),f
	movf	1+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)+0,w
	goto	u10035
	goto	u10036
u10035:
	subwf	(___lldiv@divisor+1),f
u10036:
	movf	2+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)+0,w
	goto	u10037
	goto	u10038
u10037:
	subwf	(___lldiv@divisor+2),f
u10038:
	movf	3+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)+0,w
	goto	u10039
	goto	u10030
u10039:
	subwf	(___lldiv@divisor+3),f
u10030:

	movf	(Read_Temperature@ntcVal),w
	movwf	(___lmul@multiplier)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	027h
	movwf	(___lmul@multiplicand+1)
	movlw	010h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Read_Temperature@rt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Read_Temperature@rt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@rt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@rt)

	line	91
	
l6663:	
;charge_mgr.c: 91: if(rt >= 10000UL)
		movf	(Read_Temperature@rt+3),w
	btfss	status,2
	goto	u10040
	movf	(Read_Temperature@rt+2),w
	btfss	status,2
	goto	u10040
	movlw	39
	subwf	(Read_Temperature@rt+1),w
	skipz
	goto	u10043
	movlw	16
	subwf	(Read_Temperature@rt),w
	skipz
	goto	u10043
u10043:
	btfss	status,0
	goto	u10041
	goto	u10040

u10041:
	goto	l6669
u10040:
	line	92
	
l6665:	
;charge_mgr.c: 92: temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l6667:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0F0h
	movwf	((??_Read_Temperature+0)+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+3)
	movf	(Read_Temperature@rt),w
	addwf	(??_Read_Temperature+0)+0,f
	movf	(Read_Temperature@rt+1),w
	skipnc
	incfsz	(Read_Temperature@rt+1),w
	goto	u10050
	goto	u10051
u10050:
	addwf	(??_Read_Temperature+0)+1,f
u10051:
	movf	(Read_Temperature@rt+2),w
	skipnc
	incfsz	(Read_Temperature@rt+2),w
	goto	u10052
	goto	u10053
u10052:
	addwf	(??_Read_Temperature+0)+2,f
u10053:
	movf	(Read_Temperature@rt+3),w
	skipnc
	incf	(Read_Temperature@rt+3),w
	addwf	(??_Read_Temperature+0)+3,f
	movf	3+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+3)
	movf	2+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+2)
	movf	1+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+1)
	movf	0+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier)

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(0+(?___lldiv)),w
	subwf	(Read_Temperature@temp_x10),f
	movf	(1+(?___lldiv)),w
	skipc
	decf	(Read_Temperature@temp_x10+1),f
	subwf	(Read_Temperature@temp_x10+1),f
	goto	l6673
	line	94
	
l6669:	
;charge_mgr.c: 93: else
;charge_mgr.c: 94: temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0
	movwf	(___lmul@multiplier+3)
	movlw	0
	movwf	(___lmul@multiplier+2)
	movlw	027h
	movwf	(___lmul@multiplier+1)
	movlw	010h
	movwf	(___lmul@multiplier)

	movf	(Read_Temperature@rt),w
	subwf	(___lmul@multiplier),f
	movf	(Read_Temperature@rt+1),w
	skipc
	incfsz	(Read_Temperature@rt+1),w
	goto	u10065
	goto	u10066
u10065:
	subwf	(___lmul@multiplier+1),f
u10066:
	movf	(Read_Temperature@rt+2),w
	skipc
	incfsz	(Read_Temperature@rt+2),w
	goto	u10067
	goto	u10068
u10067:
	subwf	(___lmul@multiplier+2),f
u10068:
	movf	(Read_Temperature@rt+3),w
	skipc
	incfsz	(Read_Temperature@rt+3),w
	goto	u10069
	goto	u10060
u10069:
	subwf	(___lmul@multiplier+3),f
u10060:

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10)
	
l6671:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10),f
	skipnc
	incf	(Read_Temperature@temp_x10+1),f
	line	95
	
l6673:	
;charge_mgr.c: 95: if(temp_x10 < 100U) temp_x10 = 100U;
	movlw	0
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipnc
	goto	u10071
	goto	u10070
u10071:
	goto	l514
u10070:
	
l6675:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l514:	
	line	96
;charge_mgr.c: 96: if(temp_x10 > 750U) temp_x10 = 750U;
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipc
	goto	u10081
	goto	u10080
u10081:
	goto	l515
u10080:
	
l6677:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)
	movlw	02h
	movwf	((Read_Temperature@temp_x10))+1
	
l515:	
	line	99
;charge_mgr.c: 97: }
;charge_mgr.c: 99: g_temperature = temp_x10;
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(_g_temperature+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(_g_temperature)
	line	100
	
l6679:	
;charge_mgr.c: 100: if((temp_x10 / 10U) >= 60)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u10091
	goto	u10090
u10091:
	goto	l6683
u10090:
	line	101
	
l6681:	
;charge_mgr.c: 101: g_tempProtect = 1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	incf	(_g_tempProtect)^080h,f
	goto	l508
	line	102
	
l6683:	
;charge_mgr.c: 102: else if((temp_x10 / 10U) <= 50)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u10101
	goto	u10100
u10101:
	goto	l508
u10100:
	line	103
	
l6685:	
;charge_mgr.c: 103: g_tempProtect = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	line	106
	
l508:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 235 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  d               2   46[BANK0 ] int 
;;  t               1   45[BANK0 ] unsigned char 
;;  bat_mv_long     4   40[BANK0 ] unsigned long 
;;  tc              1   44[BANK0 ] unsigned char 
;;  vx_mv           4   34[BANK0 ] unsigned long 
;;  v               2   32[BANK0 ] unsigned int 
;;  s               1   29[BANK0 ] unsigned char 
;;  pt              4   25[BANK0 ] unsigned long 
;;  vcc_mv          2   38[BANK0 ] unsigned int 
;;  i               1   48[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/A00
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      28       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      32       0       0       0
;;Total ram usage:       32 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	235
global __ptext11
__ptext11:	;psect for function _Print_SystemStatus
psect	text11
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	235
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 3
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	240
	
l5343:	
;main.c: 237: unsigned char i;
;main.c: 238: unsigned int vcc_mv;
;main.c: 240: uart_send_string("\r\n== L1211 12CH CHARGER ");
	movlw	low(((STR_4)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	241
;main.c: 241: uart_send_string("V55A");
	movlw	low(((STR_5)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	242
;main.c: 242: uart_send_string(" ==\r\n");
	movlw	low(((STR_6)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	245
	
l5345:	
;main.c: 245: test_adc = ADC_Sample(31, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	246
	
l5347:	
;main.c: 246: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u7271
	goto	u7270
u7271:
	goto	l5353
u7270:
	line	248
	
l5349:	
;main.c: 247: {
;main.c: 248: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult),w	;volatile
	movwf	(___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt)

	line	249
	
l5351:	
;main.c: 249: vcc_mv = (unsigned int)pt;
	movf	(Print_SystemStatus@pt+1),w
	movwf	(Print_SystemStatus@vcc_mv+1)
	movf	(Print_SystemStatus@pt),w
	movwf	(Print_SystemStatus@vcc_mv)
	line	250
;main.c: 250: }
	goto	l361
	line	252
	
l5353:	
;main.c: 251: else
;main.c: 252: vcc_mv = 5000;
	movlw	088h
	movwf	(Print_SystemStatus@vcc_mv)
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv))+1
	
l361:	
	line	254
;main.c: 254: g_vcc_mv = vcc_mv;
	movf	(Print_SystemStatus@vcc_mv+1),w
	movwf	(_g_vcc_mv+1)	;volatile
	movf	(Print_SystemStatus@vcc_mv),w
	movwf	(_g_vcc_mv)	;volatile
	line	256
	
l5355:	
;main.c: 256: uart_send_string("VCC=");
	movlw	low(((STR_7)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	257
	
l5357:	
;main.c: 257: uart_send_number(vcc_mv);
	movf	(Print_SystemStatus@vcc_mv+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@vcc_mv),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	258
	
l5359:	
;main.c: 258: uart_send_string("mV T=");
	movlw	low(((STR_8)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	259
	
l5361:	
;main.c: 259: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(_Print_SystemStatus$707+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_Print_SystemStatus$707)
	
l5363:	
;main.c: 259: uart_send_number(g_temperature / 10U);
	movf	(_Print_SystemStatus$707+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$707),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	260
	
l5365:	
;main.c: 260: uart_send_string(".");
	movlw	low(((STR_9)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	261
	
l5367:	
;main.c: 261: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	movwf	(_Print_SystemStatus$708+1)
	movf	(0+(?___lwmod)),w
	movwf	(_Print_SystemStatus$708)
	
l5369:	
;main.c: 261: uart_send_number(g_temperature % 10U);
	movf	(_Print_SystemStatus$708+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$708),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	262
	
l5371:	
;main.c: 262: uart_send_string("C IMP_LOCK=");
	movlw	low(((STR_10)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	263
	
l5373:	
;main.c: 263: uart_send_number(g_impCheckSlot == 0xFF ? 0xFFU : (unsigned int)g_impCheckSlot);
		incf	((_g_impCheckSlot)),w
	btfsc	status,2
	goto	u7281
	goto	u7280
u7281:
	goto	l5377
u7280:
	
l5375:	
	movf	(_g_impCheckSlot),w
	movwf	(_Print_SystemStatus$265)
	clrf	(_Print_SystemStatus$265+1)
	goto	l5379
	
l5377:	
	movlw	0FFh
	movwf	(_Print_SystemStatus$265)
	clrf	(_Print_SystemStatus$265+1)
	
l5379:	
	movf	(_Print_SystemStatus$265+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$265),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	264
	
l5381:	
;main.c: 264: uart_send_string("\r\n");
	movlw	low(((STR_11)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	269
	
l5383:	
;main.c: 269: for(i = 0; i < 12; i++)
	clrf	(Print_SystemStatus@i)
	line	274
	
l5389:	
;main.c: 273: {
;main.c: 274: unsigned int v = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Print_SystemStatus@v)
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)
	line	275
;main.c: 275: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Print_SystemStatus@s)
	line	277
	
l5391:	
;main.c: 277: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	278
	
l5393:	
;main.c: 278: uart_send_number((unsigned int)i + 1U);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@i),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	279
;main.c: 279: uart_send_char('=');
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	280
	
l5395:	
;main.c: 280: uart_send_number(v);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@v+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@v),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	286
	
l5397:	
;main.c: 285: {
;main.c: 286: unsigned long vx_mv = (unsigned long)v * 5000UL / 4096UL;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@v),w
	movwf	(___lmul@multiplier)
	movf	(Print_SystemStatus@v+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv)

	
l5399:	
	movlw	0Ch
u7295:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3),f
	rrf	(Print_SystemStatus@vx_mv+2),f
	rrf	(Print_SystemStatus@vx_mv+1),f
	rrf	(Print_SystemStatus@vx_mv),f
	addlw	-1
	skipz
	goto	u7295

	line	287
	
l5401:	
;main.c: 287: if(vx_mv + 200U >= 5000UL)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+0)+0)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+3)
	movf	(Print_SystemStatus@vx_mv),w
	addwf	(??_Print_SystemStatus+0)+0,f
	movf	(Print_SystemStatus@vx_mv+1),w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1),w
	goto	u7300
	goto	u7301
u7300:
	addwf	(??_Print_SystemStatus+0)+1,f
u7301:
	movf	(Print_SystemStatus@vx_mv+2),w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2),w
	goto	u7302
	goto	u7303
u7302:
	addwf	(??_Print_SystemStatus+0)+2,f
u7303:
	movf	(Print_SystemStatus@vx_mv+3),w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3),w
	addwf	(??_Print_SystemStatus+0)+3,f
		movf	(??_Print_SystemStatus+0)+3,w
	btfss	status,2
	goto	u7310
	movf	(??_Print_SystemStatus+0)+2,w
	btfss	status,2
	goto	u7310
	movlw	19
	subwf	(??_Print_SystemStatus+0)+1,w
	skipz
	goto	u7313
	movlw	136
	subwf	(??_Print_SystemStatus+0)+0,w
	skipz
	goto	u7313
u7313:
	btfss	status,0
	goto	u7311
	goto	u7310

u7311:
	goto	l5405
u7310:
	line	289
	
l5403:	
;main.c: 288: {
;main.c: 289: uart_send_string(" OPEN");
	movlw	low(((STR_12)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	290
;main.c: 290: }
	goto	l5417
	line	293
	
l5405:	
;main.c: 291: else
;main.c: 292: {
;main.c: 293: unsigned long bat_mv_long = 124UL * vx_mv + 206UL * 5000UL;
	movf	(Print_SystemStatus@vx_mv+3),w
	movwf	(___lmul@multiplier+3)
	movf	(Print_SystemStatus@vx_mv+2),w
	movwf	(___lmul@multiplier+2)
	movf	(Print_SystemStatus@vx_mv+1),w
	movwf	(___lmul@multiplier+1)
	movf	(Print_SystemStatus@vx_mv),w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+3)
	movf	(2+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+2)
	movf	(1+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+1)
	movf	(0+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long)

	
l5407:	
	movlw	070h
	addwf	(Print_SystemStatus@bat_mv_long),f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Print_SystemStatus@bat_mv_long+1),f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Print_SystemStatus@bat_mv_long+2),f
	movlw	0
	skipnc
movlw 1
	addwf	(Print_SystemStatus@bat_mv_long+3),f
	line	294
	
l5409:	
;main.c: 294: bat_mv_long = (bat_mv_long + 1000UL/2UL) / 1000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Print_SystemStatus+0)+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+3)
	movf	(Print_SystemStatus@bat_mv_long),w
	addwf	(??_Print_SystemStatus+0)+0,f
	movf	(Print_SystemStatus@bat_mv_long+1),w
	skipnc
	incfsz	(Print_SystemStatus@bat_mv_long+1),w
	goto	u7320
	goto	u7321
u7320:
	addwf	(??_Print_SystemStatus+0)+1,f
u7321:
	movf	(Print_SystemStatus@bat_mv_long+2),w
	skipnc
	incfsz	(Print_SystemStatus@bat_mv_long+2),w
	goto	u7322
	goto	u7323
u7322:
	addwf	(??_Print_SystemStatus+0)+2,f
u7323:
	movf	(Print_SystemStatus@bat_mv_long+3),w
	skipnc
	incf	(Print_SystemStatus@bat_mv_long+3),w
	addwf	(??_Print_SystemStatus+0)+3,f
	movf	3+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+3)
	movf	(2+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+2)
	movf	(1+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+1)
	movf	(0+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long)

	line	295
	
l5411:	
;main.c: 295: uart_send_string(" BAT(");
	movlw	low(((STR_13)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	296
	
l5413:	
;main.c: 296: uart_send_number((unsigned int)bat_mv_long);
	movf	(Print_SystemStatus@bat_mv_long+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@bat_mv_long),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	297
	
l5415:	
;main.c: 297: uart_send_string("mV)");
	movlw	low(((STR_14)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	302
	
l5417:	
;main.c: 298: }
;main.c: 299: }
;main.c: 302: uart_send_char(' ');
	movlw	low(020h)
	fcall	_uart_send_char
	line	303
;main.c: 303: switch(s)
	goto	l5473
	line	305
	
l5419:	
	movlw	low(((STR_15)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5475
	line	307
	
l5421:	
;main.c: 307: uart_send_string("[DET]");
	movlw	low(((STR_16)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	308
	
l5423:	
;main.c: 308: if(g_slotRefV[i] > 0U)
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	((??_Print_SystemStatus+0)+0),w
iorwf	((??_Print_SystemStatus+0)+1),w
	btfsc	status,2
	goto	u7331
	goto	u7330
u7331:
	goto	l5475
u7330:
	line	310
	
l5425:	
;main.c: 309: {
;main.c: 310: uart_send_string(" ref=");
	movlw	low(((STR_17)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	311
	
l5427:	
;main.c: 311: uart_send_number(g_slotRefV[i]);
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(uart_send_number@num)
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	goto	l5475
	line	314
	
l5429:	
	movlw	low(((STR_18)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5475
	line	315
	
l5431:	
	movlw	low(((STR_19)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5475
	line	316
	
l5433:	
	movlw	low(((STR_20)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5475
	line	317
	
l5435:	
	movlw	low(((STR_21)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5475
	line	318
	
l5437:	
	movlw	low(((STR_22)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5475
	line	321
	
l5439:	
;main.c: 320: {
;main.c: 321: unsigned char t = g_slot[(unsigned char)(i)].type;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Print_SystemStatus@t)
	line	322
	
l5441:	
;main.c: 322: if(t == 2 || t == 3)
		movlw	2
	xorwf	((Print_SystemStatus@t)),w
	btfsc	status,2
	goto	u7341
	goto	u7340
u7341:
	goto	l5445
u7340:
	
l5443:	
		movlw	3
	xorwf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u7351
	goto	u7350
u7351:
	goto	l5447
u7350:
	line	323
	
l5445:	
;main.c: 323: uart_send_string("[Dry/NiMH ERR]");
	movlw	low(((STR_23)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5457
	line	324
	
l5447:	
;main.c: 324: else if(t == 1)
		decf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u7361
	goto	u7360
u7361:
	goto	l5451
u7360:
	line	325
	
l5449:	
;main.c: 325: uart_send_string("[Li-ion ERR]");
	movlw	low(((STR_24)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5457
	line	326
	
l5451:	
;main.c: 326: else if(t == 6)
		movlw	6
	xorwf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u7371
	goto	u7370
u7371:
	goto	l5455
u7370:
	line	327
	
l5453:	
;main.c: 327: uart_send_string("[Linear Li ERR]");
	movlw	low(((STR_25)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5457
	line	329
	
l5455:	
;main.c: 328: else
;main.c: 329: uart_send_string("[ERR]");
	movlw	low(((STR_26)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	330
	
l5457:	
;main.c: 330: if(g_slotRefV[i] > 0U)
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	((??_Print_SystemStatus+0)+0),w
iorwf	((??_Print_SystemStatus+0)+1),w
	btfsc	status,2
	goto	u7381
	goto	u7380
u7381:
	goto	l5475
u7380:
	line	332
	
l5459:	
;main.c: 331: {
;main.c: 332: uart_send_string(" ref=");
	movlw	low(((STR_27)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5427
	line	337
	
l5463:	
	movlw	low(((STR_28)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5475
	line	339
	
l5465:	
;main.c: 339: uart_send_string("[DIO]");
	movlw	low(((STR_29)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	340
;main.c: 340: uart_send_string(" pre=");
	movlw	low(((STR_30)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	341
	
l5467:	
;main.c: 341: uart_send_number(g_impData & 0x0FFFU);
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(uart_send_number@num)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(uart_send_number@num)
	fcall	_uart_send_number
	line	342
;main.c: 342: break;
	goto	l5475
	line	343
	
l5469:	
	movlw	low(((STR_31)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5475
	line	303
	
l5473:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@s),w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l5419
	xorlw	1^0	; case 1
	skipnz
	goto	l5421
	xorlw	2^1	; case 2
	skipnz
	goto	l5429
	xorlw	3^2	; case 3
	skipnz
	goto	l5431
	xorlw	4^3	; case 4
	skipnz
	goto	l5433
	xorlw	5^4	; case 5
	skipnz
	goto	l5435
	xorlw	6^5	; case 6
	skipnz
	goto	l5437
	xorlw	7^6	; case 7
	skipnz
	goto	l5439
	xorlw	8^7	; case 8
	skipnz
	goto	l5463
	xorlw	9^8	; case 9
	skipnz
	goto	l5465
	goto	l5469
	opt asmopt_pop

	line	347
	
l5475:	
;main.c: 347: uart_send_string(" ct=");
	movlw	low(((STR_32)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	348
	
l5477:	
;main.c: 348: uart_send_number(g_slot[(unsigned char)(i)].chargeTimer);
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	349
	
l5479:	
;main.c: 349: uart_send_string(" ty=");
	movlw	low(((STR_33)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	350
;main.c: 350: uart_send_number(g_slot[(unsigned char)(i)].type);
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	353
	
l5481:	
;main.c: 353: if(g_diodeTraceCnt > 0U && g_diodeTraceSlot == i)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_g_diodeTraceCnt)),w
	btfsc	status,2
	goto	u7391
	goto	u7390
u7391:
	goto	l5517
u7390:
	
l5483:	
	movf	(_g_diodeTraceSlot),w
	xorwf	(Print_SystemStatus@i),w
	skipz
	goto	u7401
	goto	u7400
u7401:
	goto	l5517
u7400:
	line	356
	
l5485:	
;main.c: 354: {
;main.c: 355: unsigned char tc;
;main.c: 356: uart_send_string(" tr=");
	movlw	low(((STR_34)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_34)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	357
	
l5487:	
;main.c: 357: for(tc = 0; tc < g_diodeTraceCnt; tc++)
	clrf	(Print_SystemStatus@tc)
	goto	l5511
	line	359
	
l5489:	
;main.c: 358: {
;main.c: 359: signed int d = (signed int)g_diodeTrace[tc] - 128;
	movf	(Print_SystemStatus@tc),w
	addlw	low(_g_diodeTrace|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	movwf	(Print_SystemStatus@d)
	clrf	(Print_SystemStatus@d+1)
	
l5491:	
	movlw	-128
	addwf	(Print_SystemStatus@d),f
	skipc
	decf	(Print_SystemStatus@d+1),f
	line	360
	
l5493:	
;main.c: 360: if(d < 0)
	btfss	(Print_SystemStatus@d+1),7
	goto	u7411
	goto	u7410
u7411:
	goto	l5499
u7410:
	line	362
	
l5495:	
;main.c: 361: {
;main.c: 362: uart_send_char('-');
	movlw	low(02Dh)
	fcall	_uart_send_char
	line	363
	
l5497:	
;main.c: 363: d = -d;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	comf	(Print_SystemStatus@d),f
	comf	(Print_SystemStatus@d+1),f
	incf	(Print_SystemStatus@d),f
	skipnz
	incf	(Print_SystemStatus@d+1),f
	line	364
;main.c: 364: }
	goto	l5503
	line	365
	
l5499:	
;main.c: 365: else if(d > 0)
	movf	(Print_SystemStatus@d+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u7425
	movlw	01h
	subwf	(Print_SystemStatus@d),w
u7425:

	skipc
	goto	u7421
	goto	u7420
u7421:
	goto	l5503
u7420:
	line	366
	
l5501:	
;main.c: 366: uart_send_char('+');
	movlw	low(02Bh)
	fcall	_uart_send_char
	line	367
	
l5503:	
;main.c: 367: uart_send_number((unsigned int)d * 4U);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@d+1),w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	(Print_SystemStatus@d),w
	movwf	(??_Print_SystemStatus+0)+0
	clrc
	rlf	(??_Print_SystemStatus+0)+0,f
	rlf	(??_Print_SystemStatus+0)+1,f
	clrc
	rlf	(??_Print_SystemStatus+0)+0,f
	rlf	(??_Print_SystemStatus+0)+1,f
	movf	0+(??_Print_SystemStatus+0)+0,w
	movwf	(uart_send_number@num)
	movf	1+(??_Print_SystemStatus+0)+0,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	368
	
l5505:	
;main.c: 368: if(tc + 1U < g_diodeTraceCnt)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_diodeTraceCnt),w
	movwf	(??_Print_SystemStatus+0)+0
	clrf	(??_Print_SystemStatus+0)+0+1
	movf	(Print_SystemStatus@tc),w
	addlw	low(01h)
	movwf	(??_Print_SystemStatus+2)+0
	movlw	high(01h)
	skipnc
	movlw	(high(01h)+1)&0ffh
	movwf	((??_Print_SystemStatus+2)+0)+1
	movf	1+(??_Print_SystemStatus+0)+0,w
	subwf	1+(??_Print_SystemStatus+2)+0,w
	skipz
	goto	u7435
	movf	0+(??_Print_SystemStatus+0)+0,w
	subwf	0+(??_Print_SystemStatus+2)+0,w
u7435:
	skipnc
	goto	u7431
	goto	u7430
u7431:
	goto	l5509
u7430:
	line	369
	
l5507:	
;main.c: 369: uart_send_char(',');
	movlw	low(02Ch)
	fcall	_uart_send_char
	line	357
	
l5509:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Print_SystemStatus@tc),f
	
l5511:	
	movf	(_g_diodeTraceCnt),w
	subwf	(Print_SystemStatus@tc),w
	skipc
	goto	u7441
	goto	u7440
u7441:
	goto	l5489
u7440:
	line	371
	
l5513:	
;main.c: 370: }
;main.c: 371: g_diodeTraceCnt = 0;
	clrf	(_g_diodeTraceCnt)
	line	372
	
l5515:	
;main.c: 372: g_diodeTraceSlot = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_diodeTraceSlot)
	line	376
	
l5517:	
;main.c: 373: }
;main.c: 376: uart_send_string("\r\n");
	movlw	low(((STR_35)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_35)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	269
	
l5519:	
	incf	(Print_SystemStatus@i),f
	
l5521:	
	movlw	low(0Ch)
	subwf	(Print_SystemStatus@i),w
	skipc
	goto	u7451
	goto	u7450
u7451:
	goto	l5389
u7450:
	line	379
	
l5523:	
;main.c: 378: }
;main.c: 379: uart_send_string("\r\n");
	movlw	low(((STR_36)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_36)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	380
	
l401:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    2[COMMON] unsigned long 
;;  multiplicand    4    6[COMMON] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    0[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    2[COMMON] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/100
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         8       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       4       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext12
__ptext12:	;psect for function ___lmul
psect	text12
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l5101:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l888:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u7021
	goto	u7020
u7021:
	goto	l5105
u7020:
	line	122
	
l5103:	
	movf	(___lmul@multiplicand),w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7031
	addwf	(___lmul@product+1),f
u7031:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7032
	addwf	(___lmul@product+2),f
u7032:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7033
	addwf	(___lmul@product+3),f
u7033:

	line	123
	
l5105:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l5107:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u7041
	goto	u7040
u7041:
	goto	l888
u7040:
	line	128
	
l5109:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l891:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    4[BANK0 ] unsigned long 
;;  dividend        4    8[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   12[BANK0 ] unsigned long 
;;  counter         1   16[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    4[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      13       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Slot_Charge_Ctrl
;;		_Get_Vcc
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext13
__ptext13:	;psect for function ___lldiv
psect	text13
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 4
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l5113:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l5115:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u7051
	goto	u7050
u7051:
	goto	l5135
u7050:
	line	16
	
l5117:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l5121
	line	18
	
l5119:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l5121:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u7061
	goto	u7060
u7061:
	goto	l5119
u7060:
	line	22
	
l5123:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l5125:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u7075
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u7075
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u7075
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u7075:
	skipc
	goto	u7071
	goto	u7070
u7071:
	goto	l5131
u7070:
	line	24
	
l5127:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l5129:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l5131:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l5133:	
	decfsz	(___lldiv@counter),f
	goto	u7081
	goto	u7080
u7081:
	goto	l5123
u7080:
	line	30
	
l5135:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l1163:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    2[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    1[BANK0 ] unsigned char 
;;  j               1    0[BANK0 ] unsigned char 
;;  adsum           4    3[BANK0 ] volatile unsigned long 
;;  ad_temp         2   11[BANK0 ] volatile unsigned int 
;;  admax           2    9[BANK0 ] volatile unsigned int 
;;  admin           2    7[BANK0 ] volatile unsigned int 
;;  i               1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      13       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Get_Vcc
;;		_Adc_Norm
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext14
__ptext14:	;psect for function _ADC_Sample
psect	text14
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(ADC_Sample@adch)
	line	51
	
l5011:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	52
	
l5013:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	58
	
l5015:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u6851
	goto	u6850
u6851:
	goto	l5021
u6850:
	
l5017:	
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u6861
	goto	u6860
u6861:
	goto	l5021
u6860:
	line	60
	
l5019:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??_ADC_Sample+0)+0),f
	u10177:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u10177
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	l5023
	line	64
	
l5021:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	67
	
l5023:	
;adc_drv.c: 67: if(adch & 0x10)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(ADC_Sample@adch),(4)&7
	goto	u6871
	goto	u6870
u6871:
	goto	l425
u6870:
	line	69
	
l5025:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l5027:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(ADC_Sample@adch),f
	line	71
;adc_drv.c: 71: }
	goto	l5029
	line	72
	
l425:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l5029:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@i)
	line	79
	
l5035:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(ADC_Sample@adch),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u6885:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u6885
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l5037:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	6
movwf	((??_ADC_Sample+0)+0),f
	u10187:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u10187
	nop
opt asmopt_pop

	line	81
	
l5039:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l5041:	
;adc_drv.c: 84: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	l429
	
l430:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u6891
	goto	u6890
u6891:
	goto	l429
u6890:
	line	89
	
l5043:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	l432
	line	90
	
l429:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u6901
	goto	u6900
u6901:
	goto	l430
u6900:
	line	93
	
l5047:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
l5049:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
l5051:	
;adc_drv.c: 96: if(0 == admax)
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u6911
	goto	u6910
u6911:
	goto	l5055
u6910:
	line	98
	
l5053:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	100
;adc_drv.c: 100: }
	goto	l435
	line	102
	
l5055:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u6925
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u6925:
	skipnc
	goto	u6921
	goto	u6920
u6921:
	goto	l5059
u6920:
	line	103
	
l5057:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	l435
	line	105
	
l5059:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u6935
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u6935:
	skipnc
	goto	u6931
	goto	u6930
u6931:
	goto	l435
u6930:
	line	106
	
l5061:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	108
	
l435:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u6941
	addwf	(ADC_Sample@adsum+1),f	;volatile
u6941:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u6942
	addwf	(ADC_Sample@adsum+2),f	;volatile
u6942:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u6943
	addwf	(ADC_Sample@adsum+3),f	;volatile
u6943:

	line	76
	
l5063:	
	incf	(ADC_Sample@i),f
	
l5065:	
	movlw	low(022h)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u6951
	goto	u6950
u6951:
	goto	l5035
u6950:
	line	112
	
l5067:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u6965
	goto	u6966
u6965:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u6966:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u6967
	goto	u6968
u6967:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u6968:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u6969
	goto	u6960
u6969:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u6960:

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u6975
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u6975
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u6975
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u6975:
	skipc
	goto	u6971
	goto	u6970
u6971:
	goto	l439
u6970:
	line	114
	
l5069:	
;adc_drv.c: 114: adsum -= admin;
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u6985
	goto	u6986
u6985:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u6986:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u6987
	goto	u6988
u6987:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u6988:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u6989
	goto	u6980
u6989:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u6980:

	goto	l5071
	line	115
	
l439:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	118
	
l5071:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u6995:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u6990:
	addlw	-1
	skipz
	goto	u6995
	movf	1+(??_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
l5073:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
l432:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 214 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	214
global __ptext15
__ptext15:	;psect for function _Print_NtcTemp
psect	text15
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	214
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 3
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	216
	
l5331:	
;main.c: 216: uart_send_string("NTC=");
	movlw	low(((STR_1)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	217
	
l5333:	
;main.c: 217: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$705+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$705)
	
l5335:	
;main.c: 217: uart_send_number(g_temperature / 10U);
	movf	(_Print_NtcTemp$705+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$705),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	218
	
l5337:	
;main.c: 218: uart_send_string(".");
	movlw	low(((STR_2)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	219
	
l5339:	
;main.c: 219: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	movwf	(_Print_NtcTemp$706+1)
	movf	(0+(?___lwmod)),w
	movwf	(_Print_NtcTemp$706)
;main.c: 219: uart_send_number(g_temperature % 10U);
	movf	(_Print_NtcTemp$706+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$706),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	220
	
l5341:	
;main.c: 220: uart_send_string("C\r\n");
	movlw	low(((STR_3)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	221
	
l357:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2    5[COMMON] PTR const unsigned char 
;;		 -> STR_38(10), STR_37(21), STR_36(3), STR_35(3), 
;;		 -> STR_34(5), STR_33(5), STR_32(5), STR_31(6), 
;;		 -> STR_30(6), STR_29(6), STR_28(6), STR_27(6), 
;;		 -> STR_26(6), STR_25(16), STR_24(13), STR_23(15), 
;;		 -> STR_22(7), STR_21(5), STR_20(5), STR_19(6), 
;;		 -> STR_18(6), STR_17(6), STR_16(6), STR_15(7), 
;;		 -> STR_14(4), STR_13(6), STR_12(6), STR_11(3), 
;;		 -> STR_10(12), STR_9(2), STR_8(6), STR_7(5), 
;;		 -> STR_6(6), STR_5(5), STR_4(25), STR_3(4), 
;;		 -> STR_2(2), STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         2       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_main
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
global __ptext16
__ptext16:	;psect for function _uart_send_string
psect	text16
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 4
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l5185:	
;uart_dbg.c: 63: while(*str != '\0')
	goto	l5191
	line	65
	
l5187:	
;uart_dbg.c: 64: {
;uart_dbg.c: 65: uart_send_char(*str++);
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	fcall	_uart_send_char
	
l5189:	
	incf	(uart_send_string@str),f
	skipnz
	incf	(uart_send_string@str+1),f
	line	66
# 66 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
clrwdt ;# 
psect	text16
	line	63
	
l5191:	
	movf	(uart_send_string@str+1),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u7171
	goto	u7170
u7171:
	goto	l5187
u7170:
	line	68
	
l456:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2    0[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    2[BANK0 ] unsigned char [6]
;;  j               1    9[BANK0 ] unsigned char 
;;  i               1    8[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      10       0       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext17
__ptext17:	;psect for function _uart_send_number
psect	text17
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l5193:	
;uart_dbg.c: 79: unsigned char buf[6];
;uart_dbg.c: 80: unsigned char i = 0;
	clrf	(uart_send_number@i)
	line	84
	
l5195:	
;uart_dbg.c: 81: unsigned char j;
;uart_dbg.c: 84: if(num == 0)
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u7181
	goto	u7180
u7181:
	goto	l5207
u7180:
	line	86
	
l5197:	
;uart_dbg.c: 85: {
;uart_dbg.c: 86: uart_send_char('0');
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l460
	line	93
	
l5201:	
;uart_dbg.c: 92: {
;uart_dbg.c: 93: buf[i++] = '0' + (num % 10);
	movf	(uart_send_number@i),w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwmod@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank0
	movwf	indf
	
l5203:	
	incf	(uart_send_number@i),f
	line	94
	
l5205:	
;uart_dbg.c: 94: num /= 10;
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(uart_send_number@num+1)
	movf	(0+(?___lwdiv)),w
	movwf	(uart_send_number@num)
	line	91
	
l5207:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u7191
	goto	u7190
u7191:
	goto	l5201
u7190:
	line	98
	
l5209:	
;uart_dbg.c: 95: }
;uart_dbg.c: 98: for(j = i; j > 0; j--)
	movf	(uart_send_number@i),w
	movwf	(uart_send_number@j)
	
l5211:	
	movf	((uart_send_number@j)),w
	btfss	status,2
	goto	u7201
	goto	u7200
u7201:
	goto	l5215
u7200:
	goto	l460
	line	99
	
l5215:	
;uart_dbg.c: 99: uart_send_char(buf[(unsigned char)(j - 1)]);
	movf	(uart_send_number@j),w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l5217:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decf	(uart_send_number@j),f
	goto	l5211
	line	100
	
l460:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1    3[COMMON] unsigned char 
;;  i               1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          1       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext18
__ptext18:	;psect for function _uart_send_char
psect	text18
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 4
; Regs used in _uart_send_char: [wreg+status,2+status,0]
;uart_send_char@c stored from wreg
	movwf	(uart_send_char@c)
	line	38
	
l5077:	
;uart_dbg.c: 37: unsigned char i;
;uart_dbg.c: 38: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	39
;uart_dbg.c: 39: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l5079:	
;uart_dbg.c: 40: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u10197:
decfsz	(??_uart_send_char+0)+0,f
	goto	u10197
	nop
opt asmopt_pop

	line	41
	
l5081:	
;uart_dbg.c: 41: for(i = 0; i < 8; i++)
	clrf	(uart_send_char@i)
	line	42
	
l446:	
	line	43
;uart_dbg.c: 42: {
;uart_dbg.c: 43: if(c & 0x01)
	btfss	(uart_send_char@c),(0)&7
	goto	u7001
	goto	u7000
u7001:
	goto	l448
u7000:
	line	44
	
l5087:	
;uart_dbg.c: 44: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l5089
	line	45
	
l448:	
	line	46
;uart_dbg.c: 45: else
;uart_dbg.c: 46: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l5089:	
;uart_dbg.c: 47: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u10207:
decfsz	(??_uart_send_char+0)+0,f
	goto	u10207
	nop
opt asmopt_pop

	line	48
	
l5091:	
;uart_dbg.c: 48: c >>= 1;
	clrc
	rrf	(uart_send_char@c),f
	line	41
	
l5093:	
	incf	(uart_send_char@i),f
	
l5095:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u7011
	goto	u7010
u7011:
	goto	l446
u7010:
	
l447:	
	line	50
;uart_dbg.c: 49: }
;uart_dbg.c: 50: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l5097:	
;uart_dbg.c: 51: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u10217:
decfsz	(??_uart_send_char+0)+0,f
	goto	u10217
	nop
opt asmopt_pop

	line	52
	
l5099:	
;uart_dbg.c: 52: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l450:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] unsigned int 
;;  dividend        2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext19
__ptext19:	;psect for function ___lwmod
psect	text19
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l5165:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u7131
	goto	u7130
u7131:
	goto	l5181
u7130:
	line	14
	
l5167:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l5171
	line	16
	
l5169:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l5171:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u7141
	goto	u7140
u7141:
	goto	l5169
u7140:
	line	20
	
l5173:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u7155
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u7155:
	skipc
	goto	u7151
	goto	u7150
u7151:
	goto	l5177
u7150:
	line	21
	
l5175:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l5177:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l5179:	
	decfsz	(___lwmod@counter),f
	goto	u7161
	goto	u7160
u7161:
	goto	l5173
u7160:
	line	25
	
l5181:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1226:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] unsigned int 
;;  dividend        2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    7[COMMON] unsigned int 
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         3       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         7       0       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_Slot_Charge_Ctrl
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext20
__ptext20:	;psect for function ___lwdiv
psect	text20
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 4
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l5139:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l5141:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u7091
	goto	u7090
u7091:
	goto	l5161
u7090:
	line	16
	
l5143:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l5147
	line	18
	
l5145:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l5147:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u7101
	goto	u7100
u7101:
	goto	l5145
u7100:
	line	22
	
l5149:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l5151:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u7115
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u7115:
	skipc
	goto	u7111
	goto	u7110
u7111:
	goto	l5157
u7110:
	line	24
	
l5153:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l5155:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l5157:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l5159:	
	decfsz	(___lwdiv@counter),f
	goto	u7121
	goto	u7120
u7121:
	goto	l5149
u7120:
	line	30
	
l5161:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l1216:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 1256 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    8[BANK0 ] unsigned int 
;;  s               1   19[BANK0 ] unsigned char 
;;  duty            2   16[BANK0 ] int 
;;  error           2   12[BANK0 ] int 
;;  adjust          2    2[BANK0 ] int 
;;  duty_initial    1   15[BANK0 ] unsigned char 
;;  duty_target     1   14[BANK0 ] unsigned char 
;;  maxV            2   10[BANK0 ] unsigned int 
;;  i               1   18[BANK0 ] unsigned char 
;;  preCount        1    7[BANK0 ] unsigned char 
;;  ccCount         1    6[BANK0 ] unsigned char 
;;  cvCount         1    5[BANK0 ] unsigned char 
;;  hasCharging     1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          0       2       0       0       0
;;      Totals:         0      20       0       0       0
;;Total ram usage:       20 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___awdiv
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1256
global __ptext21
__ptext21:	;psect for function _CCCV_Control
psect	text21
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1256
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 4
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1259
	
l6485:	
;charge_mgr.c: 1258: unsigned char i;
;charge_mgr.c: 1259: unsigned char hasCharging = 0;
	clrf	(CCCV_Control@hasCharging)
	line	1260
;charge_mgr.c: 1260: unsigned int maxV = 0;
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	1261
;charge_mgr.c: 1261: unsigned char cvCount = 0;
	clrf	(CCCV_Control@cvCount)
	line	1262
;charge_mgr.c: 1262: unsigned char ccCount = 0;
	clrf	(CCCV_Control@ccCount)
	line	1263
;charge_mgr.c: 1263: unsigned char preCount = 0;
	clrf	(CCCV_Control@preCount)
	line	1266
	
l6487:	
;charge_mgr.c: 1266: if(g_vccProtect)
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u9631
	goto	u9630
u9631:
	goto	l6493
u9630:
	line	1268
	
l6489:	
;charge_mgr.c: 1267: {
;charge_mgr.c: 1268: if(g_vcc_mv >= 4600)
	movlw	011h
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_g_vcc_mv+1),w	;volatile
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv),w	;volatile
	skipc
	goto	u9641
	goto	u9640
u9641:
	goto	l6497
u9640:
	line	1269
	
l6491:	
;charge_mgr.c: 1269: g_vccProtect = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_vccProtect)^080h
	goto	l6497
	line	1273
	
l6493:	
;charge_mgr.c: 1271: else
;charge_mgr.c: 1272: {
;charge_mgr.c: 1273: if(g_vcc_mv < 4400)
	movlw	011h
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_g_vcc_mv+1),w	;volatile
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv),w	;volatile
	skipnc
	goto	u9651
	goto	u9650
u9651:
	goto	l6497
u9650:
	line	1274
	
l6495:	
;charge_mgr.c: 1274: g_vccProtect = 1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_vccProtect)^080h
	incf	(_g_vccProtect)^080h,f
	line	1278
	
l6497:	
;charge_mgr.c: 1275: }
;charge_mgr.c: 1278: if(g_tempProtect || g_vccProtect)
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u9661
	goto	u9660
u9661:
	goto	l6501
u9660:
	
l6499:	
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u9671
	goto	u9670
u9671:
	goto	l6505
u9670:
	line	1280
	
l6501:	
;charge_mgr.c: 1279: {
;charge_mgr.c: 1280: g_pwmDuty = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	1281
;charge_mgr.c: 1281: g_cvIntegral = 0;
	clrf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	l819
	line	1286
	
l6505:	
;charge_mgr.c: 1283: }
;charge_mgr.c: 1286: for(i = 0; i < 12; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(CCCV_Control@i)
	line	1288
	
l6511:	
;charge_mgr.c: 1287: {
;charge_mgr.c: 1288: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	1292
	
l6513:	
;charge_mgr.c: 1290: if(s == 2 || s == 3 ||
;charge_mgr.c: 1291: s == 4 || s == 5 ||
;charge_mgr.c: 1292: s == 8)
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9681
	goto	u9680
u9681:
	goto	l824
u9680:
	
l6515:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9691
	goto	u9690
u9691:
	goto	l824
u9690:
	
l6517:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9701
	goto	u9700
u9701:
	goto	l824
u9700:
	
l6519:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9711
	goto	u9710
u9711:
	goto	l824
u9710:
	
l6521:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9721
	goto	u9720
u9721:
	goto	l822
u9720:
	
l824:	
	line	1294
;charge_mgr.c: 1293: {
;charge_mgr.c: 1294: hasCharging = 1;
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	1296
	
l6523:	
;charge_mgr.c: 1295: {
;charge_mgr.c: 1296: unsigned int vt = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	1297
	
l6525:	
;charge_mgr.c: 1297: if(vt > maxV) maxV = vt;
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u9735
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u9735:
	skipnc
	goto	u9731
	goto	u9730
u9731:
	goto	l6529
u9730:
	
l6527:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	1299
	
l6529:	
;charge_mgr.c: 1298: }
;charge_mgr.c: 1299: if(s == 5)
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9741
	goto	u9740
u9741:
	goto	l6533
u9740:
	line	1300
	
l6531:	
;charge_mgr.c: 1300: cvCount++;
	incf	(CCCV_Control@cvCount),f
	line	1301
	
l6533:	
;charge_mgr.c: 1301: if(s == 4)
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9751
	goto	u9750
u9751:
	goto	l6537
u9750:
	line	1302
	
l6535:	
;charge_mgr.c: 1302: ccCount++;
	incf	(CCCV_Control@ccCount),f
	line	1303
	
l6537:	
;charge_mgr.c: 1303: if(s == 3 || s == 2)
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9761
	goto	u9760
u9761:
	goto	l6541
u9760:
	
l6539:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9771
	goto	u9770
u9771:
	goto	l822
u9770:
	line	1304
	
l6541:	
;charge_mgr.c: 1304: preCount++;
	incf	(CCCV_Control@preCount),f
	line	1305
	
l822:	
	line	1286
	incf	(CCCV_Control@i),f
	
l6543:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u9781
	goto	u9780
u9781:
	goto	l6511
u9780:
	line	1309
	
l6545:	
;charge_mgr.c: 1305: }
;charge_mgr.c: 1306: }
;charge_mgr.c: 1309: if(!hasCharging)
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u9791
	goto	u9790
u9791:
	goto	l6551
u9790:
	goto	l6501
	line	1320
	
l6551:	
;charge_mgr.c: 1314: }
;charge_mgr.c: 1320: if(cvCount == 0)
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u9801
	goto	u9800
u9801:
	goto	l6581
u9800:
	line	1324
	
l6553:	
;charge_mgr.c: 1321: {
;charge_mgr.c: 1322: unsigned char duty_target, duty_initial;
;charge_mgr.c: 1324: if(ccCount > 0)
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u9811
	goto	u9810
u9811:
	goto	l6557
u9810:
	line	1327
	
l6555:	
;charge_mgr.c: 1325: {
;charge_mgr.c: 1327: duty_target = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	1328
;charge_mgr.c: 1328: duty_initial = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	1329
;charge_mgr.c: 1329: }
	goto	l6565
	line	1330
	
l6557:	
;charge_mgr.c: 1330: else if(preCount > 0)
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u9821
	goto	u9820
u9821:
	goto	l6561
u9820:
	line	1333
	
l6559:	
;charge_mgr.c: 1331: {
;charge_mgr.c: 1333: duty_target = 8;
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	1334
;charge_mgr.c: 1334: duty_initial = 5;
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	1335
;charge_mgr.c: 1335: }
	goto	l6565
	line	1340
	
l6561:	
;charge_mgr.c: 1336: else
;charge_mgr.c: 1337: {
;charge_mgr.c: 1340: g_pwmDuty = 25;
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	l819
	line	1344
	
l6565:	
;charge_mgr.c: 1342: }
;charge_mgr.c: 1344: if(g_pwmDuty < duty_initial)
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u9831
	goto	u9830
u9831:
	goto	l6573
u9830:
	line	1347
	
l6567:	
;charge_mgr.c: 1345: {
;charge_mgr.c: 1347: g_pwmDuty += 3;
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	1348
	
l6569:	
;charge_mgr.c: 1348: if(g_pwmDuty > duty_initial)
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u9841
	goto	u9840
u9841:
	goto	l819
u9840:
	line	1349
	
l6571:	
;charge_mgr.c: 1349: g_pwmDuty = duty_initial;
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	l819
	line	1351
	
l6573:	
	line	1354
	
l6575:	
;charge_mgr.c: 1352: {
;charge_mgr.c: 1354: g_pwmDuty = duty_target;
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	1355
;charge_mgr.c: 1355: }
	goto	l819
	line	1370
	
l6581:	
;charge_mgr.c: 1362: }
;charge_mgr.c: 1369: {
;charge_mgr.c: 1370: int error = (int)(3100) - (int)(maxV);
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	1373
;charge_mgr.c: 1373: g_cvIntegral += error * 1;
	movf	(CCCV_Control@error),w
	addwf	(_g_cvIntegral),f
	skipnc
	incf	(_g_cvIntegral+1),f
	movf	(CCCV_Control@error+1),w
	addwf	(_g_cvIntegral+1),f
	line	1374
	
l6583:	
;charge_mgr.c: 1374: if(g_cvIntegral > 200)
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u9855
	movlw	0C9h
	subwf	(_g_cvIntegral),w
u9855:

	skipc
	goto	u9851
	goto	u9850
u9851:
	goto	l6587
u9850:
	line	1375
	
l6585:	
;charge_mgr.c: 1375: g_cvIntegral = 200;
	movlw	0C8h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	l6591
	line	1376
	
l6587:	
;charge_mgr.c: 1376: else if(g_cvIntegral < -200)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u9865
	movlw	038h
	subwf	(_g_cvIntegral),w
u9865:

	skipnc
	goto	u9861
	goto	u9860
u9861:
	goto	l6591
u9860:
	line	1377
	
l6589:	
;charge_mgr.c: 1377: g_cvIntegral = -200;
	movlw	038h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	movlw	0FFh
	movwf	((_g_cvIntegral))+1
	line	1380
	
l6591:	
;charge_mgr.c: 1380: int adjust = (error * 4 + g_cvIntegral) / 8;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	movf	(_g_cvIntegral),w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1),w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	1381
	
l6593:	
;charge_mgr.c: 1381: int duty = (int)g_pwmDuty + adjust;
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
l6595:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	1384
	
l6597:	
;charge_mgr.c: 1384: if(duty > 32) duty = 32;
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u9875
	movlw	021h
	subwf	(CCCV_Control@duty),w
u9875:

	skipc
	goto	u9871
	goto	u9870
u9871:
	goto	l6601
u9870:
	
l6599:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1385
	
l6601:	
;charge_mgr.c: 1385: if(duty < 0) duty = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u9881
	goto	u9880
u9881:
	goto	l6605
u9880:
	
l6603:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1387
	
l6605:	
;charge_mgr.c: 1387: g_pwmDuty = (unsigned char)duty;
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	1389
	
l819:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    2[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    4[COMMON] unsigned char 
;;  product         1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Print_SystemStatus
;;		_Slot_Charge_Ctrl
;;		_CCCV_Control
;;		_Update_LED_Global
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext22
__ptext22:	;psect for function ___bmul
psect	text22
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	movwf	(___bmul@multiplier)
	line	6
	
l5247:	
	clrf	(___bmul@product)
	line	43
	
l5249:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u7241
	goto	u7240
u7241:
	goto	l5253
u7240:
	line	44
	
l5251:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l5253:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l5255:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u7251
	goto	u7250
u7251:
	goto	l5249
u7250:
	line	50
	
l5257:	
	movf	(___bmul@product),w
	line	51
	
l897:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] int 
;;  dividend        2    4[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    8[COMMON] int 
;;  sign            1    7[COMMON] unsigned char 
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext23
__ptext23:	;psect for function ___awdiv
psect	text23
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 4
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
l3429:	
	clrf	(___awdiv@sign)
	line	15
	
l3431:	
	btfss	(___awdiv@divisor+1),7
	goto	u3771
	goto	u3770
u3771:
	goto	l3437
u3770:
	line	16
	
l3433:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
l3435:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
l3437:	
	btfss	(___awdiv@dividend+1),7
	goto	u3781
	goto	u3780
u3781:
	goto	l3443
u3780:
	line	20
	
l3439:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
l3441:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
l3443:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
l3445:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u3791
	goto	u3790
u3791:
	goto	l3465
u3790:
	line	25
	
l3447:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	l3451
	line	27
	
l3449:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
l3451:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u3801
	goto	u3800
u3801:
	goto	l3449
u3800:
	line	31
	
l3453:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
l3455:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u3815
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u3815:
	skipc
	goto	u3811
	goto	u3810
u3811:
	goto	l3461
u3810:
	line	33
	
l3457:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
l3459:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
l3461:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
l3463:	
	decfsz	(___awdiv@counter),f
	goto	u3821
	goto	u3820
u3821:
	goto	l3453
u3820:
	line	39
	
l3465:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u3831
	goto	u3830
u3831:
	goto	l3469
u3830:
	line	40
	
l3467:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
l3469:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
l1009:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 150 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		_PowerOnLedSequence
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	150
global __ptext24
__ptext24:	;psect for function _Isr_Timer
psect	text24
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	150
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 3
; Regs used in _Isr_Timer: [wreg+status,2+status,0+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Isr_Timer+0)
	movf	pclath,w
	movwf	(??_Isr_Timer+1)
	ljmp	_Isr_Timer
psect	text24
	line	153
	
i1l4923:	
;main.c: 153: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u673_21
	goto	u673_20
u673_21:
	goto	i1l349
u673_20:
	line	155
	
i1l4925:	
;main.c: 154: {
;main.c: 155: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	156
	
i1l4927:	
;main.c: 156: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(129)^080h	;volatile
	line	157
# 157 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text24
	line	160
	
i1l4929:	
;main.c: 160: g_pwmCounter++;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	161
	
i1l4931:	
;main.c: 161: if(g_pwmCounter >= 32)
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u674_21
	goto	u674_20
u674_21:
	goto	i1l4935
u674_20:
	line	162
	
i1l4933:	
;main.c: 162: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	164
	
i1l4935:	
;main.c: 164: if(g_pwmDuty > 0 && g_pwmCounter < g_pwmDuty)
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u675_21
	goto	u675_20
u675_21:
	goto	i1l346
u675_20:
	
i1l4937:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u676_21
	goto	u676_20
u676_21:
	goto	i1l346
u676_20:
	line	165
	
i1l4939:	
;main.c: 165: RB7 = 1;
	bsf	(55/8),(55)&7	;volatile
	goto	i1l4941
	line	166
	
i1l346:	
	line	167
;main.c: 166: else
;main.c: 167: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	170
	
i1l4941:	
;main.c: 170: if(g_powerOnPhase < 2)
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u677_21
	goto	u677_20
u677_21:
	goto	i1l4947
u677_20:
	line	172
	
i1l4943:	
;main.c: 171: {
;main.c: 172: PowerOnLedSequence();
	fcall	_PowerOnLedSequence
	goto	i1l349
	line	177
	
i1l4947:	
;main.c: 174: }
;main.c: 177: if(g_tempPhase == 0)
	movf	((_g_tempPhase)),w	;volatile
	btfss	status,2
	goto	u678_21
	goto	u678_20
u678_21:
	goto	i1l4959
u678_20:
	line	179
	
i1l4949:	
;main.c: 178: {
;main.c: 179: g_tempReadRoundCnt++;
	incf	(_g_tempReadRoundCnt),f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1),f	;volatile
	line	180
	
i1l4951:	
;main.c: 180: if(g_tempReadRoundCnt >= 200)
	movlw	0
	subwf	(_g_tempReadRoundCnt+1),w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt),w	;volatile
	skipc
	goto	u679_21
	goto	u679_20
u679_21:
	goto	i1l4967
u679_20:
	line	182
	
i1l4953:	
;main.c: 181: {
;main.c: 182: g_tempReadRoundCnt = 0;
	clrf	(_g_tempReadRoundCnt)	;volatile
	clrf	(_g_tempReadRoundCnt+1)	;volatile
	line	183
	
i1l4955:	
;main.c: 183: g_tempPhase = 1;
	movlw	low(01h)
	movwf	(_g_tempPhase)	;volatile
	line	184
	
i1l4957:	
;main.c: 184: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)	;volatile
	clrf	(_g_tempSettleCnt+1)	;volatile
	goto	i1l4967
	line	189
	
i1l4959:	
;main.c: 187: else
;main.c: 188: {
;main.c: 189: g_tempSettleCnt++;
	incf	(_g_tempSettleCnt),f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1),f	;volatile
	line	190
	
i1l4961:	
;main.c: 190: if(g_tempSettleCnt >= 60)
	movlw	0
	subwf	(_g_tempSettleCnt+1),w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt),w	;volatile
	skipc
	goto	u680_21
	goto	u680_20
u680_21:
	goto	i1l4967
u680_20:
	line	192
	
i1l4963:	
;main.c: 191: {
;main.c: 192: g_doNtcRead = 1;
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	193
	
i1l4965:	
;main.c: 193: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)	;volatile
	clrf	(_g_tempSettleCnt+1)	;volatile
	line	194
;main.c: 194: g_tempPhase = 0;
	clrf	(_g_tempPhase)	;volatile
	line	200
	
i1l4967:	
;main.c: 195: }
;main.c: 196: }
;main.c: 200: if(++g_printTick >= 100)
	incf	(_g_printTick),f	;volatile
	skipnz
	incf	(_g_printTick+1),f	;volatile
	movlw	0
	subwf	((_g_printTick+1)),w	;volatile
	movlw	064h
	skipnz
	subwf	((_g_printTick)),w	;volatile
	skipc
	goto	u681_21
	goto	u681_20
u681_21:
	goto	i1l349
u681_20:
	line	202
	
i1l4969:	
;main.c: 201: {
;main.c: 202: g_printTick = 0;
	clrf	(_g_printTick)	;volatile
	clrf	(_g_printTick+1)	;volatile
	line	203
	
i1l4971:	
;main.c: 203: g_printFlag = 1;
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	207
	
i1l349:	
	movf	(??_Isr_Timer+1),w
	movwf	pclath
	swapf	(??_Isr_Timer+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 80 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	80
global __ptext25
__ptext25:	;psect for function _PowerOnLedSequence
psect	text25
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	80
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	82
	
i1l3543:	
;led.c: 82: g_powerOnTimer++;
	incf	(_g_powerOnTimer),f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1),f	;volatile
	line	84
	
i1l3545:	
;led.c: 84: if(g_powerOnPhase == 0)
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u385_21
	goto	u385_20
u385_21:
	goto	i1l3555
u385_20:
	line	87
	
i1l3547:	
;led.c: 85: {
;led.c: 87: RC5 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	88
;led.c: 88: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	89
	
i1l3549:	
;led.c: 89: if(g_powerOnTimer >= 100)
	movlw	0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u386_21
	goto	u386_20
u386_21:
	goto	i1l873
u386_20:
	line	91
	
i1l3551:	
;led.c: 90: {
;led.c: 91: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	92
	
i1l3553:	
;led.c: 92: g_powerOnPhase = 1;
	movlw	low(01h)
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l873
	line	95
	
i1l3555:	
;led.c: 95: else if(g_powerOnPhase == 1)
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u387_21
	goto	u387_20
u387_21:
	goto	i1l873
u387_20:
	line	98
	
i1l3557:	
;led.c: 96: {
;led.c: 98: RC5 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	99
;led.c: 99: RC4 = 0;
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	100
	
i1l3559:	
;led.c: 100: if(g_powerOnTimer >= 100)
	movlw	0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u388_21
	goto	u388_20
u388_21:
	goto	i1l873
u388_20:
	line	102
	
i1l3561:	
;led.c: 101: {
;led.c: 102: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	103
	
i1l3563:	
;led.c: 103: g_powerOnPhase = 2;
	movlw	low(02h)
	movwf	(_g_powerOnPhase)	;volatile
	line	107
	
i1l873:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
