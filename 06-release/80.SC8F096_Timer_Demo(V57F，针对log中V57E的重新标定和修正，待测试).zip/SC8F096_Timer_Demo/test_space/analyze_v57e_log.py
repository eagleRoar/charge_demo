# -*- coding: utf-8 -*-
"""解析 V57E log.txt, 生成: 每测试每槽位状态轨迹 / 最终判定矩阵 / DIO特征提取"""
import re, sys, io

LOG = r"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\log.txt"

ACTUAL = {
    1:"碱性",2:"镍氢",3:"线性锂",4:"线性锂",5:"恒压锂",6:"线性锂",
    7:"镍氢",8:"线性锂",9:"恒压锂",10:"碳性",11:"碳性",12:"恒压锂",
}
# 期望: 可充(线性锂/恒压锂)->CHG, 不可充(碱性/镍氢/碳性)->REJ
EXPECT = {1:"REJ",2:"REJ",3:"CHG",4:"CHG",5:"CHG",6:"CHG",
          7:"REJ",8:"CHG",9:"CHG",10:"REJ",11:"REJ",12:"CHG"}
CHG_STATES = {"[CC]","[CV]","[FULL]"}
REJ_STATES = {"[Dry/NiMH ERR]","[Li-ion ERR]","[ERR]","[ERROR]"}

def parse(path):
    with io.open(path, "r", encoding="utf-8", errors="replace") as f:
        lines = f.readlines()
    # 分割测试段: 以 "N." 独立行开始
    tests = []   # list of list of lines
    cur = None
    actual_block = False
    for ln in lines:
        s = ln.strip()
        if not s:
            continue
        m = re.match(r"^(\d)\.\s*$", s)
        if m:
            cur = []
            tests.append(cur)
            continue
        if s.startswith("实际"):
            actual_block = True
            continue
        if actual_block:
            continue
        if cur is not None:
            cur.append(s)
    return tests

def parse_slot(line):
    """返回 (slot_no, v, state, ct, ty, extra) 或 None"""
    m = re.search(r"B(\d+)=(\d+)(.*?)\[(\w+[^]]*)\](.*)", line)
    if not m:
        return None
    slot = int(m.group(1)); v = int(m.group(2))
    rest = m.group(3)
    state = "[" + m.group(4) + "]"
    tail = m.group(5)
    ct = ty = None
    mc = re.search(r"ct=(\d+)", tail)
    mt = re.search(r"ty=(\d+)", tail)
    if mc: ct = int(mc.group(1))
    if mt: ty = int(mt.group(1))
    extra = {}
    mr = re.search(r"ref=(\d+)", tail)
    if mr: extra["ref"] = int(mr.group(1))
    mp = re.search(r"pre=(\d+)", tail)
    if mp: extra["pre"] = int(mp.group(1))
    mtr = re.search(r"tr=([+\-]?\d+(?:,[+\-]?\d+)*)", tail)
    if mtr: extra["tr"] = mtr.group(1)
    return slot, v, state, ct, ty, extra

def final_judge(seq_states):
    """取最后出现的非检测中间态状态"""
    for st in reversed(seq_states):
        if st.startswith("[DET]") or st.startswith("[DIO]") or st.startswith("[IMP]"):
            continue
        return st
    return seq_states[-1]

def main():
    tests = parse(LOG)
    out = []
    for ti, test in enumerate(tests, 1):
        # 每槽位状态序列
        seq = {i: [] for i in range(1, 13)}
        vcc = None
        for ln in test:
            mv = re.search(r"VCC=(\d+)mV", ln)
            if mv: vcc = int(mv.group(1))
            ps = parse_slot(ln)
            if ps:
                slot, v, state, ct, ty, extra = ps
                seq[slot].append((v, state, ct, ty, extra))
        # 打印该测试最终判定
        out.append("="*100)
        out.append("测试 %d  末帧VCC=%s mV" % (ti, vcc))
        out.append("%-4s %-6s %-5s %-6s %-30s %s" % ("槽","实际","期望","结果","最终状态","状态轨迹"))
        for slot in range(1, 13):
            sq = seq[slot]
            if not sq:
                out.append("B%-3d 无数据" % slot)
                continue
            v, state, ct, ty, extra = sq[-1]
            final = final_judge([s for (_, s, _, _, _) in sq])
            if final in CHG_STATES: res = "CHG"
            elif final in REJ_STATES: res = "REJ"
            else: res = "?"
            mark = "OK " if res == EXPECT[slot] else "BAD"
            traj = " | ".join("[%s]%s" % (s, "v%d" % vv) for (vv, s, _, _, _) in sq)
            out.append("B%-3d %-6s %-5s %-6s %-10s %s" % (slot, ACTUAL[slot], EXPECT[slot], res+mark, final, traj[:100]))
    # DIO 特征提取: 所有 [DIO] 行
    out.append("="*100)
    out.append("DIO 轨迹特征 (pre, 当前v, VCC, 判定后, tr偏移)")
    for ti, test in enumerate(tests, 1):
        for ln in test:
            ps = parse_slot(ln)
            if not ps: continue
            slot, v, state, ct, ty, extra = ps
            if state == "[DIO]":
                mv = re.search(r"VCC=(\d+)mV", " ".join(test[:test.index(ln)+1]))
                # 查找该行最近的前置VCC
                vcc = None
                for l2 in test:
                    mm = re.search(r"VCC=(\d+)mV", l2)
                    if mm: vcc = int(mm.group(1))
                    if l2 == ln: break
                pre = extra.get("pre")
                tr = extra.get("tr")
                out.append("T%d B%-3d v=%-5d pre=%-5d VCC=%-5d VCCn=%-5d diff=%-5s tr=%-24s ty=%s 实际=%s" % (
                    ti, slot, v, pre, vcc,
                    (vcc*4096//5000) if vcc else 0,
                    ("%+d"%(v-pre) if pre is not None else "?"),
                    tr, ty, ACTUAL[slot]))
    text = "\n".join(out)
    with io.open(r"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\test_space\v57e_log_analysis.txt", "w", encoding="utf-8") as f:
        f.write(text)
    print("DONE, lines=%d" % len(out))

if __name__ == "__main__":
    main()
