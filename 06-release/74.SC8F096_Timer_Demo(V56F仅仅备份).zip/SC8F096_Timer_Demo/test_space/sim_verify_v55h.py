#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
V55H 忠实状态机回放 (逐tick移植 charge_mgr.c V55H)
====================================================
输入 : test_space/log.txt (V54W 固件日志, 打印值为原始ADC, 无归一化)
输出 : 控制台 + test_space/sim_v55h_result.txt

方法:
  1. 解析每帧 VCC 与 12 槽原始 ADC。
  2. 正向归一化 fwd = min(4095, raw*VCC/5000)  (V55H Adc_Norm)
  3. 按 V55H 实际状态机逐 tick 回放: 每帧推进 ~100 tick(由日志ct增量实测),
     帧内每 tick 以该帧读数喂给 12 槽的 Slot_Charge_Ctrl 调度。
  4. 帧间隔>15s 视为断电重启(日志F12→F13), 所有槽重置为 IDLE 重新检测。

局限(与数据粒度一致): 帧内读数按保持采样处理, VCC跌落脉冲等帧内动态
无法从日志还原 → IMP_CHECK 的 VCC 跌落判据在该数据下基本不触发,
识别主要依赖 DIODE_TEST 爬升/钳位/超时判据, 结果偏保守。
"""

import re
import os
import sys
import datetime

# ---------------- config.h 常量 (V55H) ----------------
VCC_REF_MV = 5000
CHG_IDLE, CHG_DETECT, CHG_ACTIVATE, CHG_PRECHARGE = 0, 1, 2, 3
CHG_CC_CHARGE, CHG_CV_CHARGE, CHG_FULL, CHG_ERROR = 4, 5, 6, 7
CHG_IMP_CHECK, CHG_IMP_DIODE_TEST = 8, 9
ST_NAME = {0: "IDLE", 1: "DET", 2: "ACT", 3: "PRE", 4: "CC",
           5: "CV", 6: "FULL", 7: "ERR", 8: "IMP", 9: "DIO"}

BAT_UNKNOWN, BAT_LI_ION, BAT_NIMH, BAT_DRY = 0, 1, 2, 3
BAT_AMBIGUOUS, BAT_LINEAR_LI = 5, 6
TY_NAME = {0: "UNK", 1: "LI_ION", 2: "NIMH", 3: "DRY", 5: "AMB", 6: "LIN_LI"}

ADC_V_FULL = 3100
ADC_V_OVER = 3850
ADC_V_OPEN = 4090
ADC_V_NEAR_OPEN = 3500
ADC_V_PRE_MAX = 2700
ADC_V_ACTIVATE = 750
ADC_V_SHORT = 500
ADC_V_NIMH_LOW = 1015
ADC_V_NIMH_MAX = 2900

BAT_MV_ACTIVATE = 100
BAT_MV_PRECHARGE = 900
BAT_MV_FULL = 1520
ALPHA_NUM = 124
BETA_NUM = 206
CAL_DEN = 1000

TICK_PER_SEC = 16
SEC = lambda s: s * TICK_PER_SEC
TIME_ACTIVATE_MAX = SEC(60)
TIME_PRECHARGE_MAX = SEC(300)
TIME_DETECT_WAIT = SEC(2)
TIME_DETECT_SETTLE = SEC(8)
DETECT_SETTLE_DROP = 50
TIME_CV_HOLD = SEC(600)
IDLE_POLL_TICKS = SEC(24)
CC_BLOCK_TICKS = SEC(600)
CC_MAX_BLOCKS = 18
CC_NO_PROGRESS_TICKS = SEC(60)
CC_NO_PROGRESS_RISE = 30
CV_NO_PROGRESS_TICKS = SEC(60)
CV_NO_PROGRESS_RISE = 50
CV_NO_PROGRESS_CNT = 3
CV_DROP_LOOP_MAX = 2
OV_DEBOUNCE_CNT = 5
DETECT_LOW_DEBOUNCE = 5
PEAK_DROP_THRESH = 500
IMP_PULSE_TICKS = 5
DIODE_TEST_TICKS = SEC(2)
DIODE_RISE_THRESH = 900
LINEAR_LI_LOW_CRASH_TICKS = SEC(3)
CC_TIMEOUT_RETRY_TICKS = SEC(16)
DIODE_CLAMP_TICKS = SEC(2)
DIODE_CLAMP_MARGIN = 150
FULL_PULLOUT_LINEAR_TICKS = TICK_PER_SEC // 2
FULL_PULLOUT_LION_TICKS = 2
CV_PULLOUT_LION_TICKS = 2
DETECT_STABLE_TICKS = 20
CC_RETRY_FLAG = 0x80

# ---------------- 真实电池类型(日志尾部真值) ----------------
GROUND_TRUTH = {
    1: "碱性(拒充)", 2: "镍氢(拒充)", 3: "碳性(拒充)",
    4: "线性锂(充电)", 5: "恒压锂(充电)", 6: "线性锂(充电)",
    7: "镍氢(拒充)", 8: "线性锂(充电)", 9: "恒压锂(充电)",
    10: "线性锂(充电)", 11: "线性锂(充电)", 12: "恒压锂(充电)",
}
TRUTH_TY = {1: BAT_DRY, 2: BAT_NIMH, 3: BAT_DRY, 4: BAT_LINEAR_LI,
            5: BAT_LI_ION, 6: BAT_LINEAR_LI, 7: BAT_NIMH, 8: BAT_LINEAR_LI,
            9: BAT_LI_ION, 10: BAT_LINEAR_LI, 11: BAT_LINEAR_LI, 12: BAT_LI_ION}


# ---------------- 日志解析 ----------------
def parse_time(txt):
    try:
        dt = datetime.datetime.strptime(txt, "%H:%M:%S.%f")
        return dt.hour * 3600 + dt.minute * 60 + dt.second + dt.microsecond / 1e6
    except Exception:
        return None


def parse_log(path):
    """返回 frames = [{tsec, vcc, slots:{1..12:(raw,st,ct,ty,pre)}}]"""
    frames = []
    cur = None
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            m = re.search(r"(\d+:\d+:\d+\.\d+)\s+VCC=(\d+)mV", line)
            if m:
                if cur is not None:
                    frames.append(cur)
                cur = {"tsec": parse_time(m.group(1)),
                       "vcc": int(m.group(2)), "slots": {}}
                continue
            m = re.search(r"B(\d+)=(\d+)", line)
            if m and cur is not None:
                slot = int(m.group(1))
                raw = int(m.group(2))
                st, ct, ty, pre = "?", 0, -1, -1
                ms = re.search(r"\[([A-Za-z /]+)\]", line)
                if ms:
                    st = ms.group(1).strip()
                mc = re.search(r"ct=(\d+)", line)
                if mc:
                    ct = int(mc.group(1))
                mt = re.search(r"ty=(\d+)", line)
                if mt:
                    ty = int(mt.group(1))
                mp = re.search(r"pre=(\d+)", line)
                if mp:
                    pre = int(mp.group(1))
                cur["slots"][slot] = (raw, st, ct, ty, pre)
    if cur is not None:
        frames.append(cur)
    return frames


def ad_norm(raw, vcc):
    return min(4095, raw * vcc // VCC_REF_MV)


# ---------------- 每帧tick增量: 由日志ct增量实测 ----------------
def compute_deltas(frames):
    deltas = []
    for fi in range(1, len(frames)):
        diffs = []
        for slot in frames[fi]["slots"]:
            if slot in frames[fi - 1]["slots"]:
                st0 = frames[fi - 1]["slots"][slot][1]
                st1 = frames[fi]["slots"][slot][1]
                c0 = frames[fi - 1]["slots"][slot][2]
                c1 = frames[fi]["slots"][slot][2]
                if st0 == st1 and 0 < c1 - c0 <= 800:
                    diffs.append(c1 - c0)
        if diffs:
            diffs.sort()
            deltas.append(diffs[len(diffs) // 2])
        else:
            deltas.append(100)
    return deltas


# ---------------- V55H 槽位模拟对象 ----------------
class Slot:
    def __init__(self):
        self.st = CHG_IDLE
        self.ty = BAT_UNKNOWN
        self.ct = 0
        self.v = 0                # g_slot.voltage (伪OPEN过滤后的v)
        self.ref = 0              # g_slotRefV
        self.ccBlocks = 0         # g_ccBlocks (含CC_RETRY_FLAG)
        self.lowCnt = 0           # g_detectLowCnt
        self.ovCnt = 0            # g_ovCnt
        self.stableCnt = 0        # g_stableCnt
        self.route = ""           # 识别路径记录
        self.hist = []            # (frame, st, ty, v, note)


# 全局共享
g_capFlag = 0
g_highVFlag = 0
g_impCheckSlot = 0xFF
g_impData = 0
g_vcc_mv = 0
g_diodeTrace = [0] * 4
g_diodeTraceCnt = 0
g_diodeTraceSlot = 0


def reset_globals():
    global g_capFlag, g_highVFlag, g_impCheckSlot, g_impData, g_vcc_mv
    global g_diodeTraceCnt, g_diodeTraceSlot, g_diodeTrace
    g_capFlag = 0
    g_highVFlag = 0
    g_impCheckSlot = 0xFF
    g_impData = 0
    g_vcc_mv = 0
    g_diodeTrace = [0] * 4
    g_diodeTraceCnt = 0
    g_diodeTraceSlot = 0


def imp_vcc_decode(data):
    return (((data >> 12) & 0x0F) + 38) * 100


# ---------------- 共享路由(charge_mgr.c L165-216) ----------------
def li_route(s, v):
    """返回 (st, ct)"""
    vx_mv = v * VCC_REF_MV // 4096
    bat_mv_long = ALPHA_NUM * vx_mv + BETA_NUM * VCC_REF_MV
    bat_mv = (bat_mv_long + CAL_DEN // 2) // CAL_DEN
    if bat_mv <= BAT_MV_ACTIVATE:
        st = CHG_ACTIVATE
    elif bat_mv < BAT_MV_PRECHARGE:
        st = CHG_PRECHARGE
    elif bat_mv >= BAT_MV_FULL:
        if s.ccBlocks >= CV_DROP_LOOP_MAX:
            st = CHG_ERROR
        else:
            st = CHG_CV_CHARGE
            s.ref = v
            s.ccBlocks = 0
            s.stableCnt = 0
    else:
        st = CHG_CC_CHARGE
        s.ccBlocks &= CC_RETRY_FLAG
        s.ref = v
        s.stableCnt = 0
    s.ovCnt = 0
    s.lowCnt = 0
    return st, 0


def route_li_ion(i, s, v):
    global g_impCheckSlot, g_highVFlag
    g_impCheckSlot = 0xFF
    g_highVFlag &= ~(1 << i)
    s.ty = BAT_LI_ION
    return li_route(s, v)


def route_linear_li(i, s):
    global g_impCheckSlot, g_highVFlag
    g_impCheckSlot = 0xFF
    g_highVFlag &= ~(1 << i)
    s.ty = BAT_LINEAR_LI
    return li_route(s, g_impData & 0x0FFF)


# ---------------- 状态处理函数 (逐tick移植) ----------------
def slot_idle(i, s, v):
    if v >= ADC_V_OPEN:
        if s.ct < IDLE_POLL_TICKS:
            s.ct += 1
            return
    s.ct = 0
    s.st = CHG_DETECT
    s.ccBlocks = 0
    global g_highVFlag
    g_highVFlag &= ~(1 << i)
    if v < ADC_V_OPEN:
        s.ref = v
    else:
        s.ref = 0


def slot_detect(i, s, v):
    global g_capFlag, g_highVFlag, g_impCheckSlot, g_impData, g_vcc_mv
    s.ct += 1

    if s.ct == 1:
        s.stableCnt = 0
        g_capFlag &= ~(1 << i)

    if s.ct < TIME_DETECT_WAIT:
        return

    if s.ct == TIME_DETECT_WAIT:
        s.ref = v
        if v > ADC_V_NIMH_MAX:
            g_capFlag |= 1 << i
        return

    goto_amb = False
    if v > ADC_V_NIMH_MAX and v < ADC_V_OPEN:
        if not (g_capFlag & (1 << i)) and s.ty != BAT_AMBIGUOUS and v <= ADC_V_NEAR_OPEN:
            s.ct = 0
            s.ref = 0
            s.stableCnt = 0
            s.lowCnt = 0
            return

        v_init = s.ref
        if s.stableCnt >= DETECT_STABLE_TICKS:
            g_highVFlag |= 1 << i
            if v <= ADC_V_NIMH_MAX:
                g_capFlag &= ~(1 << i)
                s.stableCnt = 0
                g_highVFlag &= ~(1 << i)
            elif s.ct < TIME_DETECT_WAIT + TIME_DETECT_SETTLE:
                if (g_highVFlag & (1 << i)) and s.ct >= TIME_DETECT_WAIT + 25:
                    goto_amb = True
                else:
                    s.ref = v
                    return
            else:
                goto_amb = True
            if goto_amb:
                g_capFlag &= ~(1 << i)
                s.stableCnt = 0
                s.ty = BAT_AMBIGUOUS
        else:
            if v + DETECT_SETTLE_DROP < v_init:
                s.ref = v
                s.stableCnt = 0
            else:
                s.ref = v
                s.stableCnt += 1
            if s.stableCnt < DETECT_STABLE_TICKS:
                return
            if g_capFlag & (1 << i):
                return
            s.stableCnt = 0
    elif s.ct < TIME_DETECT_WAIT + TIME_DETECT_SETTLE and v < ADC_V_OPEN:
        v_ref = s.ref
        if v_ref < ADC_V_OPEN and v + DETECT_SETTLE_DROP < v_ref:
            s.ref = v
            return

    if not goto_amb:
        if g_capFlag & (1 << i):
            g_capFlag &= ~(1 << i)
            s.lowCnt = 0
            s.ty = BAT_AMBIGUOUS
        else:
            s.ty = detect_battery_type(v)
            if s.ty == BAT_UNKNOWN and v >= ADC_V_OPEN and \
               s.ct >= TIME_DETECT_WAIT + TIME_DETECT_SETTLE:
                s.ty = BAT_AMBIGUOUS

        if v < ADC_V_SHORT:
            s.lowCnt += 1
            if s.lowCnt < DETECT_LOW_DEBOUNCE:
                return
        elif s.ty not in (BAT_AMBIGUOUS, BAT_LI_ION, BAT_LINEAR_LI):
            s.lowCnt = 0

    # amb_check:
    if s.ty == BAT_AMBIGUOUS:
        s.lowCnt += 1
        if s.lowCnt < 2:
            return
        if g_impCheckSlot != 0xFF and g_impCheckSlot != i:
            return
        g_impCheckSlot = i
        g_vcc_mv = vcc_now
        g_impData = v | ((((g_vcc_mv + 50) // 100) - 38) << 12)
        s.st = CHG_IMP_CHECK
        s.ct = 0
        s.lowCnt = 0
    elif s.ty in (BAT_LI_ION, BAT_LINEAR_LI):
        s.lowCnt += 1
        if s.lowCnt < 2:
            return
        s.st, s.ct = li_route(s, v)
    elif s.ty == BAT_UNKNOWN:
        if v >= ADC_V_OPEN:
            return
        s.st = CHG_ERROR
        s.lowCnt = 0
    elif s.ty in (BAT_NIMH, BAT_DRY):
        s.st = CHG_ERROR
        s.lowCnt = 0


def detect_battery_type(voltage):
    if voltage >= ADC_V_OPEN:
        return BAT_UNKNOWN
    if voltage < ADC_V_SHORT:
        return BAT_UNKNOWN
    if voltage >= ADC_V_NIMH_LOW and voltage < ADC_V_OPEN:
        return BAT_AMBIGUOUS
    if voltage >= ADC_V_SHORT and voltage < ADC_V_OPEN:
        return BAT_LI_ION
    return BAT_UNKNOWN


def slot_imp_check(i, s, v):
    global g_impCheckSlot, g_highVFlag, g_impData, g_vcc_mv, g_diodeTraceCnt, g_diodeTraceSlot
    s.ct += 1
    if s.ct < IMP_PULSE_TICKS:
        return

    g_vcc_mv = vcc_now
    pre = g_impData & 0x0FFF

    if v >= 4050 and pre >= 4050:
        s.ty = BAT_UNKNOWN
        s.st = CHG_IDLE
        g_impCheckSlot = 0xFF
        g_highVFlag &= ~(1 << i)
        return

    if imp_vcc_decode(g_impData) > g_vcc_mv + 300 and v >= ADC_V_OPEN:
        s.ty = BAT_NIMH
        s.st = CHG_ERROR
        g_impCheckSlot = 0xFF
        g_highVFlag &= ~(1 << i)
        return

    if imp_vcc_decode(g_impData) > g_vcc_mv + 200 and pre < 3100:
        s.st, s.ct = route_li_ion(i, s, v)
        s.route = "IMP-VCC跌落>200"
        return

    if not (g_highVFlag & (1 << i)) and pre > v and (pre - v) > 1000:
        s.ty = BAT_DRY
        s.st = CHG_ERROR
        g_impCheckSlot = 0xFF
        g_highVFlag &= ~(1 << i)
        s.lowCnt = 0
        return

    if pre > ADC_V_NEAR_OPEN and imp_vcc_decode(g_impData) <= g_vcc_mv + 200:
        goto_dio = True
    elif v >= ADC_V_OPEN:
        goto_dio = True
    else:
        goto_dio = False

    if goto_dio:
        s.st = CHG_IMP_DIODE_TEST
        s.ct = 0
        g_diodeTraceCnt = 0
        g_diodeTraceSlot = i
        g_highVFlag &= ~(1 << i)


def slot_diode_test(i, s, v):
    global g_impCheckSlot, g_highVFlag, g_vcc_mv, g_diodeTraceCnt
    s.ct += 1
    pre = g_impData & 0x0FFF

    if s.ct in (7, 14, 21, 28) and g_diodeTraceCnt < 4:
        diff = v - pre
        diff >>= 2
        if diff > 127:
            diff = 127
        if diff < -128:
            diff = -128
        g_diodeTrace[g_diodeTraceCnt] = diff + 128
        g_diodeTraceCnt += 1

    if v > pre + DIODE_RISE_THRESH:
        if imp_vcc_decode(g_impData) > g_vcc_mv + 150:
            s.st, s.ct = route_li_ion(i, s, v)
            s.route = "DIO爬升+VCC跌落>150→LI_ION"
        else:
            s.st, s.ct = route_linear_li(i, s)
            s.route = "DIO爬升>900→LINEAR_LI"
        return

    if pre > 3000 and v > ADC_V_NIMH_MAX and v < pre:
        s.st, s.ct = route_linear_li(i, s)
        s.route = "DIO高压回落→LINEAR_LI"
        return

    if v > ADC_V_NIMH_MAX and pre <= 2300:
        s.ty = BAT_DRY
        s.st = CHG_ERROR
        g_impCheckSlot = 0xFF
        g_highVFlag &= ~(1 << i)
        s.lowCnt = 0
        return

    if s.ct >= DIODE_CLAMP_TICKS and v > 2100 and pre <= 2300 and \
       v + 160 >= pre and v <= pre + DIODE_CLAMP_MARGIN:
        s.st, s.ct = route_linear_li(i, s)
        s.route = "DIO低压钳位→LINEAR_LI"
        return

    if s.ct >= DIODE_TEST_TICKS:
        if pre > ADC_V_NEAR_OPEN and pre < ADC_V_OPEN:
            hasRise = any(t >= 136 for t in g_diodeTrace[:g_diodeTraceCnt])
            if imp_vcc_decode(g_impData) > g_vcc_mv + 150:
                s.st, s.ct = route_li_ion(i, s, v)
                s.route = "DIO超时高压+VCC跌落→LI_ION"
                return
            if not hasRise:
                s.ty = BAT_DRY
                s.st = CHG_ERROR
                g_impCheckSlot = 0xFF
                g_highVFlag &= ~(1 << i)
                s.lowCnt = 0
                return
            s.st, s.ct = route_linear_li(i, s)
            s.route = "DIO超时高压+爬升→LINEAR_LI"
            return
        if v > ADC_V_NEAR_OPEN and v < ADC_V_OPEN:
            s.st, s.ct = route_linear_li(i, s)
            s.route = "DIO超时v>3500→LINEAR_LI"
            return
        if v > 2300 and v < 3500 and pre < 3500 and \
           v + 150 >= pre and pre + 150 >= v:
            s.st, s.ct = route_linear_li(i, s)
            s.route = "DIO超时中压钳位→LINEAR_LI"
            return
        s.ty = BAT_DRY
        s.st = CHG_ERROR
        g_impCheckSlot = 0xFF
        g_highVFlag &= ~(1 << i)
        s.lowCnt = 0


def slot_activate(i, s, v):
    s.ct += 1
    if s.ct > TIME_ACTIVATE_MAX:
        s.st = CHG_ERROR
        return
    if v > ADC_V_ACTIVATE:
        s.st = CHG_PRECHARGE
        s.ct = 0
        return
    if v >= ADC_V_OVER:
        s.st = CHG_ERROR


def slot_precharge(i, s, v):
    s.ct += 1
    if s.ct > TIME_PRECHARGE_MAX:
        s.st = CHG_ERROR
        return
    if v >= ADC_V_OVER:
        s.ovCnt += 1
        if s.ovCnt >= OV_DEBOUNCE_CNT:
            s.st = CHG_ERROR
            return
    else:
        s.ovCnt = 0
    if v >= ADC_V_PRE_MAX:
        s.st = CHG_CC_CHARGE
        s.ct = 0
        s.ccBlocks = 0
        s.ovCnt = 0
        s.ref = v
        s.stableCnt = 0


def slot_cc(i, s, v):
    global g_highVFlag
    s.ct += 1
    if s.ct >= CC_BLOCK_TICKS:
        s.ct -= CC_BLOCK_TICKS
        s.ccBlocks += 1
    if s.ccBlocks >= CC_MAX_BLOCKS:
        s.st = CHG_ERROR
        return

    if v >= ADC_V_OPEN and s.ty == BAT_LINEAR_LI:
        pass
    elif s.ct <= CC_NO_PROGRESS_TICKS:
        pass
    else:
        if v > s.ref:
            s.ref = v

    if s.ty == BAT_LINEAR_LI:
        if v < 2000:
            s.lowCnt += 1
            if s.lowCnt >= LINEAR_LI_LOW_CRASH_TICKS:
                s.lowCnt = 0
                s.st = CHG_ERROR
                s.ct = 0
                return
        else:
            s.lowCnt = 0

        if s.ct >= CC_TIMEOUT_RETRY_TICKS:
            s.ct = 0
            if 2800 <= v < ADC_V_OPEN:
                s.st = CHG_CV_CHARGE
                s.ccBlocks = 0
                s.ref = v
                s.stableCnt = 0
            elif v >= s.ref + CC_NO_PROGRESS_RISE:
                s.stableCnt = 1
                s.ref = v
            elif s.stableCnt != 0:
                s.ref = v
            elif s.ccBlocks & CC_RETRY_FLAG:
                s.st = CHG_ERROR
            else:
                s.ccBlocks |= CC_RETRY_FLAG
                s.st = CHG_DETECT
                s.ref = 0
                s.stableCnt = 0
            return
    else:
        if (v < s.ref and s.ref - v > PEAK_DROP_THRESH) or v < 2000:
            s.lowCnt += 1
            if s.lowCnt < 2:
                return
            s.lowCnt = 0
            s.st = CHG_DETECT
            s.ct = 0
            return
        else:
            s.lowCnt = 0

        if s.ct <= CC_NO_PROGRESS_TICKS:
            if v >= s.ref + CC_NO_PROGRESS_RISE:
                s.stableCnt = 1
        if s.ct > CC_NO_PROGRESS_TICKS and s.stableCnt == 0:
            s.st = CHG_ERROR
            s.ct = 0
            return

    if v >= ADC_V_OPEN and s.ty == BAT_LI_ION:
        s.st = CHG_FULL
        s.ct = 0
        return

    if v >= ADC_V_OVER and s.ty != BAT_LINEAR_LI:
        s.ovCnt += 1
        if s.ovCnt >= OV_DEBOUNCE_CNT:
            s.st = CHG_ERROR
            return
    else:
        s.ovCnt = 0
        if v >= ADC_V_FULL and not (v >= ADC_V_OPEN and s.ty == BAT_LINEAR_LI):
            s.st = CHG_CV_CHARGE
            s.ct = 0
            s.ccBlocks = 0


def slot_cv(i, s, v):
    global g_highVFlag
    s.ct += 1
    if s.ct > TIME_CV_HOLD:
        s.st = CHG_FULL

    if v >= ADC_V_OPEN and s.ty == BAT_LINEAR_LI:
        return

    if v < ADC_V_OPEN and s.ct <= CV_NO_PROGRESS_TICKS and s.ty == BAT_LI_ION:
        if s.ccBlocks == 0:
            s.ref = v
            s.ccBlocks = 1
        elif v >= s.ref + CV_NO_PROGRESS_RISE:
            s.stableCnt += 1
            if s.stableCnt >= CV_NO_PROGRESS_CNT:
                s.stableCnt = 0
                s.st = CHG_ERROR
                s.ct = 0
                return
        else:
            s.stableCnt = 0

    if v >= ADC_V_OPEN:
        if s.ty == BAT_LI_ION:
            s.lowCnt += 1
            if s.lowCnt < CV_PULLOUT_LION_TICKS:
                return
            s.lowCnt = 0
            s.st = CHG_FULL
            s.ct = 0
            return
        if s.ty == BAT_LINEAR_LI:
            return
        s.lowCnt += 1
        if s.lowCnt < CV_PULLOUT_LION_TICKS:
            return
        s.lowCnt = 0
        s.ty = BAT_UNKNOWN
        s.st = CHG_IDLE
        s.ct = 0
        return

    if s.ty == BAT_LINEAR_LI:
        if v < 2000:
            s.lowCnt += 1
            if s.lowCnt >= LINEAR_LI_LOW_CRASH_TICKS:
                s.lowCnt = 0
                s.st = CHG_ERROR
                s.ct = 0
                return
        else:
            s.lowCnt = 0
    else:
        if v < s.ref and s.ref - v > PEAK_DROP_THRESH:
            s.lowCnt += 1
            if s.lowCnt >= 2:
                s.lowCnt = 0
                s.ccBlocks += 1
                s.ty = BAT_UNKNOWN
                s.st = CHG_DETECT
                s.ct = 0
                return
        else:
            s.lowCnt = 0

    if v >= ADC_V_OVER and s.ty == BAT_LI_ION:
        s.ovCnt += 1
        if s.ovCnt >= OV_DEBOUNCE_CNT:
            s.st = CHG_ERROR
    else:
        s.ovCnt = 0


def slot_full(i, s, v):
    if v >= ADC_V_OPEN:
        s.lowCnt += 1
        if s.lowCnt >= (FULL_PULLOUT_LINEAR_TICKS if s.ty == BAT_LINEAR_LI
                        else FULL_PULLOUT_LION_TICKS):
            s.lowCnt = 0
            s.st = CHG_IDLE
            s.ct = 0
        return
    if v < 2800:
        s.lowCnt += 1
        if s.lowCnt < 2:
            return
        s.lowCnt = 0
        s.st = CHG_CC_CHARGE
        s.ct = 0
        s.ovCnt = 0
        s.ccBlocks = 0
        s.ref = v
        s.stableCnt = 0
    else:
        s.lowCnt = 0


def slot_error(i, s, v):
    global g_highVFlag
    if v >= ADC_V_OPEN:
        s.lowCnt += 1
        if s.lowCnt < 2:
            return
        s.lowCnt = 0
        s.ty = BAT_UNKNOWN
        s.st = CHG_IDLE
        s.ct = 0
        s.ccBlocks = 0
        return
    if s.ty in (BAT_NIMH, BAT_DRY):
        if v > 2700 and (g_highVFlag & (1 << i)):
            s.lowCnt += 1
            if s.lowCnt < 2:
                return
            s.lowCnt = 0
            s.st = CHG_DETECT
            s.ct = 0
        else:
            s.lowCnt = 0
        return
    if v > ADC_V_ACTIVATE:
        s.lowCnt += 1
        if s.lowCnt < 2:
            return
        s.lowCnt = 0
        s.st = CHG_DETECT
        s.ct = 0
    else:
        s.lowCnt = 0


# ---------------- 主回放 ----------------
def run_sim(frames):
    global vcc_now, g_vcc_mv
    deltas = compute_deltas(frames)
    slots = {i: Slot() for i in range(1, 13)}
    reset_globals()
    for s in slots.values():
        s.st = CHG_IDLE

    epochs = []
    cur_epoch = 1
    prev_t = frames[0]["tsec"]
    for fi, fr in enumerate(frames):
        if fr["tsec"] is not None and prev_t is not None and \
           fr["tsec"] - prev_t > 15:
            # 断电重启: 全槽重置
            for s in slots.values():
                s.__init__()
            reset_globals()
            cur_epoch += 1
        prev_t = fr["tsec"]

        delta = deltas[fi - 1] if fi > 0 else 100
        vcc_now = fr["vcc"]
        g_vcc_mv = fr["vcc"]

        for _ in range(delta):
            for i in sorted(fr["slots"]):
                if i not in fr["slots"]:
                    continue
                raw, lst, lct, lty, lpre = fr["slots"][i]
                newv = ad_norm(raw, vcc_now)
                s = slots[i]
                # 伪OPEN过滤
                if not (s.ty == BAT_LINEAR_LI and
                        s.st in (CHG_CC_CHARGE, CHG_CV_CHARGE) and
                        newv >= ADC_V_OPEN):
                    s.v = newv
                v = s.v
                prev = (s.st, s.ty, s.ct)
                if s.st == CHG_IDLE:
                    slot_idle(i, s, v)
                elif s.st == CHG_DETECT:
                    slot_detect(i, s, v)
                elif s.st == CHG_IMP_CHECK:
                    slot_imp_check(i, s, v)
                elif s.st == CHG_IMP_DIODE_TEST:
                    slot_diode_test(i, s, v)
                elif s.st == CHG_ACTIVATE:
                    slot_activate(i, s, v)
                elif s.st == CHG_PRECHARGE:
                    slot_precharge(i, s, v)
                elif s.st == CHG_CC_CHARGE:
                    slot_cc(i, s, v)
                elif s.st == CHG_CV_CHARGE:
                    slot_cv(i, s, v)
                elif s.st == CHG_FULL:
                    slot_full(i, s, v)
                elif s.st == CHG_ERROR:
                    slot_error(i, s, v)
                else:
                    s.st = CHG_IDLE
                if (s.st, s.ty) != (prev[0], prev[1]):
                    s.hist.append((cur_epoch, fi, ST_NAME[prev[0]], ST_NAME[s.st],
                                   TY_NAME[s.ty], v, s.route))
        epochs.append((cur_epoch, fi, s))

    return slots, deltas, cur_epoch


# ---------------- 报告 ----------------
def main():
    base = os.path.dirname(os.path.abspath(__file__))
    log_path = os.path.join(base, "log.txt")
    out_path = os.path.join(base, "sim_v55h_result.txt")
    if not os.path.exists(log_path):
        print("未找到 %s" % log_path)
        sys.exit(1)

    frames = parse_log(log_path)
    slots, deltas, last_epoch = run_sim(frames)

    out = []
    P = out.append

    P("=" * 108)
    P("V55H 忠实状态机回放结果   输入: %s, 共 %d 帧 (%d 个检测时段)" %
      (os.path.basename(log_path), len(frames), last_epoch))
    P("换算: fwd = min(4095, raw*VCC/5000)  帧内tick增量: %s" %
      "/".join(str(d) for d in deltas))
    P("方法: 逐tick移植 charge_mgr.c V55H 全部10状态+3路由, 帧内读数按保持采样,")
    P("      IMP_CHECK的VCC跌落/拔检等帧内动态无法由日志还原, 识别主要靠DIODE_TEST")
    P("=" * 108)
    P("")
    P("一、逐槽识别结果 (最终状态; [OK]=正确 [NG]=误判 [!]=类型偏差仍充电)")
    P("%-4s %-12s %-10s %-10s %-26s %s" %
      ("槽", "真实电池", "最终状态", "识别类型", "识别路径", "结论"))
    P("-" * 108)

    li_ok, li_ng, rej_ok, rej_ng = [], [], [], []
    for i in range(1, 13):
        s = slots[i]
        truth = GROUND_TRUTH[i]
        tty = TRUTH_TY[i]
        stn = ST_NAME[s.st]
        tyn = TY_NAME[s.ty]
        route = s.route or "-"
        if tty in (BAT_LI_ION, BAT_LINEAR_LI):
            if s.st in (CHG_CC_CHARGE, CHG_CV_CHARGE, CHG_FULL):
                if s.ty == tty:
                    concl = "[OK] 正确识别并充电"
                    li_ok.append(i)
                else:
                    concl = "[!] 类型偏差(%s≠%s), 仍充电" % (tyn, TY_NAME[tty])
                    li_ok.append(i)
            elif s.st == CHG_ERROR:
                concl = "[NG] 锂电池被拒充(ERROR)"
                li_ng.append(i)
            else:
                concl = "[NG] 锂电池未进入充电(停留在%s)" % stn
                li_ng.append(i)
        else:
            if s.st == CHG_ERROR:
                concl = "[OK] 正确拒充"
                rej_ok.append(i)
            else:
                concl = "[NG] 干电池/镍氢被放行充电(%s)" % stn
                rej_ng.append(i)
        P("%-4d %-12s %-10s %-10s %-26s %s" %
          (i, truth, stn, tyn, route, concl))

    P("-" * 108)
    P("汇总: 锂电池充电正确 %s; 锂电池误判 %s; 拒充正确 %s; 误放行 %s" %
      (li_ok or "-", li_ng or "-", rej_ok or "-", rej_ng or "-"))

    P("")
    P("二、逐槽状态迁移(帧序号从0起)")
    P("-" * 108)
    for i in range(1, 13):
        s = slots[i]
        if not s.hist:
            P("B%d [%s]: 无状态迁移(全程%s)" % (i, GROUND_TRUTH[i], ST_NAME[s.st]))
            continue
        P("B%d [%s]:" % (i, GROUND_TRUTH[i]))
        for ep, fi, frm, to, ty, v, route in s.hist:
            P("   时段%d 帧%-2d %-4s -> %-4s ty=%-7s v=%-5d %s" %
              (ep, fi, frm, to, ty, v, route))

    P("")
    P("三、关键说明")
    P("  - IMP_CHECK VCC跌落判据在本数据下不可用(日志无法还原帧内VCC塌陷),")
    P("    因此多数槽经DIODE_TEST判定; 恒压锂/线性锂的区分在真机上依赖")
    P("    脉冲VCC跌落, 需以真机实测为准。")
    P("  - 帧内读数按保持采样: 一个检测状态(如DIO)在日志采样粒度内可能被")
    P("    压缩到单帧完成, 结论偏保守(只可能更慢, 不会更激进)。")

    txt = "\n".join(out)
    print(txt)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(txt)
    print("\n已写入 %s" % out_path)


if __name__ == "__main__":
    main()
