opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_CCCV_Control
	FNCALL	_main,_Get_Vcc
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_Read_Temperature
	FNCALL	_main,_Slot_Charge_Ctrl
	FNCALL	_main,_System_Init
	FNCALL	_main,_Update_LED_Global
	FNCALL	_main,_uart_send_string
	FNCALL	_Update_LED_Global,___bmul
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Slot_Charge_Ctrl,_Adc_Norm
	FNCALL	_Slot_Charge_Ctrl,_Detect_BatteryType
	FNCALL	_Slot_Charge_Ctrl,_Get_Vcc
	FNCALL	_Slot_Charge_Ctrl,___bmul
	FNCALL	_Slot_Charge_Ctrl,___lldiv
	FNCALL	_Slot_Charge_Ctrl,___lmul
	FNCALL	_Slot_Charge_Ctrl,___lwdiv
	FNCALL	_Slot_Charge_Ctrl,___wmul
	FNCALL	_Get_Vcc,_ADC_Sample
	FNCALL	_Get_Vcc,___lldiv
	FNCALL	_Adc_Norm,_ADC_Sample
	FNCALL	_Adc_Norm,___lldiv
	FNCALL	_Adc_Norm,___lmul
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,___bmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_vcc_mv
	global	_g_impCheckSlot
	global	_g_temperature
psect	idataBANK0,class=CODE,space=0,delta=2,noexec
global __pidataBANK0
__pidataBANK0:
	file	"main.c"
	line	25

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

	file	"charge_mgr.c"
	line	26

;initializer for _g_impCheckSlot
	retlw	0FFh
psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	line	18

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"main.c"
	line	47
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_powerOnPhase
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_impData
	global	_s_ledBlinkCnt
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_diodeTraceCnt
	global	_test_adc
	global	_adresult
	global	_g_slotRefV
	global	_g_stableCnt
	global	_g_detectLowCnt
	global	_g_ccBlocks
	global	_g_highVFlag
	global	_g_capFlag
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_powerOnTimer
	global	_g_cvIntegral
	global	_g_vccProtect
	global	_g_tempProtect
	global	_g_tempPhase
	global	_g_diodeTraceSlot
	global	_g_slot
	global	_g_ovCnt
	global	_g_diodeTrace
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_GIE
_GIE	set	0x5F
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC4
_RC4	set	0x834
	global	_RC5
_RC5	set	0x835
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	0
psect	stringtext
	
STR_37:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_25:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_23:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	45	;'-'
	retlw	105	;'i'
	retlw	111	;'o'
	retlw	110	;'n'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	67	;'C'
	retlw	32	;' '
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	95	;'_'
	retlw	76	;'L'
	retlw	79	;'O'
	retlw	67	;'C'
	retlw	75	;'K'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_38:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_8:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_30:	
	retlw	32	;' '
	retlw	112	;'p'
	retlw	114	;'r'
	retlw	101	;'e'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	32	;' '
	retlw	114	;'r'
	retlw	101	;'e'
	retlw	102	;'f'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_31:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_29:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	73	;'I'
	retlw	79	;'O'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_7:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_34:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	114	;'r'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_32:	
	retlw	32	;' '
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_33:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	53	;'5'
	retlw	53	;'5'
	retlw	71	;'G'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
STR_27	equ	STR_17+0
STR_9	equ	STR_2+0
STR_11	equ	STR_38+7
STR_35	equ	STR_38+7
STR_36	equ	STR_38+7
; #config settings
	file	"main.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_g_powerOnPhase:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_impData:
       ds      2

_s_ledBlinkCnt:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_diodeTraceCnt:
       ds      1

_test_adc:
       ds      1

_adresult:
       ds      2

psect	dataBANK0,class=BANK0,space=1,noexec
global __pdataBANK0
__pdataBANK0:
	file	"main.c"
	line	25
_g_vcc_mv:
       ds      2

psect	dataBANK0
	file	"charge_mgr.c"
	line	26
_g_impCheckSlot:
       ds      1

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_slotRefV:
       ds      24

_g_stableCnt:
       ds      12

_g_detectLowCnt:
       ds      12

_g_ccBlocks:
       ds      12

_g_highVFlag:
       ds      2

_g_capFlag:
       ds      2

_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_powerOnTimer:
       ds      2

_g_cvIntegral:
       ds      2

_g_vccProtect:
       ds      1

_g_tempProtect:
       ds      1

_g_tempPhase:
       ds      1

_g_diodeTraceSlot:
       ds      1

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"charge_mgr.c"
	line	18
_g_temperature:
       ds      2

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_ovCnt:
       ds      12

_g_diodeTrace:
       ds      4

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"main.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
; Initialize objects allocated to BANK0
	global __pidataBANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	fcall	__pidataBANK0+0		;fetch initializer
	movwf	__pdataBANK0+0&07fh		
	fcall	__pidataBANK0+1		;fetch initializer
	movwf	__pdataBANK0+1&07fh		
	fcall	__pidataBANK0+2		;fetch initializer
	movwf	__pdataBANK0+2&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+010h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+04Eh)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+09h)
	fcall	clear_ram0
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_Slot_Charge_Ctrl:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Update_LED_Global:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
??_Isr_Timer:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?_Get_Vcc:	; 2 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	ds	2
??_AD_Init:	; 1 bytes @ 0x2
??_uart_init:	; 1 bytes @ 0x2
?_ADC_Sample:	; 1 bytes @ 0x2
??_uart_send_char:	; 1 bytes @ 0x2
?_Detect_BatteryType:	; 1 bytes @ 0x2
?___bmul:	; 1 bytes @ 0x2
	global	?___wmul
?___wmul:	; 2 bytes @ 0x2
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x2
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x2
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x2
	global	?___lmul
?___lmul:	; 4 bytes @ 0x2
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x2
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x2
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x2
	global	___wmul@multiplier
___wmul@multiplier:	; 2 bytes @ 0x2
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x2
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x2
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x2
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x2
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x3
??___bmul:	; 1 bytes @ 0x3
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x3
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x3
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x4
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x4
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x4
	global	___wmul@multiplicand
___wmul@multiplicand:	; 2 bytes @ 0x4
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x4
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x4
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x4
	ds	1
?_uart_send_string:	; 1 bytes @ 0x5
??_Update_LED_Global:	; 1 bytes @ 0x5
??_System_Init:	; 1 bytes @ 0x5
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x5
	global	Update_LED_Global@hasErr
Update_LED_Global@hasErr:	; 1 bytes @ 0x5
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x5
	ds	1
??___wmul:	; 1 bytes @ 0x6
??___awdiv:	; 1 bytes @ 0x6
??___lwdiv:	; 1 bytes @ 0x6
??___lwmod:	; 1 bytes @ 0x6
	global	Update_LED_Global@hasChg
Update_LED_Global@hasChg:	; 1 bytes @ 0x6
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x6
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x6
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x6
	global	___wmul@product
___wmul@product:	; 2 bytes @ 0x6
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x6
	ds	1
??_uart_send_string:	; 1 bytes @ 0x7
	global	Update_LED_Global@hasFull
Update_LED_Global@hasFull:	; 1 bytes @ 0x7
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x7
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x7
	ds	1
	global	Update_LED_Global@i
Update_LED_Global@i:	; 1 bytes @ 0x8
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x8
	ds	1
??_uart_send_number:	; 1 bytes @ 0x9
??_Print_NtcTemp:	; 1 bytes @ 0x9
	global	Update_LED_Global@s
Update_LED_Global@s:	; 1 bytes @ 0x9
	ds	1
??_Get_Vcc:	; 1 bytes @ 0xA
??_Adc_Norm:	; 1 bytes @ 0xA
??___lmul:	; 1 bytes @ 0xA
??___lldiv:	; 1 bytes @ 0xA
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
?_uart_send_number:	; 1 bytes @ 0x0
??_CCCV_Control:	; 1 bytes @ 0x0
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x0
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x0
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x0
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x1
	ds	1
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x2
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x2
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x2
	ds	1
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x4
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x4
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x4
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0x5
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0x6
	ds	1
	global	CCCV_Control@detectCount
CCCV_Control@detectCount:	; 1 bytes @ 0x7
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0x8
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x8
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x8
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x9
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0xA
	global	_Print_NtcTemp$701
_Print_NtcTemp$701:	; 2 bytes @ 0xA
	ds	1
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xC
	global	_Print_NtcTemp$702
_Print_NtcTemp$702:	; 2 bytes @ 0xC
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0xC
	ds	2
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0xE
	ds	1
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0xF
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0x10
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x10
	ds	1
??_Read_Temperature:	; 1 bytes @ 0x11
??_Print_SystemStatus:	; 1 bytes @ 0x11
	global	?_Adc_Norm
?_Adc_Norm:	; 2 bytes @ 0x11
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0x11
	global	Get_Vcc@pt
Get_Vcc@pt:	; 4 bytes @ 0x11
	ds	2
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x13
	ds	1
	global	Adc_Norm@ch
Adc_Norm@ch:	; 1 bytes @ 0x14
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x14
	ds	1
	global	Adc_Norm@raw
Adc_Norm@raw:	; 2 bytes @ 0x15
	global	_Print_SystemStatus$703
_Print_SystemStatus$703:	; 2 bytes @ 0x15
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x15
	ds	2
	global	_Print_SystemStatus$704
_Print_SystemStatus$704:	; 2 bytes @ 0x17
	global	Adc_Norm@norm
Adc_Norm@norm:	; 4 bytes @ 0x17
	ds	2
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x19
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x19
	ds	2
??_Slot_Charge_Ctrl:	; 1 bytes @ 0x1B
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x1B
	ds	2
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x1D
	ds	1
	global	_Print_SystemStatus$265
_Print_SystemStatus$265:	; 2 bytes @ 0x1E
	ds	2
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x20
	global	Slot_Charge_Ctrl@v_init
Slot_Charge_Ctrl@v_init:	; 2 bytes @ 0x20
	ds	2
	global	_Slot_Charge_Ctrl$380
_Slot_Charge_Ctrl$380:	; 2 bytes @ 0x22
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0x22
	ds	2
	global	Slot_Charge_Ctrl@hasRise
Slot_Charge_Ctrl@hasRise:	; 1 bytes @ 0x24
	ds	1
	global	Slot_Charge_Ctrl@newv
Slot_Charge_Ctrl@newv:	; 2 bytes @ 0x25
	ds	1
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x26
	ds	1
	global	Slot_Charge_Ctrl@v_ref
Slot_Charge_Ctrl@v_ref:	; 2 bytes @ 0x27
	ds	1
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0x28
	ds	1
	global	Slot_Charge_Ctrl@dly
Slot_Charge_Ctrl@dly:	; 1 bytes @ 0x29
	ds	1
	global	Slot_Charge_Ctrl@tc
Slot_Charge_Ctrl@tc:	; 1 bytes @ 0x2A
	ds	1
	global	Slot_Charge_Ctrl@diff
Slot_Charge_Ctrl@diff:	; 2 bytes @ 0x2B
	ds	1
	global	Print_SystemStatus@tc
Print_SystemStatus@tc:	; 1 bytes @ 0x2C
	ds	1
	global	Print_SystemStatus@t
Print_SystemStatus@t:	; 1 bytes @ 0x2D
	global	Slot_Charge_Ctrl@vx_mv
Slot_Charge_Ctrl@vx_mv:	; 4 bytes @ 0x2D
	ds	1
	global	Print_SystemStatus@d
Print_SystemStatus@d:	; 2 bytes @ 0x2E
	ds	2
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x30
	ds	1
	global	Slot_Charge_Ctrl@bat_mv_long
Slot_Charge_Ctrl@bat_mv_long:	; 4 bytes @ 0x31
	ds	4
	global	Slot_Charge_Ctrl@pre
Slot_Charge_Ctrl@pre:	; 2 bytes @ 0x35
	ds	2
	global	Slot_Charge_Ctrl@bat_mv
Slot_Charge_Ctrl@bat_mv:	; 2 bytes @ 0x37
	ds	2
	global	Slot_Charge_Ctrl@st
Slot_Charge_Ctrl@st:	; 1 bytes @ 0x39
	ds	1
	global	Slot_Charge_Ctrl@ty
Slot_Charge_Ctrl@ty:	; 1 bytes @ 0x3A
	ds	1
	global	Slot_Charge_Ctrl@ct
Slot_Charge_Ctrl@ct:	; 2 bytes @ 0x3B
	ds	2
	global	Slot_Charge_Ctrl@v
Slot_Charge_Ctrl@v:	; 2 bytes @ 0x3D
	ds	2
	global	Slot_Charge_Ctrl@idx
Slot_Charge_Ctrl@idx:	; 1 bytes @ 0x3F
	ds	1
??_main:	; 1 bytes @ 0x40
	ds	2
	global	main@i
main@i:	; 1 bytes @ 0x42
	ds	1
;!
;!Data Sizes:
;!    Strings     254
;!    Constant    12
;!    Data        5
;!    BSS         176
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     10      12
;!    BANK0            80     67      79
;!    BANK1            80      0      80
;!    BANK3            80      0      16
;!    BANK2            80      0      72

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 25
;!		 -> STR_38(CODE[10]), STR_37(CODE[21]), STR_36(CODE[3]), STR_35(CODE[3]), 
;!		 -> STR_34(CODE[5]), STR_33(CODE[5]), STR_32(CODE[5]), STR_31(CODE[6]), 
;!		 -> STR_30(CODE[6]), STR_29(CODE[6]), STR_28(CODE[6]), STR_27(CODE[6]), 
;!		 -> STR_26(CODE[6]), STR_25(CODE[16]), STR_24(CODE[13]), STR_23(CODE[15]), 
;!		 -> STR_22(CODE[7]), STR_21(CODE[5]), STR_20(CODE[5]), STR_19(CODE[6]), 
;!		 -> STR_18(CODE[6]), STR_17(CODE[6]), STR_16(CODE[6]), STR_15(CODE[7]), 
;!		 -> STR_14(CODE[4]), STR_13(CODE[6]), STR_12(CODE[6]), STR_11(CODE[3]), 
;!		 -> STR_10(CODE[12]), STR_9(CODE[2]), STR_8(CODE[6]), STR_7(CODE[5]), 
;!		 -> STR_6(CODE[6]), STR_5(CODE[5]), STR_4(CODE[25]), STR_3(CODE[4]), 
;!		 -> STR_2(CODE[2]), STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    _main->_Update_LED_Global
;!    _Update_LED_Global->___bmul
;!    _System_Init->___bmul
;!    _Slot_Charge_Ctrl->___lmul
;!    _Adc_Norm->___lmul
;!    _Read_Temperature->___lmul
;!    _Print_SystemStatus->___lmul
;!    ___lldiv->___lmul
;!    _Print_NtcTemp->___lwdiv
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    None.
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Slot_Charge_Ctrl
;!    _Slot_Charge_Ctrl->_Adc_Norm
;!    _Get_Vcc->___lldiv
;!    _Adc_Norm->___lldiv
;!    _Read_Temperature->___lldiv
;!    _Print_SystemStatus->___lldiv
;!    ___lldiv->___lmul
;!    _Print_NtcTemp->_uart_send_number
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    None.
;!
;!Critical Paths under _main in BANK1
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 3     3      0   59245
;!                                             64 BANK0      3     3      0
;!                       _CCCV_Control
;!                            _Get_Vcc
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                   _Read_Temperature
;!                   _Slot_Charge_Ctrl
;!                        _System_Init
;!                  _Update_LED_Global
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Update_LED_Global                                    5     5      0    1173
;!                                              5 COMMON     5     5      0
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1090
;!                                              5 COMMON     1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Slot_Charge_Ctrl                                    37    37      0   25220
;!                                             27 BANK0     37    37      0
;!                           _Adc_Norm
;!                 _Detect_BatteryType
;!                            _Get_Vcc
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (2) ___wmul                                               6     2      4    1922
;!                                              2 COMMON     6     2      4
;! ---------------------------------------------------------------------------------
;! (2) _Get_Vcc                                              4     4      0    2392
;!                                             17 BANK0      4     4      0
;!                         _ADC_Sample
;!                            ___lldiv
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     185
;!                                              2 COMMON     2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _Adc_Norm                                            10     7      3    4127
;!                                             17 BANK0     10     7      3
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (1) _Read_Temperature                                    12    12      0    5143
;!                                             17 BANK0     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  32    32      0   12476
;!                                             17 BANK0     32    32      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8    1605
;!                                              2 COMMON     8     0      8
;!                                              0 BANK0      4     4      0
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1328
;!                                              4 BANK0     13     5      8
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (3) _ADC_Sample                                          18    17      1    1030
;!                                              2 COMMON     5     4      1
;!                                              0 BANK0     13    13      0
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    6430
;!                                             10 BANK0      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    2637
;!                                              5 COMMON     2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_number                                    10     8      2    2628
;!                                              0 BANK0     10     8      2
;!                             ___bmul (ARG)
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     102
;!                                              2 COMMON     3     3      0
;! ---------------------------------------------------------------------------------
;! (3) ___lwmod                                              5     1      4     378
;!                                              2 COMMON     5     1      4
;! ---------------------------------------------------------------------------------
;! (2) ___lwdiv                                              7     3      4     777
;!                                              2 COMMON     7     3      4
;! ---------------------------------------------------------------------------------
;! (1) _CCCV_Control                                        21    21      0    2585
;!                                              0 BANK0     21    21      0
;!                            ___awdiv
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1     836
;!                                              2 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (2) ___awdiv                                              8     4      4     428
;!                                              2 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 3
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            2     2      0       0
;!                                              0 COMMON     2     2      0
;!                 _PowerOnLedSequence
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 5
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     ___bmul
;!   _Get_Vcc
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Read_Temperature
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!   _Slot_Charge_Ctrl
;!     _Adc_Norm
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!     _Detect_BatteryType
;!     _Get_Vcc
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___wmul
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _Update_LED_Global
;!     ___bmul
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _PowerOnLedSequence
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50      0      10       8       20.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      0      48      10       90.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50      0      50       6      100.0%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     43      4F       4       98.8%
;!BITBANK0            50      0       0       3        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      A       C       1       85.7%
;!BITCOMMON            E      0       1       0        7.1%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     103      12        0.0%
;!ABS                  0      0     103      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 408 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   66[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       2       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_CCCV_Control
;;		_Get_Vcc
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_Slot_Charge_Ctrl
;;		_System_Init
;;		_Update_LED_Global
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"main.c"
	line	408
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"main.c"
	line	408
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 3
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	413
	
l6763:	
	opt asmopt_push
opt asmopt_off
movlw	52
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_main+0)+0+1),f
	movlw	241
movwf	((??_main+0)+0),f
	u10397:
decfsz	((??_main+0)+0),f
	goto	u10397
	decfsz	((??_main+0)+0+1),f
	goto	u10397
opt asmopt_pop

	line	414
# 414 "main.c"
clrwdt ;# 
psect	maintext
	line	417
	
l6765:	
	fcall	_System_Init
	line	420
	
l6767:	
	movlw	low(((STR_37)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_37)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	421
	
l6769:	
	movlw	low(((STR_38)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_38)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	425
	
l406:	
	line	427
# 427 "main.c"
clrwdt ;# 
psect	maintext
	line	430
	
l6771:	
	fcall	_Get_Vcc
	line	433
	
l6773:	
	clrf	(main@i)
	line	435
	
l6779:	
	movf	(main@i),w
	fcall	_Slot_Charge_Ctrl
	line	433
	
l6781:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(main@i),f
	
l6783:	
	movlw	low(0Ch)
	subwf	(main@i),w
	skipc
	goto	u10361
	goto	u10360
u10361:
	goto	l6779
u10360:
	line	439
	
l6785:	
	fcall	_CCCV_Control
	line	442
	
l6787:	
	fcall	_Update_LED_Global
	line	445
	
l6789:	
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u10371
	goto	u10370
u10371:
	goto	l6795
u10370:
	line	447
	
l6791:	
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	448
	
l6793:	
	fcall	_Read_Temperature
	line	453
	
l6795:	
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u10381
	goto	u10380
u10381:
	goto	l406
u10380:
	line	455
	
l6797:	
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	456
	
l6799:	
	fcall	_Print_SystemStatus
	line	457
	fcall	_Print_NtcTemp
	goto	l406
	global	start
	ljmp	start
	opt stack 0
	line	461
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_Update_LED_Global

;; *************** function _Update_LED_Global *****************
;; Defined at:
;;		line 27 in file "led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    9[COMMON] unsigned char 
;;  i               1    8[COMMON] unsigned char 
;;  hasFull         1    7[COMMON] unsigned char 
;;  hasChg          1    6[COMMON] unsigned char 
;;  hasErr          1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         5       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	file	"led.c"
	line	27
global __ptext1
__ptext1:	;psect for function _Update_LED_Global
psect	text1
	file	"led.c"
	line	27
	global	__size_of_Update_LED_Global
	__size_of_Update_LED_Global	equ	__end_of_Update_LED_Global-_Update_LED_Global
	
_Update_LED_Global:	
;incstack = 0
	opt	stack 4
; Regs used in _Update_LED_Global: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	30
	
l6681:	
	clrf	(Update_LED_Global@hasErr)
	line	31
	clrf	(Update_LED_Global@hasChg)
	line	32
	clrf	(Update_LED_Global@hasFull)
	line	34
	clrf	(Update_LED_Global@i)
	line	36
	
l6687:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Global@s)
	line	37
	
l6689:	
		movlw	7
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u10141
	goto	u10140
u10141:
	goto	l6693
u10140:
	line	38
	
l6691:	
	clrf	(Update_LED_Global@hasErr)
	incf	(Update_LED_Global@hasErr),f
	goto	l6703
	line	39
	
l6693:	
	movf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u10151
	goto	u10150
u10151:
	goto	l6699
u10150:
	
l6695:	
		movlw	6
	xorwf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u10161
	goto	u10160
u10161:
	goto	l6699
u10160:
	line	40
	
l6697:	
	clrf	(Update_LED_Global@hasChg)
	incf	(Update_LED_Global@hasChg),f
	goto	l6703
	line	41
	
l6699:	
		movlw	6
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u10171
	goto	u10170
u10171:
	goto	l6703
u10170:
	line	42
	
l6701:	
	clrf	(Update_LED_Global@hasFull)
	incf	(Update_LED_Global@hasFull),f
	line	34
	
l6703:	
	incf	(Update_LED_Global@i),f
	
l6705:	
	movlw	low(0Ch)
	subwf	(Update_LED_Global@i),w
	skipc
	goto	u10181
	goto	u10180
u10181:
	goto	l6687
u10180:
	line	45
	
l6707:	
	movf	((Update_LED_Global@hasErr)),w
	btfsc	status,2
	goto	u10191
	goto	u10190
u10191:
	goto	l6717
u10190:
	line	48
	
l6709:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	49
	
l6711:	
	movlw	low(08h)
	bcf	status, 6	;RP1=0, select bank0
	incf	(_s_ledBlinkCnt),f	;volatile
	subwf	((_s_ledBlinkCnt)),w	;volatile
	skipc
	goto	u10201
	goto	u10200
u10201:
	goto	l6715
u10200:
	line	50
	
l6713:	
	clrf	(_s_ledBlinkCnt)	;volatile
	line	51
	
l6715:	
	movlw	low(04h)
	subwf	(_s_ledBlinkCnt),w	;volatile
	skipnc
	goto	u10211
	goto	u10210
	
u10211:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u10224
u10210:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u10224:
	line	52
	goto	l869
	line	53
	
l6717:	
	movf	((Update_LED_Global@hasChg)),w
	btfsc	status,2
	goto	u10231
	goto	u10230
u10231:
	goto	l6721
u10230:
	line	56
	
l6719:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	57
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	58
	goto	l869
	line	59
	
l6721:	
	movf	((Update_LED_Global@hasFull)),w
	btfsc	status,2
	goto	u10241
	goto	u10240
u10241:
	goto	l867
u10240:
	line	62
	
l6723:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	63
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	64
	goto	l869
	line	65
	
l867:	
	line	68
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	69
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	71
	
l869:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Global
	__end_of_Update_LED_Global:
	signat	_Update_LED_Global,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 68 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         1       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	68
global __ptext2
__ptext2:	;psect for function _System_Init
psect	text2
	file	"main.c"
	line	68
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 4
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	73
	
l5317:	
# 73 "main.c"
nop ;# 
	line	74
# 74 "main.c"
clrwdt ;# 
psect	text2
	line	75
	
l5319:	
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	79
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	80
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	81
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l5321:	
	clrf	(262)^0100h	;volatile
	line	83
	
l5323:	
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l5325:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	86
	
l5327:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l5329:	
	clrf	(135)^080h	;volatile
	line	87
	
l5331:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l5333:	
	clrf	(7)	;volatile
	line	88
	
l5335:	
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	89
	
l5337:	
	clrf	(277)^0100h	;volatile
	line	92
	
l5339:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l5341:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	95
	
l5343:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	96
	
l5345:	
	clrf	(406)^0180h	;volatile
	line	103
	
l5347:	
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	104
	
l5349:	
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	105
	
l5351:	
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	106
	
l5353:	
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	109
	
l5355:	
	fcall	_AD_Init
	line	113
	
l5357:	
	fcall	_uart_init
	line	120
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	121
	
l5359:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	122
	
l5361:	
	bcf	(90/8),(90)&7	;volatile
	line	123
	
l5363:	
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	127
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	128
	clrf	(_g_pwmCounter)	;volatile
	line	129
	
l5365:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	130
	
l5367:	
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	131
	
l5369:	
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	132
	
l5371:	
	bcf	(55/8),(55)&7	;volatile
	line	135
	clrf	(System_Init@i)
	line	137
	
l5377:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	138
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	139
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	140
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	141
	
l5379:	
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	142
	
l5381:	
	movf	(System_Init@i),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	135
	
l5383:	
	incf	(System_Init@i),f
	
l5385:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u7441
	goto	u7440
u7441:
	goto	l5377
u7440:
	line	146
	
l339:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"uart_dbg.c"
	line	21
global __ptext3
__ptext3:	;psect for function _uart_init
psect	text3
	file	"uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 4
; Regs used in _uart_init: []
	line	23
	
l3333:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l443:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	23
global __ptext4
__ptext4:	;psect for function _AD_Init
psect	text4
	file	"adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 4
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l3327:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
	clrf	(406)^0180h	;volatile
	line	27
	
l3329:	
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l3331:	
	clrf	(150)^080h	;volatile
	line	29
	
l420:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Slot_Charge_Ctrl

;; *************** function _Slot_Charge_Ctrl *****************
;; Defined at:
;;		line 199 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   63[BANK0 ] unsigned char 
;;  tc              1   42[BANK0 ] unsigned char 
;;  hasRise         1   36[BANK0 ] unsigned char 
;;  pre             2   53[BANK0 ] unsigned int 
;;  diff            2   43[BANK0 ] int 
;;  v_ref           2   39[BANK0 ] unsigned int 
;;  v_init          2   32[BANK0 ] unsigned int 
;;  newv            2   37[BANK0 ] unsigned int 
;;  bat_mv_long     4   49[BANK0 ] unsigned long 
;;  vx_mv           4   45[BANK0 ] unsigned long 
;;  v               2   61[BANK0 ] unsigned int 
;;  ct              2   59[BANK0 ] unsigned int 
;;  bat_mv          2   55[BANK0 ] unsigned int 
;;  ty              1   58[BANK0 ] unsigned char 
;;  st              1   57[BANK0 ] unsigned char 
;;  dly             1   41[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      32       0       0       0
;;      Temps:          0       5       0       0       0
;;      Totals:         0      37       0       0       0
;;Total ram usage:       37 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Adc_Norm
;;		_Detect_BatteryType
;;		_Get_Vcc
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___wmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	199
global __ptext5
__ptext5:	;psect for function _Slot_Charge_Ctrl
psect	text5
	file	"charge_mgr.c"
	line	199
	global	__size_of_Slot_Charge_Ctrl
	__size_of_Slot_Charge_Ctrl	equ	__end_of_Slot_Charge_Ctrl-_Slot_Charge_Ctrl
	
_Slot_Charge_Ctrl:	
;incstack = 0
	opt	stack 3
; Regs used in _Slot_Charge_Ctrl: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	movwf	(Slot_Charge_Ctrl@idx)
	line	207
	
l531:	
	
l5581:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@st)
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@ty)
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@v)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v+1)
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@ct)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@ct+1)
	goto	l5585
	line	210
	
l535:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l5587
	
l537:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l5587
	
l538:	
	bsf	(51/8),(51)&7	;volatile
	goto	l5587
	
l539:	
	bsf	(50/8),(50)&7	;volatile
	goto	l5587
	
l540:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l5587
	
l541:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l5587
	
l542:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l5587
	
l543:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l5587
	
l544:	
	bsf	(48/8),(48)&7	;volatile
	goto	l5587
	
l545:	
	bsf	(49/8),(49)&7	;volatile
	goto	l5587
	
l546:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l5587
	
l547:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l5587
	
l5585:	
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l535
	xorlw	1^0	; case 1
	skipnz
	goto	l537
	xorlw	2^1	; case 2
	skipnz
	goto	l538
	xorlw	3^2	; case 3
	skipnz
	goto	l539
	xorlw	4^3	; case 4
	skipnz
	goto	l540
	xorlw	5^4	; case 5
	skipnz
	goto	l541
	xorlw	6^5	; case 6
	skipnz
	goto	l542
	xorlw	7^6	; case 7
	skipnz
	goto	l543
	xorlw	8^7	; case 8
	skipnz
	goto	l544
	xorlw	9^8	; case 9
	skipnz
	goto	l545
	xorlw	10^9	; case 10
	skipnz
	goto	l546
	xorlw	11^10	; case 11
	skipnz
	goto	l547
	goto	l5587
	opt asmopt_pop

	line	211
	
l5587:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
		decf	((Slot_Charge_Ctrl@st)),w
	btfsc	status,2
	goto	u7641
	goto	u7640
u7641:
	goto	l5593
u7640:
	
l5589:	
		movlw	8
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfsc	status,2
	goto	u7651
	goto	u7650
u7651:
	goto	l5593
u7650:
	
l5591:	
		movlw	9
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfss	status,2
	goto	u7661
	goto	u7660
u7661:
	goto	l5605
u7660:
	line	214
	
l5593:	
	clrf	(Slot_Charge_Ctrl@dly)
	
l5595:	
	movlw	low(014h)
	subwf	(Slot_Charge_Ctrl@dly),w
	skipc
	goto	u7671
	goto	u7670
u7671:
	goto	l5599
u7670:
	goto	l5607
	line	215
	
l5599:	
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u10407:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u10407
	nop
opt asmopt_pop

	line	214
	
l5601:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Slot_Charge_Ctrl@dly),f
	goto	l5595
	line	219
	
l5605:	
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u10417:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u10417
	nop
opt asmopt_pop

	line	223
	
l5607:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	fcall	_Adc_Norm
	movf	(1+(?_Adc_Norm)),w
	movwf	(Slot_Charge_Ctrl@newv+1)
	movf	(0+(?_Adc_Norm)),w
	movwf	(Slot_Charge_Ctrl@newv)
	line	227
	
l5609:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfss	status,2
	goto	u7681
	goto	u7680
u7681:
	goto	l5617
u7680:
	
l5611:	
		movlw	4
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfsc	status,2
	goto	u7691
	goto	u7690
u7691:
	goto	l5615
u7690:
	
l5613:	
		movlw	5
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfss	status,2
	goto	u7701
	goto	u7700
u7701:
	goto	l5617
u7700:
	
l5615:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@newv+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@newv),w
	skipnc
	goto	u7711
	goto	u7710
u7711:
	goto	l6509
u7710:
	line	229
	
l5617:	
	movf	(Slot_Charge_Ctrl@newv+1),w
	movwf	(Slot_Charge_Ctrl@v+1)
	movf	(Slot_Charge_Ctrl@newv),w
	movwf	(Slot_Charge_Ctrl@v)
	goto	l6509
	line	240
	
l5619:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u7721
	goto	u7720
u7721:
	goto	l5625
u7720:
	line	242
	
l5621:	
	movlw	01h
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	080h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipnc
	goto	u7731
	goto	u7730
u7731:
	goto	l5625
u7730:
	line	244
	
l5623:	
	incf	(Slot_Charge_Ctrl@ct),f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1),f
	line	245
	goto	l6511
	line	248
	
l5625:	
	clrf	(Slot_Charge_Ctrl@ct)
	clrf	(Slot_Charge_Ctrl@ct+1)
	line	249
	
l5627:	
	clrf	(Slot_Charge_Ctrl@st)
	incf	(Slot_Charge_Ctrl@st),f
	line	250
	
l5629:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	252
	
l5631:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7744
u7745:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7744:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7745
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	255
	
l5633:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipnc
	goto	u7751
	goto	u7750
u7751:
	goto	l5637
u7750:
	line	256
	
l5635:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v),w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	indf
	goto	l6511
	line	258
	
l5637:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l6511
	line	262
	
l5639:	
	incf	(Slot_Charge_Ctrl@ct),f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1),f
	line	265
	
l5641:	
		decf	((Slot_Charge_Ctrl@ct)),w
iorwf	((Slot_Charge_Ctrl@ct+1)),w
	btfss	status,2
	goto	u7761
	goto	u7760
u7761:
	goto	l5647
u7760:
	line	267
	
l5643:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	268
	
l5645:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7774
u7775:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7774:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7775
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	271
	
l5647:	
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	020h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipnc
	goto	u7781
	goto	u7780
u7781:
	goto	l5651
u7780:
	goto	l6511
	line	289
	
l5651:	
		movlw	32
	xorwf	((Slot_Charge_Ctrl@ct)),w
iorwf	((Slot_Charge_Ctrl@ct+1)),w
	btfss	status,2
	goto	u7791
	goto	u7790
u7791:
	goto	l5659
u7790:
	line	291
	
l5653:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	indf
	line	292
	
l5655:	
	movlw	0Bh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	055h
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u7801
	goto	u7800
u7801:
	goto	l6511
u7800:
	line	293
	
l5657:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7814
u7815:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7814:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7815
	
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag+1)^080h,f
	goto	l6511
	line	296
	
l5659:	
	movlw	0Bh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	055h
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u7821
	goto	u7820
u7821:
	goto	l5721
u7820:
	
l5661:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipnc
	goto	u7831
	goto	u7830
u7831:
	goto	l5721
u7830:
	line	308
	
l5663:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7844
u7845:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7844:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7845
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfss	status,2
	goto	u7851
	goto	u7850
u7851:
	goto	l5677
u7850:
	
l5665:	
		movlw	5
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfsc	status,2
	goto	u7861
	goto	u7860
u7861:
	goto	l5677
u7860:
	
l5667:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0ADh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipnc
	goto	u7871
	goto	u7870
u7871:
	goto	l5677
u7870:
	line	310
	
l5669:	
	clrf	(Slot_Charge_Ctrl@ct)
	clrf	(Slot_Charge_Ctrl@ct+1)
	line	311
	
l5671:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	312
	
l5673:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	313
	
l5675:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	314
	goto	l6511
	line	324
	
l5677:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_init)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_init+1)
	line	326
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipc
	goto	u7881
	goto	u7880
u7881:
	goto	l5707
u7880:
	line	331
	
l5679:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7894
u7895:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7894:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7895
	
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag+1)^080h,f
	line	333
	
l5681:	
	movlw	0Bh
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	055h
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipnc
	goto	u7901
	goto	u7900
u7901:
	goto	l5689
u7900:
	line	336
	
l5683:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7914
u7915:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7914:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7915
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	337
	
l5685:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	338
	
l5687:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7924
u7925:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7924:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7925
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	339
	goto	l5733
	line	340
	
l5689:	
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	0A0h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipnc
	goto	u7931
	goto	u7930
u7931:
	goto	l5701
u7930:
	line	349
	
l5691:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7944
u7945:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7944:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7945
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u7951
	goto	u7950
u7951:
	goto	l5635
u7950:
	
l5693:	
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	039h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipc
	goto	u7961
	goto	u7960
u7961:
	goto	l5635
u7960:
	line	362
	
l5701:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7974
u7975:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7974:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7975
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	363
	
l5703:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	364
	
l5705:	
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@ty)
	line	365
	goto	l5763
	line	371
	
l5707:	
	movf	(Slot_Charge_Ctrl@v),w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v+1),w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v_init+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u7985
	movf	(Slot_Charge_Ctrl@v_init),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u7985:
	skipnc
	goto	u7981
	goto	u7980
u7981:
	goto	l5711
u7980:
	line	374
	
l5709:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v),w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	indf
	line	375
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	376
	goto	l584
	line	380
	
l5711:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v),w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	indf
	line	381
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	382
	
l584:	
	line	383
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u7991
	goto	u7990
u7991:
	goto	l5715
u7990:
	goto	l6511
	line	386
	
l5715:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8004
u8005:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8004:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8005
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u8011
	goto	u8010
u8011:
	goto	l5719
u8010:
	goto	l6511
	line	388
	
l5719:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l5733
	line	391
	
l5721:	
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	0A0h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipnc
	goto	u8021
	goto	u8020
u8021:
	goto	l5733
u8020:
	
l5723:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipnc
	goto	u8031
	goto	u8030
u8031:
	goto	l5733
u8030:
	line	393
	
l5725:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_ref)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_ref+1)
	line	394
	
l5727:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v_ref+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v_ref),w
	skipnc
	goto	u8041
	goto	u8040
u8041:
	goto	l5733
u8040:
	
l5729:	
	movf	(Slot_Charge_Ctrl@v),w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v+1),w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v_ref+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8055
	movf	(Slot_Charge_Ctrl@v_ref),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8055:
	skipnc
	goto	u8051
	goto	u8050
u8051:
	goto	l5733
u8050:
	goto	l5635
	line	404
	
l5733:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8064
u8065:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8064:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8065
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u8071
	goto	u8070
u8071:
	goto	l5741
u8070:
	line	406
	
l5735:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8084
u8085:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8084:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8085
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	407
	
l5737:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	408
	
l5739:	
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@ty)
	line	409
	goto	l591
	line	412
	
l5741:	
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	(Detect_BatteryType@voltage+1)
	movf	(Slot_Charge_Ctrl@v),w
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	movwf	(Slot_Charge_Ctrl@ty)
	line	420
	
l5743:	
	movf	((Slot_Charge_Ctrl@ty)),w
	btfss	status,2
	goto	u8091
	goto	u8090
u8091:
	goto	l591
u8090:
	
l5745:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u8101
	goto	u8100
u8101:
	goto	l591
u8100:
	
l5747:	
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	0A0h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipc
	goto	u8111
	goto	u8110
u8111:
	goto	l591
u8110:
	goto	l5739
	line	422
	
l591:	
	line	426
	movlw	01h
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0F4h
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipnc
	goto	u8121
	goto	u8120
u8121:
	goto	l5755
u8120:
	line	428
	
l5751:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	429
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u8131
	goto	u8130
u8131:
	goto	l5763
u8130:
	goto	l6511
	line	433
	
l5755:	
		movlw	5
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfsc	status,2
	goto	u8141
	goto	u8140
u8141:
	goto	l5763
u8140:
	
l5757:	
		decf	((Slot_Charge_Ctrl@ty)),w
	btfsc	status,2
	goto	u8151
	goto	u8150
u8151:
	goto	l5763
u8150:
	
l5759:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfsc	status,2
	goto	u8161
	goto	u8160
u8161:
	goto	l5763
u8160:
	line	435
	
l5761:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	439
	
l5763:	
		movlw	5
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfss	status,2
	goto	u8171
	goto	u8170
u8171:
	goto	l5785
u8170:
	line	446
	
l5765:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	447
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8181
	goto	u8180
u8181:
	goto	l5769
u8180:
	goto	l6511
	line	451
	
l5769:	
		incf	((_g_impCheckSlot)),w
	btfsc	status,2
	goto	u8191
	goto	u8190
u8191:
	goto	l5775
u8190:
	
l5771:	
	movf	(_g_impCheckSlot),w
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipnz
	goto	u8201
	goto	u8200
u8201:
	goto	l5775
u8200:
	goto	l6511
	line	453
	
l5775:	
	movf	(Slot_Charge_Ctrl@idx),w
	movwf	(_g_impCheckSlot)
	line	457
	
l5777:	
	fcall	_Get_Vcc
	line	461
	
l5779:	
	movlw	064h
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(032h)
	movwf	(___lwdiv@dividend)
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_impData+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_g_impData)
	movlw	0Ch
	
u8215:
	clrc
	rlf	(_g_impData),f
	rlf	(_g_impData+1),f
	addlw	-1
	skipz
	goto	u8215
	movlw	(0A000h >> 8)
	addwf	(_g_impData+1),f
	movf	(Slot_Charge_Ctrl@v),w
	iorwf	(_g_impData),f
	movf	(Slot_Charge_Ctrl@v+1),w
	iorwf	(_g_impData+1),f
	line	462
	movlw	low(08h)
	movwf	(Slot_Charge_Ctrl@st)
	line	463
	
l5781:	
	clrf	(Slot_Charge_Ctrl@ct)
	clrf	(Slot_Charge_Ctrl@ct+1)
	line	464
	
l5783:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	466
	
l5785:	
		decf	((Slot_Charge_Ctrl@ty)),w
	btfsc	status,2
	goto	u8221
	goto	u8220
u8221:
	goto	l5789
u8220:
	
l5787:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfss	status,2
	goto	u8231
	goto	u8230
u8231:
	goto	l5839
u8230:
	line	469
	
l5789:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	470
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8241
	goto	u8240
u8241:
	goto	l5793
u8240:
	goto	l6511
	line	472
	
l5793:	
	movf	(Slot_Charge_Ctrl@v),w
	movwf	(___lmul@multiplier)
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv)

	
l5795:	
	movlw	0Ch
u8255:
	clrc
	rrf	(Slot_Charge_Ctrl@vx_mv+3),f
	rrf	(Slot_Charge_Ctrl@vx_mv+2),f
	rrf	(Slot_Charge_Ctrl@vx_mv+1),f
	rrf	(Slot_Charge_Ctrl@vx_mv),f
	addlw	-1
	skipz
	goto	u8255

	
l5797:	
	movf	(Slot_Charge_Ctrl@vx_mv+3),w
	movwf	(___lmul@multiplier+3)
	movf	(Slot_Charge_Ctrl@vx_mv+2),w
	movwf	(___lmul@multiplier+2)
	movf	(Slot_Charge_Ctrl@vx_mv+1),w
	movwf	(___lmul@multiplier+1)
	movf	(Slot_Charge_Ctrl@vx_mv),w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long+3)
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long+2)
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long+1)
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long)

	
l5799:	
	movlw	070h
	addwf	(Slot_Charge_Ctrl@bat_mv_long),f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Slot_Charge_Ctrl@bat_mv_long+1),f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Slot_Charge_Ctrl@bat_mv_long+2),f
	movlw	0
	skipnc
movlw 1
	addwf	(Slot_Charge_Ctrl@bat_mv_long+3),f
	
l5801:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Slot_Charge_Ctrl+0)+0)
	movlw	01h
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+2)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+3)
	movf	(Slot_Charge_Ctrl@bat_mv_long),w
	addwf	(??_Slot_Charge_Ctrl+0)+0,f
	movf	(Slot_Charge_Ctrl@bat_mv_long+1),w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long+1),w
	goto	u8260
	goto	u8261
u8260:
	addwf	(??_Slot_Charge_Ctrl+0)+1,f
u8261:
	movf	(Slot_Charge_Ctrl@bat_mv_long+2),w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long+2),w
	goto	u8262
	goto	u8263
u8262:
	addwf	(??_Slot_Charge_Ctrl+0)+2,f
u8263:
	movf	(Slot_Charge_Ctrl@bat_mv_long+3),w
	skipnc
	incf	(Slot_Charge_Ctrl@bat_mv_long+3),w
	addwf	(??_Slot_Charge_Ctrl+0)+3,f
	movf	3+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@bat_mv+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@bat_mv)
	
l5803:	
	movlw	0
	subwf	(Slot_Charge_Ctrl@bat_mv+1),w
	movlw	065h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv),w
	skipnc
	goto	u8271
	goto	u8270
u8271:
	goto	l5807
u8270:
	
l5805:	
	movlw	low(02h)
	movwf	(Slot_Charge_Ctrl@st)
	goto	l5833
	
l5807:	
	movlw	03h
	subwf	(Slot_Charge_Ctrl@bat_mv+1),w
	movlw	084h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv),w
	skipnc
	goto	u8281
	goto	u8280
u8281:
	goto	l5811
u8280:
	
l5809:	
	movlw	low(03h)
	movwf	(Slot_Charge_Ctrl@st)
	goto	l5833
	
l5811:	
	movlw	05h
	subwf	(Slot_Charge_Ctrl@bat_mv+1),w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv),w
	skipc
	goto	u8291
	goto	u8290
u8291:
	goto	l5825
u8290:
	
l5813:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bcf	status, 7	;select IRP bank1
	subwf	indf,w
	skipc
	goto	u8301
	goto	u8300
u8301:
	goto	l5817
u8300:
	
l5815:	
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)
	goto	l5833
	
l5817:	
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@st)
	
l5819:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v),w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	indf
	
l5821:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l5823:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l5833
	
l5825:	
	movlw	low(04h)
	movwf	(Slot_Charge_Ctrl@st)
	
l5827:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(080h)
	bcf	status, 7	;select IRP bank1
	andwf	indf,f
	
l5829:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v),w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	indf
	goto	l5823
	
l5833:	
	clrf	(Slot_Charge_Ctrl@ct)
	clrf	(Slot_Charge_Ctrl@ct+1)
	
l5835:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l5675
	line	474
	
l5839:	
	movf	((Slot_Charge_Ctrl@ty)),w
	btfss	status,2
	goto	u8311
	goto	u8310
u8311:
	goto	l5849
u8310:
	line	479
	
l5841:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u8321
	goto	u8320
u8321:
	goto	l5845
u8320:
	goto	l6511
	line	481
	
l5845:	
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)
	goto	l5675
	line	484
	
l5849:	
		movlw	2
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfsc	status,2
	goto	u8331
	goto	u8330
u8331:
	goto	l5845
u8330:
	
l5851:	
		movlw	3
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfss	status,2
	goto	u8341
	goto	u8340
u8341:
	goto	l6511
u8340:
	goto	l5845
	line	492
	
l5857:	
	incf	(Slot_Charge_Ctrl@ct),f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1),f
	line	493
	
l5859:	
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	05h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipnc
	goto	u8351
	goto	u8350
u8351:
	goto	l5863
u8350:
	goto	l6511
	line	498
	
l5863:	
	fcall	_Get_Vcc
	line	504
	
l5865:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0D2h
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u8361
	goto	u8360
u8361:
	goto	l5875
u8360:
	
l5867:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0D2h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u8371
	goto	u8370
u8371:
	goto	l5875
u8370:
	line	506
	
l5869:	
	clrf	(Slot_Charge_Ctrl@ty)
	line	507
	clrf	(Slot_Charge_Ctrl@st)
	line	508
	
l5871:	
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)
	line	509
	
l5873:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8384
u8385:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8384:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8385
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	510
	goto	l6511
	line	516
	
l5875:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(012Ch)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(012Ch)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8395
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8395:
	skipnc
	goto	u8391
	goto	u8390
u8391:
	goto	l5883
u8390:
	
l5877:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u8401
	goto	u8400
u8401:
	goto	l5883
u8400:
	line	518
	
l5879:	
	movlw	low(02h)
	movwf	(Slot_Charge_Ctrl@ty)
	line	519
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)
	line	520
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)
	goto	l5873
	line	531
	
l5883:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(0C8h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8415
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8415:
	skipnc
	goto	u8411
	goto	u8410
u8411:
	goto	l5889
u8410:
	
l5885:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Ch
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	01Ch
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u8421
	goto	u8420
u8421:
	goto	l5889
u8420:
	goto	l5919
	line	542
	
l5889:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8434
u8435:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8434:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8435
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfss	status,2
	goto	u8441
	goto	u8440
u8441:
	goto	l5901
u8440:
	
l5891:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	(Slot_Charge_Ctrl@v+1),w
	skipz
	goto	u8455
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	(Slot_Charge_Ctrl@v),w
u8455:
	skipnc
	goto	u8451
	goto	u8450
u8451:
	goto	l5901
u8450:
	
l5893:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	(Slot_Charge_Ctrl@v+1),w
	skipc
	incf	(Slot_Charge_Ctrl@v+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	03h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0E9h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipc
	goto	u8461
	goto	u8460
u8461:
	goto	l5901
u8460:
	line	544
	
l5895:	
	movlw	low(03h)
	movwf	(Slot_Charge_Ctrl@ty)
	line	545
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)
	line	546
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)
	line	547
	
l5897:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8474
u8475:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8474:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8475
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	goto	l5675
	line	556
	
l5901:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Dh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0ADh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u8481
	goto	u8480
u8481:
	goto	l5907
u8480:
	
l5903:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(0C8h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8495
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8495:
	skipc
	goto	u8491
	goto	u8490
u8491:
	goto	l5907
u8490:
	goto	l5911
	line	563
	
l5907:	
	line	569
	
l5911:	
	movlw	low(09h)
	movwf	(Slot_Charge_Ctrl@st)
	line	570
	
l5913:	
	clrf	(Slot_Charge_Ctrl@ct)
	clrf	(Slot_Charge_Ctrl@ct+1)
	line	571
	
l5915:	
	clrf	(_g_diodeTraceCnt)
	line	572
	movf	(Slot_Charge_Ctrl@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_diodeTraceSlot)^080h
	goto	l5873
	line	579
	
l5919:	
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)
	line	580
	
l5921:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8504
u8505:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8504:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8505
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	581
	
l5923:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Slot_Charge_Ctrl@ty)
	incf	(Slot_Charge_Ctrl@ty),f
	line	582
	
l5925:	
	movf	(Slot_Charge_Ctrl@v),w
	movwf	(___lmul@multiplier)
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv)

	
l5927:	
	movlw	0Ch
u8515:
	clrc
	rrf	(Slot_Charge_Ctrl@vx_mv+3),f
	rrf	(Slot_Charge_Ctrl@vx_mv+2),f
	rrf	(Slot_Charge_Ctrl@vx_mv+1),f
	rrf	(Slot_Charge_Ctrl@vx_mv),f
	addlw	-1
	skipz
	goto	u8515

	
l5929:	
	movf	(Slot_Charge_Ctrl@vx_mv+3),w
	movwf	(___lmul@multiplier+3)
	movf	(Slot_Charge_Ctrl@vx_mv+2),w
	movwf	(___lmul@multiplier+2)
	movf	(Slot_Charge_Ctrl@vx_mv+1),w
	movwf	(___lmul@multiplier+1)
	movf	(Slot_Charge_Ctrl@vx_mv),w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long+3)
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long+2)
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long+1)
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long)

	movlw	070h
	addwf	(Slot_Charge_Ctrl@bat_mv_long),f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Slot_Charge_Ctrl@bat_mv_long+1),f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Slot_Charge_Ctrl@bat_mv_long+2),f
	movlw	0
	skipnc
movlw 1
	addwf	(Slot_Charge_Ctrl@bat_mv_long+3),f
	
l5931:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Slot_Charge_Ctrl+0)+0)
	movlw	01h
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+2)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+3)
	movf	(Slot_Charge_Ctrl@bat_mv_long),w
	addwf	(??_Slot_Charge_Ctrl+0)+0,f
	movf	(Slot_Charge_Ctrl@bat_mv_long+1),w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long+1),w
	goto	u8520
	goto	u8521
u8520:
	addwf	(??_Slot_Charge_Ctrl+0)+1,f
u8521:
	movf	(Slot_Charge_Ctrl@bat_mv_long+2),w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long+2),w
	goto	u8522
	goto	u8523
u8522:
	addwf	(??_Slot_Charge_Ctrl+0)+2,f
u8523:
	movf	(Slot_Charge_Ctrl@bat_mv_long+3),w
	skipnc
	incf	(Slot_Charge_Ctrl@bat_mv_long+3),w
	addwf	(??_Slot_Charge_Ctrl+0)+3,f
	movf	3+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@bat_mv+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@bat_mv)
	
l5933:	
	movlw	0
	subwf	(Slot_Charge_Ctrl@bat_mv+1),w
	movlw	065h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv),w
	skipnc
	goto	u8531
	goto	u8530
u8531:
	goto	l5937
u8530:
	goto	l5805
	
l5937:	
	movlw	03h
	subwf	(Slot_Charge_Ctrl@bat_mv+1),w
	movlw	084h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv),w
	skipnc
	goto	u8541
	goto	u8540
u8541:
	goto	l5941
u8540:
	goto	l5809
	
l5941:	
	movlw	05h
	subwf	(Slot_Charge_Ctrl@bat_mv+1),w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv),w
	skipc
	goto	u8551
	goto	u8550
u8551:
	goto	l5825
u8550:
	
l5943:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bcf	status, 7	;select IRP bank1
	subwf	indf,w
	skipc
	goto	u8561
	goto	u8560
u8561:
	goto	l5817
u8560:
	goto	l5815
	line	593
	
l5969:	
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)
	line	594
	
l5971:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8574
u8575:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8574:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8575
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	595
	
l5973:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@ty)
	line	596
	
l5975:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(___lmul@multiplier)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(___lmul@multiplier)
	clrf	2+(___lmul@multiplier)
	clrf	3+(___lmul@multiplier)
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv)

	
l5977:	
	movlw	0Ch
u8585:
	clrc
	rrf	(Slot_Charge_Ctrl@vx_mv+3),f
	rrf	(Slot_Charge_Ctrl@vx_mv+2),f
	rrf	(Slot_Charge_Ctrl@vx_mv+1),f
	rrf	(Slot_Charge_Ctrl@vx_mv),f
	addlw	-1
	skipz
	goto	u8585

	movf	(Slot_Charge_Ctrl@vx_mv+3),w
	movwf	(___lmul@multiplier+3)
	movf	(Slot_Charge_Ctrl@vx_mv+2),w
	movwf	(___lmul@multiplier+2)
	movf	(Slot_Charge_Ctrl@vx_mv+1),w
	movwf	(___lmul@multiplier+1)
	movf	(Slot_Charge_Ctrl@vx_mv),w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long+3)
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long+2)
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long+1)
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long)

	
l5979:	
	movlw	070h
	addwf	(Slot_Charge_Ctrl@bat_mv_long),f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Slot_Charge_Ctrl@bat_mv_long+1),f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Slot_Charge_Ctrl@bat_mv_long+2),f
	movlw	0
	skipnc
movlw 1
	addwf	(Slot_Charge_Ctrl@bat_mv_long+3),f
	
l5981:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Slot_Charge_Ctrl+0)+0)
	movlw	01h
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+2)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+3)
	movf	(Slot_Charge_Ctrl@bat_mv_long),w
	addwf	(??_Slot_Charge_Ctrl+0)+0,f
	movf	(Slot_Charge_Ctrl@bat_mv_long+1),w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long+1),w
	goto	u8590
	goto	u8591
u8590:
	addwf	(??_Slot_Charge_Ctrl+0)+1,f
u8591:
	movf	(Slot_Charge_Ctrl@bat_mv_long+2),w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long+2),w
	goto	u8592
	goto	u8593
u8592:
	addwf	(??_Slot_Charge_Ctrl+0)+2,f
u8593:
	movf	(Slot_Charge_Ctrl@bat_mv_long+3),w
	skipnc
	incf	(Slot_Charge_Ctrl@bat_mv_long+3),w
	addwf	(??_Slot_Charge_Ctrl+0)+3,f
	movf	3+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@bat_mv+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@bat_mv)
	movlw	0
	subwf	(Slot_Charge_Ctrl@bat_mv+1),w
	movlw	065h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv),w
	skipnc
	goto	u8601
	goto	u8600
u8601:
	goto	l5985
u8600:
	goto	l5805
	
l5985:	
	movlw	03h
	subwf	(Slot_Charge_Ctrl@bat_mv+1),w
	movlw	084h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv),w
	skipnc
	goto	u8611
	goto	u8610
u8611:
	goto	l5989
u8610:
	goto	l5809
	
l5989:	
	movlw	05h
	subwf	(Slot_Charge_Ctrl@bat_mv+1),w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv),w
	skipc
	goto	u8621
	goto	u8620
u8621:
	goto	l6003
u8620:
	
l5991:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bcf	status, 7	;select IRP bank1
	subwf	indf,w
	skipc
	goto	u8631
	goto	u8630
u8631:
	goto	l5995
u8630:
	goto	l5815
	
l5995:	
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@st)
	
l5997:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	indf
	goto	l5821
	
l6003:	
	movlw	low(04h)
	movwf	(Slot_Charge_Ctrl@st)
	
l6005:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(080h)
	bcf	status, 7	;select IRP bank1
	andwf	indf,f
	
l6007:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	indf
	goto	l5823
	line	606
	
l6017:	
	incf	(Slot_Charge_Ctrl@ct),f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1),f
	line	612
	
l6019:	
		movlw	7
	xorwf	((Slot_Charge_Ctrl@ct)),w
iorwf	((Slot_Charge_Ctrl@ct+1)),w
	btfsc	status,2
	goto	u8641
	goto	u8640
u8641:
	goto	l6027
u8640:
	
l6021:	
		movlw	14
	xorwf	((Slot_Charge_Ctrl@ct)),w
iorwf	((Slot_Charge_Ctrl@ct+1)),w
	btfsc	status,2
	goto	u8651
	goto	u8650
u8651:
	goto	l6027
u8650:
	
l6023:	
		movlw	21
	xorwf	((Slot_Charge_Ctrl@ct)),w
iorwf	((Slot_Charge_Ctrl@ct+1)),w
	btfsc	status,2
	goto	u8661
	goto	u8660
u8661:
	goto	l6027
u8660:
	
l6025:	
		movlw	28
	xorwf	((Slot_Charge_Ctrl@ct)),w
iorwf	((Slot_Charge_Ctrl@ct+1)),w
	btfss	status,2
	goto	u8671
	goto	u8670
u8671:
	goto	l6043
u8670:
	
l6027:	
	movlw	low(04h)
	subwf	(_g_diodeTraceCnt),w
	skipnc
	goto	u8681
	goto	u8680
u8681:
	goto	l6043
u8680:
	line	614
	
l6029:	
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	(Slot_Charge_Ctrl@diff+1)
	movf	(Slot_Charge_Ctrl@v),w
	movwf	(Slot_Charge_Ctrl@diff)
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	(Slot_Charge_Ctrl@diff),f
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	decf	(Slot_Charge_Ctrl@diff+1),f
	subwf	(Slot_Charge_Ctrl@diff+1),f
	line	615
	rlf	(Slot_Charge_Ctrl@diff+1),w
	rrf	(Slot_Charge_Ctrl@diff+1),f
	rrf	(Slot_Charge_Ctrl@diff),f
	rlf	(Slot_Charge_Ctrl@diff+1),w
	rrf	(Slot_Charge_Ctrl@diff+1),f
	rrf	(Slot_Charge_Ctrl@diff),f
	line	616
	
l6031:	
	movf	(Slot_Charge_Ctrl@diff+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u8695
	movlw	080h
	subwf	(Slot_Charge_Ctrl@diff),w
u8695:

	skipc
	goto	u8691
	goto	u8690
u8691:
	goto	l6035
u8690:
	
l6033:	
	movlw	07Fh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff)
	clrf	(Slot_Charge_Ctrl@diff+1)
	line	617
	
l6035:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@diff+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u8705
	movlw	080h
	subwf	(Slot_Charge_Ctrl@diff),w
u8705:

	skipnc
	goto	u8701
	goto	u8700
u8701:
	goto	l6039
u8700:
	
l6037:	
	movlw	080h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff)
	movlw	0FFh
	movwf	((Slot_Charge_Ctrl@diff))+1
	line	618
	
l6039:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_diodeTraceCnt),w
	addlw	low(_g_diodeTrace|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@diff),w
	addlw	080h
	bsf	status, 7	;select IRP bank3
	movwf	indf
	
l6041:	
	incf	(_g_diodeTraceCnt),f
	line	622
	
l6043:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(0384h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(0384h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	(Slot_Charge_Ctrl@v+1),w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u8715
	movf	(Slot_Charge_Ctrl@v),w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u8715:
	skipnc
	goto	u8711
	goto	u8710
u8711:
	goto	l6051
u8710:
	line	626
	
l6045:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8725
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8725:
	skipnc
	goto	u8721
	goto	u8720
u8721:
	goto	l5969
u8720:
	goto	l5919
	line	643
	
l6051:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Bh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0B9h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u8731
	goto	u8730
u8731:
	goto	l6059
u8730:
	
l6053:	
	movlw	0Bh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	055h
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u8741
	goto	u8740
u8741:
	goto	l6059
u8740:
	
l6055:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	(Slot_Charge_Ctrl@v+1),w
	skipz
	goto	u8755
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	(Slot_Charge_Ctrl@v),w
u8755:
	skipnc
	goto	u8751
	goto	u8750
u8751:
	goto	l6059
u8750:
	goto	l5969
	line	650
	
l6059:	
	movlw	0Bh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	055h
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u8761
	goto	u8760
u8761:
	goto	l6069
u8760:
	
l6061:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u8771
	goto	u8770
u8771:
	goto	l6069
u8770:
	goto	l5895
	line	678
	
l6069:	
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	020h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipc
	goto	u8781
	goto	u8780
u8781:
	goto	l6081
u8780:
	
l6071:	
	movlw	08h
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	035h
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u8791
	goto	u8790
u8791:
	goto	l6081
u8790:
	
l6073:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u8801
	goto	u8800
u8801:
	goto	l6081
u8800:
	
l6075:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v),w
	addlw	low(0A0h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	(Slot_Charge_Ctrl@v+1),w
	skipnc
	addlw	1
	addlw	high(0A0h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u8815
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u8815:
	skipc
	goto	u8811
	goto	u8810
u8811:
	goto	l6081
u8810:
	
l6077:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	(Slot_Charge_Ctrl@v+1),w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u8825
	movf	(Slot_Charge_Ctrl@v),w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u8825:
	skipc
	goto	u8821
	goto	u8820
u8821:
	goto	l6081
u8820:
	goto	l5969
	line	688
	
l6081:	
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	020h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipc
	goto	u8831
	goto	u8830
u8831:
	goto	l6511
u8830:
	line	690
	
l6083:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(Slot_Charge_Ctrl@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Slot_Charge_Ctrl@pre)
	line	696
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0ADh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipc
	goto	u8841
	goto	u8840
u8841:
	goto	l6109
u8840:
	
l6085:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u8851
	goto	u8850
u8851:
	goto	l6109
u8850:
	line	699
	
l6087:	
	clrf	(Slot_Charge_Ctrl@hasRise)
	line	700
	clrf	(Slot_Charge_Ctrl@tc)
	goto	l6095
	line	702
	
l6089:	
	movf	(Slot_Charge_Ctrl@tc),w
	addlw	low(_g_diodeTrace|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(088h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u8861
	goto	u8860
u8861:
	goto	l6093
u8860:
	line	704
	
l6091:	
	clrf	(Slot_Charge_Ctrl@hasRise)
	incf	(Slot_Charge_Ctrl@hasRise),f
	line	705
	goto	l6097
	line	700
	
l6093:	
	incf	(Slot_Charge_Ctrl@tc),f
	
l6095:	
	movf	(_g_diodeTraceCnt),w
	subwf	(Slot_Charge_Ctrl@tc),w
	skipc
	goto	u8871
	goto	u8870
u8871:
	goto	l6089
u8870:
	line	708
	
l6097:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8885
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8885:
	skipnc
	goto	u8881
	goto	u8880
u8881:
	goto	l6101
u8880:
	goto	l5919
	line	710
	
l6101:	
	movf	((Slot_Charge_Ctrl@hasRise)),w
	btfss	status,2
	goto	u8891
	goto	u8890
u8891:
	goto	l5969
u8890:
	goto	l5895
	line	721
	
l6109:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0ADh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u8901
	goto	u8900
u8901:
	goto	l6115
u8900:
	
l6111:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipnc
	goto	u8911
	goto	u8910
u8911:
	goto	l6115
u8910:
	goto	l5969
	line	734
	
l6115:	
	movlw	08h
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FDh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u8921
	goto	u8920
u8921:
	goto	l5895
u8920:
	
l6117:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0ACh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipnc
	goto	u8931
	goto	u8930
u8931:
	goto	l5895
u8930:
	
l6119:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0ACh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u8941
	goto	u8940
u8941:
	goto	l5895
u8940:
	
l6121:	
	movf	(Slot_Charge_Ctrl@v),w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8955
	movf	(Slot_Charge_Ctrl@pre),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8955:
	skipc
	goto	u8951
	goto	u8950
u8951:
	goto	l5895
u8950:
	
l6123:	
	movf	(Slot_Charge_Ctrl@pre),w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8965
	movf	(Slot_Charge_Ctrl@v),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8965:
	skipc
	goto	u8961
	goto	u8960
u8961:
	goto	l5895
u8960:
	goto	l5969
	line	748
	
l6133:	
	incf	(Slot_Charge_Ctrl@ct),f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1),f
	line	749
	
l6135:	
	movlw	03h
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	0C1h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipc
	goto	u8971
	goto	u8970
u8971:
	goto	l6139
u8970:
	line	751
	
l6137:	
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)
	line	752
	goto	l6511
	line	754
	
l6139:	
	movlw	02h
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0EFh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u8981
	goto	u8980
u8981:
	goto	l6145
u8980:
	line	756
	
l6141:	
	movlw	low(03h)
	movwf	(Slot_Charge_Ctrl@st)
	line	757
	
l6143:	
	clrf	(Slot_Charge_Ctrl@ct)
	clrf	(Slot_Charge_Ctrl@ct+1)
	line	758
	goto	l6511
	line	760
	
l6145:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0Ah
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u8991
	goto	u8990
u8991:
	goto	l6511
u8990:
	goto	l6137
	line	768
	
l6149:	
	incf	(Slot_Charge_Ctrl@ct),f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1),f
	line	769
	
l6151:	
	movlw	012h
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	0C1h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipc
	goto	u9001
	goto	u9000
u9001:
	goto	l6155
u9000:
	goto	l6137
	line	774
	
l6155:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0Ah
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u9011
	goto	u9010
u9011:
	goto	l6161
u9010:
	line	776
	
l6157:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	777
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u9021
	goto	u9020
u9021:
	goto	l6163
u9020:
	goto	l6137
	line	785
	
l6161:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	787
	
l6163:	
	movlw	0Ah
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	08Ch
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u9031
	goto	u9030
u9031:
	goto	l6511
u9030:
	line	789
	
l6165:	
	movlw	low(04h)
	movwf	(Slot_Charge_Ctrl@st)
	line	790
	
l6167:	
	clrf	(Slot_Charge_Ctrl@ct)
	clrf	(Slot_Charge_Ctrl@ct+1)
	line	791
	
l6169:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	792
	
l6171:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	793
	
l6173:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	indf
	line	794
	
l6175:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6511
	line	799
	
l6177:	
	incf	(Slot_Charge_Ctrl@ct),f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1),f
	line	800
	
l6179:	
	movlw	025h
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	080h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipc
	goto	u9041
	goto	u9040
u9041:
	goto	l6185
u9040:
	line	802
	
l6181:	
	movlw	080h
	subwf	(Slot_Charge_Ctrl@ct),f
	movlw	025h
	skipc
	decf	(Slot_Charge_Ctrl@ct+1),f
	subwf	(Slot_Charge_Ctrl@ct+1),f
	line	803
	
l6183:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	805
	
l6185:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(012h)
	bcf	status, 7	;select IRP bank1
	subwf	indf,w
	skipc
	goto	u9051
	goto	u9050
u9051:
	goto	l6189
u9050:
	goto	l6137
	line	814
	
l6189:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u9061
	goto	u9060
u9061:
	goto	l6195
u9060:
	
l6191:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfss	status,2
	goto	u9071
	goto	u9070
u9071:
	goto	l6195
u9070:
	goto	l6203
	line	818
	
l6195:	
	movlw	03h
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	0C1h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipnc
	goto	u9081
	goto	u9080
u9081:
	goto	l6199
u9080:
	goto	l6203
	line	828
	
l6199:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	(Slot_Charge_Ctrl@v+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9095
	movf	(Slot_Charge_Ctrl@v),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9095:
	skipnc
	goto	u9091
	goto	u9090
u9091:
	goto	l6203
u9090:
	
l6201:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v),w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	indf
	line	838
	
l6203:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfss	status,2
	goto	u9101
	goto	u9100
u9101:
	goto	l6249
u9100:
	line	840
	
l6205:	
	movlw	07h
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0D0h
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipnc
	goto	u9111
	goto	u9110
u9111:
	goto	l6215
u9110:
	line	842
	
l6207:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	843
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(030h)
	subwf	indf,w
	skipc
	goto	u9121
	goto	u9120
u9121:
	goto	l6217
u9120:
	line	845
	
l6209:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	846
	
l6211:	
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)
	goto	l6143
	line	853
	
l6215:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	872
	
l6217:	
	movlw	01h
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	0
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipc
	goto	u9131
	goto	u9130
u9131:
	goto	l6283
u9130:
	line	874
	
l6219:	
	clrf	(Slot_Charge_Ctrl@ct)
	clrf	(Slot_Charge_Ctrl@ct+1)
	line	875
	
l6221:	
	movlw	0Ah
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u9141
	goto	u9140
u9141:
	goto	l6233
u9140:
	
l6223:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipnc
	goto	u9151
	goto	u9150
u9151:
	goto	l6233
u9150:
	line	877
	
l6225:	
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@st)
	line	878
	
l6227:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l6173
	line	882
	
l6233:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	(Slot_Charge_Ctrl@v+1),w
	skipz
	goto	u9165
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	(Slot_Charge_Ctrl@v),w
u9165:
	skipc
	goto	u9161
	goto	u9160
u9161:
	goto	l6237
u9160:
	line	884
	
l6235:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	885
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v),w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	indf
	line	886
	goto	l6511
	line	887
	
l6237:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(indf),w
	btfsc	status,2
	goto	u9171
	goto	u9170
u9171:
	goto	l6241
u9170:
	goto	l5635
	line	891
	
l6241:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	btfss	indf,(7)&7
	goto	u9181
	goto	u9180
u9181:
	goto	l6245
u9180:
	goto	l6137
	line	897
	
l6245:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(7/8),(7)&7
	line	898
	
l6247:	
	clrf	(Slot_Charge_Ctrl@st)
	incf	(Slot_Charge_Ctrl@st),f
	line	899
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	900
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6511
	line	910
	
l6249:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	(Slot_Charge_Ctrl@v+1),w
	skipz
	goto	u9195
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	(Slot_Charge_Ctrl@v),w
u9195:
	skipnc
	goto	u9191
	goto	u9190
u9191:
	goto	l6253
u9190:
	
l6251:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	(Slot_Charge_Ctrl@v),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	(Slot_Charge_Ctrl@v+1),w
	skipc
	incf	(Slot_Charge_Ctrl@v+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	01h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipnc
	goto	u9201
	goto	u9200
u9201:
	goto	l6255
u9200:
	
l6253:	
	movlw	07h
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0D0h
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipnc
	goto	u9211
	goto	u9210
u9211:
	goto	l6267
u9210:
	line	912
	
l6255:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	913
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9221
	goto	u9220
u9221:
	goto	l6259
u9220:
	goto	l6511
	line	915
	
l6259:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	916
	
l6261:	
	clrf	(Slot_Charge_Ctrl@st)
	incf	(Slot_Charge_Ctrl@st),f
	goto	l6143
	line	922
	
l6267:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	934
	
l6269:	
	movlw	03h
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	0C1h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipnc
	goto	u9231
	goto	u9230
u9231:
	goto	l6275
u9230:
	line	936
	
l6271:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	(Slot_Charge_Ctrl@v+1),w
	skipz
	goto	u9245
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	(Slot_Charge_Ctrl@v),w
u9245:
	skipc
	goto	u9241
	goto	u9240
u9241:
	goto	l6275
u9240:
	line	937
	
l6273:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	939
	
l6275:	
	movlw	03h
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	0C1h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipc
	goto	u9251
	goto	u9250
u9251:
	goto	l6283
u9250:
	
l6277:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(indf),w
	btfss	status,2
	goto	u9261
	goto	u9260
u9261:
	goto	l6283
u9260:
	goto	l6211
	line	953
	
l6283:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u9271
	goto	u9270
u9271:
	goto	l6291
u9270:
	
l6285:	
		decf	((Slot_Charge_Ctrl@ty)),w
	btfss	status,2
	goto	u9281
	goto	u9280
u9281:
	goto	l6291
u9280:
	line	955
	
l6287:	
	movlw	low(06h)
	movwf	(Slot_Charge_Ctrl@st)
	goto	l6143
	line	963
	
l6291:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0Ah
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u9291
	goto	u9290
u9291:
	goto	l6299
u9290:
	
l6293:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfsc	status,2
	goto	u9301
	goto	u9300
u9301:
	goto	l6299
u9300:
	line	965
	
l6295:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	966
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u9311
	goto	u9310
u9311:
	goto	l564
u9310:
	goto	l6137
	line	974
	
l6299:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	976
	
l6301:	
	movlw	0Ch
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	01Ch
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u9321
	goto	u9320
u9321:
	goto	l564
u9320:
	
l6303:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u9331
	goto	u9330
u9331:
	goto	l6307
u9330:
	
l6305:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfsc	status,2
	goto	u9341
	goto	u9340
u9341:
	goto	l564
u9340:
	line	978
	
l6307:	
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@st)
	line	979
	
l6309:	
	clrf	(Slot_Charge_Ctrl@ct)
	clrf	(Slot_Charge_Ctrl@ct+1)
	line	980
	
l6311:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l6511
	line	987
	
l6313:	
	incf	(Slot_Charge_Ctrl@ct),f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1),f
	line	988
	
l6315:	
	movlw	025h
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	081h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipc
	goto	u9351
	goto	u9350
u9351:
	goto	l724
u9350:
	line	989
	
l6317:	
	movlw	low(06h)
	movwf	(Slot_Charge_Ctrl@st)
	
l724:	
	line	997
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u9361
	goto	u9360
u9361:
	goto	l6323
u9360:
	
l6319:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfss	status,2
	goto	u9371
	goto	u9370
u9371:
	goto	l6323
u9370:
	goto	l6511
	line	1010
	
l6323:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipnc
	goto	u9381
	goto	u9380
u9381:
	goto	l6345
u9380:
	
l6325:	
	movlw	03h
	subwf	(Slot_Charge_Ctrl@ct+1),w
	movlw	0C1h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct),w
	skipnc
	goto	u9391
	goto	u9390
u9391:
	goto	l6345
u9390:
	
l6327:	
		decf	((Slot_Charge_Ctrl@ty)),w
	btfss	status,2
	goto	u9401
	goto	u9400
u9401:
	goto	l6345
u9400:
	line	1012
	
l6329:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	(indf),w
	btfss	status,2
	goto	u9411
	goto	u9410
u9411:
	goto	l6333
u9410:
	line	1014
	
l6331:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v),w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	indf
	line	1015
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	1016
	goto	l6345
	line	1017
	
l6333:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	(Slot_Charge_Ctrl@v+1),w
	skipz
	goto	u9425
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	(Slot_Charge_Ctrl@v),w
u9425:
	skipc
	goto	u9421
	goto	u9420
u9421:
	goto	l6343
u9420:
	line	1019
	
l6335:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	movlw	low(03h)
	subwf	(indf),w
	skipc
	goto	u9431
	goto	u9430
u9431:
	goto	l728
u9430:
	line	1021
	
l6337:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6211
	line	1029
	
l6343:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6345
	line	1030
	
l728:	
	line	1038
	
l6345:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u9441
	goto	u9440
u9441:
	goto	l6375
u9440:
	line	1040
	
l6347:	
		decf	((Slot_Charge_Ctrl@ty)),w
	btfss	status,2
	goto	u9451
	goto	u9450
u9451:
	goto	l6359
u9450:
	line	1042
	
l6349:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1043
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9461
	goto	u9460
u9461:
	goto	l6353
u9460:
	goto	l6511
	line	1045
	
l6353:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6287
	line	1050
	
l6359:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfss	status,2
	goto	u9471
	goto	u9470
u9471:
	goto	l6363
u9470:
	goto	l6511
	line	1055
	
l6363:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1056
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9481
	goto	u9480
u9481:
	goto	l6367
u9480:
	goto	l6511
	line	1058
	
l6367:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1059
	
l6369:	
	clrf	(Slot_Charge_Ctrl@ty)
	line	1060
	
l6371:	
	clrf	(Slot_Charge_Ctrl@st)
	goto	l6143
	line	1071
	
l6375:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfss	status,2
	goto	u9491
	goto	u9490
u9491:
	goto	l6389
u9490:
	line	1073
	
l6377:	
	movlw	07h
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0D0h
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipnc
	goto	u9501
	goto	u9500
u9501:
	goto	l6387
u9500:
	line	1075
	
l6379:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1076
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(030h)
	subwf	indf,w
	skipc
	goto	u9511
	goto	u9510
u9511:
	goto	l6405
u9510:
	goto	l6209
	line	1086
	
l6387:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l6405
	line	1091
	
l6389:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	(Slot_Charge_Ctrl@v+1),w
	skipz
	goto	u9525
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	(Slot_Charge_Ctrl@v),w
u9525:
	skipnc
	goto	u9521
	goto	u9520
u9521:
	goto	l6387
u9520:
	
l6391:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	(Slot_Charge_Ctrl@v),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	(Slot_Charge_Ctrl@v+1),w
	skipc
	incf	(Slot_Charge_Ctrl@v+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	01h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipc
	goto	u9531
	goto	u9530
u9531:
	goto	l6387
u9530:
	line	1093
	
l6393:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	1094
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipc
	goto	u9541
	goto	u9540
u9541:
	goto	l6405
u9540:
	line	1096
	
l6395:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1097
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	1100
	
l6397:	
	clrf	(Slot_Charge_Ctrl@ty)
	goto	l6261
	line	1116
	
l6405:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0Ah
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u9551
	goto	u9550
u9551:
	goto	l6413
u9550:
	
l6407:	
		decf	((Slot_Charge_Ctrl@ty)),w
	btfss	status,2
	goto	u9561
	goto	u9560
u9561:
	goto	l6413
u9560:
	line	1118
	
l6409:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1119
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u9571
	goto	u9570
u9571:
	goto	l564
u9570:
	goto	l6137
	line	1127
	
l6413:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6511
	line	1138
	
l6415:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u9581
	goto	u9580
u9581:
	goto	l6433
u9580:
	line	1140
	
l6417:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1141
	
l6419:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfsc	status,2
	goto	u9591
	goto	u9590
u9591:
	goto	l6423
u9590:
	
l6421:	
	movlw	02h
	movwf	(_Slot_Charge_Ctrl$380)
	clrf	(_Slot_Charge_Ctrl$380+1)
	goto	l6425
	
l6423:	
	movlw	08h
	movwf	(_Slot_Charge_Ctrl$380)
	clrf	(_Slot_Charge_Ctrl$380+1)
	
l6425:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(_Slot_Charge_Ctrl$380+1),w
	xorlw	80h
	sublw	080h
	skipz
	goto	u9605
	movf	(_Slot_Charge_Ctrl$380),w
	subwf	indf,w
u9605:

	skipc
	goto	u9601
	goto	u9600
u9601:
	goto	l6511
u9600:
	line	1143
	
l6427:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l6371
	line	1152
	
l6433:	
	movlw	0Ah
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipnc
	goto	u9611
	goto	u9610
u9611:
	goto	l5675
u9610:
	line	1154
	
l6435:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1155
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9621
	goto	u9620
u9621:
	goto	l6439
u9620:
	goto	l6511
	line	1157
	
l6439:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1158
	
l6441:	
	movlw	low(04h)
	movwf	(Slot_Charge_Ctrl@st)
	line	1159
	
l6443:	
	clrf	(Slot_Charge_Ctrl@ct)
	clrf	(Slot_Charge_Ctrl@ct+1)
	line	1160
	
l6445:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6227
	line	1174
	
l6455:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u9631
	goto	u9630
u9631:
	goto	l6471
u9630:
	line	1176
	
l6457:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1177
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9641
	goto	u9640
u9641:
	goto	l6461
u9640:
	goto	l6511
	line	1179
	
l6461:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1180
	
l6463:	
	clrf	(Slot_Charge_Ctrl@ty)
	line	1181
	
l6465:	
	clrf	(Slot_Charge_Ctrl@st)
	goto	l6309
	line	1194
	
l6471:	
		movlw	2
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfsc	status,2
	goto	u9651
	goto	u9650
u9651:
	goto	l6475
u9650:
	
l6473:	
		movlw	3
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfss	status,2
	goto	u9661
	goto	u9660
u9661:
	goto	l6491
u9660:
	line	1196
	
l6475:	
	movlw	0Ah
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	08Dh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u9671
	goto	u9670
u9671:
	goto	l5675
u9670:
	
l6477:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9684
u9685:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9684:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9685
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u9691
	goto	u9690
u9691:
	goto	l5675
u9690:
	line	1198
	
l6479:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1199
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9701
	goto	u9700
u9701:
	goto	l6259
u9700:
	goto	l6511
	line	1212
	
l6491:	
	movlw	02h
	subwf	(Slot_Charge_Ctrl@v+1),w
	movlw	0EFh
	skipnz
	subwf	(Slot_Charge_Ctrl@v),w
	skipc
	goto	u9711
	goto	u9710
u9711:
	goto	l5675
u9710:
	line	1214
	
l6493:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1215
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9721
	goto	u9720
u9721:
	goto	l6259
u9720:
	goto	l6511
	line	1228
	
l6505:	
	clrf	(Slot_Charge_Ctrl@st)
	line	1229
	goto	l6511
	line	233
	
l6509:	
	movf	(Slot_Charge_Ctrl@st),w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l5619
	xorlw	1^0	; case 1
	skipnz
	goto	l5639
	xorlw	2^1	; case 2
	skipnz
	goto	l6133
	xorlw	3^2	; case 3
	skipnz
	goto	l6149
	xorlw	4^3	; case 4
	skipnz
	goto	l6177
	xorlw	5^4	; case 5
	skipnz
	goto	l6313
	xorlw	6^5	; case 6
	skipnz
	goto	l6415
	xorlw	7^6	; case 7
	skipnz
	goto	l6455
	xorlw	8^7	; case 8
	skipnz
	goto	l5857
	xorlw	9^8	; case 9
	skipnz
	goto	l6017
	goto	l6505
	opt asmopt_pop

	line	1230
	
l564:	
	line	1232
	
l6511:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@st),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@ty),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@v),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@ct),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@ct+1),w
	movwf	indf
	line	1238
	
l6513:	
		movlw	2
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfsc	status,2
	goto	u9731
	goto	u9730
u9731:
	goto	l6525
u9730:
	
l6515:	
		movlw	3
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfsc	status,2
	goto	u9741
	goto	u9740
u9741:
	goto	l6525
u9740:
	
l6517:	
		movlw	4
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfsc	status,2
	goto	u9751
	goto	u9750
u9751:
	goto	l6525
u9750:
	
l6519:	
		movlw	5
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfsc	status,2
	goto	u9761
	goto	u9760
u9761:
	goto	l6525
u9760:
	
l6521:	
		movlw	8
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfsc	status,2
	goto	u9771
	goto	u9770
u9771:
	goto	l6525
u9770:
	
l6523:	
		decf	((Slot_Charge_Ctrl@st)),w
	btfss	status,2
	goto	u9781
	goto	u9780
u9781:
	goto	l6535
u9780:
	
l6525:	
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u9791
	goto	u9790
u9791:
	goto	l6535
u9790:
	
l6527:	
	movf	((_g_vccProtect)^080h),w
	btfss	status,2
	goto	u9801
	goto	u9800
u9801:
	goto	l6535
u9800:
	goto	l6531
	line	1240
	
l778:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	l809
	
l780:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	l809
	
l781:	
	bcf	(51/8),(51)&7	;volatile
	goto	l809
	
l782:	
	bcf	(50/8),(50)&7	;volatile
	goto	l809
	
l783:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	l809
	
l784:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	l809
	
l785:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l809
	
l786:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l809
	
l787:	
	bcf	(48/8),(48)&7	;volatile
	goto	l809
	
l788:	
	bcf	(49/8),(49)&7	;volatile
	goto	l809
	
l789:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l809
	
l790:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l809
	
l6531:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l778
	xorlw	1^0	; case 1
	skipnz
	goto	l780
	xorlw	2^1	; case 2
	skipnz
	goto	l781
	xorlw	3^2	; case 3
	skipnz
	goto	l782
	xorlw	4^3	; case 4
	skipnz
	goto	l783
	xorlw	5^4	; case 5
	skipnz
	goto	l784
	xorlw	6^5	; case 6
	skipnz
	goto	l785
	xorlw	7^6	; case 7
	skipnz
	goto	l786
	xorlw	8^7	; case 8
	skipnz
	goto	l787
	xorlw	9^8	; case 9
	skipnz
	goto	l788
	xorlw	10^9	; case 10
	skipnz
	goto	l789
	xorlw	11^10	; case 11
	skipnz
	goto	l790
	goto	l809
	opt asmopt_pop

	line	1244
	
l795:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l809
	
l797:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l809
	
l798:	
	bsf	(51/8),(51)&7	;volatile
	goto	l809
	
l799:	
	bsf	(50/8),(50)&7	;volatile
	goto	l809
	
l800:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l809
	
l801:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l809
	
l802:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l809
	
l803:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l809
	
l804:	
	bsf	(48/8),(48)&7	;volatile
	goto	l809
	
l805:	
	bsf	(49/8),(49)&7	;volatile
	goto	l809
	
l806:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l809
	
l807:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l809
	
l6535:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l795
	xorlw	1^0	; case 1
	skipnz
	goto	l797
	xorlw	2^1	; case 2
	skipnz
	goto	l798
	xorlw	3^2	; case 3
	skipnz
	goto	l799
	xorlw	4^3	; case 4
	skipnz
	goto	l800
	xorlw	5^4	; case 5
	skipnz
	goto	l801
	xorlw	6^5	; case 6
	skipnz
	goto	l802
	xorlw	7^6	; case 7
	skipnz
	goto	l803
	xorlw	8^7	; case 8
	skipnz
	goto	l804
	xorlw	9^8	; case 9
	skipnz
	goto	l805
	xorlw	10^9	; case 10
	skipnz
	goto	l806
	xorlw	11^10	; case 11
	skipnz
	goto	l807
	goto	l809
	opt asmopt_pop

	line	1246
	
l809:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_Charge_Ctrl
	__end_of_Slot_Charge_Ctrl:
	signat	_Slot_Charge_Ctrl,4217
	global	___wmul

;; *************** function ___wmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
;; Parameters:    Size  Location     Type
;;  multiplier      2    2[COMMON] unsigned int 
;;  multiplicand    2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  product         2    6[COMMON] unsigned int 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         6       0       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
global __ptext6
__ptext6:	;psect for function ___wmul
psect	text6
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
	global	__size_of___wmul
	__size_of___wmul	equ	__end_of___wmul-___wmul
	
___wmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___wmul: [wreg+status,2+status,0]
	line	43
	
l3433:	
	clrf	(___wmul@product)
	clrf	(___wmul@product+1)
	line	45
	
l3435:	
	btfss	(___wmul@multiplier),(0)&7
	goto	u3831
	goto	u3830
u3831:
	goto	l3439
u3830:
	line	46
	
l3437:	
	movf	(___wmul@multiplicand),w
	addwf	(___wmul@product),f
	skipnc
	incf	(___wmul@product+1),f
	movf	(___wmul@multiplicand+1),w
	addwf	(___wmul@product+1),f
	line	47
	
l3439:	
	clrc
	rlf	(___wmul@multiplicand),f
	rlf	(___wmul@multiplicand+1),f
	line	48
	
l3441:	
	clrc
	rrf	(___wmul@multiplier+1),f
	rrf	(___wmul@multiplier),f
	line	49
	
l3443:	
	movf	((___wmul@multiplier)),w
iorwf	((___wmul@multiplier+1)),w
	btfss	status,2
	goto	u3841
	goto	u3840
u3841:
	goto	l3435
u3840:
	line	52
	
l3445:	
	movf	(___wmul@product+1),w
	movwf	(?___wmul+1)
	movf	(___wmul@product),w
	movwf	(?___wmul)
	line	53
	
l883:	
	return
	opt stack 0
GLOBAL	__end_of___wmul
	__end_of___wmul:
	signat	___wmul,8314
	global	_Get_Vcc

;; *************** function _Get_Vcc *****************
;; Defined at:
;;		line 47 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   17[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  2   52[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;; This function is called by:
;;		_main
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	47
global __ptext7
__ptext7:	;psect for function _Get_Vcc
psect	text7
	file	"charge_mgr.c"
	line	47
	global	__size_of_Get_Vcc
	__size_of_Get_Vcc	equ	__end_of_Get_Vcc-_Get_Vcc
	
_Get_Vcc:	
;incstack = 0
	opt	stack 3
; Regs used in _Get_Vcc: [wreg+status,2+status,0+pclath+cstack]
	line	49
	
l5273:	
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u7381
	goto	u7380
u7381:
	goto	l499
u7380:
	line	51
	
l5275:	
	movf	(_adresult),w	;volatile
	movwf	(___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Get_Vcc@pt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Get_Vcc@pt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Get_Vcc@pt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Get_Vcc@pt)

	line	52
	
l5277:	
	movf	(Get_Vcc@pt+1),w
	movwf	(_g_vcc_mv+1)	;volatile
	movf	(Get_Vcc@pt),w
	movwf	(_g_vcc_mv)	;volatile
	line	55
	
l499:	
	return
	opt stack 0
GLOBAL	__end_of_Get_Vcc
	__end_of_Get_Vcc:
	signat	_Get_Vcc,90
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 119 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2    2[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         2       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	119
global __ptext8
__ptext8:	;psect for function _Detect_BatteryType
psect	text8
	file	"charge_mgr.c"
	line	119
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 4
; Regs used in _Detect_BatteryType: [wreg]
	line	121
	
l3401:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0FAh
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u3771
	goto	u3770
u3771:
	goto	l3407
u3770:
	line	122
	
l3403:	
	movlw	low(0)
	goto	l523
	line	123
	
l3407:	
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u3781
	goto	u3780
u3781:
	goto	l3413
u3780:
	goto	l3403
	line	138
	
l3413:	
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u3791
	goto	u3790
u3791:
	goto	l3421
u3790:
	
l3415:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0FAh
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u3801
	goto	u3800
u3801:
	goto	l3421
u3800:
	line	139
	
l3417:	
	movlw	low(05h)
	goto	l523
	line	144
	
l3421:	
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u3811
	goto	u3810
u3811:
	goto	l3403
u3810:
	
l3423:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0FAh
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u3821
	goto	u3820
u3821:
	goto	l3403
u3820:
	line	145
	
l3425:	
	movlw	low(01h)
	line	148
	
l523:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_Adc_Norm

;; *************** function _Adc_Norm *****************
;; Defined at:
;;		line 69 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  ch              1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  ch              1   20[BANK0 ] unsigned char 
;;  norm            4   23[BANK0 ] unsigned long 
;;  raw             2   21[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   17[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       3       0       0       0
;;      Locals:         0       7       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      10       0       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	69
global __ptext9
__ptext9:	;psect for function _Adc_Norm
psect	text9
	file	"charge_mgr.c"
	line	69
	global	__size_of_Adc_Norm
	__size_of_Adc_Norm	equ	__end_of_Adc_Norm-_Adc_Norm
	
_Adc_Norm:	
;incstack = 0
	opt	stack 3
; Regs used in _Adc_Norm: [wreg+status,2+status,0+pclath+cstack]
	movwf	(Adc_Norm@ch)
	line	74
	
l5281:	
	clrf	(ADC_Sample@adldo)
	movf	(Adc_Norm@ch),w
	fcall	_ADC_Sample
	xorlw	0A5h
	skipnz
	goto	u7391
	goto	u7390
u7391:
	goto	l5287
u7390:
	line	75
	
l5283:	
	clrf	(?_Adc_Norm)
	clrf	(?_Adc_Norm+1)
	goto	l503
	line	76
	
l5287:	
	movf	(_adresult+1),w	;volatile
	movwf	(Adc_Norm@raw+1)
	movf	(_adresult),w	;volatile
	movwf	(Adc_Norm@raw)
	line	77
	
l5289:	
	movf	((_g_vcc_mv)),w	;volatile
iorwf	((_g_vcc_mv+1)),w	;volatile
	btfss	status,2
	goto	u7401
	goto	u7400
u7401:
	goto	l5295
u7400:
	line	78
	
l5291:	
	movf	(Adc_Norm@raw+1),w
	movwf	(?_Adc_Norm+1)
	movf	(Adc_Norm@raw),w
	movwf	(?_Adc_Norm)
	goto	l503
	line	80
	
l5295:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	movf	(Adc_Norm@raw),w
	movwf	(___lmul@multiplier)
	movf	(Adc_Norm@raw+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movf	(_g_vcc_mv),w	;volatile
	movwf	(___lmul@multiplicand)
	movf	(_g_vcc_mv+1),w	;volatile
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Adc_Norm@norm+3)
	movf	(2+(?___lldiv)),w
	movwf	(Adc_Norm@norm+2)
	movf	(1+(?___lldiv)),w
	movwf	(Adc_Norm@norm+1)
	movf	(0+(?___lldiv)),w
	movwf	(Adc_Norm@norm)

	line	81
	
l5297:	
		movf	(Adc_Norm@norm+3),w
	btfss	status,2
	goto	u7410
	movf	(Adc_Norm@norm+2),w
	btfss	status,2
	goto	u7410
	movlw	16
	subwf	(Adc_Norm@norm+1),w
	skipz
	goto	u7413
	movlw	0
	subwf	(Adc_Norm@norm),w
	skipz
	goto	u7413
u7413:
	btfss	status,0
	goto	u7411
	goto	u7410

u7411:
	goto	l505
u7410:
	line	82
	
l5299:	
	movlw	0
	movwf	(Adc_Norm@norm+3)
	movlw	0
	movwf	(Adc_Norm@norm+2)
	movlw	0Fh
	movwf	(Adc_Norm@norm+1)
	movlw	0FFh
	movwf	(Adc_Norm@norm)

	
l505:	
	line	83
	movf	(Adc_Norm@norm+1),w
	movwf	(?_Adc_Norm+1)
	movf	(Adc_Norm@norm),w
	movwf	(?_Adc_Norm)
	line	84
	
l503:	
	return
	opt stack 0
GLOBAL	__end_of_Adc_Norm
	__end_of_Adc_Norm:
	signat	_Adc_Norm,4218
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 86 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   21[BANK0 ] unsigned long 
;;  temp_x10        2   27[BANK0 ] unsigned int 
;;  ntcVal          2   25[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   60[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/A00
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=0
	line	86
global __ptext10
__ptext10:	;psect for function _Read_Temperature
psect	text10
	file	"charge_mgr.c"
	line	86
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 4
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	91
	
l6725:	
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	92
	
l6727:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u10251
	goto	u10250
u10251:
	goto	l6731
u10250:
	goto	l509
	line	95
	
l6731:	
	movf	(_adresult+1),w	;volatile
	movwf	(Read_Temperature@ntcVal+1)
	movf	(_adresult),w	;volatile
	movwf	(Read_Temperature@ntcVal)
	line	96
	movlw	0
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u10261
	goto	u10260
u10261:
	goto	l509
u10260:
	
l6733:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u10271
	goto	u10270
u10271:
	goto	l6735
u10270:
	goto	l509
	line	101
	
l6735:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	010h
	movwf	(___lldiv@divisor+1)
	movlw	0
	movwf	(___lldiv@divisor)

	movf	(Read_Temperature@ntcVal),w
	movwf	((??_Read_Temperature+0)+0)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((??_Read_Temperature+0)+0+1)
	clrf	((??_Read_Temperature+0)+0+2)
	clrf	((??_Read_Temperature+0)+0+3)
	movf	0+(??_Read_Temperature+0)+0,w
	subwf	(___lldiv@divisor),f
	movf	1+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)+0,w
	goto	u10285
	goto	u10286
u10285:
	subwf	(___lldiv@divisor+1),f
u10286:
	movf	2+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)+0,w
	goto	u10287
	goto	u10288
u10287:
	subwf	(___lldiv@divisor+2),f
u10288:
	movf	3+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)+0,w
	goto	u10289
	goto	u10280
u10289:
	subwf	(___lldiv@divisor+3),f
u10280:

	movf	(Read_Temperature@ntcVal),w
	movwf	(___lmul@multiplier)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	027h
	movwf	(___lmul@multiplicand+1)
	movlw	010h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Read_Temperature@rt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Read_Temperature@rt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@rt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@rt)

	line	102
	
l6737:	
		movf	(Read_Temperature@rt+3),w
	btfss	status,2
	goto	u10290
	movf	(Read_Temperature@rt+2),w
	btfss	status,2
	goto	u10290
	movlw	39
	subwf	(Read_Temperature@rt+1),w
	skipz
	goto	u10293
	movlw	16
	subwf	(Read_Temperature@rt),w
	skipz
	goto	u10293
u10293:
	btfss	status,0
	goto	u10291
	goto	u10290

u10291:
	goto	l6743
u10290:
	line	103
	
l6739:	
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l6741:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0F0h
	movwf	((??_Read_Temperature+0)+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+3)
	movf	(Read_Temperature@rt),w
	addwf	(??_Read_Temperature+0)+0,f
	movf	(Read_Temperature@rt+1),w
	skipnc
	incfsz	(Read_Temperature@rt+1),w
	goto	u10300
	goto	u10301
u10300:
	addwf	(??_Read_Temperature+0)+1,f
u10301:
	movf	(Read_Temperature@rt+2),w
	skipnc
	incfsz	(Read_Temperature@rt+2),w
	goto	u10302
	goto	u10303
u10302:
	addwf	(??_Read_Temperature+0)+2,f
u10303:
	movf	(Read_Temperature@rt+3),w
	skipnc
	incf	(Read_Temperature@rt+3),w
	addwf	(??_Read_Temperature+0)+3,f
	movf	3+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+3)
	movf	2+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+2)
	movf	1+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+1)
	movf	0+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier)

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(0+(?___lldiv)),w
	subwf	(Read_Temperature@temp_x10),f
	movf	(1+(?___lldiv)),w
	skipc
	decf	(Read_Temperature@temp_x10+1),f
	subwf	(Read_Temperature@temp_x10+1),f
	goto	l6747
	line	105
	
l6743:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0
	movwf	(___lmul@multiplier+3)
	movlw	0
	movwf	(___lmul@multiplier+2)
	movlw	027h
	movwf	(___lmul@multiplier+1)
	movlw	010h
	movwf	(___lmul@multiplier)

	movf	(Read_Temperature@rt),w
	subwf	(___lmul@multiplier),f
	movf	(Read_Temperature@rt+1),w
	skipc
	incfsz	(Read_Temperature@rt+1),w
	goto	u10315
	goto	u10316
u10315:
	subwf	(___lmul@multiplier+1),f
u10316:
	movf	(Read_Temperature@rt+2),w
	skipc
	incfsz	(Read_Temperature@rt+2),w
	goto	u10317
	goto	u10318
u10317:
	subwf	(___lmul@multiplier+2),f
u10318:
	movf	(Read_Temperature@rt+3),w
	skipc
	incfsz	(Read_Temperature@rt+3),w
	goto	u10319
	goto	u10310
u10319:
	subwf	(___lmul@multiplier+3),f
u10310:

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10)
	
l6745:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10),f
	skipnc
	incf	(Read_Temperature@temp_x10+1),f
	line	106
	
l6747:	
	movlw	0
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipnc
	goto	u10321
	goto	u10320
u10321:
	goto	l515
u10320:
	
l6749:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l515:	
	line	107
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipc
	goto	u10331
	goto	u10330
u10331:
	goto	l516
u10330:
	
l6751:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)
	movlw	02h
	movwf	((Read_Temperature@temp_x10))+1
	
l516:	
	line	110
	movf	(Read_Temperature@temp_x10+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_temperature+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(Read_Temperature@temp_x10),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_temperature)^080h
	line	111
	
l6753:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bcf	status, 5	;RP0=0, select bank0
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u10341
	goto	u10340
u10341:
	goto	l6757
u10340:
	line	112
	
l6755:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	incf	(_g_tempProtect)^080h,f
	goto	l509
	line	113
	
l6757:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bcf	status, 5	;RP0=0, select bank0
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u10351
	goto	u10350
u10351:
	goto	l509
u10350:
	line	114
	
l6759:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	line	117
	
l509:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 245 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  d               2   46[BANK0 ] int 
;;  t               1   45[BANK0 ] unsigned char 
;;  bat_mv_long     4   40[BANK0 ] unsigned long 
;;  tc              1   44[BANK0 ] unsigned char 
;;  vx_mv           4   34[BANK0 ] unsigned long 
;;  v               2   32[BANK0 ] unsigned int 
;;  s               1   29[BANK0 ] unsigned char 
;;  pt              4   25[BANK0 ] unsigned long 
;;  vcc_mv          2   38[BANK0 ] unsigned int 
;;  i               1   48[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/A00
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      28       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      32       0       0       0
;;Total ram usage:       32 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	245
global __ptext11
__ptext11:	;psect for function _Print_SystemStatus
psect	text11
	file	"main.c"
	line	245
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 3
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	250
	
l5399:	
	movlw	low(((STR_4)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	251
	movlw	low(((STR_5)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	252
	movlw	low(((STR_6)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	255
	
l5401:	
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	256
	
l5403:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u7451
	goto	u7450
u7451:
	goto	l5409
u7450:
	line	258
	
l5405:	
	movf	(_adresult),w	;volatile
	movwf	(___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt)

	line	259
	
l5407:	
	movf	(Print_SystemStatus@pt+1),w
	movwf	(Print_SystemStatus@vcc_mv+1)
	movf	(Print_SystemStatus@pt),w
	movwf	(Print_SystemStatus@vcc_mv)
	line	260
	goto	l361
	line	262
	
l5409:	
	movlw	088h
	movwf	(Print_SystemStatus@vcc_mv)
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv))+1
	
l361:	
	line	264
	movf	(Print_SystemStatus@vcc_mv+1),w
	movwf	(_g_vcc_mv+1)	;volatile
	movf	(Print_SystemStatus@vcc_mv),w
	movwf	(_g_vcc_mv)	;volatile
	line	266
	
l5411:	
	movlw	low(((STR_7)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	267
	
l5413:	
	movf	(Print_SystemStatus@vcc_mv+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@vcc_mv),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	268
	
l5415:	
	movlw	low(((STR_8)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	269
	
l5417:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature)^080h,w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_SystemStatus$703+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_Print_SystemStatus$703)
	
l5419:	
	movf	(_Print_SystemStatus$703+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$703),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	270
	
l5421:	
	movlw	low(((STR_9)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	271
	
l5423:	
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature)^080h,w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_SystemStatus$704+1)
	movf	(0+(?___lwmod)),w
	movwf	(_Print_SystemStatus$704)
	
l5425:	
	movf	(_Print_SystemStatus$704+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$704),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	272
	
l5427:	
	movlw	low(((STR_10)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	273
	
l5429:	
		incf	((_g_impCheckSlot)),w
	btfsc	status,2
	goto	u7461
	goto	u7460
u7461:
	goto	l5433
u7460:
	
l5431:	
	movf	(_g_impCheckSlot),w
	movwf	(_Print_SystemStatus$265)
	clrf	(_Print_SystemStatus$265+1)
	goto	l5435
	
l5433:	
	movlw	0FFh
	movwf	(_Print_SystemStatus$265)
	clrf	(_Print_SystemStatus$265+1)
	
l5435:	
	movf	(_Print_SystemStatus$265+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$265),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	274
	
l5437:	
	movlw	low(((STR_11)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	279
	
l5439:	
	clrf	(Print_SystemStatus@i)
	line	284
	
l5445:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Print_SystemStatus@v)
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)
	line	285
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Print_SystemStatus@s)
	line	287
	
l5447:	
	movlw	low(042h)
	fcall	_uart_send_char
	line	288
	
l5449:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@i),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	289
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	290
	
l5451:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@v+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@v),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	296
	
l5453:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@v),w
	movwf	(___lmul@multiplier)
	movf	(Print_SystemStatus@v+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv)

	
l5455:	
	movlw	0Ch
u7475:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3),f
	rrf	(Print_SystemStatus@vx_mv+2),f
	rrf	(Print_SystemStatus@vx_mv+1),f
	rrf	(Print_SystemStatus@vx_mv),f
	addlw	-1
	skipz
	goto	u7475

	line	297
	
l5457:	
	movlw	0C8h
	movwf	((??_Print_SystemStatus+0)+0)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+3)
	movf	(Print_SystemStatus@vx_mv),w
	addwf	(??_Print_SystemStatus+0)+0,f
	movf	(Print_SystemStatus@vx_mv+1),w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1),w
	goto	u7480
	goto	u7481
u7480:
	addwf	(??_Print_SystemStatus+0)+1,f
u7481:
	movf	(Print_SystemStatus@vx_mv+2),w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2),w
	goto	u7482
	goto	u7483
u7482:
	addwf	(??_Print_SystemStatus+0)+2,f
u7483:
	movf	(Print_SystemStatus@vx_mv+3),w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3),w
	addwf	(??_Print_SystemStatus+0)+3,f
		movf	(??_Print_SystemStatus+0)+3,w
	btfss	status,2
	goto	u7490
	movf	(??_Print_SystemStatus+0)+2,w
	btfss	status,2
	goto	u7490
	movlw	19
	subwf	(??_Print_SystemStatus+0)+1,w
	skipz
	goto	u7493
	movlw	136
	subwf	(??_Print_SystemStatus+0)+0,w
	skipz
	goto	u7493
u7493:
	btfss	status,0
	goto	u7491
	goto	u7490

u7491:
	goto	l5461
u7490:
	line	299
	
l5459:	
	movlw	low(((STR_12)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	300
	goto	l5473
	line	303
	
l5461:	
	movf	(Print_SystemStatus@vx_mv+3),w
	movwf	(___lmul@multiplier+3)
	movf	(Print_SystemStatus@vx_mv+2),w
	movwf	(___lmul@multiplier+2)
	movf	(Print_SystemStatus@vx_mv+1),w
	movwf	(___lmul@multiplier+1)
	movf	(Print_SystemStatus@vx_mv),w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+3)
	movf	(2+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+2)
	movf	(1+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+1)
	movf	(0+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long)

	
l5463:	
	movlw	070h
	addwf	(Print_SystemStatus@bat_mv_long),f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Print_SystemStatus@bat_mv_long+1),f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Print_SystemStatus@bat_mv_long+2),f
	movlw	0
	skipnc
movlw 1
	addwf	(Print_SystemStatus@bat_mv_long+3),f
	line	304
	
l5465:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Print_SystemStatus+0)+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+3)
	movf	(Print_SystemStatus@bat_mv_long),w
	addwf	(??_Print_SystemStatus+0)+0,f
	movf	(Print_SystemStatus@bat_mv_long+1),w
	skipnc
	incfsz	(Print_SystemStatus@bat_mv_long+1),w
	goto	u7500
	goto	u7501
u7500:
	addwf	(??_Print_SystemStatus+0)+1,f
u7501:
	movf	(Print_SystemStatus@bat_mv_long+2),w
	skipnc
	incfsz	(Print_SystemStatus@bat_mv_long+2),w
	goto	u7502
	goto	u7503
u7502:
	addwf	(??_Print_SystemStatus+0)+2,f
u7503:
	movf	(Print_SystemStatus@bat_mv_long+3),w
	skipnc
	incf	(Print_SystemStatus@bat_mv_long+3),w
	addwf	(??_Print_SystemStatus+0)+3,f
	movf	3+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+3)
	movf	(2+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+2)
	movf	(1+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+1)
	movf	(0+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long)

	line	305
	
l5467:	
	movlw	low(((STR_13)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	306
	
l5469:	
	movf	(Print_SystemStatus@bat_mv_long+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@bat_mv_long),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	307
	
l5471:	
	movlw	low(((STR_14)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	312
	
l5473:	
	movlw	low(020h)
	fcall	_uart_send_char
	line	313
	goto	l5529
	line	315
	
l5475:	
	movlw	low(((STR_15)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5531
	line	317
	
l5477:	
	movlw	low(((STR_16)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	318
	
l5479:	
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	((??_Print_SystemStatus+0)+0),w
iorwf	((??_Print_SystemStatus+0)+1),w
	btfsc	status,2
	goto	u7511
	goto	u7510
u7511:
	goto	l5531
u7510:
	line	320
	
l5481:	
	movlw	low(((STR_17)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	321
	
l5483:	
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(uart_send_number@num)
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	goto	l5531
	line	324
	
l5485:	
	movlw	low(((STR_18)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5531
	line	325
	
l5487:	
	movlw	low(((STR_19)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5531
	line	326
	
l5489:	
	movlw	low(((STR_20)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5531
	line	327
	
l5491:	
	movlw	low(((STR_21)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5531
	line	328
	
l5493:	
	movlw	low(((STR_22)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5531
	line	331
	
l5495:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Print_SystemStatus@t)
	line	332
	
l5497:	
		movlw	2
	xorwf	((Print_SystemStatus@t)),w
	btfsc	status,2
	goto	u7521
	goto	u7520
u7521:
	goto	l5501
u7520:
	
l5499:	
		movlw	3
	xorwf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u7531
	goto	u7530
u7531:
	goto	l5503
u7530:
	line	333
	
l5501:	
	movlw	low(((STR_23)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5513
	line	334
	
l5503:	
		decf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u7541
	goto	u7540
u7541:
	goto	l5507
u7540:
	line	335
	
l5505:	
	movlw	low(((STR_24)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5513
	line	336
	
l5507:	
		movlw	6
	xorwf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u7551
	goto	u7550
u7551:
	goto	l5511
u7550:
	line	337
	
l5509:	
	movlw	low(((STR_25)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5513
	line	339
	
l5511:	
	movlw	low(((STR_26)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	340
	
l5513:	
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	((??_Print_SystemStatus+0)+0),w
iorwf	((??_Print_SystemStatus+0)+1),w
	btfsc	status,2
	goto	u7561
	goto	u7560
u7561:
	goto	l5531
u7560:
	line	342
	
l5515:	
	movlw	low(((STR_27)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5483
	line	347
	
l5519:	
	movlw	low(((STR_28)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5531
	line	349
	
l5521:	
	movlw	low(((STR_29)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	350
	movlw	low(((STR_30)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	351
	
l5523:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(uart_send_number@num)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(uart_send_number@num)
	fcall	_uart_send_number
	line	352
	goto	l5531
	line	353
	
l5525:	
	movlw	low(((STR_31)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5531
	line	313
	
l5529:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@s),w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l5475
	xorlw	1^0	; case 1
	skipnz
	goto	l5477
	xorlw	2^1	; case 2
	skipnz
	goto	l5485
	xorlw	3^2	; case 3
	skipnz
	goto	l5487
	xorlw	4^3	; case 4
	skipnz
	goto	l5489
	xorlw	5^4	; case 5
	skipnz
	goto	l5491
	xorlw	6^5	; case 6
	skipnz
	goto	l5493
	xorlw	7^6	; case 7
	skipnz
	goto	l5495
	xorlw	8^7	; case 8
	skipnz
	goto	l5519
	xorlw	9^8	; case 9
	skipnz
	goto	l5521
	goto	l5525
	opt asmopt_pop

	line	357
	
l5531:	
	movlw	low(((STR_32)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	358
	
l5533:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	359
	
l5535:	
	movlw	low(((STR_33)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	360
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	363
	
l5537:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_g_diodeTraceCnt)),w
	btfsc	status,2
	goto	u7571
	goto	u7570
u7571:
	goto	l5573
u7570:
	
l5539:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_diodeTraceSlot)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Print_SystemStatus@i),w
	skipz
	goto	u7581
	goto	u7580
u7581:
	goto	l5573
u7580:
	line	366
	
l5541:	
	movlw	low(((STR_34)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_34)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	367
	
l5543:	
	clrf	(Print_SystemStatus@tc)
	goto	l5567
	line	369
	
l5545:	
	movf	(Print_SystemStatus@tc),w
	addlw	low(_g_diodeTrace|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(Print_SystemStatus@d)
	clrf	(Print_SystemStatus@d+1)
	
l5547:	
	movlw	-128
	addwf	(Print_SystemStatus@d),f
	skipc
	decf	(Print_SystemStatus@d+1),f
	line	370
	
l5549:	
	btfss	(Print_SystemStatus@d+1),7
	goto	u7591
	goto	u7590
u7591:
	goto	l5555
u7590:
	line	372
	
l5551:	
	movlw	low(02Dh)
	fcall	_uart_send_char
	line	373
	
l5553:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	comf	(Print_SystemStatus@d),f
	comf	(Print_SystemStatus@d+1),f
	incf	(Print_SystemStatus@d),f
	skipnz
	incf	(Print_SystemStatus@d+1),f
	line	374
	goto	l5559
	line	375
	
l5555:	
	movf	(Print_SystemStatus@d+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u7605
	movlw	01h
	subwf	(Print_SystemStatus@d),w
u7605:

	skipc
	goto	u7601
	goto	u7600
u7601:
	goto	l5559
u7600:
	line	376
	
l5557:	
	movlw	low(02Bh)
	fcall	_uart_send_char
	line	377
	
l5559:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@d+1),w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	(Print_SystemStatus@d),w
	movwf	(??_Print_SystemStatus+0)+0
	clrc
	rlf	(??_Print_SystemStatus+0)+0,f
	rlf	(??_Print_SystemStatus+0)+1,f
	clrc
	rlf	(??_Print_SystemStatus+0)+0,f
	rlf	(??_Print_SystemStatus+0)+1,f
	movf	0+(??_Print_SystemStatus+0)+0,w
	movwf	(uart_send_number@num)
	movf	1+(??_Print_SystemStatus+0)+0,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	378
	
l5561:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_diodeTraceCnt),w
	movwf	(??_Print_SystemStatus+0)+0
	clrf	(??_Print_SystemStatus+0)+0+1
	movf	(Print_SystemStatus@tc),w
	addlw	low(01h)
	movwf	(??_Print_SystemStatus+2)+0
	movlw	high(01h)
	skipnc
	movlw	(high(01h)+1)&0ffh
	movwf	((??_Print_SystemStatus+2)+0)+1
	movf	1+(??_Print_SystemStatus+0)+0,w
	subwf	1+(??_Print_SystemStatus+2)+0,w
	skipz
	goto	u7615
	movf	0+(??_Print_SystemStatus+0)+0,w
	subwf	0+(??_Print_SystemStatus+2)+0,w
u7615:
	skipnc
	goto	u7611
	goto	u7610
u7611:
	goto	l5565
u7610:
	line	379
	
l5563:	
	movlw	low(02Ch)
	fcall	_uart_send_char
	line	367
	
l5565:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Print_SystemStatus@tc),f
	
l5567:	
	movf	(_g_diodeTraceCnt),w
	subwf	(Print_SystemStatus@tc),w
	skipc
	goto	u7621
	goto	u7620
u7621:
	goto	l5545
u7620:
	line	381
	
l5569:	
	clrf	(_g_diodeTraceCnt)
	line	382
	
l5571:	
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_diodeTraceSlot)^080h
	line	386
	
l5573:	
	movlw	low(((STR_35)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_35)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	279
	
l5575:	
	incf	(Print_SystemStatus@i),f
	
l5577:	
	movlw	low(0Ch)
	subwf	(Print_SystemStatus@i),w
	skipc
	goto	u7631
	goto	u7630
u7631:
	goto	l5445
u7630:
	line	389
	
l5579:	
	movlw	low(((STR_36)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_36)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	390
	
l401:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    2[COMMON] unsigned long 
;;  multiplicand    4    6[COMMON] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    0[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    2[COMMON] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         8       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       4       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext12
__ptext12:	;psect for function ___lmul
psect	text12
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l5153:	
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l892:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u7191
	goto	u7190
u7191:
	goto	l5157
u7190:
	line	122
	
l5155:	
	movf	(___lmul@multiplicand),w
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7201
	addwf	(___lmul@product+1),f
u7201:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7202
	addwf	(___lmul@product+2),f
u7202:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7203
	addwf	(___lmul@product+3),f
u7203:

	line	123
	
l5157:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l5159:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u7211
	goto	u7210
u7211:
	goto	l892
u7210:
	line	128
	
l5161:	
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l895:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    4[BANK0 ] unsigned long 
;;  dividend        4    8[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   12[BANK0 ] unsigned long 
;;  counter         1   16[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    4[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      13       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Slot_Charge_Ctrl
;;		_Get_Vcc
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext13
__ptext13:	;psect for function ___lldiv
psect	text13
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 4
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l5165:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l5167:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u7221
	goto	u7220
u7221:
	goto	l5187
u7220:
	line	16
	
l5169:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l5173
	line	18
	
l5171:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l5173:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u7231
	goto	u7230
u7231:
	goto	l5171
u7230:
	line	22
	
l5175:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l5177:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u7245
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u7245
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u7245
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u7245:
	skipc
	goto	u7241
	goto	u7240
u7241:
	goto	l5183
u7240:
	line	24
	
l5179:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l5181:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l5183:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l5185:	
	decfsz	(___lldiv@counter),f
	goto	u7251
	goto	u7250
u7251:
	goto	l5175
u7250:
	line	30
	
l5187:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l1167:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    2[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    1[BANK0 ] unsigned char 
;;  j               1    0[BANK0 ] unsigned char 
;;  adsum           4    3[BANK0 ] volatile unsigned long 
;;  ad_temp         2   11[BANK0 ] volatile unsigned int 
;;  admax           2    9[BANK0 ] volatile unsigned int 
;;  admin           2    7[BANK0 ] volatile unsigned int 
;;  i               1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      13       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Get_Vcc
;;		_Adc_Norm
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	49
global __ptext14
__ptext14:	;psect for function _ADC_Sample
psect	text14
	file	"adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(ADC_Sample@adch)
	line	51
	
l5063:	
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	52
	
l5065:	
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	53
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	54
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	58
	
l5067:	
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u7021
	goto	u7020
u7021:
	goto	l5073
u7020:
	
l5069:	
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u7031
	goto	u7030
u7031:
	goto	l5073
u7030:
	line	60
	
l5071:	
	movf	(ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	61
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??_ADC_Sample+0)+0),f
	u10427:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u10427
opt asmopt_pop

	line	62
	goto	l5075
	line	64
	
l5073:	
	movf	(ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	67
	
l5075:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(ADC_Sample@adch),(4)&7
	goto	u7041
	goto	u7040
u7041:
	goto	l425
u7040:
	line	69
	
l5077:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l5079:	
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(ADC_Sample@adch),f
	line	71
	goto	l5081
	line	72
	
l425:	
	line	73
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l5081:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@i)
	line	79
	
l5087:	
	movf	(ADC_Sample@adch),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u7055:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u7055
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l5089:	
	opt asmopt_push
opt asmopt_off
	movlw	6
movwf	((??_ADC_Sample+0)+0),f
	u10437:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u10437
	nop
opt asmopt_pop

	line	81
	
l5091:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l5093:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	85
	goto	l429
	
l430:	
	line	87
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u7061
	goto	u7060
u7061:
	goto	l429
u7060:
	line	89
	
l5095:	
	movlw	low(0)
	goto	l432
	line	90
	
l429:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u7071
	goto	u7070
u7071:
	goto	l430
u7070:
	line	93
	
l5099:	
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
l5101:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
l5103:	
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u7081
	goto	u7080
u7081:
	goto	l5107
u7080:
	line	98
	
l5105:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	99
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	100
	goto	l435
	line	102
	
l5107:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u7095
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u7095:
	skipnc
	goto	u7091
	goto	u7090
u7091:
	goto	l5111
u7090:
	line	103
	
l5109:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	l435
	line	105
	
l5111:	
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u7105
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u7105:
	skipnc
	goto	u7101
	goto	u7100
u7101:
	goto	l435
u7100:
	line	106
	
l5113:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	108
	
l435:	
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7111
	addwf	(ADC_Sample@adsum+1),f	;volatile
u7111:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7112
	addwf	(ADC_Sample@adsum+2),f	;volatile
u7112:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7113
	addwf	(ADC_Sample@adsum+3),f	;volatile
u7113:

	line	76
	
l5115:	
	incf	(ADC_Sample@i),f
	
l5117:	
	movlw	low(022h)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u7121
	goto	u7120
u7121:
	goto	l5087
u7120:
	line	112
	
l5119:	
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u7135
	goto	u7136
u7135:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u7136:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u7137
	goto	u7138
u7137:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u7138:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u7139
	goto	u7130
u7139:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u7130:

	line	113
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u7145
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u7145
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u7145
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u7145:
	skipc
	goto	u7141
	goto	u7140
u7141:
	goto	l439
u7140:
	line	114
	
l5121:	
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u7155
	goto	u7156
u7155:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u7156:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u7157
	goto	u7158
u7157:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u7158:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u7159
	goto	u7150
u7159:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u7150:

	goto	l5123
	line	115
	
l439:	
	line	116
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	118
	
l5123:	
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u7165:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u7160:
	addlw	-1
	skipz
	goto	u7165
	movf	1+(??_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
l5125:	
	movlw	low(0A5h)
	line	120
	
l432:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 224 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	224
global __ptext15
__ptext15:	;psect for function _Print_NtcTemp
psect	text15
	file	"main.c"
	line	224
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 3
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	226
	
l5387:	
	movlw	low(((STR_1)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	227
	
l5389:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature)^080h,w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_NtcTemp$701+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$701)
	
l5391:	
	movf	(_Print_NtcTemp$701+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$701),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	228
	
l5393:	
	movlw	low(((STR_2)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	229
	
l5395:	
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature)^080h,w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_NtcTemp$702+1)
	movf	(0+(?___lwmod)),w
	movwf	(_Print_NtcTemp$702)
	movf	(_Print_NtcTemp$702+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$702),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	230
	
l5397:	
	movlw	low(((STR_3)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	231
	
l357:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2    5[COMMON] PTR const unsigned char 
;;		 -> STR_38(10), STR_37(21), STR_36(3), STR_35(3), 
;;		 -> STR_34(5), STR_33(5), STR_32(5), STR_31(6), 
;;		 -> STR_30(6), STR_29(6), STR_28(6), STR_27(6), 
;;		 -> STR_26(6), STR_25(16), STR_24(13), STR_23(15), 
;;		 -> STR_22(7), STR_21(5), STR_20(5), STR_19(6), 
;;		 -> STR_18(6), STR_17(6), STR_16(6), STR_15(7), 
;;		 -> STR_14(4), STR_13(6), STR_12(6), STR_11(3), 
;;		 -> STR_10(12), STR_9(2), STR_8(6), STR_7(5), 
;;		 -> STR_6(6), STR_5(5), STR_4(25), STR_3(4), 
;;		 -> STR_2(2), STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         2       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_main
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=0
	file	"uart_dbg.c"
	line	61
global __ptext16
__ptext16:	;psect for function _uart_send_string
psect	text16
	file	"uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 4
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l5237:	
	goto	l5243
	line	65
	
l5239:	
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	fcall	_uart_send_char
	
l5241:	
	incf	(uart_send_string@str),f
	skipnz
	incf	(uart_send_string@str+1),f
	line	66
# 66 "uart_dbg.c"
clrwdt ;# 
psect	text16
	line	63
	
l5243:	
	movf	(uart_send_string@str+1),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u7341
	goto	u7340
u7341:
	goto	l5239
u7340:
	line	68
	
l456:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2    0[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    2[BANK0 ] unsigned char [6]
;;  j               1    9[BANK0 ] unsigned char 
;;  i               1    8[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      10       0       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext17
__ptext17:	;psect for function _uart_send_number
psect	text17
	file	"uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l5245:	
	clrf	(uart_send_number@i)
	line	84
	
l5247:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u7351
	goto	u7350
u7351:
	goto	l5259
u7350:
	line	86
	
l5249:	
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l460
	line	93
	
l5253:	
	movf	(uart_send_number@i),w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwmod@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank0
	movwf	indf
	
l5255:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(uart_send_number@i),f
	line	94
	
l5257:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	movf	(0+(?___lwdiv)),w
	movwf	(uart_send_number@num)
	line	91
	
l5259:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u7361
	goto	u7360
u7361:
	goto	l5253
u7360:
	line	98
	
l5261:	
	movf	(uart_send_number@i),w
	movwf	(uart_send_number@j)
	
l5263:	
	movf	((uart_send_number@j)),w
	btfss	status,2
	goto	u7371
	goto	u7370
u7371:
	goto	l5267
u7370:
	goto	l460
	line	99
	
l5267:	
	movf	(uart_send_number@j),w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l5269:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decf	(uart_send_number@j),f
	goto	l5263
	line	100
	
l460:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1    3[COMMON] unsigned char 
;;  i               1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          1       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext18
__ptext18:	;psect for function _uart_send_char
psect	text18
	file	"uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 4
; Regs used in _uart_send_char: [wreg+status,2+status,0]
	movwf	(uart_send_char@c)
	line	38
	
l5129:	
	bcf	(95/8),(95)&7	;volatile
	line	39
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l5131:	
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u10447:
decfsz	(??_uart_send_char+0)+0,f
	goto	u10447
	nop
opt asmopt_pop

	line	41
	
l5133:	
	clrf	(uart_send_char@i)
	line	42
	
l446:	
	line	43
	btfss	(uart_send_char@c),(0)&7
	goto	u7171
	goto	u7170
u7171:
	goto	l448
u7170:
	line	44
	
l5139:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l5141
	line	45
	
l448:	
	line	46
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l5141:	
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u10457:
decfsz	(??_uart_send_char+0)+0,f
	goto	u10457
	nop
opt asmopt_pop

	line	48
	
l5143:	
	clrc
	rrf	(uart_send_char@c),f
	line	41
	
l5145:	
	incf	(uart_send_char@i),f
	
l5147:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u7181
	goto	u7180
u7181:
	goto	l446
u7180:
	
l447:	
	line	50
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l5149:	
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u10467:
decfsz	(??_uart_send_char+0)+0,f
	goto	u10467
	nop
opt asmopt_pop

	line	52
	
l5151:	
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l450:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] unsigned int 
;;  dividend        2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/900
;;		On exit  : 200/0
;;		Unchanged: 200/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext19
__ptext19:	;psect for function ___lwmod
psect	text19
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l5217:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u7301
	goto	u7300
u7301:
	goto	l5233
u7300:
	line	14
	
l5219:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l5223
	line	16
	
l5221:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l5223:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u7311
	goto	u7310
u7311:
	goto	l5221
u7310:
	line	20
	
l5225:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u7325
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u7325:
	skipc
	goto	u7321
	goto	u7320
u7321:
	goto	l5229
u7320:
	line	21
	
l5227:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l5229:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l5231:	
	decfsz	(___lwmod@counter),f
	goto	u7331
	goto	u7330
u7331:
	goto	l5225
u7330:
	line	25
	
l5233:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1230:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] unsigned int 
;;  dividend        2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    7[COMMON] unsigned int 
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 200/0
;;		Unchanged: 200/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         3       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         7       0       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_Slot_Charge_Ctrl
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext20
__ptext20:	;psect for function ___lwdiv
psect	text20
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 4
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l5191:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l5193:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u7261
	goto	u7260
u7261:
	goto	l5213
u7260:
	line	16
	
l5195:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l5199
	line	18
	
l5197:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l5199:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u7271
	goto	u7270
u7271:
	goto	l5197
u7270:
	line	22
	
l5201:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l5203:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u7285
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u7285:
	skipc
	goto	u7281
	goto	u7280
u7281:
	goto	l5209
u7280:
	line	24
	
l5205:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l5207:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l5209:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l5211:	
	decfsz	(___lwdiv@counter),f
	goto	u7291
	goto	u7290
u7291:
	goto	l5201
u7290:
	line	30
	
l5213:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l1220:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 1264 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    8[BANK0 ] unsigned int 
;;  s               1   20[BANK0 ] unsigned char 
;;  duty            2   17[BANK0 ] int 
;;  error           2   12[BANK0 ] int 
;;  adjust          2    2[BANK0 ] int 
;;  duty_initial    1   16[BANK0 ] unsigned char 
;;  duty_target     1   15[BANK0 ] unsigned char 
;;  maxV            2   10[BANK0 ] unsigned int 
;;  i               1   19[BANK0 ] unsigned char 
;;  cvCount         1   14[BANK0 ] unsigned char 
;;  detectCount     1    7[BANK0 ] unsigned char 
;;  preCount        1    6[BANK0 ] unsigned char 
;;  ccCount         1    5[BANK0 ] unsigned char 
;;  hasCharging     1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      19       0       0       0
;;      Temps:          0       2       0       0       0
;;      Totals:         0      21       0       0       0
;;Total ram usage:       21 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___awdiv
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	1264
global __ptext21
__ptext21:	;psect for function _CCCV_Control
psect	text21
	file	"charge_mgr.c"
	line	1264
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 4
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1267
	
l6537:	
	clrf	(CCCV_Control@hasCharging)
	line	1268
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	1269
	clrf	(CCCV_Control@cvCount)
	line	1270
	clrf	(CCCV_Control@ccCount)
	line	1271
	clrf	(CCCV_Control@preCount)
	line	1272
	clrf	(CCCV_Control@detectCount)
	line	1275
	
l6539:	
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u9811
	goto	u9810
u9811:
	goto	l6545
u9810:
	line	1277
	
l6541:	
	movlw	011h
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_g_vcc_mv+1),w	;volatile
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv),w	;volatile
	skipc
	goto	u9821
	goto	u9820
u9821:
	goto	l6549
u9820:
	line	1278
	
l6543:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_vccProtect)^080h
	goto	l6549
	line	1282
	
l6545:	
	movlw	011h
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_g_vcc_mv+1),w	;volatile
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv),w	;volatile
	skipnc
	goto	u9831
	goto	u9830
u9831:
	goto	l6549
u9830:
	line	1283
	
l6547:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_vccProtect)^080h
	incf	(_g_vccProtect)^080h,f
	line	1287
	
l6549:	
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u9841
	goto	u9840
u9841:
	goto	l6553
u9840:
	
l6551:	
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u9851
	goto	u9850
u9851:
	goto	l6557
u9850:
	line	1289
	
l6553:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	1290
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	l819
	line	1295
	
l6557:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(CCCV_Control@i)
	line	1297
	
l6563:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	1302
	
l6565:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9861
	goto	u9860
u9861:
	goto	l824
u9860:
	
l6567:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9871
	goto	u9870
u9871:
	goto	l824
u9870:
	
l6569:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9881
	goto	u9880
u9881:
	goto	l824
u9880:
	
l6571:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9891
	goto	u9890
u9891:
	goto	l824
u9890:
	
l6573:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9901
	goto	u9900
u9901:
	goto	l824
u9900:
	
l6575:	
		decf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9911
	goto	u9910
u9911:
	goto	l824
u9910:
	
l6577:	
		movlw	9
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9921
	goto	u9920
u9921:
	goto	l822
u9920:
	
l824:	
	line	1304
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	1306
	
l6579:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	1307
	
l6581:	
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u9935
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u9935:
	skipnc
	goto	u9931
	goto	u9930
u9931:
	goto	l6585
u9930:
	
l6583:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	1309
	
l6585:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9941
	goto	u9940
u9941:
	goto	l6589
u9940:
	line	1310
	
l6587:	
	incf	(CCCV_Control@cvCount),f
	line	1311
	
l6589:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9951
	goto	u9950
u9951:
	goto	l6593
u9950:
	line	1312
	
l6591:	
	incf	(CCCV_Control@ccCount),f
	line	1313
	
l6593:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9961
	goto	u9960
u9961:
	goto	l6597
u9960:
	
l6595:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9971
	goto	u9970
u9971:
	goto	l6599
u9970:
	line	1314
	
l6597:	
	incf	(CCCV_Control@preCount),f
	line	1319
	
l6599:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9981
	goto	u9980
u9981:
	goto	l6605
u9980:
	
l6601:	
		decf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9991
	goto	u9990
u9991:
	goto	l6605
u9990:
	
l6603:	
		movlw	9
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u10001
	goto	u10000
u10001:
	goto	l822
u10000:
	line	1320
	
l6605:	
	incf	(CCCV_Control@detectCount),f
	line	1321
	
l822:	
	line	1295
	incf	(CCCV_Control@i),f
	
l6607:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u10011
	goto	u10010
u10011:
	goto	l6563
u10010:
	line	1325
	
l6609:	
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u10021
	goto	u10020
u10021:
	goto	l6615
u10020:
	goto	l6553
	line	1338
	
l6615:	
	movf	((CCCV_Control@detectCount)),w
	btfsc	status,2
	goto	u10031
	goto	u10030
u10031:
	goto	l6625
u10030:
	
l6617:	
	movf	((CCCV_Control@cvCount)),w
	btfsc	status,2
	goto	u10041
	goto	u10040
u10041:
	goto	l6625
u10040:
	line	1340
	
l6619:	
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	line	1341
	
l6621:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	l819
	line	1349
	
l6625:	
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u10051
	goto	u10050
u10051:
	goto	l6655
u10050:
	line	1353
	
l6627:	
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u10061
	goto	u10060
u10061:
	goto	l6631
u10060:
	line	1356
	
l6629:	
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	1357
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	1358
	goto	l6639
	line	1359
	
l6631:	
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u10071
	goto	u10070
u10071:
	goto	l6635
u10070:
	line	1362
	
l6633:	
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	1363
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	1364
	goto	l6639
	line	1369
	
l6635:	
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	l819
	line	1373
	
l6639:	
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u10081
	goto	u10080
u10081:
	goto	l6647
u10080:
	line	1376
	
l6641:	
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	1377
	
l6643:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u10091
	goto	u10090
u10091:
	goto	l819
u10090:
	line	1378
	
l6645:	
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	l819
	line	1380
	
l6647:	
	line	1383
	
l6649:	
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	1384
	goto	l819
	line	1399
	
l6655:	
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	1402
	movf	(CCCV_Control@error),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral)^080h,f
	skipnc
	incf	(_g_cvIntegral+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(CCCV_Control@error+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral+1)^080h,f
	line	1403
	
l6657:	
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u10105
	movlw	0C9h
	subwf	(_g_cvIntegral)^080h,w
u10105:

	skipc
	goto	u10101
	goto	u10100
u10101:
	goto	l6661
u10100:
	line	1404
	
l6659:	
	movlw	0C8h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	l6665
	line	1405
	
l6661:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u10115
	movlw	038h
	subwf	(_g_cvIntegral)^080h,w
u10115:

	skipnc
	goto	u10111
	goto	u10110
u10111:
	goto	l6665
u10110:
	line	1406
	
l6663:	
	movlw	038h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	movlw	0FFh
	movwf	((_g_cvIntegral)^080h)+1
	line	1409
	
l6665:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_cvIntegral)^080h,w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1)^080h,w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	1410
	
l6667:	
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
l6669:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	1413
	
l6671:	
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u10125
	movlw	021h
	subwf	(CCCV_Control@duty),w
u10125:

	skipc
	goto	u10121
	goto	u10120
u10121:
	goto	l6675
u10120:
	
l6673:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1414
	
l6675:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u10131
	goto	u10130
u10131:
	goto	l6679
u10130:
	
l6677:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1416
	
l6679:	
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	1418
	
l819:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    2[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    4[COMMON] unsigned char 
;;  product         1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Print_SystemStatus
;;		_Slot_Charge_Ctrl
;;		_CCCV_Control
;;		_Update_LED_Global
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext22
__ptext22:	;psect for function ___bmul
psect	text22
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___bmul: [wreg+status,2+status,0]
	movwf	(___bmul@multiplier)
	line	6
	
l5303:	
	clrf	(___bmul@product)
	line	43
	
l5305:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u7421
	goto	u7420
u7421:
	goto	l5309
u7420:
	line	44
	
l5307:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l5309:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l5311:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u7431
	goto	u7430
u7431:
	goto	l5305
u7430:
	line	50
	
l5313:	
	movf	(___bmul@product),w
	line	51
	
l901:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] int 
;;  dividend        2    4[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    8[COMMON] int 
;;  sign            1    7[COMMON] unsigned char 
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext23
__ptext23:	;psect for function ___awdiv
psect	text23
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 4
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
l3463:	
	clrf	(___awdiv@sign)
	line	15
	
l3465:	
	btfss	(___awdiv@divisor+1),7
	goto	u3871
	goto	u3870
u3871:
	goto	l3471
u3870:
	line	16
	
l3467:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
l3469:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
l3471:	
	btfss	(___awdiv@dividend+1),7
	goto	u3881
	goto	u3880
u3881:
	goto	l3477
u3880:
	line	20
	
l3473:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
l3475:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
l3477:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
l3479:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u3891
	goto	u3890
u3891:
	goto	l3499
u3890:
	line	25
	
l3481:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	l3485
	line	27
	
l3483:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
l3485:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u3901
	goto	u3900
u3901:
	goto	l3483
u3900:
	line	31
	
l3487:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
l3489:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u3915
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u3915:
	skipc
	goto	u3911
	goto	u3910
u3911:
	goto	l3495
u3910:
	line	33
	
l3491:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
l3493:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
l3495:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
l3497:	
	decfsz	(___awdiv@counter),f
	goto	u3921
	goto	u3920
u3921:
	goto	l3487
u3920:
	line	39
	
l3499:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u3931
	goto	u3930
u3931:
	goto	l3503
u3930:
	line	40
	
l3501:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
l3503:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
l1013:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 158 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		_PowerOnLedSequence
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	158
global __ptext24
__ptext24:	;psect for function _Isr_Timer
psect	text24
	file	"main.c"
	line	158
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 3
; Regs used in _Isr_Timer: [wreg+status,2+status,0+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Isr_Timer+0)
	movf	pclath,w
	movwf	(??_Isr_Timer+1)
	ljmp	_Isr_Timer
psect	text24
	line	161
	
i1l4975:	
	btfss	(90/8),(90)&7	;volatile
	goto	u690_21
	goto	u690_20
u690_21:
	goto	i1l349
u690_20:
	line	163
	
i1l4977:	
	bcf	(90/8),(90)&7	;volatile
	line	164
	
i1l4979:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(129)^080h	;volatile
	line	165
# 165 "main.c"
clrwdt ;# 
psect	text24
	line	168
	
i1l4981:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	169
	
i1l4983:	
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u691_21
	goto	u691_20
u691_21:
	goto	i1l4987
u691_20:
	line	170
	
i1l4985:	
	clrf	(_g_pwmCounter)	;volatile
	line	172
	
i1l4987:	
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u692_21
	goto	u692_20
u692_21:
	goto	i1l346
u692_20:
	
i1l4989:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u693_21
	goto	u693_20
u693_21:
	goto	i1l346
u693_20:
	line	173
	
i1l4991:	
	bsf	(55/8),(55)&7	;volatile
	goto	i1l4993
	line	174
	
i1l346:	
	line	175
	bcf	(55/8),(55)&7	;volatile
	line	178
	
i1l4993:	
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u694_21
	goto	u694_20
u694_21:
	goto	i1l4999
u694_20:
	line	180
	
i1l4995:	
	fcall	_PowerOnLedSequence
	goto	i1l349
	line	185
	
i1l4999:	
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_tempPhase)^080h),w	;volatile
	btfss	status,2
	goto	u695_21
	goto	u695_20
u695_21:
	goto	i1l5011
u695_20:
	line	187
	
i1l5001:	
	incf	(_g_tempReadRoundCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1)^080h,f	;volatile
	line	188
	
i1l5003:	
	movlw	0
	subwf	(_g_tempReadRoundCnt+1)^080h,w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt)^080h,w	;volatile
	skipc
	goto	u696_21
	goto	u696_20
u696_21:
	goto	i1l5019
u696_20:
	line	190
	
i1l5005:	
	clrf	(_g_tempReadRoundCnt)^080h	;volatile
	clrf	(_g_tempReadRoundCnt+1)^080h	;volatile
	line	191
	
i1l5007:	
	movlw	low(01h)
	movwf	(_g_tempPhase)^080h	;volatile
	line	192
	
i1l5009:	
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	goto	i1l5019
	line	197
	
i1l5011:	
	incf	(_g_tempSettleCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1)^080h,f	;volatile
	line	198
	
i1l5013:	
	movlw	0
	subwf	(_g_tempSettleCnt+1)^080h,w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt)^080h,w	;volatile
	skipc
	goto	u697_21
	goto	u697_20
u697_21:
	goto	i1l5019
u697_20:
	line	200
	
i1l5015:	
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	201
	
i1l5017:	
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	line	202
	clrf	(_g_tempPhase)^080h	;volatile
	line	210
	
i1l5019:	
	incf	(_g_printTick)^080h,f	;volatile
	skipnz
	incf	(_g_printTick+1)^080h,f	;volatile
	movlw	01Fh
	subwf	((_g_printTick+1)^080h),w	;volatile
	movlw	040h
	skipnz
	subwf	((_g_printTick)^080h),w	;volatile
	skipc
	goto	u698_21
	goto	u698_20
u698_21:
	goto	i1l349
u698_20:
	line	212
	
i1l5021:	
	clrf	(_g_printTick)^080h	;volatile
	clrf	(_g_printTick+1)^080h	;volatile
	line	213
	
i1l5023:	
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	217
	
i1l349:	
	movf	(??_Isr_Timer+1),w
	movwf	pclath
	swapf	(??_Isr_Timer+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 80 in file "led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	file	"led.c"
	line	80
global __ptext25
__ptext25:	;psect for function _PowerOnLedSequence
psect	text25
	file	"led.c"
	line	80
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	82
	
i1l3577:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_powerOnTimer)^080h,f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1)^080h,f	;volatile
	line	84
	
i1l3579:	
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u395_21
	goto	u395_20
u395_21:
	goto	i1l3589
u395_20:
	line	89
	
i1l3581:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	90
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	91
	
i1l3583:	
	movlw	01Fh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w	;volatile
	movlw	040h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u396_21
	goto	u396_20
u396_21:
	goto	i1l877
u396_20:
	line	93
	
i1l3585:	
	clrf	(_g_powerOnTimer)^080h	;volatile
	clrf	(_g_powerOnTimer+1)^080h	;volatile
	line	94
	
i1l3587:	
	movlw	low(01h)
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l877
	line	97
	
i1l3589:	
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u397_21
	goto	u397_20
u397_21:
	goto	i1l877
u397_20:
	line	100
	
i1l3591:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	101
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	102
	
i1l3593:	
	movlw	01Fh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w	;volatile
	movlw	040h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u398_21
	goto	u398_20
u398_21:
	goto	i1l877
u398_20:
	line	104
	
i1l3595:	
	clrf	(_g_powerOnTimer)^080h	;volatile
	clrf	(_g_powerOnTimer+1)^080h	;volatile
	line	105
	
i1l3597:	
	movlw	low(02h)
	movwf	(_g_powerOnPhase)	;volatile
	line	109
	
i1l877:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
