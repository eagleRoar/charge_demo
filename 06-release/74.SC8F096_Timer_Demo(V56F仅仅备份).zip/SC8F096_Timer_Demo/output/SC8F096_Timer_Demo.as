opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_CCCV_Control
	FNCALL	_main,_Get_Vcc
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_Read_Temperature
	FNCALL	_main,_Slot_Charge_Ctrl
	FNCALL	_main,_System_Init
	FNCALL	_main,_Update_LED_Global
	FNCALL	_main,_uart_send_string
	FNCALL	_Update_LED_Global,___bmul
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Slot_Charge_Ctrl,_Adc_Norm
	FNCALL	_Slot_Charge_Ctrl,_Slot_Activate
	FNCALL	_Slot_Charge_Ctrl,_Slot_CC
	FNCALL	_Slot_Charge_Ctrl,_Slot_CV
	FNCALL	_Slot_Charge_Ctrl,_Slot_Detect
	FNCALL	_Slot_Charge_Ctrl,_Slot_DiodeTest
	FNCALL	_Slot_Charge_Ctrl,_Slot_Error
	FNCALL	_Slot_Charge_Ctrl,_Slot_Full
	FNCALL	_Slot_Charge_Ctrl,_Slot_Idle
	FNCALL	_Slot_Charge_Ctrl,_Slot_ImpCheck
	FNCALL	_Slot_Charge_Ctrl,_Slot_Precharge
	FNCALL	_Slot_Charge_Ctrl,___bmul
	FNCALL	_Slot_ImpCheck,_Get_Vcc
	FNCALL	_Slot_ImpCheck,_Route_LiIon
	FNCALL	_Slot_ImpCheck,___wmul
	FNCALL	_Slot_DiodeTest,_Route_LiIon
	FNCALL	_Slot_DiodeTest,_Route_LinearLi
	FNCALL	_Slot_DiodeTest,___wmul
	FNCALL	_Route_LinearLi,_Li_Route
	FNCALL	_Route_LiIon,_Li_Route
	FNCALL	_Slot_Detect,_Detect_BatteryType
	FNCALL	_Slot_Detect,_Get_Vcc
	FNCALL	_Slot_Detect,_Li_Route
	FNCALL	_Slot_Detect,___lwdiv
	FNCALL	_Li_Route,___lldiv
	FNCALL	_Li_Route,___lmul
	FNCALL	_Get_Vcc,_ADC_Sample
	FNCALL	_Get_Vcc,___lldiv
	FNCALL	_Adc_Norm,_ADC_Sample
	FNCALL	_Adc_Norm,___lldiv
	FNCALL	_Adc_Norm,___lmul
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,___bmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_vcc_mv
	global	_g_temperature
	global	_g_impCheckSlot
psect	idataBANK0,class=CODE,space=0,delta=2,noexec
global __pidataBANK0
__pidataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	43

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	31

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

	line	39

;initializer for _g_impCheckSlot
	retlw	0FFh
	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	65
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_diodeTraceCnt
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_impData
	global	_g_pwmDuty
	global	_g_slotRefV
	global	_g_stableCnt
	global	_g_detectLowCnt
	global	_g_diodeTrace
	global	_g_highVFlag
	global	_g_capFlag
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_powerOnTimer
	global	_g_cvIntegral
	global	_s_ledBlinkCnt
	global	_g_vccProtect
	global	_g_tempProtect
	global	_g_tempPhase
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_g_diodeTraceSlot
	global	_test_adc
	global	_adresult
	global	_g_slot
	global	_g_ovCnt
	global	_g_ccBlocks
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_GIE
_GIE	set	0x5F
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC4
_RC4	set	0x834
	global	_RC5
_RC5	set	0x835
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	0
psect	stringtext
	
STR_37:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_25:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_23:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	45	;'-'
	retlw	105	;'i'
	retlw	111	;'o'
	retlw	110	;'n'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	67	;'C'
	retlw	32	;' '
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	95	;'_'
	retlw	76	;'L'
	retlw	79	;'O'
	retlw	67	;'C'
	retlw	75	;'K'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_38:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_8:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_30:	
	retlw	32	;' '
	retlw	112	;'p'
	retlw	114	;'r'
	retlw	101	;'e'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	32	;' '
	retlw	114	;'r'
	retlw	101	;'e'
	retlw	102	;'f'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_31:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_29:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	73	;'I'
	retlw	79	;'O'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_7:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_34:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	114	;'r'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_32:	
	retlw	32	;' '
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_33:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	53	;'5'
	retlw	54	;'6'
	retlw	70	;'F'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
STR_27	equ	STR_17+0
STR_9	equ	STR_2+0
STR_11	equ	STR_38+7
STR_35	equ	STR_38+7
STR_36	equ	STR_38+7
; #config settings
	file	"SC8F096_Timer_Demo.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_g_diodeTraceCnt:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_impData:
       ds      2

_g_pwmDuty:
       ds      1

psect	dataBANK0,class=BANK0,space=1,noexec
global __pdataBANK0
__pdataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	43
_g_vcc_mv:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_slotRefV:
       ds      24

_g_stableCnt:
       ds      12

_g_detectLowCnt:
       ds      12

_g_diodeTrace:
       ds      4

_g_highVFlag:
       ds      2

_g_capFlag:
       ds      2

_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_powerOnTimer:
       ds      2

_g_cvIntegral:
       ds      2

_s_ledBlinkCnt:
       ds      1

_g_vccProtect:
       ds      1

_g_tempProtect:
       ds      1

_g_tempPhase:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_diodeTraceSlot:
       ds      1

_test_adc:
       ds      1

_adresult:
       ds      2

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	31
_g_temperature:
       ds      2

psect	dataBANK1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	39
_g_impCheckSlot:
       ds      1

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_ovCnt:
       ds      12

_g_ccBlocks:
       ds      12

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"SC8F096_Timer_Demo.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
	fcall	__pidataBANK1+2		;fetch initializer
	movwf	__pdataBANK1+2&07fh		
; Initialize objects allocated to BANK0
	global __pidataBANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	fcall	__pidataBANK0+0		;fetch initializer
	movwf	__pdataBANK0+0&07fh		
	fcall	__pidataBANK0+1		;fetch initializer
	movwf	__pdataBANK0+1&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+018h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+04Ch)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssBANK0)+0)&07Fh
	clrf	((__pbssBANK0)+1)&07Fh
	clrf	((__pbssBANK0)+2)&07Fh
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
	global	main@i
main@i:	; 1 bytes @ 0x0
	ds	1
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_Slot_Charge_Ctrl:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Update_LED_Global:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
??_Isr_Timer:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?_Get_Vcc:	; 2 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
Slot_Activate@1532:	; 1 bytes @ 0x0
	ds	2
??_AD_Init:	; 1 bytes @ 0x2
??_uart_init:	; 1 bytes @ 0x2
?_ADC_Sample:	; 1 bytes @ 0x2
??_uart_send_char:	; 1 bytes @ 0x2
?_Detect_BatteryType:	; 1 bytes @ 0x2
?___bmul:	; 1 bytes @ 0x2
	global	?_Slot_Idle
?_Slot_Idle:	; 2 bytes @ 0x2
	global	?_Slot_Activate
?_Slot_Activate:	; 2 bytes @ 0x2
	global	?_Slot_Precharge
?_Slot_Precharge:	; 2 bytes @ 0x2
	global	?_Slot_CC
?_Slot_CC:	; 2 bytes @ 0x2
	global	?_Slot_CV
?_Slot_CV:	; 2 bytes @ 0x2
	global	?_Slot_Full
?_Slot_Full:	; 2 bytes @ 0x2
	global	?_Slot_Error
?_Slot_Error:	; 2 bytes @ 0x2
	global	?___wmul
?___wmul:	; 2 bytes @ 0x2
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x2
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x2
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x2
	global	?___lmul
?___lmul:	; 4 bytes @ 0x2
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x2
	global	Slot_Idle@pst
Slot_Idle@pst:	; 1 bytes @ 0x2
	global	Slot_Activate@pst
Slot_Activate@pst:	; 1 bytes @ 0x2
	global	Slot_Precharge@pst
Slot_Precharge@pst:	; 1 bytes @ 0x2
	global	Slot_CC@pst
Slot_CC@pst:	; 1 bytes @ 0x2
	global	Slot_CV@pst
Slot_CV@pst:	; 1 bytes @ 0x2
	global	Slot_Full@pst
Slot_Full@pst:	; 1 bytes @ 0x2
	global	Slot_Error@pst
Slot_Error@pst:	; 1 bytes @ 0x2
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x2
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x2
	global	___wmul@multiplier
___wmul@multiplier:	; 2 bytes @ 0x2
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x2
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x2
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x2
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x2
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x3
??___bmul:	; 1 bytes @ 0x3
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x3
	global	Slot_CC@ty
Slot_CC@ty:	; 1 bytes @ 0x3
	global	Slot_CV@pty
Slot_CV@pty:	; 1 bytes @ 0x3
	global	Slot_Full@ty
Slot_Full@ty:	; 1 bytes @ 0x3
	global	Slot_Error@pty
Slot_Error@pty:	; 1 bytes @ 0x3
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x3
	global	Slot_Idle@v
Slot_Idle@v:	; 2 bytes @ 0x3
	global	Slot_Activate@v
Slot_Activate@v:	; 2 bytes @ 0x3
	global	Slot_Precharge@v
Slot_Precharge@v:	; 2 bytes @ 0x3
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x4
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x4
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x4
	global	Slot_CC@v
Slot_CC@v:	; 2 bytes @ 0x4
	global	Slot_CV@v
Slot_CV@v:	; 2 bytes @ 0x4
	global	Slot_Full@v
Slot_Full@v:	; 2 bytes @ 0x4
	global	Slot_Error@v
Slot_Error@v:	; 2 bytes @ 0x4
	global	___wmul@multiplicand
___wmul@multiplicand:	; 2 bytes @ 0x4
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x4
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x4
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x4
	ds	1
?_uart_send_string:	; 1 bytes @ 0x5
??_Update_LED_Global:	; 1 bytes @ 0x5
??_System_Init:	; 1 bytes @ 0x5
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x5
	global	Update_LED_Global@hasErr
Update_LED_Global@hasErr:	; 1 bytes @ 0x5
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x5
	global	Slot_Idle@ct
Slot_Idle@ct:	; 2 bytes @ 0x5
	global	Slot_Activate@ct
Slot_Activate@ct:	; 2 bytes @ 0x5
	global	Slot_Precharge@ct
Slot_Precharge@ct:	; 2 bytes @ 0x5
	ds	1
??___wmul:	; 1 bytes @ 0x6
??___awdiv:	; 1 bytes @ 0x6
??___lwdiv:	; 1 bytes @ 0x6
??___lwmod:	; 1 bytes @ 0x6
	global	Update_LED_Global@hasChg
Update_LED_Global@hasChg:	; 1 bytes @ 0x6
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x6
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x6
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x6
	global	Slot_CC@ct
Slot_CC@ct:	; 2 bytes @ 0x6
	global	Slot_CV@ct
Slot_CV@ct:	; 2 bytes @ 0x6
	global	Slot_Full@ct
Slot_Full@ct:	; 2 bytes @ 0x6
	global	Slot_Error@ct
Slot_Error@ct:	; 2 bytes @ 0x6
	global	___wmul@product
___wmul@product:	; 2 bytes @ 0x6
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x6
	ds	1
??_uart_send_string:	; 1 bytes @ 0x7
??_Slot_Idle:	; 1 bytes @ 0x7
??_Slot_Activate:	; 1 bytes @ 0x7
??_Slot_Precharge:	; 1 bytes @ 0x7
	global	Slot_Precharge@idx
Slot_Precharge@idx:	; 1 bytes @ 0x7
	global	Update_LED_Global@hasFull
Update_LED_Global@hasFull:	; 1 bytes @ 0x7
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x7
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x7
	ds	1
??_Slot_Full:	; 1 bytes @ 0x8
	global	Slot_CC@idx
Slot_CC@idx:	; 1 bytes @ 0x8
	global	Slot_CV@idx
Slot_CV@idx:	; 1 bytes @ 0x8
	global	Slot_Error@idx
Slot_Error@idx:	; 1 bytes @ 0x8
	global	Update_LED_Global@i
Update_LED_Global@i:	; 1 bytes @ 0x8
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x8
	ds	1
??_uart_send_number:	; 1 bytes @ 0x9
??_Print_NtcTemp:	; 1 bytes @ 0x9
	global	Update_LED_Global@s
Update_LED_Global@s:	; 1 bytes @ 0x9
	ds	1
??_Get_Vcc:	; 1 bytes @ 0xA
??_Adc_Norm:	; 1 bytes @ 0xA
??___lmul:	; 1 bytes @ 0xA
??___lldiv:	; 1 bytes @ 0xA
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
?_uart_send_number:	; 1 bytes @ 0x0
??_CCCV_Control:	; 1 bytes @ 0x0
??_Slot_CC:	; 1 bytes @ 0x0
??_Slot_CV:	; 1 bytes @ 0x0
??_Slot_Error:	; 1 bytes @ 0x0
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x0
	global	Slot_Idle@idx
Slot_Idle@idx:	; 1 bytes @ 0x0
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x0
	global	_Slot_Full$441
_Slot_Full$441:	; 2 bytes @ 0x0
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x0
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x1
	ds	1
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x2
	global	Slot_Full@idx
Slot_Full@idx:	; 1 bytes @ 0x2
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x2
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x2
	ds	1
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x4
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x4
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x4
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x5
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0x6
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0x7
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0x8
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x8
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x8
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x9
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0xA
	global	_Print_NtcTemp$812
_Print_NtcTemp$812:	; 2 bytes @ 0xA
	ds	1
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xC
	global	_Print_NtcTemp$813
_Print_NtcTemp$813:	; 2 bytes @ 0xC
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0xC
	ds	2
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0xE
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0xF
	ds	1
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x10
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0x10
	ds	1
??_Read_Temperature:	; 1 bytes @ 0x11
??_Print_SystemStatus:	; 1 bytes @ 0x11
?_Li_Route:	; 1 bytes @ 0x11
	global	?_Adc_Norm
?_Adc_Norm:	; 2 bytes @ 0x11
	global	Li_Route@v
Li_Route@v:	; 2 bytes @ 0x11
	global	Get_Vcc@pt
Get_Vcc@pt:	; 4 bytes @ 0x11
	ds	1
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x12
	ds	1
	global	Li_Route@pst
Li_Route@pst:	; 1 bytes @ 0x13
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x13
	ds	1
	global	Adc_Norm@ch
Adc_Norm@ch:	; 1 bytes @ 0x14
	global	Li_Route@pct
Li_Route@pct:	; 1 bytes @ 0x14
	ds	1
??_Li_Route:	; 1 bytes @ 0x15
	global	Adc_Norm@raw
Adc_Norm@raw:	; 2 bytes @ 0x15
	global	_Print_SystemStatus$814
_Print_SystemStatus$814:	; 2 bytes @ 0x15
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x15
	ds	2
	global	_Print_SystemStatus$815
_Print_SystemStatus$815:	; 2 bytes @ 0x17
	global	Adc_Norm@norm
Adc_Norm@norm:	; 4 bytes @ 0x17
	ds	2
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x19
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x19
	global	Li_Route@vx_mv
Li_Route@vx_mv:	; 4 bytes @ 0x19
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x1B
	ds	2
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x1D
	global	Li_Route@bat_mv_long
Li_Route@bat_mv_long:	; 4 bytes @ 0x1D
	ds	1
	global	_Print_SystemStatus$265
_Print_SystemStatus$265:	; 2 bytes @ 0x1E
	ds	2
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x20
	ds	1
	global	Li_Route@bat_mv
Li_Route@bat_mv:	; 2 bytes @ 0x21
	ds	1
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0x22
	ds	1
	global	Li_Route@idx
Li_Route@idx:	; 1 bytes @ 0x23
	ds	1
?_Route_LiIon:	; 1 bytes @ 0x24
?_Route_LinearLi:	; 1 bytes @ 0x24
	global	?_Slot_Detect
?_Slot_Detect:	; 2 bytes @ 0x24
	global	Route_LiIon@pty
Route_LiIon@pty:	; 1 bytes @ 0x24
	global	Route_LinearLi@pty
Route_LinearLi@pty:	; 1 bytes @ 0x24
	global	Slot_Detect@pst
Slot_Detect@pst:	; 1 bytes @ 0x24
	ds	1
	global	Route_LiIon@pst
Route_LiIon@pst:	; 1 bytes @ 0x25
	global	Route_LinearLi@pst
Route_LinearLi@pst:	; 1 bytes @ 0x25
	global	Slot_Detect@pty
Slot_Detect@pty:	; 1 bytes @ 0x25
	ds	1
	global	Route_LinearLi@pct
Route_LinearLi@pct:	; 1 bytes @ 0x26
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x26
	global	Route_LiIon@v
Route_LiIon@v:	; 2 bytes @ 0x26
	global	Slot_Detect@v
Slot_Detect@v:	; 2 bytes @ 0x26
	ds	1
??_Route_LinearLi:	; 1 bytes @ 0x27
	ds	1
	global	Route_LiIon@pct
Route_LiIon@pct:	; 1 bytes @ 0x28
	global	Slot_Detect@ct
Slot_Detect@ct:	; 2 bytes @ 0x28
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0x28
	ds	1
??_Route_LiIon:	; 1 bytes @ 0x29
	ds	1
??_Slot_Detect:	; 1 bytes @ 0x2A
	global	Route_LinearLi@idx
Route_LinearLi@idx:	; 1 bytes @ 0x2A
	ds	2
	global	Print_SystemStatus@tc
Print_SystemStatus@tc:	; 1 bytes @ 0x2C
	global	Route_LiIon@idx
Route_LiIon@idx:	; 1 bytes @ 0x2C
	ds	1
	global	?_Slot_ImpCheck
?_Slot_ImpCheck:	; 2 bytes @ 0x2D
	global	?_Slot_DiodeTest
?_Slot_DiodeTest:	; 2 bytes @ 0x2D
	global	Print_SystemStatus@t
Print_SystemStatus@t:	; 1 bytes @ 0x2D
	global	Slot_ImpCheck@pst
Slot_ImpCheck@pst:	; 1 bytes @ 0x2D
	global	Slot_DiodeTest@pst
Slot_DiodeTest@pst:	; 1 bytes @ 0x2D
	ds	1
	global	Slot_ImpCheck@pty
Slot_ImpCheck@pty:	; 1 bytes @ 0x2E
	global	Slot_DiodeTest@pty
Slot_DiodeTest@pty:	; 1 bytes @ 0x2E
	global	Print_SystemStatus@d
Print_SystemStatus@d:	; 2 bytes @ 0x2E
	ds	1
	global	Slot_Detect@v_init
Slot_Detect@v_init:	; 2 bytes @ 0x2F
	global	Slot_ImpCheck@v
Slot_ImpCheck@v:	; 2 bytes @ 0x2F
	global	Slot_DiodeTest@v
Slot_DiodeTest@v:	; 2 bytes @ 0x2F
	ds	1
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x30
	ds	1
	global	Slot_Detect@v_ref
Slot_Detect@v_ref:	; 2 bytes @ 0x31
	global	Slot_ImpCheck@ct
Slot_ImpCheck@ct:	; 2 bytes @ 0x31
	global	Slot_DiodeTest@ct
Slot_DiodeTest@ct:	; 2 bytes @ 0x31
	ds	2
??_Slot_ImpCheck:	; 1 bytes @ 0x33
??_Slot_DiodeTest:	; 1 bytes @ 0x33
	global	Slot_Detect@idx
Slot_Detect@idx:	; 1 bytes @ 0x33
	ds	4
	global	Slot_DiodeTest@tc
Slot_DiodeTest@tc:	; 1 bytes @ 0x37
	ds	1
	global	Slot_ImpCheck@idx
Slot_ImpCheck@idx:	; 1 bytes @ 0x38
	global	Slot_DiodeTest@hasRise
Slot_DiodeTest@hasRise:	; 1 bytes @ 0x38
	ds	1
	global	Slot_DiodeTest@diff
Slot_DiodeTest@diff:	; 2 bytes @ 0x39
	ds	2
	global	Slot_DiodeTest@pre
Slot_DiodeTest@pre:	; 2 bytes @ 0x3B
	ds	2
	global	Slot_DiodeTest@idx
Slot_DiodeTest@idx:	; 1 bytes @ 0x3D
	ds	1
??_Slot_Charge_Ctrl:	; 1 bytes @ 0x3E
	ds	1
	global	Slot_Charge_Ctrl@newv
Slot_Charge_Ctrl@newv:	; 2 bytes @ 0x3F
	ds	2
	global	Slot_Charge_Ctrl@dly
Slot_Charge_Ctrl@dly:	; 1 bytes @ 0x41
	ds	1
	global	Slot_Charge_Ctrl@v
Slot_Charge_Ctrl@v:	; 2 bytes @ 0x42
	ds	2
	global	Slot_Charge_Ctrl@ct
Slot_Charge_Ctrl@ct:	; 2 bytes @ 0x44
	ds	2
	global	Slot_Charge_Ctrl@idx
Slot_Charge_Ctrl@idx:	; 1 bytes @ 0x46
	ds	1
	global	Slot_Charge_Ctrl@ty
Slot_Charge_Ctrl@ty:	; 1 bytes @ 0x47
	ds	1
	global	Slot_Charge_Ctrl@st
Slot_Charge_Ctrl@st:	; 1 bytes @ 0x48
	ds	1
??_main:	; 1 bytes @ 0x49
	ds	2
;!
;!Data Sizes:
;!    Strings     254
;!    Constant    12
;!    Data        5
;!    BSS         176
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     10      12
;!    BANK0            80     75      80
;!    BANK1            80      1      80
;!    BANK3            80      0      24
;!    BANK2            80      0      72

;!
;!Pointer List with Targets:
;!
;!    Slot_Error@pst	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@st(BANK0[1]), 
;!
;!    Slot_Error@pty	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@ty(BANK0[1]), 
;!
;!    Slot_Full@pst	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@st(BANK0[1]), 
;!
;!    Slot_CV@pty	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@ty(BANK0[1]), 
;!
;!    Slot_CV@pst	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@st(BANK0[1]), 
;!
;!    Slot_CC@pst	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@st(BANK0[1]), 
;!
;!    Slot_Precharge@pst	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@st(BANK0[1]), 
;!
;!    Slot_Activate@pst	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@st(BANK0[1]), 
;!
;!    Slot_DiodeTest@pst	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@st(BANK0[1]), 
;!
;!    Slot_DiodeTest@pty	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@ty(BANK0[1]), 
;!
;!    Slot_ImpCheck@pst	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@st(BANK0[1]), 
;!
;!    Slot_ImpCheck@pty	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@ty(BANK0[1]), 
;!
;!    Slot_Detect@pst	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@st(BANK0[1]), 
;!
;!    Slot_Detect@pty	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@ty(BANK0[1]), 
;!
;!    Slot_Idle@pst	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@st(BANK0[1]), 
;!
;!    Route_LinearLi@pct	PTR unsigned int  size(1) Largest target is 2
;!		 -> Slot_DiodeTest@ct(BANK0[2]), 
;!
;!    Route_LinearLi@pst	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@st(BANK0[1]), 
;!
;!    Route_LinearLi@pty	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@ty(BANK0[1]), 
;!
;!    Route_LiIon@pct	PTR unsigned int  size(1) Largest target is 2
;!		 -> Slot_DiodeTest@ct(BANK0[2]), Slot_ImpCheck@ct(BANK0[2]), 
;!
;!    Route_LiIon@pst	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@st(BANK0[1]), 
;!
;!    Route_LiIon@pty	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@ty(BANK0[1]), 
;!
;!    Li_Route@pct	PTR unsigned int  size(1) Largest target is 2
;!		 -> Slot_DiodeTest@ct(BANK0[2]), Slot_ImpCheck@ct(BANK0[2]), Slot_Detect@ct(BANK0[2]), 
;!
;!    Li_Route@pst	PTR unsigned char  size(1) Largest target is 1
;!		 -> Slot_Charge_Ctrl@st(BANK0[1]), 
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 25
;!		 -> STR_38(CODE[10]), STR_37(CODE[21]), STR_36(CODE[3]), STR_35(CODE[3]), 
;!		 -> STR_34(CODE[5]), STR_33(CODE[5]), STR_32(CODE[5]), STR_31(CODE[6]), 
;!		 -> STR_30(CODE[6]), STR_29(CODE[6]), STR_28(CODE[6]), STR_27(CODE[6]), 
;!		 -> STR_26(CODE[6]), STR_25(CODE[16]), STR_24(CODE[13]), STR_23(CODE[15]), 
;!		 -> STR_22(CODE[7]), STR_21(CODE[5]), STR_20(CODE[5]), STR_19(CODE[6]), 
;!		 -> STR_18(CODE[6]), STR_17(CODE[6]), STR_16(CODE[6]), STR_15(CODE[7]), 
;!		 -> STR_14(CODE[4]), STR_13(CODE[6]), STR_12(CODE[6]), STR_11(CODE[3]), 
;!		 -> STR_10(CODE[12]), STR_9(CODE[2]), STR_8(CODE[6]), STR_7(CODE[5]), 
;!		 -> STR_6(CODE[6]), STR_5(CODE[5]), STR_4(CODE[25]), STR_3(CODE[4]), 
;!		 -> STR_2(CODE[2]), STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    _main->_Update_LED_Global
;!    _Update_LED_Global->___bmul
;!    _System_Init->___bmul
;!    _Slot_Charge_Ctrl->_Slot_Idle
;!    _Li_Route->___lmul
;!    _Adc_Norm->___lmul
;!    _Read_Temperature->___lmul
;!    _Print_SystemStatus->___lmul
;!    ___lldiv->___lmul
;!    _Print_NtcTemp->___lwdiv
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    None.
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Slot_Charge_Ctrl
;!    _Slot_Charge_Ctrl->_Slot_DiodeTest
;!    _Slot_ImpCheck->_Route_LiIon
;!    _Slot_DiodeTest->_Route_LiIon
;!    _Route_LinearLi->_Li_Route
;!    _Route_LiIon->_Li_Route
;!    _Slot_Detect->_Li_Route
;!    _Li_Route->___lldiv
;!    _Get_Vcc->___lldiv
;!    _Adc_Norm->___lldiv
;!    _Read_Temperature->___lldiv
;!    _Print_SystemStatus->___lldiv
;!    ___lldiv->___lmul
;!    _Print_NtcTemp->_uart_send_number
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    None.
;!
;!Critical Paths under _main in BANK1
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 3     3      0   84411
;!                                             73 BANK0      2     2      0
;!                                              0 BANK1      1     1      0
;!                       _CCCV_Control
;!                            _Get_Vcc
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                   _Read_Temperature
;!                   _Slot_Charge_Ctrl
;!                        _System_Init
;!                  _Update_LED_Global
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Update_LED_Global                                    5     5      0    1173
;!                                              5 COMMON     5     5      0
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1090
;!                                              5 COMMON     1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Slot_Charge_Ctrl                                    11    11      0   52007
;!                                             62 BANK0     11    11      0
;!                           _Adc_Norm
;!                      _Slot_Activate
;!                            _Slot_CC
;!                            _Slot_CV
;!                        _Slot_Detect
;!                     _Slot_DiodeTest
;!                         _Slot_Error
;!                          _Slot_Full
;!                          _Slot_Idle
;!                      _Slot_ImpCheck
;!                     _Slot_Precharge
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) _Slot_Precharge                                       6     1      5     728
;!                                              2 COMMON     6     1      5
;! ---------------------------------------------------------------------------------
;! (2) _Slot_ImpCheck                                       12     6      6   10252
;!                                             45 BANK0     12     6      6
;!                            _Get_Vcc
;!                        _Route_LiIon
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (2) _Slot_Idle                                            9     4      5     542
;!                                              2 COMMON     8     3      5
;!                                              0 BANK0      1     1      0
;! ---------------------------------------------------------------------------------
;! (2) _Slot_Full                                            9     3      6     923
;!                                              2 COMMON     6     0      6
;!                                              0 BANK0      3     3      0
;! ---------------------------------------------------------------------------------
;! (2) _Slot_Error                                          12     6      6    1137
;!                                              2 COMMON     7     1      6
;!                                              0 BANK0      5     5      0
;! ---------------------------------------------------------------------------------
;! (2) _Slot_DiodeTest                                      17    11      6   15363
;!                                             45 BANK0     17    11      6
;!                        _Route_LiIon
;!                     _Route_LinearLi
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (3) ___wmul                                               6     2      4    2488
;!                                              2 COMMON     6     2      4
;! ---------------------------------------------------------------------------------
;! (3) _Route_LinearLi                                       7     4      3    5108
;!                                             36 BANK0      7     4      3
;!                           _Li_Route
;! ---------------------------------------------------------------------------------
;! (3) _Route_LiIon                                          9     4      5    4554
;!                                             36 BANK0      9     4      5
;!                           _Li_Route
;! ---------------------------------------------------------------------------------
;! (2) _Slot_Detect                                         16    10      6   10284
;!                                             36 BANK0     16    10      6
;!                 _Detect_BatteryType
;!                            _Get_Vcc
;!                           _Li_Route
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (4) _Li_Route                                            19    15      4    3588
;!                                             17 BANK0     19    15      4
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (3) _Get_Vcc                                              4     4      0    2132
;!                                             17 BANK0      4     4      0
;!                         _ADC_Sample
;!                            ___lldiv
;! ---------------------------------------------------------------------------------
;! (3) _Detect_BatteryType                                   2     0      2     251
;!                                              2 COMMON     2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _Slot_CV                                             11     5      6    2262
;!                                              2 COMMON     7     1      6
;!                                              0 BANK0      4     4      0
;! ---------------------------------------------------------------------------------
;! (2) _Slot_CC                                             11     5      6    2764
;!                                              2 COMMON     7     1      6
;!                                              0 BANK0      4     4      0
;! ---------------------------------------------------------------------------------
;! (2) _Slot_Activate                                        6     1      5     511
;!                                              2 COMMON     5     0      5
;! ---------------------------------------------------------------------------------
;! (2) _Adc_Norm                                            10     7      3    3469
;!                                             17 BANK0     10     7      3
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (1) _Read_Temperature                                    12    12      0    4485
;!                                             17 BANK0     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  32    32      0   11818
;!                                             17 BANK0     32    32      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (5) ___lmul                                              12     4      8    1207
;!                                              2 COMMON     8     0      8
;!                                              0 BANK0      4     4      0
;! ---------------------------------------------------------------------------------
;! (5) ___lldiv                                             13     5      8    1068
;!                                              4 BANK0     13     5      8
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (4) _ADC_Sample                                          18    17      1    1030
;!                                              2 COMMON     5     4      1
;!                                              0 BANK0     13    13      0
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    6430
;!                                             10 BANK0      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    2637
;!                                              5 COMMON     2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_number                                    10     8      2    2628
;!                                              0 BANK0     10     8      2
;!                             ___bmul (ARG)
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     102
;!                                              2 COMMON     3     3      0
;! ---------------------------------------------------------------------------------
;! (3) ___lwmod                                              5     1      4     378
;!                                              2 COMMON     5     1      4
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4     777
;!                                              2 COMMON     7     3      4
;! ---------------------------------------------------------------------------------
;! (1) _CCCV_Control                                        20    20      0    2540
;!                                              0 BANK0     20    20      0
;!                            ___awdiv
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1     836
;!                                              2 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (2) ___awdiv                                              8     4      4     606
;!                                              2 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 5
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (6) _Isr_Timer                                            2     2      0       0
;!                                              0 COMMON     2     2      0
;!                 _PowerOnLedSequence
;! ---------------------------------------------------------------------------------
;! (7) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 7
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     ___bmul
;!   _Get_Vcc
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Read_Temperature
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!   _Slot_Charge_Ctrl
;!     _Adc_Norm
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!     _Slot_Activate
;!     _Slot_CC
;!     _Slot_CV
;!     _Slot_Detect
;!       _Detect_BatteryType
;!       _Get_Vcc
;!         _ADC_Sample
;!         ___lldiv
;!           ___lmul (ARG)
;!       _Li_Route
;!         ___lldiv
;!           ___lmul (ARG)
;!         ___lmul
;!       ___lwdiv
;!     _Slot_DiodeTest
;!       _Route_LiIon
;!         _Li_Route
;!           ___lldiv
;!             ___lmul (ARG)
;!           ___lmul
;!       _Route_LinearLi
;!         _Li_Route
;!           ___lldiv
;!             ___lmul (ARG)
;!           ___lmul
;!       ___wmul
;!     _Slot_Error
;!     _Slot_Full
;!     _Slot_Idle
;!     _Slot_ImpCheck
;!       _Get_Vcc
;!         _ADC_Sample
;!         ___lldiv
;!           ___lmul (ARG)
;!       _Route_LiIon
;!         _Li_Route
;!           ___lldiv
;!             ___lmul (ARG)
;!           ___lmul
;!       ___wmul
;!     _Slot_Precharge
;!     ___bmul
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _Update_LED_Global
;!     ___bmul
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _PowerOnLedSequence
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50      0      18       8       30.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      0      48      10       90.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50      1      50       6      100.0%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     4B      50       4      100.0%
;!BITBANK0            50      0       0       3        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      A       C       1       85.7%
;!BITCOMMON            E      0       1       0        7.1%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     10C      12        0.0%
;!ABS                  0      0     10C      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 426 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1    0[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       1       0       0
;;      Temps:          0       2       0       0       0
;;      Totals:         0       2       1       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels required when called:    7
;; This function calls:
;;		_CCCV_Control
;;		_Get_Vcc
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_Slot_Charge_Ctrl
;;		_System_Init
;;		_Update_LED_Global
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	426
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	426
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 1
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	431
	
l7360:	
;main.c: 428: unsigned char i;
;main.c: 431: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_main+0)+0+1),f
	movlw	241
movwf	((??_main+0)+0),f
	u10007:
decfsz	((??_main+0)+0),f
	goto	u10007
	decfsz	((??_main+0)+0+1),f
	goto	u10007
opt asmopt_pop

	line	432
# 432 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	435
	
l7362:	
;main.c: 435: System_Init();
	fcall	_System_Init
	line	438
	
l7364:	
;main.c: 438: uart_send_string("L1211 Charger V2.1\r\n");
	movlw	low(((STR_37)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_37)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	439
	
l7366:	
;main.c: 439: uart_send_string("Init...\r\n");
	movlw	low(((STR_38)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_38)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	443
;main.c: 443: while(1)
	
l406:	
	line	445
# 445 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	448
	
l7368:	
;main.c: 448: Get_Vcc();
	fcall	_Get_Vcc
	line	451
	
l7370:	
;main.c: 451: for(i = 0; i < 12; i++)
	bsf	status, 5	;RP0=1, select bank1
	clrf	(main@i)^080h
	line	453
	
l7376:	
;main.c: 452: {
;main.c: 453: Slot_Charge_Ctrl(i);
	movf	(main@i)^080h,w
	fcall	_Slot_Charge_Ctrl
	line	451
	
l7378:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(main@i)^080h,f
	
l7380:	
	movlw	low(0Ch)
	subwf	(main@i)^080h,w
	skipc
	goto	u9971
	goto	u9970
u9971:
	goto	l7376
u9970:
	line	457
	
l7382:	
;main.c: 454: }
;main.c: 457: CCCV_Control();
	fcall	_CCCV_Control
	line	460
	
l7384:	
;main.c: 460: Update_LED_Global();
	fcall	_Update_LED_Global
	line	463
	
l7386:	
;main.c: 463: if(g_doNtcRead)
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u9981
	goto	u9980
u9981:
	goto	l7392
u9980:
	line	465
	
l7388:	
;main.c: 464: {
;main.c: 465: g_doNtcRead = 0;
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	466
	
l7390:	
;main.c: 466: Read_Temperature();
	fcall	_Read_Temperature
	line	471
	
l7392:	
;main.c: 467: }
;main.c: 471: if(g_printFlag)
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u9991
	goto	u9990
u9991:
	goto	l406
u9990:
	line	473
	
l7394:	
;main.c: 472: {
;main.c: 473: g_printFlag = 0;
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	474
	
l7396:	
;main.c: 474: Print_SystemStatus();
	fcall	_Print_SystemStatus
	line	475
;main.c: 475: Print_NtcTemp();
	fcall	_Print_NtcTemp
	goto	l406
	global	start
	ljmp	start
	opt stack 0
	line	479
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_Update_LED_Global

;; *************** function _Update_LED_Global *****************
;; Defined at:
;;		line 27 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    9[COMMON] unsigned char 
;;  i               1    8[COMMON] unsigned char 
;;  hasFull         1    7[COMMON] unsigned char 
;;  hasChg          1    6[COMMON] unsigned char 
;;  hasErr          1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/900
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         5       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	27
global __ptext1
__ptext1:	;psect for function _Update_LED_Global
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	27
	global	__size_of_Update_LED_Global
	__size_of_Update_LED_Global	equ	__end_of_Update_LED_Global-_Update_LED_Global
	
_Update_LED_Global:	
;incstack = 0
	opt	stack 4
; Regs used in _Update_LED_Global: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	30
	
l7278:	
;led.c: 29: unsigned char i;
;led.c: 30: unsigned char hasErr = 0;
	clrf	(Update_LED_Global@hasErr)
	line	31
;led.c: 31: unsigned char hasChg = 0;
	clrf	(Update_LED_Global@hasChg)
	line	32
;led.c: 32: unsigned char hasFull = 0;
	clrf	(Update_LED_Global@hasFull)
	line	34
;led.c: 34: for(i = 0; i < 12; i++)
	clrf	(Update_LED_Global@i)
	line	36
	
l7284:	
;led.c: 35: {
;led.c: 36: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Global@s)
	line	37
	
l7286:	
;led.c: 37: if(s == 7)
		movlw	7
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u9751
	goto	u9750
u9751:
	goto	l7290
u9750:
	line	38
	
l7288:	
;led.c: 38: hasErr = 1;
	clrf	(Update_LED_Global@hasErr)
	incf	(Update_LED_Global@hasErr),f
	goto	l7300
	line	39
	
l7290:	
;led.c: 39: else if(s != 0 && s != 6)
	movf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u9761
	goto	u9760
u9761:
	goto	l7296
u9760:
	
l7292:	
		movlw	6
	xorwf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u9771
	goto	u9770
u9771:
	goto	l7296
u9770:
	line	40
	
l7294:	
;led.c: 40: hasChg = 1;
	clrf	(Update_LED_Global@hasChg)
	incf	(Update_LED_Global@hasChg),f
	goto	l7300
	line	41
	
l7296:	
;led.c: 41: else if(s == 6)
		movlw	6
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u9781
	goto	u9780
u9781:
	goto	l7300
u9780:
	line	42
	
l7298:	
;led.c: 42: hasFull = 1;
	clrf	(Update_LED_Global@hasFull)
	incf	(Update_LED_Global@hasFull),f
	line	34
	
l7300:	
	incf	(Update_LED_Global@i),f
	
l7302:	
	movlw	low(0Ch)
	subwf	(Update_LED_Global@i),w
	skipc
	goto	u9791
	goto	u9790
u9791:
	goto	l7284
u9790:
	line	45
	
l7304:	
;led.c: 43: }
;led.c: 45: if(hasErr)
	movf	((Update_LED_Global@hasErr)),w
	btfsc	status,2
	goto	u9801
	goto	u9800
u9801:
	goto	l7314
u9800:
	line	48
	
l7306:	
;led.c: 46: {
;led.c: 48: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	49
	
l7308:	
;led.c: 49: if(++s_ledBlinkCnt >= (16 / 2))
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(_s_ledBlinkCnt)^080h,f	;volatile
	subwf	((_s_ledBlinkCnt)^080h),w	;volatile
	skipc
	goto	u9811
	goto	u9810
u9811:
	goto	l7312
u9810:
	line	50
	
l7310:	
;led.c: 50: s_ledBlinkCnt = 0;
	clrf	(_s_ledBlinkCnt)^080h	;volatile
	line	51
	
l7312:	
;led.c: 51: RC5 = (s_ledBlinkCnt < ((16 / 2) / 2)) ? 0 : 1;
	movlw	low(04h)
	subwf	(_s_ledBlinkCnt)^080h,w	;volatile
	skipnc
	goto	u9821
	goto	u9820
	
u9821:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u9834
u9820:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u9834:
	line	52
;led.c: 52: }
	goto	l880
	line	53
	
l7314:	
;led.c: 53: else if(hasChg)
	movf	((Update_LED_Global@hasChg)),w
	btfsc	status,2
	goto	u9841
	goto	u9840
u9841:
	goto	l7318
u9840:
	line	56
	
l7316:	
;led.c: 54: {
;led.c: 56: RC5 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	57
;led.c: 57: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	58
;led.c: 58: }
	goto	l880
	line	59
	
l7318:	
;led.c: 59: else if(hasFull)
	movf	((Update_LED_Global@hasFull)),w
	btfsc	status,2
	goto	u9851
	goto	u9850
u9851:
	goto	l878
u9850:
	line	62
	
l7320:	
;led.c: 60: {
;led.c: 62: RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	63
;led.c: 63: RC4 = 0;
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	64
;led.c: 64: }
	goto	l880
	line	65
	
l878:	
	line	68
;led.c: 65: else
;led.c: 66: {
;led.c: 68: RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	69
;led.c: 69: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	71
	
l880:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Global
	__end_of_Update_LED_Global:
	signat	_Update_LED_Global,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 86 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         1       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	86
global __ptext2
__ptext2:	;psect for function _System_Init
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	86
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 4
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	91
	
l6802:	
# 91 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	92
# 92 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text2
	line	93
	
l6804:	
;main.c: 93: OSCCON = 0x72;
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	97
;main.c: 97: TRISA = 0xF0; PORTA = 0x0F;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	98
;main.c: 98: TRISB = 0x30; PORTB = 0x4F;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	99
;main.c: 99: TRISC = 0x07; PORTC = 0x00;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l6806:	
	clrf	(262)^0100h	;volatile
	line	101
	
l6808:	
;main.c: 101: TRISD = 0xF0; PORTD = 0x0F;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l6810:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	104
	
l6812:	
;main.c: 104: WPUA = 0x00; WPDA = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l6814:	
	clrf	(135)^080h	;volatile
	line	105
	
l6816:	
;main.c: 105: WPUB = 0x00; WPDB = 0x00;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l6818:	
	clrf	(7)	;volatile
	line	106
	
l6820:	
;main.c: 106: WPUC = 0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	107
	
l6822:	
;main.c: 107: WPUD = 0x00;
	clrf	(277)^0100h	;volatile
	line	110
	
l6824:	
;main.c: 110: IOCA = 0x00; IOCB = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l6826:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	113
	
l6828:	
;main.c: 113: CC0CON = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	114
	
l6830:	
;main.c: 114: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	121
	
l6832:	
;main.c: 121: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	122
	
l6834:	
;main.c: 122: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	123
	
l6836:	
;main.c: 123: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	124
	
l6838:	
;main.c: 124: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	127
	
l6840:	
;main.c: 127: AD_Init();
	fcall	_AD_Init
	line	131
	
l6842:	
;main.c: 131: uart_init();
	fcall	_uart_init
	line	138
;main.c: 138: OPTION_REG = 0x00;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	139
	
l6844:	
;main.c: 139: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	140
	
l6846:	
;main.c: 140: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	141
	
l6848:	
;main.c: 141: INTCON = 0xE0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	145
;main.c: 145: g_pwmDuty = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	146
;main.c: 146: g_pwmCounter = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_pwmCounter)^080h	;volatile
	line	147
	
l6850:	
;main.c: 147: RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	148
	
l6852:	
;main.c: 148: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	149
	
l6854:	
;main.c: 149: RB6 = 1;
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	150
	
l6856:	
;main.c: 150: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	153
;main.c: 153: for(i = 0; i < 12; i++)
	clrf	(System_Init@i)
	line	155
	
l6862:	
;main.c: 154: {
;main.c: 155: g_slot[i].state = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	156
;main.c: 156: g_slot[i].type = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	157
;main.c: 157: g_slot[i].voltage = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	158
;main.c: 158: g_slot[i].chargeTimer = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	159
	
l6864:	
;main.c: 159: g_ccBlocks[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	160
	
l6866:	
;main.c: 160: g_ovCnt[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	153
	
l6868:	
	incf	(System_Init@i),f
	
l6870:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u9131
	goto	u9130
u9131:
	goto	l6862
u9130:
	line	164
	
l339:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
global __ptext3
__ptext3:	;psect for function _uart_init
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 4
; Regs used in _uart_init: []
	line	23
	
l5694:	
;uart_dbg.c: 23: TRISC &= (unsigned char)~0x10;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
;uart_dbg.c: 24: ANSEL2 &= (unsigned char)~0x10;
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
;uart_dbg.c: 25: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l443:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
global __ptext4
__ptext4:	;psect for function _AD_Init
psect	text4
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 4
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l5688:	
;adc_drv.c: 25: CC0CON = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
;adc_drv.c: 26: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	27
	
l5690:	
;adc_drv.c: 27: ADCON0 = 0X81;
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l5692:	
;adc_drv.c: 28: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	29
	
l420:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Slot_Charge_Ctrl

;; *************** function _Slot_Charge_Ctrl *****************
;; Defined at:
;;		line 1234 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   70[BANK0 ] unsigned char 
;;  newv            2   63[BANK0 ] unsigned int 
;;  ct              2   68[BANK0 ] unsigned int 
;;  v               2   66[BANK0 ] unsigned int 
;;  st              1   72[BANK0 ] unsigned char 
;;  ty              1   71[BANK0 ] unsigned char 
;;  dly             1   65[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      10       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0      11       0       0       0
;;Total ram usage:       11 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_Adc_Norm
;;		_Slot_Activate
;;		_Slot_CC
;;		_Slot_CV
;;		_Slot_Detect
;;		_Slot_DiodeTest
;;		_Slot_Error
;;		_Slot_Full
;;		_Slot_Idle
;;		_Slot_ImpCheck
;;		_Slot_Precharge
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1234
global __ptext5
__ptext5:	;psect for function _Slot_Charge_Ctrl
psect	text5
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1234
	global	__size_of_Slot_Charge_Ctrl
	__size_of_Slot_Charge_Ctrl	equ	__end_of_Slot_Charge_Ctrl-_Slot_Charge_Ctrl
	
_Slot_Charge_Ctrl:	
;incstack = 0
	opt	stack 1
; Regs used in _Slot_Charge_Ctrl: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
;Slot_Charge_Ctrl@idx stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@idx)
	line	1240
;charge_mgr.c: 1236: unsigned char st, ty;
;charge_mgr.c: 1237: unsigned int v, ct;
;charge_mgr.c: 1238: unsigned char dly;
;charge_mgr.c: 1240: do { st = g_slot[(idx)].state; ty = g_slot[(idx)].type; v = g_slot[(idx)].voltage; ct = g_slot[(idx)].chargeTimer; } while(0);
	
l744:	
	
l7066:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@st)
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@ty)
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@v)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v+1)
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@ct)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@ct+1)
	goto	l7070
	line	1243
	
l748:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l7072
	
l750:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l7072
	
l751:	
	bsf	(51/8),(51)&7	;volatile
	goto	l7072
	
l752:	
	bsf	(50/8),(50)&7	;volatile
	goto	l7072
	
l753:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l7072
	
l754:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l7072
	
l755:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l7072
	
l756:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l7072
	
l757:	
	bsf	(48/8),(48)&7	;volatile
	goto	l7072
	
l758:	
	bsf	(49/8),(49)&7	;volatile
	goto	l7072
	
l759:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l7072
	
l760:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l7072
	
l7070:	
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l748
	xorlw	1^0	; case 1
	skipnz
	goto	l750
	xorlw	2^1	; case 2
	skipnz
	goto	l751
	xorlw	3^2	; case 3
	skipnz
	goto	l752
	xorlw	4^3	; case 4
	skipnz
	goto	l753
	xorlw	5^4	; case 5
	skipnz
	goto	l754
	xorlw	6^5	; case 6
	skipnz
	goto	l755
	xorlw	7^6	; case 7
	skipnz
	goto	l756
	xorlw	8^7	; case 8
	skipnz
	goto	l757
	xorlw	9^8	; case 9
	skipnz
	goto	l758
	xorlw	10^9	; case 10
	skipnz
	goto	l759
	xorlw	11^10	; case 11
	skipnz
	goto	l760
	goto	l7072
	opt asmopt_pop

	line	1244
	
l7072:	
;charge_mgr.c: 1244: if(st == 1 || st == 8 || st == 9)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
		decf	((Slot_Charge_Ctrl@st)),w
	btfsc	status,2
	goto	u9331
	goto	u9330
u9331:
	goto	l7078
u9330:
	
l7074:	
		movlw	8
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfsc	status,2
	goto	u9341
	goto	u9340
u9341:
	goto	l7078
u9340:
	
l7076:	
		movlw	9
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfss	status,2
	goto	u9351
	goto	u9350
u9351:
	goto	l7090
u9350:
	line	1247
	
l7078:	
;charge_mgr.c: 1245: {
;charge_mgr.c: 1247: for(dly = 0; dly < 20; dly++)
	clrf	(Slot_Charge_Ctrl@dly)
	line	1248
	
l7084:	
;charge_mgr.c: 1248: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u10017:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u10017
	nop
opt asmopt_pop

	line	1247
	
l7086:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Slot_Charge_Ctrl@dly),f
	
l7088:	
	movlw	low(014h)
	subwf	(Slot_Charge_Ctrl@dly),w
	skipc
	goto	u9361
	goto	u9360
u9361:
	goto	l7084
u9360:
	goto	l7092
	line	1252
	
l7090:	
;charge_mgr.c: 1250: else
;charge_mgr.c: 1251: {
;charge_mgr.c: 1252: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u10027:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u10027
	nop
opt asmopt_pop

	line	1256
	
l7092:	
;charge_mgr.c: 1253: }
;charge_mgr.c: 1255: {
;charge_mgr.c: 1256: unsigned int newv = Adc_Norm(s_adcChannels[idx]);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	fcall	_Adc_Norm
	movf	(1+(?_Adc_Norm)),w
	movwf	(Slot_Charge_Ctrl@newv+1)
	movf	(0+(?_Adc_Norm)),w
	movwf	(Slot_Charge_Ctrl@newv)
	line	1260
	
l7094:	
;charge_mgr.c: 1258: if(!(ty == 6 &&
;charge_mgr.c: 1259: (st == 4 || st == 5) &&
;charge_mgr.c: 1260: newv >= 4090))
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)),w
	btfss	status,2
	goto	u9371
	goto	u9370
u9371:
	goto	l7102
u9370:
	
l7096:	
		movlw	4
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfsc	status,2
	goto	u9381
	goto	u9380
u9381:
	goto	l7100
u9380:
	
l7098:	
		movlw	5
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfss	status,2
	goto	u9391
	goto	u9390
u9391:
	goto	l7102
u9390:
	
l7100:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@newv+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@newv),w
	skipnc
	goto	u9401
	goto	u9400
u9401:
	goto	l7128
u9400:
	line	1262
	
l7102:	
;charge_mgr.c: 1261: {
;charge_mgr.c: 1262: v = newv;
	movf	(Slot_Charge_Ctrl@newv+1),w
	movwf	(Slot_Charge_Ctrl@v+1)
	movf	(Slot_Charge_Ctrl@newv),w
	movwf	(Slot_Charge_Ctrl@v)
	goto	l7128
	line	1268
	
l7104:	
	movlw	(low(Slot_Charge_Ctrl@st|((0x0)<<8)))&0ffh
	movwf	(Slot_Idle@pst)
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	(Slot_Idle@v+1)
	movf	(Slot_Charge_Ctrl@v),w
	movwf	(Slot_Idle@v)
	movf	(Slot_Charge_Ctrl@ct+1),w
	movwf	(Slot_Idle@ct+1)
	movf	(Slot_Charge_Ctrl@ct),w
	movwf	(Slot_Idle@ct)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Slot_Idle
	movf	(1+(?_Slot_Idle)),w
	movwf	(Slot_Charge_Ctrl@ct+1)
	movf	(0+(?_Slot_Idle)),w
	movwf	(Slot_Charge_Ctrl@ct)
	goto	l7130
	line	1269
	
l7106:	
	movlw	(low(Slot_Charge_Ctrl@st|((0x0)<<8)))&0ffh
	movwf	(Slot_Detect@pst)
	movlw	(low(Slot_Charge_Ctrl@ty|((0x0)<<8)))&0ffh
	movwf	(Slot_Detect@pty)
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	(Slot_Detect@v+1)
	movf	(Slot_Charge_Ctrl@v),w
	movwf	(Slot_Detect@v)
	movf	(Slot_Charge_Ctrl@ct+1),w
	movwf	(Slot_Detect@ct+1)
	movf	(Slot_Charge_Ctrl@ct),w
	movwf	(Slot_Detect@ct)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Slot_Detect
	movf	(1+(?_Slot_Detect)),w
	movwf	(Slot_Charge_Ctrl@ct+1)
	movf	(0+(?_Slot_Detect)),w
	movwf	(Slot_Charge_Ctrl@ct)
	goto	l7130
	line	1270
	
l7108:	
	movlw	(low(Slot_Charge_Ctrl@st|((0x0)<<8)))&0ffh
	movwf	(Slot_ImpCheck@pst)
	movlw	(low(Slot_Charge_Ctrl@ty|((0x0)<<8)))&0ffh
	movwf	(Slot_ImpCheck@pty)
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	(Slot_ImpCheck@v+1)
	movf	(Slot_Charge_Ctrl@v),w
	movwf	(Slot_ImpCheck@v)
	movf	(Slot_Charge_Ctrl@ct+1),w
	movwf	(Slot_ImpCheck@ct+1)
	movf	(Slot_Charge_Ctrl@ct),w
	movwf	(Slot_ImpCheck@ct)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Slot_ImpCheck
	movf	(1+(?_Slot_ImpCheck)),w
	movwf	(Slot_Charge_Ctrl@ct+1)
	movf	(0+(?_Slot_ImpCheck)),w
	movwf	(Slot_Charge_Ctrl@ct)
	goto	l7130
	line	1271
	
l7110:	
	movlw	(low(Slot_Charge_Ctrl@st|((0x0)<<8)))&0ffh
	movwf	(Slot_DiodeTest@pst)
	movlw	(low(Slot_Charge_Ctrl@ty|((0x0)<<8)))&0ffh
	movwf	(Slot_DiodeTest@pty)
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	(Slot_DiodeTest@v+1)
	movf	(Slot_Charge_Ctrl@v),w
	movwf	(Slot_DiodeTest@v)
	movf	(Slot_Charge_Ctrl@ct+1),w
	movwf	(Slot_DiodeTest@ct+1)
	movf	(Slot_Charge_Ctrl@ct),w
	movwf	(Slot_DiodeTest@ct)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Slot_DiodeTest
	movf	(1+(?_Slot_DiodeTest)),w
	movwf	(Slot_Charge_Ctrl@ct+1)
	movf	(0+(?_Slot_DiodeTest)),w
	movwf	(Slot_Charge_Ctrl@ct)
	goto	l7130
	line	1272
	
l7112:	
	movlw	(low(Slot_Charge_Ctrl@st|((0x0)<<8)))&0ffh
	movwf	(Slot_Activate@pst)
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	(Slot_Activate@v+1)
	movf	(Slot_Charge_Ctrl@v),w
	movwf	(Slot_Activate@v)
	movf	(Slot_Charge_Ctrl@ct+1),w
	movwf	(Slot_Activate@ct+1)
	movf	(Slot_Charge_Ctrl@ct),w
	movwf	(Slot_Activate@ct)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Slot_Activate
	movf	(1+(?_Slot_Activate)),w
	movwf	(Slot_Charge_Ctrl@ct+1)
	movf	(0+(?_Slot_Activate)),w
	movwf	(Slot_Charge_Ctrl@ct)
	goto	l7130
	line	1273
	
l7114:	
	movlw	(low(Slot_Charge_Ctrl@st|((0x0)<<8)))&0ffh
	movwf	(Slot_Precharge@pst)
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	(Slot_Precharge@v+1)
	movf	(Slot_Charge_Ctrl@v),w
	movwf	(Slot_Precharge@v)
	movf	(Slot_Charge_Ctrl@ct+1),w
	movwf	(Slot_Precharge@ct+1)
	movf	(Slot_Charge_Ctrl@ct),w
	movwf	(Slot_Precharge@ct)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Slot_Precharge
	movf	(1+(?_Slot_Precharge)),w
	movwf	(Slot_Charge_Ctrl@ct+1)
	movf	(0+(?_Slot_Precharge)),w
	movwf	(Slot_Charge_Ctrl@ct)
	goto	l7130
	line	1274
	
l7116:	
	movlw	(low(Slot_Charge_Ctrl@st|((0x0)<<8)))&0ffh
	movwf	(Slot_CC@pst)
	movf	(Slot_Charge_Ctrl@ty),w
	movwf	(Slot_CC@ty)
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	(Slot_CC@v+1)
	movf	(Slot_Charge_Ctrl@v),w
	movwf	(Slot_CC@v)
	movf	(Slot_Charge_Ctrl@ct+1),w
	movwf	(Slot_CC@ct+1)
	movf	(Slot_Charge_Ctrl@ct),w
	movwf	(Slot_CC@ct)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Slot_CC
	movf	(1+(?_Slot_CC)),w
	movwf	(Slot_Charge_Ctrl@ct+1)
	movf	(0+(?_Slot_CC)),w
	movwf	(Slot_Charge_Ctrl@ct)
	goto	l7130
	line	1275
	
l7118:	
	movlw	(low(Slot_Charge_Ctrl@st|((0x0)<<8)))&0ffh
	movwf	(Slot_CV@pst)
	movlw	(low(Slot_Charge_Ctrl@ty|((0x0)<<8)))&0ffh
	movwf	(Slot_CV@pty)
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	(Slot_CV@v+1)
	movf	(Slot_Charge_Ctrl@v),w
	movwf	(Slot_CV@v)
	movf	(Slot_Charge_Ctrl@ct+1),w
	movwf	(Slot_CV@ct+1)
	movf	(Slot_Charge_Ctrl@ct),w
	movwf	(Slot_CV@ct)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Slot_CV
	movf	(1+(?_Slot_CV)),w
	movwf	(Slot_Charge_Ctrl@ct+1)
	movf	(0+(?_Slot_CV)),w
	movwf	(Slot_Charge_Ctrl@ct)
	goto	l7130
	line	1276
	
l7120:	
	movlw	(low(Slot_Charge_Ctrl@st|((0x0)<<8)))&0ffh
	movwf	(Slot_Full@pst)
	movf	(Slot_Charge_Ctrl@ty),w
	movwf	(Slot_Full@ty)
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	(Slot_Full@v+1)
	movf	(Slot_Charge_Ctrl@v),w
	movwf	(Slot_Full@v)
	movf	(Slot_Charge_Ctrl@ct+1),w
	movwf	(Slot_Full@ct+1)
	movf	(Slot_Charge_Ctrl@ct),w
	movwf	(Slot_Full@ct)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Slot_Full
	movf	(1+(?_Slot_Full)),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@ct+1)
	movf	(0+(?_Slot_Full)),w
	movwf	(Slot_Charge_Ctrl@ct)
	goto	l7130
	line	1277
	
l7122:	
	movlw	(low(Slot_Charge_Ctrl@st|((0x0)<<8)))&0ffh
	movwf	(Slot_Error@pst)
	movlw	(low(Slot_Charge_Ctrl@ty|((0x0)<<8)))&0ffh
	movwf	(Slot_Error@pty)
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	(Slot_Error@v+1)
	movf	(Slot_Charge_Ctrl@v),w
	movwf	(Slot_Error@v)
	movf	(Slot_Charge_Ctrl@ct+1),w
	movwf	(Slot_Error@ct+1)
	movf	(Slot_Charge_Ctrl@ct),w
	movwf	(Slot_Error@ct)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Slot_Error
	movf	(1+(?_Slot_Error)),w
	movwf	(Slot_Charge_Ctrl@ct+1)
	movf	(0+(?_Slot_Error)),w
	movwf	(Slot_Charge_Ctrl@ct)
	goto	l7130
	line	1278
	
l7124:	
	clrf	(Slot_Charge_Ctrl@st)
	goto	l7130
	line	1266
	
l7128:	
	movf	(Slot_Charge_Ctrl@st),w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l7104
	xorlw	1^0	; case 1
	skipnz
	goto	l7106
	xorlw	2^1	; case 2
	skipnz
	goto	l7112
	xorlw	3^2	; case 3
	skipnz
	goto	l7114
	xorlw	4^3	; case 4
	skipnz
	goto	l7116
	xorlw	5^4	; case 5
	skipnz
	goto	l7118
	xorlw	6^5	; case 6
	skipnz
	goto	l7120
	xorlw	7^6	; case 7
	skipnz
	goto	l7122
	xorlw	8^7	; case 8
	skipnz
	goto	l7108
	xorlw	9^8	; case 9
	skipnz
	goto	l7110
	goto	l7124
	opt asmopt_pop

	line	1281
	
l7130:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@st),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@ty),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@v),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1),w
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@ct),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@ct+1),w
	movwf	indf
	line	1287
	
l7132:	
;charge_mgr.c: 1284: if((st == 2 || st == 3 ||
;charge_mgr.c: 1285: st == 4 || st == 5 ||
;charge_mgr.c: 1286: st == 8 || st == 1) &&
;charge_mgr.c: 1287: !g_tempProtect && !g_vccProtect)
		movlw	2
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfsc	status,2
	goto	u9411
	goto	u9410
u9411:
	goto	l7144
u9410:
	
l7134:	
		movlw	3
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfsc	status,2
	goto	u9421
	goto	u9420
u9421:
	goto	l7144
u9420:
	
l7136:	
		movlw	4
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfsc	status,2
	goto	u9431
	goto	u9430
u9431:
	goto	l7144
u9430:
	
l7138:	
		movlw	5
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfsc	status,2
	goto	u9441
	goto	u9440
u9441:
	goto	l7144
u9440:
	
l7140:	
		movlw	8
	xorwf	((Slot_Charge_Ctrl@st)),w
	btfsc	status,2
	goto	u9451
	goto	u9450
u9451:
	goto	l7144
u9450:
	
l7142:	
		decf	((Slot_Charge_Ctrl@st)),w
	btfss	status,2
	goto	u9461
	goto	u9460
u9461:
	goto	l7154
u9460:
	
l7144:	
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u9471
	goto	u9470
u9471:
	goto	l7154
u9470:
	
l7146:	
	movf	((_g_vccProtect)^080h),w
	btfss	status,2
	goto	u9481
	goto	u9480
u9481:
	goto	l7154
u9480:
	goto	l7150
	line	1289
	
l793:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	l824
	
l795:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	l824
	
l796:	
	bcf	(51/8),(51)&7	;volatile
	goto	l824
	
l797:	
	bcf	(50/8),(50)&7	;volatile
	goto	l824
	
l798:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	l824
	
l799:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	l824
	
l800:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l824
	
l801:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l824
	
l802:	
	bcf	(48/8),(48)&7	;volatile
	goto	l824
	
l803:	
	bcf	(49/8),(49)&7	;volatile
	goto	l824
	
l804:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l824
	
l805:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l824
	
l7150:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l793
	xorlw	1^0	; case 1
	skipnz
	goto	l795
	xorlw	2^1	; case 2
	skipnz
	goto	l796
	xorlw	3^2	; case 3
	skipnz
	goto	l797
	xorlw	4^3	; case 4
	skipnz
	goto	l798
	xorlw	5^4	; case 5
	skipnz
	goto	l799
	xorlw	6^5	; case 6
	skipnz
	goto	l800
	xorlw	7^6	; case 7
	skipnz
	goto	l801
	xorlw	8^7	; case 8
	skipnz
	goto	l802
	xorlw	9^8	; case 9
	skipnz
	goto	l803
	xorlw	10^9	; case 10
	skipnz
	goto	l804
	xorlw	11^10	; case 11
	skipnz
	goto	l805
	goto	l824
	opt asmopt_pop

	line	1293
	
l810:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l824
	
l812:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l824
	
l813:	
	bsf	(51/8),(51)&7	;volatile
	goto	l824
	
l814:	
	bsf	(50/8),(50)&7	;volatile
	goto	l824
	
l815:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l824
	
l816:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l824
	
l817:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l824
	
l818:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l824
	
l819:	
	bsf	(48/8),(48)&7	;volatile
	goto	l824
	
l820:	
	bsf	(49/8),(49)&7	;volatile
	goto	l824
	
l821:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l824
	
l822:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l824
	
l7154:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l810
	xorlw	1^0	; case 1
	skipnz
	goto	l812
	xorlw	2^1	; case 2
	skipnz
	goto	l813
	xorlw	3^2	; case 3
	skipnz
	goto	l814
	xorlw	4^3	; case 4
	skipnz
	goto	l815
	xorlw	5^4	; case 5
	skipnz
	goto	l816
	xorlw	6^5	; case 6
	skipnz
	goto	l817
	xorlw	7^6	; case 7
	skipnz
	goto	l818
	xorlw	8^7	; case 8
	skipnz
	goto	l819
	xorlw	9^8	; case 9
	skipnz
	goto	l820
	xorlw	10^9	; case 10
	skipnz
	goto	l821
	xorlw	11^10	; case 11
	skipnz
	goto	l822
	goto	l824
	opt asmopt_pop

	line	1295
	
l824:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_Charge_Ctrl
	__end_of_Slot_Charge_Ctrl:
	signat	_Slot_Charge_Ctrl,4217
	global	_Slot_Precharge

;; *************** function _Slot_Precharge *****************
;; Defined at:
;;		line 763 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  pst             1    2[COMMON] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@st(1), 
;;  v               2    3[COMMON] unsigned int 
;;  ct              2    5[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1    7[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         5       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         6       0       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	line	763
global __ptext6
__ptext6:	;psect for function _Slot_Precharge
psect	text6
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	763
	global	__size_of_Slot_Precharge
	__size_of_Slot_Precharge	equ	__end_of_Slot_Precharge-_Slot_Precharge
	
_Slot_Precharge:	
;incstack = 0
	opt	stack 4
; Regs used in _Slot_Precharge: [wreg-fsr0h+status,2+status,0]
;Slot_Precharge@idx stored from wreg
	movwf	(Slot_Precharge@idx)
	line	765
	
l6272:	
;charge_mgr.c: 765: ct++;
	incf	(Slot_Precharge@ct),f
	skipnz
	incf	(Slot_Precharge@ct+1),f
	line	766
	
l6274:	
;charge_mgr.c: 766: if(ct > ((unsigned long)(300) * 16))
	movlw	012h
	subwf	(Slot_Precharge@ct+1),w
	movlw	0C1h
	skipnz
	subwf	(Slot_Precharge@ct),w
	skipc
	goto	u8311
	goto	u8310
u8311:
	goto	l6282
u8310:
	line	768
	
l6276:	
;charge_mgr.c: 767: {
;charge_mgr.c: 768: *pst = 7;
	movf	(Slot_Precharge@pst),w
	movwf	fsr0
	movlw	low(07h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	769
	
l6278:	
;charge_mgr.c: 769: return ct;
	movf	(Slot_Precharge@ct+1),w
	movwf	(?_Slot_Precharge+1)
	movf	(Slot_Precharge@ct),w
	movwf	(?_Slot_Precharge)
	goto	l643
	line	771
	
l6282:	
;charge_mgr.c: 770: }
;charge_mgr.c: 771: if(v >= 3850)
	movlw	0Fh
	subwf	(Slot_Precharge@v+1),w
	movlw	0Ah
	skipnz
	subwf	(Slot_Precharge@v),w
	skipc
	goto	u8321
	goto	u8320
u8321:
	goto	l6292
u8320:
	line	773
	
l6284:	
;charge_mgr.c: 772: {
;charge_mgr.c: 773: g_ovCnt[idx]++;
	movf	(Slot_Precharge@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	774
;charge_mgr.c: 774: if(g_ovCnt[idx] >= 5)
	movf	(Slot_Precharge@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u8331
	goto	u8330
u8331:
	goto	l6294
u8330:
	goto	l6276
	line	782
	
l6292:	
;charge_mgr.c: 780: else
;charge_mgr.c: 781: {
;charge_mgr.c: 782: g_ovCnt[idx] = 0;
	movf	(Slot_Precharge@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	784
	
l6294:	
;charge_mgr.c: 783: }
;charge_mgr.c: 784: if(v >= 2700)
	movlw	0Ah
	subwf	(Slot_Precharge@v+1),w
	movlw	08Ch
	skipnz
	subwf	(Slot_Precharge@v),w
	skipc
	goto	u8341
	goto	u8340
u8341:
	goto	l6278
u8340:
	line	786
	
l6296:	
;charge_mgr.c: 785: {
;charge_mgr.c: 786: *pst = 4;
	movf	(Slot_Precharge@pst),w
	movwf	fsr0
	movlw	low(04h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	787
	
l6298:	
;charge_mgr.c: 787: ct = 0;
	clrf	(Slot_Precharge@ct)
	clrf	(Slot_Precharge@ct+1)
	line	788
	
l6300:	
;charge_mgr.c: 788: g_ccBlocks[idx] = 0;
	movf	(Slot_Precharge@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	789
	
l6302:	
;charge_mgr.c: 789: g_ovCnt[idx] = 0;
	movf	(Slot_Precharge@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	790
	
l6304:	
;charge_mgr.c: 790: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_Precharge@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Precharge@v),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Precharge@v+1),w
	movwf	indf
	line	791
	
l6306:	
;charge_mgr.c: 791: g_stableCnt[idx] = 0;
	movf	(Slot_Precharge@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6278
	line	794
	
l643:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_Precharge
	__end_of_Slot_Precharge:
	signat	_Slot_Precharge,16506
	global	_Slot_ImpCheck

;; *************** function _Slot_ImpCheck *****************
;; Defined at:
;;		line 499 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  pst             1   45[BANK0 ] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@st(1), 
;;  pty             1   46[BANK0 ] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@ty(1), 
;;  v               2   47[BANK0 ] unsigned int 
;;  ct              2   49[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1   56[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   45[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       6       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       5       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Get_Vcc
;;		_Route_LiIon
;;		___wmul
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	line	499
global __ptext7
__ptext7:	;psect for function _Slot_ImpCheck
psect	text7
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	499
	global	__size_of_Slot_ImpCheck
	__size_of_Slot_ImpCheck	equ	__end_of_Slot_ImpCheck-_Slot_ImpCheck
	
_Slot_ImpCheck:	
;incstack = 0
	opt	stack 1
; Regs used in _Slot_ImpCheck: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Slot_ImpCheck@idx stored from wreg
	movwf	(Slot_ImpCheck@idx)
	line	502
	
l5994:	
;charge_mgr.c: 502: ct++;
	incf	(Slot_ImpCheck@ct),f
	skipnz
	incf	(Slot_ImpCheck@ct+1),f
	line	503
	
l5996:	
;charge_mgr.c: 503: if(ct < 5)
	movlw	0
	subwf	(Slot_ImpCheck@ct+1),w
	movlw	05h
	skipnz
	subwf	(Slot_ImpCheck@ct),w
	skipnc
	goto	u7791
	goto	u7790
u7791:
	goto	l6002
u7790:
	line	504
	
l5998:	
;charge_mgr.c: 504: return ct;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_ImpCheck@ct+1),w
	movwf	(?_Slot_ImpCheck+1)
	movf	(Slot_ImpCheck@ct),w
	movwf	(?_Slot_ImpCheck)
	goto	l602
	line	508
	
l6002:	
;charge_mgr.c: 506: {
;charge_mgr.c: 508: Get_Vcc();
	fcall	_Get_Vcc
	line	513
;charge_mgr.c: 513: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 300U && v >= 4090)
	bcf	status, 5	;RP0=0, select bank0
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(012Ch)
	movwf	(??_Slot_ImpCheck+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(012Ch)
	movwf	1+(??_Slot_ImpCheck+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_ImpCheck+0)+0,w
	skipz
	goto	u7805
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_ImpCheck+0)+0,w
u7805:
	skipnc
	goto	u7801
	goto	u7800
u7801:
	goto	l6016
u7800:
	
l6004:	
	movlw	0Fh
	subwf	(Slot_ImpCheck@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_ImpCheck@v),w
	skipc
	goto	u7811
	goto	u7810
u7811:
	goto	l6016
u7810:
	line	515
	
l6006:	
;charge_mgr.c: 514: {
;charge_mgr.c: 515: *pty = 2;
	movf	(Slot_ImpCheck@pty),w
	movwf	fsr0
	movlw	low(02h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	516
;charge_mgr.c: 516: *pst = 7;
	movf	(Slot_ImpCheck@pst),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	517
	
l6008:	
;charge_mgr.c: 517: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	518
	
l6010:	
;charge_mgr.c: 518: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_ImpCheck@idx),w
	movwf	(??_Slot_ImpCheck+0)+0
	movlw	01h
	movwf	(??_Slot_ImpCheck+1)+0
	movlw	0
	movwf	(??_Slot_ImpCheck+1)+0+1
	goto	u7824
u7825:
	clrc
	rlf	(??_Slot_ImpCheck+1)+0,f
	rlf	(??_Slot_ImpCheck+1)+1,f
u7824:
	decfsz	(??_Slot_ImpCheck+0)+0,f
	goto	u7825
	
	comf	(??_Slot_ImpCheck+1)+0,f
	comf	(??_Slot_ImpCheck+1)+1,f
	movf	0+(??_Slot_ImpCheck+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_ImpCheck+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	goto	l5998
	line	527
	
l6016:	
;charge_mgr.c: 520: }
;charge_mgr.c: 526: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 200U &&
;charge_mgr.c: 527: ((g_impData) & 0x0FFFU) < 3100U)
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(0C8h)
	movwf	(??_Slot_ImpCheck+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_Slot_ImpCheck+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_ImpCheck+0)+0,w
	skipz
	goto	u7835
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_ImpCheck+0)+0,w
u7835:
	skipnc
	goto	u7831
	goto	u7830
u7831:
	goto	l6026
u7830:
	
l6018:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_ImpCheck+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_ImpCheck+0)+0
	movlw	0Ch
	subwf	1+(??_Slot_ImpCheck+0)+0,w
	movlw	01Ch
	skipnz
	subwf	0+(??_Slot_ImpCheck+0)+0,w
	skipnc
	goto	u7841
	goto	u7840
u7841:
	goto	l6026
u7840:
	line	529
	
l6020:	
;charge_mgr.c: 528: {
;charge_mgr.c: 529: Route_LiIon(idx, pty, pst, v, &ct);
	movf	(Slot_ImpCheck@pty),w
	movwf	(Route_LiIon@pty)
	movf	(Slot_ImpCheck@pst),w
	movwf	(Route_LiIon@pst)
	movf	(Slot_ImpCheck@v+1),w
	movwf	(Route_LiIon@v+1)
	movf	(Slot_ImpCheck@v),w
	movwf	(Route_LiIon@v)
	movlw	(low(Slot_ImpCheck@ct|((0x0)<<8)))&0ffh
	movwf	(Route_LiIon@pct)
	movf	(Slot_ImpCheck@idx),w
	fcall	_Route_LiIon
	goto	l5998
	line	540
	
l6026:	
;charge_mgr.c: 531: }
;charge_mgr.c: 538: if(!(g_highVFlag & ((unsigned int)1 << idx)) &&
;charge_mgr.c: 539: (((g_impData) & 0x0FFFU) > v) &&
;charge_mgr.c: 540: (((g_impData) & 0x0FFFU) - v) > 1000U)
	incf	(Slot_ImpCheck@idx),w
	movwf	(??_Slot_ImpCheck+0)+0
	movlw	01h
	movwf	(??_Slot_ImpCheck+1)+0
	movlw	0
	movwf	(??_Slot_ImpCheck+1)+0+1
	goto	u7854
u7855:
	clrc
	rlf	(??_Slot_ImpCheck+1)+0,f
	rlf	(??_Slot_ImpCheck+1)+1,f
u7854:
	decfsz	(??_Slot_ImpCheck+0)+0,f
	goto	u7855
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_ImpCheck+1)+0,w
	movwf	(??_Slot_ImpCheck+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_ImpCheck+1)+0,w
	movwf	1+(??_Slot_ImpCheck+3)+0
	movf	((??_Slot_ImpCheck+3)+0),w
iorwf	((??_Slot_ImpCheck+3)+1),w
	btfss	status,2
	goto	u7861
	goto	u7860
u7861:
	goto	l6042
u7860:
	
l6028:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_ImpCheck+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_ImpCheck+0)+0
	movf	1+(??_Slot_ImpCheck+0)+0,w
	subwf	(Slot_ImpCheck@v+1),w
	skipz
	goto	u7875
	movf	0+(??_Slot_ImpCheck+0)+0,w
	subwf	(Slot_ImpCheck@v),w
u7875:
	skipnc
	goto	u7871
	goto	u7870
u7871:
	goto	l6042
u7870:
	
l6030:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_ImpCheck+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_ImpCheck+0)+0
	movf	(Slot_ImpCheck@v),w
	subwf	0+(??_Slot_ImpCheck+0)+0,w
	movwf	(??_Slot_ImpCheck+2)+0
	movf	(Slot_ImpCheck@v+1),w
	skipc
	incf	(Slot_ImpCheck@v+1),w
	subwf	1+(??_Slot_ImpCheck+0)+0,w
	movwf	1+(??_Slot_ImpCheck+2)+0
	movlw	03h
	subwf	1+(??_Slot_ImpCheck+2)+0,w
	movlw	0E9h
	skipnz
	subwf	0+(??_Slot_ImpCheck+2)+0,w
	skipc
	goto	u7881
	goto	u7880
u7881:
	goto	l6042
u7880:
	line	542
	
l6032:	
;charge_mgr.c: 541: {
;charge_mgr.c: 542: *pty = 3;
	movf	(Slot_ImpCheck@pty),w
	movwf	fsr0
	movlw	low(03h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	543
;charge_mgr.c: 543: *pst = 7;
	movf	(Slot_ImpCheck@pst),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	544
	
l6034:	
;charge_mgr.c: 544: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	545
	
l6036:	
;charge_mgr.c: 545: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_ImpCheck@idx),w
	movwf	(??_Slot_ImpCheck+0)+0
	movlw	01h
	movwf	(??_Slot_ImpCheck+1)+0
	movlw	0
	movwf	(??_Slot_ImpCheck+1)+0+1
	goto	u7894
u7895:
	clrc
	rlf	(??_Slot_ImpCheck+1)+0,f
	rlf	(??_Slot_ImpCheck+1)+1,f
u7894:
	decfsz	(??_Slot_ImpCheck+0)+0,f
	goto	u7895
	
	comf	(??_Slot_ImpCheck+1)+0,f
	comf	(??_Slot_ImpCheck+1)+1,f
	movf	0+(??_Slot_ImpCheck+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_ImpCheck+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	546
;charge_mgr.c: 546: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_ImpCheck@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l5998
	line	554
	
l6042:	
;charge_mgr.c: 548: }
;charge_mgr.c: 553: if((((g_impData) & 0x0FFFU) > 3500) &&
;charge_mgr.c: 554: ((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) <= g_vcc_mv + 200U))
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_ImpCheck+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_ImpCheck+0)+0
	movlw	0Dh
	subwf	1+(??_Slot_ImpCheck+0)+0,w
	movlw	0ADh
	skipnz
	subwf	0+(??_Slot_ImpCheck+0)+0,w
	skipc
	goto	u7901
	goto	u7900
u7901:
	goto	l6048
u7900:
	
l6044:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(0C8h)
	movwf	(??_Slot_ImpCheck+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_Slot_ImpCheck+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_ImpCheck+0)+0,w
	skipz
	goto	u7915
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_ImpCheck+0)+0,w
u7915:
	skipc
	goto	u7911
	goto	u7910
u7911:
	goto	l6048
u7910:
	goto	l6052
	line	561
	
l6048:	
	line	567
	
l6052:	
;charge_mgr.c: 567: *pst = 9;
	movf	(Slot_ImpCheck@pst),w
	movwf	fsr0
	movlw	low(09h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	568
	
l6054:	
;charge_mgr.c: 568: ct = 0;
	clrf	(Slot_ImpCheck@ct)
	clrf	(Slot_ImpCheck@ct+1)
	line	569
	
l6056:	
;charge_mgr.c: 569: g_diodeTraceCnt = 0;
	clrf	(_g_diodeTraceCnt)
	line	570
	
l6058:	
;charge_mgr.c: 570: g_diodeTraceSlot = (unsigned char)idx;
	movf	(Slot_ImpCheck@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_diodeTraceSlot)^080h
	goto	l6010
	line	574
	
l602:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_ImpCheck
	__end_of_Slot_ImpCheck:
	signat	_Slot_ImpCheck,20602
	global	_Slot_Idle

;; *************** function _Slot_Idle *****************
;; Defined at:
;;		line 243 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  pst             1    2[COMMON] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@st(1), 
;;  v               2    3[COMMON] unsigned int 
;;  ct              2    5[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         5       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          3       0       0       0       0
;;      Totals:         8       1       0       0       0
;;Total ram usage:        9 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	243
global __ptext8
__ptext8:	;psect for function _Slot_Idle
psect	text8
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	243
	global	__size_of_Slot_Idle
	__size_of_Slot_Idle	equ	__end_of_Slot_Idle-_Slot_Idle
	
_Slot_Idle:	
;incstack = 0
	opt	stack 4
; Regs used in _Slot_Idle: [wreg-fsr0h+status,2+status,0]
;Slot_Idle@idx stored from wreg
	movwf	(Slot_Idle@idx)
	line	245
	
l5754:	
;charge_mgr.c: 245: if(v >= 4090)
	movlw	0Fh
	subwf	(Slot_Idle@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Idle@v),w
	skipc
	goto	u7221
	goto	u7220
u7221:
	goto	l5764
u7220:
	line	247
	
l5756:	
;charge_mgr.c: 246: {
;charge_mgr.c: 247: if(ct < ((unsigned long)(24) * 16))
	movlw	01h
	subwf	(Slot_Idle@ct+1),w
	movlw	080h
	skipnz
	subwf	(Slot_Idle@ct),w
	skipnc
	goto	u7231
	goto	u7230
u7231:
	goto	l5764
u7230:
	line	249
	
l5758:	
;charge_mgr.c: 248: {
;charge_mgr.c: 249: ct++;
	incf	(Slot_Idle@ct),f
	skipnz
	incf	(Slot_Idle@ct+1),f
	line	250
	
l5760:	
;charge_mgr.c: 250: return ct;
	movf	(Slot_Idle@ct+1),w
	movwf	(?_Slot_Idle+1)
	movf	(Slot_Idle@ct),w
	movwf	(?_Slot_Idle)
	goto	l550
	line	253
	
l5764:	
	line	254
	
l5766:	
;charge_mgr.c: 254: *pst = 1;
	movf	(Slot_Idle@pst),w
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	clrf	indf
	incf	indf,f
	line	255
	
l5768:	
;charge_mgr.c: 255: g_ccBlocks[idx] = 0;
	movf	(Slot_Idle@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	257
	
l5770:	
;charge_mgr.c: 257: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Idle@idx),w
	movwf	(??_Slot_Idle+0)+0
	movlw	01h
	movwf	(??_Slot_Idle+1)+0
	movlw	0
	movwf	(??_Slot_Idle+1)+0+1
	goto	u7244
u7245:
	clrc
	rlf	(??_Slot_Idle+1)+0,f
	rlf	(??_Slot_Idle+1)+1,f
u7244:
	decfsz	(??_Slot_Idle+0)+0,f
	goto	u7245
	
	comf	(??_Slot_Idle+1)+0,f
	comf	(??_Slot_Idle+1)+1,f
	movf	0+(??_Slot_Idle+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_Slot_Idle+1)+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	260
	
l5772:	
;charge_mgr.c: 260: if(v < 4090)
	movlw	0Fh
	subwf	(Slot_Idle@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Idle@v),w
	skipnc
	goto	u7251
	goto	u7250
u7251:
	goto	l5776
u7250:
	line	261
	
l5774:	
;charge_mgr.c: 261: g_slotRefV[idx] = v;
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Idle@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Idle@v),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Idle@v+1),w
	movwf	indf
	goto	l5778
	line	263
	
l5776:	
;charge_mgr.c: 262: else
;charge_mgr.c: 263: g_slotRefV[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Idle@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	264
	
l5778:	
;charge_mgr.c: 264: return ct;
	clrf	(?_Slot_Idle)
	clrf	(?_Slot_Idle+1)
	line	265
	
l550:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_Idle
	__end_of_Slot_Idle:
	signat	_Slot_Idle,16506
	global	_Slot_Full

;; *************** function _Slot_Full *****************
;; Defined at:
;;		line 1131 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  pst             1    2[COMMON] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@st(1), 
;;  ty              1    3[COMMON] unsigned char 
;;  v               2    4[COMMON] unsigned int 
;;  ct              2    6[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         6       0       0       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         6       3       0       0       0
;;Total ram usage:        9 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	1131
global __ptext9
__ptext9:	;psect for function _Slot_Full
psect	text9
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1131
	global	__size_of_Slot_Full
	__size_of_Slot_Full	equ	__end_of_Slot_Full-_Slot_Full
	
_Slot_Full:	
;incstack = 0
	opt	stack 4
; Regs used in _Slot_Full: [wreg-fsr0h+status,2+status,0]
;Slot_Full@idx stored from wreg
	movwf	(Slot_Full@idx)
	line	1140
	
l6626:	
;charge_mgr.c: 1140: if(v >= 4090)
	movlw	0Fh
	subwf	(Slot_Full@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Full@v),w
	skipc
	goto	u8891
	goto	u8890
u8891:
	goto	l6648
u8890:
	line	1142
	
l6628:	
;charge_mgr.c: 1141: {
;charge_mgr.c: 1142: g_detectLowCnt[idx]++;
	movf	(Slot_Full@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1143
	
l6630:	
;charge_mgr.c: 1143: if(g_detectLowCnt[idx] >= (ty == 6 ? (16 / 2) : 2))
		movlw	6
	xorwf	((Slot_Full@ty)),w
	btfsc	status,2
	goto	u8901
	goto	u8900
u8901:
	goto	l6634
u8900:
	
l6632:	
	movlw	02h
	movwf	(_Slot_Full$441)
	clrf	(_Slot_Full$441+1)
	goto	l6636
	
l6634:	
	movlw	08h
	movwf	(_Slot_Full$441)
	clrf	(_Slot_Full$441+1)
	
l6636:	
	movf	(Slot_Full@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(_Slot_Full$441+1),w
	xorlw	80h
	sublw	080h
	skipz
	goto	u8915
	movf	(_Slot_Full$441),w
	subwf	indf,w
u8915:

	skipc
	goto	u8911
	goto	u8910
u8911:
	goto	l6644
u8910:
	line	1145
	
l6638:	
;charge_mgr.c: 1144: {
;charge_mgr.c: 1145: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Full@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	1146
	
l6640:	
;charge_mgr.c: 1146: *pst = 0;
	movf	(Slot_Full@pst),w
	movwf	fsr0
	clrf	indf
	line	1147
	
l6642:	
;charge_mgr.c: 1147: ct = 0;
	clrf	(Slot_Full@ct)
	clrf	(Slot_Full@ct+1)
	line	1149
	
l6644:	
;charge_mgr.c: 1148: }
;charge_mgr.c: 1149: return ct;
	movf	(Slot_Full@ct+1),w
	movwf	(?_Slot_Full+1)
	movf	(Slot_Full@ct),w
	movwf	(?_Slot_Full)
	goto	l724
	line	1154
	
l6648:	
;charge_mgr.c: 1150: }
;charge_mgr.c: 1154: if(v < 2800U)
	movlw	0Ah
	subwf	(Slot_Full@v+1),w
	movlw	0F0h
	skipnz
	subwf	(Slot_Full@v),w
	skipnc
	goto	u8921
	goto	u8920
u8921:
	goto	l6670
u8920:
	line	1156
	
l6650:	
;charge_mgr.c: 1155: {
;charge_mgr.c: 1156: g_detectLowCnt[idx]++;
	movf	(Slot_Full@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1157
;charge_mgr.c: 1157: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Full@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8931
	goto	u8930
u8931:
	goto	l6656
u8930:
	goto	l6644
	line	1159
	
l6656:	
;charge_mgr.c: 1159: g_detectLowCnt[idx] = 0;
	movf	(Slot_Full@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1160
	
l6658:	
;charge_mgr.c: 1160: *pst = 4;
	movf	(Slot_Full@pst),w
	movwf	fsr0
	movlw	low(04h)
	movwf	indf
	line	1161
	
l6660:	
;charge_mgr.c: 1161: ct = 0;
	clrf	(Slot_Full@ct)
	clrf	(Slot_Full@ct+1)
	line	1162
	
l6662:	
;charge_mgr.c: 1162: g_ovCnt[idx] = 0;
	movf	(Slot_Full@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	1163
	
l6664:	
;charge_mgr.c: 1163: g_ccBlocks[idx] = 0;
	movf	(Slot_Full@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1165
	
l6666:	
;charge_mgr.c: 1165: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_Full@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Full@v),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Full@v+1),w
	movwf	indf
	line	1166
	
l6668:	
;charge_mgr.c: 1166: g_stableCnt[idx] = 0;
	movf	(Slot_Full@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1167
;charge_mgr.c: 1167: }
	goto	l6644
	line	1170
	
l6670:	
;charge_mgr.c: 1168: else
;charge_mgr.c: 1169: {
;charge_mgr.c: 1170: g_detectLowCnt[idx] = 0;
	movf	(Slot_Full@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l6644
	line	1173
	
l724:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_Full
	__end_of_Slot_Full:
	signat	_Slot_Full,20602
	global	_Slot_Error

;; *************** function _Slot_Error *****************
;; Defined at:
;;		line 1176 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  pst             1    2[COMMON] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@st(1), 
;;  pty             1    3[COMMON] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@ty(1), 
;;  v               2    4[COMMON] unsigned int 
;;  ct              2    6[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1    8[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         6       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       5       0       0       0
;;      Totals:         7       5       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=0
	line	1176
global __ptext10
__ptext10:	;psect for function _Slot_Error
psect	text10
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1176
	global	__size_of_Slot_Error
	__size_of_Slot_Error	equ	__end_of_Slot_Error-_Slot_Error
	
_Slot_Error:	
;incstack = 0
	opt	stack 4
; Regs used in _Slot_Error: [wreg-fsr0h+status,2+status,0]
;Slot_Error@idx stored from wreg
	movwf	(Slot_Error@idx)
	line	1180
	
l6676:	
;charge_mgr.c: 1180: if(v >= 4090)
	movlw	0Fh
	subwf	(Slot_Error@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Error@v),w
	skipc
	goto	u8941
	goto	u8940
u8941:
	goto	l6698
u8940:
	line	1182
	
l6678:	
;charge_mgr.c: 1181: {
;charge_mgr.c: 1182: g_detectLowCnt[idx]++;
	movf	(Slot_Error@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1183
;charge_mgr.c: 1183: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Error@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8951
	goto	u8950
u8951:
	goto	l6684
u8950:
	line	1184
	
l6680:	
;charge_mgr.c: 1184: return ct;
	movf	(Slot_Error@ct+1),w
	movwf	(?_Slot_Error+1)
	movf	(Slot_Error@ct),w
	movwf	(?_Slot_Error)
	goto	l732
	line	1185
	
l6684:	
;charge_mgr.c: 1185: g_detectLowCnt[idx] = 0;
	movf	(Slot_Error@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1186
	
l6686:	
;charge_mgr.c: 1186: *pty = 0;
	movf	(Slot_Error@pty),w
	movwf	fsr0
	clrf	indf
	line	1187
	
l6688:	
;charge_mgr.c: 1187: *pst = 0;
	movf	(Slot_Error@pst),w
	movwf	fsr0
	clrf	indf
	line	1188
	
l6690:	
	line	1189
	
l6692:	
;charge_mgr.c: 1189: g_ccBlocks[idx] = 0;
	movf	(Slot_Error@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	1190
	
l6694:	
;charge_mgr.c: 1190: return ct;
	clrf	(?_Slot_Error)
	clrf	(?_Slot_Error+1)
	goto	l732
	line	1200
	
l6698:	
;charge_mgr.c: 1191: }
;charge_mgr.c: 1200: if(*pty == 2 || *pty == 3)
	movf	(Slot_Error@pty),w
	movwf	fsr0
		movlw	2
	bcf	status, 7	;select IRP bank0
	xorwf	(indf),w
	btfsc	status,2
	goto	u8961
	goto	u8960
u8961:
	goto	l6702
u8960:
	
l6700:	
	movf	(Slot_Error@pty),w
	movwf	fsr0
		movlw	3
	xorwf	(indf),w
	btfss	status,2
	goto	u8971
	goto	u8970
u8971:
	goto	l6724
u8970:
	line	1202
	
l6702:	
;charge_mgr.c: 1201: {
;charge_mgr.c: 1202: if(v > 2700U && (g_highVFlag & ((unsigned int)1 << idx)))
	movlw	0Ah
	subwf	(Slot_Error@v+1),w
	movlw	08Dh
	skipnz
	subwf	(Slot_Error@v),w
	skipc
	goto	u8981
	goto	u8980
u8981:
	goto	l6718
u8980:
	
l6704:	
	incf	(Slot_Error@idx),w
	movwf	(??_Slot_Error+0)+0
	movlw	01h
	movwf	(??_Slot_Error+1)+0
	movlw	0
	movwf	(??_Slot_Error+1)+0+1
	goto	u8994
u8995:
	clrc
	rlf	(??_Slot_Error+1)+0,f
	rlf	(??_Slot_Error+1)+1,f
u8994:
	decfsz	(??_Slot_Error+0)+0,f
	goto	u8995
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Error+1)+0,w
	movwf	(??_Slot_Error+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Error+1)+0,w
	movwf	1+(??_Slot_Error+3)+0
	movf	((??_Slot_Error+3)+0),w
iorwf	((??_Slot_Error+3)+1),w
	btfsc	status,2
	goto	u9001
	goto	u9000
u9001:
	goto	l6718
u9000:
	line	1204
	
l6706:	
;charge_mgr.c: 1203: {
;charge_mgr.c: 1204: g_detectLowCnt[idx]++;
	movf	(Slot_Error@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	1205
;charge_mgr.c: 1205: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Error@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9011
	goto	u9010
u9011:
	goto	l6712
u9010:
	goto	l6680
	line	1207
	
l6712:	
;charge_mgr.c: 1207: g_detectLowCnt[idx] = 0;
	movf	(Slot_Error@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1208
	
l6714:	
;charge_mgr.c: 1208: *pst = 1;
	movf	(Slot_Error@pst),w
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	1209
	
l6716:	
;charge_mgr.c: 1209: ct = 0;
	clrf	(Slot_Error@ct)
	clrf	(Slot_Error@ct+1)
	line	1210
;charge_mgr.c: 1210: }
	goto	l6680
	line	1213
	
l6718:	
;charge_mgr.c: 1211: else
;charge_mgr.c: 1212: {
;charge_mgr.c: 1213: g_detectLowCnt[idx] = 0;
	movf	(Slot_Error@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6680
	line	1218
	
l6724:	
;charge_mgr.c: 1216: }
;charge_mgr.c: 1218: if(v > 750)
	movlw	02h
	subwf	(Slot_Error@v+1),w
	movlw	0EFh
	skipnz
	subwf	(Slot_Error@v),w
	skipc
	goto	u9021
	goto	u9020
u9021:
	goto	l6718
u9020:
	line	1220
	
l6726:	
;charge_mgr.c: 1219: {
;charge_mgr.c: 1220: g_detectLowCnt[idx]++;
	movf	(Slot_Error@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	1221
;charge_mgr.c: 1221: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Error@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9031
	goto	u9030
u9031:
	goto	l6712
u9030:
	goto	l6680
	line	1232
	
l732:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_Error
	__end_of_Slot_Error:
	signat	_Slot_Error,20602
	global	_Slot_DiodeTest

;; *************** function _Slot_DiodeTest *****************
;; Defined at:
;;		line 580 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  pst             1   45[BANK0 ] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@st(1), 
;;  pty             1   46[BANK0 ] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@ty(1), 
;;  v               2   47[BANK0 ] unsigned int 
;;  ct              2   49[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1   61[BANK0 ] unsigned char 
;;  hasRise         1   56[BANK0 ] unsigned char 
;;  tc              1   55[BANK0 ] unsigned char 
;;  pre             2   59[BANK0 ] unsigned int 
;;  diff            2   57[BANK0 ] int 
;; Return value:  Size  Location     Type
;;                  2   45[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       6       0       0       0
;;      Locals:         0       7       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      17       0       0       0
;;Total ram usage:       17 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Route_LiIon
;;		_Route_LinearLi
;;		___wmul
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	line	580
global __ptext11
__ptext11:	;psect for function _Slot_DiodeTest
psect	text11
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	580
	global	__size_of_Slot_DiodeTest
	__size_of_Slot_DiodeTest	equ	__end_of_Slot_DiodeTest-_Slot_DiodeTest
	
_Slot_DiodeTest:	
;incstack = 0
	opt	stack 1
; Regs used in _Slot_DiodeTest: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
;Slot_DiodeTest@idx stored from wreg
	movwf	(Slot_DiodeTest@idx)
	line	583
	
l6066:	
;charge_mgr.c: 583: ct++;
	incf	(Slot_DiodeTest@ct),f
	skipnz
	incf	(Slot_DiodeTest@ct+1),f
	line	587
	
l6068:	
;charge_mgr.c: 586: if((ct == 7U || ct == 14U || ct == 21U || ct == 28U) &&
;charge_mgr.c: 587: g_diodeTraceCnt < 4U)
		movlw	7
	xorwf	((Slot_DiodeTest@ct)),w
iorwf	((Slot_DiodeTest@ct+1)),w
	btfsc	status,2
	goto	u7921
	goto	u7920
u7921:
	goto	l6076
u7920:
	
l6070:	
		movlw	14
	xorwf	((Slot_DiodeTest@ct)),w
iorwf	((Slot_DiodeTest@ct+1)),w
	btfsc	status,2
	goto	u7931
	goto	u7930
u7931:
	goto	l6076
u7930:
	
l6072:	
		movlw	21
	xorwf	((Slot_DiodeTest@ct)),w
iorwf	((Slot_DiodeTest@ct+1)),w
	btfsc	status,2
	goto	u7941
	goto	u7940
u7941:
	goto	l6076
u7940:
	
l6074:	
		movlw	28
	xorwf	((Slot_DiodeTest@ct)),w
iorwf	((Slot_DiodeTest@ct+1)),w
	btfss	status,2
	goto	u7951
	goto	u7950
u7951:
	goto	l6092
u7950:
	
l6076:	
	movlw	low(04h)
	subwf	(_g_diodeTraceCnt),w
	skipnc
	goto	u7961
	goto	u7960
u7961:
	goto	l6092
u7960:
	line	589
	
l6078:	
;charge_mgr.c: 588: {
;charge_mgr.c: 589: signed int diff = (signed int)v - (signed int)((g_impData) & 0x0FFFU);
	movf	(Slot_DiodeTest@v+1),w
	movwf	(Slot_DiodeTest@diff+1)
	movf	(Slot_DiodeTest@v),w
	movwf	(Slot_DiodeTest@diff)
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_DiodeTest+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_DiodeTest+0)+0
	movf	0+(??_Slot_DiodeTest+0)+0,w
	subwf	(Slot_DiodeTest@diff),f
	movf	1+(??_Slot_DiodeTest+0)+0,w
	skipc
	decf	(Slot_DiodeTest@diff+1),f
	subwf	(Slot_DiodeTest@diff+1),f
	line	590
;charge_mgr.c: 590: diff >>= 2;
	rlf	(Slot_DiodeTest@diff+1),w
	rrf	(Slot_DiodeTest@diff+1),f
	rrf	(Slot_DiodeTest@diff),f
	rlf	(Slot_DiodeTest@diff+1),w
	rrf	(Slot_DiodeTest@diff+1),f
	rrf	(Slot_DiodeTest@diff),f
	line	591
	
l6080:	
;charge_mgr.c: 591: if(diff > 127) diff = 127;
	movf	(Slot_DiodeTest@diff+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u7975
	movlw	080h
	subwf	(Slot_DiodeTest@diff),w
u7975:

	skipc
	goto	u7971
	goto	u7970
u7971:
	goto	l6084
u7970:
	
l6082:	
	movlw	07Fh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_DiodeTest@diff)
	clrf	(Slot_DiodeTest@diff+1)
	line	592
	
l6084:	
;charge_mgr.c: 592: if(diff < -128) diff = -128;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_DiodeTest@diff+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u7985
	movlw	080h
	subwf	(Slot_DiodeTest@diff),w
u7985:

	skipnc
	goto	u7981
	goto	u7980
u7981:
	goto	l6088
u7980:
	
l6086:	
	movlw	080h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_DiodeTest@diff)
	movlw	0FFh
	movwf	((Slot_DiodeTest@diff))+1
	line	593
	
l6088:	
;charge_mgr.c: 593: g_diodeTrace[g_diodeTraceCnt++] = (unsigned char)(diff + 128);
	movf	(_g_diodeTraceCnt),w
	addlw	low(_g_diodeTrace|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_DiodeTest@diff),w
	addlw	080h
	bcf	status, 7	;select IRP bank1
	movwf	indf
	
l6090:	
	incf	(_g_diodeTraceCnt),f
	line	597
	
l6092:	
;charge_mgr.c: 594: }
;charge_mgr.c: 595: {
;charge_mgr.c: 597: if(v > ((g_impData) & 0x0FFFU) + 900)
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_DiodeTest+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_DiodeTest+0)+0
	movf	0+(??_Slot_DiodeTest+0)+0,w
	addlw	low(0384h)
	movwf	(??_Slot_DiodeTest+2)+0
	movf	1+(??_Slot_DiodeTest+0)+0,w
	skipnc
	addlw	1
	addlw	high(0384h)
	movwf	1+(??_Slot_DiodeTest+2)+0
	movf	(Slot_DiodeTest@v+1),w
	subwf	1+(??_Slot_DiodeTest+2)+0,w
	skipz
	goto	u7995
	movf	(Slot_DiodeTest@v),w
	subwf	0+(??_Slot_DiodeTest+2)+0,w
u7995:
	skipnc
	goto	u7991
	goto	u7990
u7991:
	goto	l6110
u7990:
	line	601
	
l6094:	
;charge_mgr.c: 598: {
;charge_mgr.c: 601: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150)
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(096h)
	movwf	(??_Slot_DiodeTest+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_DiodeTest+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_DiodeTest+0)+0,w
	skipz
	goto	u8005
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_DiodeTest+0)+0,w
u8005:
	skipnc
	goto	u8001
	goto	u8000
u8001:
	goto	l6104
u8000:
	line	603
	
l6096:	
;charge_mgr.c: 602: {
;charge_mgr.c: 603: Route_LiIon(idx, pty, pst, v, &ct);
	movf	(Slot_DiodeTest@pty),w
	movwf	(Route_LiIon@pty)
	movf	(Slot_DiodeTest@pst),w
	movwf	(Route_LiIon@pst)
	movf	(Slot_DiodeTest@v+1),w
	movwf	(Route_LiIon@v+1)
	movf	(Slot_DiodeTest@v),w
	movwf	(Route_LiIon@v)
	movlw	(low(Slot_DiodeTest@ct|((0x0)<<8)))&0ffh
	movwf	(Route_LiIon@pct)
	movf	(Slot_DiodeTest@idx),w
	fcall	_Route_LiIon
	line	604
	
l6098:	
;charge_mgr.c: 604: return ct;
	movf	(Slot_DiodeTest@ct+1),w
	movwf	(?_Slot_DiodeTest+1)
	movf	(Slot_DiodeTest@ct),w
	movwf	(?_Slot_DiodeTest)
	goto	l618
	line	608
	
l6104:	
;charge_mgr.c: 606: else
;charge_mgr.c: 607: {
;charge_mgr.c: 608: Route_LinearLi(idx, pty, pst, &ct);
	movf	(Slot_DiodeTest@pty),w
	movwf	(Route_LinearLi@pty)
	movf	(Slot_DiodeTest@pst),w
	movwf	(Route_LinearLi@pst)
	movlw	(low(Slot_DiodeTest@ct|((0x0)<<8)))&0ffh
	movwf	(Route_LinearLi@pct)
	movf	(Slot_DiodeTest@idx),w
	fcall	_Route_LinearLi
	goto	l6098
	line	624
	
l6110:	
;charge_mgr.c: 610: }
;charge_mgr.c: 611: }
;charge_mgr.c: 622: if((((g_impData) & 0x0FFFU) > 3000) &&
;charge_mgr.c: 623: (v > 2900) &&
;charge_mgr.c: 624: (v + 40 < ((g_impData) & 0x0FFFU)))
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_DiodeTest+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_DiodeTest+0)+0
	movlw	0Bh
	subwf	1+(??_Slot_DiodeTest+0)+0,w
	movlw	0B9h
	skipnz
	subwf	0+(??_Slot_DiodeTest+0)+0,w
	skipc
	goto	u8011
	goto	u8010
u8011:
	goto	l6122
u8010:
	
l6112:	
	movlw	0Bh
	subwf	(Slot_DiodeTest@v+1),w
	movlw	055h
	skipnz
	subwf	(Slot_DiodeTest@v),w
	skipc
	goto	u8021
	goto	u8020
u8021:
	goto	l6122
u8020:
	
l6114:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_DiodeTest+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_DiodeTest+0)+0
	movf	(Slot_DiodeTest@v),w
	addlw	low(028h)
	movwf	(??_Slot_DiodeTest+2)+0
	movf	(Slot_DiodeTest@v+1),w
	skipnc
	addlw	1
	addlw	high(028h)
	movwf	1+(??_Slot_DiodeTest+2)+0
	movf	1+(??_Slot_DiodeTest+0)+0,w
	subwf	1+(??_Slot_DiodeTest+2)+0,w
	skipz
	goto	u8035
	movf	0+(??_Slot_DiodeTest+0)+0,w
	subwf	0+(??_Slot_DiodeTest+2)+0,w
u8035:
	skipnc
	goto	u8031
	goto	u8030
u8031:
	goto	l6122
u8030:
	line	626
	
l6116:	
;charge_mgr.c: 625: {
;charge_mgr.c: 626: Route_LinearLi(idx, pty, pst, &ct);
	movf	(Slot_DiodeTest@pty),w
	movwf	(Route_LinearLi@pty)
	movf	(Slot_DiodeTest@pst),w
	movwf	(Route_LinearLi@pst)
	movlw	(low(Slot_DiodeTest@ct|((0x0)<<8)))&0ffh
	movwf	(Route_LinearLi@pct)
	movf	(Slot_DiodeTest@idx),w
	fcall	_Route_LinearLi
	goto	l6098
	line	634
	
l6122:	
;charge_mgr.c: 628: }
;charge_mgr.c: 633: if((v > 2900) &&
;charge_mgr.c: 634: (((g_impData) & 0x0FFFU) <= 2300))
	movlw	0Bh
	subwf	(Slot_DiodeTest@v+1),w
	movlw	055h
	skipnz
	subwf	(Slot_DiodeTest@v),w
	skipc
	goto	u8041
	goto	u8040
u8041:
	goto	l6136
u8040:
	
l6124:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_DiodeTest+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_DiodeTest+0)+0
	movlw	08h
	subwf	1+(??_Slot_DiodeTest+0)+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_Slot_DiodeTest+0)+0,w
	skipnc
	goto	u8051
	goto	u8050
u8051:
	goto	l6136
u8050:
	line	636
	
l6126:	
;charge_mgr.c: 635: {
;charge_mgr.c: 636: *pty = 3;
	movf	(Slot_DiodeTest@pty),w
	movwf	fsr0
	movlw	low(03h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	637
;charge_mgr.c: 637: *pst = 7;
	movf	(Slot_DiodeTest@pst),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	638
	
l6128:	
;charge_mgr.c: 638: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	639
	
l6130:	
;charge_mgr.c: 639: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_DiodeTest@idx),w
	movwf	(??_Slot_DiodeTest+0)+0
	movlw	01h
	movwf	(??_Slot_DiodeTest+1)+0
	movlw	0
	movwf	(??_Slot_DiodeTest+1)+0+1
	goto	u8064
u8065:
	clrc
	rlf	(??_Slot_DiodeTest+1)+0,f
	rlf	(??_Slot_DiodeTest+1)+1,f
u8064:
	decfsz	(??_Slot_DiodeTest+0)+0,f
	goto	u8065
	
	comf	(??_Slot_DiodeTest+1)+0,f
	comf	(??_Slot_DiodeTest+1)+1,f
	movf	0+(??_Slot_DiodeTest+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_DiodeTest+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	640
;charge_mgr.c: 640: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_DiodeTest@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6098
	line	652
	
l6136:	
;charge_mgr.c: 642: }
;charge_mgr.c: 649: if(ct >= ((unsigned long)(2) * 16) && v > 2100 &&
;charge_mgr.c: 650: ((g_impData) & 0x0FFFU) <= 2300 &&
;charge_mgr.c: 651: v + 160 >= ((g_impData) & 0x0FFFU) &&
;charge_mgr.c: 652: v <= ((g_impData) & 0x0FFFU) + 150)
	movlw	0
	subwf	(Slot_DiodeTest@ct+1),w
	movlw	020h
	skipnz
	subwf	(Slot_DiodeTest@ct),w
	skipc
	goto	u8071
	goto	u8070
u8071:
	goto	l6152
u8070:
	
l6138:	
	movlw	08h
	subwf	(Slot_DiodeTest@v+1),w
	movlw	035h
	skipnz
	subwf	(Slot_DiodeTest@v),w
	skipc
	goto	u8081
	goto	u8080
u8081:
	goto	l6152
u8080:
	
l6140:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_DiodeTest+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_DiodeTest+0)+0
	movlw	08h
	subwf	1+(??_Slot_DiodeTest+0)+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_Slot_DiodeTest+0)+0,w
	skipnc
	goto	u8091
	goto	u8090
u8091:
	goto	l6152
u8090:
	
l6142:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_DiodeTest+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_DiodeTest+0)+0
	movf	(Slot_DiodeTest@v),w
	addlw	low(0A0h)
	movwf	(??_Slot_DiodeTest+2)+0
	movf	(Slot_DiodeTest@v+1),w
	skipnc
	addlw	1
	addlw	high(0A0h)
	movwf	1+(??_Slot_DiodeTest+2)+0
	movf	1+(??_Slot_DiodeTest+0)+0,w
	subwf	1+(??_Slot_DiodeTest+2)+0,w
	skipz
	goto	u8105
	movf	0+(??_Slot_DiodeTest+0)+0,w
	subwf	0+(??_Slot_DiodeTest+2)+0,w
u8105:
	skipc
	goto	u8101
	goto	u8100
u8101:
	goto	l6152
u8100:
	
l6144:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_DiodeTest+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_DiodeTest+0)+0
	movf	0+(??_Slot_DiodeTest+0)+0,w
	addlw	low(096h)
	movwf	(??_Slot_DiodeTest+2)+0
	movf	1+(??_Slot_DiodeTest+0)+0,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_DiodeTest+2)+0
	movf	(Slot_DiodeTest@v+1),w
	subwf	1+(??_Slot_DiodeTest+2)+0,w
	skipz
	goto	u8115
	movf	(Slot_DiodeTest@v),w
	subwf	0+(??_Slot_DiodeTest+2)+0,w
u8115:
	skipc
	goto	u8111
	goto	u8110
u8111:
	goto	l6152
u8110:
	line	654
	
l6146:	
;charge_mgr.c: 653: {
;charge_mgr.c: 654: Route_LinearLi(idx, pty, pst, &ct);
	movf	(Slot_DiodeTest@pty),w
	movwf	(Route_LinearLi@pty)
	movf	(Slot_DiodeTest@pst),w
	movwf	(Route_LinearLi@pst)
	movlw	(low(Slot_DiodeTest@ct|((0x0)<<8)))&0ffh
	movwf	(Route_LinearLi@pct)
	movf	(Slot_DiodeTest@idx),w
	fcall	_Route_LinearLi
	goto	l6098
	line	661
	
l6152:	
;charge_mgr.c: 656: }
;charge_mgr.c: 661: if(ct >= ((unsigned long)(2) * 16))
	movlw	0
	subwf	(Slot_DiodeTest@ct+1),w
	movlw	020h
	skipnz
	subwf	(Slot_DiodeTest@ct),w
	skipc
	goto	u8121
	goto	u8120
u8121:
	goto	l6098
u8120:
	line	663
	
l6154:	
;charge_mgr.c: 662: {
;charge_mgr.c: 663: unsigned int pre = ((g_impData) & 0x0FFFU);
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(Slot_DiodeTest@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Slot_DiodeTest@pre)
	line	668
;charge_mgr.c: 668: if(pre > 3500 && pre < 4090)
	movlw	0Dh
	subwf	(Slot_DiodeTest@pre+1),w
	movlw	0ADh
	skipnz
	subwf	(Slot_DiodeTest@pre),w
	skipc
	goto	u8131
	goto	u8130
u8131:
	goto	l6192
u8130:
	
l6156:	
	movlw	0Fh
	subwf	(Slot_DiodeTest@pre+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_DiodeTest@pre),w
	skipnc
	goto	u8141
	goto	u8140
u8141:
	goto	l6192
u8140:
	line	671
	
l6158:	
;charge_mgr.c: 669: {
;charge_mgr.c: 670: unsigned char tc;
;charge_mgr.c: 671: unsigned char hasRise = 0;
	clrf	(Slot_DiodeTest@hasRise)
	line	675
;charge_mgr.c: 675: for(tc = 0; tc < g_diodeTraceCnt; tc++)
	clrf	(Slot_DiodeTest@tc)
	goto	l6164
	
l6162:	
	incf	(Slot_DiodeTest@tc),f
	
l6164:	
	movf	(_g_diodeTraceCnt),w
	subwf	(Slot_DiodeTest@tc),w
	skipc
	goto	u8151
	goto	u8150
u8151:
	goto	l6162
u8150:
	line	683
	
l6166:	
;charge_mgr.c: 681: }
;charge_mgr.c: 682: }
;charge_mgr.c: 683: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150)
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(096h)
	movwf	(??_Slot_DiodeTest+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_DiodeTest+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_DiodeTest+0)+0,w
	skipz
	goto	u8165
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_DiodeTest+0)+0,w
u8165:
	skipnc
	goto	u8161
	goto	u8160
u8161:
	goto	l6174
u8160:
	line	685
	
l6168:	
;charge_mgr.c: 684: {
;charge_mgr.c: 685: Route_LiIon(idx, pty, pst, v, &ct);
	movf	(Slot_DiodeTest@pty),w
	movwf	(Route_LiIon@pty)
	movf	(Slot_DiodeTest@pst),w
	movwf	(Route_LiIon@pst)
	movf	(Slot_DiodeTest@v+1),w
	movwf	(Route_LiIon@v+1)
	movf	(Slot_DiodeTest@v),w
	movwf	(Route_LiIon@v)
	movlw	(low(Slot_DiodeTest@ct|((0x0)<<8)))&0ffh
	movwf	(Route_LiIon@pct)
	movf	(Slot_DiodeTest@idx),w
	fcall	_Route_LiIon
	goto	l6098
	line	688
	
l6174:	
;charge_mgr.c: 687: }
;charge_mgr.c: 688: if(!hasRise)
	movf	((Slot_DiodeTest@hasRise)),w
	btfss	status,2
	goto	u8171
	goto	u8170
u8171:
	goto	l6186
u8170:
	goto	l6126
	line	697
	
l6186:	
;charge_mgr.c: 696: }
;charge_mgr.c: 697: Route_LinearLi(idx, pty, pst, &ct);
	movf	(Slot_DiodeTest@pty),w
	movwf	(Route_LinearLi@pty)
	movf	(Slot_DiodeTest@pst),w
	movwf	(Route_LinearLi@pst)
	movlw	(low(Slot_DiodeTest@ct|((0x0)<<8)))&0ffh
	movwf	(Route_LinearLi@pct)
	movf	(Slot_DiodeTest@idx),w
	fcall	_Route_LinearLi
	goto	l6098
	line	700
	
l6192:	
;charge_mgr.c: 699: }
;charge_mgr.c: 700: if(v > 3500 && v < 4090)
	movlw	0Dh
	subwf	(Slot_DiodeTest@v+1),w
	movlw	0ADh
	skipnz
	subwf	(Slot_DiodeTest@v),w
	skipc
	goto	u8181
	goto	u8180
u8181:
	goto	l6202
u8180:
	
l6194:	
	movlw	0Fh
	subwf	(Slot_DiodeTest@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_DiodeTest@v),w
	skipnc
	goto	u8191
	goto	u8190
u8191:
	goto	l6202
u8190:
	line	702
	
l6196:	
;charge_mgr.c: 701: {
;charge_mgr.c: 702: Route_LinearLi(idx, pty, pst, &ct);
	movf	(Slot_DiodeTest@pty),w
	movwf	(Route_LinearLi@pty)
	movf	(Slot_DiodeTest@pst),w
	movwf	(Route_LinearLi@pst)
	movlw	(low(Slot_DiodeTest@ct|((0x0)<<8)))&0ffh
	movwf	(Route_LinearLi@pct)
	movf	(Slot_DiodeTest@idx),w
	fcall	_Route_LinearLi
	goto	l6098
	line	711
	
l6202:	
;charge_mgr.c: 704: }
;charge_mgr.c: 711: if(pre >= 4090 && v >= 4090)
	movlw	0Fh
	subwf	(Slot_DiodeTest@pre+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_DiodeTest@pre),w
	skipc
	goto	u8201
	goto	u8200
u8201:
	goto	l6212
u8200:
	
l6204:	
	movlw	0Fh
	subwf	(Slot_DiodeTest@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_DiodeTest@v),w
	skipc
	goto	u8211
	goto	u8210
u8211:
	goto	l6212
u8210:
	line	713
	
l6206:	
;charge_mgr.c: 712: {
;charge_mgr.c: 713: Route_LinearLi(idx, pty, pst, &ct);
	movf	(Slot_DiodeTest@pty),w
	movwf	(Route_LinearLi@pty)
	movf	(Slot_DiodeTest@pst),w
	movwf	(Route_LinearLi@pst)
	movlw	(low(Slot_DiodeTest@ct|((0x0)<<8)))&0ffh
	movwf	(Route_LinearLi@pct)
	movf	(Slot_DiodeTest@idx),w
	fcall	_Route_LinearLi
	goto	l6098
	line	724
	
l6212:	
;charge_mgr.c: 715: }
;charge_mgr.c: 720: if(v > 2300 && v < 3500 &&
;charge_mgr.c: 721: pre < 3500 &&
;charge_mgr.c: 722: v + 150 >= pre &&
;charge_mgr.c: 723: pre + 150 >= v &&
;charge_mgr.c: 724: (((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150)
	movlw	08h
	subwf	(Slot_DiodeTest@v+1),w
	movlw	0FDh
	skipnz
	subwf	(Slot_DiodeTest@v),w
	skipc
	goto	u8221
	goto	u8220
u8221:
	goto	l6126
u8220:
	
l6214:	
	movlw	0Dh
	subwf	(Slot_DiodeTest@v+1),w
	movlw	0ACh
	skipnz
	subwf	(Slot_DiodeTest@v),w
	skipnc
	goto	u8231
	goto	u8230
u8231:
	goto	l6126
u8230:
	
l6216:	
	movlw	0Dh
	subwf	(Slot_DiodeTest@pre+1),w
	movlw	0ACh
	skipnz
	subwf	(Slot_DiodeTest@pre),w
	skipnc
	goto	u8241
	goto	u8240
u8241:
	goto	l6126
u8240:
	
l6218:	
	movf	(Slot_DiodeTest@v),w
	addlw	low(096h)
	movwf	(??_Slot_DiodeTest+0)+0
	movf	(Slot_DiodeTest@v+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_DiodeTest+0)+0
	movf	(Slot_DiodeTest@pre+1),w
	subwf	1+(??_Slot_DiodeTest+0)+0,w
	skipz
	goto	u8255
	movf	(Slot_DiodeTest@pre),w
	subwf	0+(??_Slot_DiodeTest+0)+0,w
u8255:
	skipc
	goto	u8251
	goto	u8250
u8251:
	goto	l6126
u8250:
	
l6220:	
	movf	(Slot_DiodeTest@pre),w
	addlw	low(096h)
	movwf	(??_Slot_DiodeTest+0)+0
	movf	(Slot_DiodeTest@pre+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_DiodeTest+0)+0
	movf	(Slot_DiodeTest@v+1),w
	subwf	1+(??_Slot_DiodeTest+0)+0,w
	skipz
	goto	u8265
	movf	(Slot_DiodeTest@v),w
	subwf	0+(??_Slot_DiodeTest+0)+0,w
u8265:
	skipc
	goto	u8261
	goto	u8260
u8261:
	goto	l6126
u8260:
	
l6222:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(096h)
	movwf	(??_Slot_DiodeTest+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_DiodeTest+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_DiodeTest+0)+0,w
	skipz
	goto	u8275
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_DiodeTest+0)+0,w
u8275:
	skipnc
	goto	u8271
	goto	u8270
u8271:
	goto	l6126
u8270:
	line	726
	
l6224:	
;charge_mgr.c: 725: {
;charge_mgr.c: 726: Route_LinearLi(idx, pty, pst, &ct);
	movf	(Slot_DiodeTest@pty),w
	movwf	(Route_LinearLi@pty)
	movf	(Slot_DiodeTest@pst),w
	movwf	(Route_LinearLi@pst)
	movlw	(low(Slot_DiodeTest@ct|((0x0)<<8)))&0ffh
	movwf	(Route_LinearLi@pct)
	movf	(Slot_DiodeTest@idx),w
	fcall	_Route_LinearLi
	goto	l6098
	line	737
	
l618:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_DiodeTest
	__end_of_Slot_DiodeTest:
	signat	_Slot_DiodeTest,20602
	global	___wmul

;; *************** function ___wmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
;; Parameters:    Size  Location     Type
;;  multiplier      2    2[COMMON] unsigned int 
;;  multiplicand    2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  product         2    6[COMMON] unsigned int 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         6       0       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_ImpCheck
;;		_Slot_DiodeTest
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
global __ptext12
__ptext12:	;psect for function ___wmul
psect	text12
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
	global	__size_of___wmul
	__size_of___wmul	equ	__end_of___wmul-___wmul
	
___wmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___wmul: [wreg+status,2+status,0]
	line	43
	
l5626:	
	clrf	(___wmul@product)
	clrf	(___wmul@product+1)
	line	45
	
l5628:	
	btfss	(___wmul@multiplier),(0)&7
	goto	u7051
	goto	u7050
u7051:
	goto	l5632
u7050:
	line	46
	
l5630:	
	movf	(___wmul@multiplicand),w
	addwf	(___wmul@product),f
	skipnc
	incf	(___wmul@product+1),f
	movf	(___wmul@multiplicand+1),w
	addwf	(___wmul@product+1),f
	line	47
	
l5632:	
	clrc
	rlf	(___wmul@multiplicand),f
	rlf	(___wmul@multiplicand+1),f
	line	48
	
l5634:	
	clrc
	rrf	(___wmul@multiplier+1),f
	rrf	(___wmul@multiplier),f
	line	49
	
l5636:	
	movf	((___wmul@multiplier)),w
iorwf	((___wmul@multiplier+1)),w
	btfss	status,2
	goto	u7061
	goto	u7060
u7061:
	goto	l5628
u7060:
	line	52
	
l5638:	
	movf	(___wmul@product+1),w
	movwf	(?___wmul+1)
	movf	(___wmul@product),w
	movwf	(?___wmul)
	line	53
	
l894:	
	return
	opt stack 0
GLOBAL	__end_of___wmul
	__end_of___wmul:
	signat	___wmul,8314
	global	_Route_LinearLi

;; *************** function _Route_LinearLi *****************
;; Defined at:
;;		line 222 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  pty             1   36[BANK0 ] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@ty(1), 
;;  pst             1   37[BANK0 ] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@st(1), 
;;  pct             1   38[BANK0 ] PTR unsigned int 
;;		 -> Slot_DiodeTest@ct(2), 
;; Auto vars:     Size  Location     Type
;;  idx             1   42[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       3       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       7       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Li_Route
;; This function is called by:
;;		_Slot_DiodeTest
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	222
global __ptext13
__ptext13:	;psect for function _Route_LinearLi
psect	text13
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	222
	global	__size_of_Route_LinearLi
	__size_of_Route_LinearLi	equ	__end_of_Route_LinearLi-_Route_LinearLi
	
_Route_LinearLi:	
;incstack = 0
	opt	stack 1
; Regs used in _Route_LinearLi: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Route_LinearLi@idx stored from wreg
	movwf	(Route_LinearLi@idx)
	line	225
	
l5618:	
;charge_mgr.c: 225: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	226
	
l5620:	
;charge_mgr.c: 226: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Route_LinearLi@idx),w
	movwf	(??_Route_LinearLi+0)+0
	movlw	01h
	movwf	(??_Route_LinearLi+1)+0
	movlw	0
	movwf	(??_Route_LinearLi+1)+0+1
	goto	u7044
u7045:
	clrc
	rlf	(??_Route_LinearLi+1)+0,f
	rlf	(??_Route_LinearLi+1)+1,f
u7044:
	decfsz	(??_Route_LinearLi+0)+0,f
	goto	u7045
	
	comf	(??_Route_LinearLi+1)+0,f
	comf	(??_Route_LinearLi+1)+1,f
	movf	0+(??_Route_LinearLi+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Route_LinearLi+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	227
	
l5622:	
;charge_mgr.c: 227: *pty = 6;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Route_LinearLi@pty),w
	movwf	fsr0
	movlw	low(06h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	228
	
l5624:	
;charge_mgr.c: 228: Li_Route(idx, ((g_impData) & 0x0FFFU), pst, pct);
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(Li_Route@v)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Li_Route@v)
	movf	(Route_LinearLi@pst),w
	movwf	(Li_Route@pst)
	movf	(Route_LinearLi@pct),w
	movwf	(Li_Route@pct)
	movf	(Route_LinearLi@idx),w
	fcall	_Li_Route
	line	229
	
l545:	
	return
	opt stack 0
GLOBAL	__end_of_Route_LinearLi
	__end_of_Route_LinearLi:
	signat	_Route_LinearLi,16505
	global	_Route_LiIon

;; *************** function _Route_LiIon *****************
;; Defined at:
;;		line 211 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  pty             1   36[BANK0 ] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@ty(1), 
;;  pst             1   37[BANK0 ] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@st(1), 
;;  v               2   38[BANK0 ] unsigned int 
;;  pct             1   40[BANK0 ] PTR unsigned int 
;;		 -> Slot_DiodeTest@ct(2), Slot_ImpCheck@ct(2), 
;; Auto vars:     Size  Location     Type
;;  idx             1   44[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       5       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       9       0       0       0
;;Total ram usage:        9 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Li_Route
;; This function is called by:
;;		_Slot_ImpCheck
;;		_Slot_DiodeTest
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	line	211
global __ptext14
__ptext14:	;psect for function _Route_LiIon
psect	text14
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	211
	global	__size_of_Route_LiIon
	__size_of_Route_LiIon	equ	__end_of_Route_LiIon-_Route_LiIon
	
_Route_LiIon:	
;incstack = 0
	opt	stack 1
; Regs used in _Route_LiIon: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Route_LiIon@idx stored from wreg
	movwf	(Route_LiIon@idx)
	line	214
	
l5610:	
;charge_mgr.c: 214: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	215
	
l5612:	
;charge_mgr.c: 215: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Route_LiIon@idx),w
	movwf	(??_Route_LiIon+0)+0
	movlw	01h
	movwf	(??_Route_LiIon+1)+0
	movlw	0
	movwf	(??_Route_LiIon+1)+0+1
	goto	u7034
u7035:
	clrc
	rlf	(??_Route_LiIon+1)+0,f
	rlf	(??_Route_LiIon+1)+1,f
u7034:
	decfsz	(??_Route_LiIon+0)+0,f
	goto	u7035
	
	comf	(??_Route_LiIon+1)+0,f
	comf	(??_Route_LiIon+1)+1,f
	movf	0+(??_Route_LiIon+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Route_LiIon+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	216
	
l5614:	
;charge_mgr.c: 216: *pty = 1;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Route_LiIon@pty),w
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	clrf	indf
	incf	indf,f
	line	217
	
l5616:	
;charge_mgr.c: 217: Li_Route(idx, v, pst, pct);
	movf	(Route_LiIon@v+1),w
	movwf	(Li_Route@v+1)
	movf	(Route_LiIon@v),w
	movwf	(Li_Route@v)
	movf	(Route_LiIon@pst),w
	movwf	(Li_Route@pst)
	movf	(Route_LiIon@pct),w
	movwf	(Li_Route@pct)
	movf	(Route_LiIon@idx),w
	fcall	_Li_Route
	line	218
	
l542:	
	return
	opt stack 0
GLOBAL	__end_of_Route_LiIon
	__end_of_Route_LiIon:
	signat	_Route_LiIon,20601
	global	_Slot_Detect

;; *************** function _Slot_Detect *****************
;; Defined at:
;;		line 268 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  pst             1   36[BANK0 ] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@st(1), 
;;  pty             1   37[BANK0 ] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@ty(1), 
;;  v               2   38[BANK0 ] unsigned int 
;;  ct              2   40[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1   51[BANK0 ] unsigned char 
;;  v_ref           2   49[BANK0 ] unsigned int 
;;  v_init          2   47[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   36[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       6       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       5       0       0       0
;;      Totals:         0      16       0       0       0
;;Total ram usage:       16 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Detect_BatteryType
;;		_Get_Vcc
;;		_Li_Route
;;		___lwdiv
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=0
	line	268
global __ptext15
__ptext15:	;psect for function _Slot_Detect
psect	text15
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	268
	global	__size_of_Slot_Detect
	__size_of_Slot_Detect	equ	__end_of_Slot_Detect-_Slot_Detect
	
_Slot_Detect:	
;incstack = 0
	opt	stack 2
; Regs used in _Slot_Detect: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Slot_Detect@idx stored from wreg
	movwf	(Slot_Detect@idx)
	line	271
	
l5782:	
;charge_mgr.c: 271: ct++;
	incf	(Slot_Detect@ct),f
	skipnz
	incf	(Slot_Detect@ct+1),f
	line	274
	
l5784:	
;charge_mgr.c: 274: if(ct == 1)
		decf	((Slot_Detect@ct)),w
iorwf	((Slot_Detect@ct+1)),w
	btfss	status,2
	goto	u7261
	goto	u7260
u7261:
	goto	l5790
u7260:
	line	276
	
l5786:	
;charge_mgr.c: 275: {
;charge_mgr.c: 276: g_stableCnt[idx] = 0;
	movf	(Slot_Detect@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	277
	
l5788:	
;charge_mgr.c: 277: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Detect@idx),w
	movwf	(??_Slot_Detect+0)+0
	movlw	01h
	movwf	(??_Slot_Detect+1)+0
	movlw	0
	movwf	(??_Slot_Detect+1)+0+1
	goto	u7274
u7275:
	clrc
	rlf	(??_Slot_Detect+1)+0,f
	rlf	(??_Slot_Detect+1)+1,f
u7274:
	decfsz	(??_Slot_Detect+0)+0,f
	goto	u7275
	
	comf	(??_Slot_Detect+1)+0,f
	comf	(??_Slot_Detect+1)+1,f
	movf	0+(??_Slot_Detect+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Detect+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	280
	
l5790:	
;charge_mgr.c: 278: }
;charge_mgr.c: 280: if(ct < ((unsigned long)(2) * 16))
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Slot_Detect@ct+1),w
	movlw	020h
	skipnz
	subwf	(Slot_Detect@ct),w
	skipnc
	goto	u7281
	goto	u7280
u7281:
	goto	l5796
u7280:
	line	288
	
l5792:	
;charge_mgr.c: 281: {
;charge_mgr.c: 288: return ct;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Detect@ct+1),w
	movwf	(?_Slot_Detect+1)
	movf	(Slot_Detect@ct),w
	movwf	(?_Slot_Detect)
	goto	l557
	line	297
	
l5796:	
;charge_mgr.c: 289: }
;charge_mgr.c: 297: if(ct == ((unsigned long)(2) * 16))
		movlw	32
	xorwf	((Slot_Detect@ct)),w
iorwf	((Slot_Detect@ct+1)),w
	btfss	status,2
	goto	u7291
	goto	u7290
u7291:
	goto	l5808
u7290:
	line	299
	
l5798:	
;charge_mgr.c: 298: {
;charge_mgr.c: 299: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_Detect@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Detect@v),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Detect@v+1),w
	movwf	indf
	line	300
	
l5800:	
;charge_mgr.c: 300: if(v > 2900)
	movlw	0Bh
	subwf	(Slot_Detect@v+1),w
	movlw	055h
	skipnz
	subwf	(Slot_Detect@v),w
	skipc
	goto	u7301
	goto	u7300
u7301:
	goto	l5792
u7300:
	line	301
	
l5802:	
;charge_mgr.c: 301: g_capFlag |= (unsigned int)1 << idx;
	incf	(Slot_Detect@idx),w
	movwf	(??_Slot_Detect+0)+0
	movlw	01h
	movwf	(??_Slot_Detect+1)+0
	movlw	0
	movwf	(??_Slot_Detect+1)+0+1
	goto	u7314
u7315:
	clrc
	rlf	(??_Slot_Detect+1)+0,f
	rlf	(??_Slot_Detect+1)+1,f
u7314:
	decfsz	(??_Slot_Detect+0)+0,f
	goto	u7315
	
	movf	0+(??_Slot_Detect+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Detect+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag+1)^080h,f
	goto	l5792
	line	304
	
l5808:	
;charge_mgr.c: 303: }
;charge_mgr.c: 304: if(v > 2900 && v < 4090)
	movlw	0Bh
	subwf	(Slot_Detect@v+1),w
	movlw	055h
	skipnz
	subwf	(Slot_Detect@v),w
	skipc
	goto	u7321
	goto	u7320
u7321:
	goto	l5882
u7320:
	
l5810:	
	movlw	0Fh
	subwf	(Slot_Detect@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Detect@v),w
	skipnc
	goto	u7331
	goto	u7330
u7331:
	goto	l5882
u7330:
	line	316
	
l5812:	
;charge_mgr.c: 305: {
;charge_mgr.c: 315: if(!(g_capFlag & ((unsigned int)1 << idx)) && *pty != 5 &&
;charge_mgr.c: 316: v <= 3500)
	incf	(Slot_Detect@idx),w
	movwf	(??_Slot_Detect+0)+0
	movlw	01h
	movwf	(??_Slot_Detect+1)+0
	movlw	0
	movwf	(??_Slot_Detect+1)+0+1
	goto	u7344
u7345:
	clrc
	rlf	(??_Slot_Detect+1)+0,f
	rlf	(??_Slot_Detect+1)+1,f
u7344:
	decfsz	(??_Slot_Detect+0)+0,f
	goto	u7345
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Detect+1)+0,w
	movwf	(??_Slot_Detect+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Detect+1)+0,w
	movwf	1+(??_Slot_Detect+3)+0
	movf	((??_Slot_Detect+3)+0),w
iorwf	((??_Slot_Detect+3)+1),w
	btfss	status,2
	goto	u7351
	goto	u7350
u7351:
	goto	l5830
u7350:
	
l5814:	
	movf	(Slot_Detect@pty),w
	movwf	fsr0
		movlw	5
	bcf	status, 7	;select IRP bank0
	xorwf	(indf),w
	btfsc	status,2
	goto	u7361
	goto	u7360
u7361:
	goto	l5830
u7360:
	
l5816:	
	movlw	0Dh
	subwf	(Slot_Detect@v+1),w
	movlw	0ADh
	skipnz
	subwf	(Slot_Detect@v),w
	skipnc
	goto	u7371
	goto	u7370
u7371:
	goto	l5830
u7370:
	line	318
	
l5818:	
;charge_mgr.c: 317: {
;charge_mgr.c: 318: ct = 0;
	clrf	(Slot_Detect@ct)
	clrf	(Slot_Detect@ct+1)
	line	319
	
l5820:	
;charge_mgr.c: 319: g_slotRefV[idx] = 0;
	clrc
	rlf	(Slot_Detect@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	320
	
l5822:	
;charge_mgr.c: 320: g_stableCnt[idx] = 0;
	movf	(Slot_Detect@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	321
	
l5824:	
;charge_mgr.c: 321: g_detectLowCnt[idx] = 0;
	movf	(Slot_Detect@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l5792
	line	332
	
l5830:	
;charge_mgr.c: 323: }
;charge_mgr.c: 332: unsigned int v_init = g_slotRefV[idx];
	clrc
	rlf	(Slot_Detect@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(Slot_Detect@v_init)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Detect@v_init+1)
	line	334
;charge_mgr.c: 334: if(g_stableCnt[idx] >= 20)
	movf	(Slot_Detect@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipc
	goto	u7381
	goto	u7380
u7381:
	goto	l5864
u7380:
	line	339
	
l5832:	
;charge_mgr.c: 335: {
;charge_mgr.c: 339: g_highVFlag |= (unsigned int)1 << idx;
	incf	(Slot_Detect@idx),w
	movwf	(??_Slot_Detect+0)+0
	movlw	01h
	movwf	(??_Slot_Detect+1)+0
	movlw	0
	movwf	(??_Slot_Detect+1)+0+1
	goto	u7394
u7395:
	clrc
	rlf	(??_Slot_Detect+1)+0,f
	rlf	(??_Slot_Detect+1)+1,f
u7394:
	decfsz	(??_Slot_Detect+0)+0,f
	goto	u7395
	
	movf	0+(??_Slot_Detect+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Detect+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag+1)^080h,f
	line	341
	
l5834:	
;charge_mgr.c: 341: if(v <= 2900)
	movlw	0Bh
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Slot_Detect@v+1),w
	movlw	055h
	skipnz
	subwf	(Slot_Detect@v),w
	skipnc
	goto	u7401
	goto	u7400
u7401:
	goto	l5842
u7400:
	line	344
	
l5836:	
;charge_mgr.c: 342: {
;charge_mgr.c: 344: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Detect@idx),w
	movwf	(??_Slot_Detect+0)+0
	movlw	01h
	movwf	(??_Slot_Detect+1)+0
	movlw	0
	movwf	(??_Slot_Detect+1)+0+1
	goto	u7414
u7415:
	clrc
	rlf	(??_Slot_Detect+1)+0,f
	rlf	(??_Slot_Detect+1)+1,f
u7414:
	decfsz	(??_Slot_Detect+0)+0,f
	goto	u7415
	
	comf	(??_Slot_Detect+1)+0,f
	comf	(??_Slot_Detect+1)+1,f
	movf	0+(??_Slot_Detect+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Detect+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	345
	
l5838:	
;charge_mgr.c: 345: g_stableCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Detect@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	346
	
l5840:	
;charge_mgr.c: 346: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Detect@idx),w
	movwf	(??_Slot_Detect+0)+0
	movlw	01h
	movwf	(??_Slot_Detect+1)+0
	movlw	0
	movwf	(??_Slot_Detect+1)+0+1
	goto	u7424
u7425:
	clrc
	rlf	(??_Slot_Detect+1)+0,f
	rlf	(??_Slot_Detect+1)+1,f
u7424:
	decfsz	(??_Slot_Detect+0)+0,f
	goto	u7425
	
	comf	(??_Slot_Detect+1)+0,f
	comf	(??_Slot_Detect+1)+1,f
	movf	0+(??_Slot_Detect+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Detect+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	347
;charge_mgr.c: 347: }
	goto	l5898
	line	348
	
l5842:	
;charge_mgr.c: 348: else if(ct < ((unsigned long)(2) * 16) + ((unsigned long)(8) * 16))
	movlw	0
	subwf	(Slot_Detect@ct+1),w
	movlw	0A0h
	skipnz
	subwf	(Slot_Detect@ct),w
	skipnc
	goto	u7431
	goto	u7430
u7431:
	goto	l5858
u7430:
	line	356
	
l5844:	
;charge_mgr.c: 349: {
;charge_mgr.c: 355: if((g_highVFlag & ((unsigned int)1 << idx)) &&
;charge_mgr.c: 356: ct >= ((unsigned long)(2) * 16) + 25U)
	incf	(Slot_Detect@idx),w
	movwf	(??_Slot_Detect+0)+0
	movlw	01h
	movwf	(??_Slot_Detect+1)+0
	movlw	0
	movwf	(??_Slot_Detect+1)+0+1
	goto	u7444
u7445:
	clrc
	rlf	(??_Slot_Detect+1)+0,f
	rlf	(??_Slot_Detect+1)+1,f
u7444:
	decfsz	(??_Slot_Detect+0)+0,f
	goto	u7445
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Detect+1)+0,w
	movwf	(??_Slot_Detect+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Detect+1)+0,w
	movwf	1+(??_Slot_Detect+3)+0
	movf	((??_Slot_Detect+3)+0),w
iorwf	((??_Slot_Detect+3)+1),w
	btfsc	status,2
	goto	u7451
	goto	u7450
u7451:
	goto	l5850
u7450:
	
l5846:	
	movlw	0
	subwf	(Slot_Detect@ct+1),w
	movlw	039h
	skipnz
	subwf	(Slot_Detect@ct),w
	skipc
	goto	u7461
	goto	u7460
u7461:
	goto	l5850
u7460:
	goto	l5858
	line	359
	
l5850:	
;charge_mgr.c: 359: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_Detect@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Detect@v),w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Detect@v+1),w
	movwf	indf
	goto	l5792
	line	369
	
l5858:	
;charge_mgr.c: 369: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Detect@idx),w
	movwf	(??_Slot_Detect+0)+0
	movlw	01h
	movwf	(??_Slot_Detect+1)+0
	movlw	0
	movwf	(??_Slot_Detect+1)+0+1
	goto	u7474
u7475:
	clrc
	rlf	(??_Slot_Detect+1)+0,f
	rlf	(??_Slot_Detect+1)+1,f
u7474:
	decfsz	(??_Slot_Detect+0)+0,f
	goto	u7475
	
	comf	(??_Slot_Detect+1)+0,f
	comf	(??_Slot_Detect+1)+1,f
	movf	0+(??_Slot_Detect+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Detect+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	370
	
l5860:	
;charge_mgr.c: 370: g_stableCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Detect@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	371
	
l5862:	
;charge_mgr.c: 371: *pty = 5;
	movf	(Slot_Detect@pty),w
	movwf	fsr0
	movlw	low(05h)
	movwf	indf
	line	372
;charge_mgr.c: 372: goto amb_check;
	goto	l569
	line	378
	
l5864:	
;charge_mgr.c: 375: else
;charge_mgr.c: 376: {
;charge_mgr.c: 378: if(v + 50 < v_init)
	movf	(Slot_Detect@v),w
	addlw	low(032h)
	movwf	(??_Slot_Detect+0)+0
	movf	(Slot_Detect@v+1),w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Detect+0)+0
	movf	(Slot_Detect@v_init+1),w
	subwf	1+(??_Slot_Detect+0)+0,w
	skipz
	goto	u7485
	movf	(Slot_Detect@v_init),w
	subwf	0+(??_Slot_Detect+0)+0,w
u7485:
	skipnc
	goto	u7481
	goto	u7480
u7481:
	goto	l5868
u7480:
	line	381
	
l5866:	
;charge_mgr.c: 379: {
;charge_mgr.c: 381: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_Detect@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Detect@v),w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Detect@v+1),w
	movwf	indf
	line	382
;charge_mgr.c: 382: g_stableCnt[idx] = 0;
	movf	(Slot_Detect@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	383
;charge_mgr.c: 383: }
	goto	l572
	line	387
	
l5868:	
;charge_mgr.c: 384: else
;charge_mgr.c: 385: {
;charge_mgr.c: 387: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_Detect@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Detect@v),w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Detect@v+1),w
	movwf	indf
	line	388
;charge_mgr.c: 388: g_stableCnt[idx]++;
	movf	(Slot_Detect@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	389
	
l572:	
	line	390
;charge_mgr.c: 389: }
;charge_mgr.c: 390: if(g_stableCnt[idx] < 20)
	movf	(Slot_Detect@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u7491
	goto	u7490
u7491:
	goto	l5874
u7490:
	goto	l5792
	line	393
	
l5874:	
;charge_mgr.c: 393: if(g_capFlag & ((unsigned int)1 << idx))
	incf	(Slot_Detect@idx),w
	movwf	(??_Slot_Detect+0)+0
	movlw	01h
	movwf	(??_Slot_Detect+1)+0
	movlw	0
	movwf	(??_Slot_Detect+1)+0+1
	goto	u7504
u7505:
	clrc
	rlf	(??_Slot_Detect+1)+0,f
	rlf	(??_Slot_Detect+1)+1,f
u7504:
	decfsz	(??_Slot_Detect+0)+0,f
	goto	u7505
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Detect+1)+0,w
	movwf	(??_Slot_Detect+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Detect+1)+0,w
	movwf	1+(??_Slot_Detect+3)+0
	movf	((??_Slot_Detect+3)+0),w
iorwf	((??_Slot_Detect+3)+1),w
	btfsc	status,2
	goto	u7511
	goto	u7510
u7511:
	goto	l5880
u7510:
	goto	l5792
	line	395
	
l5880:	
;charge_mgr.c: 395: g_stableCnt[idx] = 0;
	movf	(Slot_Detect@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l5898
	line	398
	
l5882:	
;charge_mgr.c: 398: else if(ct < ((unsigned long)(2) * 16) + ((unsigned long)(8) * 16) && v < 4090)
	movlw	0
	subwf	(Slot_Detect@ct+1),w
	movlw	0A0h
	skipnz
	subwf	(Slot_Detect@ct),w
	skipnc
	goto	u7521
	goto	u7520
u7521:
	goto	l5898
u7520:
	
l5884:	
	movlw	0Fh
	subwf	(Slot_Detect@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Detect@v),w
	skipnc
	goto	u7531
	goto	u7530
u7531:
	goto	l5898
u7530:
	line	400
	
l5886:	
;charge_mgr.c: 399: {
;charge_mgr.c: 400: unsigned int v_ref = g_slotRefV[idx];
	clrc
	rlf	(Slot_Detect@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(Slot_Detect@v_ref)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Detect@v_ref+1)
	line	401
	
l5888:	
;charge_mgr.c: 401: if(v_ref < 4090 && v + 50 < v_ref)
	movlw	0Fh
	subwf	(Slot_Detect@v_ref+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Detect@v_ref),w
	skipnc
	goto	u7541
	goto	u7540
u7541:
	goto	l5898
u7540:
	
l5890:	
	movf	(Slot_Detect@v),w
	addlw	low(032h)
	movwf	(??_Slot_Detect+0)+0
	movf	(Slot_Detect@v+1),w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Detect+0)+0
	movf	(Slot_Detect@v_ref+1),w
	subwf	1+(??_Slot_Detect+0)+0,w
	skipz
	goto	u7555
	movf	(Slot_Detect@v_ref),w
	subwf	0+(??_Slot_Detect+0)+0,w
u7555:
	skipnc
	goto	u7551
	goto	u7550
u7551:
	goto	l5898
u7550:
	goto	l5850
	line	411
	
l5898:	
;charge_mgr.c: 405: }
;charge_mgr.c: 406: }
;charge_mgr.c: 411: if(g_capFlag & ((unsigned int)1 << idx))
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Detect@idx),w
	movwf	(??_Slot_Detect+0)+0
	movlw	01h
	movwf	(??_Slot_Detect+1)+0
	movlw	0
	movwf	(??_Slot_Detect+1)+0+1
	goto	u7564
u7565:
	clrc
	rlf	(??_Slot_Detect+1)+0,f
	rlf	(??_Slot_Detect+1)+1,f
u7564:
	decfsz	(??_Slot_Detect+0)+0,f
	goto	u7565
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Detect+1)+0,w
	movwf	(??_Slot_Detect+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Detect+1)+0,w
	movwf	1+(??_Slot_Detect+3)+0
	movf	((??_Slot_Detect+3)+0),w
iorwf	((??_Slot_Detect+3)+1),w
	btfsc	status,2
	goto	u7571
	goto	u7570
u7571:
	goto	l5906
u7570:
	line	413
	
l5900:	
;charge_mgr.c: 412: {
;charge_mgr.c: 413: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Detect@idx),w
	movwf	(??_Slot_Detect+0)+0
	movlw	01h
	movwf	(??_Slot_Detect+1)+0
	movlw	0
	movwf	(??_Slot_Detect+1)+0+1
	goto	u7584
u7585:
	clrc
	rlf	(??_Slot_Detect+1)+0,f
	rlf	(??_Slot_Detect+1)+1,f
u7584:
	decfsz	(??_Slot_Detect+0)+0,f
	goto	u7585
	
	comf	(??_Slot_Detect+1)+0,f
	comf	(??_Slot_Detect+1)+1,f
	movf	0+(??_Slot_Detect+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Detect+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	414
	
l5902:	
;charge_mgr.c: 414: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Detect@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	415
	
l5904:	
;charge_mgr.c: 415: *pty = 5;
	movf	(Slot_Detect@pty),w
	movwf	fsr0
	movlw	low(05h)
	movwf	indf
	line	416
;charge_mgr.c: 416: }
	goto	l5916
	line	419
	
l5906:	
;charge_mgr.c: 417: else
;charge_mgr.c: 418: {
;charge_mgr.c: 419: *pty = Detect_BatteryType(v);
	movf	(Slot_Detect@pty),w
	movwf	fsr0
	movf	(Slot_Detect@v+1),w
	movwf	(Detect_BatteryType@voltage+1)
	movf	(Slot_Detect@v),w
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	426
	
l5908:	
;charge_mgr.c: 425: if(*pty == 0 && v >= 4090 &&
;charge_mgr.c: 426: ct >= ((unsigned long)(2) * 16) + ((unsigned long)(8) * 16))
	movf	(Slot_Detect@pty),w
	movwf	fsr0
	movf	(indf),w
	btfss	status,2
	goto	u7591
	goto	u7590
u7591:
	goto	l5916
u7590:
	
l5910:	
	movlw	0Fh
	subwf	(Slot_Detect@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Detect@v),w
	skipc
	goto	u7601
	goto	u7600
u7601:
	goto	l5916
u7600:
	
l5912:	
	movlw	0
	subwf	(Slot_Detect@ct+1),w
	movlw	0A0h
	skipnz
	subwf	(Slot_Detect@ct),w
	skipc
	goto	u7611
	goto	u7610
u7611:
	goto	l5916
u7610:
	goto	l5904
	line	432
	
l5916:	
;charge_mgr.c: 428: }
;charge_mgr.c: 432: if(v < 500)
	movlw	01h
	subwf	(Slot_Detect@v+1),w
	movlw	0F4h
	skipnz
	subwf	(Slot_Detect@v),w
	skipnc
	goto	u7621
	goto	u7620
u7621:
	goto	l5924
u7620:
	line	434
	
l5918:	
;charge_mgr.c: 433: {
;charge_mgr.c: 434: g_detectLowCnt[idx]++;
	movf	(Slot_Detect@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	435
;charge_mgr.c: 435: if(g_detectLowCnt[idx] < 5)
	movf	(Slot_Detect@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u7631
	goto	u7630
u7631:
	goto	l569
u7630:
	goto	l5792
	line	439
	
l5924:	
;charge_mgr.c: 439: else if(*pty != 5 && *pty != 1 && *pty != 6)
	movf	(Slot_Detect@pty),w
	movwf	fsr0
		movlw	5
	xorwf	(indf),w
	btfsc	status,2
	goto	u7641
	goto	u7640
u7641:
	goto	l569
u7640:
	
l5926:	
	movf	(Slot_Detect@pty),w
	movwf	fsr0
		decf	(indf),w
	btfsc	status,2
	goto	u7651
	goto	u7650
u7651:
	goto	l569
u7650:
	
l5928:	
	movf	(Slot_Detect@pty),w
	movwf	fsr0
		movlw	6
	xorwf	(indf),w
	btfsc	status,2
	goto	u7661
	goto	u7660
u7661:
	goto	l569
u7660:
	line	441
	
l5930:	
;charge_mgr.c: 440: {
;charge_mgr.c: 441: g_detectLowCnt[idx] = 0;
	movf	(Slot_Detect@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	444
;charge_mgr.c: 442: }
;charge_mgr.c: 444: amb_check:
	
l569:	
	line	445
;charge_mgr.c: 445: if(*pty == 5)
	movf	(Slot_Detect@pty),w
	movwf	fsr0
		movlw	5
	xorwf	(indf),w
	btfss	status,2
	goto	u7671
	goto	u7670
u7671:
	goto	l5958
u7670:
	line	452
	
l5932:	
;charge_mgr.c: 446: {
;charge_mgr.c: 452: g_detectLowCnt[idx]++;
	movf	(Slot_Detect@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	453
;charge_mgr.c: 453: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Detect@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u7681
	goto	u7680
u7681:
	goto	l5938
u7680:
	goto	l5792
	line	457
	
l5938:	
;charge_mgr.c: 457: if(g_impCheckSlot != 0xFF && g_impCheckSlot != idx)
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u7691
	goto	u7690
u7691:
	goto	l5946
u7690:
	
l5940:	
	movf	(_g_impCheckSlot)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Detect@idx),w
	skipnz
	goto	u7701
	goto	u7700
u7701:
	goto	l5946
u7700:
	goto	l5792
	line	459
	
l5946:	
;charge_mgr.c: 459: g_impCheckSlot = idx;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Detect@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	463
	
l5948:	
;charge_mgr.c: 463: Get_Vcc();
	fcall	_Get_Vcc
	line	467
	
l5950:	
;charge_mgr.c: 467: g_impData = v | ((unsigned int)(((g_vcc_mv + 50U) / 100U) - 38U) << 12);
	movlw	064h
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(032h)
	movwf	(___lwdiv@dividend)
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_impData+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_g_impData)
	movlw	0Ch
	
u7715:
	clrc
	rlf	(_g_impData),f
	rlf	(_g_impData+1),f
	addlw	-1
	skipz
	goto	u7715
	movlw	(0A000h >> 8)
	addwf	(_g_impData+1),f
	movf	(Slot_Detect@v),w
	iorwf	(_g_impData),f
	movf	(Slot_Detect@v+1),w
	iorwf	(_g_impData+1),f
	line	468
	
l5952:	
;charge_mgr.c: 468: *pst = 8;
	movf	(Slot_Detect@pst),w
	movwf	fsr0
	movlw	low(08h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	469
	
l5954:	
;charge_mgr.c: 469: ct = 0;
	clrf	(Slot_Detect@ct)
	clrf	(Slot_Detect@ct+1)
	line	470
	
l5956:	
;charge_mgr.c: 470: g_detectLowCnt[idx] = 0;
	movf	(Slot_Detect@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	472
	
l5958:	
;charge_mgr.c: 471: }
;charge_mgr.c: 472: if(*pty == 1 || *pty == 6)
	movf	(Slot_Detect@pty),w
	movwf	fsr0
		decf	(indf),w
	btfsc	status,2
	goto	u7721
	goto	u7720
u7721:
	goto	l5962
u7720:
	
l5960:	
	movf	(Slot_Detect@pty),w
	movwf	fsr0
		movlw	6
	xorwf	(indf),w
	btfss	status,2
	goto	u7731
	goto	u7730
u7731:
	goto	l5970
u7730:
	line	475
	
l5962:	
;charge_mgr.c: 473: {
;charge_mgr.c: 475: g_detectLowCnt[idx]++;
	movf	(Slot_Detect@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	476
;charge_mgr.c: 476: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Detect@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u7741
	goto	u7740
u7741:
	goto	l5968
u7740:
	goto	l5792
	line	478
	
l5968:	
;charge_mgr.c: 478: Li_Route(idx, v, pst, &ct);
	movf	(Slot_Detect@v+1),w
	movwf	(Li_Route@v+1)
	movf	(Slot_Detect@v),w
	movwf	(Li_Route@v)
	movf	(Slot_Detect@pst),w
	movwf	(Li_Route@pst)
	movlw	(low(Slot_Detect@ct|((0x0)<<8)))&0ffh
	movwf	(Li_Route@pct)
	movf	(Slot_Detect@idx),w
	fcall	_Li_Route
	line	479
;charge_mgr.c: 479: }
	goto	l5792
	line	480
	
l5970:	
;charge_mgr.c: 480: else if(*pty == 0)
	movf	(Slot_Detect@pty),w
	movwf	fsr0
	movf	(indf),w
	btfss	status,2
	goto	u7751
	goto	u7750
u7751:
	goto	l5982
u7750:
	line	485
	
l5972:	
;charge_mgr.c: 481: {
;charge_mgr.c: 485: if(v >= 4090)
	movlw	0Fh
	subwf	(Slot_Detect@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_Detect@v),w
	skipc
	goto	u7761
	goto	u7760
u7761:
	goto	l5978
u7760:
	goto	l5792
	line	487
	
l5978:	
;charge_mgr.c: 487: *pst = 7;
	movf	(Slot_Detect@pst),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	goto	l5824
	line	490
	
l5982:	
;charge_mgr.c: 490: else if(*pty == 2 || *pty == 3)
	movf	(Slot_Detect@pty),w
	movwf	fsr0
		movlw	2
	xorwf	(indf),w
	btfsc	status,2
	goto	u7771
	goto	u7770
u7771:
	goto	l5978
u7770:
	
l5984:	
	movf	(Slot_Detect@pty),w
	movwf	fsr0
		movlw	3
	xorwf	(indf),w
	btfss	status,2
	goto	u7781
	goto	u7780
u7781:
	goto	l5792
u7780:
	goto	l5978
	line	496
	
l557:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_Detect
	__end_of_Slot_Detect:
	signat	_Slot_Detect,20602
	global	_Li_Route

;; *************** function _Li_Route *****************
;; Defined at:
;;		line 178 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  v               2   17[BANK0 ] unsigned int 
;;  pst             1   19[BANK0 ] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@st(1), 
;;  pct             1   20[BANK0 ] PTR unsigned int 
;;		 -> Slot_DiodeTest@ct(2), Slot_ImpCheck@ct(2), Slot_Detect@ct(2), 
;; Auto vars:     Size  Location     Type
;;  idx             1   35[BANK0 ] unsigned char 
;;  bat_mv_long     4   29[BANK0 ] unsigned long 
;;  vx_mv           4   25[BANK0 ] unsigned long 
;;  bat_mv          2   33[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0      11       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      19       0       0       0
;;Total ram usage:       19 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_Route_LiIon
;;		_Route_LinearLi
;;		_Slot_Detect
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=0
	line	178
global __ptext16
__ptext16:	;psect for function _Li_Route
psect	text16
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	178
	global	__size_of_Li_Route
	__size_of_Li_Route	equ	__end_of_Li_Route-_Li_Route
	
_Li_Route:	
;incstack = 0
	opt	stack 1
; Regs used in _Li_Route: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Li_Route@idx stored from wreg
	movwf	(Li_Route@idx)
	line	180
	
l5500:	
;charge_mgr.c: 180: unsigned long vx_mv = (unsigned long)(v) * 5000UL / 4096UL;
	movf	(Li_Route@v),w
	movwf	(___lmul@multiplier)
	movf	(Li_Route@v+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Li_Route@vx_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(Li_Route@vx_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(Li_Route@vx_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(Li_Route@vx_mv)

	
l5502:	
	movlw	0Ch
u6885:
	clrc
	rrf	(Li_Route@vx_mv+3),f
	rrf	(Li_Route@vx_mv+2),f
	rrf	(Li_Route@vx_mv+1),f
	rrf	(Li_Route@vx_mv),f
	addlw	-1
	skipz
	goto	u6885

	line	181
	
l5504:	
;charge_mgr.c: 181: unsigned long bat_mv_long = 124UL * vx_mv + 206UL * 5000UL;
	movf	(Li_Route@vx_mv+3),w
	movwf	(___lmul@multiplier+3)
	movf	(Li_Route@vx_mv+2),w
	movwf	(___lmul@multiplier+2)
	movf	(Li_Route@vx_mv+1),w
	movwf	(___lmul@multiplier+1)
	movf	(Li_Route@vx_mv),w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Li_Route@bat_mv_long+3)
	movf	(2+(?___lmul)),w
	movwf	(Li_Route@bat_mv_long+2)
	movf	(1+(?___lmul)),w
	movwf	(Li_Route@bat_mv_long+1)
	movf	(0+(?___lmul)),w
	movwf	(Li_Route@bat_mv_long)

	
l5506:	
	movlw	070h
	addwf	(Li_Route@bat_mv_long),f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Li_Route@bat_mv_long+1),f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Li_Route@bat_mv_long+2),f
	movlw	0
	skipnc
movlw 1
	addwf	(Li_Route@bat_mv_long+3),f
	line	182
	
l5508:	
;charge_mgr.c: 182: unsigned int bat_mv = (unsigned int)((bat_mv_long + 1000UL/2UL) / 1000UL);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Li_Route+0)+0)
	movlw	01h
	movwf	((??_Li_Route+0)+0+1)
	movlw	0
	movwf	((??_Li_Route+0)+0+2)
	movlw	0
	movwf	((??_Li_Route+0)+0+3)
	movf	(Li_Route@bat_mv_long),w
	addwf	(??_Li_Route+0)+0,f
	movf	(Li_Route@bat_mv_long+1),w
	skipnc
	incfsz	(Li_Route@bat_mv_long+1),w
	goto	u6890
	goto	u6891
u6890:
	addwf	(??_Li_Route+0)+1,f
u6891:
	movf	(Li_Route@bat_mv_long+2),w
	skipnc
	incfsz	(Li_Route@bat_mv_long+2),w
	goto	u6892
	goto	u6893
u6892:
	addwf	(??_Li_Route+0)+2,f
u6893:
	movf	(Li_Route@bat_mv_long+3),w
	skipnc
	incf	(Li_Route@bat_mv_long+3),w
	addwf	(??_Li_Route+0)+3,f
	movf	3+(??_Li_Route+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Li_Route+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Li_Route+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Li_Route+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Li_Route@bat_mv+1)
	movf	(0+(?___lldiv)),w
	movwf	(Li_Route@bat_mv)
	line	183
	
l5510:	
;charge_mgr.c: 183: if(bat_mv <= 100) {
	movlw	0
	subwf	(Li_Route@bat_mv+1),w
	movlw	065h
	skipnz
	subwf	(Li_Route@bat_mv),w
	skipnc
	goto	u6901
	goto	u6900
u6901:
	goto	l5514
u6900:
	line	184
	
l5512:	
;charge_mgr.c: 184: *pst = 2;
	movf	(Li_Route@pst),w
	movwf	fsr0
	movlw	low(02h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	185
;charge_mgr.c: 185: } else if(bat_mv < 900) {
	goto	l5540
	
l5514:	
	movlw	03h
	subwf	(Li_Route@bat_mv+1),w
	movlw	084h
	skipnz
	subwf	(Li_Route@bat_mv),w
	skipnc
	goto	u6911
	goto	u6910
u6911:
	goto	l5518
u6910:
	line	186
	
l5516:	
;charge_mgr.c: 186: *pst = 3;
	movf	(Li_Route@pst),w
	movwf	fsr0
	movlw	low(03h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	187
;charge_mgr.c: 187: } else if(bat_mv >= 1520) {
	goto	l5540
	
l5518:	
	movlw	05h
	subwf	(Li_Route@bat_mv+1),w
	movlw	0F0h
	skipnz
	subwf	(Li_Route@bat_mv),w
	skipc
	goto	u6921
	goto	u6920
u6921:
	goto	l5532
u6920:
	line	188
	
l5520:	
;charge_mgr.c: 188: if(g_ccBlocks[idx] >= 2) {
	movf	(Li_Route@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u6931
	goto	u6930
u6931:
	goto	l5524
u6930:
	line	189
	
l5522:	
;charge_mgr.c: 189: *pst = 7;
	movf	(Li_Route@pst),w
	movwf	fsr0
	movlw	low(07h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	190
;charge_mgr.c: 190: } else {
	goto	l5540
	line	191
	
l5524:	
;charge_mgr.c: 191: *pst = 5;
	movf	(Li_Route@pst),w
	movwf	fsr0
	movlw	low(05h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	192
	
l5526:	
;charge_mgr.c: 192: g_slotRefV[idx] = v;
	clrc
	rlf	(Li_Route@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Li_Route@v),w
	movwf	indf
	incf	fsr0,f
	movf	(Li_Route@v+1),w
	movwf	indf
	line	193
	
l5528:	
;charge_mgr.c: 193: g_ccBlocks[idx] = 0;
	movf	(Li_Route@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	194
	
l5530:	
;charge_mgr.c: 194: g_stableCnt[idx] = 0;
	movf	(Li_Route@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l5540
	line	197
	
l5532:	
;charge_mgr.c: 197: *pst = 4;
	movf	(Li_Route@pst),w
	movwf	fsr0
	movlw	low(04h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	198
	
l5534:	
;charge_mgr.c: 198: g_ccBlocks[idx] &= 0x80;
	movf	(Li_Route@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(080h)
	bsf	status, 7	;select IRP bank3
	andwf	indf,f
	line	202
	
l5536:	
;charge_mgr.c: 202: g_slotRefV[idx] = v;
	clrc
	rlf	(Li_Route@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Li_Route@v),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	(Li_Route@v+1),w
	movwf	indf
	goto	l5530
	line	205
	
l5540:	
;charge_mgr.c: 204: }
;charge_mgr.c: 205: *pct = 0;
	movf	(Li_Route@pct),w
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	206
	
l5542:	
;charge_mgr.c: 206: g_ovCnt[idx] = 0;
	movf	(Li_Route@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	207
	
l5544:	
;charge_mgr.c: 207: g_detectLowCnt[idx] = 0;
	movf	(Li_Route@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	208
	
l539:	
	return
	opt stack 0
GLOBAL	__end_of_Li_Route
	__end_of_Li_Route:
	signat	_Li_Route,16505
	global	_Get_Vcc

;; *************** function _Get_Vcc *****************
;; Defined at:
;;		line 60 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   17[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  2   52[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;; This function is called by:
;;		_main
;;		_Slot_Detect
;;		_Slot_ImpCheck
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=0
	line	60
global __ptext17
__ptext17:	;psect for function _Get_Vcc
psect	text17
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	60
	global	__size_of_Get_Vcc
	__size_of_Get_Vcc	equ	__end_of_Get_Vcc-_Get_Vcc
	
_Get_Vcc:	
;incstack = 0
	opt	stack 2
; Regs used in _Get_Vcc: [wreg+status,2+status,0+pclath+cstack]
	line	62
	
l5570:	
;charge_mgr.c: 62: if(0xA5 == ADC_Sample(31, 0))
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u6961
	goto	u6960
u6961:
	goto	l499
u6960:
	line	64
	
l5572:	
;charge_mgr.c: 63: {
;charge_mgr.c: 64: unsigned long pt = (4096UL * 1200UL) / adresult;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Get_Vcc@pt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Get_Vcc@pt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Get_Vcc@pt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Get_Vcc@pt)

	line	65
	
l5574:	
;charge_mgr.c: 65: g_vcc_mv = (unsigned int)pt;
	movf	(Get_Vcc@pt+1),w
	movwf	(_g_vcc_mv+1)	;volatile
	movf	(Get_Vcc@pt),w
	movwf	(_g_vcc_mv)	;volatile
	line	68
	
l499:	
	return
	opt stack 0
GLOBAL	__end_of_Get_Vcc
	__end_of_Get_Vcc:
	signat	_Get_Vcc,90
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 132 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2    2[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         2       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Detect
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=0
	line	132
global __ptext18
__ptext18:	;psect for function _Detect_BatteryType
psect	text18
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	132
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	134
	
l5578:	
;charge_mgr.c: 134: if(voltage >= 4090)
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0FAh
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u6971
	goto	u6970
u6971:
	goto	l5584
u6970:
	line	135
	
l5580:	
;charge_mgr.c: 135: return 0;
	movlw	low(0)
	goto	l523
	line	136
	
l5584:	
;charge_mgr.c: 136: if(voltage < 500)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u6981
	goto	u6980
u6981:
	goto	l5590
u6980:
	goto	l5580
	line	151
	
l5590:	
;charge_mgr.c: 151: if(voltage >= 1015 && voltage < 4090)
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u6991
	goto	u6990
u6991:
	goto	l5598
u6990:
	
l5592:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0FAh
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u7001
	goto	u7000
u7001:
	goto	l5598
u7000:
	line	152
	
l5594:	
;charge_mgr.c: 152: return 5;
	movlw	low(05h)
	goto	l523
	line	157
	
l5598:	
;charge_mgr.c: 157: if(voltage >= 500 && voltage < 4090)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u7011
	goto	u7010
u7011:
	goto	l5580
u7010:
	
l5600:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0FAh
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u7021
	goto	u7020
u7021:
	goto	l5580
u7020:
	line	158
	
l5602:	
;charge_mgr.c: 158: return 1;
	movlw	low(01h)
	line	161
	
l523:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_Slot_CV

;; *************** function _Slot_CV *****************
;; Defined at:
;;		line 983 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  pst             1    2[COMMON] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@st(1), 
;;  pty             1    3[COMMON] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@ty(1), 
;;  v               2    4[COMMON] unsigned int 
;;  ct              2    6[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1    8[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         6       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         7       4       0       0       0
;;Total ram usage:       11 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=0
	line	983
global __ptext19
__ptext19:	;psect for function _Slot_CV
psect	text19
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	983
	global	__size_of_Slot_CV
	__size_of_Slot_CV	equ	__end_of_Slot_CV-_Slot_CV
	
_Slot_CV:	
;incstack = 0
	opt	stack 4
; Regs used in _Slot_CV: [wreg-fsr0h+status,2+status,0]
;Slot_CV@idx stored from wreg
	movwf	(Slot_CV@idx)
	line	986
	
l6486:	
;charge_mgr.c: 986: ct++;
	incf	(Slot_CV@ct),f
	skipnz
	incf	(Slot_CV@ct+1),f
	line	987
	
l6488:	
;charge_mgr.c: 987: if(ct > ((unsigned long)(600) * 16))
	movlw	025h
	subwf	(Slot_CV@ct+1),w
	movlw	081h
	skipnz
	subwf	(Slot_CV@ct),w
	skipc
	goto	u8661
	goto	u8660
u8661:
	goto	l6492
u8660:
	line	988
	
l6490:	
;charge_mgr.c: 988: *pst = 6;
	movf	(Slot_CV@pst),w
	movwf	fsr0
	movlw	low(06h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	996
	
l6492:	
;charge_mgr.c: 996: if(v >= 4090 && *pty == 6)
	movlw	0Fh
	subwf	(Slot_CV@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_CV@v),w
	skipc
	goto	u8671
	goto	u8670
u8671:
	goto	l6500
u8670:
	
l6494:	
	movf	(Slot_CV@pty),w
	movwf	fsr0
		movlw	6
	bcf	status, 7	;select IRP bank0
	xorwf	(indf),w
	btfss	status,2
	goto	u8681
	goto	u8680
u8681:
	goto	l6500
u8680:
	line	997
	
l6496:	
;charge_mgr.c: 997: return ct;
	movf	(Slot_CV@ct+1),w
	movwf	(?_Slot_CV+1)
	movf	(Slot_CV@ct),w
	movwf	(?_Slot_CV)
	goto	l693
	line	1008
	
l6500:	
;charge_mgr.c: 1008: if(v < 4090 && ct <= ((unsigned long)(60) * 16) && *pty == 1)
	movlw	0Fh
	subwf	(Slot_CV@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_CV@v),w
	skipnc
	goto	u8691
	goto	u8690
u8691:
	goto	l6526
u8690:
	
l6502:	
	movlw	03h
	subwf	(Slot_CV@ct+1),w
	movlw	0C1h
	skipnz
	subwf	(Slot_CV@ct),w
	skipnc
	goto	u8701
	goto	u8700
u8701:
	goto	l6526
u8700:
	
l6504:	
	movf	(Slot_CV@pty),w
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
		decf	(indf),w
	btfss	status,2
	goto	u8711
	goto	u8710
u8711:
	goto	l6526
u8710:
	line	1010
	
l6506:	
;charge_mgr.c: 1009: {
;charge_mgr.c: 1010: if(g_ccBlocks[idx] == 0)
	movf	(Slot_CV@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfss	status,2
	goto	u8721
	goto	u8720
u8721:
	goto	l6510
u8720:
	line	1012
	
l6508:	
;charge_mgr.c: 1011: {
;charge_mgr.c: 1012: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_CV@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_CV@v),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	(Slot_CV@v+1),w
	movwf	indf
	line	1013
;charge_mgr.c: 1013: g_ccBlocks[idx] = 1;
	movf	(Slot_CV@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	indf,f
	line	1014
;charge_mgr.c: 1014: }
	goto	l6526
	line	1015
	
l6510:	
;charge_mgr.c: 1015: else if(v >= g_slotRefV[idx] + (50))
	clrc
	rlf	(Slot_CV@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Slot_CV+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_CV+0)+0+1
	movf	0+(??_Slot_CV+0)+0,w
	addlw	low(032h)
	movwf	(??_Slot_CV+2)+0
	movf	1+(??_Slot_CV+0)+0,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_CV+2)+0
	movf	1+(??_Slot_CV+2)+0,w
	subwf	(Slot_CV@v+1),w
	skipz
	goto	u8735
	movf	0+(??_Slot_CV+2)+0,w
	subwf	(Slot_CV@v),w
u8735:
	skipc
	goto	u8731
	goto	u8730
u8731:
	goto	l6524
u8730:
	line	1017
	
l6512:	
;charge_mgr.c: 1016: {
;charge_mgr.c: 1017: if(++g_stableCnt[idx] >= 3)
	movf	(Slot_CV@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	movlw	low(03h)
	subwf	(indf),w
	skipc
	goto	u8741
	goto	u8740
u8741:
	goto	l696
u8740:
	line	1019
	
l6514:	
;charge_mgr.c: 1018: {
;charge_mgr.c: 1019: g_stableCnt[idx] = 0;
	movf	(Slot_CV@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1020
	
l6516:	
;charge_mgr.c: 1020: *pst = 7;
	movf	(Slot_CV@pst),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	1021
	
l6518:	
	line	1022
	
l6520:	
;charge_mgr.c: 1022: return ct;
	clrf	(?_Slot_CV)
	clrf	(?_Slot_CV+1)
	goto	l693
	line	1027
	
l6524:	
;charge_mgr.c: 1025: else
;charge_mgr.c: 1026: {
;charge_mgr.c: 1027: g_stableCnt[idx] = 0;
	movf	(Slot_CV@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6526
	line	1028
	
l696:	
	line	1036
	
l6526:	
;charge_mgr.c: 1028: }
;charge_mgr.c: 1029: }
;charge_mgr.c: 1036: if(v >= 4090)
	movlw	0Fh
	subwf	(Slot_CV@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_CV@v),w
	skipc
	goto	u8751
	goto	u8750
u8751:
	goto	l6570
u8750:
	line	1038
	
l6528:	
;charge_mgr.c: 1037: {
;charge_mgr.c: 1038: if(*pty == 1)
	movf	(Slot_CV@pty),w
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
		decf	(indf),w
	btfss	status,2
	goto	u8761
	goto	u8760
u8761:
	goto	l6546
u8760:
	line	1040
	
l6530:	
;charge_mgr.c: 1039: {
;charge_mgr.c: 1040: g_detectLowCnt[idx]++;
	movf	(Slot_CV@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	1041
;charge_mgr.c: 1041: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_CV@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8771
	goto	u8770
u8771:
	goto	l6536
u8770:
	goto	l6496
	line	1043
	
l6536:	
;charge_mgr.c: 1043: g_detectLowCnt[idx] = 0;
	movf	(Slot_CV@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1044
	
l6538:	
;charge_mgr.c: 1044: *pst = 6;
	movf	(Slot_CV@pst),w
	movwf	fsr0
	movlw	low(06h)
	movwf	indf
	goto	l6518
	line	1048
	
l6546:	
;charge_mgr.c: 1047: }
;charge_mgr.c: 1048: if(*pty == 6)
	movf	(Slot_CV@pty),w
	movwf	fsr0
		movlw	6
	xorwf	(indf),w
	btfss	status,2
	goto	u8781
	goto	u8780
u8781:
	goto	l6552
u8780:
	goto	l6496
	line	1053
	
l6552:	
;charge_mgr.c: 1052: }
;charge_mgr.c: 1053: g_detectLowCnt[idx]++;
	movf	(Slot_CV@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	1054
;charge_mgr.c: 1054: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_CV@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8791
	goto	u8790
u8791:
	goto	l6558
u8790:
	goto	l6496
	line	1056
	
l6558:	
;charge_mgr.c: 1056: g_detectLowCnt[idx] = 0;
	movf	(Slot_CV@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1057
	
l6560:	
;charge_mgr.c: 1057: *pty = 0;
	movf	(Slot_CV@pty),w
	movwf	fsr0
	clrf	indf
	line	1058
	
l6562:	
;charge_mgr.c: 1058: *pst = 0;
	movf	(Slot_CV@pst),w
	movwf	fsr0
	clrf	indf
	goto	l6518
	line	1069
	
l6570:	
;charge_mgr.c: 1061: }
;charge_mgr.c: 1069: if(*pty == 6)
	movf	(Slot_CV@pty),w
	movwf	fsr0
		movlw	6
	bcf	status, 7	;select IRP bank0
	xorwf	(indf),w
	btfss	status,2
	goto	u8801
	goto	u8800
u8801:
	goto	l6588
u8800:
	line	1071
	
l6572:	
;charge_mgr.c: 1070: {
;charge_mgr.c: 1071: if(v < 2000U)
	movlw	07h
	subwf	(Slot_CV@v+1),w
	movlw	0D0h
	skipnz
	subwf	(Slot_CV@v),w
	skipnc
	goto	u8811
	goto	u8810
u8811:
	goto	l6586
u8810:
	line	1073
	
l6574:	
;charge_mgr.c: 1072: {
;charge_mgr.c: 1073: g_detectLowCnt[idx]++;
	movf	(Slot_CV@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	1074
;charge_mgr.c: 1074: if(g_detectLowCnt[idx] >= ((unsigned long)(3) * 16))
	movf	(Slot_CV@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(030h)
	subwf	indf,w
	skipc
	goto	u8821
	goto	u8820
u8821:
	goto	l6608
u8820:
	line	1076
	
l6576:	
;charge_mgr.c: 1075: {
;charge_mgr.c: 1076: g_detectLowCnt[idx] = 0;
	movf	(Slot_CV@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6516
	line	1084
	
l6586:	
;charge_mgr.c: 1082: else
;charge_mgr.c: 1083: {
;charge_mgr.c: 1084: g_detectLowCnt[idx] = 0;
	movf	(Slot_CV@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6608
	line	1089
	
l6588:	
;charge_mgr.c: 1087: else
;charge_mgr.c: 1088: {
;charge_mgr.c: 1089: if(v < g_slotRefV[idx] && g_slotRefV[idx] - v > 500)
	clrc
	rlf	(Slot_CV@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_CV+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_CV+0)+0+1
	movf	1+(??_Slot_CV+0)+0,w
	subwf	(Slot_CV@v+1),w
	skipz
	goto	u8835
	movf	0+(??_Slot_CV+0)+0,w
	subwf	(Slot_CV@v),w
u8835:
	skipnc
	goto	u8831
	goto	u8830
u8831:
	goto	l6586
u8830:
	
l6590:	
	clrc
	rlf	(Slot_CV@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_CV+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_CV+0)+0+1
	movf	(Slot_CV@v),w
	subwf	0+(??_Slot_CV+0)+0,w
	movwf	(??_Slot_CV+2)+0
	movf	(Slot_CV@v+1),w
	skipc
	incf	(Slot_CV@v+1),w
	subwf	1+(??_Slot_CV+0)+0,w
	movwf	1+(??_Slot_CV+2)+0
	movlw	01h
	subwf	1+(??_Slot_CV+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_CV+2)+0,w
	skipc
	goto	u8841
	goto	u8840
u8841:
	goto	l6586
u8840:
	line	1091
	
l6592:	
;charge_mgr.c: 1090: {
;charge_mgr.c: 1091: g_detectLowCnt[idx]++;
	movf	(Slot_CV@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	1092
;charge_mgr.c: 1092: if(g_detectLowCnt[idx] >= 2)
	movf	(Slot_CV@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipc
	goto	u8851
	goto	u8850
u8851:
	goto	l6608
u8850:
	line	1094
	
l6594:	
;charge_mgr.c: 1093: {
;charge_mgr.c: 1094: g_detectLowCnt[idx] = 0;
	movf	(Slot_CV@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1095
;charge_mgr.c: 1095: g_ccBlocks[idx]++;
	movf	(Slot_CV@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1098
	
l6596:	
;charge_mgr.c: 1098: *pty = 0;
	movf	(Slot_CV@pty),w
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	clrf	indf
	line	1099
	
l6598:	
;charge_mgr.c: 1099: *pst = 1;
	movf	(Slot_CV@pst),w
	movwf	fsr0
	clrf	indf
	incf	indf,f
	goto	l6518
	line	1114
	
l6608:	
;charge_mgr.c: 1107: }
;charge_mgr.c: 1108: }
;charge_mgr.c: 1114: if(v >= 3850 && *pty == 1)
	movlw	0Fh
	subwf	(Slot_CV@v+1),w
	movlw	0Ah
	skipnz
	subwf	(Slot_CV@v),w
	skipc
	goto	u8861
	goto	u8860
u8861:
	goto	l6620
u8860:
	
l6610:	
	movf	(Slot_CV@pty),w
	movwf	fsr0
		decf	(indf),w
	btfss	status,2
	goto	u8871
	goto	u8870
u8871:
	goto	l6620
u8870:
	line	1116
	
l6612:	
;charge_mgr.c: 1115: {
;charge_mgr.c: 1116: g_ovCnt[idx]++;
	movf	(Slot_CV@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1117
;charge_mgr.c: 1117: if(g_ovCnt[idx] >= 5)
	movf	(Slot_CV@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u8881
	goto	u8880
u8881:
	goto	l6496
u8880:
	line	1119
	
l6614:	
;charge_mgr.c: 1118: {
;charge_mgr.c: 1119: *pst = 7;
	movf	(Slot_CV@pst),w
	movwf	fsr0
	movlw	low(07h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	goto	l6496
	line	1125
	
l6620:	
;charge_mgr.c: 1123: else
;charge_mgr.c: 1124: {
;charge_mgr.c: 1125: g_ovCnt[idx] = 0;
	movf	(Slot_CV@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6496
	line	1128
	
l693:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_CV
	__end_of_Slot_CV:
	signat	_Slot_CV,20602
	global	_Slot_CC

;; *************** function _Slot_CC *****************
;; Defined at:
;;		line 797 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  pst             1    2[COMMON] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@st(1), 
;;  ty              1    3[COMMON] unsigned char 
;;  v               2    4[COMMON] unsigned int 
;;  ct              2    6[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1    8[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         6       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         7       4       0       0       0
;;Total ram usage:       11 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	line	797
global __ptext20
__ptext20:	;psect for function _Slot_CC
psect	text20
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	797
	global	__size_of_Slot_CC
	__size_of_Slot_CC	equ	__end_of_Slot_CC-_Slot_CC
	
_Slot_CC:	
;incstack = 0
	opt	stack 4
; Regs used in _Slot_CC: [wreg-fsr0h+status,2+status,0]
;Slot_CC@idx stored from wreg
	movwf	(Slot_CC@idx)
	line	800
	
l6312:	
;charge_mgr.c: 800: ct++;
	incf	(Slot_CC@ct),f
	skipnz
	incf	(Slot_CC@ct+1),f
	line	801
	
l6314:	
;charge_mgr.c: 801: if(ct >= ((unsigned long)(600) * 16))
	movlw	025h
	subwf	(Slot_CC@ct+1),w
	movlw	080h
	skipnz
	subwf	(Slot_CC@ct),w
	skipc
	goto	u8351
	goto	u8350
u8351:
	goto	l6320
u8350:
	line	803
	
l6316:	
;charge_mgr.c: 802: {
;charge_mgr.c: 803: ct -= ((unsigned long)(600) * 16);
	movlw	080h
	subwf	(Slot_CC@ct),f
	movlw	025h
	skipc
	decf	(Slot_CC@ct+1),f
	subwf	(Slot_CC@ct+1),f
	line	804
	
l6318:	
;charge_mgr.c: 804: g_ccBlocks[idx]++;
	movf	(Slot_CC@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	806
	
l6320:	
;charge_mgr.c: 805: }
;charge_mgr.c: 806: if(g_ccBlocks[idx] >= 18)
	movf	(Slot_CC@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(012h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u8361
	goto	u8360
u8361:
	goto	l6328
u8360:
	line	808
	
l6322:	
;charge_mgr.c: 807: {
;charge_mgr.c: 808: *pst = 7;
	movf	(Slot_CC@pst),w
	movwf	fsr0
	movlw	low(07h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	809
	
l6324:	
;charge_mgr.c: 809: return ct;
	movf	(Slot_CC@ct+1),w
	movwf	(?_Slot_CC+1)
	movf	(Slot_CC@ct),w
	movwf	(?_Slot_CC)
	goto	l652
	line	815
	
l6328:	
;charge_mgr.c: 810: }
;charge_mgr.c: 815: if(v >= 4090 && ty == 6)
	movlw	0Fh
	subwf	(Slot_CC@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_CC@v),w
	skipc
	goto	u8371
	goto	u8370
u8371:
	goto	l6334
u8370:
	
l6330:	
		movlw	6
	xorwf	((Slot_CC@ty)),w
	btfss	status,2
	goto	u8381
	goto	u8380
u8381:
	goto	l6334
u8380:
	goto	l6342
	line	819
	
l6334:	
;charge_mgr.c: 819: else if(ct <= ((unsigned long)(60) * 16))
	movlw	03h
	subwf	(Slot_CC@ct+1),w
	movlw	0C1h
	skipnz
	subwf	(Slot_CC@ct),w
	skipnc
	goto	u8391
	goto	u8390
u8391:
	goto	l6338
u8390:
	goto	l6342
	line	829
	
l6338:	
;charge_mgr.c: 827: else
;charge_mgr.c: 828: {
;charge_mgr.c: 829: if(v > g_slotRefV[idx]) g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_CC@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Slot_CC+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_CC+0)+0+1
	movf	(Slot_CC@v+1),w
	subwf	1+(??_Slot_CC+0)+0,w
	skipz
	goto	u8405
	movf	(Slot_CC@v),w
	subwf	0+(??_Slot_CC+0)+0,w
u8405:
	skipnc
	goto	u8401
	goto	u8400
u8401:
	goto	l6342
u8400:
	
l6340:	
	clrc
	rlf	(Slot_CC@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_CC@v),w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_CC@v+1),w
	movwf	indf
	line	838
	
l6342:	
;charge_mgr.c: 830: }
;charge_mgr.c: 838: if(ty == 6)
		movlw	6
	xorwf	((Slot_CC@ty)),w
	btfss	status,2
	goto	u8411
	goto	u8410
u8411:
	goto	l6400
u8410:
	line	840
	
l6344:	
;charge_mgr.c: 839: {
;charge_mgr.c: 840: if(v < 2000U)
	movlw	07h
	subwf	(Slot_CC@v+1),w
	movlw	0D0h
	skipnz
	subwf	(Slot_CC@v),w
	skipnc
	goto	u8421
	goto	u8420
u8421:
	goto	l6358
u8420:
	line	842
	
l6346:	
;charge_mgr.c: 841: {
;charge_mgr.c: 842: g_detectLowCnt[idx]++;
	movf	(Slot_CC@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	843
;charge_mgr.c: 843: if(g_detectLowCnt[idx] >= ((unsigned long)(3) * 16))
	movf	(Slot_CC@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(030h)
	subwf	indf,w
	skipc
	goto	u8431
	goto	u8430
u8431:
	goto	l6360
u8430:
	line	845
	
l6348:	
;charge_mgr.c: 844: {
;charge_mgr.c: 845: g_detectLowCnt[idx] = 0;
	movf	(Slot_CC@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	846
	
l6350:	
;charge_mgr.c: 846: *pst = 7;
	movf	(Slot_CC@pst),w
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	847
	
l6352:	
	line	848
	
l6354:	
;charge_mgr.c: 848: return ct;
	clrf	(?_Slot_CC)
	clrf	(?_Slot_CC+1)
	goto	l652
	line	853
	
l6358:	
;charge_mgr.c: 851: else
;charge_mgr.c: 852: {
;charge_mgr.c: 853: g_detectLowCnt[idx] = 0;
	movf	(Slot_CC@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	870
	
l6360:	
;charge_mgr.c: 854: }
;charge_mgr.c: 870: if(ct >= ((unsigned long)(16) * 16))
	movlw	01h
	subwf	(Slot_CC@ct+1),w
	movlw	0
	skipnz
	subwf	(Slot_CC@ct),w
	skipc
	goto	u8441
	goto	u8440
u8441:
	goto	l6444
u8440:
	line	872
	
l6362:	
	line	873
	
l6364:	
;charge_mgr.c: 873: if(v >= 2800U && v < 4090)
	movlw	0Ah
	subwf	(Slot_CC@v+1),w
	movlw	0F0h
	skipnz
	subwf	(Slot_CC@v),w
	skipc
	goto	u8451
	goto	u8450
u8451:
	goto	l6376
u8450:
	
l6366:	
	movlw	0Fh
	subwf	(Slot_CC@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_CC@v),w
	skipnc
	goto	u8461
	goto	u8460
u8461:
	goto	l6376
u8460:
	line	875
	
l6368:	
;charge_mgr.c: 874: {
;charge_mgr.c: 875: *pst = 5;
	movf	(Slot_CC@pst),w
	movwf	fsr0
	movlw	low(05h)
	movwf	indf
	line	876
	
l6370:	
;charge_mgr.c: 876: g_ccBlocks[idx] = 0;
	movf	(Slot_CC@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	877
	
l6372:	
;charge_mgr.c: 877: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_CC@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_CC@v),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	(Slot_CC@v+1),w
	movwf	indf
	line	878
	
l6374:	
;charge_mgr.c: 878: g_stableCnt[idx] = 0;
	movf	(Slot_CC@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	879
;charge_mgr.c: 879: }
	goto	l6354
	line	880
	
l6376:	
;charge_mgr.c: 880: else if(v >= g_slotRefV[idx] + (30))
	clrc
	rlf	(Slot_CC@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_CC+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_CC+0)+0+1
	movf	0+(??_Slot_CC+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_CC+2)+0
	movf	1+(??_Slot_CC+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_CC+2)+0
	movf	1+(??_Slot_CC+2)+0,w
	subwf	(Slot_CC@v+1),w
	skipz
	goto	u8475
	movf	0+(??_Slot_CC+2)+0,w
	subwf	(Slot_CC@v),w
u8475:
	skipc
	goto	u8471
	goto	u8470
u8471:
	goto	l6380
u8470:
	line	882
	
l6378:	
;charge_mgr.c: 881: {
;charge_mgr.c: 882: g_stableCnt[idx] = 1;
	movf	(Slot_CC@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	883
;charge_mgr.c: 883: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_CC@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_CC@v),w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_CC@v+1),w
	movwf	indf
	line	884
;charge_mgr.c: 884: }
	goto	l6354
	line	885
	
l6380:	
;charge_mgr.c: 885: else if(g_stableCnt[idx] != 0)
	movf	(Slot_CC@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(indf),w
	btfsc	status,2
	goto	u8481
	goto	u8480
u8481:
	goto	l6384
u8480:
	line	887
	
l6382:	
;charge_mgr.c: 886: {
;charge_mgr.c: 887: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_CC@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_CC@v),w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_CC@v+1),w
	movwf	indf
	line	888
;charge_mgr.c: 888: }
	goto	l6354
	line	889
	
l6384:	
;charge_mgr.c: 889: else if(g_ccBlocks[idx] & 0x80)
	movf	(Slot_CC@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	btfss	indf,(7)&7
	goto	u8491
	goto	u8490
u8491:
	goto	l6388
u8490:
	line	891
	
l6386:	
;charge_mgr.c: 890: {
;charge_mgr.c: 891: *pst = 7;
	movf	(Slot_CC@pst),w
	movwf	fsr0
	movlw	low(07h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	892
;charge_mgr.c: 892: }
	goto	l6354
	line	895
	
l6388:	
;charge_mgr.c: 893: else
;charge_mgr.c: 894: {
;charge_mgr.c: 895: g_ccBlocks[idx] |= 0x80;
	movf	(Slot_CC@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(7/8),(7)&7
	line	896
	
l6390:	
;charge_mgr.c: 896: *pst = 1;
	movf	(Slot_CC@pst),w
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	clrf	indf
	incf	indf,f
	line	897
	
l6392:	
;charge_mgr.c: 897: g_slotRefV[idx] = 0;
	clrc
	rlf	(Slot_CC@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l6374
	line	907
	
l6400:	
;charge_mgr.c: 903: else
;charge_mgr.c: 904: {
;charge_mgr.c: 907: if((v < g_slotRefV[idx] && g_slotRefV[idx] - v > 500) || v < 2000U)
	clrc
	rlf	(Slot_CC@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Slot_CC+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_CC+0)+0+1
	movf	1+(??_Slot_CC+0)+0,w
	subwf	(Slot_CC@v+1),w
	skipz
	goto	u8505
	movf	0+(??_Slot_CC+0)+0,w
	subwf	(Slot_CC@v),w
u8505:
	skipnc
	goto	u8501
	goto	u8500
u8501:
	goto	l6404
u8500:
	
l6402:	
	clrc
	rlf	(Slot_CC@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_CC+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_CC+0)+0+1
	movf	(Slot_CC@v),w
	subwf	0+(??_Slot_CC+0)+0,w
	movwf	(??_Slot_CC+2)+0
	movf	(Slot_CC@v+1),w
	skipc
	incf	(Slot_CC@v+1),w
	subwf	1+(??_Slot_CC+0)+0,w
	movwf	1+(??_Slot_CC+2)+0
	movlw	01h
	subwf	1+(??_Slot_CC+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_CC+2)+0,w
	skipnc
	goto	u8511
	goto	u8510
u8511:
	goto	l6406
u8510:
	
l6404:	
	movlw	07h
	subwf	(Slot_CC@v+1),w
	movlw	0D0h
	skipnz
	subwf	(Slot_CC@v),w
	skipnc
	goto	u8521
	goto	u8520
u8521:
	goto	l6424
u8520:
	line	909
	
l6406:	
;charge_mgr.c: 908: {
;charge_mgr.c: 909: g_detectLowCnt[idx]++;
	movf	(Slot_CC@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	910
;charge_mgr.c: 910: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_CC@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8531
	goto	u8530
u8531:
	goto	l6412
u8530:
	goto	l6324
	line	912
	
l6412:	
;charge_mgr.c: 912: g_detectLowCnt[idx] = 0;
	movf	(Slot_CC@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	913
	
l6414:	
;charge_mgr.c: 913: *pst = 1;
	movf	(Slot_CC@pst),w
	movwf	fsr0
	clrf	indf
	incf	indf,f
	goto	l6352
	line	919
	
l6424:	
;charge_mgr.c: 917: else
;charge_mgr.c: 918: {
;charge_mgr.c: 919: g_detectLowCnt[idx] = 0;
	movf	(Slot_CC@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	930
	
l6426:	
;charge_mgr.c: 920: }
;charge_mgr.c: 930: if(ct <= ((unsigned long)(60) * 16))
	movlw	03h
	subwf	(Slot_CC@ct+1),w
	movlw	0C1h
	skipnz
	subwf	(Slot_CC@ct),w
	skipnc
	goto	u8541
	goto	u8540
u8541:
	goto	l6432
u8540:
	line	932
	
l6428:	
;charge_mgr.c: 931: {
;charge_mgr.c: 932: if(v >= g_slotRefV[idx] + (30))
	clrc
	rlf	(Slot_CC@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_CC+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_CC+0)+0+1
	movf	0+(??_Slot_CC+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_CC+2)+0
	movf	1+(??_Slot_CC+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_CC+2)+0
	movf	1+(??_Slot_CC+2)+0,w
	subwf	(Slot_CC@v+1),w
	skipz
	goto	u8555
	movf	0+(??_Slot_CC+2)+0,w
	subwf	(Slot_CC@v),w
u8555:
	skipc
	goto	u8551
	goto	u8550
u8551:
	goto	l6432
u8550:
	line	933
	
l6430:	
;charge_mgr.c: 933: g_stableCnt[idx] = 1;
	movf	(Slot_CC@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	935
	
l6432:	
;charge_mgr.c: 934: }
;charge_mgr.c: 935: if(ct > ((unsigned long)(60) * 16) && g_stableCnt[idx] == 0)
	movlw	03h
	subwf	(Slot_CC@ct+1),w
	movlw	0C1h
	skipnz
	subwf	(Slot_CC@ct),w
	skipc
	goto	u8561
	goto	u8560
u8561:
	goto	l6444
u8560:
	
l6434:	
	movf	(Slot_CC@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(indf),w
	btfss	status,2
	goto	u8571
	goto	u8570
u8571:
	goto	l6444
u8570:
	goto	l6350
	line	949
	
l6444:	
;charge_mgr.c: 940: }
;charge_mgr.c: 941: }
;charge_mgr.c: 949: if(v >= 4090 && ty == 1)
	movlw	0Fh
	subwf	(Slot_CC@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_CC@v),w
	skipc
	goto	u8581
	goto	u8580
u8581:
	goto	l6456
u8580:
	
l6446:	
		decf	((Slot_CC@ty)),w
	btfss	status,2
	goto	u8591
	goto	u8590
u8591:
	goto	l6456
u8590:
	line	951
	
l6448:	
;charge_mgr.c: 950: {
;charge_mgr.c: 951: *pst = 6;
	movf	(Slot_CC@pst),w
	movwf	fsr0
	movlw	low(06h)
	movwf	indf
	goto	l6352
	line	959
	
l6456:	
;charge_mgr.c: 954: }
;charge_mgr.c: 959: if(v >= 3850 && ty != 6)
	movlw	0Fh
	subwf	(Slot_CC@v+1),w
	movlw	0Ah
	skipnz
	subwf	(Slot_CC@v),w
	skipc
	goto	u8601
	goto	u8600
u8601:
	goto	l6468
u8600:
	
l6458:	
		movlw	6
	xorwf	((Slot_CC@ty)),w
	btfsc	status,2
	goto	u8611
	goto	u8610
u8611:
	goto	l6468
u8610:
	line	961
	
l6460:	
;charge_mgr.c: 960: {
;charge_mgr.c: 961: g_ovCnt[idx]++;
	movf	(Slot_CC@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	962
;charge_mgr.c: 962: if(g_ovCnt[idx] >= 5)
	movf	(Slot_CC@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u8621
	goto	u8620
u8621:
	goto	l6324
u8620:
	goto	l6322
	line	970
	
l6468:	
;charge_mgr.c: 968: else
;charge_mgr.c: 969: {
;charge_mgr.c: 970: g_ovCnt[idx] = 0;
	movf	(Slot_CC@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	972
	
l6470:	
;charge_mgr.c: 972: if(v >= 3100 && !(v >= 4090 && ty == 6))
	movlw	0Ch
	subwf	(Slot_CC@v+1),w
	movlw	01Ch
	skipnz
	subwf	(Slot_CC@v),w
	skipc
	goto	u8631
	goto	u8630
u8631:
	goto	l6324
u8630:
	
l6472:	
	movlw	0Fh
	subwf	(Slot_CC@v+1),w
	movlw	0FAh
	skipnz
	subwf	(Slot_CC@v),w
	skipc
	goto	u8641
	goto	u8640
u8641:
	goto	l6476
u8640:
	
l6474:	
		movlw	6
	xorwf	((Slot_CC@ty)),w
	btfsc	status,2
	goto	u8651
	goto	u8650
u8651:
	goto	l6324
u8650:
	line	974
	
l6476:	
;charge_mgr.c: 973: {
;charge_mgr.c: 974: *pst = 5;
	movf	(Slot_CC@pst),w
	movwf	fsr0
	movlw	low(05h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	975
	
l6478:	
;charge_mgr.c: 975: ct = 0;
	clrf	(Slot_CC@ct)
	clrf	(Slot_CC@ct+1)
	line	976
	
l6480:	
;charge_mgr.c: 976: g_ccBlocks[idx] = 0;
	movf	(Slot_CC@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6324
	line	980
	
l652:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_CC
	__end_of_Slot_CC:
	signat	_Slot_CC,20602
	global	_Slot_Activate

;; *************** function _Slot_Activate *****************
;; Defined at:
;;		line 740 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  1532            1    wreg     unsigned char 
;;  pst             1    2[COMMON] PTR unsigned char 
;;		 -> Slot_Charge_Ctrl@st(1), 
;;  v               2    3[COMMON] unsigned int 
;;  ct              2    5[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  1532            1    0[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         5       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	line	740
global __ptext21
__ptext21:	;psect for function _Slot_Activate
psect	text21
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	740
	global	__size_of_Slot_Activate
	__size_of_Slot_Activate	equ	__end_of_Slot_Activate-_Slot_Activate
	
_Slot_Activate:	
;incstack = 0
	opt	stack 4
; Regs used in _Slot_Activate: [wreg-fsr0h+status,2+status,0]
	line	742
	
l6240:	
;charge_mgr.c: 742: ct++;
	incf	(Slot_Activate@ct),f
	skipnz
	incf	(Slot_Activate@ct+1),f
	line	743
	
l6242:	
;charge_mgr.c: 743: if(ct > ((unsigned long)(60) * 16))
	movlw	03h
	subwf	(Slot_Activate@ct+1),w
	movlw	0C1h
	skipnz
	subwf	(Slot_Activate@ct),w
	skipc
	goto	u8281
	goto	u8280
u8281:
	goto	l6250
u8280:
	line	745
	
l6244:	
;charge_mgr.c: 744: {
;charge_mgr.c: 745: *pst = 7;
	movf	(Slot_Activate@pst),w
	movwf	fsr0
	movlw	low(07h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	746
	
l6246:	
;charge_mgr.c: 746: return ct;
	movf	(Slot_Activate@ct+1),w
	movwf	(?_Slot_Activate+1)
	movf	(Slot_Activate@ct),w
	movwf	(?_Slot_Activate)
	goto	l637
	line	748
	
l6250:	
;charge_mgr.c: 747: }
;charge_mgr.c: 748: if(v > 750)
	movlw	02h
	subwf	(Slot_Activate@v+1),w
	movlw	0EFh
	skipnz
	subwf	(Slot_Activate@v),w
	skipc
	goto	u8291
	goto	u8290
u8291:
	goto	l6260
u8290:
	line	750
	
l6252:	
;charge_mgr.c: 749: {
;charge_mgr.c: 750: *pst = 3;
	movf	(Slot_Activate@pst),w
	movwf	fsr0
	movlw	low(03h)
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	751
	
l6254:	
	line	752
	
l6256:	
;charge_mgr.c: 752: return ct;
	clrf	(?_Slot_Activate)
	clrf	(?_Slot_Activate+1)
	goto	l637
	line	754
	
l6260:	
;charge_mgr.c: 753: }
;charge_mgr.c: 754: if(v >= 3850)
	movlw	0Fh
	subwf	(Slot_Activate@v+1),w
	movlw	0Ah
	skipnz
	subwf	(Slot_Activate@v),w
	skipc
	goto	u8301
	goto	u8300
u8301:
	goto	l6246
u8300:
	goto	l6244
	line	760
	
l637:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_Activate
	__end_of_Slot_Activate:
	signat	_Slot_Activate,16506
	global	_Adc_Norm

;; *************** function _Adc_Norm *****************
;; Defined at:
;;		line 82 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  ch              1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  ch              1   20[BANK0 ] unsigned char 
;;  norm            4   23[BANK0 ] unsigned long 
;;  raw             2   21[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   17[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       3       0       0       0
;;      Locals:         0       7       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      10       0       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	line	82
global __ptext22
__ptext22:	;psect for function _Adc_Norm
psect	text22
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	82
	global	__size_of_Adc_Norm
	__size_of_Adc_Norm	equ	__end_of_Adc_Norm-_Adc_Norm
	
_Adc_Norm:	
;incstack = 0
	opt	stack 3
; Regs used in _Adc_Norm: [wreg+status,2+status,0+pclath+cstack]
;Adc_Norm@ch stored from wreg
	movwf	(Adc_Norm@ch)
	line	87
	
l5732:	
;charge_mgr.c: 84: unsigned int raw;
;charge_mgr.c: 85: unsigned long norm;
;charge_mgr.c: 87: if(0xA5 != ADC_Sample(ch, 0))
	clrf	(ADC_Sample@adldo)
	movf	(Adc_Norm@ch),w
	fcall	_ADC_Sample
	xorlw	0A5h
	skipnz
	goto	u7191
	goto	u7190
u7191:
	goto	l5738
u7190:
	line	88
	
l5734:	
;charge_mgr.c: 88: return 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(?_Adc_Norm)
	clrf	(?_Adc_Norm+1)
	goto	l503
	line	89
	
l5738:	
;charge_mgr.c: 89: raw = adresult;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Adc_Norm@raw+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Adc_Norm@raw)
	line	90
	
l5740:	
;charge_mgr.c: 90: if(g_vcc_mv == 0)
	movf	((_g_vcc_mv)),w	;volatile
iorwf	((_g_vcc_mv+1)),w	;volatile
	btfss	status,2
	goto	u7201
	goto	u7200
u7201:
	goto	l5746
u7200:
	line	91
	
l5742:	
;charge_mgr.c: 91: return raw;
	movf	(Adc_Norm@raw+1),w
	movwf	(?_Adc_Norm+1)
	movf	(Adc_Norm@raw),w
	movwf	(?_Adc_Norm)
	goto	l503
	line	93
	
l5746:	
;charge_mgr.c: 93: norm = (unsigned long)raw * g_vcc_mv / 5000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	movf	(Adc_Norm@raw),w
	movwf	(___lmul@multiplier)
	movf	(Adc_Norm@raw+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movf	(_g_vcc_mv),w	;volatile
	movwf	(___lmul@multiplicand)
	movf	(_g_vcc_mv+1),w	;volatile
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Adc_Norm@norm+3)
	movf	(2+(?___lldiv)),w
	movwf	(Adc_Norm@norm+2)
	movf	(1+(?___lldiv)),w
	movwf	(Adc_Norm@norm+1)
	movf	(0+(?___lldiv)),w
	movwf	(Adc_Norm@norm)

	line	94
	
l5748:	
;charge_mgr.c: 94: if(norm > 4095UL)
		movf	(Adc_Norm@norm+3),w
	btfss	status,2
	goto	u7210
	movf	(Adc_Norm@norm+2),w
	btfss	status,2
	goto	u7210
	movlw	16
	subwf	(Adc_Norm@norm+1),w
	skipz
	goto	u7213
	movlw	0
	subwf	(Adc_Norm@norm),w
	skipz
	goto	u7213
u7213:
	btfss	status,0
	goto	u7211
	goto	u7210

u7211:
	goto	l505
u7210:
	line	95
	
l5750:	
;charge_mgr.c: 95: norm = 4095UL;
	movlw	0
	movwf	(Adc_Norm@norm+3)
	movlw	0
	movwf	(Adc_Norm@norm+2)
	movlw	0Fh
	movwf	(Adc_Norm@norm+1)
	movlw	0FFh
	movwf	(Adc_Norm@norm)

	
l505:	
	line	96
;charge_mgr.c: 96: return (unsigned int)norm;
	movf	(Adc_Norm@norm+1),w
	movwf	(?_Adc_Norm+1)
	movf	(Adc_Norm@norm),w
	movwf	(?_Adc_Norm)
	line	97
	
l503:	
	return
	opt stack 0
GLOBAL	__end_of_Adc_Norm
	__end_of_Adc_Norm:
	signat	_Adc_Norm,4218
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 99 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   21[BANK0 ] unsigned long 
;;  temp_x10        2   27[BANK0 ] unsigned int 
;;  ntcVal          2   25[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   60[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/A00
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	line	99
global __ptext23
__ptext23:	;psect for function _Read_Temperature
psect	text23
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	99
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 4
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	104
	
l7322:	
;charge_mgr.c: 101: unsigned int ntcVal;
;charge_mgr.c: 102: unsigned int temp_x10;
;charge_mgr.c: 104: test_adc = ADC_Sample(18, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_test_adc)^080h	;volatile
	line	105
	
l7324:	
;charge_mgr.c: 105: if(0xA5 != test_adc)
		movlw	165
	xorwf	((_test_adc)^080h),w	;volatile
	btfsc	status,2
	goto	u9861
	goto	u9860
u9861:
	goto	l7328
u9860:
	goto	l509
	line	108
	
l7328:	
;charge_mgr.c: 108: ntcVal = adresult;
	movf	(_adresult+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Read_Temperature@ntcVal+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Read_Temperature@ntcVal)
	line	109
;charge_mgr.c: 109: if(ntcVal < 100 || ntcVal > 3996)
	movlw	0
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u9871
	goto	u9870
u9871:
	goto	l509
u9870:
	
l7330:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u9881
	goto	u9880
u9881:
	goto	l7332
u9880:
	goto	l509
	line	114
	
l7332:	
;charge_mgr.c: 112: {
;charge_mgr.c: 113: unsigned long rt;
;charge_mgr.c: 114: rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	010h
	movwf	(___lldiv@divisor+1)
	movlw	0
	movwf	(___lldiv@divisor)

	movf	(Read_Temperature@ntcVal),w
	movwf	((??_Read_Temperature+0)+0)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((??_Read_Temperature+0)+0+1)
	clrf	((??_Read_Temperature+0)+0+2)
	clrf	((??_Read_Temperature+0)+0+3)
	movf	0+(??_Read_Temperature+0)+0,w
	subwf	(___lldiv@divisor),f
	movf	1+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)+0,w
	goto	u9895
	goto	u9896
u9895:
	subwf	(___lldiv@divisor+1),f
u9896:
	movf	2+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)+0,w
	goto	u9897
	goto	u9898
u9897:
	subwf	(___lldiv@divisor+2),f
u9898:
	movf	3+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)+0,w
	goto	u9899
	goto	u9890
u9899:
	subwf	(___lldiv@divisor+3),f
u9890:

	movf	(Read_Temperature@ntcVal),w
	movwf	(___lmul@multiplier)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	027h
	movwf	(___lmul@multiplicand+1)
	movlw	010h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Read_Temperature@rt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Read_Temperature@rt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@rt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@rt)

	line	115
	
l7334:	
;charge_mgr.c: 115: if(rt >= 10000UL)
		movf	(Read_Temperature@rt+3),w
	btfss	status,2
	goto	u9900
	movf	(Read_Temperature@rt+2),w
	btfss	status,2
	goto	u9900
	movlw	39
	subwf	(Read_Temperature@rt+1),w
	skipz
	goto	u9903
	movlw	16
	subwf	(Read_Temperature@rt),w
	skipz
	goto	u9903
u9903:
	btfss	status,0
	goto	u9901
	goto	u9900

u9901:
	goto	l7340
u9900:
	line	116
	
l7336:	
;charge_mgr.c: 116: temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l7338:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0F0h
	movwf	((??_Read_Temperature+0)+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+3)
	movf	(Read_Temperature@rt),w
	addwf	(??_Read_Temperature+0)+0,f
	movf	(Read_Temperature@rt+1),w
	skipnc
	incfsz	(Read_Temperature@rt+1),w
	goto	u9910
	goto	u9911
u9910:
	addwf	(??_Read_Temperature+0)+1,f
u9911:
	movf	(Read_Temperature@rt+2),w
	skipnc
	incfsz	(Read_Temperature@rt+2),w
	goto	u9912
	goto	u9913
u9912:
	addwf	(??_Read_Temperature+0)+2,f
u9913:
	movf	(Read_Temperature@rt+3),w
	skipnc
	incf	(Read_Temperature@rt+3),w
	addwf	(??_Read_Temperature+0)+3,f
	movf	3+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+3)
	movf	2+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+2)
	movf	1+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+1)
	movf	0+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier)

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(0+(?___lldiv)),w
	subwf	(Read_Temperature@temp_x10),f
	movf	(1+(?___lldiv)),w
	skipc
	decf	(Read_Temperature@temp_x10+1),f
	subwf	(Read_Temperature@temp_x10+1),f
	goto	l7344
	line	118
	
l7340:	
;charge_mgr.c: 117: else
;charge_mgr.c: 118: temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0
	movwf	(___lmul@multiplier+3)
	movlw	0
	movwf	(___lmul@multiplier+2)
	movlw	027h
	movwf	(___lmul@multiplier+1)
	movlw	010h
	movwf	(___lmul@multiplier)

	movf	(Read_Temperature@rt),w
	subwf	(___lmul@multiplier),f
	movf	(Read_Temperature@rt+1),w
	skipc
	incfsz	(Read_Temperature@rt+1),w
	goto	u9925
	goto	u9926
u9925:
	subwf	(___lmul@multiplier+1),f
u9926:
	movf	(Read_Temperature@rt+2),w
	skipc
	incfsz	(Read_Temperature@rt+2),w
	goto	u9927
	goto	u9928
u9927:
	subwf	(___lmul@multiplier+2),f
u9928:
	movf	(Read_Temperature@rt+3),w
	skipc
	incfsz	(Read_Temperature@rt+3),w
	goto	u9929
	goto	u9920
u9929:
	subwf	(___lmul@multiplier+3),f
u9920:

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10)
	
l7342:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10),f
	skipnc
	incf	(Read_Temperature@temp_x10+1),f
	line	119
	
l7344:	
;charge_mgr.c: 119: if(temp_x10 < 100U) temp_x10 = 100U;
	movlw	0
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipnc
	goto	u9931
	goto	u9930
u9931:
	goto	l515
u9930:
	
l7346:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l515:	
	line	120
;charge_mgr.c: 120: if(temp_x10 > 750U) temp_x10 = 750U;
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipc
	goto	u9941
	goto	u9940
u9941:
	goto	l516
u9940:
	
l7348:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)
	movlw	02h
	movwf	((Read_Temperature@temp_x10))+1
	
l516:	
	line	123
;charge_mgr.c: 121: }
;charge_mgr.c: 123: g_temperature = temp_x10;
	movf	(Read_Temperature@temp_x10+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_temperature+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(Read_Temperature@temp_x10),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_temperature)^080h
	line	124
	
l7350:	
;charge_mgr.c: 124: if((temp_x10 / 10U) >= 60)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bcf	status, 5	;RP0=0, select bank0
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u9951
	goto	u9950
u9951:
	goto	l7354
u9950:
	line	125
	
l7352:	
;charge_mgr.c: 125: g_tempProtect = 1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	incf	(_g_tempProtect)^080h,f
	goto	l509
	line	126
	
l7354:	
;charge_mgr.c: 126: else if((temp_x10 / 10U) <= 50)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bcf	status, 5	;RP0=0, select bank0
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u9961
	goto	u9960
u9961:
	goto	l509
u9960:
	line	127
	
l7356:	
;charge_mgr.c: 127: g_tempProtect = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	line	130
	
l509:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 263 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  d               2   46[BANK0 ] int 
;;  t               1   45[BANK0 ] unsigned char 
;;  bat_mv_long     4   40[BANK0 ] unsigned long 
;;  tc              1   44[BANK0 ] unsigned char 
;;  vx_mv           4   34[BANK0 ] unsigned long 
;;  v               2   32[BANK0 ] unsigned int 
;;  s               1   29[BANK0 ] unsigned char 
;;  pt              4   25[BANK0 ] unsigned long 
;;  vcc_mv          2   38[BANK0 ] unsigned int 
;;  i               1   48[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/A00
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      28       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      32       0       0       0
;;Total ram usage:       32 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	263
global __ptext24
__ptext24:	;psect for function _Print_SystemStatus
psect	text24
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	263
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 3
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	268
	
l6884:	
;main.c: 265: unsigned char i;
;main.c: 266: unsigned int vcc_mv;
;main.c: 268: uart_send_string("\r\n== L1211 12CH CHARGER ");
	movlw	low(((STR_4)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	269
;main.c: 269: uart_send_string("V56F");
	movlw	low(((STR_5)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	270
;main.c: 270: uart_send_string(" ==\r\n");
	movlw	low(((STR_6)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	273
	
l6886:	
;main.c: 273: test_adc = ADC_Sample(31, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_test_adc)^080h	;volatile
	line	274
	
l6888:	
;main.c: 274: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)^080h),w	;volatile
	btfss	status,2
	goto	u9141
	goto	u9140
u9141:
	goto	l6894
u9140:
	line	276
	
l6890:	
;main.c: 275: {
;main.c: 276: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt)

	line	277
	
l6892:	
;main.c: 277: vcc_mv = (unsigned int)pt;
	movf	(Print_SystemStatus@pt+1),w
	movwf	(Print_SystemStatus@vcc_mv+1)
	movf	(Print_SystemStatus@pt),w
	movwf	(Print_SystemStatus@vcc_mv)
	line	278
;main.c: 278: }
	goto	l361
	line	280
	
l6894:	
;main.c: 279: else
;main.c: 280: vcc_mv = 5000;
	movlw	088h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Print_SystemStatus@vcc_mv)
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv))+1
	
l361:	
	line	282
;main.c: 282: g_vcc_mv = vcc_mv;
	movf	(Print_SystemStatus@vcc_mv+1),w
	movwf	(_g_vcc_mv+1)	;volatile
	movf	(Print_SystemStatus@vcc_mv),w
	movwf	(_g_vcc_mv)	;volatile
	line	284
	
l6896:	
;main.c: 284: uart_send_string("VCC=");
	movlw	low(((STR_7)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	285
	
l6898:	
;main.c: 285: uart_send_number(vcc_mv);
	movf	(Print_SystemStatus@vcc_mv+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@vcc_mv),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	286
	
l6900:	
;main.c: 286: uart_send_string("mV T=");
	movlw	low(((STR_8)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	287
	
l6902:	
;main.c: 287: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature)^080h,w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_SystemStatus$814+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_Print_SystemStatus$814)
	
l6904:	
;main.c: 287: uart_send_number(g_temperature / 10U);
	movf	(_Print_SystemStatus$814+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$814),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	288
	
l6906:	
;main.c: 288: uart_send_string(".");
	movlw	low(((STR_9)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	289
	
l6908:	
;main.c: 289: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature)^080h,w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_SystemStatus$815+1)
	movf	(0+(?___lwmod)),w
	movwf	(_Print_SystemStatus$815)
	
l6910:	
;main.c: 289: uart_send_number(g_temperature % 10U);
	movf	(_Print_SystemStatus$815+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$815),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	290
	
l6912:	
;main.c: 290: uart_send_string("C IMP_LOCK=");
	movlw	low(((STR_10)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	291
	
l6914:	
;main.c: 291: uart_send_number(g_impCheckSlot == 0xFF ? 0xFFU : (unsigned int)g_impCheckSlot);
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u9151
	goto	u9150
u9151:
	goto	l6918
u9150:
	
l6916:	
	movf	(_g_impCheckSlot)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_SystemStatus$265)
	clrf	(_Print_SystemStatus$265+1)
	goto	l6920
	
l6918:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_SystemStatus$265)
	clrf	(_Print_SystemStatus$265+1)
	
l6920:	
	movf	(_Print_SystemStatus$265+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$265),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	292
	
l6922:	
;main.c: 292: uart_send_string("\r\n");
	movlw	low(((STR_11)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	297
	
l6924:	
;main.c: 297: for(i = 0; i < 12; i++)
	clrf	(Print_SystemStatus@i)
	line	302
	
l6930:	
;main.c: 301: {
;main.c: 302: unsigned int v = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Print_SystemStatus@v)
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)
	line	303
;main.c: 303: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Print_SystemStatus@s)
	line	305
	
l6932:	
;main.c: 305: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	306
	
l6934:	
;main.c: 306: uart_send_number((unsigned int)i + 1U);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@i),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	307
;main.c: 307: uart_send_char('=');
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	308
	
l6936:	
;main.c: 308: uart_send_number(v);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@v+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@v),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	314
	
l6938:	
;main.c: 313: {
;main.c: 314: unsigned long vx_mv = (unsigned long)v * 5000UL / 4096UL;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@v),w
	movwf	(___lmul@multiplier)
	movf	(Print_SystemStatus@v+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv)

	
l6940:	
	movlw	0Ch
u9165:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3),f
	rrf	(Print_SystemStatus@vx_mv+2),f
	rrf	(Print_SystemStatus@vx_mv+1),f
	rrf	(Print_SystemStatus@vx_mv),f
	addlw	-1
	skipz
	goto	u9165

	line	315
	
l6942:	
;main.c: 315: if(vx_mv + 200U >= 5000UL)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+0)+0)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+3)
	movf	(Print_SystemStatus@vx_mv),w
	addwf	(??_Print_SystemStatus+0)+0,f
	movf	(Print_SystemStatus@vx_mv+1),w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1),w
	goto	u9170
	goto	u9171
u9170:
	addwf	(??_Print_SystemStatus+0)+1,f
u9171:
	movf	(Print_SystemStatus@vx_mv+2),w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2),w
	goto	u9172
	goto	u9173
u9172:
	addwf	(??_Print_SystemStatus+0)+2,f
u9173:
	movf	(Print_SystemStatus@vx_mv+3),w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3),w
	addwf	(??_Print_SystemStatus+0)+3,f
		movf	(??_Print_SystemStatus+0)+3,w
	btfss	status,2
	goto	u9180
	movf	(??_Print_SystemStatus+0)+2,w
	btfss	status,2
	goto	u9180
	movlw	19
	subwf	(??_Print_SystemStatus+0)+1,w
	skipz
	goto	u9183
	movlw	136
	subwf	(??_Print_SystemStatus+0)+0,w
	skipz
	goto	u9183
u9183:
	btfss	status,0
	goto	u9181
	goto	u9180

u9181:
	goto	l6946
u9180:
	line	317
	
l6944:	
;main.c: 316: {
;main.c: 317: uart_send_string(" OPEN");
	movlw	low(((STR_12)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	318
;main.c: 318: }
	goto	l6958
	line	321
	
l6946:	
;main.c: 319: else
;main.c: 320: {
;main.c: 321: unsigned long bat_mv_long = 124UL * vx_mv + 206UL * 5000UL;
	movf	(Print_SystemStatus@vx_mv+3),w
	movwf	(___lmul@multiplier+3)
	movf	(Print_SystemStatus@vx_mv+2),w
	movwf	(___lmul@multiplier+2)
	movf	(Print_SystemStatus@vx_mv+1),w
	movwf	(___lmul@multiplier+1)
	movf	(Print_SystemStatus@vx_mv),w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+3)
	movf	(2+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+2)
	movf	(1+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+1)
	movf	(0+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long)

	
l6948:	
	movlw	070h
	addwf	(Print_SystemStatus@bat_mv_long),f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Print_SystemStatus@bat_mv_long+1),f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Print_SystemStatus@bat_mv_long+2),f
	movlw	0
	skipnc
movlw 1
	addwf	(Print_SystemStatus@bat_mv_long+3),f
	line	322
	
l6950:	
;main.c: 322: bat_mv_long = (bat_mv_long + 1000UL/2UL) / 1000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Print_SystemStatus+0)+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+3)
	movf	(Print_SystemStatus@bat_mv_long),w
	addwf	(??_Print_SystemStatus+0)+0,f
	movf	(Print_SystemStatus@bat_mv_long+1),w
	skipnc
	incfsz	(Print_SystemStatus@bat_mv_long+1),w
	goto	u9190
	goto	u9191
u9190:
	addwf	(??_Print_SystemStatus+0)+1,f
u9191:
	movf	(Print_SystemStatus@bat_mv_long+2),w
	skipnc
	incfsz	(Print_SystemStatus@bat_mv_long+2),w
	goto	u9192
	goto	u9193
u9192:
	addwf	(??_Print_SystemStatus+0)+2,f
u9193:
	movf	(Print_SystemStatus@bat_mv_long+3),w
	skipnc
	incf	(Print_SystemStatus@bat_mv_long+3),w
	addwf	(??_Print_SystemStatus+0)+3,f
	movf	3+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+3)
	movf	(2+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+2)
	movf	(1+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+1)
	movf	(0+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long)

	line	323
	
l6952:	
;main.c: 323: uart_send_string(" BAT(");
	movlw	low(((STR_13)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	324
	
l6954:	
;main.c: 324: uart_send_number((unsigned int)bat_mv_long);
	movf	(Print_SystemStatus@bat_mv_long+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@bat_mv_long),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	325
	
l6956:	
;main.c: 325: uart_send_string("mV)");
	movlw	low(((STR_14)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	330
	
l6958:	
;main.c: 326: }
;main.c: 327: }
;main.c: 330: uart_send_char(' ');
	movlw	low(020h)
	fcall	_uart_send_char
	line	331
;main.c: 331: switch(s)
	goto	l7014
	line	333
	
l6960:	
	movlw	low(((STR_15)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7016
	line	335
	
l6962:	
;main.c: 335: uart_send_string("[DET]");
	movlw	low(((STR_16)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	336
	
l6964:	
;main.c: 336: if(g_slotRefV[i] > 0U)
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	((??_Print_SystemStatus+0)+0),w
iorwf	((??_Print_SystemStatus+0)+1),w
	btfsc	status,2
	goto	u9201
	goto	u9200
u9201:
	goto	l7016
u9200:
	line	338
	
l6966:	
;main.c: 337: {
;main.c: 338: uart_send_string(" ref=");
	movlw	low(((STR_17)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	339
	
l6968:	
;main.c: 339: uart_send_number(g_slotRefV[i]);
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(uart_send_number@num)
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	goto	l7016
	line	342
	
l6970:	
	movlw	low(((STR_18)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7016
	line	343
	
l6972:	
	movlw	low(((STR_19)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7016
	line	344
	
l6974:	
	movlw	low(((STR_20)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7016
	line	345
	
l6976:	
	movlw	low(((STR_21)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7016
	line	346
	
l6978:	
	movlw	low(((STR_22)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7016
	line	349
	
l6980:	
;main.c: 348: {
;main.c: 349: unsigned char t = g_slot[(unsigned char)(i)].type;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Print_SystemStatus@t)
	line	350
	
l6982:	
;main.c: 350: if(t == 2 || t == 3)
		movlw	2
	xorwf	((Print_SystemStatus@t)),w
	btfsc	status,2
	goto	u9211
	goto	u9210
u9211:
	goto	l6986
u9210:
	
l6984:	
		movlw	3
	xorwf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u9221
	goto	u9220
u9221:
	goto	l6988
u9220:
	line	351
	
l6986:	
;main.c: 351: uart_send_string("[Dry/NiMH ERR]");
	movlw	low(((STR_23)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6998
	line	352
	
l6988:	
;main.c: 352: else if(t == 1)
		decf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u9231
	goto	u9230
u9231:
	goto	l6992
u9230:
	line	353
	
l6990:	
;main.c: 353: uart_send_string("[Li-ion ERR]");
	movlw	low(((STR_24)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6998
	line	354
	
l6992:	
;main.c: 354: else if(t == 6)
		movlw	6
	xorwf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u9241
	goto	u9240
u9241:
	goto	l6996
u9240:
	line	355
	
l6994:	
;main.c: 355: uart_send_string("[Linear Li ERR]");
	movlw	low(((STR_25)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6998
	line	357
	
l6996:	
;main.c: 356: else
;main.c: 357: uart_send_string("[ERR]");
	movlw	low(((STR_26)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	358
	
l6998:	
;main.c: 358: if(g_slotRefV[i] > 0U)
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	((??_Print_SystemStatus+0)+0),w
iorwf	((??_Print_SystemStatus+0)+1),w
	btfsc	status,2
	goto	u9251
	goto	u9250
u9251:
	goto	l7016
u9250:
	line	360
	
l7000:	
;main.c: 359: {
;main.c: 360: uart_send_string(" ref=");
	movlw	low(((STR_27)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6968
	line	365
	
l7004:	
	movlw	low(((STR_28)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7016
	line	367
	
l7006:	
;main.c: 367: uart_send_string("[DIO]");
	movlw	low(((STR_29)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	368
;main.c: 368: uart_send_string(" pre=");
	movlw	low(((STR_30)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	369
	
l7008:	
;main.c: 369: uart_send_number(g_impData & 0x0FFFU);
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(uart_send_number@num)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(uart_send_number@num)
	fcall	_uart_send_number
	line	370
;main.c: 370: break;
	goto	l7016
	line	371
	
l7010:	
	movlw	low(((STR_31)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7016
	line	331
	
l7014:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@s),w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l6960
	xorlw	1^0	; case 1
	skipnz
	goto	l6962
	xorlw	2^1	; case 2
	skipnz
	goto	l6970
	xorlw	3^2	; case 3
	skipnz
	goto	l6972
	xorlw	4^3	; case 4
	skipnz
	goto	l6974
	xorlw	5^4	; case 5
	skipnz
	goto	l6976
	xorlw	6^5	; case 6
	skipnz
	goto	l6978
	xorlw	7^6	; case 7
	skipnz
	goto	l6980
	xorlw	8^7	; case 8
	skipnz
	goto	l7004
	xorlw	9^8	; case 9
	skipnz
	goto	l7006
	goto	l7010
	opt asmopt_pop

	line	375
	
l7016:	
;main.c: 375: uart_send_string(" ct=");
	movlw	low(((STR_32)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	376
	
l7018:	
;main.c: 376: uart_send_number(g_slot[(unsigned char)(i)].chargeTimer);
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	377
	
l7020:	
;main.c: 377: uart_send_string(" ty=");
	movlw	low(((STR_33)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	378
;main.c: 378: uart_send_number(g_slot[(unsigned char)(i)].type);
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	381
	
l7022:	
;main.c: 381: if(g_diodeTraceCnt > 0U && g_diodeTraceSlot == i)
	movf	((_g_diodeTraceCnt)),w
	btfsc	status,2
	goto	u9261
	goto	u9260
u9261:
	goto	l7058
u9260:
	
l7024:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_diodeTraceSlot)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Print_SystemStatus@i),w
	skipz
	goto	u9271
	goto	u9270
u9271:
	goto	l7058
u9270:
	line	384
	
l7026:	
;main.c: 382: {
;main.c: 383: unsigned char tc;
;main.c: 384: uart_send_string(" tr=");
	movlw	low(((STR_34)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_34)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	385
	
l7028:	
;main.c: 385: for(tc = 0; tc < g_diodeTraceCnt; tc++)
	clrf	(Print_SystemStatus@tc)
	goto	l7052
	line	387
	
l7030:	
;main.c: 386: {
;main.c: 387: signed int d = (signed int)g_diodeTrace[tc] - 128;
	movf	(Print_SystemStatus@tc),w
	addlw	low(_g_diodeTrace|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(Print_SystemStatus@d)
	clrf	(Print_SystemStatus@d+1)
	
l7032:	
	movlw	-128
	addwf	(Print_SystemStatus@d),f
	skipc
	decf	(Print_SystemStatus@d+1),f
	line	388
	
l7034:	
;main.c: 388: if(d < 0)
	btfss	(Print_SystemStatus@d+1),7
	goto	u9281
	goto	u9280
u9281:
	goto	l7040
u9280:
	line	390
	
l7036:	
;main.c: 389: {
;main.c: 390: uart_send_char('-');
	movlw	low(02Dh)
	fcall	_uart_send_char
	line	391
	
l7038:	
;main.c: 391: d = -d;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	comf	(Print_SystemStatus@d),f
	comf	(Print_SystemStatus@d+1),f
	incf	(Print_SystemStatus@d),f
	skipnz
	incf	(Print_SystemStatus@d+1),f
	line	392
;main.c: 392: }
	goto	l7044
	line	393
	
l7040:	
;main.c: 393: else if(d > 0)
	movf	(Print_SystemStatus@d+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u9295
	movlw	01h
	subwf	(Print_SystemStatus@d),w
u9295:

	skipc
	goto	u9291
	goto	u9290
u9291:
	goto	l7044
u9290:
	line	394
	
l7042:	
;main.c: 394: uart_send_char('+');
	movlw	low(02Bh)
	fcall	_uart_send_char
	line	395
	
l7044:	
;main.c: 395: uart_send_number((unsigned int)d * 4U);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@d+1),w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	(Print_SystemStatus@d),w
	movwf	(??_Print_SystemStatus+0)+0
	clrc
	rlf	(??_Print_SystemStatus+0)+0,f
	rlf	(??_Print_SystemStatus+0)+1,f
	clrc
	rlf	(??_Print_SystemStatus+0)+0,f
	rlf	(??_Print_SystemStatus+0)+1,f
	movf	0+(??_Print_SystemStatus+0)+0,w
	movwf	(uart_send_number@num)
	movf	1+(??_Print_SystemStatus+0)+0,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	396
	
l7046:	
;main.c: 396: if(tc + 1U < g_diodeTraceCnt)
	movf	(_g_diodeTraceCnt),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Print_SystemStatus+0)+0
	clrf	(??_Print_SystemStatus+0)+0+1
	movf	(Print_SystemStatus@tc),w
	addlw	low(01h)
	movwf	(??_Print_SystemStatus+2)+0
	movlw	high(01h)
	skipnc
	movlw	(high(01h)+1)&0ffh
	movwf	((??_Print_SystemStatus+2)+0)+1
	movf	1+(??_Print_SystemStatus+0)+0,w
	subwf	1+(??_Print_SystemStatus+2)+0,w
	skipz
	goto	u9305
	movf	0+(??_Print_SystemStatus+0)+0,w
	subwf	0+(??_Print_SystemStatus+2)+0,w
u9305:
	skipnc
	goto	u9301
	goto	u9300
u9301:
	goto	l7050
u9300:
	line	397
	
l7048:	
;main.c: 397: uart_send_char(',');
	movlw	low(02Ch)
	fcall	_uart_send_char
	line	385
	
l7050:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Print_SystemStatus@tc),f
	
l7052:	
	movf	(_g_diodeTraceCnt),w
	subwf	(Print_SystemStatus@tc),w
	skipc
	goto	u9311
	goto	u9310
u9311:
	goto	l7030
u9310:
	line	399
	
l7054:	
;main.c: 398: }
;main.c: 399: g_diodeTraceCnt = 0;
	clrf	(_g_diodeTraceCnt)
	line	400
	
l7056:	
;main.c: 400: g_diodeTraceSlot = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_diodeTraceSlot)^080h
	line	404
	
l7058:	
;main.c: 401: }
;main.c: 404: uart_send_string("\r\n");
	movlw	low(((STR_35)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_35)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	297
	
l7060:	
	incf	(Print_SystemStatus@i),f
	
l7062:	
	movlw	low(0Ch)
	subwf	(Print_SystemStatus@i),w
	skipc
	goto	u9321
	goto	u9320
u9321:
	goto	l6930
u9320:
	line	407
	
l7064:	
;main.c: 406: }
;main.c: 407: uart_send_string("\r\n");
	movlw	low(((STR_36)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_36)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	408
	
l401:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    2[COMMON] unsigned long 
;;  multiplicand    4    6[COMMON] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    0[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    2[COMMON] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         8       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       4       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Li_Route
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext25
__ptext25:	;psect for function ___lmul
psect	text25
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 1
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l5396:	
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l903:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u6661
	goto	u6660
u6661:
	goto	l5400
u6660:
	line	122
	
l5398:	
	movf	(___lmul@multiplicand),w
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u6671
	addwf	(___lmul@product+1),f
u6671:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u6672
	addwf	(___lmul@product+2),f
u6672:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u6673
	addwf	(___lmul@product+3),f
u6673:

	line	123
	
l5400:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l5402:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u6681
	goto	u6680
u6681:
	goto	l903
u6680:
	line	128
	
l5404:	
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l906:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    4[BANK0 ] unsigned long 
;;  dividend        4    8[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   12[BANK0 ] unsigned long 
;;  counter         1   16[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    4[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      13       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Li_Route
;;		_Get_Vcc
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext26
__ptext26:	;psect for function ___lldiv
psect	text26
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 1
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l5408:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l5410:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u6691
	goto	u6690
u6691:
	goto	l5430
u6690:
	line	16
	
l5412:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l5416
	line	18
	
l5414:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l5416:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u6701
	goto	u6700
u6701:
	goto	l5414
u6700:
	line	22
	
l5418:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l5420:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u6715
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u6715
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u6715
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u6715:
	skipc
	goto	u6711
	goto	u6710
u6711:
	goto	l5426
u6710:
	line	24
	
l5422:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l5424:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l5426:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l5428:	
	decfsz	(___lldiv@counter),f
	goto	u6721
	goto	u6720
u6721:
	goto	l5418
u6720:
	line	30
	
l5430:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l1178:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    2[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    1[BANK0 ] unsigned char 
;;  j               1    0[BANK0 ] unsigned char 
;;  adsum           4    3[BANK0 ] volatile unsigned long 
;;  ad_temp         2   11[BANK0 ] volatile unsigned int 
;;  admax           2    9[BANK0 ] volatile unsigned int 
;;  admin           2    7[BANK0 ] volatile unsigned int 
;;  i               1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      13       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Get_Vcc
;;		_Adc_Norm
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext27
__ptext27:	;psect for function _ADC_Sample
psect	text27
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 2
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(ADC_Sample@adch)
	line	51
	
l5434:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	52
	
l5436:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	58
	
l5438:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u6731
	goto	u6730
u6731:
	goto	l5444
u6730:
	
l5440:	
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u6741
	goto	u6740
u6741:
	goto	l5444
u6740:
	line	60
	
l5442:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??_ADC_Sample+0)+0),f
	u10037:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u10037
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	l5446
	line	64
	
l5444:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	67
	
l5446:	
;adc_drv.c: 67: if(adch & 0x10)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(ADC_Sample@adch),(4)&7
	goto	u6751
	goto	u6750
u6751:
	goto	l425
u6750:
	line	69
	
l5448:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l5450:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(ADC_Sample@adch),f
	line	71
;adc_drv.c: 71: }
	goto	l5452
	line	72
	
l425:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l5452:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@i)
	line	79
	
l5458:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(ADC_Sample@adch),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u6765:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u6765
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l5460:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	6
movwf	((??_ADC_Sample+0)+0),f
	u10047:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u10047
	nop
opt asmopt_pop

	line	81
	
l5462:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l5464:	
;adc_drv.c: 84: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	l429
	
l430:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u6771
	goto	u6770
u6771:
	goto	l429
u6770:
	line	89
	
l5466:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	l432
	line	90
	
l429:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u6781
	goto	u6780
u6781:
	goto	l430
u6780:
	line	93
	
l5470:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
l5472:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
l5474:	
;adc_drv.c: 96: if(0 == admax)
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u6791
	goto	u6790
u6791:
	goto	l5478
u6790:
	line	98
	
l5476:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	100
;adc_drv.c: 100: }
	goto	l435
	line	102
	
l5478:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u6805
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u6805:
	skipnc
	goto	u6801
	goto	u6800
u6801:
	goto	l5482
u6800:
	line	103
	
l5480:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	l435
	line	105
	
l5482:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u6815
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u6815:
	skipnc
	goto	u6811
	goto	u6810
u6811:
	goto	l435
u6810:
	line	106
	
l5484:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	108
	
l435:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u6821
	addwf	(ADC_Sample@adsum+1),f	;volatile
u6821:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u6822
	addwf	(ADC_Sample@adsum+2),f	;volatile
u6822:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u6823
	addwf	(ADC_Sample@adsum+3),f	;volatile
u6823:

	line	76
	
l5486:	
	incf	(ADC_Sample@i),f
	
l5488:	
	movlw	low(022h)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u6831
	goto	u6830
u6831:
	goto	l5458
u6830:
	line	112
	
l5490:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u6845
	goto	u6846
u6845:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u6846:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u6847
	goto	u6848
u6847:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u6848:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u6849
	goto	u6840
u6849:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u6840:

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u6855
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u6855
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u6855
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u6855:
	skipc
	goto	u6851
	goto	u6850
u6851:
	goto	l439
u6850:
	line	114
	
l5492:	
;adc_drv.c: 114: adsum -= admin;
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u6865
	goto	u6866
u6865:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u6866:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u6867
	goto	u6868
u6867:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u6868:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u6869
	goto	u6860
u6869:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u6860:

	goto	l5494
	line	115
	
l439:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	118
	
l5494:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u6875:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u6870:
	addlw	-1
	skipz
	goto	u6875
	movf	1+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_adresult+1)^080h	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)^080h	;volatile
	line	119
	
l5496:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
l432:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 242 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	242
global __ptext28
__ptext28:	;psect for function _Print_NtcTemp
psect	text28
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	242
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 3
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	244
	
l6872:	
;main.c: 244: uart_send_string("NTC=");
	movlw	low(((STR_1)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	245
	
l6874:	
;main.c: 245: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature)^080h,w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_NtcTemp$812+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$812)
	
l6876:	
;main.c: 245: uart_send_number(g_temperature / 10U);
	movf	(_Print_NtcTemp$812+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$812),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	246
	
l6878:	
;main.c: 246: uart_send_string(".");
	movlw	low(((STR_2)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	247
	
l6880:	
;main.c: 247: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature)^080h,w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_NtcTemp$813+1)
	movf	(0+(?___lwmod)),w
	movwf	(_Print_NtcTemp$813)
;main.c: 247: uart_send_number(g_temperature % 10U);
	movf	(_Print_NtcTemp$813+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$813),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	248
	
l6882:	
;main.c: 248: uart_send_string("C\r\n");
	movlw	low(((STR_3)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	249
	
l357:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2    5[COMMON] PTR const unsigned char 
;;		 -> STR_38(10), STR_37(21), STR_36(3), STR_35(3), 
;;		 -> STR_34(5), STR_33(5), STR_32(5), STR_31(6), 
;;		 -> STR_30(6), STR_29(6), STR_28(6), STR_27(6), 
;;		 -> STR_26(6), STR_25(16), STR_24(13), STR_23(15), 
;;		 -> STR_22(7), STR_21(5), STR_20(5), STR_19(6), 
;;		 -> STR_18(6), STR_17(6), STR_16(6), STR_15(7), 
;;		 -> STR_14(4), STR_13(6), STR_12(6), STR_11(3), 
;;		 -> STR_10(12), STR_9(2), STR_8(6), STR_7(5), 
;;		 -> STR_6(6), STR_5(5), STR_4(25), STR_3(4), 
;;		 -> STR_2(2), STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         2       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_main
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
global __ptext29
__ptext29:	;psect for function _uart_send_string
psect	text29
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 4
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l5696:	
;uart_dbg.c: 63: while(*str != '\0')
	goto	l5702
	line	65
	
l5698:	
;uart_dbg.c: 64: {
;uart_dbg.c: 65: uart_send_char(*str++);
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	fcall	_uart_send_char
	
l5700:	
	incf	(uart_send_string@str),f
	skipnz
	incf	(uart_send_string@str+1),f
	line	66
# 66 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
clrwdt ;# 
psect	text29
	line	63
	
l5702:	
	movf	(uart_send_string@str+1),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u7151
	goto	u7150
u7151:
	goto	l5698
u7150:
	line	68
	
l456:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2    0[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    2[BANK0 ] unsigned char [6]
;;  j               1    9[BANK0 ] unsigned char 
;;  i               1    8[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      10       0       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text30,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext30
__ptext30:	;psect for function _uart_send_number
psect	text30
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l5704:	
;uart_dbg.c: 79: unsigned char buf[6];
;uart_dbg.c: 80: unsigned char i = 0;
	clrf	(uart_send_number@i)
	line	84
	
l5706:	
;uart_dbg.c: 81: unsigned char j;
;uart_dbg.c: 84: if(num == 0)
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u7161
	goto	u7160
u7161:
	goto	l5718
u7160:
	line	86
	
l5708:	
;uart_dbg.c: 85: {
;uart_dbg.c: 86: uart_send_char('0');
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l460
	line	93
	
l5712:	
;uart_dbg.c: 92: {
;uart_dbg.c: 93: buf[i++] = '0' + (num % 10);
	movf	(uart_send_number@i),w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwmod@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank0
	movwf	indf
	
l5714:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(uart_send_number@i),f
	line	94
	
l5716:	
;uart_dbg.c: 94: num /= 10;
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	movf	(0+(?___lwdiv)),w
	movwf	(uart_send_number@num)
	line	91
	
l5718:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u7171
	goto	u7170
u7171:
	goto	l5712
u7170:
	line	98
	
l5720:	
;uart_dbg.c: 95: }
;uart_dbg.c: 98: for(j = i; j > 0; j--)
	movf	(uart_send_number@i),w
	movwf	(uart_send_number@j)
	
l5722:	
	movf	((uart_send_number@j)),w
	btfss	status,2
	goto	u7181
	goto	u7180
u7181:
	goto	l5726
u7180:
	goto	l460
	line	99
	
l5726:	
;uart_dbg.c: 99: uart_send_char(buf[(unsigned char)(j - 1)]);
	movf	(uart_send_number@j),w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l5728:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decf	(uart_send_number@j),f
	goto	l5722
	line	100
	
l460:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1    3[COMMON] unsigned char 
;;  i               1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          1       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text31,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext31
__ptext31:	;psect for function _uart_send_char
psect	text31
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 4
; Regs used in _uart_send_char: [wreg+status,2+status,0]
;uart_send_char@c stored from wreg
	movwf	(uart_send_char@c)
	line	38
	
l5546:	
;uart_dbg.c: 37: unsigned char i;
;uart_dbg.c: 38: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	39
;uart_dbg.c: 39: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l5548:	
;uart_dbg.c: 40: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u10057:
decfsz	(??_uart_send_char+0)+0,f
	goto	u10057
	nop
opt asmopt_pop

	line	41
	
l5550:	
;uart_dbg.c: 41: for(i = 0; i < 8; i++)
	clrf	(uart_send_char@i)
	line	42
	
l446:	
	line	43
;uart_dbg.c: 42: {
;uart_dbg.c: 43: if(c & 0x01)
	btfss	(uart_send_char@c),(0)&7
	goto	u6941
	goto	u6940
u6941:
	goto	l448
u6940:
	line	44
	
l5556:	
;uart_dbg.c: 44: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l5558
	line	45
	
l448:	
	line	46
;uart_dbg.c: 45: else
;uart_dbg.c: 46: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l5558:	
;uart_dbg.c: 47: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u10067:
decfsz	(??_uart_send_char+0)+0,f
	goto	u10067
	nop
opt asmopt_pop

	line	48
	
l5560:	
;uart_dbg.c: 48: c >>= 1;
	clrc
	rrf	(uart_send_char@c),f
	line	41
	
l5562:	
	incf	(uart_send_char@i),f
	
l5564:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u6951
	goto	u6950
u6951:
	goto	l446
u6950:
	
l447:	
	line	50
;uart_dbg.c: 49: }
;uart_dbg.c: 50: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l5566:	
;uart_dbg.c: 51: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u10077:
decfsz	(??_uart_send_char+0)+0,f
	goto	u10077
	nop
opt asmopt_pop

	line	52
	
l5568:	
;uart_dbg.c: 52: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l450:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] unsigned int 
;;  dividend        2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/900
;;		On exit  : 200/0
;;		Unchanged: 200/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text32,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext32
__ptext32:	;psect for function ___lwmod
psect	text32
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l5668:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u7111
	goto	u7110
u7111:
	goto	l5684
u7110:
	line	14
	
l5670:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l5674
	line	16
	
l5672:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l5674:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u7121
	goto	u7120
u7121:
	goto	l5672
u7120:
	line	20
	
l5676:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u7135
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u7135:
	skipc
	goto	u7131
	goto	u7130
u7131:
	goto	l5680
u7130:
	line	21
	
l5678:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l5680:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l5682:	
	decfsz	(___lwmod@counter),f
	goto	u7141
	goto	u7140
u7141:
	goto	l5676
u7140:
	line	25
	
l5684:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1241:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] unsigned int 
;;  dividend        2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    7[COMMON] unsigned int 
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 200/0
;;		Unchanged: 200/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         3       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         7       0       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_Slot_Detect
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text33,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext33
__ptext33:	;psect for function ___lwdiv
psect	text33
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l5642:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l5644:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u7071
	goto	u7070
u7071:
	goto	l5664
u7070:
	line	16
	
l5646:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l5650
	line	18
	
l5648:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l5650:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u7081
	goto	u7080
u7081:
	goto	l5648
u7080:
	line	22
	
l5652:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l5654:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u7095
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u7095:
	skipc
	goto	u7091
	goto	u7090
u7091:
	goto	l5660
u7090:
	line	24
	
l5656:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l5658:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l5660:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l5662:	
	decfsz	(___lwdiv@counter),f
	goto	u7101
	goto	u7100
u7101:
	goto	l5652
u7100:
	line	30
	
l5664:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l1231:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 1313 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    8[BANK0 ] unsigned int 
;;  s               1   19[BANK0 ] unsigned char 
;;  duty            2   16[BANK0 ] int 
;;  error           2   12[BANK0 ] int 
;;  adjust          2    2[BANK0 ] int 
;;  duty_initial    1   15[BANK0 ] unsigned char 
;;  duty_target     1   14[BANK0 ] unsigned char 
;;  maxV            2   10[BANK0 ] unsigned int 
;;  i               1   18[BANK0 ] unsigned char 
;;  preCount        1    7[BANK0 ] unsigned char 
;;  ccCount         1    6[BANK0 ] unsigned char 
;;  cvCount         1    5[BANK0 ] unsigned char 
;;  hasCharging     1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/900
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          0       2       0       0       0
;;      Totals:         0      20       0       0       0
;;Total ram usage:       20 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___awdiv
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text34,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1313
global __ptext34
__ptext34:	;psect for function _CCCV_Control
psect	text34
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1313
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 4
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1316
	
l7156:	
;charge_mgr.c: 1315: unsigned char i;
;charge_mgr.c: 1316: unsigned char hasCharging = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	1317
;charge_mgr.c: 1317: unsigned int maxV = 0;
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	1318
;charge_mgr.c: 1318: unsigned char cvCount = 0;
	clrf	(CCCV_Control@cvCount)
	line	1319
;charge_mgr.c: 1319: unsigned char ccCount = 0;
	clrf	(CCCV_Control@ccCount)
	line	1320
;charge_mgr.c: 1320: unsigned char preCount = 0;
	clrf	(CCCV_Control@preCount)
	line	1323
	
l7158:	
;charge_mgr.c: 1323: if(g_vccProtect)
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u9491
	goto	u9490
u9491:
	goto	l7164
u9490:
	line	1325
	
l7160:	
;charge_mgr.c: 1324: {
;charge_mgr.c: 1325: if(g_vcc_mv >= 4600)
	movlw	011h
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_g_vcc_mv+1),w	;volatile
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv),w	;volatile
	skipc
	goto	u9501
	goto	u9500
u9501:
	goto	l7168
u9500:
	line	1326
	
l7162:	
;charge_mgr.c: 1326: g_vccProtect = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_vccProtect)^080h
	goto	l7168
	line	1330
	
l7164:	
;charge_mgr.c: 1328: else
;charge_mgr.c: 1329: {
;charge_mgr.c: 1330: if(g_vcc_mv < 4400)
	movlw	011h
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_g_vcc_mv+1),w	;volatile
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv),w	;volatile
	skipnc
	goto	u9511
	goto	u9510
u9511:
	goto	l7168
u9510:
	line	1331
	
l7166:	
;charge_mgr.c: 1331: g_vccProtect = 1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_vccProtect)^080h
	incf	(_g_vccProtect)^080h,f
	line	1335
	
l7168:	
;charge_mgr.c: 1332: }
;charge_mgr.c: 1335: if(g_tempProtect || g_vccProtect)
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u9521
	goto	u9520
u9521:
	goto	l7172
u9520:
	
l7170:	
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u9531
	goto	u9530
u9531:
	goto	l7176
u9530:
	line	1337
	
l7172:	
;charge_mgr.c: 1336: {
;charge_mgr.c: 1337: g_pwmDuty = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	1338
;charge_mgr.c: 1338: g_cvIntegral = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	l834
	line	1343
	
l7176:	
;charge_mgr.c: 1340: }
;charge_mgr.c: 1343: for(i = 0; i < 12; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(CCCV_Control@i)
	line	1345
	
l7182:	
;charge_mgr.c: 1344: {
;charge_mgr.c: 1345: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	1349
	
l7184:	
;charge_mgr.c: 1347: if(s == 2 || s == 3 ||
;charge_mgr.c: 1348: s == 4 || s == 5 ||
;charge_mgr.c: 1349: s == 8)
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9541
	goto	u9540
u9541:
	goto	l839
u9540:
	
l7186:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9551
	goto	u9550
u9551:
	goto	l839
u9550:
	
l7188:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9561
	goto	u9560
u9561:
	goto	l839
u9560:
	
l7190:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9571
	goto	u9570
u9571:
	goto	l839
u9570:
	
l7192:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9581
	goto	u9580
u9581:
	goto	l837
u9580:
	
l839:	
	line	1351
;charge_mgr.c: 1350: {
;charge_mgr.c: 1351: hasCharging = 1;
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	1353
	
l7194:	
;charge_mgr.c: 1352: {
;charge_mgr.c: 1353: unsigned int vt = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	1354
	
l7196:	
;charge_mgr.c: 1354: if(vt > maxV) maxV = vt;
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u9595
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u9595:
	skipnc
	goto	u9591
	goto	u9590
u9591:
	goto	l7200
u9590:
	
l7198:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	1356
	
l7200:	
;charge_mgr.c: 1355: }
;charge_mgr.c: 1356: if(s == 5)
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9601
	goto	u9600
u9601:
	goto	l7204
u9600:
	line	1357
	
l7202:	
;charge_mgr.c: 1357: cvCount++;
	incf	(CCCV_Control@cvCount),f
	line	1358
	
l7204:	
;charge_mgr.c: 1358: if(s == 4)
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9611
	goto	u9610
u9611:
	goto	l7208
u9610:
	line	1359
	
l7206:	
;charge_mgr.c: 1359: ccCount++;
	incf	(CCCV_Control@ccCount),f
	line	1360
	
l7208:	
;charge_mgr.c: 1360: if(s == 3 || s == 2)
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9621
	goto	u9620
u9621:
	goto	l7212
u9620:
	
l7210:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9631
	goto	u9630
u9631:
	goto	l837
u9630:
	line	1361
	
l7212:	
;charge_mgr.c: 1361: preCount++;
	incf	(CCCV_Control@preCount),f
	line	1362
	
l837:	
	line	1343
	incf	(CCCV_Control@i),f
	
l7214:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u9641
	goto	u9640
u9641:
	goto	l7182
u9640:
	line	1366
	
l7216:	
;charge_mgr.c: 1362: }
;charge_mgr.c: 1363: }
;charge_mgr.c: 1366: if(!hasCharging)
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u9651
	goto	u9650
u9651:
	goto	l7222
u9650:
	goto	l7172
	line	1377
	
l7222:	
;charge_mgr.c: 1371: }
;charge_mgr.c: 1377: if(cvCount == 0)
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u9661
	goto	u9660
u9661:
	goto	l7252
u9660:
	line	1381
	
l7224:	
;charge_mgr.c: 1378: {
;charge_mgr.c: 1379: unsigned char duty_target, duty_initial;
;charge_mgr.c: 1381: if(ccCount > 0)
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u9671
	goto	u9670
u9671:
	goto	l7228
u9670:
	line	1384
	
l7226:	
;charge_mgr.c: 1382: {
;charge_mgr.c: 1384: duty_target = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	1385
;charge_mgr.c: 1385: duty_initial = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	1386
;charge_mgr.c: 1386: }
	goto	l7236
	line	1387
	
l7228:	
;charge_mgr.c: 1387: else if(preCount > 0)
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u9681
	goto	u9680
u9681:
	goto	l7232
u9680:
	line	1390
	
l7230:	
;charge_mgr.c: 1388: {
;charge_mgr.c: 1390: duty_target = 8;
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	1391
;charge_mgr.c: 1391: duty_initial = 5;
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	1392
;charge_mgr.c: 1392: }
	goto	l7236
	line	1397
	
l7232:	
;charge_mgr.c: 1393: else
;charge_mgr.c: 1394: {
;charge_mgr.c: 1397: g_pwmDuty = 25;
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	l834
	line	1401
	
l7236:	
;charge_mgr.c: 1399: }
;charge_mgr.c: 1401: if(g_pwmDuty < duty_initial)
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u9691
	goto	u9690
u9691:
	goto	l7244
u9690:
	line	1404
	
l7238:	
;charge_mgr.c: 1402: {
;charge_mgr.c: 1404: g_pwmDuty += 3;
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	1405
	
l7240:	
;charge_mgr.c: 1405: if(g_pwmDuty > duty_initial)
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u9701
	goto	u9700
u9701:
	goto	l834
u9700:
	line	1406
	
l7242:	
;charge_mgr.c: 1406: g_pwmDuty = duty_initial;
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	l834
	line	1408
	
l7244:	
	line	1411
	
l7246:	
;charge_mgr.c: 1409: {
;charge_mgr.c: 1411: g_pwmDuty = duty_target;
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	1412
;charge_mgr.c: 1412: }
	goto	l834
	line	1427
	
l7252:	
;charge_mgr.c: 1419: }
;charge_mgr.c: 1426: {
;charge_mgr.c: 1427: int error = (int)(3100) - (int)(maxV);
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	1430
;charge_mgr.c: 1430: g_cvIntegral += error * 1;
	movf	(CCCV_Control@error),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral)^080h,f
	skipnc
	incf	(_g_cvIntegral+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(CCCV_Control@error+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral+1)^080h,f
	line	1431
	
l7254:	
;charge_mgr.c: 1431: if(g_cvIntegral > 200)
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u9715
	movlw	0C9h
	subwf	(_g_cvIntegral)^080h,w
u9715:

	skipc
	goto	u9711
	goto	u9710
u9711:
	goto	l7258
u9710:
	line	1432
	
l7256:	
;charge_mgr.c: 1432: g_cvIntegral = 200;
	movlw	0C8h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	l7262
	line	1433
	
l7258:	
;charge_mgr.c: 1433: else if(g_cvIntegral < -200)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u9725
	movlw	038h
	subwf	(_g_cvIntegral)^080h,w
u9725:

	skipnc
	goto	u9721
	goto	u9720
u9721:
	goto	l7262
u9720:
	line	1434
	
l7260:	
;charge_mgr.c: 1434: g_cvIntegral = -200;
	movlw	038h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	movlw	0FFh
	movwf	((_g_cvIntegral)^080h)+1
	line	1437
	
l7262:	
;charge_mgr.c: 1437: int adjust = (error * 4 + g_cvIntegral) / 8;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_cvIntegral)^080h,w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1)^080h,w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	1438
	
l7264:	
;charge_mgr.c: 1438: int duty = (int)g_pwmDuty + adjust;
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
l7266:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	1441
	
l7268:	
;charge_mgr.c: 1441: if(duty > 32) duty = 32;
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u9735
	movlw	021h
	subwf	(CCCV_Control@duty),w
u9735:

	skipc
	goto	u9731
	goto	u9730
u9731:
	goto	l7272
u9730:
	
l7270:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1442
	
l7272:	
;charge_mgr.c: 1442: if(duty < 0) duty = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u9741
	goto	u9740
u9741:
	goto	l7276
u9740:
	
l7274:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1444
	
l7276:	
;charge_mgr.c: 1444: g_pwmDuty = (unsigned char)duty;
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	1446
	
l834:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    2[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    4[COMMON] unsigned char 
;;  product         1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Print_SystemStatus
;;		_Slot_Charge_Ctrl
;;		_CCCV_Control
;;		_Update_LED_Global
;; This function uses a non-reentrant model
;;
psect	text35,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext35
__ptext35:	;psect for function ___bmul
psect	text35
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	movwf	(___bmul@multiplier)
	line	6
	
l6744:	
	clrf	(___bmul@product)
	line	43
	
l6746:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u9041
	goto	u9040
u9041:
	goto	l6750
u9040:
	line	44
	
l6748:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l6750:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l6752:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u9051
	goto	u9050
u9051:
	goto	l6746
u9050:
	line	50
	
l6754:	
	movf	(___bmul@product),w
	line	51
	
l912:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] int 
;;  dividend        2    4[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    8[COMMON] int 
;;  sign            1    7[COMMON] unsigned char 
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text36,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext36
__ptext36:	;psect for function ___awdiv
psect	text36
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 4
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
l6758:	
	clrf	(___awdiv@sign)
	line	15
	
l6760:	
	btfss	(___awdiv@divisor+1),7
	goto	u9061
	goto	u9060
u9061:
	goto	l6766
u9060:
	line	16
	
l6762:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
l6764:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
l6766:	
	btfss	(___awdiv@dividend+1),7
	goto	u9071
	goto	u9070
u9071:
	goto	l6772
u9070:
	line	20
	
l6768:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
l6770:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
l6772:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
l6774:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u9081
	goto	u9080
u9081:
	goto	l6794
u9080:
	line	25
	
l6776:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	l6780
	line	27
	
l6778:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
l6780:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u9091
	goto	u9090
u9091:
	goto	l6778
u9090:
	line	31
	
l6782:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
l6784:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u9105
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u9105:
	skipc
	goto	u9101
	goto	u9100
u9101:
	goto	l6790
u9100:
	line	33
	
l6786:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
l6788:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
l6790:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
l6792:	
	decfsz	(___awdiv@counter),f
	goto	u9111
	goto	u9110
u9111:
	goto	l6782
u9110:
	line	39
	
l6794:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u9121
	goto	u9120
u9121:
	goto	l6798
u9120:
	line	40
	
l6796:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
l6798:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
l1024:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 176 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		_PowerOnLedSequence
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text37,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	176
global __ptext37
__ptext37:	;psect for function _Isr_Timer
psect	text37
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	176
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 1
; Regs used in _Isr_Timer: [wreg+status,2+status,0+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Isr_Timer+0)
	movf	pclath,w
	movwf	(??_Isr_Timer+1)
	ljmp	_Isr_Timer
psect	text37
	line	179
	
i1l5308:	
;main.c: 179: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u654_21
	goto	u654_20
u654_21:
	goto	i1l349
u654_20:
	line	181
	
i1l5310:	
;main.c: 180: {
;main.c: 181: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	182
	
i1l5312:	
;main.c: 182: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(129)^080h	;volatile
	line	183
# 183 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text37
	line	186
	
i1l5314:	
;main.c: 186: g_pwmCounter++;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(_g_pwmCounter)^080h,f	;volatile
	line	187
	
i1l5316:	
;main.c: 187: if(g_pwmCounter >= 32)
	movlw	low(020h)
	subwf	(_g_pwmCounter)^080h,w	;volatile
	skipc
	goto	u655_21
	goto	u655_20
u655_21:
	goto	i1l5320
u655_20:
	line	188
	
i1l5318:	
;main.c: 188: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)^080h	;volatile
	line	190
	
i1l5320:	
;main.c: 190: if(g_pwmDuty > 0 && g_pwmCounter < g_pwmDuty)
	bcf	status, 5	;RP0=0, select bank0
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u656_21
	goto	u656_20
u656_21:
	goto	i1l346
u656_20:
	
i1l5322:	
	movf	(_g_pwmDuty),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_pwmCounter)^080h,w	;volatile
	skipnc
	goto	u657_21
	goto	u657_20
u657_21:
	goto	i1l346
u657_20:
	line	191
	
i1l5324:	
;main.c: 191: RB7 = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(55/8),(55)&7	;volatile
	goto	i1l5326
	line	192
	
i1l346:	
	line	193
;main.c: 192: else
;main.c: 193: RB7 = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(55/8),(55)&7	;volatile
	line	196
	
i1l5326:	
;main.c: 196: if(g_powerOnPhase < 2)
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_powerOnPhase)^080h,w	;volatile
	skipnc
	goto	u658_21
	goto	u658_20
u658_21:
	goto	i1l5332
u658_20:
	line	198
	
i1l5328:	
;main.c: 197: {
;main.c: 198: PowerOnLedSequence();
	fcall	_PowerOnLedSequence
	goto	i1l349
	line	203
	
i1l5332:	
;main.c: 200: }
;main.c: 203: if(g_tempPhase == 0)
	movf	((_g_tempPhase)^080h),w	;volatile
	btfss	status,2
	goto	u659_21
	goto	u659_20
u659_21:
	goto	i1l5344
u659_20:
	line	205
	
i1l5334:	
;main.c: 204: {
;main.c: 205: g_tempReadRoundCnt++;
	incf	(_g_tempReadRoundCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1)^080h,f	;volatile
	line	206
	
i1l5336:	
;main.c: 206: if(g_tempReadRoundCnt >= 200)
	movlw	0
	subwf	(_g_tempReadRoundCnt+1)^080h,w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt)^080h,w	;volatile
	skipc
	goto	u660_21
	goto	u660_20
u660_21:
	goto	i1l5352
u660_20:
	line	208
	
i1l5338:	
;main.c: 207: {
;main.c: 208: g_tempReadRoundCnt = 0;
	clrf	(_g_tempReadRoundCnt)^080h	;volatile
	clrf	(_g_tempReadRoundCnt+1)^080h	;volatile
	line	209
	
i1l5340:	
;main.c: 209: g_tempPhase = 1;
	movlw	low(01h)
	movwf	(_g_tempPhase)^080h	;volatile
	line	210
	
i1l5342:	
;main.c: 210: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	goto	i1l5352
	line	215
	
i1l5344:	
;main.c: 213: else
;main.c: 214: {
;main.c: 215: g_tempSettleCnt++;
	incf	(_g_tempSettleCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1)^080h,f	;volatile
	line	216
	
i1l5346:	
;main.c: 216: if(g_tempSettleCnt >= 60)
	movlw	0
	subwf	(_g_tempSettleCnt+1)^080h,w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt)^080h,w	;volatile
	skipc
	goto	u661_21
	goto	u661_20
u661_21:
	goto	i1l5352
u661_20:
	line	218
	
i1l5348:	
;main.c: 217: {
;main.c: 218: g_doNtcRead = 1;
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	219
	
i1l5350:	
;main.c: 219: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	line	220
;main.c: 220: g_tempPhase = 0;
	clrf	(_g_tempPhase)^080h	;volatile
	line	228
	
i1l5352:	
;main.c: 221: }
;main.c: 222: }
;main.c: 228: if(++g_printTick >= 8000)
	incf	(_g_printTick)^080h,f	;volatile
	skipnz
	incf	(_g_printTick+1)^080h,f	;volatile
	movlw	01Fh
	subwf	((_g_printTick+1)^080h),w	;volatile
	movlw	040h
	skipnz
	subwf	((_g_printTick)^080h),w	;volatile
	skipc
	goto	u662_21
	goto	u662_20
u662_21:
	goto	i1l349
u662_20:
	line	230
	
i1l5354:	
;main.c: 229: {
;main.c: 230: g_printTick = 0;
	clrf	(_g_printTick)^080h	;volatile
	clrf	(_g_printTick+1)^080h	;volatile
	line	231
	
i1l5356:	
;main.c: 231: g_printFlag = 1;
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	235
	
i1l349:	
	movf	(??_Isr_Timer+1),w
	movwf	pclath
	swapf	(??_Isr_Timer+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 80 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text38,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	80
global __ptext38
__ptext38:	;psect for function _PowerOnLedSequence
psect	text38
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	80
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 1
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	82
	
i1l4798:	
;led.c: 82: g_powerOnTimer++;
	incf	(_g_powerOnTimer)^080h,f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1)^080h,f	;volatile
	line	84
	
i1l4800:	
;led.c: 84: if(g_powerOnPhase == 0)
	movf	((_g_powerOnPhase)^080h),w	;volatile
	btfss	status,2
	goto	u567_21
	goto	u567_20
u567_21:
	goto	i1l4810
u567_20:
	line	89
	
i1l4802:	
;led.c: 85: {
;led.c: 89: RC5 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	90
;led.c: 90: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	91
	
i1l4804:	
;led.c: 91: if(g_powerOnTimer >= 8000)
	movlw	01Fh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w	;volatile
	movlw	040h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u568_21
	goto	u568_20
u568_21:
	goto	i1l888
u568_20:
	line	93
	
i1l4806:	
;led.c: 92: {
;led.c: 93: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)^080h	;volatile
	clrf	(_g_powerOnTimer+1)^080h	;volatile
	line	94
	
i1l4808:	
;led.c: 94: g_powerOnPhase = 1;
	movlw	low(01h)
	movwf	(_g_powerOnPhase)^080h	;volatile
	goto	i1l888
	line	97
	
i1l4810:	
;led.c: 97: else if(g_powerOnPhase == 1)
		decf	((_g_powerOnPhase)^080h),w	;volatile
	btfss	status,2
	goto	u569_21
	goto	u569_20
u569_21:
	goto	i1l888
u569_20:
	line	100
	
i1l4812:	
;led.c: 98: {
;led.c: 100: RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	101
;led.c: 101: RC4 = 0;
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	102
	
i1l4814:	
;led.c: 102: if(g_powerOnTimer >= 8000)
	movlw	01Fh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w	;volatile
	movlw	040h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u570_21
	goto	u570_20
u570_21:
	goto	i1l888
u570_20:
	line	104
	
i1l4816:	
;led.c: 103: {
;led.c: 104: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)^080h	;volatile
	clrf	(_g_powerOnTimer+1)^080h	;volatile
	line	105
	
i1l4818:	
;led.c: 105: g_powerOnPhase = 2;
	movlw	low(02h)
	movwf	(_g_powerOnPhase)^080h	;volatile
	line	109
	
i1l888:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
