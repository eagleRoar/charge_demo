opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ChargeProcess_Slot
	FNCALL	_main,_Do_AdcSample
	FNCALL	_main,_Do_NtcRead
	FNCALL	_main,_Print_DetectLog
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_System_Init
	FNCALL	_main,_uart_send_number
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_Print_DetectLog,_uart_send_char
	FNCALL	_Print_DetectLog,_uart_send_number
	FNCALL	_Print_DetectLog,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_Do_NtcRead,_Read_Temperature
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Do_AdcSample,_ADC_Sample
	FNCALL	_Do_AdcSample,___bmul
	FNCALL	_ChargeProcess_Slot,_ADC_Sample
	FNCALL	_ChargeProcess_Slot,_Detect_BatteryType
	FNCALL	_ChargeProcess_Slot,___bmul
	FNCALL	_ChargeProcess_Slot,___lldiv
	FNCALL	_ChargeProcess_Slot,___lmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_CCCV_Control
	FNCALL	_Isr_Timer,_Charging_Control
	FNCALL	_Isr_Timer,_Led_BlinkProcess
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Update_LED_Slot
	FNCALL	_Isr_Timer,i1_ADC_Sample
	FNCALL	_Isr_Timer,i1___bmul
	FNCALL	_Isr_Timer,i1___lldiv
	FNCALL	_Charging_Control,i1___bmul
	FNCALL	_Charging_Control,i1___lwmod
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,i1___bmul
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_vcc_mv
	global	_g_temperature
	global	_g_vccLoaded
	global	_g_impCheckSlot
psect	idataBANK0,class=CODE,space=0,delta=2,noexec
global __pidataBANK0
__pidataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	15

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	12

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	16

;initializer for _g_vccLoaded
	retlw	088h
	retlw	013h

	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	23

;initializer for _g_impCheckSlot
	retlw	0FFh
	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	48
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_powerOnTimer
	global	_g_dbgDetectFlag
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_adcBusy
	global	_g_doAdcSample
	global	_g_detectLogFlag
	global	_g_cvIntegral
	global	_g_ccCycle
	global	_g_vccProtect
	global	_g_tempProtect
	global	_g_dbgNewType
	global	_g_dbgNewState
	global	_g_dbgOldState
	global	_g_dbgSlot
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_tempPhase
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_scanPhase
	global	_g_scanIndex
	global	_g_detectLogType
	global	_g_detectLogSlot
	global	_test_adc
	global	_g_blinkTick
	global	_adresult
	global	_g_highVFlag
	global	_g_impData
	global	_g_capFlag
	global	_g_printTick
	global	_g_slot
	global	_g_slotRefV
	global	_g_detectLowCnt
	global	_g_ovCnt
	global	_g_ccBlocks
	global	ChargeProcess_Slot@s_oldSt
	global	_g_dbgVoltage
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_GIE
_GIE	set	0x5F
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RC4
_RC4	set	0x834
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC5
_RC5	set	0x835
	global	_RC3
_RC3	set	0x833
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_34:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_35:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_33:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_36:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	45	;'-'
	retlw	105	;'i'
	retlw	111	;'o'
	retlw	110	;'n'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_8:	
	retlw	67	;'C'
	retlw	32	;' '
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	95	;'_'
	retlw	76	;'L'
	retlw	79	;'O'
	retlw	67	;'C'
	retlw	75	;'K'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_38:	
	retlw	68	;'D'
	retlw	66	;'B'
	retlw	71	;'G'
	retlw	58	;':'
	retlw	32	;' '
	retlw	115	;'s'
	retlw	108	;'l'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_37:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_11:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_39:	
	retlw	32	;' '
	retlw	111	;'o'
	retlw	108	;'l'
	retlw	100	;'d'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_29:	
	retlw	32	;' '
	retlw	98	;'b'
	retlw	108	;'l'
	retlw	107	;'k'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_40:	
	retlw	32	;' '
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	119	;'w'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_25:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	73	;'I'
	retlw	79	;'O'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_23:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_27:	
	retlw	32	;' '
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_42:	
	retlw	32	;' '
	retlw	86	;'V'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
	
STR_30:	
	retlw	47	;'/'
	retlw	0
psect	stringtext
STR_41	equ	STR_28+0
STR_7	equ	STR_2+0
STR_9	equ	STR_37+7
STR_31	equ	STR_37+7
STR_32	equ	STR_37+7
STR_43	equ	STR_37+7
; #config settings
	file	"SC8P096_timer_C.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_g_dbgDetectFlag:
       ds      1

_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

_g_adcBusy:
       ds      1

_g_doAdcSample:
       ds      1

_g_detectLogFlag:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_g_powerOnTimer:
       ds      2

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_cvIntegral:
       ds      2

_g_ccCycle:
       ds      1

_g_vccProtect:
       ds      1

_g_tempProtect:
       ds      1

_g_dbgNewType:
       ds      1

_g_dbgNewState:
       ds      1

_g_dbgOldState:
       ds      1

_g_dbgSlot:
       ds      1

_g_tempReadRoundCnt:
       ds      1

_g_tempSettleCnt:
       ds      1

_g_tempPhase:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_scanPhase:
       ds      1

_g_scanIndex:
       ds      1

_g_detectLogType:
       ds      1

_g_detectLogSlot:
       ds      1

_test_adc:
       ds      1

_g_blinkTick:
       ds      1

_adresult:
       ds      2

psect	dataBANK0,class=BANK0,space=1,noexec
global __pdataBANK0
__pdataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	15
_g_vcc_mv:
       ds      2

psect	dataBANK0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	12
_g_temperature:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_highVFlag:
       ds      2

_g_impData:
       ds      2

_g_capFlag:
       ds      2

_g_printTick:
       ds      2

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	16
_g_vccLoaded:
       ds      2

psect	dataBANK1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	23
_g_impCheckSlot:
       ds      1

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slotRefV:
       ds      24

_g_detectLowCnt:
       ds      12

_g_ovCnt:
       ds      12

_g_ccBlocks:
       ds      12

ChargeProcess_Slot@s_oldSt:
       ds      6

_g_dbgVoltage:
       ds      2

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"SC8P096_timer_C.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
	fcall	__pidataBANK1+2		;fetch initializer
	movwf	__pdataBANK1+2&07fh		
; Initialize objects allocated to BANK0
	global __pidataBANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	fcall	__pidataBANK0+0		;fetch initializer
	movwf	__pdataBANK0+0&07fh		
	fcall	__pidataBANK0+1		;fetch initializer
	movwf	__pdataBANK0+1&07fh		
	fcall	__pidataBANK0+2		;fetch initializer
	movwf	__pdataBANK0+2&07fh		
	fcall	__pidataBANK0+3		;fetch initializer
	movwf	__pdataBANK0+3&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+044h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+08h)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+017h)
	fcall	clear_ram0
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
	clrf	((__pbssCOMMON)+1)&07Fh
; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK3,class=BANK3,space=1,noexec
global __pcstackBANK3
__pcstackBANK3:
	global	ChargeProcess_Slot@bat_mv
ChargeProcess_Slot@bat_mv:	; 2 bytes @ 0x0
	ds	2
	global	ChargeProcess_Slot@bat_mv_400
ChargeProcess_Slot@bat_mv_400:	; 2 bytes @ 0x2
	ds	2
	global	ChargeProcess_Slot@bat_mv_403
ChargeProcess_Slot@bat_mv_403:	; 2 bytes @ 0x4
	ds	2
	global	ChargeProcess_Slot@bat_mv_406
ChargeProcess_Slot@bat_mv_406:	; 2 bytes @ 0x6
	ds	2
	global	ChargeProcess_Slot@pre_v
ChargeProcess_Slot@pre_v:	; 2 bytes @ 0x8
	ds	2
	global	ChargeProcess_Slot@pre
ChargeProcess_Slot@pre:	; 2 bytes @ 0xA
	ds	2
psect	cstackBANK2,class=BANK2,space=1,noexec
global __pcstackBANK2
__pcstackBANK2:
	global	ChargeProcess_Slot@ct
ChargeProcess_Slot@ct:	; 2 bytes @ 0x0
	ds	2
	global	ChargeProcess_Slot@ty
ChargeProcess_Slot@ty:	; 1 bytes @ 0x2
	ds	1
	global	ChargeProcess_Slot@v
ChargeProcess_Slot@v:	; 2 bytes @ 0x3
	ds	2
	global	ChargeProcess_Slot@idx
ChargeProcess_Slot@idx:	; 1 bytes @ 0x5
	ds	1
??_main:	; 1 bytes @ 0x6
	ds	2
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
?_ADC_Sample:	; 1 bytes @ 0x0
?_Detect_BatteryType:	; 1 bytes @ 0x0
?___bmul:	; 1 bytes @ 0x0
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x0
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x0
	global	?___lmul
?___lmul:	; 4 bytes @ 0x0
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x0
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x0
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x0
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x0
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x0
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x0
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x0
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x1
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x1
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x1
	ds	1
?_uart_send_string:	; 1 bytes @ 0x2
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x2
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x2
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x2
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x2
	ds	2
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x4
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x4
	ds	1
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x5
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x5
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x6
	ds	1
?_uart_send_number:	; 1 bytes @ 0x7
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x7
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x7
	ds	1
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x8
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x8
	ds	1
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x9
	ds	3
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0xC
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0xC
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0xC
	ds	2
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0xE
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0xF
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x10
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0x10
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x10
	ds	1
	global	_Print_NtcTemp$767
_Print_NtcTemp$767:	; 2 bytes @ 0x11
	ds	1
	global	Do_AdcSample@ch
Do_AdcSample@ch:	; 1 bytes @ 0x12
	ds	1
	global	Do_AdcSample@ty
Do_AdcSample@ty:	; 1 bytes @ 0x13
	global	_Print_NtcTemp$768
_Print_NtcTemp$768:	; 2 bytes @ 0x13
	ds	1
	global	Do_AdcSample@dly
Do_AdcSample@dly:	; 1 bytes @ 0x14
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x14
	ds	1
	global	Do_AdcSample@st
Do_AdcSample@st:	; 1 bytes @ 0x15
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x15
	ds	4
??_Read_Temperature:	; 1 bytes @ 0x19
??_ChargeProcess_Slot:	; 1 bytes @ 0x19
??_Print_SystemStatus:	; 1 bytes @ 0x19
	ds	4
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x1D
	ds	1
	global	ChargeProcess_Slot@v_init
ChargeProcess_Slot@v_init:	; 2 bytes @ 0x1E
	ds	2
	global	ChargeProcess_Slot@vx_mv
ChargeProcess_Slot@vx_mv:	; 4 bytes @ 0x20
	ds	1
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x21
	global	_Print_SystemStatus$769
_Print_SystemStatus$769:	; 2 bytes @ 0x21
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x23
	global	_Print_SystemStatus$770
_Print_SystemStatus$770:	; 2 bytes @ 0x23
	ds	1
	global	ChargeProcess_Slot@bat_mv_long
ChargeProcess_Slot@bat_mv_long:	; 4 bytes @ 0x24
	ds	1
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x25
	ds	3
	global	ChargeProcess_Slot@vx_mv_398
ChargeProcess_Slot@vx_mv_398:	; 4 bytes @ 0x28
	ds	1
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x29
	ds	1
	global	_Print_SystemStatus$286
_Print_SystemStatus$286:	; 2 bytes @ 0x2A
	ds	2
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x2C
	global	ChargeProcess_Slot@bat_mv_long_399
ChargeProcess_Slot@bat_mv_long_399:	; 4 bytes @ 0x2C
	ds	2
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0x2E
	ds	2
	global	ChargeProcess_Slot@vx_mv_401
ChargeProcess_Slot@vx_mv_401:	; 4 bytes @ 0x30
	ds	2
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0x32
	ds	2
	global	ChargeProcess_Slot@bat_mv_long_402
ChargeProcess_Slot@bat_mv_long_402:	; 4 bytes @ 0x34
	ds	2
	global	Print_SystemStatus@t
Print_SystemStatus@t:	; 1 bytes @ 0x36
	ds	1
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x37
	ds	1
	global	ChargeProcess_Slot@vx_mv_404
ChargeProcess_Slot@vx_mv_404:	; 4 bytes @ 0x38
	ds	1
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x39
	ds	3
	global	ChargeProcess_Slot@bat_mv_long_405
ChargeProcess_Slot@bat_mv_long_405:	; 4 bytes @ 0x3C
	ds	4
	global	_ChargeProcess_Slot$408
_ChargeProcess_Slot$408:	; 2 bytes @ 0x40
	ds	2
	global	ChargeProcess_Slot@v_ref
ChargeProcess_Slot@v_ref:	; 2 bytes @ 0x42
	ds	2
	global	ChargeProcess_Slot@st
ChargeProcess_Slot@st:	; 1 bytes @ 0x44
	ds	1
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Update_LED_Slot:	; 1 bytes @ 0x0
??_Update_LED_Slot:	; 1 bytes @ 0x0
?_Charging_Control:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Led_BlinkProcess:	; 1 bytes @ 0x0
??_Led_BlinkProcess:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_ChargeProcess_Slot:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Do_AdcSample:	; 1 bytes @ 0x0
?_Do_NtcRead:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_Print_DetectLog:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?i1_ADC_Sample:	; 1 bytes @ 0x0
?i1___bmul:	; 1 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	?i1___lwmod
?i1___lwmod:	; 2 bytes @ 0x0
	global	?i1___lldiv
?i1___lldiv:	; 4 bytes @ 0x0
Update_LED_Slot@idx:	; 1 bytes @ 0x0
	global	i1ADC_Sample@adldo
i1ADC_Sample@adldo:	; 1 bytes @ 0x0
	global	i1___bmul@multiplicand
i1___bmul@multiplicand:	; 1 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	global	i1___lwmod@divisor
i1___lwmod@divisor:	; 2 bytes @ 0x0
	global	i1___lldiv@divisor
i1___lldiv@divisor:	; 4 bytes @ 0x0
	ds	1
??i1_ADC_Sample:	; 1 bytes @ 0x1
??i1___bmul:	; 1 bytes @ 0x1
	global	i1___bmul@multiplier
i1___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
	global	i1___bmul@product
i1___bmul@product:	; 1 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	global	i1___lwmod@dividend
i1___lwmod@dividend:	; 2 bytes @ 0x2
	ds	2
??___awdiv:	; 1 bytes @ 0x4
??i1___lwmod:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	global	i1___lwmod@counter
i1___lwmod@counter:	; 1 bytes @ 0x4
	global	i1___lldiv@dividend
i1___lldiv@dividend:	; 4 bytes @ 0x4
	ds	1
??_Charging_Control:	; 1 bytes @ 0x5
	global	Charging_Control@chargeB1_6
Charging_Control@chargeB1_6:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	ds	1
	global	Charging_Control@chargeB7_12
Charging_Control@chargeB7_12:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	1
	global	Charging_Control@s
Charging_Control@s:	; 1 bytes @ 0x7
	ds	1
??_CCCV_Control:	; 1 bytes @ 0x8
??i1___lldiv:	; 1 bytes @ 0x8
	global	Charging_Control@i
Charging_Control@i:	; 1 bytes @ 0x8
	ds	2
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	i1ADC_Sample@adch
i1ADC_Sample@adch:	; 1 bytes @ 0x0
	global	i1___lldiv@counter
i1___lldiv@counter:	; 1 bytes @ 0x0
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x0
	ds	1
	global	i1ADC_Sample@j
i1ADC_Sample@j:	; 1 bytes @ 0x1
	global	i1___lldiv@quotient
i1___lldiv@quotient:	; 4 bytes @ 0x1
	ds	1
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x2
	global	i1ADC_Sample@i
i1ADC_Sample@i:	; 1 bytes @ 0x2
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x3
	global	i1ADC_Sample@adsum
i1ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0x4
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0x5
	ds	1
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x6
	ds	1
	global	i1ADC_Sample@admin
i1ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x8
	ds	1
	global	i1ADC_Sample@admax
i1ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	1
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xA
	ds	1
	global	i1ADC_Sample@ad_temp
i1ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0xC
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0xD
	ds	1
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0xE
	ds	2
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x10
	ds	1
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x11
	ds	1
??_Isr_Timer:	; 1 bytes @ 0x12
	ds	4
	global	Isr_Timer@pt
Isr_Timer@pt:	; 4 bytes @ 0x16
	ds	4
??_AD_Init:	; 1 bytes @ 0x1A
??_uart_init:	; 1 bytes @ 0x1A
??_uart_send_char:	; 1 bytes @ 0x1A
??_System_Init:	; 1 bytes @ 0x1A
??_Do_AdcSample:	; 1 bytes @ 0x1A
??_Do_NtcRead:	; 1 bytes @ 0x1A
??_Detect_BatteryType:	; 1 bytes @ 0x1A
??___lmul:	; 1 bytes @ 0x1A
??___bmul:	; 1 bytes @ 0x1A
??___lldiv:	; 1 bytes @ 0x1A
??___lwdiv:	; 1 bytes @ 0x1A
??___lwmod:	; 1 bytes @ 0x1A
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x1A
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x1A
	ds	1
??_uart_send_string:	; 1 bytes @ 0x1B
??_uart_send_number:	; 1 bytes @ 0x1B
??_Print_NtcTemp:	; 1 bytes @ 0x1B
??_Print_DetectLog:	; 1 bytes @ 0x1B
;!
;!Data Sizes:
;!    Strings     369
;!    Constant    12
;!    Data        7
;!    BSS         173
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     10      13
;!    BANK0            80     27      54
;!    BANK1            80     69      80
;!    BANK3            80     12      80
;!    BANK2            80      8      80

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 37
;!		 -> STR_43(CODE[3]), STR_42(CODE[4]), STR_41(CODE[5]), STR_40(CODE[6]), 
;!		 -> STR_39(CODE[6]), STR_38(CODE[11]), STR_37(CODE[10]), STR_36(CODE[21]), 
;!		 -> STR_35(CODE[34]), STR_34(CODE[37]), STR_33(CODE[33]), STR_32(CODE[3]), 
;!		 -> STR_31(CODE[3]), STR_30(CODE[2]), STR_29(CODE[6]), STR_28(CODE[5]), 
;!		 -> STR_27(CODE[5]), STR_26(CODE[6]), STR_25(CODE[6]), STR_24(CODE[6]), 
;!		 -> STR_23(CODE[6]), STR_22(CODE[16]), STR_21(CODE[13]), STR_20(CODE[15]), 
;!		 -> STR_19(CODE[7]), STR_18(CODE[5]), STR_17(CODE[5]), STR_16(CODE[6]), 
;!		 -> STR_15(CODE[6]), STR_14(CODE[6]), STR_13(CODE[7]), STR_12(CODE[4]), 
;!		 -> STR_11(CODE[6]), STR_10(CODE[6]), STR_9(CODE[3]), STR_8(CODE[12]), 
;!		 -> STR_7(CODE[2]), STR_6(CODE[6]), STR_5(CODE[5]), STR_4(CODE[29]), 
;!		 -> STR_3(CODE[4]), STR_2(CODE[2]), STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->_CCCV_Control
;!    _Charging_Control->i1___lwmod
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Do_AdcSample
;!    _main->_System_Init
;!    _Print_SystemStatus->___lwmod
;!    _Print_SystemStatus->_uart_send_char
;!    _Print_NtcTemp->___lwmod
;!    _Print_DetectLog->_uart_send_char
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwmod
;!    _uart_send_number->_uart_send_char
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    _Isr_Timer->_CCCV_Control
;!
;!Critical Paths under _main in BANK1
;!
;!    _main->_ChargeProcess_Slot
;!    _System_Init->___bmul
;!    _Print_SystemStatus->___lldiv
;!    _Print_NtcTemp->_uart_send_number
;!    _Print_DetectLog->_uart_send_number
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _Do_NtcRead->_Read_Temperature
;!    _Read_Temperature->___lldiv
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->___lldiv
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    _main->_ChargeProcess_Slot
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    _main->_ChargeProcess_Slot
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 2     2      0   75223
;!                                              6 BANK2      2     2      0
;!                 _ChargeProcess_Slot
;!                       _Do_AdcSample
;!                         _Do_NtcRead
;!                    _Print_DetectLog
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                        _System_Init
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1643
;!                                             26 BANK0      1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  33    33      0   17664
;!                                             25 BANK1     33    33      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    8766
;!                                             17 BANK1      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_DetectLog                                      0     0      0    7450
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    3631
;!                                              2 BANK1      2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_number                                    10     8      2    3675
;!                                              7 BANK1     10     8      2
;!                             ___bmul (ARG)
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     144
;!                                             26 BANK0      1     1      0
;!                                              0 BANK1      2     2      0
;! ---------------------------------------------------------------------------------
;! (2) ___lwmod                                              5     1      4     584
;!                                             26 BANK0      1     1      0
;!                                              0 BANK1      4     0      4
;! ---------------------------------------------------------------------------------
;! (1) _Do_NtcRead                                           0     0      0    7485
;!                   _Read_Temperature
;! ---------------------------------------------------------------------------------
;! (2) _Read_Temperature                                    12    12      0    7485
;!                                             25 BANK1     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (2) ___lwdiv                                              7     3      4     852
;!                                              0 BANK1      7     3      4
;! ---------------------------------------------------------------------------------
;! (1) _Do_AdcSample                                         5     5      0    2786
;!                                             26 BANK0      1     1      0
;!                                             18 BANK1      4     4      0
;!                         _ADC_Sample
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _ChargeProcess_Slot                                  62    62      0   22123
;!                                             25 BANK1     44    44      0
;!                                              0 BANK3     12    12      0
;!                                              0 BANK2      6     6      0
;!                         _ADC_Sample
;!                 _Detect_BatteryType
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8    3236
;!                                              0 BANK1     12     4      8
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1712
;!                                             12 BANK1     13     5      8
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1    1295
;!                                              0 BANK1      3     2      1
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     331
;!                                              0 BANK1      2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _ADC_Sample                                          18    17      1    1125
;!                                              0 BANK1     18    17      1
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 2
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            8     8      0    4307
;!                                             18 BANK0      8     8      0
;!                       _CCCV_Control
;!                   _Charging_Control
;!                   _Led_BlinkProcess
;!                 _PowerOnLedSequence
;!                    _Update_LED_Slot
;!                       i1_ADC_Sample
;!                           i1___bmul
;!                          i1___lldiv
;! ---------------------------------------------------------------------------------
;! (5) i1___lldiv                                           13     5      8      44
;!                                              0 COMMON     8     0      8
;!                                              0 BANK0      5     5      0
;! ---------------------------------------------------------------------------------
;! (5) i1_ADC_Sample                                        18    17      1     551
;!                                              0 COMMON     5     4      1
;!                                              0 BANK0     13    13      0
;! ---------------------------------------------------------------------------------
;! (5) _Update_LED_Slot                                      1     1      0       0
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Led_BlinkProcess                                     0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Charging_Control                                     4     4      0    1374
;!                                              5 COMMON     4     4      0
;!                           i1___bmul
;!                          i1___lwmod
;! ---------------------------------------------------------------------------------
;! (6) i1___lwmod                                            5     1      4     233
;!                                              0 COMMON     5     1      4
;! ---------------------------------------------------------------------------------
;! (5) _CCCV_Control                                        20    20      0    2127
;!                                              8 COMMON     2     2      0
;!                                              0 BANK0     18    18      0
;!                            ___awdiv
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) i1___bmul                                             3     2      1     163
;!                                              0 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (6) ___awdiv                                              8     4      4     428
;!                                              0 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ChargeProcess_Slot
;!     _ADC_Sample
;!     _Detect_BatteryType
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!   _Do_AdcSample
;!     _ADC_Sample
;!     ___bmul
;!   _Do_NtcRead
;!     _Read_Temperature
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!       ___lwdiv
;!   _Print_DetectLog
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _uart_send_number
;!     ___bmul (ARG)
;!     ___lwdiv (ARG)
;!     ___lwmod (ARG)
;!     _uart_send_char (ARG)
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     i1___bmul
;!   _Charging_Control
;!     i1___bmul
;!     i1___lwmod
;!   _Led_BlinkProcess
;!   _PowerOnLedSequence
;!   _Update_LED_Slot
;!   i1_ADC_Sample
;!   i1___bmul
;!   i1___lldiv
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50      C      50       8      100.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      8      50      10      100.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50     45      50       6      100.0%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     1B      36       4       67.5%
;!BITBANK0            50      0       0       3        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      A       D       1       92.9%
;!BITCOMMON            E      0       1       0        7.1%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     133      12        0.0%
;!ABS                  0      0     133      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 519 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       2
;;      Totals:         0       0       0       0       2
;;Total ram usage:        2 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ChargeProcess_Slot
;;		_Do_AdcSample
;;		_Do_NtcRead
;;		_Print_DetectLog
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_System_Init
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	519
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	519
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	522
	
l8601:	
;main.c: 522: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
movwf	((??_main+0)^0100h+0+1),f
	movlw	241
movwf	((??_main+0)^0100h+0),f
	u13237:
decfsz	((??_main+0)^0100h+0),f
	goto	u13237
	decfsz	((??_main+0)^0100h+0+1),f
	goto	u13237
opt asmopt_pop

	line	523
# 523 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	526
	
l8603:	
;main.c: 526: System_Init();
	fcall	_System_Init
	line	529
	
l8605:	
;main.c: 529: uart_send_string("L1211 Charger V2.1\r\n");
	movlw	low(((STR_36)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_36)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	530
	
l8607:	
;main.c: 530: uart_send_string("Init...\r\n");
	movlw	low(((STR_37)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_37)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	533
;main.c: 533: while(1)
	
l476:	
	line	535
# 535 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	538
	
l8609:	
;main.c: 538: if(g_doAdcSample)
	btfss	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u13181
	goto	u13180
u13181:
	goto	l8639
u13180:
	line	540
	
l8611:	
;main.c: 539: {
;main.c: 540: g_doAdcSample = 0;
	bcf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	line	541
;main.c: 541: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	542
	
l8613:	
;main.c: 542: Do_AdcSample();
	fcall	_Do_AdcSample
	line	543
	
l8615:	
;main.c: 543: ChargeProcess_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_ChargeProcess_Slot
	line	546
	
l8617:	
;main.c: 546: if(g_dbgDetectFlag)
	btfss	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	goto	u13191
	goto	u13190
u13191:
	goto	l8637
u13190:
	line	548
	
l8619:	
;main.c: 547: {
;main.c: 548: g_dbgDetectFlag = 0;
	bcf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	549
	
l8621:	
;main.c: 549: uart_send_string("DBG: slot=");
	movlw	low(((STR_38)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_38)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	550
	
l8623:	
;main.c: 550: uart_send_number(g_dbgSlot);
	movf	(_g_dbgSlot),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	551
	
l8625:	
;main.c: 551: uart_send_string(" old=");
	movlw	low(((STR_39)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_39)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	552
;main.c: 552: uart_send_number(g_dbgOldState);
	movf	(_g_dbgOldState),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	553
	
l8627:	
;main.c: 553: uart_send_string(" new=");
	movlw	low(((STR_40)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_40)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	554
	
l8629:	
;main.c: 554: uart_send_number(g_dbgNewState);
	movf	(_g_dbgNewState),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	555
;main.c: 555: uart_send_string(" ty=");
	movlw	low(((STR_41)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_41)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	556
	
l8631:	
;main.c: 556: uart_send_number(g_dbgNewType);
	movf	(_g_dbgNewType),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	557
	
l8633:	
;main.c: 557: uart_send_string(" V=");
	movlw	low(((STR_42)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_42)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	558
;main.c: 558: uart_send_number(g_dbgVoltage);
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(_g_dbgVoltage+1)^0180h,w	;volatile
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(_g_dbgVoltage)^0180h,w	;volatile
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	559
	
l8635:	
;main.c: 559: uart_send_string("\r\n");
	movlw	low(((STR_43)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_43)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	562
	
l8637:	
;main.c: 560: }
;main.c: 562: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	566
	
l8639:	
;main.c: 563: }
;main.c: 566: if(g_doNtcRead)
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u13201
	goto	u13200
u13201:
	goto	l8647
u13200:
	line	568
	
l8641:	
;main.c: 567: {
;main.c: 568: g_doNtcRead = 0;
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	569
;main.c: 569: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	570
	
l8643:	
;main.c: 570: Do_NtcRead();
	fcall	_Do_NtcRead
	line	571
	
l8645:	
;main.c: 571: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	575
	
l8647:	
;main.c: 572: }
;main.c: 575: if(g_printFlag)
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u13211
	goto	u13210
u13211:
	goto	l8653
u13210:
	line	577
	
l8649:	
;main.c: 576: {
;main.c: 577: g_printFlag = 0;
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	578
	
l8651:	
;main.c: 578: Print_SystemStatus();
	fcall	_Print_SystemStatus
	line	579
;main.c: 579: Print_NtcTemp();
	fcall	_Print_NtcTemp
	line	583
	
l8653:	
;main.c: 580: }
;main.c: 583: if(g_detectLogFlag)
	btfss	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	goto	u13221
	goto	u13220
u13221:
	goto	l476
u13220:
	line	585
	
l8655:	
;main.c: 584: {
;main.c: 585: g_detectLogFlag = 0;
	bcf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	line	586
	
l8657:	
;main.c: 586: Print_DetectLog();
	fcall	_Print_DetectLog
	goto	l476
	global	start
	ljmp	start
	opt stack 0
	line	589
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 69 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   26[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	69
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	69
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	74
	
l7171:	
# 74 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	75
# 75 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text1
	line	76
	
l7173:	
;main.c: 76: OSCCON = 0x72;
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	80
;main.c: 80: TRISA = 0xF0; PORTA = 0x0F;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	81
;main.c: 81: TRISB = 0x30; PORTB = 0x4F;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	82
;main.c: 82: TRISC = 0x07; PORTC = 0x00;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l7175:	
	clrf	(262)^0100h	;volatile
	line	83
	
l7177:	
;main.c: 83: TRISD = 0xF0; PORTD = 0x0F;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l7179:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	86
	
l7181:	
;main.c: 86: WPUA = 0x00; WPDA = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l7183:	
	clrf	(135)^080h	;volatile
	line	87
	
l7185:	
;main.c: 87: WPUB = 0x00; WPDB = 0x00;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l7187:	
	clrf	(7)	;volatile
	line	88
	
l7189:	
;main.c: 88: WPUC = 0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	89
	
l7191:	
;main.c: 89: WPUD = 0x00;
	clrf	(277)^0100h	;volatile
	line	92
	
l7193:	
;main.c: 92: IOCA = 0x00; IOCB = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l7195:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	95
	
l7197:	
;main.c: 95: CC0CON = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	96
	
l7199:	
;main.c: 96: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	103
	
l7201:	
;main.c: 103: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	104
	
l7203:	
;main.c: 104: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	105
	
l7205:	
;main.c: 105: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	106
	
l7207:	
;main.c: 106: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	109
	
l7209:	
;main.c: 109: AD_Init();
	fcall	_AD_Init
	line	112
	
l7211:	
;main.c: 112: uart_init();
	fcall	_uart_init
	line	119
;main.c: 119: OPTION_REG = 0x00;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	120
	
l7213:	
;main.c: 120: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	121
	
l7215:	
;main.c: 121: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	122
	
l7217:	
;main.c: 122: INTCON = 0xE0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	125
;main.c: 125: g_pwmDuty = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	126
;main.c: 126: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	127
	
l7219:	
;main.c: 127: RC3 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	128
	
l7221:	
;main.c: 128: RC5 = 0;
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	129
	
l7223:	
;main.c: 129: RB6 = 1;
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	130
	
l7225:	
;main.c: 130: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	133
;main.c: 133: for(i = 0; i < 12; i++)
	clrf	(System_Init@i)
	line	135
	
l7231:	
;main.c: 134: {
;main.c: 135: g_slot[i].state = 0;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	136
;main.c: 136: g_slot[i].type = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	137
;main.c: 137: g_slot[i].voltage = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	138
;main.c: 138: g_slot[i].chargeTimer = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	139
	
l7233:	
;main.c: 139: g_ccBlocks[i] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	140
	
l7235:	
;main.c: 140: g_ovCnt[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	133
	
l7237:	
	incf	(System_Init@i),f
	
l7239:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u10541
	goto	u10540
u10541:
	goto	l7231
u10540:
	line	142
	
l7241:	
;main.c: 141: }
;main.c: 142: g_blinkTick = 0;
	clrf	(_g_blinkTick)
	line	145
	
l363:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
global __ptext2
__ptext2:	;psect for function _uart_init
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_init: []
	line	23
	
l7049:	
;uart_dbg.c: 23: TRISC &= (unsigned char)~0x10;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
;uart_dbg.c: 24: ANSEL2 &= (unsigned char)~0x10;
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
;uart_dbg.c: 25: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l514:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
global __ptext3
__ptext3:	;psect for function _AD_Init
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l7043:	
;adc_drv.c: 25: CC0CON = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
;adc_drv.c: 26: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	27
	
l7045:	
;adc_drv.c: 27: ADCON0 = 0X81;
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l7047:	
;adc_drv.c: 28: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	29
	
l491:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 365 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  t               1   54[BANK1 ] unsigned char 
;;  bat_mv_long     4   50[BANK1 ] unsigned long 
;;  vx_mv           4   46[BANK1 ] unsigned long 
;;  v               2   44[BANK1 ] unsigned int 
;;  s               1   41[BANK1 ] unsigned char 
;;  pt              4   37[BANK1 ] unsigned long 
;;  vcc_mv          2   55[BANK1 ] unsigned int 
;;  i               1   57[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      25       0       0
;;      Temps:          0       0       8       0       0
;;      Totals:         0       0      33       0       0
;;Total ram usage:       33 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	365
global __ptext4
__ptext4:	;psect for function _Print_SystemStatus
psect	text4
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	365
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	370
	
l7495:	
;main.c: 367: unsigned char i;
;main.c: 368: unsigned int vcc_mv;
;main.c: 370: uart_send_string("\r\n== L1211 12CH CHARGER ==\r\n");
	movlw	low(((STR_4)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	373
	
l7497:	
;main.c: 373: test_adc = ADC_Sample(31, 0);
	bsf	status, 5	;RP0=1, select bank1
	clrf	(ADC_Sample@adldo)^080h
	movlw	low(01Fh)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	374
	
l7499:	
;main.c: 374: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u11051
	goto	u11050
u11051:
	goto	l7505
u11050:
	line	376
	
l7501:	
;main.c: 375: {
;main.c: 376: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt)^080h

	line	377
	
l7503:	
;main.c: 377: vcc_mv = (unsigned int)pt;
	movf	(Print_SystemStatus@pt+1)^080h,w
	movwf	(Print_SystemStatus@vcc_mv+1)^080h
	movf	(Print_SystemStatus@pt)^080h,w
	movwf	(Print_SystemStatus@vcc_mv)^080h
	line	378
;main.c: 378: }
	goto	l431
	line	380
	
l7505:	
;main.c: 379: else
;main.c: 380: vcc_mv = 5000;
	movlw	088h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vcc_mv)^080h
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv)^080h)+1
	
l431:	
	line	382
;main.c: 382: g_vcc_mv = vcc_mv;
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_vcc_mv+1)	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_vcc_mv)	;volatile
	line	384
	
l7507:	
;main.c: 384: uart_send_string("VCC=");
	movlw	low(((STR_5)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	385
	
l7509:	
;main.c: 385: uart_send_number(vcc_mv);
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	386
	
l7511:	
;main.c: 386: uart_send_string("mV T=");
	movlw	low(((STR_6)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	387
	
l7513:	
;main.c: 387: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(_Print_SystemStatus$769+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(_Print_SystemStatus$769)^080h
	
l7515:	
;main.c: 387: uart_send_number(g_temperature / 10U);
	movf	(_Print_SystemStatus$769+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$769)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	388
	
l7517:	
;main.c: 388: uart_send_string(".");
	movlw	low(((STR_7)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	389
	
l7519:	
;main.c: 389: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@divisor)^080h
	clrf	(___lwmod@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend)^080h
	fcall	___lwmod
	movf	(1+(?___lwmod))^080h,w
	movwf	(_Print_SystemStatus$770+1)^080h
	movf	(0+(?___lwmod))^080h,w
	movwf	(_Print_SystemStatus$770)^080h
	
l7521:	
;main.c: 389: uart_send_number(g_temperature % 10U);
	movf	(_Print_SystemStatus$770+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$770)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	390
	
l7523:	
;main.c: 390: uart_send_string("C IMP_LOCK=");
	movlw	low(((STR_8)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	391
	
l7525:	
;main.c: 391: uart_send_number(g_impCheckSlot == 0xFF ? 0xFFU : (unsigned int)g_impCheckSlot);
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u11061
	goto	u11060
u11061:
	goto	l7529
u11060:
	
l7527:	
	movf	(_g_impCheckSlot)^080h,w
	movwf	(_Print_SystemStatus$286)^080h
	clrf	(_Print_SystemStatus$286+1)^080h
	goto	l7531
	
l7529:	
	movlw	0FFh
	movwf	(_Print_SystemStatus$286)^080h
	clrf	(_Print_SystemStatus$286+1)^080h
	
l7531:	
	movf	(_Print_SystemStatus$286+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$286)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	392
	
l7533:	
;main.c: 392: uart_send_string("\r\n");
	movlw	low(((STR_9)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	396
	
l7535:	
;main.c: 396: for(i = 0; i < 6; i++)
	bsf	status, 5	;RP0=1, select bank1
	clrf	(Print_SystemStatus@i)^080h
	line	405
	
l7541:	
;main.c: 404: {
;main.c: 405: unsigned int v = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Print_SystemStatus@v)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)^080h
	line	406
;main.c: 406: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Print_SystemStatus@s)^080h
	line	413
	
l7543:	
;main.c: 413: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	414
	
l7545:	
;main.c: 414: uart_send_number((unsigned int)i + 1U);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	incf	(uart_send_number@num)^080h,f
	skipnz
	incf	(uart_send_number@num+1)^080h,f
	fcall	_uart_send_number
	line	415
;main.c: 415: uart_send_char('=');
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	416
	
l7547:	
;main.c: 416: uart_send_number(v);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(Print_SystemStatus@v)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	422
	
l7549:	
;main.c: 421: {
;main.c: 422: unsigned long vx_mv = (unsigned long)v * (unsigned long)vcc_mv / 4096UL;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Print_SystemStatus@v+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(___lmul@multiplicand)^080h
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv)^080h

	
l7551:	
	movlw	0Ch
u11075:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3)^080h,f
	rrf	(Print_SystemStatus@vx_mv+2)^080h,f
	rrf	(Print_SystemStatus@vx_mv+1)^080h,f
	rrf	(Print_SystemStatus@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u11075

	line	423
	
l7553:	
;main.c: 423: if(vx_mv + 200U >= (unsigned long)vcc_mv)
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	clrf	((??_Print_SystemStatus+0)^080h+0+2)
	clrf	((??_Print_SystemStatus+0)^080h+0+3)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+4)^080h+0)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	(Print_SystemStatus@vx_mv)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+0,f
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1)^080h,w
	goto	u11080
	goto	u11081
u11080:
	addwf	(??_Print_SystemStatus+4)^080h+1,f
u11081:
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2)^080h,w
	goto	u11082
	goto	u11083
u11082:
	addwf	(??_Print_SystemStatus+4)^080h+2,f
u11083:
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	subwf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u11095
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	subwf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u11095
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	subwf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u11095
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	subwf	0+(??_Print_SystemStatus+4)^080h+0,w
u11095:
	skipc
	goto	u11091
	goto	u11090
u11091:
	goto	l7557
u11090:
	line	425
	
l7555:	
;main.c: 424: {
;main.c: 425: uart_send_string(" OPEN");
	movlw	low(((STR_10)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	426
;main.c: 426: }
	goto	l7567
	line	429
	
l7557:	
;main.c: 427: else
;main.c: 428: {
;main.c: 429: unsigned long bat_mv_long = 124UL * vx_mv;
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(Print_SystemStatus@vx_mv)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long)^080h

	line	430
;main.c: 430: if(bat_mv_long > (206UL * (unsigned long)vcc_mv))
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(Print_SystemStatus@bat_mv_long+3)^080h,w
	subwf	(3+(?___lmul))^080h,w
	skipz
	goto	u11105
	movf	(Print_SystemStatus@bat_mv_long+2)^080h,w
	subwf	(2+(?___lmul))^080h,w
	skipz
	goto	u11105
	movf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	subwf	(1+(?___lmul))^080h,w
	skipz
	goto	u11105
	movf	(Print_SystemStatus@bat_mv_long)^080h,w
	subwf	(0+(?___lmul))^080h,w
u11105:
	skipnc
	goto	u11101
	goto	u11100
u11101:
	goto	l7567
u11100:
	line	432
	
l7559:	
;main.c: 431: {
;main.c: 432: bat_mv_long = (bat_mv_long - 206UL * (unsigned long)vcc_mv + 1000UL/2UL) / 1000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+3)
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+1)^080h
	movlw	032h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(Print_SystemStatus@bat_mv_long)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+0)
	movlw	0
	skipnc
	movlw	1
	addwf	(1+(?___lmul))^080h,w
	clrf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	addwf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	movf	(2+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+2),w
	clrf	((??_Print_SystemStatus+4)^080h+0+3)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	addwf	(Print_SystemStatus@bat_mv_long+2)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	movf	(3+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+3),w
	addwf	(Print_SystemStatus@bat_mv_long+3)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	0+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+0,f
	movf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	1+(??_Print_SystemStatus+4)^080h+0,w
	goto	u11110
	goto	u11111
u11110:
	addwf	(??_Print_SystemStatus+0)^080h+1,f
u11111:
	movf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	2+(??_Print_SystemStatus+4)^080h+0,w
	goto	u11112
	goto	u11113
u11112:
	addwf	(??_Print_SystemStatus+0)^080h+2,f
u11113:
	movf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incf	3+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long)^080h

	line	433
	
l7561:	
;main.c: 433: uart_send_string(" BAT(");
	movlw	low(((STR_11)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	434
	
l7563:	
;main.c: 434: uart_send_number((unsigned int)bat_mv_long);
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(Print_SystemStatus@bat_mv_long)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	435
	
l7565:	
;main.c: 435: uart_send_string("mV)");
	movlw	low(((STR_12)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	442
	
l7567:	
;main.c: 436: }
;main.c: 438: }
;main.c: 439: }
;main.c: 442: uart_send_char(' ');
	movlw	low(020h)
	fcall	_uart_send_char
	line	443
;main.c: 443: switch(s)
	goto	l7609
	line	445
	
l7569:	
	movlw	low(((STR_13)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7611
	line	446
	
l7571:	
	movlw	low(((STR_14)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7611
	line	447
	
l7573:	
	movlw	low(((STR_15)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7611
	line	448
	
l7575:	
	movlw	low(((STR_16)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7611
	line	449
	
l7577:	
	movlw	low(((STR_17)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7611
	line	450
	
l7579:	
	movlw	low(((STR_18)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7611
	line	451
	
l7581:	
	movlw	low(((STR_19)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7611
	line	454
	
l7583:	
;main.c: 453: {
;main.c: 454: unsigned char t = g_slot[(unsigned char)(i)].type;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Print_SystemStatus@t)^080h
	line	455
	
l7585:	
;main.c: 455: if(t == 2 || t == 3)
		movlw	2
	xorwf	((Print_SystemStatus@t)^080h),w
	btfsc	status,2
	goto	u11121
	goto	u11120
u11121:
	goto	l7589
u11120:
	
l7587:	
		movlw	3
	xorwf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u11131
	goto	u11130
u11131:
	goto	l7591
u11130:
	line	456
	
l7589:	
;main.c: 456: uart_send_string("[Dry/NiMH ERR]");
	movlw	low(((STR_20)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7611
	line	457
	
l7591:	
;main.c: 457: else if(t == 1)
		decf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u11141
	goto	u11140
u11141:
	goto	l7595
u11140:
	line	458
	
l7593:	
;main.c: 458: uart_send_string("[Li-ion ERR]");
	movlw	low(((STR_21)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7611
	line	459
	
l7595:	
;main.c: 459: else if(t == 6)
		movlw	6
	xorwf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u11151
	goto	u11150
u11151:
	goto	l7599
u11150:
	line	460
	
l7597:	
;main.c: 460: uart_send_string("[Linear Li ERR]");
	movlw	low(((STR_22)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7611
	line	462
	
l7599:	
;main.c: 461: else
;main.c: 462: uart_send_string("[ERR]");
	movlw	low(((STR_23)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7611
	line	465
	
l7601:	
	movlw	low(((STR_24)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7611
	line	466
	
l7603:	
	movlw	low(((STR_25)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7611
	line	467
	
l7605:	
	movlw	low(((STR_26)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7611
	line	443
	
l7609:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@s)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l7569
	xorlw	1^0	; case 1
	skipnz
	goto	l7571
	xorlw	2^1	; case 2
	skipnz
	goto	l7573
	xorlw	3^2	; case 3
	skipnz
	goto	l7575
	xorlw	4^3	; case 4
	skipnz
	goto	l7577
	xorlw	5^4	; case 5
	skipnz
	goto	l7579
	xorlw	6^5	; case 6
	skipnz
	goto	l7581
	xorlw	7^6	; case 7
	skipnz
	goto	l7583
	xorlw	8^7	; case 8
	skipnz
	goto	l7601
	xorlw	9^8	; case 9
	skipnz
	goto	l7603
	goto	l7605
	opt asmopt_pop

	line	471
	
l7611:	
;main.c: 471: uart_send_string(" ct=");
	movlw	low(((STR_27)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	472
	
l7613:	
;main.c: 472: uart_send_number(g_slot[(unsigned char)(i)].chargeTimer);
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(uart_send_number@num)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	473
	
l7615:	
;main.c: 473: uart_send_string(" ty=");
	movlw	low(((STR_28)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	474
;main.c: 474: uart_send_number(g_slot[(unsigned char)(i)].type);
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	476
;main.c: 476: if(g_slot[(unsigned char)(i)].type == 6 && g_slot[(unsigned char)(i)].state == 4)
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
		movlw	6
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u11161
	goto	u11160
u11161:
	goto	l7625
u11160:
	
l7617:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
		movlw	4
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u11171
	goto	u11170
u11171:
	goto	l7625
u11170:
	line	478
	
l7619:	
;main.c: 477: {
;main.c: 478: uart_send_string(" blk=");
	movlw	low(((STR_29)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	479
	
l7621:	
;main.c: 479: uart_send_number(g_ccBlocks[i]);
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	480
	
l7623:	
;main.c: 480: uart_send_string("/");
	movlw	low(((STR_30)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	481
;main.c: 481: uart_send_number(8);
	movlw	08h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	485
	
l7625:	
;main.c: 482: }
;main.c: 485: uart_send_string("\r\n");
	movlw	low(((STR_31)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	396
	
l7627:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(Print_SystemStatus@i)^080h,f
	
l7629:	
	movlw	low(06h)
	subwf	(Print_SystemStatus@i)^080h,w
	skipc
	goto	u11181
	goto	u11180
u11181:
	goto	l7541
u11180:
	line	488
	
l7631:	
;main.c: 487: }
;main.c: 488: uart_send_string("\r\n");
	movlw	low(((STR_32)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	489
	
l463:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 345 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	345
global __ptext5
__ptext5:	;psect for function _Print_NtcTemp
psect	text5
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	345
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	347
	
l7483:	
;main.c: 347: uart_send_string("NTC=");
	movlw	low(((STR_1)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	348
	
l7485:	
;main.c: 348: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(_Print_NtcTemp$767+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(_Print_NtcTemp$767)^080h
	
l7487:	
;main.c: 348: uart_send_number(g_temperature / 10U);
	movf	(_Print_NtcTemp$767+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$767)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	349
	
l7489:	
;main.c: 349: uart_send_string(".");
	movlw	low(((STR_2)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	350
	
l7491:	
;main.c: 350: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@divisor)^080h
	clrf	(___lwmod@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend)^080h
	fcall	___lwmod
	movf	(1+(?___lwmod))^080h,w
	movwf	(_Print_NtcTemp$768+1)^080h
	movf	(0+(?___lwmod))^080h,w
	movwf	(_Print_NtcTemp$768)^080h
;main.c: 350: uart_send_number(g_temperature % 10U);
	movf	(_Print_NtcTemp$768+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$768)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	351
	
l7493:	
;main.c: 351: uart_send_string("C\r\n");
	movlw	low(((STR_3)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	352
	
l427:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_Print_DetectLog

;; *************** function _Print_DetectLog *****************
;; Defined at:
;;		line 495 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	line	495
global __ptext6
__ptext6:	;psect for function _Print_DetectLog
psect	text6
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	495
	global	__size_of_Print_DetectLog
	__size_of_Print_DetectLog	equ	__end_of_Print_DetectLog-_Print_DetectLog
	
_Print_DetectLog:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_DetectLog: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	497
	
l7633:	
;main.c: 497: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	498
	
l7635:	
;main.c: 498: uart_send_number((unsigned int)g_detectLogSlot + 1U);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_detectLogSlot),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	incf	(uart_send_number@num)^080h,f
	skipnz
	incf	(uart_send_number@num+1)^080h,f
	fcall	_uart_send_number
	line	500
	
l7637:	
;main.c: 500: if(g_detectLogType == 2)
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u11191
	goto	u11190
u11191:
	goto	l7641
u11190:
	line	501
	
l7639:	
;main.c: 501: uart_send_string(": NiMH detected! Not charging.\r\n");
	movlw	low(((STR_33)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l471
	line	502
	
l7641:	
;main.c: 502: else if(g_detectLogType == 3)
		movlw	3
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u11201
	goto	u11200
u11201:
	goto	l7645
u11200:
	line	503
	
l7643:	
;main.c: 503: uart_send_string(": Dry/NiMH detected! Not charging.\r\n");
	movlw	low(((STR_34)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_34)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l471
	line	504
	
l7645:	
;main.c: 504: else if(g_detectLogType == 6)
		movlw	6
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u11211
	goto	u11210
u11211:
	goto	l471
u11210:
	line	505
	
l7647:	
;main.c: 505: uart_send_string(": Linear Li detected! Charging.\r\n");
	movlw	low(((STR_35)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_35)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	506
	
l471:	
	return
	opt stack 0
GLOBAL	__end_of_Print_DetectLog
	__end_of_Print_DetectLog:
	signat	_Print_DetectLog,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2    2[BANK1 ] PTR const unsigned char 
;;		 -> STR_43(3), STR_42(4), STR_41(5), STR_40(6), 
;;		 -> STR_39(6), STR_38(11), STR_37(10), STR_36(21), 
;;		 -> STR_35(34), STR_34(37), STR_33(33), STR_32(3), 
;;		 -> STR_31(3), STR_30(2), STR_29(6), STR_28(5), 
;;		 -> STR_27(5), STR_26(6), STR_25(6), STR_24(6), 
;;		 -> STR_23(6), STR_22(16), STR_21(13), STR_20(15), 
;;		 -> STR_19(7), STR_18(5), STR_17(5), STR_16(6), 
;;		 -> STR_15(6), STR_14(6), STR_13(7), STR_12(4), 
;;		 -> STR_11(6), STR_10(6), STR_9(3), STR_8(12), 
;;		 -> STR_7(2), STR_6(6), STR_5(5), STR_4(29), 
;;		 -> STR_3(4), STR_2(2), STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
global __ptext7
__ptext7:	;psect for function _uart_send_string
psect	text7
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l7089:	
;uart_dbg.c: 63: while(*str != '\0')
	goto	l7095
	line	65
	
l7091:	
;uart_dbg.c: 64: {
;uart_dbg.c: 65: uart_send_char(*str++);
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	btemp+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str)^080h,w
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	fcall	stringtab
	fcall	_uart_send_char
	
l7093:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(uart_send_string@str)^080h,f
	skipnz
	incf	(uart_send_string@str+1)^080h,f
	line	66
# 66 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
clrwdt ;# 
psect	text7
	line	63
	
l7095:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(uart_send_string@str+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	btemp+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str)^080h,w
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u10421
	goto	u10420
u10421:
	goto	l7091
u10420:
	line	68
	
l527:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2    7[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    9[BANK1 ] unsigned char [6]
;;  j               1   16[BANK1 ] unsigned char 
;;  i               1   15[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      10       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext8
__ptext8:	;psect for function _uart_send_number
psect	text8
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l7097:	
;uart_dbg.c: 79: unsigned char buf[6];
;uart_dbg.c: 80: unsigned char i = 0;
	clrf	(uart_send_number@i)^080h
	line	84
	
l7099:	
;uart_dbg.c: 81: unsigned char j;
;uart_dbg.c: 84: if(num == 0)
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u10431
	goto	u10430
u10431:
	goto	l7111
u10430:
	line	86
	
l7101:	
;uart_dbg.c: 85: {
;uart_dbg.c: 86: uart_send_char('0');
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l531
	line	93
	
l7105:	
;uart_dbg.c: 92: {
;uart_dbg.c: 93: buf[i++] = '0' + (num % 10);
	movf	(uart_send_number@i)^080h,w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)^080h
	clrf	(___lwmod@divisor+1)^080h
	movf	(uart_send_number@num+1)^080h,w
	movwf	(___lwmod@dividend+1)^080h
	movf	(uart_send_number@num)^080h,w
	movwf	(___lwmod@dividend)^080h
	fcall	___lwmod
	movf	(0+(?___lwmod))^080h,w
	addlw	030h
	bcf	status, 7	;select IRP bank1
	movwf	indf
	
l7107:	
	incf	(uart_send_number@i)^080h,f
	line	94
	
l7109:	
;uart_dbg.c: 94: num /= 10;
	movlw	0Ah
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(uart_send_number@num+1)^080h,w
	movwf	(___lwdiv@dividend+1)^080h
	movf	(uart_send_number@num)^080h,w
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(uart_send_number@num)^080h
	line	91
	
l7111:	
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u10441
	goto	u10440
u10441:
	goto	l7105
u10440:
	line	98
	
l7113:	
;uart_dbg.c: 95: }
;uart_dbg.c: 98: for(j = i; j > 0; j--)
	movf	(uart_send_number@i)^080h,w
	movwf	(uart_send_number@j)^080h
	
l7115:	
	movf	((uart_send_number@j)^080h),w
	btfss	status,2
	goto	u10451
	goto	u10450
u10451:
	goto	l7119
u10450:
	goto	l531
	line	99
	
l7119:	
;uart_dbg.c: 99: uart_send_char(buf[(unsigned char)(j - 1)]);
	movf	(uart_send_number@j)^080h,w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l7121:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decf	(uart_send_number@j)^080h,f
	goto	l7115
	line	100
	
l531:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1    0[BANK1 ] unsigned char 
;;  i               1    1[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       2       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       1       2       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext9
__ptext9:	;psect for function _uart_send_char
psect	text9
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_char: [wreg+status,2+status,0]
;uart_send_char@c stored from wreg
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_char@c)^080h
	line	38
	
l6935:	
;uart_dbg.c: 37: unsigned char i;
;uart_dbg.c: 38: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	39
;uart_dbg.c: 39: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l6937:	
;uart_dbg.c: 40: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u13247:
decfsz	(??_uart_send_char+0)+0,f
	goto	u13247
	nop2
opt asmopt_pop

	line	41
	
l6939:	
;uart_dbg.c: 41: for(i = 0; i < 8; i++)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(uart_send_char@i)^080h
	line	42
	
l517:	
	line	43
;uart_dbg.c: 42: {
;uart_dbg.c: 43: if(c & 0x01)
	btfss	(uart_send_char@c)^080h,(0)&7
	goto	u10151
	goto	u10150
u10151:
	goto	l519
u10150:
	line	44
	
l6945:	
;uart_dbg.c: 44: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l6947
	line	45
	
l519:	
	line	46
;uart_dbg.c: 45: else
;uart_dbg.c: 46: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l6947:	
;uart_dbg.c: 47: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u13257:
decfsz	(??_uart_send_char+0)+0,f
	goto	u13257
	nop2
opt asmopt_pop

	line	48
	
l6949:	
;uart_dbg.c: 48: c >>= 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrc
	rrf	(uart_send_char@c)^080h,f
	line	41
	
l6951:	
	incf	(uart_send_char@i)^080h,f
	
l6953:	
	movlw	low(08h)
	subwf	(uart_send_char@i)^080h,w
	skipc
	goto	u10161
	goto	u10160
u10161:
	goto	l517
u10160:
	
l518:	
	line	50
;uart_dbg.c: 49: }
;uart_dbg.c: 50: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l6955:	
;uart_dbg.c: 51: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u13267:
decfsz	(??_uart_send_char+0)+0,f
	goto	u13267
	nop2
opt asmopt_pop

	line	52
	
l6957:	
;uart_dbg.c: 52: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l521:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK1 ] unsigned int 
;;  dividend        2    2[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1   26[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK1 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       4       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       4       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext10
__ptext10:	;psect for function ___lwmod
psect	text10
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l7023:	
	movf	((___lwmod@divisor)^080h),w
iorwf	((___lwmod@divisor+1)^080h),w
	btfsc	status,2
	goto	u10281
	goto	u10280
u10281:
	goto	l7039
u10280:
	line	14
	
l7025:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l7029
	line	16
	
l7027:	
	clrc
	rlf	(___lwmod@divisor)^080h,f
	rlf	(___lwmod@divisor+1)^080h,f
	line	17
	bcf	status, 5	;RP0=0, select bank0
	incf	(___lwmod@counter),f
	line	15
	
l7029:	
	bsf	status, 5	;RP0=1, select bank1
	btfss	(___lwmod@divisor+1)^080h,(15)&7
	goto	u10291
	goto	u10290
u10291:
	goto	l7027
u10290:
	line	20
	
l7031:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lwmod@divisor+1)^080h,w
	subwf	(___lwmod@dividend+1)^080h,w
	skipz
	goto	u10305
	movf	(___lwmod@divisor)^080h,w
	subwf	(___lwmod@dividend)^080h,w
u10305:
	skipc
	goto	u10301
	goto	u10300
u10301:
	goto	l7035
u10300:
	line	21
	
l7033:	
	movf	(___lwmod@divisor)^080h,w
	subwf	(___lwmod@dividend)^080h,f
	movf	(___lwmod@divisor+1)^080h,w
	skipc
	decf	(___lwmod@dividend+1)^080h,f
	subwf	(___lwmod@dividend+1)^080h,f
	line	22
	
l7035:	
	clrc
	rrf	(___lwmod@divisor+1)^080h,f
	rrf	(___lwmod@divisor)^080h,f
	line	23
	
l7037:	
	bcf	status, 5	;RP0=0, select bank0
	decfsz	(___lwmod@counter),f
	goto	u10311
	goto	u10310
u10311:
	goto	l7031
u10310:
	line	25
	
l7039:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lwmod@dividend+1)^080h,w
	movwf	(?___lwmod+1)^080h
	movf	(___lwmod@dividend)^080h,w
	movwf	(?___lwmod)^080h
	line	26
	
l1292:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	_Do_NtcRead

;; *************** function _Do_NtcRead *****************
;; Defined at:
;;		line 336 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Read_Temperature
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	336
global __ptext11
__ptext11:	;psect for function _Do_NtcRead
psect	text11
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	336
	global	__size_of_Do_NtcRead
	__size_of_Do_NtcRead	equ	__end_of_Do_NtcRead-_Do_NtcRead
	
_Do_NtcRead:	
;incstack = 0
	opt	stack 2
; Regs used in _Do_NtcRead: [wreg+status,2+status,0+pclath+cstack]
	line	338
	
l7481:	
;main.c: 338: Read_Temperature();
	fcall	_Read_Temperature
	line	339
	
l424:	
	return
	opt stack 0
GLOBAL	__end_of_Do_NtcRead
	__end_of_Do_NtcRead:
	signat	_Do_NtcRead,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 42 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   29[BANK1 ] unsigned long 
;;  temp_x10        2   35[BANK1 ] unsigned int 
;;  ntcVal          2   33[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   66[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Do_NtcRead
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	42
global __ptext12
__ptext12:	;psect for function _Read_Temperature
psect	text12
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	42
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 2
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	47
	
l7051:	
;charge_mgr.c: 44: unsigned int ntcVal;
;charge_mgr.c: 45: unsigned int temp_x10;
;charge_mgr.c: 47: test_adc = ADC_Sample(18, 0);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ADC_Sample@adldo)^080h
	movlw	low(012h)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	48
	
l7053:	
;charge_mgr.c: 48: if(0xA5 != test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u10321
	goto	u10320
u10321:
	goto	l7057
u10320:
	goto	l572
	line	51
	
l7057:	
;charge_mgr.c: 51: ntcVal = adresult;
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal)^080h
	line	52
;charge_mgr.c: 52: if(ntcVal < 100 || ntcVal > 3996)
	movlw	0
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u10331
	goto	u10330
u10331:
	goto	l572
u10330:
	
l7059:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u10341
	goto	u10340
u10341:
	goto	l7061
u10340:
	goto	l572
	line	57
	
l7061:	
;charge_mgr.c: 55: {
;charge_mgr.c: 56: unsigned long rt;
;charge_mgr.c: 57: rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	010h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0
	movwf	(___lldiv@divisor)^080h

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0)
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0+1)
	clrf	((??_Read_Temperature+0)^080h+0+2)
	clrf	((??_Read_Temperature+0)^080h+0+3)
	movf	0+(??_Read_Temperature+0)^080h+0,w
	subwf	(___lldiv@divisor)^080h,f
	movf	1+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)^080h+0,w
	goto	u10355
	goto	u10356
u10355:
	subwf	(___lldiv@divisor+1)^080h,f
u10356:
	movf	2+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)^080h+0,w
	goto	u10357
	goto	u10358
u10357:
	subwf	(___lldiv@divisor+2)^080h,f
u10358:
	movf	3+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)^080h+0,w
	goto	u10359
	goto	u10350
u10359:
	subwf	(___lldiv@divisor+3)^080h,f
u10350:

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0
	movwf	(___lmul@multiplicand+2)^080h
	movlw	027h
	movwf	(___lmul@multiplicand+1)^080h
	movlw	010h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt)^080h

	line	58
	
l7063:	
;charge_mgr.c: 58: if(rt >= 10000UL)
		movf	(Read_Temperature@rt+3)^080h,w
	btfss	status,2
	goto	u10360
	movf	(Read_Temperature@rt+2)^080h,w
	btfss	status,2
	goto	u10360
	movlw	39
	subwf	(Read_Temperature@rt+1)^080h,w
	skipz
	goto	u10363
	movlw	16
	subwf	(Read_Temperature@rt)^080h,w
	skipz
	goto	u10363
u10363:
	btfss	status,0
	goto	u10361
	goto	u10360

u10361:
	goto	l7069
u10360:
	line	59
	
l7065:	
;charge_mgr.c: 59: temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l7067:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0F0h
	movwf	((??_Read_Temperature+0)^080h+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)^080h+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+3)
	movf	(Read_Temperature@rt)^080h,w
	addwf	(??_Read_Temperature+0)^080h+0,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+1)^080h,w
	goto	u10370
	goto	u10371
u10370:
	addwf	(??_Read_Temperature+0)^080h+1,f
u10371:
	movf	(Read_Temperature@rt+2)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+2)^080h,w
	goto	u10372
	goto	u10373
u10372:
	addwf	(??_Read_Temperature+0)^080h+2,f
u10373:
	movf	(Read_Temperature@rt+3)^080h,w
	skipnc
	incf	(Read_Temperature@rt+3)^080h,w
	addwf	(??_Read_Temperature+0)^080h+3,f
	movf	3+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+3)^080h
	movf	2+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+2)^080h
	movf	1+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+1)^080h
	movf	0+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier)^080h

	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(0+(?___lldiv))^080h,w
	subwf	(Read_Temperature@temp_x10)^080h,f
	movf	(1+(?___lldiv))^080h,w
	skipc
	decf	(Read_Temperature@temp_x10+1)^080h,f
	subwf	(Read_Temperature@temp_x10+1)^080h,f
	goto	l7073
	line	61
	
l7069:	
;charge_mgr.c: 60: else
;charge_mgr.c: 61: temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0
	movwf	(___lmul@multiplier+3)^080h
	movlw	0
	movwf	(___lmul@multiplier+2)^080h
	movlw	027h
	movwf	(___lmul@multiplier+1)^080h
	movlw	010h
	movwf	(___lmul@multiplier)^080h

	movf	(Read_Temperature@rt)^080h,w
	subwf	(___lmul@multiplier)^080h,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+1)^080h,w
	subwf	(___lmul@multiplier+1)^080h,f
	movf	(Read_Temperature@rt+2)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+2)^080h,w
	subwf	(___lmul@multiplier+2)^080h,f
	movf	(Read_Temperature@rt+3)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+3)^080h,w
	subwf	(___lmul@multiplier+3)^080h,f
	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10)^080h
	
l7071:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10)^080h,f
	skipnc
	incf	(Read_Temperature@temp_x10+1)^080h,f
	line	62
	
l7073:	
;charge_mgr.c: 62: if(temp_x10 < 100U) temp_x10 = 100U;
	movlw	0
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipnc
	goto	u10381
	goto	u10380
u10381:
	goto	l578
u10380:
	
l7075:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l578:	
	line	63
;charge_mgr.c: 63: if(temp_x10 > 750U) temp_x10 = 750U;
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipc
	goto	u10391
	goto	u10390
u10391:
	goto	l579
u10390:
	
l7077:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)^080h
	movlw	02h
	movwf	((Read_Temperature@temp_x10)^080h)+1
	
l579:	
	line	66
;charge_mgr.c: 64: }
;charge_mgr.c: 66: g_temperature = temp_x10;
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature)
	line	67
	
l7079:	
;charge_mgr.c: 67: if((temp_x10 / 10U) >= 60)
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(Read_Temperature@temp_x10+1)^080h,w
	movwf	(___lwdiv@dividend+1)^080h
	movf	(Read_Temperature@temp_x10)^080h,w
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv))^080h,w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv))^080h,w
	skipc
	goto	u10401
	goto	u10400
u10401:
	goto	l7083
u10400:
	line	68
	
l7081:	
;charge_mgr.c: 68: g_tempProtect = 1;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_tempProtect)
	incf	(_g_tempProtect),f
	goto	l572
	line	69
	
l7083:	
;charge_mgr.c: 69: else if((temp_x10 / 10U) <= 50)
	movlw	0Ah
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(Read_Temperature@temp_x10+1)^080h,w
	movwf	(___lwdiv@dividend+1)^080h
	movf	(Read_Temperature@temp_x10)^080h,w
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv))^080h,w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv))^080h,w
	skipnc
	goto	u10411
	goto	u10410
u10411:
	goto	l572
u10410:
	line	70
	
l7085:	
;charge_mgr.c: 70: g_tempProtect = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_tempProtect)
	line	73
	
l572:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK1 ] unsigned int 
;;  dividend        2    2[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    5[BANK1 ] unsigned int 
;;  counter         1    4[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK1 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       4       0       0
;;      Locals:         0       0       3       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       7       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext13
__ptext13:	;psect for function ___lwdiv
psect	text13
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l6997:	
	clrf	(___lwdiv@quotient)^080h
	clrf	(___lwdiv@quotient+1)^080h
	line	15
	
l6999:	
	movf	((___lwdiv@divisor)^080h),w
iorwf	((___lwdiv@divisor+1)^080h),w
	btfsc	status,2
	goto	u10241
	goto	u10240
u10241:
	goto	l7019
u10240:
	line	16
	
l7001:	
	clrf	(___lwdiv@counter)^080h
	incf	(___lwdiv@counter)^080h,f
	line	17
	goto	l7005
	line	18
	
l7003:	
	clrc
	rlf	(___lwdiv@divisor)^080h,f
	rlf	(___lwdiv@divisor+1)^080h,f
	line	19
	incf	(___lwdiv@counter)^080h,f
	line	17
	
l7005:	
	btfss	(___lwdiv@divisor+1)^080h,(15)&7
	goto	u10251
	goto	u10250
u10251:
	goto	l7003
u10250:
	line	22
	
l7007:	
	clrc
	rlf	(___lwdiv@quotient)^080h,f
	rlf	(___lwdiv@quotient+1)^080h,f
	line	23
	
l7009:	
	movf	(___lwdiv@divisor+1)^080h,w
	subwf	(___lwdiv@dividend+1)^080h,w
	skipz
	goto	u10265
	movf	(___lwdiv@divisor)^080h,w
	subwf	(___lwdiv@dividend)^080h,w
u10265:
	skipc
	goto	u10261
	goto	u10260
u10261:
	goto	l7015
u10260:
	line	24
	
l7011:	
	movf	(___lwdiv@divisor)^080h,w
	subwf	(___lwdiv@dividend)^080h,f
	movf	(___lwdiv@divisor+1)^080h,w
	skipc
	decf	(___lwdiv@dividend+1)^080h,f
	subwf	(___lwdiv@dividend+1)^080h,f
	line	25
	
l7013:	
	bsf	(___lwdiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l7015:	
	clrc
	rrf	(___lwdiv@divisor+1)^080h,f
	rrf	(___lwdiv@divisor)^080h,f
	line	28
	
l7017:	
	decfsz	(___lwdiv@counter)^080h,f
	goto	u10271
	goto	u10270
u10271:
	goto	l7007
u10270:
	line	30
	
l7019:	
	movf	(___lwdiv@quotient+1)^080h,w
	movwf	(?___lwdiv+1)^080h
	movf	(___lwdiv@quotient)^080h,w
	movwf	(?___lwdiv)^080h
	line	31
	
l1282:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	_Do_AdcSample

;; *************** function _Do_AdcSample *****************
;; Defined at:
;;		line 283 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  st              1   21[BANK1 ] unsigned char 
;;  dly             1   20[BANK1 ] unsigned char 
;;  ty              1   19[BANK1 ] unsigned char 
;;  ch              1   18[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       1       4       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	283
global __ptext14
__ptext14:	;psect for function _Do_AdcSample
psect	text14
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	283
	global	__size_of_Do_AdcSample
	__size_of_Do_AdcSample	equ	__end_of_Do_AdcSample-_Do_AdcSample
	
_Do_AdcSample:	
;incstack = 0
	opt	stack 3
; Regs used in _Do_AdcSample: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	285
	
l7437:	
;main.c: 285: unsigned char ch = s_adcChannels[g_scanIndex];
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_scanIndex),w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@ch)^080h
	line	286
	
l7439:	
;main.c: 286: unsigned char ty = g_slot[(unsigned char)(g_scanIndex)].type;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Do_AdcSample@ty)^080h
	line	287
	
l7441:	
;main.c: 287: unsigned char st = g_slot[(unsigned char)(g_scanIndex)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Do_AdcSample@st)^080h
	line	295
	
l7443:	
;main.c: 288: unsigned char dly;
;main.c: 295: if(st == 1 || st == 8)
		decf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10971
	goto	u10970
u10971:
	goto	l7447
u10970:
	
l7445:	
		movlw	8
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u10981
	goto	u10980
u10981:
	goto	l7459
u10980:
	line	297
	
l7447:	
;main.c: 296: {
;main.c: 297: for(dly = 0; dly < 20; dly++)
	clrf	(Do_AdcSample@dly)^080h
	line	298
	
l7453:	
;main.c: 298: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Do_AdcSample+0)+0),f
	u13277:
decfsz	(??_Do_AdcSample+0)+0,f
	goto	u13277
	nop
opt asmopt_pop

	line	297
	
l7455:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(Do_AdcSample@dly)^080h,f
	
l7457:	
	movlw	low(014h)
	subwf	(Do_AdcSample@dly)^080h,w
	skipc
	goto	u10991
	goto	u10990
u10991:
	goto	l7453
u10990:
	goto	l7461
	line	302
	
l7459:	
;main.c: 300: else
;main.c: 301: {
;main.c: 302: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Do_AdcSample+0)+0),f
	u13287:
decfsz	(??_Do_AdcSample+0)+0,f
	goto	u13287
	nop
opt asmopt_pop

	line	305
	
l7461:	
;main.c: 303: }
;main.c: 305: test_adc = ADC_Sample(ch, 0);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ADC_Sample@adldo)^080h
	movf	(Do_AdcSample@ch)^080h,w
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	307
	
l7463:	
;main.c: 307: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u11001
	goto	u11000
u11001:
	goto	l7477
u11000:
	line	313
	
l7465:	
;main.c: 308: {
;main.c: 312: if(ty == 6 && (st == 4 || st == 5)
;main.c: 313: && adresult >= 3990)
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	((Do_AdcSample@ty)^080h),w
	btfss	status,2
	goto	u11011
	goto	u11010
u11011:
	goto	l7475
u11010:
	
l7467:	
		movlw	4
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11021
	goto	u11020
u11021:
	goto	l7471
u11020:
	
l7469:	
		movlw	5
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u11031
	goto	u11030
u11031:
	goto	l7475
u11030:
	
l7471:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_adresult+1),w	;volatile
	movlw	096h
	skipnz
	subwf	(_adresult),w	;volatile
	skipc
	goto	u11041
	goto	u11040
u11041:
	goto	l7475
u11040:
	goto	l7479
	line	319
	
l7475:	
;main.c: 317: else
;main.c: 318: {
;main.c: 319: g_slot[g_scanIndex].voltage = adresult;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_adresult+1),w	;volatile
	movwf	indf
	goto	l7479
	line	324
	
l7477:	
;main.c: 322: else
;main.c: 323: {
;main.c: 324: g_slot[g_scanIndex].voltage = 0;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	327
	
l7479:	
;main.c: 325: }
;main.c: 327: g_scanPhase = 1;
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_scanPhase)	;volatile
	line	328
	
l421:	
	return
	opt stack 0
GLOBAL	__end_of_Do_AdcSample
	__end_of_Do_AdcSample:
	signat	_Do_AdcSample,89
	global	_ChargeProcess_Slot

;; *************** function _ChargeProcess_Slot *****************
;; Defined at:
;;		line 139 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    5[BANK2 ] unsigned char 
;;  pre_v           2    8[BANK3 ] unsigned int 
;;  bat_mv_long     4   36[BANK1 ] unsigned long 
;;  vx_mv           4   32[BANK1 ] unsigned long 
;;  bat_mv          2    0[BANK3 ] unsigned int 
;;  bat_mv_long     4   60[BANK1 ] unsigned long 
;;  vx_mv           4   56[BANK1 ] unsigned long 
;;  bat_mv          2    6[BANK3 ] unsigned int 
;;  bat_mv_long     4   52[BANK1 ] unsigned long 
;;  vx_mv           4   48[BANK1 ] unsigned long 
;;  bat_mv          2    4[BANK3 ] unsigned int 
;;  bat_mv_long     4   44[BANK1 ] unsigned long 
;;  vx_mv           4   40[BANK1 ] unsigned long 
;;  bat_mv          2    2[BANK3 ] unsigned int 
;;  pre             2   10[BANK3 ] unsigned int 
;;  v_ref           2   66[BANK1 ] unsigned int 
;;  v_init          2   30[BANK1 ] unsigned int 
;;  v               2    3[BANK2 ] unsigned int 
;;  ct              2    0[BANK2 ] unsigned int 
;;  ty              1    2[BANK2 ] unsigned char 
;;  st              1   68[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      39      12       6
;;      Temps:          0       0       5       0       0
;;      Totals:         0       0      44      12       6
;;Total ram usage:       62 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		_Detect_BatteryType
;;		___bmul
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	139
global __ptext15
__ptext15:	;psect for function _ChargeProcess_Slot
psect	text15
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	139
	global	__size_of_ChargeProcess_Slot
	__size_of_ChargeProcess_Slot	equ	__end_of_ChargeProcess_Slot-_ChargeProcess_Slot
	
_ChargeProcess_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _ChargeProcess_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;ChargeProcess_Slot@idx stored from wreg
	bsf	status, 6	;RP1=1, select bank2
	movwf	(ChargeProcess_Slot@idx)^0100h
	line	144
;charge_mgr.c: 141: unsigned char st, ty;
;charge_mgr.c: 142: unsigned int v, ct;
;charge_mgr.c: 144: do { st = g_slot[(idx)].state; ty = g_slot[(idx)].type; v = g_slot[(idx)].voltage; ct = g_slot[(idx)].chargeTimer; } while(0);
	
l594:	
	
l7649:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(ChargeProcess_Slot@st)^080h
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(ChargeProcess_Slot@ty)^0100h
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(ChargeProcess_Slot@v)^0100h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v+1)^0100h
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(ChargeProcess_Slot@ct)^0100h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@ct+1)^0100h
	goto	l8459
	line	154
	
l7651:	
;charge_mgr.c: 154: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11224
u11225:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11224:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11225
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	155
	
l7653:	
;charge_mgr.c: 155: if(g_slotRefV[idx] == 0xFFFF)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
		incf	((??_ChargeProcess_Slot+0)^080h+0),w
	skipz
	goto	u11231
	incf	((??_ChargeProcess_Slot+0)^080h+1),w
	btfss	status,2
	goto	u11231
	goto	u11230
u11231:
	goto	l7659
u11230:
	line	158
	
l7655:	
;charge_mgr.c: 159: if(g_detectLowCnt[idx] < 500)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	160
;charge_mgr.c: 160: break;
	goto	l8461
	line	164
	
l7659:	
;charge_mgr.c: 163: }
;charge_mgr.c: 164: if(v < 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u11241
	goto	u11240
u11241:
	goto	l7671
u11240:
	line	167
	
l7661:	
;charge_mgr.c: 165: {
;charge_mgr.c: 167: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	168
;charge_mgr.c: 168: g_slotRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	169
;charge_mgr.c: 169: if(g_detectLowCnt[idx] < 3)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(03h)
	subwf	indf,w
	skipnc
	goto	u11251
	goto	u11250
u11251:
	goto	l7665
u11250:
	goto	l8461
	line	171
	
l7665:	
;charge_mgr.c: 171: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	172
	
l7667:	
;charge_mgr.c: 172: st = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@st)^080h
	incf	(ChargeProcess_Slot@st)^080h,f
	line	173
	
l7669:	
;charge_mgr.c: 173: ct = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrf	(ChargeProcess_Slot@ct)^0100h
	clrf	(ChargeProcess_Slot@ct+1)^0100h
	line	174
;charge_mgr.c: 174: }
	goto	l8461
	line	178
	
l7671:	
;charge_mgr.c: 175: else
;charge_mgr.c: 176: {
;charge_mgr.c: 178: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	179
;charge_mgr.c: 179: g_slotRefV[idx] = 0;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l8461
	line	184
	
l7673:	
;charge_mgr.c: 184: ct++;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@ct)^0100h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0100h,f
	line	187
	
l7675:	
;charge_mgr.c: 187: if(ct == 1)
		decf	((ChargeProcess_Slot@ct)^0100h),w
iorwf	((ChargeProcess_Slot@ct+1)^0100h),w
	btfss	status,2
	goto	u11261
	goto	u11260
u11261:
	goto	l7681
u11260:
	line	189
	
l7677:	
;charge_mgr.c: 188: {
;charge_mgr.c: 189: g_ccBlocks[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	190
	
l7679:	
;charge_mgr.c: 190: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11274
u11275:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11274:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11275
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	201
	
l7681:	
;charge_mgr.c: 191: }
;charge_mgr.c: 200: if(v >= 3990 && g_slotRefV[idx] > 0 && g_slotRefV[idx] < 3990
;charge_mgr.c: 201: && (unsigned int)(v - g_slotRefV[idx]) > 500)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11281
	goto	u11280
u11281:
	goto	l7711
u11280:
	
l7683:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	((??_ChargeProcess_Slot+0)^080h+0),w
iorwf	((??_ChargeProcess_Slot+0)^080h+1),w
	btfsc	status,2
	goto	u11291
	goto	u11290
u11291:
	goto	l7711
u11290:
	
l7685:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movlw	0Fh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	096h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	goto	u11301
	goto	u11300
u11301:
	goto	l7711
u11300:
	
l7687:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	incf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u11311
	goto	u11310
u11311:
	goto	l7711
u11310:
	line	204
	
l7689:	
;charge_mgr.c: 202: {
;charge_mgr.c: 204: if(g_impCheckSlot != 0xFF && g_impCheckSlot != idx)
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u11321
	goto	u11320
u11321:
	goto	l7695
u11320:
	
l7691:	
	movf	(_g_impCheckSlot)^080h,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	xorwf	(ChargeProcess_Slot@idx)^0100h,w
	skipnz
	goto	u11331
	goto	u11330
u11331:
	goto	l7695
u11330:
	goto	l7711
	line	209
	
l7695:	
;charge_mgr.c: 207: else
;charge_mgr.c: 208: {
;charge_mgr.c: 209: g_impCheckSlot = idx;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	210
	
l7697:	
;charge_mgr.c: 210: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11344
u11345:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11344:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11345
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	211
	
l7699:	
;charge_mgr.c: 211: if(0xA5 == ADC_Sample(31, 0))
	clrf	(ADC_Sample@adldo)^080h
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u11351
	goto	u11350
u11351:
	goto	l7703
u11350:
	line	212
	
l7701:	
;charge_mgr.c: 212: g_vcc_mv = (unsigned int)((4096UL * 1200UL) / adresult);
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_vcc_mv+1)	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movf	(0+(?___lldiv))^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_vcc_mv)	;volatile
	line	213
	
l7703:	
;charge_mgr.c: 213: g_impData = v;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impData+1)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impData)^080h
	line	214
	
l7705:	
;charge_mgr.c: 214: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	215
	
l7707:	
;charge_mgr.c: 215: st = 8;
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7669
	line	221
	
l7711:	
;charge_mgr.c: 218: }
;charge_mgr.c: 219: }
;charge_mgr.c: 221: if(ct < (2 * 100))
	movlw	0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@ct+1)^0100h,w
	movlw	0C8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0100h,w
	skipnc
	goto	u11361
	goto	u11360
u11361:
	goto	l7715
u11360:
	goto	l8461
	line	229
	
l7715:	
;charge_mgr.c: 226: }
;charge_mgr.c: 229: if(ct == (2 * 100))
		movlw	200
	xorwf	((ChargeProcess_Slot@ct)^0100h),w
iorwf	((ChargeProcess_Slot@ct+1)^0100h),w
	btfss	status,2
	goto	u11371
	goto	u11370
u11371:
	goto	l7723
u11370:
	line	231
	
l7717:	
;charge_mgr.c: 230: {
;charge_mgr.c: 231: g_slotRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	232
	
l7719:	
;charge_mgr.c: 232: if(v > 2900)
	movlw	0Bh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11381
	goto	u11380
u11381:
	goto	l8461
u11380:
	line	233
	
l7721:	
;charge_mgr.c: 233: g_capFlag |= (unsigned int)1 << idx;
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11394
u11395:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11394:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11395
	
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_capFlag+1)^080h,f
	goto	l8461
	line	236
	
l7723:	
;charge_mgr.c: 235: }
;charge_mgr.c: 236: if(v > 2900 && v < 3990)
	movlw	0Bh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11401
	goto	u11400
u11401:
	goto	l7783
u11400:
	
l7725:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u11411
	goto	u11410
u11411:
	goto	l7783
u11410:
	line	240
	
l7727:	
;charge_mgr.c: 237: {
;charge_mgr.c: 240: if(!(g_capFlag & ((unsigned int)1 << idx)) && ty != 5)
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11424
u11425:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11424:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11425
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfss	status,2
	goto	u11431
	goto	u11430
u11431:
	goto	l7739
u11430:
	
l7729:	
		movlw	5
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	xorwf	((ChargeProcess_Slot@ty)^0100h),w
	btfsc	status,2
	goto	u11441
	goto	u11440
u11441:
	goto	l7739
u11440:
	line	242
	
l7731:	
;charge_mgr.c: 241: {
;charge_mgr.c: 242: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0100h
	clrf	(ChargeProcess_Slot@ct+1)^0100h
	line	243
	
l7733:	
;charge_mgr.c: 243: g_slotRefV[idx] = 0;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	244
	
l7735:	
;charge_mgr.c: 244: g_ccBlocks[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	245
	
l7737:	
;charge_mgr.c: 245: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	246
;charge_mgr.c: 246: break;
	goto	l8461
	line	252
	
l7739:	
;charge_mgr.c: 247: }
;charge_mgr.c: 252: unsigned int v_init = g_slotRefV[idx];
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@v_init)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_init+1)^080h
	line	254
;charge_mgr.c: 254: if(g_ccBlocks[idx] >= 20)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipc
	goto	u11451
	goto	u11450
u11451:
	goto	l7769
u11450:
	line	257
	
l7741:	
;charge_mgr.c: 255: {
;charge_mgr.c: 257: g_highVFlag |= (unsigned int)1 << idx;
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11464
u11465:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11464:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11465
	
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_highVFlag+1)^080h,f
	line	259
	
l7743:	
;charge_mgr.c: 259: if(v <= 2900)
	movlw	0Bh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u11471
	goto	u11470
u11471:
	goto	l7751
u11470:
	line	262
	
l7745:	
;charge_mgr.c: 260: {
;charge_mgr.c: 262: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11484
u11485:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11484:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11485
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	263
	
l7747:	
;charge_mgr.c: 263: g_ccBlocks[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	264
	
l7749:	
;charge_mgr.c: 264: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11494
u11495:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11494:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11495
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	265
;charge_mgr.c: 265: }
	goto	l7795
	line	266
	
l7751:	
;charge_mgr.c: 266: else if(ct < (2 * 100) + (8 * 100))
	movlw	03h
	subwf	(ChargeProcess_Slot@ct+1)^0100h,w
	movlw	0E8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0100h,w
	skipnc
	goto	u11501
	goto	u11500
u11501:
	goto	l7763
u11500:
	line	270
	
l7753:	
;charge_mgr.c: 267: {
;charge_mgr.c: 269: if((g_highVFlag & ((unsigned int)1 << idx)) &&
;charge_mgr.c: 270: ct >= (2 * 100) + 200U)
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11514
u11515:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11514:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11515
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u11521
	goto	u11520
u11521:
	goto	l7759
u11520:
	
l7755:	
	movlw	01h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@ct+1)^0100h,w
	movlw	090h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0100h,w
	skipc
	goto	u11531
	goto	u11530
u11531:
	goto	l7759
u11530:
	goto	l7763
	line	272
	
l7759:	
;charge_mgr.c: 272: g_slotRefV[idx] = v;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	273
;charge_mgr.c: 273: break;
	goto	l8461
	line	280
	
l7763:	
;charge_mgr.c: 280: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11544
u11545:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11544:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11545
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	281
	
l7765:	
;charge_mgr.c: 281: g_ccBlocks[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	282
	
l7767:	
;charge_mgr.c: 282: ty = 5;
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@ty)^0100h
	line	283
;charge_mgr.c: 283: goto amb_check;
	goto	l7819
	line	289
	
l7769:	
;charge_mgr.c: 286: else
;charge_mgr.c: 287: {
;charge_mgr.c: 289: if(v + 50 < v_init)
	movf	(ChargeProcess_Slot@v)^0100h,w
	addlw	low(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(ChargeProcess_Slot@v_init+1)^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11555
	movf	(ChargeProcess_Slot@v_init)^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11555:
	skipnc
	goto	u11551
	goto	u11550
u11551:
	goto	l7773
u11550:
	line	292
	
l7771:	
;charge_mgr.c: 290: {
;charge_mgr.c: 292: g_slotRefV[idx] = v;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	293
;charge_mgr.c: 293: g_ccBlocks[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	294
;charge_mgr.c: 294: }
	goto	l625
	line	298
	
l7773:	
;charge_mgr.c: 295: else
;charge_mgr.c: 296: {
;charge_mgr.c: 298: g_slotRefV[idx] = v;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	299
;charge_mgr.c: 299: g_ccBlocks[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	300
	
l625:	
	line	301
;charge_mgr.c: 300: }
;charge_mgr.c: 301: if(g_ccBlocks[idx] < 20)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u11561
	goto	u11560
u11561:
	goto	l7777
u11560:
	goto	l8461
	line	304
	
l7777:	
;charge_mgr.c: 304: if(g_capFlag & ((unsigned int)1 << idx))
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11574
u11575:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11574:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11575
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u11581
	goto	u11580
u11581:
	goto	l7781
u11580:
	goto	l8461
	line	306
	
l7781:	
;charge_mgr.c: 306: g_ccBlocks[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7795
	line	309
	
l7783:	
;charge_mgr.c: 309: else if(ct < (2 * 100) + (8 * 100) && v < 3990)
	movlw	03h
	subwf	(ChargeProcess_Slot@ct+1)^0100h,w
	movlw	0E8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0100h,w
	skipnc
	goto	u11591
	goto	u11590
u11591:
	goto	l7795
u11590:
	
l7785:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u11601
	goto	u11600
u11601:
	goto	l7795
u11600:
	line	311
	
l7787:	
;charge_mgr.c: 310: {
;charge_mgr.c: 311: unsigned int v_ref = g_slotRefV[idx];
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@v_ref)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_ref+1)^080h
	line	312
	
l7789:	
;charge_mgr.c: 312: if(v_ref < 3990 && v + 50 < v_ref)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v_ref+1)^080h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v_ref)^080h,w
	skipnc
	goto	u11611
	goto	u11610
u11611:
	goto	l7795
u11610:
	
l7791:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	addlw	low(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(ChargeProcess_Slot@v_ref+1)^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11625
	movf	(ChargeProcess_Slot@v_ref)^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11625:
	skipnc
	goto	u11621
	goto	u11620
u11621:
	goto	l7795
u11620:
	goto	l7759
	line	325
	
l7795:	
;charge_mgr.c: 316: }
;charge_mgr.c: 317: }
;charge_mgr.c: 325: if(g_capFlag & ((unsigned int)1 << idx))
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11634
u11635:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11634:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11635
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u11641
	goto	u11640
u11641:
	goto	l7803
u11640:
	line	327
	
l7797:	
;charge_mgr.c: 326: {
;charge_mgr.c: 327: g_capFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11654
u11655:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11654:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11655
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	328
	
l7799:	
;charge_mgr.c: 328: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	329
	
l7801:	
;charge_mgr.c: 329: ty = 5;
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@ty)^0100h
	line	330
;charge_mgr.c: 330: }
	goto	l7805
	line	333
	
l7803:	
;charge_mgr.c: 331: else
;charge_mgr.c: 332: {
;charge_mgr.c: 333: ty = Detect_BatteryType(v);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Detect_BatteryType@voltage+1)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Detect_BatteryType@voltage)^080h
	fcall	_Detect_BatteryType
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(ChargeProcess_Slot@ty)^0100h
	line	338
	
l7805:	
;charge_mgr.c: 334: }
;charge_mgr.c: 338: if(v < 500)
	movlw	01h
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0F4h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u11661
	goto	u11660
u11661:
	goto	l7811
u11660:
	line	340
	
l7807:	
;charge_mgr.c: 339: {
;charge_mgr.c: 340: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	341
;charge_mgr.c: 341: if(g_detectLowCnt[idx] < 5)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u11671
	goto	u11670
u11671:
	goto	l7819
u11670:
	goto	l8461
	line	345
	
l7811:	
;charge_mgr.c: 345: else if(ty != 5 && ty != 1 && ty != 6)
		movlw	5
	xorwf	((ChargeProcess_Slot@ty)^0100h),w
	btfsc	status,2
	goto	u11681
	goto	u11680
u11681:
	goto	l7819
u11680:
	
l7813:	
		decf	((ChargeProcess_Slot@ty)^0100h),w
	btfsc	status,2
	goto	u11691
	goto	u11690
u11691:
	goto	l7819
u11690:
	
l7815:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0100h),w
	btfsc	status,2
	goto	u11701
	goto	u11700
u11701:
	goto	l7819
u11700:
	line	347
	
l7817:	
;charge_mgr.c: 346: {
;charge_mgr.c: 347: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	352
	
l7819:	
;charge_mgr.c: 352: if(ty == 5)
		movlw	5
	xorwf	((ChargeProcess_Slot@ty)^0100h),w
	btfss	status,2
	goto	u11711
	goto	u11710
u11711:
	goto	l7845
u11710:
	line	356
	
l7821:	
;charge_mgr.c: 353: {
;charge_mgr.c: 356: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	357
;charge_mgr.c: 357: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11721
	goto	u11720
u11721:
	goto	l7825
u11720:
	goto	l8461
	line	360
	
l7825:	
;charge_mgr.c: 360: if(g_impCheckSlot != 0xFF && g_impCheckSlot != idx)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u11731
	goto	u11730
u11731:
	goto	l7831
u11730:
	
l7827:	
	movf	(_g_impCheckSlot)^080h,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	xorwf	(ChargeProcess_Slot@idx)^0100h,w
	skipnz
	goto	u11741
	goto	u11740
u11741:
	goto	l7831
u11740:
	goto	l8461
	line	362
	
l7831:	
;charge_mgr.c: 362: g_impCheckSlot = idx;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	364
	
l7833:	
;charge_mgr.c: 364: if(0xA5 == ADC_Sample(31, 0))
	clrf	(ADC_Sample@adldo)^080h
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u11751
	goto	u11750
u11751:
	goto	l7837
u11750:
	line	365
	
l7835:	
;charge_mgr.c: 365: g_vcc_mv = (unsigned int)((4096UL * 1200UL) / adresult);
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_vcc_mv+1)	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movf	(0+(?___lldiv))^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_vcc_mv)	;volatile
	line	366
	
l7837:	
;charge_mgr.c: 366: g_impData = v;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impData+1)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impData)^080h
	line	367
	
l7839:	
;charge_mgr.c: 367: st = 8;
	movlw	low(08h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	368
	
l7841:	
;charge_mgr.c: 368: ct = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrf	(ChargeProcess_Slot@ct)^0100h
	clrf	(ChargeProcess_Slot@ct+1)^0100h
	line	369
	
l7843:	
;charge_mgr.c: 369: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	371
	
l7845:	
;charge_mgr.c: 370: }
;charge_mgr.c: 371: if(ty == 1 || ty == 6)
		decf	((ChargeProcess_Slot@ty)^0100h),w
	btfsc	status,2
	goto	u11761
	goto	u11760
u11761:
	goto	l7849
u11760:
	
l7847:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0100h),w
	btfss	status,2
	goto	u11771
	goto	u11770
u11771:
	goto	l7889
u11770:
	line	374
	
l7849:	
;charge_mgr.c: 372: {
;charge_mgr.c: 374: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	375
;charge_mgr.c: 375: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11781
	goto	u11780
u11781:
	goto	l7853
u11780:
	goto	l8461
	line	377
	
l7853:	
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv)^080h

	
l7855:	
	movlw	0Ch
u11795:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u11795

	
l7857:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lmul@multiplier)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long)^080h

	
l7859:	
	movf	(ChargeProcess_Slot@vx_mv+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11801
	addwf	(ChargeProcess_Slot@bat_mv_long+1)^080h,f
u11801:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11802
	addwf	(ChargeProcess_Slot@bat_mv_long+2)^080h,f
u11802:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11803
	addwf	(ChargeProcess_Slot@bat_mv_long+3)^080h,f
u11803:

	
l7861:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	goto	u11810
	goto	u11811
u11810:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u11811:
	movf	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	goto	u11812
	goto	u11813
u11812:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u11813:
	movf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv)^0180h
	
l7863:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u11821
	goto	u11820
u11821:
	goto	l7867
u11820:
	
l7865:	
	movlw	low(02h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7883
	
l7867:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u11831
	goto	u11830
u11831:
	goto	l7871
u11830:
	
l7869:	
	movlw	low(03h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7883
	
l7871:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipc
	goto	u11841
	goto	u11840
u11841:
	goto	l7877
u11840:
	
l7873:	
	movlw	low(05h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l7875:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	goto	l7883
	
l7877:	
	movlw	low(04h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l7879:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l7875
	
l7883:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrf	(ChargeProcess_Slot@ct)^0100h
	clrf	(ChargeProcess_Slot@ct+1)^0100h
	
l7885:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l7737
	line	379
	
l7889:	
;charge_mgr.c: 379: else if(ty == 0)
	movf	((ChargeProcess_Slot@ty)^0100h),w
	btfss	status,2
	goto	u11851
	goto	u11850
u11851:
	goto	l7905
u11850:
	line	381
	
l7891:	
;charge_mgr.c: 380: {
;charge_mgr.c: 381: if(v >= 3990)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11861
	goto	u11860
u11861:
	goto	l7901
u11860:
	line	386
	
l7893:	
;charge_mgr.c: 382: {
;charge_mgr.c: 386: if(ct < (2 * 100) + 200U)
	movlw	01h
	subwf	(ChargeProcess_Slot@ct+1)^0100h,w
	movlw	090h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0100h,w
	skipnc
	goto	u11871
	goto	u11870
u11871:
	goto	l7767
u11870:
	goto	l8461
	line	393
	
l7901:	
;charge_mgr.c: 391: else
;charge_mgr.c: 392: {
;charge_mgr.c: 393: st = 7;
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7737
	line	397
	
l7905:	
;charge_mgr.c: 397: else if(ty == 2 || ty == 3)
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)^0100h),w
	btfsc	status,2
	goto	u11881
	goto	u11880
u11881:
	goto	l7909
u11880:
	
l7907:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0100h),w
	btfss	status,2
	goto	u11891
	goto	u11890
u11891:
	goto	l8461
u11890:
	line	399
	
l7909:	
;charge_mgr.c: 398: {
;charge_mgr.c: 399: st = 7;
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	400
	
l7911:	
;charge_mgr.c: 400: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	401
	
l7913:	
;charge_mgr.c: 401: g_detectLogSlot = idx;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	402
	
l7915:	
;charge_mgr.c: 402: g_detectLogType = ty;
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@ty)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogType)	;volatile
	line	403
	
l7917:	
;charge_mgr.c: 403: g_detectLogFlag = 1;
	bsf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	goto	l8461
	line	408
	
l7919:	
;charge_mgr.c: 408: ct++;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@ct)^0100h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0100h,f
	line	412
	
l7921:	
;charge_mgr.c: 412: if(ct == 1)
		decf	((ChargeProcess_Slot@ct)^0100h),w
iorwf	((ChargeProcess_Slot@ct+1)^0100h),w
	btfss	status,2
	goto	u11901
	goto	u11900
u11901:
	goto	l7929
u11900:
	line	414
	
l7923:	
;charge_mgr.c: 413: {
;charge_mgr.c: 414: if(g_vccLoaded > g_vcc_mv && (g_vccLoaded - g_vcc_mv) > 200U)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_vccLoaded+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_g_vcc_mv+1),w	;volatile
	skipz
	goto	u11915
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vccLoaded)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_g_vcc_mv),w	;volatile
u11915:
	skipnc
	goto	u11911
	goto	u11910
u11911:
	goto	l7929
u11910:
	
l7925:	
	movf	(_g_vcc_mv),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vccLoaded)^080h,w	;volatile
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv+1),w	;volatile
	skipc
	incf	(_g_vcc_mv+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vccLoaded+1)^080h,w	;volatile
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0C9h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u11921
	goto	u11920
u11921:
	goto	l7929
u11920:
	line	415
	
l7927:	
;charge_mgr.c: 415: g_impData |= 0x8000U;
	bsf	(_g_impData)^080h+(15/8),(15)&7
	line	418
	
l7929:	
;charge_mgr.c: 416: }
;charge_mgr.c: 418: if(ct <= 1)
	movlw	0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@ct+1)^0100h,w
	movlw	02h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0100h,w
	skipnc
	goto	u11931
	goto	u11930
u11931:
	goto	l7933
u11930:
	goto	l8461
	line	422
	
l7933:	
;charge_mgr.c: 421: {
;charge_mgr.c: 422: unsigned int pre = (g_impData & 0x0FFFU);
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@pre)^0180h
	movlw	0Fh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData+1)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	1+(ChargeProcess_Slot@pre)^0180h
	line	437
;charge_mgr.c: 437: if(v >= 3990 && pre >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11941
	goto	u11940
u11941:
	goto	l7947
u11940:
	
l7935:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@pre+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@pre)^0180h,w
	skipc
	goto	u11951
	goto	u11950
u11951:
	goto	l7947
u11950:
	line	439
	
l7937:	
;charge_mgr.c: 438: {
;charge_mgr.c: 439: ty = 0;
	bcf	status, 5	;RP0=0, select bank2
	clrf	(ChargeProcess_Slot@ty)^0100h
	line	440
;charge_mgr.c: 440: st = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@st)^080h
	line	441
	
l7939:	
;charge_mgr.c: 441: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	line	442
	
l7941:	
;charge_mgr.c: 442: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11964
u11965:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11964:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11965
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	443
	
l7943:	
;charge_mgr.c: 443: g_slotRefV[idx] = 0xFFFF;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	0FFh
	movwf	indf
	incf	fsr0,f
	movlw	0FFh
	movwf	indf
	goto	l7737
	line	450
	
l7947:	
;charge_mgr.c: 446: }
;charge_mgr.c: 450: if(v >= 3500)
	movlw	0Dh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0ACh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11971
	goto	u11970
u11971:
	goto	l7967
u11970:
	line	454
	
l7949:	
;charge_mgr.c: 451: {
;charge_mgr.c: 454: if(v > pre + 200U)
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@pre)^0180h,w
	addlw	low(0C8h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@pre+1)^0180h,w
	skipnc
	addlw	1
	addlw	high(0C8h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11985
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11985:
	skipnc
	goto	u11981
	goto	u11980
u11981:
	goto	l7993
u11980:
	line	456
	
l7951:	
;charge_mgr.c: 455: {
;charge_mgr.c: 456: if(pre >= 1015 && pre < 3500)
	movlw	03h
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@pre+1)^0180h,w
	movlw	0F7h
	skipnz
	subwf	(ChargeProcess_Slot@pre)^0180h,w
	skipc
	goto	u11991
	goto	u11990
u11991:
	goto	l7937
u11990:
	
l7953:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@pre+1)^0180h,w
	movlw	0ACh
	skipnz
	subwf	(ChargeProcess_Slot@pre)^0180h,w
	skipnc
	goto	u12001
	goto	u12000
u12001:
	goto	l7937
u12000:
	goto	l8037
	line	473
	
l7967:	
;charge_mgr.c: 468: }
;charge_mgr.c: 473: if(pre > v && (pre - v) > 300 && pre <= 2900)
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@pre+1)^0180h,w
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	skipz
	goto	u12015
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@pre)^0180h,w
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v)^0100h,w
u12015:
	skipnc
	goto	u12011
	goto	u12010
u12011:
	goto	l7985
u12010:
	
l7969:	
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@pre)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@pre+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	02Dh
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u12021
	goto	u12020
u12021:
	goto	l7985
u12020:
	
l7971:	
	movlw	0Bh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@pre+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@pre)^0180h,w
	skipnc
	goto	u12031
	goto	u12030
u12031:
	goto	l7985
u12030:
	line	475
	
l7973:	
;charge_mgr.c: 474: {
;charge_mgr.c: 475: ty = 2;
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(ChargeProcess_Slot@ty)^0100h
	line	476
;charge_mgr.c: 476: st = 7;
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	477
;charge_mgr.c: 477: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	line	478
	
l7975:	
;charge_mgr.c: 478: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12044
u12045:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12044:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12045
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	479
	
l7977:	
;charge_mgr.c: 479: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	480
	
l7979:	
;charge_mgr.c: 480: g_detectLogSlot = idx;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	481
	
l7981:	
;charge_mgr.c: 481: g_detectLogType = 2;
	movlw	low(02h)
	movwf	(_g_detectLogType)	;volatile
	goto	l7917
	line	488
	
l7985:	
;charge_mgr.c: 484: }
;charge_mgr.c: 488: if(pre >= 3990 && v >= 1015 && v < 3990)
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@pre+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@pre)^0180h,w
	skipc
	goto	u12051
	goto	u12050
u12051:
	goto	l7993
u12050:
	
l7987:	
	movlw	03h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0F7h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12061
	goto	u12060
u12061:
	goto	l7993
u12060:
	
l7989:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12071
	goto	u12070
u12071:
	goto	l7993
u12070:
	goto	l8037
	line	493
	
l7993:	
;charge_mgr.c: 493: st = 9;
	movlw	low(09h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7669
	line	500
	
l7997:	
;charge_mgr.c: 500: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	501
	
l7999:	
;charge_mgr.c: 501: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12084
u12085:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12084:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12085
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	502
	
l8001:	
;charge_mgr.c: 502: ty = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrf	(ChargeProcess_Slot@ty)^0100h
	incf	(ChargeProcess_Slot@ty)^0100h,f
	line	503
	
l8003:	
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_398+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_398+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_398+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_398)^080h

	
l8005:	
	movlw	0Ch
u12095:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_398+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_398+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_398+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_398)^080h,f
	addlw	-1
	skipz
	goto	u12095

	
l8007:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lmul@multiplier)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_399+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_399+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_399+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_399)^080h

	
l8009:	
	movf	(ChargeProcess_Slot@vx_mv_398+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv_398+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv_398+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv_398)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long_399)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12101
	addwf	(ChargeProcess_Slot@bat_mv_long_399+1)^080h,f
u12101:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12102
	addwf	(ChargeProcess_Slot@bat_mv_long_399+2)^080h,f
u12102:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12103
	addwf	(ChargeProcess_Slot@bat_mv_long_399+3)^080h,f
u12103:

	
l8011:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long_399)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long_399+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_399+1)^080h,w
	goto	u12110
	goto	u12111
u12110:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u12111:
	movf	(ChargeProcess_Slot@bat_mv_long_399+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_399+2)^080h,w
	goto	u12112
	goto	u12113
u12112:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u12113:
	movf	(ChargeProcess_Slot@bat_mv_long_399+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_399+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_400+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_400)^0180h
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_400+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_400)^0180h,w
	skipnc
	goto	u12121
	goto	u12120
u12121:
	goto	l8015
u12120:
	goto	l7865
	
l8015:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_400+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_400)^0180h,w
	skipnc
	goto	u12131
	goto	u12130
u12131:
	goto	l8019
u12130:
	goto	l7869
	
l8019:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_400+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_400)^0180h,w
	skipc
	goto	u12141
	goto	u12140
u12141:
	goto	l7877
u12140:
	goto	l7873
	line	508
	
l8037:	
;charge_mgr.c: 508: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	509
	
l8039:	
;charge_mgr.c: 509: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12154
u12155:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12154:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12155
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	510
	
l8041:	
;charge_mgr.c: 510: ty = 6;
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(ChargeProcess_Slot@ty)^0100h
	line	511
	
l8043:	
;charge_mgr.c: 511: if(v < 3990)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12161
	goto	u12160
u12161:
	goto	l8081
u12160:
	line	512
	
l8045:	
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_401+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_401+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_401+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_401)^080h

	
l8047:	
	movlw	0Ch
u12175:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_401+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_401+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_401+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_401)^080h,f
	addlw	-1
	skipz
	goto	u12175

	
l8049:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lmul@multiplier)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_402+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_402+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_402+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_402)^080h

	
l8051:	
	movf	(ChargeProcess_Slot@vx_mv_401+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv_401+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv_401+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv_401)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long_402)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12181
	addwf	(ChargeProcess_Slot@bat_mv_long_402+1)^080h,f
u12181:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12182
	addwf	(ChargeProcess_Slot@bat_mv_long_402+2)^080h,f
u12182:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12183
	addwf	(ChargeProcess_Slot@bat_mv_long_402+3)^080h,f
u12183:

	
l8053:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long_402)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long_402+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_402+1)^080h,w
	goto	u12190
	goto	u12191
u12190:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u12191:
	movf	(ChargeProcess_Slot@bat_mv_long_402+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_402+2)^080h,w
	goto	u12192
	goto	u12193
u12192:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u12193:
	movf	(ChargeProcess_Slot@bat_mv_long_402+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_402+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_403+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_403)^0180h
	
l8055:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_403+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_403)^0180h,w
	skipnc
	goto	u12201
	goto	u12200
u12201:
	goto	l8059
u12200:
	goto	l7865
	
l8059:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_403+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_403)^0180h,w
	skipnc
	goto	u12211
	goto	u12210
u12211:
	goto	l8063
u12210:
	goto	l7869
	
l8063:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_403+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_403)^0180h,w
	skipc
	goto	u12221
	goto	u12220
u12221:
	goto	l7877
u12220:
	goto	l7873
	line	514
	
l8081:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(___lmul@multiplier)^080h
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(___lmul@multiplier)^080h
	clrf	2+(___lmul@multiplier)^080h
	clrf	3+(___lmul@multiplier)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_404+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_404+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_404+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_404)^080h

	
l8083:	
	movlw	0Ch
u12235:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_404+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_404+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_404+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_404)^080h,f
	addlw	-1
	skipz
	goto	u12235

	
l8085:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lmul@multiplier)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_405+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_405+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_405+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_405)^080h

	
l8087:	
	movf	(ChargeProcess_Slot@vx_mv_404+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv_404+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv_404+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv_404)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long_405)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12241
	addwf	(ChargeProcess_Slot@bat_mv_long_405+1)^080h,f
u12241:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12242
	addwf	(ChargeProcess_Slot@bat_mv_long_405+2)^080h,f
u12242:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12243
	addwf	(ChargeProcess_Slot@bat_mv_long_405+3)^080h,f
u12243:

	
l8089:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long_405)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long_405+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_405+1)^080h,w
	goto	u12250
	goto	u12251
u12250:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u12251:
	movf	(ChargeProcess_Slot@bat_mv_long_405+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_405+2)^080h,w
	goto	u12252
	goto	u12253
u12252:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u12253:
	movf	(ChargeProcess_Slot@bat_mv_long_405+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_405+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_406+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_406)^0180h
	
l8091:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_406+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_406)^0180h,w
	skipnc
	goto	u12261
	goto	u12260
u12261:
	goto	l8095
u12260:
	goto	l7865
	
l8095:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_406+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_406)^0180h,w
	skipnc
	goto	u12271
	goto	u12270
u12271:
	goto	l8099
u12270:
	goto	l7869
	
l8099:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_406+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_406)^0180h,w
	skipc
	goto	u12281
	goto	u12280
u12281:
	goto	l8105
u12280:
	
l8101:	
	movlw	low(05h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l8103:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	goto	l7883
	
l8105:	
	movlw	low(04h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l8107:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l8103
	line	522
	
l8117:	
;charge_mgr.c: 522: ct++;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@ct)^0100h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0100h,f
	line	535
	
l8123:	
;charge_mgr.c: 527: }
;charge_mgr.c: 534: if(ct > 10 && v + 500U < (g_impData & 0x0FFFU)
;charge_mgr.c: 535: && (g_impData & 0x0FFFU) <= 2900)
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1)^0100h,w
	movlw	0Bh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0100h,w
	skipc
	goto	u12291
	goto	u12290
u12291:
	goto	l8141
u12290:
	
l8125:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	addlw	low(01F4h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipnc
	addlw	1
	addlw	high(01F4h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	skipz
	goto	u12305
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
u12305:
	skipnc
	goto	u12301
	goto	u12300
u12301:
	goto	l8141
u12300:
	
l8127:	
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Bh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	055h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	goto	u12311
	goto	u12310
u12311:
	goto	l8141
u12310:
	goto	l7973
	line	549
	
l8141:	
;charge_mgr.c: 546: }
;charge_mgr.c: 549: if(v > (g_impData & 0x0FFFU) + 900)
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(0384h)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(0384h)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	skipz
	goto	u12325
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
u12325:
	skipnc
	goto	u12321
	goto	u12320
u12321:
	goto	l8145
u12320:
	goto	l8037
	line	556
	
l8145:	
;charge_mgr.c: 556: if(ct >= 100)
	movlw	0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@ct+1)^0100h,w
	movlw	064h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0100h,w
	skipc
	goto	u12331
	goto	u12330
u12331:
	goto	l8461
u12330:
	line	558
	
l8147:	
;charge_mgr.c: 557: {
;charge_mgr.c: 558: unsigned int pre_v = (g_impData & 0x0FFFU);
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@pre_v)^0180h
	movlw	0Fh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData+1)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	1+(ChargeProcess_Slot@pre_v)^0180h
	line	559
	
l8149:	
;charge_mgr.c: 559: if((g_highVFlag & ((unsigned int)1 << idx)) || pre_v >= 2300U)
	bcf	status, 5	;RP0=0, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12344
u12345:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12344:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12345
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfss	status,2
	goto	u12351
	goto	u12350
u12351:
	goto	l7997
u12350:
	
l8151:	
	movlw	08h
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@pre_v+1)^0180h,w
	movlw	0FCh
	skipnz
	subwf	(ChargeProcess_Slot@pre_v)^0180h,w
	skipc
	goto	u12361
	goto	u12360
u12361:
	goto	l8155
u12360:
	goto	l7997
	line	561
	
l8155:	
;charge_mgr.c: 561: else if(pre_v >= 1015 && pre_v <= 2900 && (g_impData & 0x8000U))
	movlw	03h
	subwf	(ChargeProcess_Slot@pre_v+1)^0180h,w
	movlw	0F7h
	skipnz
	subwf	(ChargeProcess_Slot@pre_v)^0180h,w
	skipc
	goto	u12371
	goto	u12370
u12371:
	goto	l8173
u12370:
	
l8157:	
	movlw	0Bh
	subwf	(ChargeProcess_Slot@pre_v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@pre_v)^0180h,w
	skipnc
	goto	u12381
	goto	u12380
u12381:
	goto	l8173
u12380:
	
l8159:	
	bcf	status, 6	;RP1=0, select bank1
	btfss	(_g_impData+1)^080h,(15)&7
	goto	u12391
	goto	u12390
u12391:
	goto	l8173
u12390:
	goto	l7973
	line	576
	
l8173:	
;charge_mgr.c: 573: else
;charge_mgr.c: 574: {
;charge_mgr.c: 576: ty = 3;
	movlw	low(03h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(ChargeProcess_Slot@ty)^0100h
	line	577
;charge_mgr.c: 577: st = 7;
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	578
;charge_mgr.c: 578: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	line	579
	
l8175:	
;charge_mgr.c: 579: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12404
u12405:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12404:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12405
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	580
	
l8177:	
;charge_mgr.c: 580: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	581
	
l8179:	
;charge_mgr.c: 581: g_detectLogSlot = idx;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	582
	
l8181:	
;charge_mgr.c: 582: g_detectLogType = 3;
	movlw	low(03h)
	movwf	(_g_detectLogType)	;volatile
	goto	l7917
	line	592
	
l8185:	
;charge_mgr.c: 592: ct++;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@ct)^0100h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0100h,f
	line	593
	
l8187:	
;charge_mgr.c: 593: if(ct > (60 * 100))
	movlw	017h
	subwf	(ChargeProcess_Slot@ct+1)^0100h,w
	movlw	071h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0100h,w
	skipc
	goto	u12411
	goto	u12410
u12411:
	goto	l8191
u12410:
	line	595
	
l8189:	
;charge_mgr.c: 594: {
;charge_mgr.c: 595: st = 7;
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	596
;charge_mgr.c: 596: break;
	goto	l8461
	line	598
	
l8191:	
;charge_mgr.c: 597: }
;charge_mgr.c: 598: if(v > 750)
	movlw	02h
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12421
	goto	u12420
u12421:
	goto	l8197
u12420:
	line	600
	
l8193:	
;charge_mgr.c: 599: {
;charge_mgr.c: 600: st = 3;
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7669
	line	604
	
l8197:	
;charge_mgr.c: 603: }
;charge_mgr.c: 604: if(v >= 3850)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12431
	goto	u12430
u12431:
	goto	l8461
u12430:
	goto	l8189
	line	612
	
l8201:	
;charge_mgr.c: 612: ct++;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@ct)^0100h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0100h,f
	line	613
	
l8203:	
;charge_mgr.c: 613: if(ct > (300 * 100))
	movlw	075h
	subwf	(ChargeProcess_Slot@ct+1)^0100h,w
	movlw	031h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0100h,w
	skipc
	goto	u12441
	goto	u12440
u12441:
	goto	l8207
u12440:
	goto	l8189
	line	618
	
l8207:	
;charge_mgr.c: 617: }
;charge_mgr.c: 618: if(v >= 3850)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12451
	goto	u12450
u12451:
	goto	l8213
u12450:
	line	620
	
l8209:	
;charge_mgr.c: 619: {
;charge_mgr.c: 620: g_ovCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	621
;charge_mgr.c: 621: if(g_ovCnt[idx] >= 5)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u12461
	goto	u12460
u12461:
	goto	l8215
u12460:
	goto	l8189
	line	629
	
l8213:	
;charge_mgr.c: 627: else
;charge_mgr.c: 628: {
;charge_mgr.c: 629: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	631
	
l8215:	
;charge_mgr.c: 630: }
;charge_mgr.c: 631: if(v >= 2700)
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	08Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12471
	goto	u12470
u12471:
	goto	l8461
u12470:
	line	633
	
l8217:	
;charge_mgr.c: 632: {
;charge_mgr.c: 633: st = 4;
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	634
	
l8219:	
;charge_mgr.c: 634: ct = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrf	(ChargeProcess_Slot@ct)^0100h
	clrf	(ChargeProcess_Slot@ct+1)^0100h
	line	635
	
l8221:	
;charge_mgr.c: 635: g_ccBlocks[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	636
	
l8223:	
;charge_mgr.c: 636: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7759
	line	642
	
l8227:	
;charge_mgr.c: 642: ct++;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@ct)^0100h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0100h,f
	line	643
	
l8229:	
;charge_mgr.c: 643: if(ct >= (600 * 100))
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0100h,w
	movlw	060h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0100h,w
	skipc
	goto	u12481
	goto	u12480
u12481:
	goto	l8235
u12480:
	line	645
	
l8231:	
;charge_mgr.c: 644: {
;charge_mgr.c: 645: ct -= (600 * 100);
	movlw	060h
	subwf	(ChargeProcess_Slot@ct)^0100h,f
	movlw	0EAh
	skipc
	decf	(ChargeProcess_Slot@ct+1)^0100h,f
	subwf	(ChargeProcess_Slot@ct+1)^0100h,f
	line	646
	
l8233:	
;charge_mgr.c: 646: g_ccBlocks[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	648
	
l8235:	
;charge_mgr.c: 647: }
;charge_mgr.c: 648: if(g_ccBlocks[idx] >= 18)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(012h)
	subwf	indf,w
	skipc
	goto	u12491
	goto	u12490
u12491:
	goto	l8239
u12490:
	goto	l8189
	line	655
	
l8239:	
;charge_mgr.c: 652: }
;charge_mgr.c: 655: if(ty == 6 && g_ccBlocks[idx] >= 8)
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0100h),w
	btfss	status,2
	goto	u12501
	goto	u12500
u12501:
	goto	l8247
u12500:
	
l8241:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(08h)
	subwf	indf,w
	skipc
	goto	u12511
	goto	u12510
u12511:
	goto	l8247
u12510:
	line	657
	
l8243:	
;charge_mgr.c: 656: {
;charge_mgr.c: 657: st = 5;
	movlw	low(05h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7669
	line	664
	
l8247:	
;charge_mgr.c: 660: }
;charge_mgr.c: 663: if(v < 3990 && v > g_slotRefV[idx]
;charge_mgr.c: 664: && (ty != 6 || v < 3500U))
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12521
	goto	u12520
u12521:
	goto	l726
u12520:
	
l8249:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u12535
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u12535:
	skipnc
	goto	u12531
	goto	u12530
u12531:
	goto	l726
u12530:
	
l8251:	
		movlw	6
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	xorwf	((ChargeProcess_Slot@ty)^0100h),w
	btfss	status,2
	goto	u12541
	goto	u12540
u12541:
	goto	l8255
u12540:
	
l8253:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0ACh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12551
	goto	u12550
u12551:
	goto	l726
u12550:
	line	665
	
l8255:	
;charge_mgr.c: 665: g_slotRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	
l726:	
	line	668
;charge_mgr.c: 668: if(v < g_slotRefV[idx] && g_slotRefV[idx] - v > 500)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	skipz
	goto	u12565
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v)^0100h,w
u12565:
	skipnc
	goto	u12561
	goto	u12560
u12561:
	goto	l8271
u12560:
	
l8257:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u12571
	goto	u12570
u12571:
	goto	l8271
u12570:
	line	670
	
l8259:	
;charge_mgr.c: 669: {
;charge_mgr.c: 670: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	671
;charge_mgr.c: 671: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12581
	goto	u12580
u12581:
	goto	l7665
u12580:
	goto	l8461
	line	680
	
l8271:	
;charge_mgr.c: 678: else
;charge_mgr.c: 679: {
;charge_mgr.c: 680: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	684
	
l8273:	
;charge_mgr.c: 681: }
;charge_mgr.c: 684: if(v >= 3990 && ty == 1)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12591
	goto	u12590
u12591:
	goto	l8281
u12590:
	
l8275:	
		decf	((ChargeProcess_Slot@ty)^0100h),w
	btfss	status,2
	goto	u12601
	goto	u12600
u12601:
	goto	l8281
u12600:
	line	686
	
l8277:	
;charge_mgr.c: 685: {
;charge_mgr.c: 686: st = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7669
	line	692
	
l8281:	
;charge_mgr.c: 689: }
;charge_mgr.c: 692: if(ty == 6)
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0100h),w
	btfss	status,2
	goto	u12611
	goto	u12610
u12611:
	goto	l8289
u12610:
	line	694
	
l8283:	
;charge_mgr.c: 693: {
;charge_mgr.c: 694: if(g_slotRefV[idx] >= 3100)
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movlw	0Ch
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	01Ch
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u12621
	goto	u12620
u12621:
	goto	l8461
u12620:
	goto	l8243
	line	703
	
l8289:	
;charge_mgr.c: 700: }
;charge_mgr.c: 703: if(v >= 3850)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12631
	goto	u12630
u12631:
	goto	l8295
u12630:
	line	705
	
l8291:	
;charge_mgr.c: 704: {
;charge_mgr.c: 705: g_ovCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	706
;charge_mgr.c: 706: if(g_ovCnt[idx] >= 5)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u12641
	goto	u12640
u12641:
	goto	l600
u12640:
	goto	l8189
	line	714
	
l8295:	
;charge_mgr.c: 712: else
;charge_mgr.c: 713: {
;charge_mgr.c: 714: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	716
	
l8297:	
;charge_mgr.c: 716: if(v >= 3100)
	movlw	0Ch
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	01Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12651
	goto	u12650
u12651:
	goto	l600
u12650:
	goto	l8243
	line	725
	
l8303:	
;charge_mgr.c: 725: ct++;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@ct)^0100h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0100h,f
	line	726
	
l8305:	
;charge_mgr.c: 726: if(ct > (600 * 100))
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0100h,w
	movlw	061h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0100h,w
	skipc
	goto	u12661
	goto	u12660
u12661:
	goto	l740
u12660:
	line	727
	
l8307:	
;charge_mgr.c: 727: st = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l740:	
	line	731
;charge_mgr.c: 730: if(v < 3990 && v > g_slotRefV[idx]
;charge_mgr.c: 731: && (ty != 6 || v < 3500U))
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12671
	goto	u12670
u12671:
	goto	l8317
u12670:
	
l8309:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u12685
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u12685:
	skipnc
	goto	u12681
	goto	u12680
u12681:
	goto	l8317
u12680:
	
l8311:	
		movlw	6
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	xorwf	((ChargeProcess_Slot@ty)^0100h),w
	btfss	status,2
	goto	u12691
	goto	u12690
u12691:
	goto	l8315
u12690:
	
l8313:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0ACh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12701
	goto	u12700
u12701:
	goto	l8317
u12700:
	line	732
	
l8315:	
;charge_mgr.c: 732: g_slotRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	735
	
l8317:	
;charge_mgr.c: 735: if(v >= 3990 && ty != 6)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12711
	goto	u12710
u12711:
	goto	l8345
u12710:
	
l8319:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0100h),w
	btfsc	status,2
	goto	u12721
	goto	u12720
u12721:
	goto	l8345
u12720:
	line	737
	
l8321:	
;charge_mgr.c: 736: {
;charge_mgr.c: 737: if(ty == 1)
		decf	((ChargeProcess_Slot@ty)^0100h),w
	btfss	status,2
	goto	u12731
	goto	u12730
u12731:
	goto	l8333
u12730:
	line	739
	
l8323:	
;charge_mgr.c: 738: {
;charge_mgr.c: 739: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	740
;charge_mgr.c: 740: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12741
	goto	u12740
u12741:
	goto	l8327
u12740:
	goto	l8461
	line	742
	
l8327:	
;charge_mgr.c: 742: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8277
	line	747
	
l8333:	
;charge_mgr.c: 746: }
;charge_mgr.c: 747: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	748
;charge_mgr.c: 748: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12751
	goto	u12750
u12751:
	goto	l8337
u12750:
	goto	l8461
	line	750
	
l8337:	
;charge_mgr.c: 750: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	751
	
l8339:	
;charge_mgr.c: 751: ty = 0;
	clrf	(ChargeProcess_Slot@ty)^0100h
	line	752
	
l8341:	
;charge_mgr.c: 752: st = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@st)^080h
	goto	l7669
	line	758
	
l8345:	
;charge_mgr.c: 755: }
;charge_mgr.c: 758: if(v < g_slotRefV[idx] && g_slotRefV[idx] - v > 500)
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	skipz
	goto	u12765
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v)^0100h,w
u12765:
	skipnc
	goto	u12761
	goto	u12760
u12761:
	goto	l8359
u12760:
	
l8347:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u12771
	goto	u12770
u12771:
	goto	l8359
u12770:
	line	760
	
l8349:	
;charge_mgr.c: 759: {
;charge_mgr.c: 760: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	761
;charge_mgr.c: 761: if(g_detectLowCnt[idx] >= 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipc
	goto	u12781
	goto	u12780
u12781:
	goto	l8361
u12780:
	line	763
	
l8351:	
;charge_mgr.c: 762: {
;charge_mgr.c: 763: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	764
	
l8353:	
;charge_mgr.c: 764: ty = 0;
	clrf	(ChargeProcess_Slot@ty)^0100h
	goto	l7667
	line	772
	
l8359:	
;charge_mgr.c: 770: else
;charge_mgr.c: 771: {
;charge_mgr.c: 772: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	776
	
l8361:	
;charge_mgr.c: 773: }
;charge_mgr.c: 776: if(v >= 3850)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12791
	goto	u12790
u12791:
	goto	l8367
u12790:
	line	778
	
l8363:	
;charge_mgr.c: 777: {
;charge_mgr.c: 778: g_ovCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	779
;charge_mgr.c: 779: if(g_ovCnt[idx] >= 5)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u12801
	goto	u12800
u12801:
	goto	l600
u12800:
	goto	l8189
	line	787
	
l8367:	
;charge_mgr.c: 785: else
;charge_mgr.c: 786: {
;charge_mgr.c: 787: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8461
	line	793
	
l8369:	
;charge_mgr.c: 793: if(v >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12811
	goto	u12810
u12811:
	goto	l8387
u12810:
	line	795
	
l8371:	
;charge_mgr.c: 794: {
;charge_mgr.c: 795: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	796
	
l8373:	
;charge_mgr.c: 796: if(g_detectLowCnt[idx] >= (ty == 6 ? 50 : 2))
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0100h),w
	btfsc	status,2
	goto	u12821
	goto	u12820
u12821:
	goto	l8377
u12820:
	
l8375:	
	movlw	02h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_ChargeProcess_Slot$408)^080h
	clrf	(_ChargeProcess_Slot$408+1)^080h
	goto	l8379
	
l8377:	
	movlw	032h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_ChargeProcess_Slot$408)^080h
	clrf	(_ChargeProcess_Slot$408+1)^080h
	
l8379:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_ChargeProcess_Slot$408+1)^080h,w
	xorlw	80h
	sublw	080h
	skipz
	goto	u12835
	movf	(_ChargeProcess_Slot$408)^080h,w
	subwf	indf,w
u12835:

	skipc
	goto	u12831
	goto	u12830
u12831:
	goto	l8461
u12830:
	line	798
	
l8381:	
;charge_mgr.c: 797: {
;charge_mgr.c: 798: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l8341
	line	805
	
l8387:	
;charge_mgr.c: 803: }
;charge_mgr.c: 805: if(v < 2800U)
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12841
	goto	u12840
u12841:
	goto	l7737
u12840:
	line	807
	
l8389:	
;charge_mgr.c: 806: {
;charge_mgr.c: 807: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	808
;charge_mgr.c: 808: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12851
	goto	u12850
u12851:
	goto	l8393
u12850:
	goto	l8461
	line	810
	
l8393:	
;charge_mgr.c: 810: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8217
	line	825
	
l8407:	
;charge_mgr.c: 825: if(v >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12861
	goto	u12860
u12861:
	goto	l8421
u12860:
	line	827
	
l8409:	
;charge_mgr.c: 826: {
;charge_mgr.c: 827: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	828
;charge_mgr.c: 828: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12871
	goto	u12870
u12871:
	goto	l8337
u12870:
	goto	l8461
	line	838
	
l8421:	
;charge_mgr.c: 835: }
;charge_mgr.c: 838: if(ty == 2 || ty == 3)
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)^0100h),w
	btfsc	status,2
	goto	u12881
	goto	u12880
u12881:
	goto	l8425
u12880:
	
l8423:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0100h),w
	btfss	status,2
	goto	u12891
	goto	u12890
u12891:
	goto	l8441
u12890:
	line	840
	
l8425:	
;charge_mgr.c: 839: {
;charge_mgr.c: 840: if(v > 2700U && (g_highVFlag & ((unsigned int)1 << idx)))
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	08Dh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12901
	goto	u12900
u12901:
	goto	l7737
u12900:
	
l8427:	
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12914
u12915:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12914:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12915
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u12921
	goto	u12920
u12921:
	goto	l7737
u12920:
	line	842
	
l8429:	
;charge_mgr.c: 841: {
;charge_mgr.c: 842: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	843
;charge_mgr.c: 843: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12931
	goto	u12930
u12931:
	goto	l7665
u12930:
	goto	l8461
	line	856
	
l8441:	
;charge_mgr.c: 854: }
;charge_mgr.c: 856: if(v > 750)
	movlw	02h
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12941
	goto	u12940
u12941:
	goto	l7737
u12940:
	line	858
	
l8443:	
;charge_mgr.c: 857: {
;charge_mgr.c: 858: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	859
;charge_mgr.c: 859: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12951
	goto	u12950
u12951:
	goto	l7665
u12950:
	goto	l8461
	line	872
	
l8455:	
;charge_mgr.c: 872: st = 0;
	clrf	(ChargeProcess_Slot@st)^080h
	line	873
;charge_mgr.c: 873: break;
	goto	l8461
	line	146
	
l8459:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(ChargeProcess_Slot@st)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l7651
	xorlw	1^0	; case 1
	skipnz
	goto	l7673
	xorlw	2^1	; case 2
	skipnz
	goto	l8185
	xorlw	3^2	; case 3
	skipnz
	goto	l8201
	xorlw	4^3	; case 4
	skipnz
	goto	l8227
	xorlw	5^4	; case 5
	skipnz
	goto	l8303
	xorlw	6^5	; case 6
	skipnz
	goto	l8369
	xorlw	7^6	; case 7
	skipnz
	goto	l8407
	xorlw	8^7	; case 8
	skipnz
	goto	l7919
	xorlw	9^8	; case 9
	skipnz
	goto	l8117
	goto	l8455
	opt asmopt_pop

	line	874
	
l600:	
	line	876
	
l8461:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@st)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@ty)^0100h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@ct)^0100h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@ct+1)^0100h,w
	movwf	indf
	line	881
	
l8463:	
;charge_mgr.c: 879: {
;charge_mgr.c: 880: static unsigned char s_oldSt[6];
;charge_mgr.c: 881: if(idx <= 5 && st != s_oldSt[idx])
	movlw	low(06h)
	subwf	(ChargeProcess_Slot@idx)^0100h,w
	skipnc
	goto	u12961
	goto	u12960
u12961:
	goto	l782
u12960:
	
l8465:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(ChargeProcess_Slot@s_oldSt|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	xorwf	(ChargeProcess_Slot@st)^080h,w
	skipnz
	goto	u12971
	goto	u12970
u12971:
	goto	l782
u12970:
	line	883
	
l8467:	
;charge_mgr.c: 882: {
;charge_mgr.c: 883: g_dbgSlot = idx;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_dbgSlot)	;volatile
	line	884
	
l8469:	
;charge_mgr.c: 884: g_dbgOldState = s_oldSt[idx];
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(ChargeProcess_Slot@s_oldSt|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_dbgOldState)	;volatile
	line	885
	
l8471:	
;charge_mgr.c: 885: g_dbgNewState = st;
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@st)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_dbgNewState)	;volatile
	line	886
	
l8473:	
;charge_mgr.c: 886: g_dbgNewType = ty;
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@ty)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_dbgNewType)	;volatile
	line	887
	
l8475:	
;charge_mgr.c: 887: g_dbgVoltage = v;
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank3
	movwf	(_g_dbgVoltage+1)^0180h	;volatile
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank3
	movwf	(_g_dbgVoltage)^0180h	;volatile
	line	888
	
l8477:	
;charge_mgr.c: 888: g_dbgDetectFlag = 1;
	bsf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	889
;charge_mgr.c: 889: s_oldSt[idx] = st;
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(ChargeProcess_Slot@s_oldSt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(ChargeProcess_Slot@st)^080h,w
	movwf	indf
	line	892
	
l782:	
	return
	opt stack 0
GLOBAL	__end_of_ChargeProcess_Slot
	__end_of_ChargeProcess_Slot:
	signat	_ChargeProcess_Slot,4217
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    0[BANK1 ] unsigned long 
;;  multiplicand    4    4[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    8[BANK1 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    0[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext16
__ptext16:	;psect for function ___lmul
psect	text16
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l6959:	
	clrf	(___lmul@product)^080h
	clrf	(___lmul@product+1)^080h
	clrf	(___lmul@product+2)^080h
	clrf	(___lmul@product+3)^080h
	line	120
	
l954:	
	line	121
	btfss	(___lmul@multiplier)^080h,(0)&7
	goto	u10171
	goto	u10170
u10171:
	goto	l6963
u10170:
	line	122
	
l6961:	
	movf	(___lmul@multiplicand)^080h,w
	addwf	(___lmul@product)^080h,f
	movf	(___lmul@multiplicand+1)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10181
	addwf	(___lmul@product+1)^080h,f
u10181:
	movf	(___lmul@multiplicand+2)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10182
	addwf	(___lmul@product+2)^080h,f
u10182:
	movf	(___lmul@multiplicand+3)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10183
	addwf	(___lmul@product+3)^080h,f
u10183:

	line	123
	
l6963:	
	clrc
	rlf	(___lmul@multiplicand)^080h,f
	rlf	(___lmul@multiplicand+1)^080h,f
	rlf	(___lmul@multiplicand+2)^080h,f
	rlf	(___lmul@multiplicand+3)^080h,f
	line	124
	
l6965:	
	clrc
	rrf	(___lmul@multiplier+3)^080h,f
	rrf	(___lmul@multiplier+2)^080h,f
	rrf	(___lmul@multiplier+1)^080h,f
	rrf	(___lmul@multiplier)^080h,f
	line	125
	movf	(___lmul@multiplier+3)^080h,w
	iorwf	(___lmul@multiplier+2)^080h,w
	iorwf	(___lmul@multiplier+1)^080h,w
	iorwf	(___lmul@multiplier)^080h,w
	skipz
	goto	u10191
	goto	u10190
u10191:
	goto	l954
u10190:
	line	128
	
l6967:	
	movf	(___lmul@product+3)^080h,w
	movwf	(?___lmul+3)^080h
	movf	(___lmul@product+2)^080h,w
	movwf	(?___lmul+2)^080h
	movf	(___lmul@product+1)^080h,w
	movwf	(?___lmul+1)^080h
	movf	(___lmul@product)^080h,w
	movwf	(?___lmul)^080h

	line	129
	
l957:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4   12[BANK1 ] unsigned long 
;;  dividend        4   16[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   21[BANK1 ] unsigned long 
;;  counter         1   20[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4   12[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       0       5       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext17
__ptext17:	;psect for function ___lldiv
psect	text17
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l6971:	
	clrf	(___lldiv@quotient)^080h
	clrf	(___lldiv@quotient+1)^080h
	clrf	(___lldiv@quotient+2)^080h
	clrf	(___lldiv@quotient+3)^080h
	line	15
	
l6973:	
	movf	(___lldiv@divisor+3)^080h,w
	iorwf	(___lldiv@divisor+2)^080h,w
	iorwf	(___lldiv@divisor+1)^080h,w
	iorwf	(___lldiv@divisor)^080h,w
	skipnz
	goto	u10201
	goto	u10200
u10201:
	goto	l6993
u10200:
	line	16
	
l6975:	
	clrf	(___lldiv@counter)^080h
	incf	(___lldiv@counter)^080h,f
	line	17
	goto	l6979
	line	18
	
l6977:	
	clrc
	rlf	(___lldiv@divisor)^080h,f
	rlf	(___lldiv@divisor+1)^080h,f
	rlf	(___lldiv@divisor+2)^080h,f
	rlf	(___lldiv@divisor+3)^080h,f
	line	19
	incf	(___lldiv@counter)^080h,f
	line	17
	
l6979:	
	btfss	(___lldiv@divisor+3)^080h,(31)&7
	goto	u10211
	goto	u10210
u10211:
	goto	l6977
u10210:
	line	22
	
l6981:	
	clrc
	rlf	(___lldiv@quotient)^080h,f
	rlf	(___lldiv@quotient+1)^080h,f
	rlf	(___lldiv@quotient+2)^080h,f
	rlf	(___lldiv@quotient+3)^080h,f
	line	23
	
l6983:	
	movf	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,w
	skipz
	goto	u10225
	movf	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,w
	skipz
	goto	u10225
	movf	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,w
	skipz
	goto	u10225
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,w
u10225:
	skipc
	goto	u10221
	goto	u10220
u10221:
	goto	l6989
u10220:
	line	24
	
l6985:	
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,f
	movf	(___lldiv@divisor+1)^080h,w
	skipc
	incfsz	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,f
	movf	(___lldiv@divisor+2)^080h,w
	skipc
	incfsz	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,f
	movf	(___lldiv@divisor+3)^080h,w
	skipc
	incfsz	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,f
	line	25
	
l6987:	
	bsf	(___lldiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l6989:	
	clrc
	rrf	(___lldiv@divisor+3)^080h,f
	rrf	(___lldiv@divisor+2)^080h,f
	rrf	(___lldiv@divisor+1)^080h,f
	rrf	(___lldiv@divisor)^080h,f
	line	28
	
l6991:	
	decfsz	(___lldiv@counter)^080h,f
	goto	u10231
	goto	u10230
u10231:
	goto	l6981
u10230:
	line	30
	
l6993:	
	movf	(___lldiv@quotient+3)^080h,w
	movwf	(?___lldiv+3)^080h
	movf	(___lldiv@quotient+2)^080h,w
	movwf	(?___lldiv+2)^080h
	movf	(___lldiv@quotient+1)^080h,w
	movwf	(?___lldiv+1)^080h
	movf	(___lldiv@quotient)^080h,w
	movwf	(?___lldiv)^080h

	line	31
	
l1229:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[BANK1 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    2[BANK1 ] unsigned char 
;;  product         1    1[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       1       0       0
;;      Locals:         0       0       2       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Isr_Timer
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext18
__ptext18:	;psect for function ___bmul
psect	text18
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplier)^080h
	line	6
	
l7157:	
	clrf	(___bmul@product)^080h
	line	43
	
l7159:	
	btfss	(___bmul@multiplier)^080h,(0)&7
	goto	u10521
	goto	u10520
u10521:
	goto	l7163
u10520:
	line	44
	
l7161:	
	movf	(___bmul@multiplicand)^080h,w
	addwf	(___bmul@product)^080h,f
	line	45
	
l7163:	
	clrc
	rlf	(___bmul@multiplicand)^080h,f
	line	46
	
l7165:	
	clrc
	rrf	(___bmul@multiplier)^080h,f
	line	47
	movf	((___bmul@multiplier)^080h),w
	btfss	status,2
	goto	u10531
	goto	u10530
u10531:
	goto	l7159
u10530:
	line	50
	
l7167:	
	movf	(___bmul@product)^080h,w
	line	51
	
l963:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 75 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2    0[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	75
global __ptext19
__ptext19:	;psect for function _Detect_BatteryType
psect	text19
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	75
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	77
	
l7125:	
;charge_mgr.c: 77: if(voltage >= 3990)
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipc
	goto	u10461
	goto	u10460
u10461:
	goto	l7131
u10460:
	line	78
	
l7127:	
;charge_mgr.c: 78: return 0;
	movlw	low(0)
	goto	l586
	line	79
	
l7131:	
;charge_mgr.c: 79: if(voltage < 500)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipnc
	goto	u10471
	goto	u10470
u10471:
	goto	l7137
u10470:
	goto	l7127
	line	90
	
l7137:	
;charge_mgr.c: 90: if(voltage >= 1015 && voltage < 3990)
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipc
	goto	u10481
	goto	u10480
u10481:
	goto	l7145
u10480:
	
l7139:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipnc
	goto	u10491
	goto	u10490
u10491:
	goto	l7145
u10490:
	line	91
	
l7141:	
;charge_mgr.c: 91: return 5;
	movlw	low(05h)
	goto	l586
	line	96
	
l7145:	
;charge_mgr.c: 96: if(voltage >= 500 && voltage < 3990)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipc
	goto	u10501
	goto	u10500
u10501:
	goto	l7127
u10500:
	
l7147:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipnc
	goto	u10511
	goto	u10510
u10511:
	goto	l7127
u10510:
	line	97
	
l7149:	
;charge_mgr.c: 97: return 1;
	movlw	low(01h)
	line	100
	
l586:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    0[BANK1 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    6[BANK1 ] unsigned char 
;;  j               1    5[BANK1 ] unsigned char 
;;  adsum           4    8[BANK1 ] volatile unsigned long 
;;  ad_temp         2   16[BANK1 ] volatile unsigned int 
;;  admax           2   14[BANK1 ] volatile unsigned int 
;;  admin           2   12[BANK1 ] volatile unsigned int 
;;  i               1    7[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       1       0       0
;;      Locals:         0       0      13       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       0      18       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext20
__ptext20:	;psect for function _ADC_Sample
psect	text20
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	movwf	(ADC_Sample@adch)^080h
	line	51
	
l5145:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	52
	
l5147:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(ADC_Sample@admin)^080h	;volatile
	clrf	(ADC_Sample@admin+1)^080h	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(ADC_Sample@admax)^080h	;volatile
	clrf	(ADC_Sample@admax+1)^080h	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	line	58
	
l5149:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u6921
	goto	u6920
u6921:
	goto	l5155
u6920:
	
l5151:	
	btfss	(ADC_Sample@adldo)^080h,(2)&7
	goto	u6931
	goto	u6930
u6931:
	goto	l5155
u6930:
	line	60
	
l5153:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(ADC_Sample@adldo)^080h,w
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_ADC_Sample+0)^080h+0),f
	u13297:
decfsz	(??_ADC_Sample+0)^080h+0,f
	goto	u13297
	nop
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	l5157
	line	64
	
l5155:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	movf	(ADC_Sample@adldo)^080h,w
	movwf	(150)^080h	;volatile
	line	67
	
l5157:	
;adc_drv.c: 67: if(adch & 0x10)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	btfss	(ADC_Sample@adch)^080h,(4)&7
	goto	u6941
	goto	u6940
u6941:
	goto	l496
u6940:
	line	69
	
l5159:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l5161:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	andwf	(ADC_Sample@adch)^080h,f
	line	71
;adc_drv.c: 71: }
	goto	l5163
	line	72
	
l496:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l5163:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	clrf	(ADC_Sample@i)^080h
	line	79
	
l5169:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(ADC_Sample@adch)^080h,w
	movwf	(??_ADC_Sample+0)^080h+0
	movlw	(02h)-1
u6955:
	clrc
	rlf	(??_ADC_Sample+0)^080h+0,f
	addlw	-1
	skipz
	goto	u6955
	clrc
	rlf	(??_ADC_Sample+0)^080h+0,w
	iorlw	081h
	movwf	(149)^080h	;volatile
	line	80
	
l5171:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	5
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_ADC_Sample+0)^080h+0),f
	u13307:
decfsz	(??_ADC_Sample+0)^080h+0,f
	goto	u13307
	nop2
opt asmopt_pop

	line	81
	
l5173:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l5175:	
;adc_drv.c: 84: unsigned char j = 0;
	clrf	(ADC_Sample@j)^080h
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	l500
	
l501:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decfsz	(ADC_Sample@j)^080h,f
	goto	u6961
	goto	u6960
u6961:
	goto	l500
u6960:
	line	89
	
l5177:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	l503
	line	90
	
l500:	
	line	85
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u6971
	goto	u6970
u6971:
	goto	l501
u6970:
	line	93
	
l5181:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	movwf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	swapf	(ADC_Sample@ad_temp)^080h,f	;volatile
	swapf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	
l5183:	
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	addwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	line	96
	
l5185:	
;adc_drv.c: 96: if(0 == admax)
	movf	((ADC_Sample@admax)^080h),w	;volatile
iorwf	((ADC_Sample@admax+1)^080h),w	;volatile
	btfss	status,2
	goto	u6981
	goto	u6980
u6981:
	goto	l5189
u6980:
	line	98
	
l5187:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	100
;adc_drv.c: 100: }
	goto	l506
	line	102
	
l5189:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	subwf	(ADC_Sample@admax+1)^080h,w	;volatile
	skipz
	goto	u6995
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	subwf	(ADC_Sample@admax)^080h,w	;volatile
u6995:
	skipnc
	goto	u6991
	goto	u6990
u6991:
	goto	l5193
u6990:
	line	103
	
l5191:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	goto	l506
	line	105
	
l5193:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	skipz
	goto	u7005
	movf	(ADC_Sample@admin)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp)^080h,w	;volatile
u7005:
	skipnc
	goto	u7001
	goto	u7000
u7001:
	goto	l506
u7000:
	line	106
	
l5195:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	108
	
l506:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	0+(??_ADC_Sample+0)^080h+0,w
	addwf	(ADC_Sample@adsum)^080h,f	;volatile
	movf	1+(??_ADC_Sample+0)^080h+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7011
	addwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u7011:
	movf	2+(??_ADC_Sample+0)^080h+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7012
	addwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u7012:
	movf	3+(??_ADC_Sample+0)^080h+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7013
	addwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u7013:

	line	76
	
l5197:	
	incf	(ADC_Sample@i)^080h,f
	
l5199:	
	movlw	low(022h)
	subwf	(ADC_Sample@i)^080h,w
	skipc
	goto	u7021
	goto	u7020
u7021:
	goto	l5169
u7020:
	line	112
	
l5201:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(ADC_Sample@admax)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@admax+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	0+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	movf	1+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)^080h+0,w
	goto	u7035
	goto	u7036
u7035:
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u7036:
	movf	2+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)^080h+0,w
	goto	u7037
	goto	u7038
u7037:
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u7038:
	movf	3+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)^080h+0,w
	goto	u7039
	goto	u7030
u7039:
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u7030:

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(ADC_Sample@admin)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	3+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum+3)^080h,w	;volatile
	skipz
	goto	u7045
	movf	2+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum+2)^080h,w	;volatile
	skipz
	goto	u7045
	movf	1+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum+1)^080h,w	;volatile
	skipz
	goto	u7045
	movf	0+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum)^080h,w	;volatile
u7045:
	skipc
	goto	u7041
	goto	u7040
u7041:
	goto	l510
u7040:
	line	114
	
l5203:	
;adc_drv.c: 114: adsum -= admin;
	movf	(ADC_Sample@admin)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	0+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	movf	1+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)^080h+0,w
	goto	u7055
	goto	u7056
u7055:
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u7056:
	movf	2+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)^080h+0,w
	goto	u7057
	goto	u7058
u7057:
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u7058:
	movf	3+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)^080h+0,w
	goto	u7059
	goto	u7050
u7059:
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u7050:

	goto	l5205
	line	115
	
l510:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	118
	
l5205:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(ADC_Sample@adsum)^080h,w	;volatile
	movwf	(??_ADC_Sample+0)^080h+0
	movf	(ADC_Sample@adsum+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	movf	(ADC_Sample@adsum+2)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+2)
	movf	(ADC_Sample@adsum+3)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+3)
	movlw	05h
u7065:
	clrc
	rrf	(??_ADC_Sample+0)^080h+3,f
	rrf	(??_ADC_Sample+0)^080h+2,f
	rrf	(??_ADC_Sample+0)^080h+1,f
	rrf	(??_ADC_Sample+0)^080h+0,f
u7060:
	addlw	-1
	skipz
	goto	u7065
	movf	1+(??_ADC_Sample+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_adresult+1)	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(??_ADC_Sample+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_adresult)	;volatile
	line	119
	
l5207:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
l503:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 157 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   22[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0       8       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_CCCV_Control
;;		_Charging_Control
;;		_Led_BlinkProcess
;;		_PowerOnLedSequence
;;		_Update_LED_Slot
;;		i1_ADC_Sample
;;		i1___bmul
;;		i1___lldiv
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	157
global __ptext21
__ptext21:	;psect for function _Isr_Timer
psect	text21
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	157
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 2
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	movf	btemp+1,w
	movwf	(??_Isr_Timer+3)
	ljmp	_Isr_Timer
psect	text21
	line	160
	
i1l8505:	
;main.c: 160: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u1302_21
	goto	u1302_20
u1302_21:
	goto	i1l373
u1302_20:
	line	162
	
i1l8507:	
;main.c: 161: {
;main.c: 162: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	163
	
i1l8509:	
;main.c: 163: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	164
# 164 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text21
	line	167
	
i1l8511:	
;main.c: 167: g_pwmCounter++;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	168
	
i1l8513:	
;main.c: 168: if(g_pwmCounter >= 32)
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u1303_21
	goto	u1303_20
u1303_21:
	goto	i1l8517
u1303_20:
	line	169
	
i1l8515:	
;main.c: 169: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	172
	
i1l8517:	
;main.c: 172: if(g_pwmDuty > 0 && g_pwmCounter < g_pwmDuty)
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u1304_21
	goto	u1304_20
u1304_21:
	goto	i1l370
u1304_20:
	
i1l8519:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u1305_21
	goto	u1305_20
u1305_21:
	goto	i1l370
u1305_20:
	line	173
	
i1l8521:	
;main.c: 173: RB7 = 1;
	bsf	(55/8),(55)&7	;volatile
	goto	i1l8523
	line	174
	
i1l370:	
	line	175
;main.c: 174: else
;main.c: 175: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	178
	
i1l8523:	
;main.c: 178: if(g_powerOnPhase < 2)
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u1306_21
	goto	u1306_20
u1306_21:
	goto	i1l8599
u1306_20:
	line	180
	
i1l8525:	
;main.c: 179: {
;main.c: 180: PowerOnLedSequence();
	fcall	_PowerOnLedSequence
	goto	i1l373
	line	187
;main.c: 186: {
;main.c: 187: case 0:
	
i1l375:	
	line	191
;main.c: 191: if(!g_adcBusy && !g_doAdcSample)
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u1307_21
	goto	u1307_20
u1307_21:
	goto	i1l373
u1307_20:
	
i1l8529:	
	btfsc	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u1308_21
	goto	u1308_20
u1308_21:
	goto	i1l373
u1308_20:
	line	193
	
i1l8531:	
;main.c: 192: {
;main.c: 193: if(g_slot[(unsigned char)(g_scanIndex)].state != 1)
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
		decf	(indf),w
	btfsc	status,2
	goto	u1309_21
	goto	u1309_20
u1309_21:
	goto	i1l377
u1309_20:
	goto	i1l8535
	line	194
	
i1l380:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l377
	
i1l382:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l377
	
i1l383:	
	bsf	(51/8),(51)&7	;volatile
	goto	i1l377
	
i1l384:	
	bsf	(50/8),(50)&7	;volatile
	goto	i1l377
	
i1l385:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l377
	
i1l386:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l377
	
i1l387:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l377
	
i1l388:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l377
	
i1l389:	
	bsf	(48/8),(48)&7	;volatile
	goto	i1l377
	
i1l390:	
	bsf	(49/8),(49)&7	;volatile
	goto	i1l377
	
i1l391:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l377
	
i1l392:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l377
	
i1l8535:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_scanIndex),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l380
	xorlw	1^0	; case 1
	skipnz
	goto	i1l382
	xorlw	2^1	; case 2
	skipnz
	goto	i1l383
	xorlw	3^2	; case 3
	skipnz
	goto	i1l384
	xorlw	4^3	; case 4
	skipnz
	goto	i1l385
	xorlw	5^4	; case 5
	skipnz
	goto	i1l386
	xorlw	6^5	; case 6
	skipnz
	goto	i1l387
	xorlw	7^6	; case 7
	skipnz
	goto	i1l388
	xorlw	8^7	; case 8
	skipnz
	goto	i1l389
	xorlw	9^8	; case 9
	skipnz
	goto	i1l390
	xorlw	10^9	; case 10
	skipnz
	goto	i1l391
	xorlw	11^10	; case 11
	skipnz
	goto	i1l392
	goto	i1l377
	opt asmopt_pop

	
i1l377:	
	line	195
;main.c: 195: g_doAdcSample = 1;
	bsf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	i1l373
	line	201
	
i1l8537:	
;main.c: 201: Update_LED_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_Update_LED_Slot
	line	203
	
i1l8539:	
;main.c: 203: g_scanPhase = 2;
	movlw	low(02h)
	movwf	(_g_scanPhase)	;volatile
	line	204
;main.c: 204: break;
	goto	i1l373
	line	207
	
i1l8541:	
;main.c: 207: if(g_scanIndex == 0)
	movf	((_g_scanIndex)),w	;volatile
	btfss	status,2
	goto	u1310_21
	goto	u1310_20
u1310_21:
	goto	i1l8591
u1310_20:
	line	211
	
i1l8543:	
;main.c: 208: {
;main.c: 211: g_vccLoaded = g_vcc_mv;
	movf	(_g_vcc_mv+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vccLoaded+1)^080h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_vcc_mv),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vccLoaded)^080h	;volatile
	line	213
	
i1l8545:	
;main.c: 213: Charging_Control();
	fcall	_Charging_Control
	line	214
	
i1l8547:	
;main.c: 214: CCCV_Control();
	fcall	_CCCV_Control
	line	218
	
i1l8549:	
;main.c: 218: if(!g_adcBusy)
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u1311_21
	goto	u1311_20
u1311_21:
	goto	i1l8563
u1311_20:
	line	220
	
i1l8551:	
;main.c: 219: {
;main.c: 220: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	221
	
i1l8553:	
;main.c: 221: test_adc = ADC_Sample(31, 0);
	clrf	(i1ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	i1_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	222
	
i1l8555:	
;main.c: 222: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u1312_21
	goto	u1312_20
u1312_21:
	goto	i1l8561
u1312_20:
	line	224
	
i1l8557:	
;main.c: 223: {
;main.c: 224: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult),w	;volatile
	movwf	(i1___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((i1___lldiv@divisor))+1
	clrf	2+((i1___lldiv@divisor))
	clrf	3+((i1___lldiv@divisor))
	movlw	0
	movwf	(i1___lldiv@dividend+3)
	movlw	04Bh
	movwf	(i1___lldiv@dividend+2)
	movlw	0
	movwf	(i1___lldiv@dividend+1)
	movlw	0
	movwf	(i1___lldiv@dividend)

	fcall	i1___lldiv
	movf	(3+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+3)
	movf	(2+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+2)
	movf	(1+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+1)
	movf	(0+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt)

	line	225
	
i1l8559:	
;main.c: 225: g_vcc_mv = (unsigned int)pt;
	movf	(Isr_Timer@pt+1),w
	movwf	(_g_vcc_mv+1)	;volatile
	movf	(Isr_Timer@pt),w
	movwf	(_g_vcc_mv)	;volatile
	line	227
	
i1l8561:	
;main.c: 226: }
;main.c: 227: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	230
	
i1l8563:	
;main.c: 228: }
;main.c: 230: Led_BlinkProcess();
	fcall	_Led_BlinkProcess
	line	234
	
i1l8565:	
;main.c: 233: {
;main.c: 234: if(g_tempPhase == 0)
	movf	((_g_tempPhase)),w	;volatile
	btfss	status,2
	goto	u1313_21
	goto	u1313_20
u1313_21:
	goto	i1l8577
u1313_20:
	line	236
	
i1l8567:	
;main.c: 235: {
;main.c: 236: g_tempReadRoundCnt++;
	incf	(_g_tempReadRoundCnt),f	;volatile
	line	237
	
i1l8569:	
;main.c: 237: if(g_tempReadRoundCnt >= 200)
	movlw	low(0C8h)
	subwf	(_g_tempReadRoundCnt),w	;volatile
	skipc
	goto	u1314_21
	goto	u1314_20
u1314_21:
	goto	i1l8585
u1314_20:
	line	239
	
i1l8571:	
;main.c: 238: {
;main.c: 239: g_tempReadRoundCnt = 0;
	clrf	(_g_tempReadRoundCnt)	;volatile
	line	240
	
i1l8573:	
;main.c: 240: g_tempPhase = 1;
	movlw	low(01h)
	movwf	(_g_tempPhase)	;volatile
	line	241
	
i1l8575:	
;main.c: 241: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)	;volatile
	goto	i1l8585
	line	246
	
i1l8577:	
;main.c: 244: else
;main.c: 245: {
;main.c: 246: g_tempSettleCnt++;
	incf	(_g_tempSettleCnt),f	;volatile
	line	247
	
i1l8579:	
;main.c: 247: if(g_tempSettleCnt >= 60)
	movlw	low(03Ch)
	subwf	(_g_tempSettleCnt),w	;volatile
	skipc
	goto	u1315_21
	goto	u1315_20
u1315_21:
	goto	i1l8585
u1315_20:
	line	249
	
i1l8581:	
;main.c: 248: {
;main.c: 249: g_doNtcRead = 1;
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	250
	
i1l8583:	
;main.c: 250: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)	;volatile
	line	251
;main.c: 251: g_tempPhase = 0;
	clrf	(_g_tempPhase)	;volatile
	line	257
	
i1l8585:	
;main.c: 252: }
;main.c: 253: }
;main.c: 254: }
;main.c: 257: if(++g_printTick >= 100)
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_printTick)^080h,f	;volatile
	skipnz
	incf	(_g_printTick+1)^080h,f	;volatile
	movlw	0
	subwf	((_g_printTick+1)^080h),w	;volatile
	movlw	064h
	skipnz
	subwf	((_g_printTick)^080h),w	;volatile
	skipc
	goto	u1316_21
	goto	u1316_20
u1316_21:
	goto	i1l8591
u1316_20:
	line	259
	
i1l8587:	
;main.c: 258: {
;main.c: 259: g_printTick = 0;
	clrf	(_g_printTick)^080h	;volatile
	clrf	(_g_printTick+1)^080h	;volatile
	line	260
	
i1l8589:	
;main.c: 260: g_printFlag = 1;
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	265
	
i1l8591:	
;main.c: 261: }
;main.c: 262: }
;main.c: 265: if(++g_scanIndex >= 12)
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	incf	(_g_scanIndex),f	;volatile
	subwf	((_g_scanIndex)),w	;volatile
	skipc
	goto	u1317_21
	goto	u1317_20
u1317_21:
	goto	i1l405
u1317_20:
	line	266
	
i1l8593:	
;main.c: 266: g_scanIndex = 0;
	clrf	(_g_scanIndex)	;volatile
	
i1l405:	
	line	267
;main.c: 267: g_scanPhase = 0;
	clrf	(_g_scanPhase)	;volatile
	line	268
;main.c: 268: break;
	goto	i1l373
	line	185
	
i1l8599:	
	movf	(_g_scanPhase),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 2
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           17     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l375
	xorlw	1^0	; case 1
	skipnz
	goto	i1l8537
	xorlw	2^1	; case 2
	skipnz
	goto	i1l8541
	goto	i1l405
	opt asmopt_pop

	line	275
	
i1l373:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(??_Isr_Timer+3),w
	movwf	btemp+1
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^00h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	i1___lldiv

;; *************** function i1___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    0[COMMON] unsigned long 
;;  dividend        4    4[COMMON] unsigned long 
;; Auto vars:     Size  Location     Type
;;  __lldiv         4    1[BANK0 ] unsigned long 
;;  __lldiv         1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    0[COMMON] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         8       0       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       5       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext22
__ptext22:	;psect for function i1___lldiv
psect	text22
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_ofi1___lldiv
	__size_ofi1___lldiv	equ	__end_ofi1___lldiv-i1___lldiv
	
i1___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in i1___lldiv: [wreg+status,2+status,0]
	line	14
	
i1l8479:	
	clrf	(i1___lldiv@quotient)
	clrf	(i1___lldiv@quotient+1)
	clrf	(i1___lldiv@quotient+2)
	clrf	(i1___lldiv@quotient+3)
	line	15
	
i1l8481:	
	movf	(i1___lldiv@divisor+3),w
	iorwf	(i1___lldiv@divisor+2),w
	iorwf	(i1___lldiv@divisor+1),w
	iorwf	(i1___lldiv@divisor),w
	skipnz
	goto	u1298_21
	goto	u1298_20
u1298_21:
	goto	i1l8501
u1298_20:
	line	16
	
i1l8483:	
	clrf	(i1___lldiv@counter)
	incf	(i1___lldiv@counter),f
	line	17
	goto	i1l8487
	line	18
	
i1l8485:	
	clrc
	rlf	(i1___lldiv@divisor),f
	rlf	(i1___lldiv@divisor+1),f
	rlf	(i1___lldiv@divisor+2),f
	rlf	(i1___lldiv@divisor+3),f
	line	19
	incf	(i1___lldiv@counter),f
	line	17
	
i1l8487:	
	btfss	(i1___lldiv@divisor+3),(31)&7
	goto	u1299_21
	goto	u1299_20
u1299_21:
	goto	i1l8485
u1299_20:
	line	22
	
i1l8489:	
	clrc
	rlf	(i1___lldiv@quotient),f
	rlf	(i1___lldiv@quotient+1),f
	rlf	(i1___lldiv@quotient+2),f
	rlf	(i1___lldiv@quotient+3),f
	line	23
	
i1l8491:	
	movf	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),w
	skipz
	goto	u1300_25
	movf	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),w
	skipz
	goto	u1300_25
	movf	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),w
	skipz
	goto	u1300_25
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),w
u1300_25:
	skipc
	goto	u1300_21
	goto	u1300_20
u1300_21:
	goto	i1l8497
u1300_20:
	line	24
	
i1l8493:	
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),f
	movf	(i1___lldiv@divisor+1),w
	skipc
	incfsz	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),f
	movf	(i1___lldiv@divisor+2),w
	skipc
	incfsz	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),f
	movf	(i1___lldiv@divisor+3),w
	skipc
	incfsz	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),f
	line	25
	
i1l8495:	
	bsf	(i1___lldiv@quotient)+(0/8),(0)&7
	line	27
	
i1l8497:	
	clrc
	rrf	(i1___lldiv@divisor+3),f
	rrf	(i1___lldiv@divisor+2),f
	rrf	(i1___lldiv@divisor+1),f
	rrf	(i1___lldiv@divisor),f
	line	28
	
i1l8499:	
	decfsz	(i1___lldiv@counter),f
	goto	u1301_21
	goto	u1301_20
u1301_21:
	goto	i1l8489
u1301_20:
	line	30
	
i1l8501:	
	movf	(i1___lldiv@quotient+3),w
	movwf	(?i1___lldiv+3)
	movf	(i1___lldiv@quotient+2),w
	movwf	(?i1___lldiv+2)
	movf	(i1___lldiv@quotient+1),w
	movwf	(?i1___lldiv+1)
	movf	(i1___lldiv@quotient),w
	movwf	(?i1___lldiv)

	line	31
	
i1l1229:	
	return
	opt stack 0
GLOBAL	__end_ofi1___lldiv
	__end_ofi1___lldiv:
	signat	i1___lldiv,92
	global	i1_ADC_Sample

;; *************** function i1_ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    0[BANK0 ] unsigned char 
;;  ADC_Sample      4    3[BANK0 ] volatile unsigned long 
;;  ADC_Sample      2   11[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    9[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    7[BANK0 ] volatile unsigned int 
;;  ADC_Sample      1    2[BANK0 ] unsigned char 
;;  ADC_Sample      1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      13       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext23
__ptext23:	;psect for function i1_ADC_Sample
psect	text23
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_ofi1_ADC_Sample
	__size_ofi1_ADC_Sample	equ	__end_ofi1_ADC_Sample-i1_ADC_Sample
	
i1_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in i1_ADC_Sample: [wreg+status,2+status,0]
;i1ADC_Sample@adch stored from wreg
	movwf	(i1ADC_Sample@adch)
	line	51
	
i1l4925:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	52
	
i1l4927:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(i1ADC_Sample@admin)	;volatile
	clrf	(i1ADC_Sample@admin+1)	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(i1ADC_Sample@admax)	;volatile
	clrf	(i1ADC_Sample@admax+1)	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	line	58
	
i1l4929:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u656_21
	goto	u656_20
u656_21:
	goto	i1l4935
u656_20:
	
i1l4931:	
	btfss	(i1ADC_Sample@adldo),(2)&7
	goto	u657_21
	goto	u657_20
u657_21:
	goto	i1l4935
u657_20:
	line	60
	
i1l4933:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??i1_ADC_Sample+0)+0),f
	u1331_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u1331_27
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	i1l4937
	line	64
	
i1l4935:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	67
	
i1l4937:	
;adc_drv.c: 67: if(adch & 0x10)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(i1ADC_Sample@adch),(4)&7
	goto	u658_21
	goto	u658_20
u658_21:
	goto	i1l496
u658_20:
	line	69
	
i1l4939:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
i1l4941:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(i1ADC_Sample@adch),f
	line	71
;adc_drv.c: 71: }
	goto	i1l4943
	line	72
	
i1l496:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
i1l4943:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@i)
	
i1l4945:	
	movlw	low(022h)
	subwf	(i1ADC_Sample@i),w
	skipc
	goto	u659_21
	goto	u659_20
u659_21:
	goto	i1l4949
u659_20:
	goto	i1l4981
	line	79
	
i1l4949:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(i1ADC_Sample@adch),w
	movwf	(??i1_ADC_Sample+0)+0
	movlw	(02h)-1
u660_25:
	clrc
	rlf	(??i1_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u660_25
	clrc
	rlf	(??i1_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
i1l4951:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	6
movwf	((??i1_ADC_Sample+0)+0),f
	u1332_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u1332_27
	nop
opt asmopt_pop

	line	81
	
i1l4953:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
i1l4955:	
;adc_drv.c: 84: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@j)
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	i1l500
	
i1l501:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(i1ADC_Sample@j),f
	goto	u661_21
	goto	u661_20
u661_21:
	goto	i1l500
u661_20:
	line	89
	
i1l4957:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	i1l503
	line	90
	
i1l500:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u662_21
	goto	u662_20
u662_21:
	goto	i1l501
u662_20:
	line	93
	
i1l4961:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	swapf	(i1ADC_Sample@ad_temp),f	;volatile
	swapf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp),f	;volatile
	
i1l4963:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(i1ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(i1ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
i1l4965:	
;adc_drv.c: 96: if(0 == admax)
	movf	((i1ADC_Sample@admax)),w	;volatile
iorwf	((i1ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u663_21
	goto	u663_20
u663_21:
	goto	i1l4969
u663_20:
	line	98
	
i1l4967:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	100
;adc_drv.c: 100: }
	goto	i1l506
	line	102
	
i1l4969:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	subwf	(i1ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u664_25
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	subwf	(i1ADC_Sample@admax),w	;volatile
u664_25:
	skipnc
	goto	u664_21
	goto	u664_20
u664_21:
	goto	i1l4973
u664_20:
	line	103
	
i1l4971:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	goto	i1l506
	line	105
	
i1l4973:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	subwf	(i1ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u665_25
	movf	(i1ADC_Sample@admin),w	;volatile
	subwf	(i1ADC_Sample@ad_temp),w	;volatile
u665_25:
	skipnc
	goto	u665_21
	goto	u665_20
u665_21:
	goto	i1l506
u665_20:
	line	106
	
i1l4975:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	108
	
i1l506:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	addwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u666_21
	addwf	(i1ADC_Sample@adsum+1),f	;volatile
u666_21:
	movf	2+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u666_22
	addwf	(i1ADC_Sample@adsum+2),f	;volatile
u666_22:
	movf	3+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u666_23
	addwf	(i1ADC_Sample@adsum+3),f	;volatile
u666_23:

	line	76
	
i1l4977:	
	incf	(i1ADC_Sample@i),f
	goto	i1l4945
	line	112
	
i1l4981:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(i1ADC_Sample@admax),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admax+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u667_25
	goto	u667_26
u667_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u667_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u667_27
	goto	u667_28
u667_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u667_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u667_29
	goto	u667_20
u667_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u667_20:

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	3+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u668_25
	movf	2+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u668_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u668_25
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),w	;volatile
u668_25:
	skipc
	goto	u668_21
	goto	u668_20
u668_21:
	goto	i1l510
u668_20:
	line	114
	
i1l4983:	
;adc_drv.c: 114: adsum -= admin;
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u669_25
	goto	u669_26
u669_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u669_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u669_27
	goto	u669_28
u669_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u669_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u669_29
	goto	u669_20
u669_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u669_20:

	goto	i1l4985
	line	115
	
i1l510:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	118
	
i1l4985:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(i1ADC_Sample@adsum),w	;volatile
	movwf	(??i1_ADC_Sample+0)+0
	movf	(i1ADC_Sample@adsum+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	movf	(i1ADC_Sample@adsum+2),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+2)
	movf	(i1ADC_Sample@adsum+3),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+3)
	movlw	05h
u670_25:
	clrc
	rrf	(??i1_ADC_Sample+0)+3,f
	rrf	(??i1_ADC_Sample+0)+2,f
	rrf	(??i1_ADC_Sample+0)+1,f
	rrf	(??i1_ADC_Sample+0)+0,f
u670_20:
	addlw	-1
	skipz
	goto	u670_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
i1l4987:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
i1l503:	
	return
	opt stack 0
GLOBAL	__end_ofi1_ADC_Sample
	__end_ofi1_ADC_Sample:
	signat	i1_ADC_Sample,89
	global	_Update_LED_Slot

;; *************** function _Update_LED_Slot *****************
;; Defined at:
;;		line 31 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    0[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	31
global __ptext24
__ptext24:	;psect for function _Update_LED_Slot
psect	text24
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	31
	global	__size_of_Update_LED_Slot
	__size_of_Update_LED_Slot	equ	__end_of_Update_LED_Slot-_Update_LED_Slot
	
_Update_LED_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _Update_LED_Slot: [wreg]
	line	36
	
i1l927:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Slot
	__end_of_Update_LED_Slot:
	signat	_Update_LED_Slot,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 63 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	line	63
global __ptext25
__ptext25:	;psect for function _PowerOnLedSequence
psect	text25
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	63
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	65
	
i1l3639:	
;led.c: 65: g_powerOnTimer++;
	incf	(_g_powerOnTimer),f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1),f	;volatile
	line	67
	
i1l3641:	
;led.c: 67: if(g_powerOnPhase == 0)
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u404_21
	goto	u404_20
u404_21:
	goto	i1l3649
u404_20:
	line	70
	
i1l3643:	
;led.c: 68: {
;led.c: 70: if(g_powerOnTimer >= 100)
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u405_21
	goto	u405_20
u405_21:
	goto	i1l939
u405_20:
	line	72
	
i1l3645:	
;led.c: 71: {
;led.c: 72: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	73
	
i1l3647:	
;led.c: 73: g_powerOnPhase = 1;
	movlw	low(01h)
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l939
	line	76
	
i1l3649:	
;led.c: 76: else if(g_powerOnPhase == 1)
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u406_21
	goto	u406_20
u406_21:
	goto	i1l939
u406_20:
	line	79
	
i1l3651:	
;led.c: 77: {
;led.c: 79: if(g_powerOnTimer >= 100)
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u407_21
	goto	u407_20
u407_21:
	goto	i1l939
u407_20:
	line	81
	
i1l3653:	
;led.c: 80: {
;led.c: 81: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	82
	
i1l3655:	
;led.c: 82: g_powerOnPhase = 2;
	movlw	low(02h)
	movwf	(_g_powerOnPhase)	;volatile
	line	86
	
i1l939:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
	global	_Led_BlinkProcess

;; *************** function _Led_BlinkProcess *****************
;; Defined at:
;;		line 48 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=0
	line	48
global __ptext26
__ptext26:	;psect for function _Led_BlinkProcess
psect	text26
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	48
	global	__size_of_Led_BlinkProcess
	__size_of_Led_BlinkProcess	equ	__end_of_Led_BlinkProcess-_Led_BlinkProcess
	
_Led_BlinkProcess:	
;incstack = 0
	opt	stack 3
; Regs used in _Led_BlinkProcess: [wreg+status,2+status,0]
	line	50
	
i1l3851:	
;led.c: 50: g_blinkTick++;
	incf	(_g_blinkTick),f
	line	51
	
i1l3853:	
;led.c: 51: if(g_blinkTick >= 100)
	movlw	low(064h)
	subwf	(_g_blinkTick),w
	skipc
	goto	u450_21
	goto	u450_20
u450_21:
	goto	i1l931
u450_20:
	line	52
	
i1l3855:	
;led.c: 52: g_blinkTick = 0;
	clrf	(_g_blinkTick)
	line	53
	
i1l931:	
	return
	opt stack 0
GLOBAL	__end_of_Led_BlinkProcess
	__end_of_Led_BlinkProcess:
	signat	_Led_BlinkProcess,89
	global	_Charging_Control

;; *************** function _Charging_Control *****************
;; Defined at:
;;		line 906 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    7[COMMON] unsigned char 
;;  i               1    8[COMMON] unsigned char 
;;  chargeB7_12     1    6[COMMON] unsigned char 
;;  chargeB1_6      1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 100/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;;		i1___lwmod
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	906
global __ptext27
__ptext27:	;psect for function _Charging_Control
psect	text27
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	906
	global	__size_of_Charging_Control
	__size_of_Charging_Control	equ	__end_of_Charging_Control-_Charging_Control
	
_Charging_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _Charging_Control: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	909
	
i1l7243:	
;charge_mgr.c: 908: unsigned char i;
;charge_mgr.c: 909: unsigned char chargeB1_6 = 0;
	clrf	(Charging_Control@chargeB1_6)
	line	910
;charge_mgr.c: 910: unsigned char chargeB7_12 = 0;
	clrf	(Charging_Control@chargeB7_12)
	line	913
	
i1l7245:	
;charge_mgr.c: 913: if(g_tempProtect)
	bcf	status, 5	;RP0=0, select bank0
	movf	((_g_tempProtect)),w
	btfsc	status,2
	goto	u1055_21
	goto	u1055_20
u1055_21:
	goto	i1l7251
u1055_20:
	line	915
;charge_mgr.c: 914: {
;charge_mgr.c: 915: do { RA0=1; RA1=1; RB3=1; RB2=1; RA3=1; RA2=1; RD1=1; RD3=1; RB0=1; RB1=1; RD2=1; RD0=1; } while(0);
	
i1l786:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	bsf	(1073/8)^080h,(1073)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	bsf	(50/8),(50)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	bsf	(1074/8)^080h,(1074)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	bsf	(49/8),(49)&7	;volatile
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	
i1l787:	
	line	916
;charge_mgr.c: 916: RC3 = 0;
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	917
;charge_mgr.c: 917: RC5 = 0;
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	918
	
i1l7247:	
;charge_mgr.c: 918: g_pwmDuty = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	goto	i1l788
	line	925
	
i1l7251:	
;charge_mgr.c: 920: }
;charge_mgr.c: 925: if(g_vccProtect)
	movf	((_g_vccProtect)),w
	btfsc	status,2
	goto	u1056_21
	goto	u1056_20
u1056_21:
	goto	i1l7261
u1056_20:
	line	927
	
i1l7253:	
;charge_mgr.c: 926: {
;charge_mgr.c: 927: if(g_vcc_mv < 4600)
	movlw	011h
	subwf	(_g_vcc_mv+1),w	;volatile
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv),w	;volatile
	skipnc
	goto	u1057_21
	goto	u1057_20
u1057_21:
	goto	i1l7259
u1057_20:
	goto	i1l786
	line	935
	
i1l7259:	
;charge_mgr.c: 934: }
;charge_mgr.c: 935: g_vccProtect = 0;
	clrf	(_g_vccProtect)
	line	936
;charge_mgr.c: 936: }
	goto	i1l7269
	line	939
	
i1l7261:	
;charge_mgr.c: 937: else
;charge_mgr.c: 938: {
;charge_mgr.c: 939: if(g_vcc_mv < 4400)
	movlw	011h
	subwf	(_g_vcc_mv+1),w	;volatile
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv),w	;volatile
	skipnc
	goto	u1058_21
	goto	u1058_20
u1058_21:
	goto	i1l7269
u1058_20:
	line	941
	
i1l7263:	
;charge_mgr.c: 940: {
;charge_mgr.c: 941: g_vccProtect = 1;
	clrf	(_g_vccProtect)
	incf	(_g_vccProtect),f
	goto	i1l786
	line	951
	
i1l7269:	
;charge_mgr.c: 947: }
;charge_mgr.c: 948: }
;charge_mgr.c: 951: for(i = 0; i < 12; i++)
	clrf	(Charging_Control@i)
	line	953
	
i1l7275:	
;charge_mgr.c: 952: {
;charge_mgr.c: 953: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Charging_Control@s)
	line	958
	
i1l7277:	
;charge_mgr.c: 956: if(s == 2 || s == 3 ||
;charge_mgr.c: 957: s == 4 || s == 5 ||
;charge_mgr.c: 958: s == 8)
		movlw	2
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1059_21
	goto	u1059_20
u1059_21:
	goto	i1l7287
u1059_20:
	
i1l7279:	
		movlw	3
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1060_21
	goto	u1060_20
u1060_21:
	goto	i1l7287
u1060_20:
	
i1l7281:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1061_21
	goto	u1061_20
u1061_21:
	goto	i1l7287
u1061_20:
	
i1l7283:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1062_21
	goto	u1062_20
u1062_21:
	goto	i1l7287
u1062_20:
	
i1l7285:	
		movlw	8
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u1063_21
	goto	u1063_20
u1063_21:
	goto	i1l7315
u1063_20:
	line	965
	
i1l7287:	
;charge_mgr.c: 959: {
;charge_mgr.c: 964: if(g_slot[(unsigned char)(i)].type == 6 &&
;charge_mgr.c: 965: (s == 4 || s == 5))
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
		movlw	6
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u1064_21
	goto	u1064_20
u1064_21:
	goto	i1l7309
u1064_20:
	
i1l7289:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1065_21
	goto	u1065_20
u1065_21:
	goto	i1l7293
u1065_20:
	
i1l7291:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u1066_21
	goto	u1066_20
u1066_21:
	goto	i1l7309
u1066_20:
	line	967
	
i1l7293:	
;charge_mgr.c: 966: {
;charge_mgr.c: 967: if(((unsigned int)g_ccCycle + i) % (10 + 1U) == 0)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_ccCycle),w
	movwf	(i1___lwmod@dividend)
	clrf	(i1___lwmod@dividend+1)
	movf	(Charging_Control@i),w
	addwf	(i1___lwmod@dividend),f
	skipnc
	incf	(i1___lwmod@dividend+1),f
	movlw	0Bh
	movwf	(i1___lwmod@divisor)
	clrf	(i1___lwmod@divisor+1)
	fcall	i1___lwmod
	movf	((0+(?i1___lwmod))),w
iorwf	((1+(?i1___lwmod))),w
	btfss	status,2
	goto	u1067_21
	goto	u1067_20
u1067_21:
	goto	i1l7305
u1067_20:
	goto	i1l7297
	line	969
	
i1l808:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l7299
	
i1l810:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l7299
	
i1l811:	
	bcf	(51/8),(51)&7	;volatile
	goto	i1l7299
	
i1l812:	
	bcf	(50/8),(50)&7	;volatile
	goto	i1l7299
	
i1l813:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l7299
	
i1l814:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l7299
	
i1l815:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l7299
	
i1l816:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l7299
	
i1l817:	
	bcf	(48/8),(48)&7	;volatile
	goto	i1l7299
	
i1l818:	
	bcf	(49/8),(49)&7	;volatile
	goto	i1l7299
	
i1l819:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l7299
	
i1l820:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l7299
	
i1l7297:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l808
	xorlw	1^0	; case 1
	skipnz
	goto	i1l810
	xorlw	2^1	; case 2
	skipnz
	goto	i1l811
	xorlw	3^2	; case 3
	skipnz
	goto	i1l812
	xorlw	4^3	; case 4
	skipnz
	goto	i1l813
	xorlw	5^4	; case 5
	skipnz
	goto	i1l814
	xorlw	6^5	; case 6
	skipnz
	goto	i1l815
	xorlw	7^6	; case 7
	skipnz
	goto	i1l816
	xorlw	8^7	; case 8
	skipnz
	goto	i1l817
	xorlw	9^8	; case 9
	skipnz
	goto	i1l818
	xorlw	10^9	; case 10
	skipnz
	goto	i1l819
	xorlw	11^10	; case 11
	skipnz
	goto	i1l820
	goto	i1l7299
	opt asmopt_pop

	line	970
	
i1l7299:	
;charge_mgr.c: 970: if(i < 6) chargeB1_6 = 1;
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipnc
	goto	u1068_21
	goto	u1068_20
u1068_21:
	goto	i1l822
u1068_20:
	
i1l7301:	
	clrf	(Charging_Control@chargeB1_6)
	incf	(Charging_Control@chargeB1_6),f
	goto	i1l7325
	line	971
	
i1l822:	
;charge_mgr.c: 971: else chargeB7_12 = 1;
	clrf	(Charging_Control@chargeB7_12)
	incf	(Charging_Control@chargeB7_12),f
	goto	i1l7325
	line	975
	
i1l827:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l7325
	
i1l829:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l7325
	
i1l830:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	i1l7325
	
i1l831:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	i1l7325
	
i1l832:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l7325
	
i1l833:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l7325
	
i1l834:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l7325
	
i1l835:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l7325
	
i1l836:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	i1l7325
	
i1l837:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	i1l7325
	
i1l838:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l7325
	
i1l839:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l7325
	
i1l7305:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l827
	xorlw	1^0	; case 1
	skipnz
	goto	i1l829
	xorlw	2^1	; case 2
	skipnz
	goto	i1l830
	xorlw	3^2	; case 3
	skipnz
	goto	i1l831
	xorlw	4^3	; case 4
	skipnz
	goto	i1l832
	xorlw	5^4	; case 5
	skipnz
	goto	i1l833
	xorlw	6^5	; case 6
	skipnz
	goto	i1l834
	xorlw	7^6	; case 7
	skipnz
	goto	i1l835
	xorlw	8^7	; case 8
	skipnz
	goto	i1l836
	xorlw	9^8	; case 9
	skipnz
	goto	i1l837
	xorlw	10^9	; case 10
	skipnz
	goto	i1l838
	xorlw	11^10	; case 11
	skipnz
	goto	i1l839
	goto	i1l841
	opt asmopt_pop

	line	980
	
i1l844:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l7311
	
i1l846:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l7311
	
i1l847:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l7311
	
i1l848:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l7311
	
i1l849:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l7311
	
i1l850:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l7311
	
i1l851:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l7311
	
i1l852:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l7311
	
i1l853:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l7311
	
i1l854:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l7311
	
i1l855:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l7311
	
i1l856:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l7311
	
i1l7309:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l844
	xorlw	1^0	; case 1
	skipnz
	goto	i1l846
	xorlw	2^1	; case 2
	skipnz
	goto	i1l847
	xorlw	3^2	; case 3
	skipnz
	goto	i1l848
	xorlw	4^3	; case 4
	skipnz
	goto	i1l849
	xorlw	5^4	; case 5
	skipnz
	goto	i1l850
	xorlw	6^5	; case 6
	skipnz
	goto	i1l851
	xorlw	7^6	; case 7
	skipnz
	goto	i1l852
	xorlw	8^7	; case 8
	skipnz
	goto	i1l853
	xorlw	9^8	; case 9
	skipnz
	goto	i1l854
	xorlw	10^9	; case 10
	skipnz
	goto	i1l855
	xorlw	11^10	; case 11
	skipnz
	goto	i1l856
	goto	i1l7311
	opt asmopt_pop

	line	983
	
i1l7311:	
;charge_mgr.c: 983: if(i < 6)
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipnc
	goto	u1069_21
	goto	u1069_20
u1069_21:
	goto	i1l822
u1069_20:
	goto	i1l7301
	line	987
	
i1l841:	
	line	988
;charge_mgr.c: 987: }
;charge_mgr.c: 988: }
	goto	i1l7325
	line	991
	
i1l7315:	
;charge_mgr.c: 991: else if(s == 1)
		decf	((Charging_Control@s)),w
	btfss	status,2
	goto	u1070_21
	goto	u1070_20
u1070_21:
	goto	i1l7323
u1070_20:
	goto	i1l7319
	line	993
	
i1l864:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l7325
	
i1l866:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l7325
	
i1l867:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l7325
	
i1l868:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l7325
	
i1l869:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l7325
	
i1l870:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l7325
	
i1l871:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l7325
	
i1l872:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l7325
	
i1l873:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l7325
	
i1l874:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l7325
	
i1l875:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l7325
	
i1l876:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l7325
	
i1l7319:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l864
	xorlw	1^0	; case 1
	skipnz
	goto	i1l866
	xorlw	2^1	; case 2
	skipnz
	goto	i1l867
	xorlw	3^2	; case 3
	skipnz
	goto	i1l868
	xorlw	4^3	; case 4
	skipnz
	goto	i1l869
	xorlw	5^4	; case 5
	skipnz
	goto	i1l870
	xorlw	6^5	; case 6
	skipnz
	goto	i1l871
	xorlw	7^6	; case 7
	skipnz
	goto	i1l872
	xorlw	8^7	; case 8
	skipnz
	goto	i1l873
	xorlw	9^8	; case 9
	skipnz
	goto	i1l874
	xorlw	10^9	; case 10
	skipnz
	goto	i1l875
	xorlw	11^10	; case 11
	skipnz
	goto	i1l876
	goto	i1l7325
	opt asmopt_pop

	line	997
	
i1l7323:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l827
	xorlw	1^0	; case 1
	skipnz
	goto	i1l829
	xorlw	2^1	; case 2
	skipnz
	goto	i1l830
	xorlw	3^2	; case 3
	skipnz
	goto	i1l831
	xorlw	4^3	; case 4
	skipnz
	goto	i1l832
	xorlw	5^4	; case 5
	skipnz
	goto	i1l833
	xorlw	6^5	; case 6
	skipnz
	goto	i1l834
	xorlw	7^6	; case 7
	skipnz
	goto	i1l835
	xorlw	8^7	; case 8
	skipnz
	goto	i1l836
	xorlw	9^8	; case 9
	skipnz
	goto	i1l837
	xorlw	10^9	; case 10
	skipnz
	goto	i1l838
	xorlw	11^10	; case 11
	skipnz
	goto	i1l839
	goto	i1l7325
	opt asmopt_pop

	line	951
	
i1l7325:	
	incf	(Charging_Control@i),f
	
i1l7327:	
	movlw	low(0Ch)
	subwf	(Charging_Control@i),w
	skipc
	goto	u1071_21
	goto	u1071_20
u1071_21:
	goto	i1l7275
u1071_20:
	line	1001
	
i1l7329:	
;charge_mgr.c: 998: }
;charge_mgr.c: 999: }
;charge_mgr.c: 1001: g_ccCycle++;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_ccCycle),f
	line	1004
	
i1l7331:	
;charge_mgr.c: 1004: RC3 = chargeB1_6;
	btfsc	(Charging_Control@chargeB1_6),0
	goto	u1072_21
	goto	u1072_20
	
u1072_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2099/8)^0100h,(2099)&7	;volatile
	goto	u1073_24
u1072_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
u1073_24:
	line	1005
	
i1l7333:	
;charge_mgr.c: 1005: RC5 = chargeB7_12;
	btfsc	(Charging_Control@chargeB7_12),0
	goto	u1074_21
	goto	u1074_20
	
u1074_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u1075_24
u1074_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u1075_24:
	line	1008
	
i1l788:	
	return
	opt stack 0
GLOBAL	__end_of_Charging_Control
	__end_of_Charging_Control:
	signat	_Charging_Control,89
	global	i1___lwmod

;; *************** function i1___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] unsigned int 
;;  dividend        2    2[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  __lwmod         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: B00/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Charging_Control
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext28
__ptext28:	;psect for function i1___lwmod
psect	text28
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_ofi1___lwmod
	__size_ofi1___lwmod	equ	__end_ofi1___lwmod-i1___lwmod
	
i1___lwmod:	
;incstack = 0
	opt	stack 2
; Regs used in i1___lwmod: [wreg+status,2+status,0]
	line	13
	
i1l3533:	
	movf	((i1___lwmod@divisor)),w
iorwf	((i1___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u397_21
	goto	u397_20
u397_21:
	goto	i1l3549
u397_20:
	line	14
	
i1l3535:	
	clrf	(i1___lwmod@counter)
	incf	(i1___lwmod@counter),f
	line	15
	goto	i1l3539
	line	16
	
i1l3537:	
	clrc
	rlf	(i1___lwmod@divisor),f
	rlf	(i1___lwmod@divisor+1),f
	line	17
	incf	(i1___lwmod@counter),f
	line	15
	
i1l3539:	
	btfss	(i1___lwmod@divisor+1),(15)&7
	goto	u398_21
	goto	u398_20
u398_21:
	goto	i1l3537
u398_20:
	line	20
	
i1l3541:	
	movf	(i1___lwmod@divisor+1),w
	subwf	(i1___lwmod@dividend+1),w
	skipz
	goto	u399_25
	movf	(i1___lwmod@divisor),w
	subwf	(i1___lwmod@dividend),w
u399_25:
	skipc
	goto	u399_21
	goto	u399_20
u399_21:
	goto	i1l3545
u399_20:
	line	21
	
i1l3543:	
	movf	(i1___lwmod@divisor),w
	subwf	(i1___lwmod@dividend),f
	movf	(i1___lwmod@divisor+1),w
	skipc
	decf	(i1___lwmod@dividend+1),f
	subwf	(i1___lwmod@dividend+1),f
	line	22
	
i1l3545:	
	clrc
	rrf	(i1___lwmod@divisor+1),f
	rrf	(i1___lwmod@divisor),f
	line	23
	
i1l3547:	
	decfsz	(i1___lwmod@counter),f
	goto	u400_21
	goto	u400_20
u400_21:
	goto	i1l3541
u400_20:
	line	25
	
i1l3549:	
	movf	(i1___lwmod@dividend+1),w
	movwf	(?i1___lwmod+1)
	movf	(i1___lwmod@dividend),w
	movwf	(?i1___lwmod)
	line	26
	
i1l1292:	
	return
	opt stack 0
GLOBAL	__end_ofi1___lwmod
	__end_ofi1___lwmod:
	signat	i1___lwmod,90
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 1026 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    6[BANK0 ] unsigned int 
;;  s               1   17[BANK0 ] unsigned char 
;;  duty            2   14[BANK0 ] int 
;;  error           2   10[BANK0 ] int 
;;  adjust          2    0[BANK0 ] int 
;;  duty_initial    1   13[BANK0 ] unsigned char 
;;  duty_target     1   12[BANK0 ] unsigned char 
;;  maxV            2    8[BANK0 ] unsigned int 
;;  i               1   16[BANK0 ] unsigned char 
;;  preCount        1    5[BANK0 ] unsigned char 
;;  ccCount         1    4[BANK0 ] unsigned char 
;;  cvCount         1    3[BANK0 ] unsigned char 
;;  hasCharging     1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 100/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2      18       0       0       0
;;Total ram usage:       20 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___awdiv
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1026
global __ptext29
__ptext29:	;psect for function _CCCV_Control
psect	text29
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1026
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1029
	
i1l7335:	
;charge_mgr.c: 1028: unsigned char i;
;charge_mgr.c: 1029: unsigned char hasCharging = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	1030
;charge_mgr.c: 1030: unsigned int maxV = 0;
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	1031
;charge_mgr.c: 1031: unsigned char cvCount = 0;
	clrf	(CCCV_Control@cvCount)
	line	1032
;charge_mgr.c: 1032: unsigned char ccCount = 0;
	clrf	(CCCV_Control@ccCount)
	line	1033
;charge_mgr.c: 1033: unsigned char preCount = 0;
	clrf	(CCCV_Control@preCount)
	line	1036
;charge_mgr.c: 1036: for(i = 0; i < 12; i++)
	clrf	(CCCV_Control@i)
	line	1038
	
i1l7341:	
;charge_mgr.c: 1037: {
;charge_mgr.c: 1038: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	1042
	
i1l7343:	
;charge_mgr.c: 1040: if(s == 2 || s == 3 ||
;charge_mgr.c: 1041: s == 4 || s == 5 ||
;charge_mgr.c: 1042: s == 8)
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1076_21
	goto	u1076_20
u1076_21:
	goto	i1l901
u1076_20:
	
i1l7345:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1077_21
	goto	u1077_20
u1077_21:
	goto	i1l901
u1077_20:
	
i1l7347:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1078_21
	goto	u1078_20
u1078_21:
	goto	i1l901
u1078_20:
	
i1l7349:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1079_21
	goto	u1079_20
u1079_21:
	goto	i1l901
u1079_20:
	
i1l7351:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1080_21
	goto	u1080_20
u1080_21:
	goto	i1l899
u1080_20:
	
i1l901:	
	line	1044
;charge_mgr.c: 1043: {
;charge_mgr.c: 1044: hasCharging = 1;
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	1046
	
i1l7353:	
;charge_mgr.c: 1045: {
;charge_mgr.c: 1046: unsigned int vt = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	1047
	
i1l7355:	
;charge_mgr.c: 1047: if(vt > maxV) maxV = vt;
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u1081_25
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u1081_25:
	skipnc
	goto	u1081_21
	goto	u1081_20
u1081_21:
	goto	i1l7359
u1081_20:
	
i1l7357:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	1049
	
i1l7359:	
;charge_mgr.c: 1048: }
;charge_mgr.c: 1049: if(s == 5)
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1082_21
	goto	u1082_20
u1082_21:
	goto	i1l7363
u1082_20:
	line	1050
	
i1l7361:	
;charge_mgr.c: 1050: cvCount++;
	incf	(CCCV_Control@cvCount),f
	line	1051
	
i1l7363:	
;charge_mgr.c: 1051: if(s == 4)
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1083_21
	goto	u1083_20
u1083_21:
	goto	i1l7367
u1083_20:
	line	1052
	
i1l7365:	
;charge_mgr.c: 1052: ccCount++;
	incf	(CCCV_Control@ccCount),f
	line	1053
	
i1l7367:	
;charge_mgr.c: 1053: if(s == 3 || s == 2)
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1084_21
	goto	u1084_20
u1084_21:
	goto	i1l7371
u1084_20:
	
i1l7369:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1085_21
	goto	u1085_20
u1085_21:
	goto	i1l899
u1085_20:
	line	1054
	
i1l7371:	
;charge_mgr.c: 1054: preCount++;
	incf	(CCCV_Control@preCount),f
	line	1055
	
i1l899:	
	line	1036
	incf	(CCCV_Control@i),f
	
i1l7373:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u1086_21
	goto	u1086_20
u1086_21:
	goto	i1l7341
u1086_20:
	line	1059
	
i1l7375:	
;charge_mgr.c: 1055: }
;charge_mgr.c: 1056: }
;charge_mgr.c: 1059: if(!hasCharging)
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u1087_21
	goto	u1087_20
u1087_21:
	goto	i1l7381
u1087_20:
	line	1061
	
i1l7377:	
;charge_mgr.c: 1060: {
;charge_mgr.c: 1061: g_pwmDuty = 0;
	clrf	(_g_pwmDuty)	;volatile
	line	1062
;charge_mgr.c: 1062: g_cvIntegral = 0;
	clrf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l909
	line	1070
	
i1l7381:	
;charge_mgr.c: 1064: }
;charge_mgr.c: 1070: if(cvCount == 0)
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u1088_21
	goto	u1088_20
u1088_21:
	goto	i1l7411
u1088_20:
	line	1074
	
i1l7383:	
;charge_mgr.c: 1071: {
;charge_mgr.c: 1072: unsigned char duty_target, duty_initial;
;charge_mgr.c: 1074: if(ccCount > 0)
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u1089_21
	goto	u1089_20
u1089_21:
	goto	i1l7387
u1089_20:
	line	1077
	
i1l7385:	
;charge_mgr.c: 1075: {
;charge_mgr.c: 1077: duty_target = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	1078
;charge_mgr.c: 1078: duty_initial = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	1079
;charge_mgr.c: 1079: }
	goto	i1l7395
	line	1080
	
i1l7387:	
;charge_mgr.c: 1080: else if(preCount > 0)
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u1090_21
	goto	u1090_20
u1090_21:
	goto	i1l7391
u1090_20:
	line	1083
	
i1l7389:	
;charge_mgr.c: 1081: {
;charge_mgr.c: 1083: duty_target = 8;
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	1084
;charge_mgr.c: 1084: duty_initial = 5;
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	1085
;charge_mgr.c: 1085: }
	goto	i1l7395
	line	1090
	
i1l7391:	
;charge_mgr.c: 1086: else
;charge_mgr.c: 1087: {
;charge_mgr.c: 1090: g_pwmDuty = 25;
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l909
	line	1094
	
i1l7395:	
;charge_mgr.c: 1092: }
;charge_mgr.c: 1094: if(g_pwmDuty < duty_initial)
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u1091_21
	goto	u1091_20
u1091_21:
	goto	i1l7403
u1091_20:
	line	1097
	
i1l7397:	
;charge_mgr.c: 1095: {
;charge_mgr.c: 1097: g_pwmDuty += 3;
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	1098
	
i1l7399:	
;charge_mgr.c: 1098: if(g_pwmDuty > duty_initial)
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u1092_21
	goto	u1092_20
u1092_21:
	goto	i1l909
u1092_20:
	line	1099
	
i1l7401:	
;charge_mgr.c: 1099: g_pwmDuty = duty_initial;
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l909
	line	1101
	
i1l7403:	
	line	1104
	
i1l7405:	
;charge_mgr.c: 1102: {
;charge_mgr.c: 1104: g_pwmDuty = duty_target;
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	1105
;charge_mgr.c: 1105: }
	goto	i1l909
	line	1120
	
i1l7411:	
;charge_mgr.c: 1112: }
;charge_mgr.c: 1119: {
;charge_mgr.c: 1120: int error = (int)(3100) - (int)(maxV);
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	1123
;charge_mgr.c: 1123: g_cvIntegral += error * 1;
	movf	(CCCV_Control@error),w
	addwf	(_g_cvIntegral),f
	skipnc
	incf	(_g_cvIntegral+1),f
	movf	(CCCV_Control@error+1),w
	addwf	(_g_cvIntegral+1),f
	line	1124
	
i1l7413:	
;charge_mgr.c: 1124: if(g_cvIntegral > 200)
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u1093_25
	movlw	0C9h
	subwf	(_g_cvIntegral),w
u1093_25:

	skipc
	goto	u1093_21
	goto	u1093_20
u1093_21:
	goto	i1l7417
u1093_20:
	line	1125
	
i1l7415:	
;charge_mgr.c: 1125: g_cvIntegral = 200;
	movlw	0C8h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l7421
	line	1126
	
i1l7417:	
;charge_mgr.c: 1126: else if(g_cvIntegral < -200)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u1094_25
	movlw	038h
	subwf	(_g_cvIntegral),w
u1094_25:

	skipnc
	goto	u1094_21
	goto	u1094_20
u1094_21:
	goto	i1l7421
u1094_20:
	line	1127
	
i1l7419:	
;charge_mgr.c: 1127: g_cvIntegral = -200;
	movlw	038h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	movlw	0FFh
	movwf	((_g_cvIntegral))+1
	line	1130
	
i1l7421:	
;charge_mgr.c: 1130: int adjust = (error * 4 + g_cvIntegral) / 8;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	movf	(_g_cvIntegral),w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1),w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	1131
	
i1l7423:	
;charge_mgr.c: 1131: int duty = (int)g_pwmDuty + adjust;
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
i1l7425:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	1134
	
i1l7427:	
;charge_mgr.c: 1134: if(duty > 32) duty = 32;
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u1095_25
	movlw	021h
	subwf	(CCCV_Control@duty),w
u1095_25:

	skipc
	goto	u1095_21
	goto	u1095_20
u1095_21:
	goto	i1l7431
u1095_20:
	
i1l7429:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1135
	
i1l7431:	
;charge_mgr.c: 1135: if(duty < 0) duty = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u1096_21
	goto	u1096_20
u1096_21:
	goto	i1l7435
u1096_20:
	
i1l7433:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1137
	
i1l7435:	
;charge_mgr.c: 1137: g_pwmDuty = (unsigned char)duty;
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	1139
	
i1l909:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	i1___bmul

;; *************** function i1___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[COMMON] unsigned char 
;;  __bmul          1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;;		_Charging_Control
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text30,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext30
__ptext30:	;psect for function i1___bmul
psect	text30
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_ofi1___bmul
	__size_ofi1___bmul	equ	__end_ofi1___bmul-i1___bmul
	
i1___bmul:	
;incstack = 0
	opt	stack 3
; Regs used in i1___bmul: [wreg+status,2+status,0]
;i1___bmul@multiplier stored from wreg
	movwf	(i1___bmul@multiplier)
	line	6
	
i1l3553:	
	clrf	(i1___bmul@product)
	line	43
	
i1l3555:	
	btfss	(i1___bmul@multiplier),(0)&7
	goto	u401_21
	goto	u401_20
u401_21:
	goto	i1l3559
u401_20:
	line	44
	
i1l3557:	
	movf	(i1___bmul@multiplicand),w
	addwf	(i1___bmul@product),f
	line	45
	
i1l3559:	
	clrc
	rlf	(i1___bmul@multiplicand),f
	line	46
	
i1l3561:	
	clrc
	rrf	(i1___bmul@multiplier),f
	line	47
	movf	((i1___bmul@multiplier)),w
	btfss	status,2
	goto	u402_21
	goto	u402_20
u402_21:
	goto	i1l3555
u402_20:
	line	50
	
i1l3563:	
	movf	(i1___bmul@product),w
	line	51
	
i1l963:	
	return
	opt stack 0
GLOBAL	__end_ofi1___bmul
	__end_ofi1___bmul:
	signat	i1___bmul,89
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] int 
;;  dividend        2    2[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] int 
;;  sign            1    5[COMMON] unsigned char 
;;  counter         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text31,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext31
__ptext31:	;psect for function ___awdiv
psect	text31
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
i1l3489:	
	clrf	(___awdiv@sign)
	line	15
	
i1l3491:	
	btfss	(___awdiv@divisor+1),7
	goto	u390_21
	goto	u390_20
u390_21:
	goto	i1l3497
u390_20:
	line	16
	
i1l3493:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
i1l3495:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
i1l3497:	
	btfss	(___awdiv@dividend+1),7
	goto	u391_21
	goto	u391_20
u391_21:
	goto	i1l3503
u391_20:
	line	20
	
i1l3499:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
i1l3501:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
i1l3503:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
i1l3505:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u392_21
	goto	u392_20
u392_21:
	goto	i1l3525
u392_20:
	line	25
	
i1l3507:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	i1l3511
	line	27
	
i1l3509:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
i1l3511:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u393_21
	goto	u393_20
u393_21:
	goto	i1l3509
u393_20:
	line	31
	
i1l3513:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
i1l3515:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u394_25
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u394_25:
	skipc
	goto	u394_21
	goto	u394_20
u394_21:
	goto	i1l3521
u394_20:
	line	33
	
i1l3517:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
i1l3519:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
i1l3521:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
i1l3523:	
	decfsz	(___awdiv@counter),f
	goto	u395_21
	goto	u395_20
u395_21:
	goto	i1l3513
u395_20:
	line	39
	
i1l3525:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u396_21
	goto	u396_20
u396_21:
	goto	i1l3529
u396_20:
	line	40
	
i1l3527:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
i1l3529:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
i1l1075:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
