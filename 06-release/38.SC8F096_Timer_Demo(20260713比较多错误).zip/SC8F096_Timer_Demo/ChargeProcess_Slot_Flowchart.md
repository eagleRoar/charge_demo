# ChargeProcess_Slot() 流程图

> 用 VS Code + Markdown Preview Mermaid Support 插件查看，或复制到 [mermaid.live](https://mermaid.live)

---

## 1. 状态机总览（顶层）

```mermaid
flowchart TD
    START([Entry: SLOT_RD_ALL]) --> SWITCH{switch st}
    SWITCH --> IDLE
    SWITCH --> DETECT
    SWITCH --> IMP_CHECK
    SWITCH --> DIODE_TEST
    SWITCH --> ACTIVATE
    SWITCH --> PRECHARGE
    SWITCH --> CC
    SWITCH --> CV
    SWITCH --> FULL
    SWITCH --> ERROR

    IDLE[CHG_IDLE<br>ct=0,记录基准电压] -->|无条件| DETECT

    DETECT[CHG_DETECT<br>电池类型识别] -->|AMBIGUOUS| IMP_CHECK
    DETECT -->|LI_ION / LINEAR_LI| ROUTE[DETECT_LI_ROUTE<br>计算电池mV分档]
    DETECT -->|NIMH / DRY / UNKNOWN| ERROR

    ROUTE -->|bat_mv<=100mV| ACTIVATE
    ROUTE -->|bat_mv<3200mV| PRECHARGE
    ROUTE -->|bat_mv<4200mV| CC
    ROUTE -->|bat_mv>=4200mV| CV

    IMP_CHECK[CHG_IMP_CHECK<br>VCC跌落脉冲检测] -->|跌>300mV: NiMH| ERROR
    IMP_CHECK -->|脉冲前后均OPEN: 空槽| IDLE
    IMP_CHECK -->|跌>100mV: 恒压锂| LIION[imp_li_ion]
    IMP_CHECK -->|无跌落| DIODE_TEST

    DIODE_TEST[CHG_IMP_DIODE_TEST<br>体二极管爬升检测] -->|爬升>900: 线性锂| LLI[imp_linear_li]
    DIODE_TEST -->|超时+高压: 恒压锂| LIION
    DIODE_TEST -->|超时+低压: 干电池| ERROR

    LIION --> ROUTE
    LLI --> ROUTE

    ACTIVATE[CHG_ACTIVATE<br>过放脉冲激活] -->|v>阈值| PRECHARGE
    ACTIVATE -->|超时| ERROR

    PRECHARGE[CHG_PRECHARGE<br>小电流预充] -->|v>=预充阈值| CC
    PRECHARGE -->|超时/过压| ERROR

    CC[CHG_CC_CHARGE<br>恒流充电] -->|峰值>=FULL / LINEAR_LI>=8块| CV
    CC -->|LI_ION + v>=OPEN| FULL
    CC -->|PEAK_DROP>500| DETECT
    CC -->|超时/过压| ERROR

    CV[CHG_CV_CHARGE<br>恒压充电] -->|ct>TIME_CV_HOLD / LI_ION拔出| FULL
    CV -->|拔出 非LINEAR_LI| IDLE
    CV -->|PEAK_DROP>500| DETECT
    CV -->|过压| ERROR

    FULL[CHG_FULL<br>充满待机] -->|拔出确认| IDLE
    FULL -->|v<2800补电| CC

    ERROR[CHG_ERROR<br>错误状态] -->|v>=OPEN拔出| IDLE
    ERROR -->|重判条件满足| DETECT

    style IDLE fill:#dae8fc,stroke:#6c8ebf
    style DETECT fill:#dae8fc,stroke:#6c8ebf
    style IMP_CHECK fill:#dae8fc,stroke:#6c8ebf
    style DIODE_TEST fill:#dae8fc,stroke:#6c8ebf
    style ACTIVATE fill:#dae8fc,stroke:#6c8ebf
    style PRECHARGE fill:#dae8fc,stroke:#6c8ebf
    style ROUTE fill:#fff2cc,stroke:#d6b656
    style LIION fill:#d5e8d4,stroke:#82b366
    style LLI fill:#d5e8d4,stroke:#82b366
    style CC fill:#e1d5e7,stroke:#9673a6
    style CV fill:#e1d5e7,stroke:#9673a6
    style FULL fill:#d5e8d4,stroke:#82b366
    style ERROR fill:#f8cecc,stroke:#b85450
    style START fill:#f5f5f5,stroke:#666666
    style SWITCH fill:#fff2cc,stroke:#d6b656
```

### 1b. DETECT 内部子状态

```mermaid
flowchart TD
    A[CHG_DETECT] --> B[ct++]
    B --> C{线性锂跳变?\nv≥OPEN 且 基准>0\n且 跳幅>500}
    C -->|Y| C1[ty=LINEAR_LI → CC_CHARGE]
    C -->|N| D{ct < TIME_DETECT_WAIT?}
    D -->|Y| D1[跟踪g_slotRefV\nv<OPEN时更新]
    D -->|N| E{ct == TIME_DETECT_WAIT?}
    E -->|Y| E1[记录基准\nv>2900→g_capFlag]
    E -->|N| F{v>2900 且 v<OPEN?}
    F -->|高压路径| G{g_capFlag 或 AMBIGUOUS?}
    G -->|N| G1[异常跳升→重置DETECT]
    G -->|Y| H{稳定计数≥TICKS?}
    H -->|阶段1:未稳定| H1[下跌→重置/稳定→计数++]
    H -->|阶段2:已稳定| H2{v≤2900?}
    H2 -->|Y| H3[电容放电确认\n清除高压标记]
    H2 -->|N| H4{ct<WAIT+SETTLE?}
    H4 -->|Y-提前| H5[稳定2秒→amb_shortcut]
    H4 -->|N-超时| H5
    F -->|低压路径| I{ct<WAIT+SETTLE\n且v<OPEN?}
    I -->|Y| I1[电压下跌→更新基准]
    I -->|N| J{g_capFlag?}
    H3 --> J
    H5 --> K[ty=AMBIGUOUS]
    I1 --> J
    J -->|Y| K
    J -->|N| L[Detect_BatteryType]
    K --> M{v<SHORT?}
    L --> M
    M -->|Y| M1[消抖N次→UNKNOWN]
    M -->|N| N["amb_check分发"]
    N --> O{AMBIGUOUS?}
    O -->|Y| O1[2帧→串行锁→IMP_CHECK]
    O -->|N| P{LI_ION/LINEAR_LI?}
    P -->|Y| P1[2帧→DETECT_LI_ROUTE]
    P -->|N| Q{UNKNOWN?}
    Q -->|v≥OPEN| Q1[等待放电超时→AMBIGUOUS]
    Q -->|v<OPEN| Q2[→ERROR]
    Q -->|N| R[NIMH/DRY→ERROR]
```

### 1c. IMP_CHECK 内部子状态

```mermaid
flowchart TD
    A[IMP_CHECK入口] --> B[等待IMP_PULSE_TICKS\nMOSFET导通~80ms]
    B --> C[采样VCC,与脉冲前比较]
    C --> D{VCC跌>300mV?}
    D -->|Y| D1[NiMH → ERROR]
    D -->|N| E{脉冲前后均OPEN?}
    E -->|Y| E1[空槽 → IDLE]
    E -->|N| F{VCC跌>100mV?}
    F -->|Y| F1[imp_li_ion → 充电路由]
    F -->|N| G{脉冲前>2300?}
    G -->|Y,>3500| G1[空槽噪声 → IDLE]
    G -->|Y,2300~3500| G2[DIODE_TEST]
    G -->|N| H{脉冲后≥OPEN?}
    H -->|Y| H1[imp_linear_li → 充电路由]
    H -->|N| H2[DIODE_TEST]
    G2 --> I[DIODE_TEST]
    H2 --> I
    I --> J[关断MOSFET\n观察电容爬升]
    J --> K{爬升>900?}
    K -->|Y| K1[imp_linear_li → 充电路由]
    K -->|N| L{超时?}
    L -->|N| J
    L -->|Y| M{高压标记 或 v>2900?}
    M -->|Y| M1[imp_li_ion → 充电路由]
    M -->|N| M2[干电池 → ERROR]
```



---

## 2. 充电状态 (CC/CV/FULL/ERROR)

```mermaid
flowchart TD
    subgraph CC["CHG_CC_CHARGE"]
        CC1[ct++ 时间块计数] --> CC2{CC_BLOCK_TICKS到达?}
        CC2 -->|是| CC3[块计数++]
        CC2 -->|否| CC4[继续]
        CC3 --> CC5{块数 ≥ CC_MAX_BLOCKS?}
        CC5 -->|是| CC6[超时 → ERROR]
        CC5 -->|否| CC7{LINEAR_LI 且 块≥8?}
        CC7 -->|是| CC8[时间基准 → CV_CHARGE]
        CC7 -->|否| CC9[峰值跟踪:\nv<OPEN且更大→更新\nLINEAR_LI加v<3500门禁]
        CC9 --> CC10{PEAK_DROP > 500?}
        CC10 -->|是| CC11[2帧消抖 → DETECT重判]
        CC10 -->|否| CC12{v≥OPEN 且 LI_ION?}
        CC12 -->|是| CC13[电芯已满 → FULL]
        CC12 -->|否| CC14{LINEAR_LI?}
        CC14 -->|是| CC15{峰值 ≥ ADC_V_FULL?}
        CC15 -->|是| CC16[→ CV_CHARGE]
        CC15 -->|否| CC17[跳过OV检查, 继续CC]
        CC14 -->|否| CC18{v ≥ ADC_V_OVER?}
        CC18 -->|是| CC19[过压消抖 → ERROR]
        CC18 -->|否| CC20{v ≥ ADC_V_FULL?}
        CC20 -->|是| CC21[→ CV_CHARGE]
        CC20 -->|否| CC17
    end

    subgraph CV["CHG_CV_CHARGE"]
        CV1[ct++] --> CV2{ct > TIME_CV_HOLD?}
        CV2 -->|是| CV3[→ FULL]
        CV2 -->|否| CV4[峰值追踪\nLINEAR_LI加v<3500门禁]
        CV4 --> CV5{v≥OPEN 且 非LINEAR_LI?}
        CV5 -->|是| CV6{ty==LI_ION?}
        CV6 -->|是| CV7[2帧 → FULL]
        CV6 -->|否| CV8[2帧 → IDLE]
        CV5 -->|否| CV9{PEAK_DROP > 500?}
        CV9 -->|是| CV10[2帧 → DETECT重判]
        CV9 -->|否| CV11{v ≥ ADC_V_OVER?}
        CV11 -->|是| CV12[过压消抖 → ERROR]
        CV11 -->|否| CV13[继续CV]
    end

    subgraph FULL["CHG_FULL"]
        F1{v ≥ ADC_V_OPEN?} -->|是| F2{LINEAR_LI?}
        F2 -->|是| F3[50帧消抖 → IDLE]
        F2 -->|否| F4[2帧 → IDLE]
        F1 -->|否| F5{v < 2800?}
        F5 -->|是| F6[2帧 → CC补电]
        F5 -->|否| F7[保持FULL]
    end

    subgraph ERR["CHG_ERROR"]
        E1{v ≥ ADC_V_OPEN?} -->|是| E2[2帧 → IDLE]
        E1 -->|否| E3{NIMH/DRY?}
        E3 -->|是| E4{v>2700 且 g_highVFlag?}
        E4 -->|是| E5[2帧 → DETECT重判\n可能恒压锂误判]
        E4 -->|否| E6[锁定ERROR\n真NiMH/干电池]
        E3 -->|否| E7{v > ADC_V_ACTIVATE?}
        E7 -->|是| E8[2帧 → DETECT重判]
        E7 -->|否| E9[保持ERROR]
    end

    CC --> CV
    CV --> FULL
    CC --> ERR
    CV --> ERR
```

---

## 3. 关键 goto 标签说明

| 标签 | 位置 | 功能 |
|------|------|------|
| `amb_shortcut` | DETECT:262 | 高压超时→ty=AMBIGUOUS后跳转 `amb_check` |
| `amb_check` | DETECT:321 | 电池类型统一分发: AMBIGUOUS→IMP_CHECK, 锂电→路由, 干电池→ERROR |
| `imp_li_ion` | IMP_CHECK:443 | 恒压锂共享路由, IMP_CHECK/DIODE_TEST确认后跳入 |
| `imp_linear_li` | IMP_CHECK:451 | 线性锂共享路由, v<OPEN用当前值, v≥OPEN用脉冲前电压 |

## 4. 电池分类决策树

```mermaid
flowchart LR
    BAT[放入电池] --> DETECT
    DETECT -->|跳变>500| LINEAR_LI[线性锂 → CC]
    DETECT -->|v<SHORT短路| UNKNOWN
    DETECT -->|NIMH_LOW~OPEN| AMBIGUOUS[AMBIGUOUS]
    DETECT -->|v≥OPEN| AMBIGUOUS
    DETECT -->|SHORT~NIMH_LOW| LI_ION[恒压锂 → 路由]
    
    AMBIGUOUS --> IMP_CHECK
    IMP_CHECK -->|VCC跌>300mV| NIMH[NiMH → ERROR]
    IMP_CHECK -->|脉冲前后均OPEN| EMPTY[空槽 → IDLE]
    IMP_CHECK -->|VCC跌>100mV| LI_ION
    IMP_CHECK -->|无跌落| DIODE_TEST
    
    DIODE_TEST -->|爬升>900| LINEAR_LI
    DIODE_TEST -->|超时+高压| LI_ION
    DIODE_TEST -->|超时+低压| DRY[干电池 → ERROR]
```
