opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_CCCV_Control
	FNCALL	_main,_Get_Vcc
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_Read_Temperature
	FNCALL	_main,_Slot_Charge_Ctrl
	FNCALL	_main,_System_Init
	FNCALL	_main,_Update_LED_Global
	FNCALL	_main,_uart_send_string
	FNCALL	_Update_LED_Global,___bmul
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Slot_Charge_Ctrl,_Adc_Norm
	FNCALL	_Slot_Charge_Ctrl,_Detect_BatteryType
	FNCALL	_Slot_Charge_Ctrl,_Get_Vcc
	FNCALL	_Slot_Charge_Ctrl,___bmul
	FNCALL	_Slot_Charge_Ctrl,___lldiv
	FNCALL	_Slot_Charge_Ctrl,___lmul
	FNCALL	_Slot_Charge_Ctrl,___lwdiv
	FNCALL	_Slot_Charge_Ctrl,___wmul
	FNCALL	_Get_Vcc,_ADC_Sample
	FNCALL	_Get_Vcc,___lldiv
	FNCALL	_Adc_Norm,_ADC_Sample
	FNCALL	_Adc_Norm,___lldiv
	FNCALL	_Adc_Norm,___lmul
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,___bmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_vcc_mv
	global	_g_temperature
	global	_g_impCheckSlot
psect	idataBANK0,class=CODE,space=0,delta=2,noexec
global __pidataBANK0
__pidataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	25

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	18

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

	line	26

;initializer for _g_impCheckSlot
	retlw	0FFh
	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	47
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_powerOnPhase
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_diodeTrace
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_powerOnTimer
	global	_g_cvIntegral
	global	_g_impData
	global	_s_ledBlinkCnt
	global	_g_tempPhase
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_diodeTraceSlot
	global	_g_diodeTraceCnt
	global	_test_adc
	global	_adresult
	global	_g_detectLowCnt
	global	_g_highVFlag
	global	_g_capFlag
	global	_g_vccProtect
	global	_g_tempProtect
	global	_g_slot
	global	_g_slotRefV
	global	_g_stableCnt
	global	_g_ovCnt
	global	_g_ccBlocks
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_GIE
_GIE	set	0x5F
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC4
_RC4	set	0x834
	global	_RC5
_RC5	set	0x835
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	0
psect	stringtext
	
STR_37:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_25:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_23:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	45	;'-'
	retlw	105	;'i'
	retlw	111	;'o'
	retlw	110	;'n'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	67	;'C'
	retlw	32	;' '
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	95	;'_'
	retlw	76	;'L'
	retlw	79	;'O'
	retlw	67	;'C'
	retlw	75	;'K'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_38:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_8:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_30:	
	retlw	32	;' '
	retlw	112	;'p'
	retlw	114	;'r'
	retlw	101	;'e'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	32	;' '
	retlw	114	;'r'
	retlw	101	;'e'
	retlw	102	;'f'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_31:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_29:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	73	;'I'
	retlw	79	;'O'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_7:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_34:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	114	;'r'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_32:	
	retlw	32	;' '
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_33:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	53	;'5'
	retlw	53	;'5'
	retlw	70	;'F'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
STR_27	equ	STR_17+0
STR_9	equ	STR_2+0
STR_11	equ	STR_38+7
STR_35	equ	STR_38+7
STR_36	equ	STR_38+7
; #config settings
	file	"SC8F096_Timer_Demo.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_g_powerOnPhase:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_diodeTrace:
       ds      4

_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_powerOnTimer:
       ds      2

_g_cvIntegral:
       ds      2

_g_impData:
       ds      2

_s_ledBlinkCnt:
       ds      1

_g_tempPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_diodeTraceSlot:
       ds      1

_g_diodeTraceCnt:
       ds      1

_test_adc:
       ds      1

_adresult:
       ds      2

psect	dataBANK0,class=BANK0,space=1,noexec
global __pdataBANK0
__pdataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	25
_g_vcc_mv:
       ds      2

psect	dataBANK0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	18
_g_temperature:
       ds      2

psect	dataBANK0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	26
_g_impCheckSlot:
       ds      1

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_detectLowCnt:
       ds      12

_g_highVFlag:
       ds      2

_g_capFlag:
       ds      2

_g_vccProtect:
       ds      1

_g_tempProtect:
       ds      1

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slotRefV:
       ds      24

_g_stableCnt:
       ds      12

_g_ovCnt:
       ds      12

_g_ccBlocks:
       ds      12

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"SC8F096_Timer_Demo.as"
	line	#
; Initialize objects allocated to BANK0
	global __pidataBANK0
psect cinit,class=CODE,delta=2,merge=1
	fcall	__pidataBANK0+0		;fetch initializer
	movwf	__pdataBANK0+0&07fh		
	fcall	__pidataBANK0+1		;fetch initializer
	movwf	__pdataBANK0+1&07fh		
	fcall	__pidataBANK0+2		;fetch initializer
	movwf	__pdataBANK0+2&07fh		
	fcall	__pidataBANK0+3		;fetch initializer
	movwf	__pdataBANK0+3&07fh		
	fcall	__pidataBANK0+4		;fetch initializer
	movwf	__pdataBANK0+4&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+03Ch)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+012h)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+019h)
	fcall	clear_ram0
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
	global	Slot_Charge_Ctrl@v_init
Slot_Charge_Ctrl@v_init:	; 2 bytes @ 0x0
	ds	2
	global	Slot_Charge_Ctrl@vx_mv
Slot_Charge_Ctrl@vx_mv:	; 4 bytes @ 0x2
	ds	4
	global	Slot_Charge_Ctrl@bat_mv_long
Slot_Charge_Ctrl@bat_mv_long:	; 4 bytes @ 0x6
	ds	4
	global	Slot_Charge_Ctrl@vx_mv_376
Slot_Charge_Ctrl@vx_mv_376:	; 4 bytes @ 0xA
	ds	4
	global	Slot_Charge_Ctrl@bat_mv_long_377
Slot_Charge_Ctrl@bat_mv_long_377:	; 4 bytes @ 0xE
	ds	4
	global	Slot_Charge_Ctrl@vx_mv_379
Slot_Charge_Ctrl@vx_mv_379:	; 4 bytes @ 0x12
	ds	4
	global	Slot_Charge_Ctrl@bat_mv_long_380
Slot_Charge_Ctrl@bat_mv_long_380:	; 4 bytes @ 0x16
	ds	4
	global	_Slot_Charge_Ctrl$386
_Slot_Charge_Ctrl$386:	; 2 bytes @ 0x1A
	ds	2
	global	Slot_Charge_Ctrl@hasRise
Slot_Charge_Ctrl@hasRise:	; 1 bytes @ 0x1C
	ds	1
	global	Slot_Charge_Ctrl@newv
Slot_Charge_Ctrl@newv:	; 2 bytes @ 0x1D
	ds	2
	global	Slot_Charge_Ctrl@v_ref
Slot_Charge_Ctrl@v_ref:	; 2 bytes @ 0x1F
	ds	2
	global	Slot_Charge_Ctrl@dly
Slot_Charge_Ctrl@dly:	; 1 bytes @ 0x21
	ds	1
	global	Slot_Charge_Ctrl@tc
Slot_Charge_Ctrl@tc:	; 1 bytes @ 0x22
	ds	1
	global	Slot_Charge_Ctrl@bat_mv
Slot_Charge_Ctrl@bat_mv:	; 2 bytes @ 0x23
	ds	2
	global	Slot_Charge_Ctrl@bat_mv_378
Slot_Charge_Ctrl@bat_mv_378:	; 2 bytes @ 0x25
	ds	2
	global	Slot_Charge_Ctrl@bat_mv_381
Slot_Charge_Ctrl@bat_mv_381:	; 2 bytes @ 0x27
	ds	2
	global	Slot_Charge_Ctrl@diff
Slot_Charge_Ctrl@diff:	; 2 bytes @ 0x29
	ds	2
	global	Slot_Charge_Ctrl@pre
Slot_Charge_Ctrl@pre:	; 2 bytes @ 0x2B
	ds	2
	global	Slot_Charge_Ctrl@st
Slot_Charge_Ctrl@st:	; 1 bytes @ 0x2D
	ds	1
	global	Slot_Charge_Ctrl@ty
Slot_Charge_Ctrl@ty:	; 1 bytes @ 0x2E
	ds	1
	global	Slot_Charge_Ctrl@ct
Slot_Charge_Ctrl@ct:	; 2 bytes @ 0x2F
	ds	2
	global	Slot_Charge_Ctrl@v
Slot_Charge_Ctrl@v:	; 2 bytes @ 0x31
	ds	2
	global	Slot_Charge_Ctrl@idx
Slot_Charge_Ctrl@idx:	; 1 bytes @ 0x33
	ds	1
??_main:	; 1 bytes @ 0x34
	ds	2
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_Slot_Charge_Ctrl:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Update_LED_Global:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
??_Isr_Timer:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?_Get_Vcc:	; 2 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	ds	2
??_AD_Init:	; 1 bytes @ 0x2
??_uart_init:	; 1 bytes @ 0x2
?_ADC_Sample:	; 1 bytes @ 0x2
??_uart_send_char:	; 1 bytes @ 0x2
?_Detect_BatteryType:	; 1 bytes @ 0x2
?___bmul:	; 1 bytes @ 0x2
	global	?___wmul
?___wmul:	; 2 bytes @ 0x2
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x2
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x2
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x2
	global	?___lmul
?___lmul:	; 4 bytes @ 0x2
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x2
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x2
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x2
	global	___wmul@multiplier
___wmul@multiplier:	; 2 bytes @ 0x2
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x2
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x2
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x2
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x2
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x3
??___bmul:	; 1 bytes @ 0x3
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x3
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x3
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x4
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x4
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x4
	global	___wmul@multiplicand
___wmul@multiplicand:	; 2 bytes @ 0x4
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x4
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x4
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x4
	ds	1
?_uart_send_string:	; 1 bytes @ 0x5
??_Update_LED_Global:	; 1 bytes @ 0x5
??_System_Init:	; 1 bytes @ 0x5
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x5
	global	Update_LED_Global@hasErr
Update_LED_Global@hasErr:	; 1 bytes @ 0x5
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x5
	ds	1
??___wmul:	; 1 bytes @ 0x6
??___awdiv:	; 1 bytes @ 0x6
??___lwdiv:	; 1 bytes @ 0x6
??___lwmod:	; 1 bytes @ 0x6
	global	Update_LED_Global@hasChg
Update_LED_Global@hasChg:	; 1 bytes @ 0x6
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x6
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x6
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x6
	global	___wmul@product
___wmul@product:	; 2 bytes @ 0x6
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x6
	ds	1
??_uart_send_string:	; 1 bytes @ 0x7
	global	Update_LED_Global@hasFull
Update_LED_Global@hasFull:	; 1 bytes @ 0x7
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x7
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x7
	ds	1
	global	Update_LED_Global@i
Update_LED_Global@i:	; 1 bytes @ 0x8
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x8
	ds	1
??_uart_send_number:	; 1 bytes @ 0x9
??_Print_NtcTemp:	; 1 bytes @ 0x9
	global	Update_LED_Global@s
Update_LED_Global@s:	; 1 bytes @ 0x9
	ds	1
??_Get_Vcc:	; 1 bytes @ 0xA
??_Adc_Norm:	; 1 bytes @ 0xA
??___lmul:	; 1 bytes @ 0xA
??___lldiv:	; 1 bytes @ 0xA
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
?_uart_send_number:	; 1 bytes @ 0x0
??_CCCV_Control:	; 1 bytes @ 0x0
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x0
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x0
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x0
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x1
	ds	1
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x2
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x2
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x2
	ds	1
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x4
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x4
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x4
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0x5
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0x6
	ds	1
	global	CCCV_Control@detectCount
CCCV_Control@detectCount:	; 1 bytes @ 0x7
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0x8
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x8
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x8
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x9
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0xA
	global	_Print_NtcTemp$707
_Print_NtcTemp$707:	; 2 bytes @ 0xA
	ds	1
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xC
	global	_Print_NtcTemp$708
_Print_NtcTemp$708:	; 2 bytes @ 0xC
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0xC
	ds	2
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0xE
	ds	1
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0xF
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0x10
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x10
	ds	1
??_Read_Temperature:	; 1 bytes @ 0x11
??_Print_SystemStatus:	; 1 bytes @ 0x11
	global	?_Adc_Norm
?_Adc_Norm:	; 2 bytes @ 0x11
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0x11
	global	Get_Vcc@pt
Get_Vcc@pt:	; 4 bytes @ 0x11
	ds	2
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x13
	ds	1
	global	Adc_Norm@ch
Adc_Norm@ch:	; 1 bytes @ 0x14
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x14
	ds	1
	global	Adc_Norm@raw
Adc_Norm@raw:	; 2 bytes @ 0x15
	global	_Print_SystemStatus$709
_Print_SystemStatus$709:	; 2 bytes @ 0x15
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x15
	ds	2
	global	_Print_SystemStatus$710
_Print_SystemStatus$710:	; 2 bytes @ 0x17
	global	Adc_Norm@norm
Adc_Norm@norm:	; 4 bytes @ 0x17
	ds	2
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x19
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x19
	ds	2
??_Slot_Charge_Ctrl:	; 1 bytes @ 0x1B
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x1B
	ds	2
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x1D
	ds	1
	global	_Print_SystemStatus$265
_Print_SystemStatus$265:	; 2 bytes @ 0x1E
	ds	2
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x20
	ds	2
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0x22
	ds	4
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x26
	ds	2
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0x28
	ds	4
	global	Print_SystemStatus@tc
Print_SystemStatus@tc:	; 1 bytes @ 0x2C
	ds	1
	global	Print_SystemStatus@t
Print_SystemStatus@t:	; 1 bytes @ 0x2D
	ds	1
	global	Print_SystemStatus@d
Print_SystemStatus@d:	; 2 bytes @ 0x2E
	ds	2
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x30
	ds	1
	global	main@i
main@i:	; 1 bytes @ 0x31
	ds	1
;!
;!Data Sizes:
;!    Strings     254
;!    Constant    12
;!    Data        5
;!    BSS         176
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     10      12
;!    BANK0            80     50      80
;!    BANK1            80     54      72
;!    BANK3            80      0      60
;!    BANK2            80      0      72

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 25
;!		 -> STR_38(CODE[10]), STR_37(CODE[21]), STR_36(CODE[3]), STR_35(CODE[3]), 
;!		 -> STR_34(CODE[5]), STR_33(CODE[5]), STR_32(CODE[5]), STR_31(CODE[6]), 
;!		 -> STR_30(CODE[6]), STR_29(CODE[6]), STR_28(CODE[6]), STR_27(CODE[6]), 
;!		 -> STR_26(CODE[6]), STR_25(CODE[16]), STR_24(CODE[13]), STR_23(CODE[15]), 
;!		 -> STR_22(CODE[7]), STR_21(CODE[5]), STR_20(CODE[5]), STR_19(CODE[6]), 
;!		 -> STR_18(CODE[6]), STR_17(CODE[6]), STR_16(CODE[6]), STR_15(CODE[7]), 
;!		 -> STR_14(CODE[4]), STR_13(CODE[6]), STR_12(CODE[6]), STR_11(CODE[3]), 
;!		 -> STR_10(CODE[12]), STR_9(CODE[2]), STR_8(CODE[6]), STR_7(CODE[5]), 
;!		 -> STR_6(CODE[6]), STR_5(CODE[5]), STR_4(CODE[25]), STR_3(CODE[4]), 
;!		 -> STR_2(CODE[2]), STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    _main->_Update_LED_Global
;!    _Update_LED_Global->___bmul
;!    _System_Init->___bmul
;!    _Slot_Charge_Ctrl->___lmul
;!    _Adc_Norm->___lmul
;!    _Read_Temperature->___lmul
;!    _Print_SystemStatus->___lmul
;!    ___lldiv->___lmul
;!    _Print_NtcTemp->___lwdiv
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    None.
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Print_SystemStatus
;!    _Slot_Charge_Ctrl->_Adc_Norm
;!    _Get_Vcc->___lldiv
;!    _Adc_Norm->___lldiv
;!    _Read_Temperature->___lldiv
;!    _Print_SystemStatus->___lldiv
;!    ___lldiv->___lmul
;!    _Print_NtcTemp->_uart_send_number
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    None.
;!
;!Critical Paths under _main in BANK1
;!
;!    _main->_Slot_Charge_Ctrl
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 3     3      0   59276
;!                                             49 BANK0      1     1      0
;!                                             52 BANK1      2     2      0
;!                       _CCCV_Control
;!                            _Get_Vcc
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                   _Read_Temperature
;!                   _Slot_Charge_Ctrl
;!                        _System_Init
;!                  _Update_LED_Global
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Update_LED_Global                                    5     5      0    1173
;!                                              5 COMMON     5     5      0
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1090
;!                                              5 COMMON     1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Slot_Charge_Ctrl                                    57    57      0   25251
;!                                             27 BANK0      5     5      0
;!                                              0 BANK1     52    52      0
;!                           _Adc_Norm
;!                 _Detect_BatteryType
;!                            _Get_Vcc
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (2) ___wmul                                               6     2      4    1922
;!                                              2 COMMON     6     2      4
;! ---------------------------------------------------------------------------------
;! (2) _Get_Vcc                                              4     4      0    2392
;!                                             17 BANK0      4     4      0
;!                         _ADC_Sample
;!                            ___lldiv
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     185
;!                                              2 COMMON     2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _Adc_Norm                                            10     7      3    4127
;!                                             17 BANK0     10     7      3
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (1) _Read_Temperature                                    12    12      0    5143
;!                                             17 BANK0     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  32    32      0   12476
;!                                             17 BANK0     32    32      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8    1605
;!                                              2 COMMON     8     0      8
;!                                              0 BANK0      4     4      0
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1328
;!                                              4 BANK0     13     5      8
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (3) _ADC_Sample                                          18    17      1    1030
;!                                              2 COMMON     5     4      1
;!                                              0 BANK0     13    13      0
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    6430
;!                                             10 BANK0      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    2637
;!                                              5 COMMON     2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_number                                    10     8      2    2628
;!                                              0 BANK0     10     8      2
;!                             ___bmul (ARG)
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     102
;!                                              2 COMMON     3     3      0
;! ---------------------------------------------------------------------------------
;! (3) ___lwmod                                              5     1      4     378
;!                                              2 COMMON     5     1      4
;! ---------------------------------------------------------------------------------
;! (2) ___lwdiv                                              7     3      4     777
;!                                              2 COMMON     7     3      4
;! ---------------------------------------------------------------------------------
;! (1) _CCCV_Control                                        21    21      0    2585
;!                                              0 BANK0     21    21      0
;!                            ___awdiv
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1     836
;!                                              2 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (2) ___awdiv                                              8     4      4     428
;!                                              2 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 3
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            2     2      0       0
;!                                              0 COMMON     2     2      0
;!                 _PowerOnLedSequence
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 5
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     ___bmul
;!   _Get_Vcc
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Read_Temperature
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!   _Slot_Charge_Ctrl
;!     _Adc_Norm
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!     _Detect_BatteryType
;!     _Get_Vcc
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___wmul
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _Update_LED_Global
;!     ___bmul
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _PowerOnLedSequence
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50      0      3C       8       75.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      0      48      10       90.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50     36      48       6       90.0%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     32      50       4      100.0%
;!BITBANK0            50      0       0       3        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      A       C       1       85.7%
;!BITCOMMON            E      0       1       0        7.1%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     128      12        0.0%
;!ABS                  0      0     128      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 408 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   49[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       2       0       0
;;      Totals:         0       1       2       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_CCCV_Control
;;		_Get_Vcc
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_Slot_Charge_Ctrl
;;		_System_Init
;;		_Update_LED_Global
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	408
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	408
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 3
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	413
	
l6772:	
;main.c: 410: unsigned char i;
;main.c: 413: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_main+0)^080h+0+1),f
	movlw	241
movwf	((??_main+0)^080h+0),f
	u10387:
decfsz	((??_main+0)^080h+0),f
	goto	u10387
	decfsz	((??_main+0)^080h+0+1),f
	goto	u10387
opt asmopt_pop

	line	414
# 414 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	417
	
l6774:	
;main.c: 417: System_Init();
	fcall	_System_Init
	line	420
	
l6776:	
;main.c: 420: uart_send_string("L1211 Charger V2.1\r\n");
	movlw	low(((STR_37)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_37)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	421
	
l6778:	
;main.c: 421: uart_send_string("Init...\r\n");
	movlw	low(((STR_38)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_38)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	425
;main.c: 425: while(1)
	
l406:	
	line	427
# 427 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	430
	
l6780:	
;main.c: 430: Get_Vcc();
	fcall	_Get_Vcc
	line	433
	
l6782:	
;main.c: 433: for(i = 0; i < 12; i++)
	clrf	(main@i)
	line	435
	
l6788:	
;main.c: 434: {
;main.c: 435: Slot_Charge_Ctrl(i);
	movf	(main@i),w
	fcall	_Slot_Charge_Ctrl
	line	433
	
l6790:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(main@i),f
	
l6792:	
	movlw	low(0Ch)
	subwf	(main@i),w
	skipc
	goto	u10351
	goto	u10350
u10351:
	goto	l6788
u10350:
	line	439
	
l6794:	
;main.c: 436: }
;main.c: 439: CCCV_Control();
	fcall	_CCCV_Control
	line	442
	
l6796:	
;main.c: 442: Update_LED_Global();
	fcall	_Update_LED_Global
	line	445
	
l6798:	
;main.c: 445: if(g_doNtcRead)
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u10361
	goto	u10360
u10361:
	goto	l6804
u10360:
	line	447
	
l6800:	
;main.c: 446: {
;main.c: 447: g_doNtcRead = 0;
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	448
	
l6802:	
;main.c: 448: Read_Temperature();
	fcall	_Read_Temperature
	line	453
	
l6804:	
;main.c: 449: }
;main.c: 453: if(g_printFlag)
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u10371
	goto	u10370
u10371:
	goto	l406
u10370:
	line	455
	
l6806:	
;main.c: 454: {
;main.c: 455: g_printFlag = 0;
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	456
	
l6808:	
;main.c: 456: Print_SystemStatus();
	fcall	_Print_SystemStatus
	line	457
;main.c: 457: Print_NtcTemp();
	fcall	_Print_NtcTemp
	goto	l406
	global	start
	ljmp	start
	opt stack 0
	line	461
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_Update_LED_Global

;; *************** function _Update_LED_Global *****************
;; Defined at:
;;		line 27 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    9[COMMON] unsigned char 
;;  i               1    8[COMMON] unsigned char 
;;  hasFull         1    7[COMMON] unsigned char 
;;  hasChg          1    6[COMMON] unsigned char 
;;  hasErr          1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         5       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	27
global __ptext1
__ptext1:	;psect for function _Update_LED_Global
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	27
	global	__size_of_Update_LED_Global
	__size_of_Update_LED_Global	equ	__end_of_Update_LED_Global-_Update_LED_Global
	
_Update_LED_Global:	
;incstack = 0
	opt	stack 4
; Regs used in _Update_LED_Global: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	30
	
l6690:	
;led.c: 29: unsigned char i;
;led.c: 30: unsigned char hasErr = 0;
	clrf	(Update_LED_Global@hasErr)
	line	31
;led.c: 31: unsigned char hasChg = 0;
	clrf	(Update_LED_Global@hasChg)
	line	32
;led.c: 32: unsigned char hasFull = 0;
	clrf	(Update_LED_Global@hasFull)
	line	34
;led.c: 34: for(i = 0; i < 12; i++)
	clrf	(Update_LED_Global@i)
	line	36
	
l6696:	
;led.c: 35: {
;led.c: 36: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Global@s)
	line	37
	
l6698:	
;led.c: 37: if(s == 7)
		movlw	7
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u10131
	goto	u10130
u10131:
	goto	l6702
u10130:
	line	38
	
l6700:	
;led.c: 38: hasErr = 1;
	clrf	(Update_LED_Global@hasErr)
	incf	(Update_LED_Global@hasErr),f
	goto	l6712
	line	39
	
l6702:	
;led.c: 39: else if(s != 0 && s != 6)
	movf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u10141
	goto	u10140
u10141:
	goto	l6708
u10140:
	
l6704:	
		movlw	6
	xorwf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u10151
	goto	u10150
u10151:
	goto	l6708
u10150:
	line	40
	
l6706:	
;led.c: 40: hasChg = 1;
	clrf	(Update_LED_Global@hasChg)
	incf	(Update_LED_Global@hasChg),f
	goto	l6712
	line	41
	
l6708:	
;led.c: 41: else if(s == 6)
		movlw	6
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u10161
	goto	u10160
u10161:
	goto	l6712
u10160:
	line	42
	
l6710:	
;led.c: 42: hasFull = 1;
	clrf	(Update_LED_Global@hasFull)
	incf	(Update_LED_Global@hasFull),f
	line	34
	
l6712:	
	incf	(Update_LED_Global@i),f
	
l6714:	
	movlw	low(0Ch)
	subwf	(Update_LED_Global@i),w
	skipc
	goto	u10171
	goto	u10170
u10171:
	goto	l6696
u10170:
	line	45
	
l6716:	
;led.c: 43: }
;led.c: 45: if(hasErr)
	movf	((Update_LED_Global@hasErr)),w
	btfsc	status,2
	goto	u10181
	goto	u10180
u10181:
	goto	l6726
u10180:
	line	48
	
l6718:	
;led.c: 46: {
;led.c: 48: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	49
	
l6720:	
;led.c: 49: if(++s_ledBlinkCnt >= (16 / 2))
	movlw	low(08h)
	bcf	status, 6	;RP1=0, select bank0
	incf	(_s_ledBlinkCnt),f	;volatile
	subwf	((_s_ledBlinkCnt)),w	;volatile
	skipc
	goto	u10191
	goto	u10190
u10191:
	goto	l6724
u10190:
	line	50
	
l6722:	
;led.c: 50: s_ledBlinkCnt = 0;
	clrf	(_s_ledBlinkCnt)	;volatile
	line	51
	
l6724:	
;led.c: 51: RC5 = (s_ledBlinkCnt < ((16 / 2) / 2)) ? 0 : 1;
	movlw	low(04h)
	subwf	(_s_ledBlinkCnt),w	;volatile
	skipnc
	goto	u10201
	goto	u10200
	
u10201:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u10214
u10200:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u10214:
	line	52
;led.c: 52: }
	goto	l870
	line	53
	
l6726:	
;led.c: 53: else if(hasChg)
	movf	((Update_LED_Global@hasChg)),w
	btfsc	status,2
	goto	u10221
	goto	u10220
u10221:
	goto	l6730
u10220:
	line	56
	
l6728:	
;led.c: 54: {
;led.c: 56: RC5 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	57
;led.c: 57: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	58
;led.c: 58: }
	goto	l870
	line	59
	
l6730:	
;led.c: 59: else if(hasFull)
	movf	((Update_LED_Global@hasFull)),w
	btfsc	status,2
	goto	u10231
	goto	u10230
u10231:
	goto	l868
u10230:
	line	62
	
l6732:	
;led.c: 60: {
;led.c: 62: RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	63
;led.c: 63: RC4 = 0;
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	64
;led.c: 64: }
	goto	l870
	line	65
	
l868:	
	line	68
;led.c: 65: else
;led.c: 66: {
;led.c: 68: RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	69
;led.c: 69: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	71
	
l870:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Global
	__end_of_Update_LED_Global:
	signat	_Update_LED_Global,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 68 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         1       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	68
global __ptext2
__ptext2:	;psect for function _System_Init
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	68
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 4
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	73
	
l5322:	
# 73 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	74
# 74 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text2
	line	75
	
l5324:	
;main.c: 75: OSCCON = 0x72;
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	79
;main.c: 79: TRISA = 0xF0; PORTA = 0x0F;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	80
;main.c: 80: TRISB = 0x30; PORTB = 0x4F;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	81
;main.c: 81: TRISC = 0x07; PORTC = 0x00;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l5326:	
	clrf	(262)^0100h	;volatile
	line	83
	
l5328:	
;main.c: 83: TRISD = 0xF0; PORTD = 0x0F;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l5330:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	86
	
l5332:	
;main.c: 86: WPUA = 0x00; WPDA = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l5334:	
	clrf	(135)^080h	;volatile
	line	87
	
l5336:	
;main.c: 87: WPUB = 0x00; WPDB = 0x00;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l5338:	
	clrf	(7)	;volatile
	line	88
	
l5340:	
;main.c: 88: WPUC = 0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	89
	
l5342:	
;main.c: 89: WPUD = 0x00;
	clrf	(277)^0100h	;volatile
	line	92
	
l5344:	
;main.c: 92: IOCA = 0x00; IOCB = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l5346:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	95
	
l5348:	
;main.c: 95: CC0CON = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	96
	
l5350:	
;main.c: 96: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	103
	
l5352:	
;main.c: 103: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	104
	
l5354:	
;main.c: 104: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	105
	
l5356:	
;main.c: 105: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	106
	
l5358:	
;main.c: 106: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	109
	
l5360:	
;main.c: 109: AD_Init();
	fcall	_AD_Init
	line	113
	
l5362:	
;main.c: 113: uart_init();
	fcall	_uart_init
	line	120
;main.c: 120: OPTION_REG = 0x00;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	121
	
l5364:	
;main.c: 121: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	122
	
l5366:	
;main.c: 122: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	123
	
l5368:	
;main.c: 123: INTCON = 0xE0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	127
;main.c: 127: g_pwmDuty = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	128
;main.c: 128: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	129
	
l5370:	
;main.c: 129: RC5 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	130
	
l5372:	
;main.c: 130: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	131
	
l5374:	
;main.c: 131: RB6 = 1;
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	132
	
l5376:	
;main.c: 132: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	135
;main.c: 135: for(i = 0; i < 12; i++)
	clrf	(System_Init@i)
	line	137
	
l5382:	
;main.c: 136: {
;main.c: 137: g_slot[i].state = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	138
;main.c: 138: g_slot[i].type = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	139
;main.c: 139: g_slot[i].voltage = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	140
;main.c: 140: g_slot[i].chargeTimer = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	141
	
l5384:	
;main.c: 141: g_ccBlocks[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	142
	
l5386:	
;main.c: 142: g_ovCnt[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	135
	
l5388:	
	incf	(System_Init@i),f
	
l5390:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u7431
	goto	u7430
u7431:
	goto	l5382
u7430:
	line	146
	
l339:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
global __ptext3
__ptext3:	;psect for function _uart_init
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 4
; Regs used in _uart_init: []
	line	23
	
l3334:	
;uart_dbg.c: 23: TRISC &= (unsigned char)~0x10;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
;uart_dbg.c: 24: ANSEL2 &= (unsigned char)~0x10;
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
;uart_dbg.c: 25: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l443:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
global __ptext4
__ptext4:	;psect for function _AD_Init
psect	text4
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 4
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l3328:	
;adc_drv.c: 25: CC0CON = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
;adc_drv.c: 26: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	27
	
l3330:	
;adc_drv.c: 27: ADCON0 = 0X81;
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l3332:	
;adc_drv.c: 28: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	29
	
l420:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Slot_Charge_Ctrl

;; *************** function _Slot_Charge_Ctrl *****************
;; Defined at:
;;		line 198 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   51[BANK1 ] unsigned char 
;;  tc              1   34[BANK1 ] unsigned char 
;;  hasRise         1   28[BANK1 ] unsigned char 
;;  pre             2   43[BANK1 ] unsigned int 
;;  bat_mv_long     4    6[BANK1 ] unsigned long 
;;  vx_mv           4    2[BANK1 ] unsigned long 
;;  bat_mv          2   35[BANK1 ] unsigned int 
;;  diff            2   41[BANK1 ] int 
;;  bat_mv_long     4   22[BANK1 ] unsigned long 
;;  vx_mv           4   18[BANK1 ] unsigned long 
;;  bat_mv          2   39[BANK1 ] unsigned int 
;;  bat_mv_long     4   14[BANK1 ] unsigned long 
;;  vx_mv           4   10[BANK1 ] unsigned long 
;;  bat_mv          2   37[BANK1 ] unsigned int 
;;  v_ref           2   31[BANK1 ] unsigned int 
;;  v_init          2    0[BANK1 ] unsigned int 
;;  newv            2   29[BANK1 ] unsigned int 
;;  v               2   49[BANK1 ] unsigned int 
;;  ct              2   47[BANK1 ] unsigned int 
;;  ty              1   46[BANK1 ] unsigned char 
;;  st              1   45[BANK1 ] unsigned char 
;;  dly             1   33[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      52       0       0
;;      Temps:          0       5       0       0       0
;;      Totals:         0       5      52       0       0
;;Total ram usage:       57 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Adc_Norm
;;		_Detect_BatteryType
;;		_Get_Vcc
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___wmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	198
global __ptext5
__ptext5:	;psect for function _Slot_Charge_Ctrl
psect	text5
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	198
	global	__size_of_Slot_Charge_Ctrl
	__size_of_Slot_Charge_Ctrl	equ	__end_of_Slot_Charge_Ctrl-_Slot_Charge_Ctrl
	
_Slot_Charge_Ctrl:	
;incstack = 0
	opt	stack 3
; Regs used in _Slot_Charge_Ctrl: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
;Slot_Charge_Ctrl@idx stored from wreg
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@idx)^080h
	line	204
;charge_mgr.c: 200: unsigned char st, ty;
;charge_mgr.c: 201: unsigned int v, ct;
;charge_mgr.c: 202: unsigned char dly;
;charge_mgr.c: 204: do { st = g_slot[(idx)].state; ty = g_slot[(idx)].type; v = g_slot[(idx)].voltage; ct = g_slot[(idx)].chargeTimer; } while(0);
	
l531:	
	
l5586:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Slot_Charge_Ctrl@st)^080h
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Slot_Charge_Ctrl@ty)^080h
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Slot_Charge_Ctrl@v)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v+1)^080h
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Slot_Charge_Ctrl@ct)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@ct+1)^080h
	goto	l5590
	line	207
	
l535:	
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l5592
	
l537:	
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l5592
	
l538:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	l5592
	
l539:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	l5592
	
l540:	
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l5592
	
l541:	
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l5592
	
l542:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l5592
	
l543:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l5592
	
l544:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	l5592
	
l545:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	l5592
	
l546:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l5592
	
l547:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l5592
	
l5590:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l535
	xorlw	1^0	; case 1
	skipnz
	goto	l537
	xorlw	2^1	; case 2
	skipnz
	goto	l538
	xorlw	3^2	; case 3
	skipnz
	goto	l539
	xorlw	4^3	; case 4
	skipnz
	goto	l540
	xorlw	5^4	; case 5
	skipnz
	goto	l541
	xorlw	6^5	; case 6
	skipnz
	goto	l542
	xorlw	7^6	; case 7
	skipnz
	goto	l543
	xorlw	8^7	; case 8
	skipnz
	goto	l544
	xorlw	9^8	; case 9
	skipnz
	goto	l545
	xorlw	10^9	; case 10
	skipnz
	goto	l546
	xorlw	11^10	; case 11
	skipnz
	goto	l547
	goto	l5592
	opt asmopt_pop

	line	208
	
l5592:	
;charge_mgr.c: 208: if(st == 1 || st == 8 || st == 9)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
		decf	((Slot_Charge_Ctrl@st)^080h),w
	btfsc	status,2
	goto	u7631
	goto	u7630
u7631:
	goto	l5598
u7630:
	
l5594:	
		movlw	8
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfsc	status,2
	goto	u7641
	goto	u7640
u7641:
	goto	l5598
u7640:
	
l5596:	
		movlw	9
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfss	status,2
	goto	u7651
	goto	u7650
u7651:
	goto	l5610
u7650:
	line	211
	
l5598:	
;charge_mgr.c: 209: {
;charge_mgr.c: 211: for(dly = 0; dly < 20; dly++)
	clrf	(Slot_Charge_Ctrl@dly)^080h
	
l5600:	
	movlw	low(014h)
	subwf	(Slot_Charge_Ctrl@dly)^080h,w
	skipc
	goto	u7661
	goto	u7660
u7661:
	goto	l5604
u7660:
	goto	l5612
	line	212
	
l5604:	
;charge_mgr.c: 212: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u10397:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u10397
	nop
opt asmopt_pop

	line	211
	
l5606:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(Slot_Charge_Ctrl@dly)^080h,f
	goto	l5600
	line	216
	
l5610:	
;charge_mgr.c: 214: else
;charge_mgr.c: 215: {
;charge_mgr.c: 216: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u10407:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u10407
	nop
opt asmopt_pop

	line	220
	
l5612:	
;charge_mgr.c: 217: }
;charge_mgr.c: 219: {
;charge_mgr.c: 220: unsigned int newv = Adc_Norm(s_adcChannels[idx]);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	fcall	_Adc_Norm
	movf	(1+(?_Adc_Norm)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@newv+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?_Adc_Norm)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@newv)^080h
	line	224
	
l5614:	
;charge_mgr.c: 222: if(!(ty == 6 &&
;charge_mgr.c: 223: (st == 4 || st == 5) &&
;charge_mgr.c: 224: newv >= 4090))
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u7671
	goto	u7670
u7671:
	goto	l5622
u7670:
	
l5616:	
		movlw	4
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfsc	status,2
	goto	u7681
	goto	u7680
u7681:
	goto	l5620
u7680:
	
l5618:	
		movlw	5
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfss	status,2
	goto	u7691
	goto	u7690
u7691:
	goto	l5622
u7690:
	
l5620:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@newv+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@newv)^080h,w
	skipnc
	goto	u7701
	goto	u7700
u7701:
	goto	l6518
u7700:
	line	226
	
l5622:	
;charge_mgr.c: 225: {
;charge_mgr.c: 226: v = newv;
	movf	(Slot_Charge_Ctrl@newv+1)^080h,w
	movwf	(Slot_Charge_Ctrl@v+1)^080h
	movf	(Slot_Charge_Ctrl@newv)^080h,w
	movwf	(Slot_Charge_Ctrl@v)^080h
	goto	l6518
	line	237
	
l5624:	
;charge_mgr.c: 237: if(v >= 4090)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u7711
	goto	u7710
u7711:
	goto	l5630
u7710:
	line	239
	
l5626:	
;charge_mgr.c: 238: {
;charge_mgr.c: 239: if(ct < ((unsigned long)(24) * 16))
	movlw	01h
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	080h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipnc
	goto	u7721
	goto	u7720
u7721:
	goto	l5630
u7720:
	line	241
	
l5628:	
;charge_mgr.c: 240: {
;charge_mgr.c: 241: ct++;
	incf	(Slot_Charge_Ctrl@ct)^080h,f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	242
;charge_mgr.c: 242: break;
	goto	l6520
	line	245
	
l5630:	
;charge_mgr.c: 243: }
;charge_mgr.c: 244: }
;charge_mgr.c: 245: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	246
	
l5632:	
;charge_mgr.c: 246: st = 1;
	clrf	(Slot_Charge_Ctrl@st)^080h
	incf	(Slot_Charge_Ctrl@st)^080h,f
	line	247
	
l5634:	
;charge_mgr.c: 247: g_ccBlocks[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	249
	
l5636:	
;charge_mgr.c: 249: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7734
u7735:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7734:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7735
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	252
	
l5638:	
;charge_mgr.c: 252: if(v < 4090)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u7741
	goto	u7740
u7741:
	goto	l5642
u7740:
	line	253
	
l5640:	
;charge_mgr.c: 253: g_slotRefV[idx] = v;
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	goto	l6520
	line	255
	
l5642:	
;charge_mgr.c: 254: else
;charge_mgr.c: 255: g_slotRefV[idx] = 0;
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l6520
	line	259
	
l5644:	
;charge_mgr.c: 259: ct++;
	incf	(Slot_Charge_Ctrl@ct)^080h,f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	262
	
l5646:	
;charge_mgr.c: 262: if(ct == 1)
		decf	((Slot_Charge_Ctrl@ct)^080h),w
iorwf	((Slot_Charge_Ctrl@ct+1)^080h),w
	btfss	status,2
	goto	u7751
	goto	u7750
u7751:
	goto	l5652
u7750:
	line	264
	
l5648:	
;charge_mgr.c: 263: {
;charge_mgr.c: 264: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	265
	
l5650:	
;charge_mgr.c: 265: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7764
u7765:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7764:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7765
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	268
	
l5652:	
;charge_mgr.c: 266: }
;charge_mgr.c: 268: if(ct < ((unsigned long)(2) * 16))
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	020h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipnc
	goto	u7771
	goto	u7770
u7771:
	goto	l5656
u7770:
	goto	l6520
	line	286
	
l5656:	
;charge_mgr.c: 278: }
;charge_mgr.c: 286: if(ct == ((unsigned long)(2) * 16))
		movlw	32
	xorwf	((Slot_Charge_Ctrl@ct)^080h),w
iorwf	((Slot_Charge_Ctrl@ct+1)^080h),w
	btfss	status,2
	goto	u7781
	goto	u7780
u7781:
	goto	l5664
u7780:
	line	288
	
l5658:	
;charge_mgr.c: 287: {
;charge_mgr.c: 288: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	line	289
	
l5660:	
;charge_mgr.c: 289: if(v > 2900)
	movlw	0Bh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	055h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u7791
	goto	u7790
u7791:
	goto	l6520
u7790:
	line	290
	
l5662:	
;charge_mgr.c: 290: g_capFlag |= (unsigned int)1 << idx;
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7804
u7805:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7804:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7805
	
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag+1)^080h,f
	goto	l6520
	line	293
	
l5664:	
;charge_mgr.c: 292: }
;charge_mgr.c: 293: if(v > 2900 && v < 4090)
	movlw	0Bh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	055h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u7811
	goto	u7810
u7811:
	goto	l5726
u7810:
	
l5666:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u7821
	goto	u7820
u7821:
	goto	l5726
u7820:
	line	305
	
l5668:	
;charge_mgr.c: 294: {
;charge_mgr.c: 304: if(!(g_capFlag & ((unsigned int)1 << idx)) && ty != 5 &&
;charge_mgr.c: 305: v <= 3500)
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7834
u7835:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7834:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7835
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfss	status,2
	goto	u7841
	goto	u7840
u7841:
	goto	l5682
u7840:
	
l5670:	
		movlw	5
	bsf	status, 5	;RP0=1, select bank1
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u7851
	goto	u7850
u7851:
	goto	l5682
u7850:
	
l5672:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0ADh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u7861
	goto	u7860
u7861:
	goto	l5682
u7860:
	line	307
	
l5674:	
;charge_mgr.c: 306: {
;charge_mgr.c: 307: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	308
	
l5676:	
;charge_mgr.c: 308: g_slotRefV[idx] = 0;
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	309
	
l5678:	
;charge_mgr.c: 309: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	310
	
l5680:	
;charge_mgr.c: 310: g_detectLowCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	311
;charge_mgr.c: 311: break;
	goto	l6520
	line	321
	
l5682:	
;charge_mgr.c: 312: }
;charge_mgr.c: 321: unsigned int v_init = g_slotRefV[idx];
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_init)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_init+1)^080h
	line	323
;charge_mgr.c: 323: if(g_stableCnt[idx] >= 20)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipc
	goto	u7871
	goto	u7870
u7871:
	goto	l5712
u7870:
	line	328
	
l5684:	
;charge_mgr.c: 324: {
;charge_mgr.c: 328: g_highVFlag |= (unsigned int)1 << idx;
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7884
u7885:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7884:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7885
	
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag+1)^080h,f
	line	330
	
l5686:	
;charge_mgr.c: 330: if(v <= 2900)
	movlw	0Bh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	055h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u7891
	goto	u7890
u7891:
	goto	l5694
u7890:
	line	333
	
l5688:	
;charge_mgr.c: 331: {
;charge_mgr.c: 333: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7904
u7905:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7904:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7905
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	334
	
l5690:	
;charge_mgr.c: 334: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	335
	
l5692:	
;charge_mgr.c: 335: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7914
u7915:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7914:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7915
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	336
;charge_mgr.c: 336: }
	goto	l5738
	line	337
	
l5694:	
;charge_mgr.c: 337: else if(ct < ((unsigned long)(2) * 16) + ((unsigned long)(8) * 16))
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	0A0h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipnc
	goto	u7921
	goto	u7920
u7921:
	goto	l5706
u7920:
	line	346
	
l5696:	
;charge_mgr.c: 338: {
;charge_mgr.c: 345: if((g_highVFlag & ((unsigned int)1 << idx)) &&
;charge_mgr.c: 346: ct >= ((unsigned long)(2) * 16) + 25U)
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7934
u7935:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7934:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7935
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u7941
	goto	u7940
u7941:
	goto	l5640
u7940:
	
l5698:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	039h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u7951
	goto	u7950
u7951:
	goto	l5640
u7950:
	line	359
	
l5706:	
;charge_mgr.c: 359: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7964
u7965:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7964:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7965
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	360
	
l5708:	
;charge_mgr.c: 360: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	361
	
l5710:	
;charge_mgr.c: 361: ty = 5;
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@ty)^080h
	line	362
;charge_mgr.c: 362: goto amb_check;
	goto	l5768
	line	368
	
l5712:	
;charge_mgr.c: 365: else
;charge_mgr.c: 366: {
;charge_mgr.c: 368: if(v + 50 < v_init)
	movf	(Slot_Charge_Ctrl@v)^080h,w
	addlw	low(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v_init+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u7975
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v_init)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u7975:
	skipnc
	goto	u7971
	goto	u7970
u7971:
	goto	l5716
u7970:
	line	371
	
l5714:	
;charge_mgr.c: 369: {
;charge_mgr.c: 371: g_slotRefV[idx] = v;
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	line	372
;charge_mgr.c: 372: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	373
;charge_mgr.c: 373: }
	goto	l584
	line	377
	
l5716:	
;charge_mgr.c: 374: else
;charge_mgr.c: 375: {
;charge_mgr.c: 377: g_slotRefV[idx] = v;
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	line	378
;charge_mgr.c: 378: g_stableCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	379
	
l584:	
	line	380
;charge_mgr.c: 379: }
;charge_mgr.c: 380: if(g_stableCnt[idx] < 20)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u7981
	goto	u7980
u7981:
	goto	l5720
u7980:
	goto	l6520
	line	383
	
l5720:	
;charge_mgr.c: 383: if(g_capFlag & ((unsigned int)1 << idx))
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u7994
u7995:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u7994:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7995
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u8001
	goto	u8000
u8001:
	goto	l5724
u8000:
	goto	l6520
	line	385
	
l5724:	
;charge_mgr.c: 385: g_stableCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l5738
	line	388
	
l5726:	
;charge_mgr.c: 388: else if(ct < ((unsigned long)(2) * 16) + ((unsigned long)(8) * 16) && v < 4090)
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	0A0h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipnc
	goto	u8011
	goto	u8010
u8011:
	goto	l5738
u8010:
	
l5728:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u8021
	goto	u8020
u8021:
	goto	l5738
u8020:
	line	390
	
l5730:	
;charge_mgr.c: 389: {
;charge_mgr.c: 390: unsigned int v_ref = g_slotRefV[idx];
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_ref)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_ref+1)^080h
	line	391
	
l5732:	
;charge_mgr.c: 391: if(v_ref < 4090 && v + 50 < v_ref)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v_ref+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v_ref)^080h,w
	skipnc
	goto	u8031
	goto	u8030
u8031:
	goto	l5738
u8030:
	
l5734:	
	movf	(Slot_Charge_Ctrl@v)^080h,w
	addlw	low(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v_ref+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8045
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v_ref)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8045:
	skipnc
	goto	u8041
	goto	u8040
u8041:
	goto	l5738
u8040:
	goto	l5640
	line	401
	
l5738:	
;charge_mgr.c: 395: }
;charge_mgr.c: 396: }
;charge_mgr.c: 401: if(g_capFlag & ((unsigned int)1 << idx))
	bsf	status, 5	;RP0=1, select bank1
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8054
u8055:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8054:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8055
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u8061
	goto	u8060
u8061:
	goto	l5746
u8060:
	line	403
	
l5740:	
;charge_mgr.c: 402: {
;charge_mgr.c: 403: g_capFlag &= ~((unsigned int)1 << idx);
	bsf	status, 5	;RP0=1, select bank1
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8074
u8075:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8074:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8075
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	404
	
l5742:	
;charge_mgr.c: 404: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	405
	
l5744:	
;charge_mgr.c: 405: ty = 5;
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@ty)^080h
	line	406
;charge_mgr.c: 406: }
	goto	l591
	line	409
	
l5746:	
;charge_mgr.c: 407: else
;charge_mgr.c: 408: {
;charge_mgr.c: 409: ty = Detect_BatteryType(v);
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	(Detect_BatteryType@voltage+1)
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	movwf	(Slot_Charge_Ctrl@ty)^080h
	line	417
	
l5748:	
;charge_mgr.c: 416: if(ty == 0 && v >= 4090 &&
;charge_mgr.c: 417: ct >= ((unsigned long)(2) * 16) + ((unsigned long)(8) * 16))
	movf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u8081
	goto	u8080
u8081:
	goto	l591
u8080:
	
l5750:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8091
	goto	u8090
u8091:
	goto	l591
u8090:
	
l5752:	
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	0A0h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u8101
	goto	u8100
u8101:
	goto	l591
u8100:
	goto	l5744
	line	419
	
l591:	
	line	423
;charge_mgr.c: 419: }
;charge_mgr.c: 423: if(v < 500)
	movlw	01h
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0F4h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u8111
	goto	u8110
u8111:
	goto	l5760
u8110:
	line	425
	
l5756:	
;charge_mgr.c: 424: {
;charge_mgr.c: 425: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	426
;charge_mgr.c: 426: if(g_detectLowCnt[idx] < 5)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u8121
	goto	u8120
u8121:
	goto	l5768
u8120:
	goto	l6520
	line	430
	
l5760:	
;charge_mgr.c: 430: else if(ty != 5 && ty != 1 && ty != 6)
		movlw	5
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u8131
	goto	u8130
u8131:
	goto	l5768
u8130:
	
l5762:	
		decf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u8141
	goto	u8140
u8141:
	goto	l5768
u8140:
	
l5764:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u8151
	goto	u8150
u8151:
	goto	l5768
u8150:
	line	432
	
l5766:	
;charge_mgr.c: 431: {
;charge_mgr.c: 432: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	436
	
l5768:	
;charge_mgr.c: 436: if(ty == 5)
		movlw	5
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u8161
	goto	u8160
u8161:
	goto	l5790
u8160:
	line	443
	
l5770:	
;charge_mgr.c: 437: {
;charge_mgr.c: 443: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	444
;charge_mgr.c: 444: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8171
	goto	u8170
u8171:
	goto	l5774
u8170:
	goto	l6520
	line	448
	
l5774:	
;charge_mgr.c: 448: if(g_impCheckSlot != 0xFF && g_impCheckSlot != idx)
	bcf	status, 5	;RP0=0, select bank0
		incf	((_g_impCheckSlot)),w
	btfsc	status,2
	goto	u8181
	goto	u8180
u8181:
	goto	l5780
u8180:
	
l5776:	
	movf	(_g_impCheckSlot),w
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(Slot_Charge_Ctrl@idx)^080h,w
	skipnz
	goto	u8191
	goto	u8190
u8191:
	goto	l5780
u8190:
	goto	l6520
	line	450
	
l5780:	
;charge_mgr.c: 450: g_impCheckSlot = idx;
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_impCheckSlot)
	line	454
	
l5782:	
;charge_mgr.c: 454: Get_Vcc();
	fcall	_Get_Vcc
	line	458
	
l5784:	
;charge_mgr.c: 458: g_impData = v | ((unsigned int)(((g_vcc_mv + 50U) / 100U) - 38U) << 12);
	movlw	064h
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(032h)
	movwf	(___lwdiv@dividend)
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(_g_impData+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_g_impData)
	movlw	0Ch
	
u8205:
	clrc
	rlf	(_g_impData),f
	rlf	(_g_impData+1),f
	addlw	-1
	skipz
	goto	u8205
	movlw	(0A000h >> 8)
	addwf	(_g_impData+1),f
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(_g_impData),f
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(_g_impData+1),f
	line	459
;charge_mgr.c: 459: st = 8;
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	460
	
l5786:	
;charge_mgr.c: 460: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	461
	
l5788:	
;charge_mgr.c: 461: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	463
	
l5790:	
;charge_mgr.c: 462: }
;charge_mgr.c: 463: if(ty == 1 || ty == 6)
		decf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u8211
	goto	u8210
u8211:
	goto	l5794
u8210:
	
l5792:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u8221
	goto	u8220
u8221:
	goto	l5844
u8220:
	line	466
	
l5794:	
;charge_mgr.c: 464: {
;charge_mgr.c: 466: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	467
;charge_mgr.c: 467: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8231
	goto	u8230
u8231:
	goto	l5798
u8230:
	goto	l6520
	line	469
	
l5798:	
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	(___lmul@multiplier)
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@vx_mv+3)^080h
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv+2)^080h
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv+1)^080h
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv)^080h

	
l5800:	
	movlw	0Ch
u8245:
	clrc
	rrf	(Slot_Charge_Ctrl@vx_mv+3)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv+2)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv+1)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u8245

	
l5802:	
	movf	(Slot_Charge_Ctrl@vx_mv+3)^080h,w
	movwf	(___lmul@multiplier+3)
	movf	(Slot_Charge_Ctrl@vx_mv+2)^080h,w
	movwf	(___lmul@multiplier+2)
	movf	(Slot_Charge_Ctrl@vx_mv+1)^080h,w
	movwf	(___lmul@multiplier+1)
	movf	(Slot_Charge_Ctrl@vx_mv)^080h,w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv_long+3)^080h
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long+2)^080h
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long+1)^080h
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long)^080h

	
l5804:	
	movlw	070h
	addwf	(Slot_Charge_Ctrl@bat_mv_long)^080h,f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Slot_Charge_Ctrl@bat_mv_long+1)^080h,f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Slot_Charge_Ctrl@bat_mv_long+2)^080h,f
	movlw	0
	skipnc
movlw 1
	addwf	(Slot_Charge_Ctrl@bat_mv_long+3)^080h,f
	
l5806:	
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Slot_Charge_Ctrl+0)+0)
	movlw	01h
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+2)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+0,f
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long+1)^080h,w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long+1)^080h,w
	goto	u8250
	goto	u8251
u8250:
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+1,f
u8251:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long+2)^080h,w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long+2)^080h,w
	goto	u8252
	goto	u8253
u8252:
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+2,f
u8253:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long+3)^080h,w
	skipnc
	incf	(Slot_Charge_Ctrl@bat_mv_long+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+3,f
	movf	3+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv)^080h
	
l5808:	
	movlw	0
	subwf	(Slot_Charge_Ctrl@bat_mv+1)^080h,w
	movlw	065h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv)^080h,w
	skipnc
	goto	u8261
	goto	u8260
u8261:
	goto	l5812
u8260:
	
l5810:	
	movlw	low(02h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	goto	l5838
	
l5812:	
	movlw	03h
	subwf	(Slot_Charge_Ctrl@bat_mv+1)^080h,w
	movlw	084h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv)^080h,w
	skipnc
	goto	u8271
	goto	u8270
u8271:
	goto	l5816
u8270:
	
l5814:	
	movlw	low(03h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	goto	l5838
	
l5816:	
	movlw	05h
	subwf	(Slot_Charge_Ctrl@bat_mv+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv)^080h,w
	skipc
	goto	u8281
	goto	u8280
u8281:
	goto	l5830
u8280:
	
l5818:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u8291
	goto	u8290
u8291:
	goto	l5822
u8290:
	
l5820:	
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	goto	l5838
	
l5822:	
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	
l5824:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	
l5826:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l5828:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l5838
	
l5830:	
	movlw	low(04h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	
l5832:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(080h)
	bsf	status, 7	;select IRP bank3
	andwf	indf,f
	
l5834:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	goto	l5828
	
l5838:	
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	
l5840:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l5680
	line	471
	
l5844:	
;charge_mgr.c: 471: else if(ty == 0)
	movf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u8301
	goto	u8300
u8301:
	goto	l5854
u8300:
	line	476
	
l5846:	
;charge_mgr.c: 472: {
;charge_mgr.c: 476: if(v >= 4090)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8311
	goto	u8310
u8311:
	goto	l5850
u8310:
	goto	l6520
	line	478
	
l5850:	
;charge_mgr.c: 478: st = 7;
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	goto	l5680
	line	481
	
l5854:	
;charge_mgr.c: 481: else if(ty == 2 || ty == 3)
		movlw	2
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u8321
	goto	u8320
u8321:
	goto	l5850
u8320:
	
l5856:	
		movlw	3
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u8331
	goto	u8330
u8331:
	goto	l6520
u8330:
	goto	l5850
	line	489
	
l5862:	
;charge_mgr.c: 489: ct++;
	incf	(Slot_Charge_Ctrl@ct)^080h,f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	490
	
l5864:	
;charge_mgr.c: 490: if(ct < 5)
	movlw	0
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	05h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipnc
	goto	u8341
	goto	u8340
u8341:
	goto	l5868
u8340:
	goto	l6520
	line	495
	
l5868:	
;charge_mgr.c: 493: {
;charge_mgr.c: 495: Get_Vcc();
	fcall	_Get_Vcc
	line	501
	
l5870:	
;charge_mgr.c: 501: if(v >= 4050U && (g_impData & 0x0FFFU) >= 4050U)
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0D2h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8351
	goto	u8350
u8351:
	goto	l5880
u8350:
	
l5872:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0D2h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u8361
	goto	u8360
u8361:
	goto	l5880
u8360:
	line	503
	
l5874:	
;charge_mgr.c: 502: {
;charge_mgr.c: 503: ty = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(Slot_Charge_Ctrl@ty)^080h
	line	504
;charge_mgr.c: 504: st = 0;
	clrf	(Slot_Charge_Ctrl@st)^080h
	line	505
	
l5876:	
;charge_mgr.c: 505: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_impCheckSlot)
	line	506
	
l5878:	
;charge_mgr.c: 506: g_highVFlag &= ~((unsigned int)1 << idx);
	bsf	status, 5	;RP0=1, select bank1
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8374
u8375:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8374:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8375
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	507
;charge_mgr.c: 507: break;
	goto	l6520
	line	513
	
l5880:	
;charge_mgr.c: 508: }
;charge_mgr.c: 513: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 300U && v >= 4090)
	bcf	status, 5	;RP0=0, select bank0
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(012Ch)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(012Ch)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8385
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8385:
	skipnc
	goto	u8381
	goto	u8380
u8381:
	goto	l5888
u8380:
	
l5882:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8391
	goto	u8390
u8391:
	goto	l5888
u8390:
	line	515
	
l5884:	
;charge_mgr.c: 514: {
;charge_mgr.c: 515: ty = 2;
	movlw	low(02h)
	movwf	(Slot_Charge_Ctrl@ty)^080h
	line	516
;charge_mgr.c: 516: st = 7;
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	517
;charge_mgr.c: 517: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_impCheckSlot)
	goto	l5878
	line	528
	
l5888:	
;charge_mgr.c: 520: }
;charge_mgr.c: 527: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 200U &&
;charge_mgr.c: 528: (g_impData & 0x0FFFU) < 3100U)
	bcf	status, 5	;RP0=0, select bank0
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(0C8h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8405
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8405:
	skipnc
	goto	u8401
	goto	u8400
u8401:
	goto	l5894
u8400:
	
l5890:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Ch
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	01Ch
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u8411
	goto	u8410
u8411:
	goto	l5894
u8410:
	goto	l5924
	line	539
	
l5894:	
;charge_mgr.c: 537: if(!(g_highVFlag & ((unsigned int)1 << idx)) &&
;charge_mgr.c: 538: ((g_impData & 0x0FFFU) > v) &&
;charge_mgr.c: 539: ((g_impData & 0x0FFFU) - v) > 1000U)
	bsf	status, 5	;RP0=1, select bank1
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8424
u8425:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8424:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8425
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfss	status,2
	goto	u8431
	goto	u8430
u8431:
	goto	l5906
u8430:
	
l5896:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipz
	goto	u8445
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v)^080h,w
u8445:
	skipnc
	goto	u8441
	goto	u8440
u8441:
	goto	l5906
u8440:
	
l5898:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipc
	incf	(Slot_Charge_Ctrl@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	03h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0E9h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipc
	goto	u8451
	goto	u8450
u8451:
	goto	l5906
u8450:
	line	541
	
l5900:	
;charge_mgr.c: 540: {
;charge_mgr.c: 541: ty = 3;
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@ty)^080h
	line	542
;charge_mgr.c: 542: st = 7;
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	543
;charge_mgr.c: 543: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_impCheckSlot)
	line	544
	
l5902:	
;charge_mgr.c: 544: g_highVFlag &= ~((unsigned int)1 << idx);
	bsf	status, 5	;RP0=1, select bank1
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8464
u8465:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8464:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8465
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	goto	l5680
	line	553
	
l5906:	
;charge_mgr.c: 547: }
;charge_mgr.c: 552: if(((g_impData & 0x0FFFU) > 3500) &&
;charge_mgr.c: 553: ((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) <= g_vcc_mv + 200U))
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Dh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0ADh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u8471
	goto	u8470
u8471:
	goto	l5912
u8470:
	
l5908:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(0C8h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8485
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8485:
	skipc
	goto	u8481
	goto	u8480
u8481:
	goto	l5912
u8480:
	goto	l5916
	line	560
	
l5912:	
	line	566
	
l5916:	
;charge_mgr.c: 566: st = 9;
	movlw	low(09h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	567
	
l5918:	
;charge_mgr.c: 567: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	568
	
l5920:	
;charge_mgr.c: 568: g_diodeTraceCnt = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_diodeTraceCnt)
	line	569
;charge_mgr.c: 569: g_diodeTraceSlot = (unsigned char)idx;
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_diodeTraceSlot)
	goto	l5878
	line	576
	
l5924:	
;charge_mgr.c: 576: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)
	line	577
	
l5926:	
;charge_mgr.c: 577: g_highVFlag &= ~((unsigned int)1 << idx);
	bsf	status, 5	;RP0=1, select bank1
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8494
u8495:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8494:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8495
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	578
	
l5928:	
;charge_mgr.c: 578: ty = 1;
	clrf	(Slot_Charge_Ctrl@ty)^080h
	incf	(Slot_Charge_Ctrl@ty)^080h,f
	line	579
	
l5930:	
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	(___lmul@multiplier)
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@vx_mv_376+3)^080h
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv_376+2)^080h
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv_376+1)^080h
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv_376)^080h

	
l5932:	
	movlw	0Ch
u8505:
	clrc
	rrf	(Slot_Charge_Ctrl@vx_mv_376+3)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv_376+2)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv_376+1)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv_376)^080h,f
	addlw	-1
	skipz
	goto	u8505

	
l5934:	
	movf	(Slot_Charge_Ctrl@vx_mv_376+3)^080h,w
	movwf	(___lmul@multiplier+3)
	movf	(Slot_Charge_Ctrl@vx_mv_376+2)^080h,w
	movwf	(___lmul@multiplier+2)
	movf	(Slot_Charge_Ctrl@vx_mv_376+1)^080h,w
	movwf	(___lmul@multiplier+1)
	movf	(Slot_Charge_Ctrl@vx_mv_376)^080h,w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv_long_377+3)^080h
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long_377+2)^080h
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long_377+1)^080h
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long_377)^080h

	movlw	070h
	addwf	(Slot_Charge_Ctrl@bat_mv_long_377)^080h,f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Slot_Charge_Ctrl@bat_mv_long_377+1)^080h,f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Slot_Charge_Ctrl@bat_mv_long_377+2)^080h,f
	movlw	0
	skipnc
movlw 1
	addwf	(Slot_Charge_Ctrl@bat_mv_long_377+3)^080h,f
	
l5936:	
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Slot_Charge_Ctrl+0)+0)
	movlw	01h
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+2)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long_377)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+0,f
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long_377+1)^080h,w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long_377+1)^080h,w
	goto	u8510
	goto	u8511
u8510:
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+1,f
u8511:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long_377+2)^080h,w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long_377+2)^080h,w
	goto	u8512
	goto	u8513
u8512:
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+2,f
u8513:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long_377+3)^080h,w
	skipnc
	incf	(Slot_Charge_Ctrl@bat_mv_long_377+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+3,f
	movf	3+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv_378+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv_378)^080h
	
l5938:	
	movlw	0
	subwf	(Slot_Charge_Ctrl@bat_mv_378+1)^080h,w
	movlw	065h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv_378)^080h,w
	skipnc
	goto	u8521
	goto	u8520
u8521:
	goto	l5942
u8520:
	goto	l5810
	
l5942:	
	movlw	03h
	subwf	(Slot_Charge_Ctrl@bat_mv_378+1)^080h,w
	movlw	084h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv_378)^080h,w
	skipnc
	goto	u8531
	goto	u8530
u8531:
	goto	l5946
u8530:
	goto	l5814
	
l5946:	
	movlw	05h
	subwf	(Slot_Charge_Ctrl@bat_mv_378+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv_378)^080h,w
	skipc
	goto	u8541
	goto	u8540
u8541:
	goto	l5830
u8540:
	
l5948:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u8551
	goto	u8550
u8551:
	goto	l5822
u8550:
	goto	l5820
	line	590
	
l5974:	
;charge_mgr.c: 590: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_impCheckSlot)
	line	591
	
l5976:	
;charge_mgr.c: 591: g_highVFlag &= ~((unsigned int)1 << idx);
	bsf	status, 5	;RP0=1, select bank1
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8564
u8565:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8564:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8565
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	592
	
l5978:	
;charge_mgr.c: 592: ty = 6;
	movlw	low(06h)
	movwf	(Slot_Charge_Ctrl@ty)^080h
	line	593
	
l5980:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(___lmul@multiplier)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(___lmul@multiplier)
	clrf	2+(___lmul@multiplier)
	clrf	3+(___lmul@multiplier)
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@vx_mv_379+3)^080h
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv_379+2)^080h
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv_379+1)^080h
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@vx_mv_379)^080h

	
l5982:	
	movlw	0Ch
u8575:
	clrc
	rrf	(Slot_Charge_Ctrl@vx_mv_379+3)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv_379+2)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv_379+1)^080h,f
	rrf	(Slot_Charge_Ctrl@vx_mv_379)^080h,f
	addlw	-1
	skipz
	goto	u8575

	movf	(Slot_Charge_Ctrl@vx_mv_379+3)^080h,w
	movwf	(___lmul@multiplier+3)
	movf	(Slot_Charge_Ctrl@vx_mv_379+2)^080h,w
	movwf	(___lmul@multiplier+2)
	movf	(Slot_Charge_Ctrl@vx_mv_379+1)^080h,w
	movwf	(___lmul@multiplier+1)
	movf	(Slot_Charge_Ctrl@vx_mv_379)^080h,w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv_long_380+3)^080h
	movf	(2+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long_380+2)^080h
	movf	(1+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long_380+1)^080h
	movf	(0+(?___lmul)),w
	movwf	(Slot_Charge_Ctrl@bat_mv_long_380)^080h

	
l5984:	
	movlw	070h
	addwf	(Slot_Charge_Ctrl@bat_mv_long_380)^080h,f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Slot_Charge_Ctrl@bat_mv_long_380+1)^080h,f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Slot_Charge_Ctrl@bat_mv_long_380+2)^080h,f
	movlw	0
	skipnc
movlw 1
	addwf	(Slot_Charge_Ctrl@bat_mv_long_380+3)^080h,f
	
l5986:	
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Slot_Charge_Ctrl+0)+0)
	movlw	01h
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+2)
	movlw	0
	movwf	((??_Slot_Charge_Ctrl+0)+0+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long_380)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+0,f
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long_380+1)^080h,w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long_380+1)^080h,w
	goto	u8580
	goto	u8581
u8580:
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+1,f
u8581:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long_380+2)^080h,w
	skipnc
	incfsz	(Slot_Charge_Ctrl@bat_mv_long_380+2)^080h,w
	goto	u8582
	goto	u8583
u8582:
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+2,f
u8583:
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@bat_mv_long_380+3)^080h,w
	skipnc
	incf	(Slot_Charge_Ctrl@bat_mv_long_380+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(??_Slot_Charge_Ctrl+0)+3,f
	movf	3+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv_381+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@bat_mv_381)^080h
	movlw	0
	subwf	(Slot_Charge_Ctrl@bat_mv_381+1)^080h,w
	movlw	065h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv_381)^080h,w
	skipnc
	goto	u8591
	goto	u8590
u8591:
	goto	l5990
u8590:
	goto	l5810
	
l5990:	
	movlw	03h
	subwf	(Slot_Charge_Ctrl@bat_mv_381+1)^080h,w
	movlw	084h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv_381)^080h,w
	skipnc
	goto	u8601
	goto	u8600
u8601:
	goto	l5994
u8600:
	goto	l5814
	
l5994:	
	movlw	05h
	subwf	(Slot_Charge_Ctrl@bat_mv_381+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@bat_mv_381)^080h,w
	skipc
	goto	u8611
	goto	u8610
u8611:
	goto	l6008
u8610:
	
l5996:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u8621
	goto	u8620
u8621:
	goto	l6000
u8620:
	goto	l5820
	
l6000:	
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	
l6002:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	indf
	goto	l5826
	
l6008:	
	movlw	low(04h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	
l6010:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(080h)
	bsf	status, 7	;select IRP bank3
	andwf	indf,f
	
l6012:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	indf
	goto	l5828
	line	603
	
l6022:	
;charge_mgr.c: 603: ct++;
	incf	(Slot_Charge_Ctrl@ct)^080h,f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	609
	
l6024:	
;charge_mgr.c: 608: if((ct == 7U || ct == 14U || ct == 21U || ct == 28U) &&
;charge_mgr.c: 609: g_diodeTraceCnt < 4U)
		movlw	7
	xorwf	((Slot_Charge_Ctrl@ct)^080h),w
iorwf	((Slot_Charge_Ctrl@ct+1)^080h),w
	btfsc	status,2
	goto	u8631
	goto	u8630
u8631:
	goto	l6032
u8630:
	
l6026:	
		movlw	14
	xorwf	((Slot_Charge_Ctrl@ct)^080h),w
iorwf	((Slot_Charge_Ctrl@ct+1)^080h),w
	btfsc	status,2
	goto	u8641
	goto	u8640
u8641:
	goto	l6032
u8640:
	
l6028:	
		movlw	21
	xorwf	((Slot_Charge_Ctrl@ct)^080h),w
iorwf	((Slot_Charge_Ctrl@ct+1)^080h),w
	btfsc	status,2
	goto	u8651
	goto	u8650
u8651:
	goto	l6032
u8650:
	
l6030:	
		movlw	28
	xorwf	((Slot_Charge_Ctrl@ct)^080h),w
iorwf	((Slot_Charge_Ctrl@ct+1)^080h),w
	btfss	status,2
	goto	u8661
	goto	u8660
u8661:
	goto	l6048
u8660:
	
l6032:	
	movlw	low(04h)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_g_diodeTraceCnt),w
	skipnc
	goto	u8671
	goto	u8670
u8671:
	goto	l6048
u8670:
	line	611
	
l6034:	
;charge_mgr.c: 610: {
;charge_mgr.c: 611: signed int diff = (signed int)v - (signed int)(g_impData & 0x0FFFU);
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	(Slot_Charge_Ctrl@diff+1)^080h
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	(Slot_Charge_Ctrl@diff)^080h
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@diff)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	skipc
	decf	(Slot_Charge_Ctrl@diff+1)^080h,f
	subwf	(Slot_Charge_Ctrl@diff+1)^080h,f
	line	612
;charge_mgr.c: 612: diff >>= 2;
	rlf	(Slot_Charge_Ctrl@diff+1)^080h,w
	rrf	(Slot_Charge_Ctrl@diff+1)^080h,f
	rrf	(Slot_Charge_Ctrl@diff)^080h,f
	rlf	(Slot_Charge_Ctrl@diff+1)^080h,w
	rrf	(Slot_Charge_Ctrl@diff+1)^080h,f
	rrf	(Slot_Charge_Ctrl@diff)^080h,f
	line	613
	
l6036:	
;charge_mgr.c: 613: if(diff > 127) diff = 127;
	movf	(Slot_Charge_Ctrl@diff+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u8685
	movlw	080h
	subwf	(Slot_Charge_Ctrl@diff)^080h,w
u8685:

	skipc
	goto	u8681
	goto	u8680
u8681:
	goto	l6040
u8680:
	
l6038:	
	movlw	07Fh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Slot_Charge_Ctrl@diff)^080h
	clrf	(Slot_Charge_Ctrl@diff+1)^080h
	line	614
	
l6040:	
;charge_mgr.c: 614: if(diff < -128) diff = -128;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Slot_Charge_Ctrl@diff+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u8695
	movlw	080h
	subwf	(Slot_Charge_Ctrl@diff)^080h,w
u8695:

	skipnc
	goto	u8691
	goto	u8690
u8691:
	goto	l6044
u8690:
	
l6042:	
	movlw	080h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Slot_Charge_Ctrl@diff)^080h
	movlw	0FFh
	movwf	((Slot_Charge_Ctrl@diff)^080h)+1
	line	615
	
l6044:	
;charge_mgr.c: 615: g_diodeTrace[g_diodeTraceCnt++] = (unsigned char)(diff + 128);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_diodeTraceCnt),w
	addlw	low(_g_diodeTrace|((0x0)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@diff)^080h,w
	addlw	080h
	bcf	status, 7	;select IRP bank0
	movwf	indf
	
l6046:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(_g_diodeTraceCnt),f
	goto	l6052
	line	619
	
l6048:	
	line	625
	
l6052:	
;charge_mgr.c: 622: }
;charge_mgr.c: 625: if(v > (g_impData & 0x0FFFU) + 900)
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(0384h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(0384h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u8705
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u8705:
	skipnc
	goto	u8701
	goto	u8700
u8701:
	goto	l6060
u8700:
	line	629
	
l6054:	
;charge_mgr.c: 626: {
;charge_mgr.c: 629: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150U)
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8715
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8715:
	skipnc
	goto	u8711
	goto	u8710
u8711:
	goto	l5974
u8710:
	goto	l5924
	line	646
	
l6060:	
;charge_mgr.c: 633: }
;charge_mgr.c: 644: if(((g_impData & 0x0FFFU) > 3000U) &&
;charge_mgr.c: 645: (v > 2900) &&
;charge_mgr.c: 646: (v < (g_impData & 0x0FFFU)))
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Bh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0B9h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u8721
	goto	u8720
u8721:
	goto	l6068
u8720:
	
l6062:	
	movlw	0Bh
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	055h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8731
	goto	u8730
u8731:
	goto	l6068
u8730:
	
l6064:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipz
	goto	u8745
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v)^080h,w
u8745:
	skipnc
	goto	u8741
	goto	u8740
u8741:
	goto	l6068
u8740:
	goto	l5974
	line	653
	
l6068:	
;charge_mgr.c: 652: if((v > 2900) &&
;charge_mgr.c: 653: ((g_impData & 0x0FFFU) <= 2300U))
	movlw	0Bh
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	055h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8751
	goto	u8750
u8751:
	goto	l6078
u8750:
	
l6070:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u8761
	goto	u8760
u8761:
	goto	l6078
u8760:
	goto	l5900
	line	681
	
l6078:	
;charge_mgr.c: 661: }
;charge_mgr.c: 678: if(ct >= ((unsigned long)(2) * 16) && v > 2100U &&
;charge_mgr.c: 679: (g_impData & 0x0FFFU) <= 2300U &&
;charge_mgr.c: 680: v + 160U >= (g_impData & 0x0FFFU) &&
;charge_mgr.c: 681: v <= (g_impData & 0x0FFFU) + 150)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	020h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u8771
	goto	u8770
u8771:
	goto	l6090
u8770:
	
l6080:	
	movlw	08h
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	035h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8781
	goto	u8780
u8781:
	goto	l6090
u8780:
	
l6082:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u8791
	goto	u8790
u8791:
	goto	l6090
u8790:
	
l6084:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	addlw	low(0A0h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipnc
	addlw	1
	addlw	high(0A0h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u8805
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u8805:
	skipc
	goto	u8801
	goto	u8800
u8801:
	goto	l6090
u8800:
	
l6086:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u8815
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u8815:
	skipc
	goto	u8811
	goto	u8810
u8811:
	goto	l6090
u8810:
	goto	l5974
	line	691
	
l6090:	
;charge_mgr.c: 691: if(ct >= ((unsigned long)(2) * 16))
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	020h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u8821
	goto	u8820
u8821:
	goto	l6520
u8820:
	line	693
	
l6092:	
;charge_mgr.c: 692: {
;charge_mgr.c: 693: unsigned int pre = (unsigned int)(g_impData & 0x0FFFU);
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Slot_Charge_Ctrl@pre)^080h
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	andwf	(_g_impData+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	1+(Slot_Charge_Ctrl@pre)^080h
	line	699
;charge_mgr.c: 699: if(pre > 3500 && pre < 4090)
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1)^080h,w
	movlw	0ADh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre)^080h,w
	skipc
	goto	u8831
	goto	u8830
u8831:
	goto	l6118
u8830:
	
l6094:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@pre+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre)^080h,w
	skipnc
	goto	u8841
	goto	u8840
u8841:
	goto	l6118
u8840:
	line	702
	
l6096:	
;charge_mgr.c: 700: {
;charge_mgr.c: 701: unsigned char tc;
;charge_mgr.c: 702: unsigned char hasRise = 0;
	clrf	(Slot_Charge_Ctrl@hasRise)^080h
	line	703
;charge_mgr.c: 703: for(tc = 0; tc < g_diodeTraceCnt; tc++)
	clrf	(Slot_Charge_Ctrl@tc)^080h
	goto	l6104
	line	705
	
l6098:	
;charge_mgr.c: 704: {
;charge_mgr.c: 705: if(g_diodeTrace[tc] >= 136U)
	movf	(Slot_Charge_Ctrl@tc)^080h,w
	addlw	low(_g_diodeTrace|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(088h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipc
	goto	u8851
	goto	u8850
u8851:
	goto	l6102
u8850:
	line	707
	
l6100:	
;charge_mgr.c: 706: {
;charge_mgr.c: 707: hasRise = 1;
	clrf	(Slot_Charge_Ctrl@hasRise)^080h
	incf	(Slot_Charge_Ctrl@hasRise)^080h,f
	line	708
;charge_mgr.c: 708: break;
	goto	l6106
	line	703
	
l6102:	
	incf	(Slot_Charge_Ctrl@tc)^080h,f
	
l6104:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_diodeTraceCnt),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@tc)^080h,w
	skipc
	goto	u8861
	goto	u8860
u8861:
	goto	l6098
u8860:
	line	711
	
l6106:	
;charge_mgr.c: 709: }
;charge_mgr.c: 710: }
;charge_mgr.c: 711: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150U)
	bcf	status, 5	;RP0=0, select bank0
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w	;volatile
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w	;volatile
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8875
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8875:
	skipnc
	goto	u8871
	goto	u8870
u8871:
	goto	l6110
u8870:
	goto	l5924
	line	713
	
l6110:	
;charge_mgr.c: 713: if(!hasRise)
	bsf	status, 5	;RP0=1, select bank1
	movf	((Slot_Charge_Ctrl@hasRise)^080h),w
	btfss	status,2
	goto	u8881
	goto	u8880
u8881:
	goto	l5974
u8880:
	goto	l5900
	line	724
	
l6118:	
;charge_mgr.c: 723: }
;charge_mgr.c: 724: if(v > 3500 && v < 4090)
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0ADh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8891
	goto	u8890
u8891:
	goto	l6124
u8890:
	
l6120:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u8901
	goto	u8900
u8901:
	goto	l6124
u8900:
	goto	l5974
	line	737
	
l6124:	
;charge_mgr.c: 727: }
;charge_mgr.c: 736: if(v > 2300U && v < 3500U && pre < 3500U &&
;charge_mgr.c: 737: v + 150U >= pre && pre + 150U >= v)
	movlw	08h
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FDh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8911
	goto	u8910
u8911:
	goto	l5900
u8910:
	
l6126:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0ACh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u8921
	goto	u8920
u8921:
	goto	l5900
u8920:
	
l6128:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1)^080h,w
	movlw	0ACh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre)^080h,w
	skipnc
	goto	u8931
	goto	u8930
u8931:
	goto	l5900
u8930:
	
l6130:	
	movf	(Slot_Charge_Ctrl@v)^080h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@pre+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8945
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@pre)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8945:
	skipc
	goto	u8941
	goto	u8940
u8941:
	goto	l5900
u8940:
	
l6132:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@pre)^080h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@pre+1)^080h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u8955
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u8955:
	skipc
	goto	u8951
	goto	u8950
u8951:
	goto	l5900
u8950:
	goto	l5974
	line	751
	
l6142:	
;charge_mgr.c: 751: ct++;
	incf	(Slot_Charge_Ctrl@ct)^080h,f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	752
	
l6144:	
;charge_mgr.c: 752: if(ct > ((unsigned long)(60) * 16))
	movlw	03h
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	0C1h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u8961
	goto	u8960
u8961:
	goto	l6148
u8960:
	line	754
	
l6146:	
;charge_mgr.c: 753: {
;charge_mgr.c: 754: st = 7;
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	755
;charge_mgr.c: 755: break;
	goto	l6520
	line	757
	
l6148:	
;charge_mgr.c: 756: }
;charge_mgr.c: 757: if(v > 750)
	movlw	02h
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8971
	goto	u8970
u8971:
	goto	l6154
u8970:
	line	759
	
l6150:	
;charge_mgr.c: 758: {
;charge_mgr.c: 759: st = 3;
	movlw	low(03h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	760
	
l6152:	
;charge_mgr.c: 760: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	761
;charge_mgr.c: 761: break;
	goto	l6520
	line	763
	
l6154:	
;charge_mgr.c: 762: }
;charge_mgr.c: 763: if(v >= 3850)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0Ah
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u8981
	goto	u8980
u8981:
	goto	l6520
u8980:
	goto	l6146
	line	771
	
l6158:	
;charge_mgr.c: 771: ct++;
	incf	(Slot_Charge_Ctrl@ct)^080h,f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	772
	
l6160:	
;charge_mgr.c: 772: if(ct > ((unsigned long)(300) * 16))
	movlw	012h
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	0C1h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u8991
	goto	u8990
u8991:
	goto	l6164
u8990:
	goto	l6146
	line	777
	
l6164:	
;charge_mgr.c: 776: }
;charge_mgr.c: 777: if(v >= 3850)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0Ah
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9001
	goto	u9000
u9001:
	goto	l6170
u9000:
	line	779
	
l6166:	
;charge_mgr.c: 778: {
;charge_mgr.c: 779: g_ovCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	780
;charge_mgr.c: 780: if(g_ovCnt[idx] >= 5)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u9011
	goto	u9010
u9011:
	goto	l6172
u9010:
	goto	l6146
	line	788
	
l6170:	
;charge_mgr.c: 786: else
;charge_mgr.c: 787: {
;charge_mgr.c: 788: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	790
	
l6172:	
;charge_mgr.c: 789: }
;charge_mgr.c: 790: if(v >= 2700)
	movlw	0Ah
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	08Ch
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9021
	goto	u9020
u9021:
	goto	l6520
u9020:
	line	792
	
l6174:	
;charge_mgr.c: 791: {
;charge_mgr.c: 792: st = 4;
	movlw	low(04h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	793
	
l6176:	
;charge_mgr.c: 793: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	794
	
l6178:	
;charge_mgr.c: 794: g_ccBlocks[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	795
	
l6180:	
;charge_mgr.c: 795: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	796
	
l6182:	
;charge_mgr.c: 796: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	line	797
	
l6184:	
;charge_mgr.c: 797: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6520
	line	802
	
l6186:	
;charge_mgr.c: 802: ct++;
	incf	(Slot_Charge_Ctrl@ct)^080h,f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	803
	
l6188:	
;charge_mgr.c: 803: if(ct >= ((unsigned long)(600) * 16))
	movlw	025h
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	080h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u9031
	goto	u9030
u9031:
	goto	l6194
u9030:
	line	805
	
l6190:	
;charge_mgr.c: 804: {
;charge_mgr.c: 805: ct -= ((unsigned long)(600) * 16);
	movlw	080h
	subwf	(Slot_Charge_Ctrl@ct)^080h,f
	movlw	025h
	skipc
	decf	(Slot_Charge_Ctrl@ct+1)^080h,f
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	806
	
l6192:	
;charge_mgr.c: 806: g_ccBlocks[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	808
	
l6194:	
;charge_mgr.c: 807: }
;charge_mgr.c: 808: if(g_ccBlocks[idx] >= 18)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(012h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u9041
	goto	u9040
u9041:
	goto	l6198
u9040:
	goto	l6146
	line	817
	
l6198:	
;charge_mgr.c: 812: }
;charge_mgr.c: 817: if(v >= 4090 && ty == 6)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9051
	goto	u9050
u9051:
	goto	l6204
u9050:
	
l6200:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9061
	goto	u9060
u9061:
	goto	l6204
u9060:
	goto	l6212
	line	821
	
l6204:	
;charge_mgr.c: 821: else if(ct <= ((unsigned long)(60) * 16))
	movlw	03h
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	0C1h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipnc
	goto	u9071
	goto	u9070
u9071:
	goto	l6208
u9070:
	goto	l6212
	line	831
	
l6208:	
;charge_mgr.c: 829: else
;charge_mgr.c: 830: {
;charge_mgr.c: 831: if(v > g_slotRefV[idx]) g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9085
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9085:
	skipnc
	goto	u9081
	goto	u9080
u9081:
	goto	l6212
u9080:
	
l6210:	
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	line	841
	
l6212:	
;charge_mgr.c: 832: }
;charge_mgr.c: 841: if(ty == 6)
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9091
	goto	u9090
u9091:
	goto	l6258
u9090:
	line	843
	
l6214:	
;charge_mgr.c: 842: {
;charge_mgr.c: 843: if(v < 2000U)
	movlw	07h
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0D0h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u9101
	goto	u9100
u9101:
	goto	l6224
u9100:
	line	845
	
l6216:	
;charge_mgr.c: 844: {
;charge_mgr.c: 845: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	846
;charge_mgr.c: 846: if(g_detectLowCnt[idx] >= ((unsigned long)(3) * 16))
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(030h)
	subwf	indf,w
	skipc
	goto	u9111
	goto	u9110
u9111:
	goto	l6226
u9110:
	line	848
	
l6218:	
;charge_mgr.c: 847: {
;charge_mgr.c: 848: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	849
	
l6220:	
;charge_mgr.c: 849: st = 7;
	movlw	low(07h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	goto	l6152
	line	856
	
l6224:	
;charge_mgr.c: 854: else
;charge_mgr.c: 855: {
;charge_mgr.c: 856: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	875
	
l6226:	
;charge_mgr.c: 857: }
;charge_mgr.c: 875: if(ct >= ((unsigned long)(16) * 16))
	movlw	01h
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	0
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u9121
	goto	u9120
u9121:
	goto	l6292
u9120:
	line	877
	
l6228:	
;charge_mgr.c: 876: {
;charge_mgr.c: 877: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	878
	
l6230:	
;charge_mgr.c: 878: if(v >= 2800U && v < 4090)
	movlw	0Ah
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9131
	goto	u9130
u9131:
	goto	l6242
u9130:
	
l6232:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u9141
	goto	u9140
u9141:
	goto	l6242
u9140:
	line	880
	
l6234:	
;charge_mgr.c: 879: {
;charge_mgr.c: 880: st = 5;
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	881
	
l6236:	
;charge_mgr.c: 881: g_ccBlocks[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6182
	line	885
	
l6242:	
;charge_mgr.c: 885: else if(v >= g_slotRefV[idx] + (30))
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipz
	goto	u9155
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v)^080h,w
u9155:
	skipc
	goto	u9151
	goto	u9150
u9151:
	goto	l6246
u9150:
	line	887
	
l6244:	
;charge_mgr.c: 886: {
;charge_mgr.c: 887: g_stableCnt[idx] = 1;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	888
;charge_mgr.c: 888: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	line	889
;charge_mgr.c: 889: }
	goto	l6520
	line	890
	
l6246:	
;charge_mgr.c: 890: else if(g_stableCnt[idx] != 0)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(indf),w
	btfsc	status,2
	goto	u9161
	goto	u9160
u9161:
	goto	l6250
u9160:
	goto	l5640
	line	894
	
l6250:	
;charge_mgr.c: 894: else if(g_ccBlocks[idx] & 0x80)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	btfss	indf,(7)&7
	goto	u9171
	goto	u9170
u9171:
	goto	l6254
u9170:
	goto	l6146
	line	900
	
l6254:	
;charge_mgr.c: 898: else
;charge_mgr.c: 899: {
;charge_mgr.c: 900: g_ccBlocks[idx] |= 0x80;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(7/8),(7)&7
	line	901
	
l6256:	
;charge_mgr.c: 901: st = 1;
	clrf	(Slot_Charge_Ctrl@st)^080h
	incf	(Slot_Charge_Ctrl@st)^080h,f
	line	902
;charge_mgr.c: 902: g_slotRefV[idx] = 0;
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	903
;charge_mgr.c: 903: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6520
	line	913
	
l6258:	
;charge_mgr.c: 908: else
;charge_mgr.c: 909: {
;charge_mgr.c: 913: if((v < g_slotRefV[idx] && g_slotRefV[idx] - v > 500) || v < 2000U)
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipz
	goto	u9185
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v)^080h,w
u9185:
	skipnc
	goto	u9181
	goto	u9180
u9181:
	goto	l6262
u9180:
	
l6260:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipc
	incf	(Slot_Charge_Ctrl@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	01h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipnc
	goto	u9191
	goto	u9190
u9191:
	goto	l6264
u9190:
	
l6262:	
	movlw	07h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0D0h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u9201
	goto	u9200
u9201:
	goto	l6276
u9200:
	line	915
	
l6264:	
;charge_mgr.c: 914: {
;charge_mgr.c: 915: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	916
;charge_mgr.c: 916: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9211
	goto	u9210
u9211:
	goto	l6268
u9210:
	goto	l6520
	line	918
	
l6268:	
;charge_mgr.c: 918: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	919
	
l6270:	
;charge_mgr.c: 919: st = 1;
	clrf	(Slot_Charge_Ctrl@st)^080h
	incf	(Slot_Charge_Ctrl@st)^080h,f
	goto	l6152
	line	925
	
l6276:	
;charge_mgr.c: 923: else
;charge_mgr.c: 924: {
;charge_mgr.c: 925: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	937
	
l6278:	
;charge_mgr.c: 926: }
;charge_mgr.c: 937: if(ct <= ((unsigned long)(60) * 16))
	movlw	03h
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	0C1h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipnc
	goto	u9221
	goto	u9220
u9221:
	goto	l6284
u9220:
	line	939
	
l6280:	
;charge_mgr.c: 938: {
;charge_mgr.c: 939: if(v >= g_slotRefV[idx] + (30))
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipz
	goto	u9235
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v)^080h,w
u9235:
	skipc
	goto	u9231
	goto	u9230
u9231:
	goto	l6284
u9230:
	line	940
	
l6282:	
;charge_mgr.c: 940: g_stableCnt[idx] = 1;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	942
	
l6284:	
;charge_mgr.c: 941: }
;charge_mgr.c: 942: if(ct > ((unsigned long)(60) * 16) && g_stableCnt[idx] == 0)
	movlw	03h
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	0C1h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u9241
	goto	u9240
u9241:
	goto	l6292
u9240:
	
l6286:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfss	status,2
	goto	u9251
	goto	u9250
u9251:
	goto	l6292
u9250:
	goto	l6220
	line	956
	
l6292:	
;charge_mgr.c: 947: }
;charge_mgr.c: 948: }
;charge_mgr.c: 956: if(v >= 4090 && ty == 1)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9261
	goto	u9260
u9261:
	goto	l6300
u9260:
	
l6294:	
		decf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9271
	goto	u9270
u9271:
	goto	l6300
u9270:
	line	958
	
l6296:	
;charge_mgr.c: 957: {
;charge_mgr.c: 958: st = 6;
	movlw	low(06h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	goto	l6152
	line	966
	
l6300:	
;charge_mgr.c: 961: }
;charge_mgr.c: 966: if(v >= 3850 && ty != 6)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0Ah
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9281
	goto	u9280
u9281:
	goto	l6308
u9280:
	
l6302:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u9291
	goto	u9290
u9291:
	goto	l6308
u9290:
	line	968
	
l6304:	
;charge_mgr.c: 967: {
;charge_mgr.c: 968: g_ovCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	969
;charge_mgr.c: 969: if(g_ovCnt[idx] >= 5)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u9301
	goto	u9300
u9301:
	goto	l564
u9300:
	goto	l6146
	line	977
	
l6308:	
;charge_mgr.c: 975: else
;charge_mgr.c: 976: {
;charge_mgr.c: 977: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	979
	
l6310:	
;charge_mgr.c: 979: if(v >= 3100 && !(v >= 4090 && ty == 6))
	movlw	0Ch
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	01Ch
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9311
	goto	u9310
u9311:
	goto	l564
u9310:
	
l6312:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9321
	goto	u9320
u9321:
	goto	l6316
u9320:
	
l6314:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u9331
	goto	u9330
u9331:
	goto	l564
u9330:
	line	981
	
l6316:	
;charge_mgr.c: 980: {
;charge_mgr.c: 981: st = 5;
	movlw	low(05h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	982
	
l6318:	
;charge_mgr.c: 982: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	983
	
l6320:	
;charge_mgr.c: 983: g_ccBlocks[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6520
	line	990
	
l6322:	
;charge_mgr.c: 990: ct++;
	incf	(Slot_Charge_Ctrl@ct)^080h,f
	skipnz
	incf	(Slot_Charge_Ctrl@ct+1)^080h,f
	line	991
	
l6324:	
;charge_mgr.c: 991: if(ct > ((unsigned long)(600) * 16))
	movlw	025h
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	081h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipc
	goto	u9341
	goto	u9340
u9341:
	goto	l725
u9340:
	line	992
	
l6326:	
;charge_mgr.c: 992: st = 6;
	movlw	low(06h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	
l725:	
	line	1000
;charge_mgr.c: 1000: if(v >= 4090 && ty == 6)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9351
	goto	u9350
u9351:
	goto	l6332
u9350:
	
l6328:	
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9361
	goto	u9360
u9361:
	goto	l6332
u9360:
	goto	l6520
	line	1013
	
l6332:	
;charge_mgr.c: 1013: if(v < 4090 && ct <= ((unsigned long)(60) * 16) && ty == 1)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u9371
	goto	u9370
u9371:
	goto	l6354
u9370:
	
l6334:	
	movlw	03h
	subwf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movlw	0C1h
	skipnz
	subwf	(Slot_Charge_Ctrl@ct)^080h,w
	skipnc
	goto	u9381
	goto	u9380
u9381:
	goto	l6354
u9380:
	
l6336:	
		decf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9391
	goto	u9390
u9391:
	goto	l6354
u9390:
	line	1015
	
l6338:	
;charge_mgr.c: 1014: {
;charge_mgr.c: 1015: if(g_ccBlocks[idx] == 0)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfss	status,2
	goto	u9401
	goto	u9400
u9401:
	goto	l6342
u9400:
	line	1017
	
l6340:	
;charge_mgr.c: 1016: {
;charge_mgr.c: 1017: g_slotRefV[idx] = v;
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Slot_Charge_Ctrl@v)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	line	1018
;charge_mgr.c: 1018: g_ccBlocks[idx] = 1;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	1019
;charge_mgr.c: 1019: }
	goto	l6354
	line	1020
	
l6342:	
;charge_mgr.c: 1020: else if(v >= g_slotRefV[idx] + (50))
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipz
	goto	u9415
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v)^080h,w
u9415:
	skipc
	goto	u9411
	goto	u9410
u9411:
	goto	l6352
u9410:
	line	1022
	
l6344:	
;charge_mgr.c: 1021: {
;charge_mgr.c: 1022: if(++g_stableCnt[idx] >= 3)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	movlw	low(03h)
	subwf	(indf),w
	skipc
	goto	u9421
	goto	u9420
u9421:
	goto	l729
u9420:
	line	1024
	
l6346:	
;charge_mgr.c: 1023: {
;charge_mgr.c: 1024: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6220
	line	1032
	
l6352:	
;charge_mgr.c: 1030: else
;charge_mgr.c: 1031: {
;charge_mgr.c: 1032: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6354
	line	1033
	
l729:	
	line	1041
	
l6354:	
;charge_mgr.c: 1033: }
;charge_mgr.c: 1034: }
;charge_mgr.c: 1041: if(v >= 4090)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9431
	goto	u9430
u9431:
	goto	l6384
u9430:
	line	1043
	
l6356:	
;charge_mgr.c: 1042: {
;charge_mgr.c: 1043: if(ty == 1)
		decf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9441
	goto	u9440
u9441:
	goto	l6368
u9440:
	line	1045
	
l6358:	
;charge_mgr.c: 1044: {
;charge_mgr.c: 1045: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1046
;charge_mgr.c: 1046: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9451
	goto	u9450
u9451:
	goto	l6362
u9450:
	goto	l6520
	line	1048
	
l6362:	
;charge_mgr.c: 1048: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6296
	line	1053
	
l6368:	
;charge_mgr.c: 1052: }
;charge_mgr.c: 1053: if(ty == 6)
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9461
	goto	u9460
u9461:
	goto	l6372
u9460:
	goto	l6520
	line	1058
	
l6372:	
;charge_mgr.c: 1057: }
;charge_mgr.c: 1058: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1059
;charge_mgr.c: 1059: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9471
	goto	u9470
u9471:
	goto	l6376
u9470:
	goto	l6520
	line	1061
	
l6376:	
;charge_mgr.c: 1061: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1062
	
l6378:	
;charge_mgr.c: 1062: ty = 0;
	clrf	(Slot_Charge_Ctrl@ty)^080h
	line	1063
	
l6380:	
;charge_mgr.c: 1063: st = 0;
	clrf	(Slot_Charge_Ctrl@st)^080h
	goto	l6152
	line	1074
	
l6384:	
;charge_mgr.c: 1066: }
;charge_mgr.c: 1074: if(ty == 6)
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9481
	goto	u9480
u9481:
	goto	l6398
u9480:
	line	1076
	
l6386:	
;charge_mgr.c: 1075: {
;charge_mgr.c: 1076: if(v < 2000U)
	movlw	07h
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0D0h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u9491
	goto	u9490
u9491:
	goto	l6396
u9490:
	line	1078
	
l6388:	
;charge_mgr.c: 1077: {
;charge_mgr.c: 1078: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1079
;charge_mgr.c: 1079: if(g_detectLowCnt[idx] >= ((unsigned long)(3) * 16))
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(030h)
	subwf	indf,w
	skipc
	goto	u9501
	goto	u9500
u9501:
	goto	l6414
u9500:
	goto	l6218
	line	1089
	
l6396:	
;charge_mgr.c: 1087: else
;charge_mgr.c: 1088: {
;charge_mgr.c: 1089: g_detectLowCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l6414
	line	1094
	
l6398:	
;charge_mgr.c: 1092: else
;charge_mgr.c: 1093: {
;charge_mgr.c: 1094: if(v < g_slotRefV[idx] && g_slotRefV[idx] - v > 500)
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipz
	goto	u9515
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(Slot_Charge_Ctrl@v)^080h,w
u9515:
	skipnc
	goto	u9511
	goto	u9510
u9511:
	goto	l6396
u9510:
	
l6400:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	skipc
	incf	(Slot_Charge_Ctrl@v+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	01h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipc
	goto	u9521
	goto	u9520
u9521:
	goto	l6396
u9520:
	line	1096
	
l6402:	
;charge_mgr.c: 1095: {
;charge_mgr.c: 1096: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1097
;charge_mgr.c: 1097: if(g_detectLowCnt[idx] >= 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipc
	goto	u9531
	goto	u9530
u9531:
	goto	l6414
u9530:
	line	1099
	
l6404:	
;charge_mgr.c: 1098: {
;charge_mgr.c: 1099: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1100
;charge_mgr.c: 1100: g_ccBlocks[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1103
	
l6406:	
;charge_mgr.c: 1103: ty = 0;
	clrf	(Slot_Charge_Ctrl@ty)^080h
	goto	l6270
	line	1119
	
l6414:	
;charge_mgr.c: 1112: }
;charge_mgr.c: 1113: }
;charge_mgr.c: 1119: if(v >= 3850 && ty == 1)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0Ah
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9541
	goto	u9540
u9541:
	goto	l6422
u9540:
	
l6416:	
		decf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9551
	goto	u9550
u9551:
	goto	l6422
u9550:
	line	1121
	
l6418:	
;charge_mgr.c: 1120: {
;charge_mgr.c: 1121: g_ovCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1122
;charge_mgr.c: 1122: if(g_ovCnt[idx] >= 5)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u9561
	goto	u9560
u9561:
	goto	l564
u9560:
	goto	l6146
	line	1130
	
l6422:	
;charge_mgr.c: 1128: else
;charge_mgr.c: 1129: {
;charge_mgr.c: 1130: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6520
	line	1141
	
l6424:	
;charge_mgr.c: 1141: if(v >= 4090)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9571
	goto	u9570
u9571:
	goto	l6442
u9570:
	line	1143
	
l6426:	
;charge_mgr.c: 1142: {
;charge_mgr.c: 1143: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1144
	
l6428:	
;charge_mgr.c: 1144: if(g_detectLowCnt[idx] >= (ty == 6 ? (16 / 2) : 2))
		movlw	6
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u9581
	goto	u9580
u9581:
	goto	l6432
u9580:
	
l6430:	
	movlw	02h
	movwf	(_Slot_Charge_Ctrl$386)^080h
	clrf	(_Slot_Charge_Ctrl$386+1)^080h
	goto	l6434
	
l6432:	
	movlw	08h
	movwf	(_Slot_Charge_Ctrl$386)^080h
	clrf	(_Slot_Charge_Ctrl$386+1)^080h
	
l6434:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(_Slot_Charge_Ctrl$386+1)^080h,w
	xorlw	80h
	sublw	080h
	skipz
	goto	u9595
	movf	(_Slot_Charge_Ctrl$386)^080h,w
	subwf	indf,w
u9595:

	skipc
	goto	u9591
	goto	u9590
u9591:
	goto	l6520
u9590:
	line	1146
	
l6436:	
;charge_mgr.c: 1145: {
;charge_mgr.c: 1146: g_detectLowCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l6380
	line	1155
	
l6442:	
;charge_mgr.c: 1151: }
;charge_mgr.c: 1155: if(v < 2800U)
	movlw	0Ah
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipnc
	goto	u9601
	goto	u9600
u9601:
	goto	l5680
u9600:
	line	1157
	
l6444:	
;charge_mgr.c: 1156: {
;charge_mgr.c: 1157: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1158
;charge_mgr.c: 1158: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9611
	goto	u9610
u9611:
	goto	l6448
u9610:
	goto	l6520
	line	1160
	
l6448:	
;charge_mgr.c: 1160: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1161
	
l6450:	
;charge_mgr.c: 1161: st = 4;
	movlw	low(04h)
	movwf	(Slot_Charge_Ctrl@st)^080h
	line	1162
	
l6452:	
;charge_mgr.c: 1162: ct = 0;
	clrf	(Slot_Charge_Ctrl@ct)^080h
	clrf	(Slot_Charge_Ctrl@ct+1)^080h
	line	1163
	
l6454:	
;charge_mgr.c: 1163: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6236
	line	1177
	
l6464:	
;charge_mgr.c: 1177: if(v >= 4090)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0FAh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9621
	goto	u9620
u9621:
	goto	l6480
u9620:
	line	1179
	
l6466:	
;charge_mgr.c: 1178: {
;charge_mgr.c: 1179: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1180
;charge_mgr.c: 1180: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9631
	goto	u9630
u9631:
	goto	l6470
u9630:
	goto	l6520
	line	1182
	
l6470:	
;charge_mgr.c: 1182: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1183
	
l6472:	
;charge_mgr.c: 1183: ty = 0;
	clrf	(Slot_Charge_Ctrl@ty)^080h
	line	1184
	
l6474:	
;charge_mgr.c: 1184: st = 0;
	clrf	(Slot_Charge_Ctrl@st)^080h
	goto	l6318
	line	1197
	
l6480:	
;charge_mgr.c: 1188: }
;charge_mgr.c: 1197: if(ty == 2 || ty == 3)
		movlw	2
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfsc	status,2
	goto	u9641
	goto	u9640
u9641:
	goto	l6484
u9640:
	
l6482:	
		movlw	3
	xorwf	((Slot_Charge_Ctrl@ty)^080h),w
	btfss	status,2
	goto	u9651
	goto	u9650
u9651:
	goto	l6500
u9650:
	line	1199
	
l6484:	
;charge_mgr.c: 1198: {
;charge_mgr.c: 1199: if(v > 2700U && (g_highVFlag & ((unsigned int)1 << idx)))
	movlw	0Ah
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	08Dh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9661
	goto	u9660
u9661:
	goto	l5680
u9660:
	
l6486:	
	incf	(Slot_Charge_Ctrl@idx)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9674
u9675:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9674:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9675
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u9681
	goto	u9680
u9681:
	goto	l5680
u9680:
	line	1201
	
l6488:	
;charge_mgr.c: 1200: {
;charge_mgr.c: 1201: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1202
;charge_mgr.c: 1202: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9691
	goto	u9690
u9691:
	goto	l6268
u9690:
	goto	l6520
	line	1215
	
l6500:	
;charge_mgr.c: 1213: }
;charge_mgr.c: 1215: if(v > 750)
	movlw	02h
	subwf	(Slot_Charge_Ctrl@v+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Slot_Charge_Ctrl@v)^080h,w
	skipc
	goto	u9701
	goto	u9700
u9701:
	goto	l5680
u9700:
	line	1217
	
l6502:	
;charge_mgr.c: 1216: {
;charge_mgr.c: 1217: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1218
;charge_mgr.c: 1218: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u9711
	goto	u9710
u9711:
	goto	l6268
u9710:
	goto	l6520
	line	1231
	
l6514:	
;charge_mgr.c: 1231: st = 0;
	clrf	(Slot_Charge_Ctrl@st)^080h
	line	1232
;charge_mgr.c: 1232: break;
	goto	l6520
	line	230
	
l6518:	
	movf	(Slot_Charge_Ctrl@st)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l5624
	xorlw	1^0	; case 1
	skipnz
	goto	l5644
	xorlw	2^1	; case 2
	skipnz
	goto	l6142
	xorlw	3^2	; case 3
	skipnz
	goto	l6158
	xorlw	4^3	; case 4
	skipnz
	goto	l6186
	xorlw	5^4	; case 5
	skipnz
	goto	l6322
	xorlw	6^5	; case 6
	skipnz
	goto	l6424
	xorlw	7^6	; case 7
	skipnz
	goto	l6464
	xorlw	8^7	; case 8
	skipnz
	goto	l5862
	xorlw	9^8	; case 9
	skipnz
	goto	l6022
	goto	l6514
	opt asmopt_pop

	line	1233
	
l564:	
	line	1235
	
l6520:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Slot_Charge_Ctrl@st)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Slot_Charge_Ctrl@ty)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Slot_Charge_Ctrl@v)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@v+1)^080h,w
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Slot_Charge_Ctrl@ct)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(Slot_Charge_Ctrl@ct+1)^080h,w
	movwf	indf
	line	1241
	
l6522:	
;charge_mgr.c: 1238: if((st == 2 || st == 3 ||
;charge_mgr.c: 1239: st == 4 || st == 5 ||
;charge_mgr.c: 1240: st == 8 || st == 1) &&
;charge_mgr.c: 1241: !g_tempProtect && !g_vccProtect)
		movlw	2
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfsc	status,2
	goto	u9721
	goto	u9720
u9721:
	goto	l6534
u9720:
	
l6524:	
		movlw	3
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfsc	status,2
	goto	u9731
	goto	u9730
u9731:
	goto	l6534
u9730:
	
l6526:	
		movlw	4
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfsc	status,2
	goto	u9741
	goto	u9740
u9741:
	goto	l6534
u9740:
	
l6528:	
		movlw	5
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfsc	status,2
	goto	u9751
	goto	u9750
u9751:
	goto	l6534
u9750:
	
l6530:	
		movlw	8
	xorwf	((Slot_Charge_Ctrl@st)^080h),w
	btfsc	status,2
	goto	u9761
	goto	u9760
u9761:
	goto	l6534
u9760:
	
l6532:	
		decf	((Slot_Charge_Ctrl@st)^080h),w
	btfss	status,2
	goto	u9771
	goto	u9770
u9771:
	goto	l6544
u9770:
	
l6534:	
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u9781
	goto	u9780
u9781:
	goto	l6544
u9780:
	
l6536:	
	movf	((_g_vccProtect)^080h),w
	btfss	status,2
	goto	u9791
	goto	u9790
u9791:
	goto	l6544
u9790:
	goto	l6540
	line	1243
	
l779:	
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	l810
	
l781:	
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	l810
	
l782:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	l810
	
l783:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	l810
	
l784:	
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	l810
	
l785:	
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	l810
	
l786:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l810
	
l787:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l810
	
l788:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	l810
	
l789:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	l810
	
l790:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l810
	
l791:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l810
	
l6540:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l779
	xorlw	1^0	; case 1
	skipnz
	goto	l781
	xorlw	2^1	; case 2
	skipnz
	goto	l782
	xorlw	3^2	; case 3
	skipnz
	goto	l783
	xorlw	4^3	; case 4
	skipnz
	goto	l784
	xorlw	5^4	; case 5
	skipnz
	goto	l785
	xorlw	6^5	; case 6
	skipnz
	goto	l786
	xorlw	7^6	; case 7
	skipnz
	goto	l787
	xorlw	8^7	; case 8
	skipnz
	goto	l788
	xorlw	9^8	; case 9
	skipnz
	goto	l789
	xorlw	10^9	; case 10
	skipnz
	goto	l790
	xorlw	11^10	; case 11
	skipnz
	goto	l791
	goto	l810
	opt asmopt_pop

	line	1247
	
l796:	
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l810
	
l798:	
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l810
	
l799:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	l810
	
l800:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	l810
	
l801:	
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l810
	
l802:	
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l810
	
l803:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l810
	
l804:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l810
	
l805:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	l810
	
l806:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	l810
	
l807:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l810
	
l808:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l810
	
l6544:	
	movf	(Slot_Charge_Ctrl@idx)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l796
	xorlw	1^0	; case 1
	skipnz
	goto	l798
	xorlw	2^1	; case 2
	skipnz
	goto	l799
	xorlw	3^2	; case 3
	skipnz
	goto	l800
	xorlw	4^3	; case 4
	skipnz
	goto	l801
	xorlw	5^4	; case 5
	skipnz
	goto	l802
	xorlw	6^5	; case 6
	skipnz
	goto	l803
	xorlw	7^6	; case 7
	skipnz
	goto	l804
	xorlw	8^7	; case 8
	skipnz
	goto	l805
	xorlw	9^8	; case 9
	skipnz
	goto	l806
	xorlw	10^9	; case 10
	skipnz
	goto	l807
	xorlw	11^10	; case 11
	skipnz
	goto	l808
	goto	l810
	opt asmopt_pop

	line	1249
	
l810:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_Charge_Ctrl
	__end_of_Slot_Charge_Ctrl:
	signat	_Slot_Charge_Ctrl,4217
	global	___wmul

;; *************** function ___wmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
;; Parameters:    Size  Location     Type
;;  multiplier      2    2[COMMON] unsigned int 
;;  multiplicand    2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  product         2    6[COMMON] unsigned int 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         6       0       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
global __ptext6
__ptext6:	;psect for function ___wmul
psect	text6
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
	global	__size_of___wmul
	__size_of___wmul	equ	__end_of___wmul-___wmul
	
___wmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___wmul: [wreg+status,2+status,0]
	line	43
	
l3434:	
	clrf	(___wmul@product)
	clrf	(___wmul@product+1)
	line	45
	
l3436:	
	btfss	(___wmul@multiplier),(0)&7
	goto	u3821
	goto	u3820
u3821:
	goto	l3440
u3820:
	line	46
	
l3438:	
	movf	(___wmul@multiplicand),w
	addwf	(___wmul@product),f
	skipnc
	incf	(___wmul@product+1),f
	movf	(___wmul@multiplicand+1),w
	addwf	(___wmul@product+1),f
	line	47
	
l3440:	
	clrc
	rlf	(___wmul@multiplicand),f
	rlf	(___wmul@multiplicand+1),f
	line	48
	
l3442:	
	clrc
	rrf	(___wmul@multiplier+1),f
	rrf	(___wmul@multiplier),f
	line	49
	
l3444:	
	movf	((___wmul@multiplier)),w
iorwf	((___wmul@multiplier+1)),w
	btfss	status,2
	goto	u3831
	goto	u3830
u3831:
	goto	l3436
u3830:
	line	52
	
l3446:	
	movf	(___wmul@product+1),w
	movwf	(?___wmul+1)
	movf	(___wmul@product),w
	movwf	(?___wmul)
	line	53
	
l884:	
	return
	opt stack 0
GLOBAL	__end_of___wmul
	__end_of___wmul:
	signat	___wmul,8314
	global	_Get_Vcc

;; *************** function _Get_Vcc *****************
;; Defined at:
;;		line 47 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   17[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  2   52[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;; This function is called by:
;;		_main
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	47
global __ptext7
__ptext7:	;psect for function _Get_Vcc
psect	text7
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	47
	global	__size_of_Get_Vcc
	__size_of_Get_Vcc	equ	__end_of_Get_Vcc-_Get_Vcc
	
_Get_Vcc:	
;incstack = 0
	opt	stack 3
; Regs used in _Get_Vcc: [wreg+status,2+status,0+pclath+cstack]
	line	49
	
l5278:	
;charge_mgr.c: 49: if(0xA5 == ADC_Sample(31, 0))
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u7371
	goto	u7370
u7371:
	goto	l499
u7370:
	line	51
	
l5280:	
;charge_mgr.c: 50: {
;charge_mgr.c: 51: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult),w	;volatile
	movwf	(___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Get_Vcc@pt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Get_Vcc@pt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Get_Vcc@pt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Get_Vcc@pt)

	line	52
	
l5282:	
;charge_mgr.c: 52: g_vcc_mv = (unsigned int)pt;
	movf	(Get_Vcc@pt+1),w
	movwf	(_g_vcc_mv+1)	;volatile
	movf	(Get_Vcc@pt),w
	movwf	(_g_vcc_mv)	;volatile
	line	55
	
l499:	
	return
	opt stack 0
GLOBAL	__end_of_Get_Vcc
	__end_of_Get_Vcc:
	signat	_Get_Vcc,90
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 119 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2    2[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         2       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	119
global __ptext8
__ptext8:	;psect for function _Detect_BatteryType
psect	text8
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	119
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 4
; Regs used in _Detect_BatteryType: [wreg]
	line	121
	
l3402:	
;charge_mgr.c: 121: if(voltage >= 4090)
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0FAh
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u3761
	goto	u3760
u3761:
	goto	l3408
u3760:
	line	122
	
l3404:	
;charge_mgr.c: 122: return 0;
	movlw	low(0)
	goto	l523
	line	123
	
l3408:	
;charge_mgr.c: 123: if(voltage < 500)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u3771
	goto	u3770
u3771:
	goto	l3414
u3770:
	goto	l3404
	line	138
	
l3414:	
;charge_mgr.c: 138: if(voltage >= 1015 && voltage < 4090)
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u3781
	goto	u3780
u3781:
	goto	l3422
u3780:
	
l3416:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0FAh
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u3791
	goto	u3790
u3791:
	goto	l3422
u3790:
	line	139
	
l3418:	
;charge_mgr.c: 139: return 5;
	movlw	low(05h)
	goto	l523
	line	144
	
l3422:	
;charge_mgr.c: 144: if(voltage >= 500 && voltage < 4090)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u3801
	goto	u3800
u3801:
	goto	l3404
u3800:
	
l3424:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0FAh
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u3811
	goto	u3810
u3811:
	goto	l3404
u3810:
	line	145
	
l3426:	
;charge_mgr.c: 145: return 1;
	movlw	low(01h)
	line	148
	
l523:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_Adc_Norm

;; *************** function _Adc_Norm *****************
;; Defined at:
;;		line 69 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  ch              1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  ch              1   20[BANK0 ] unsigned char 
;;  norm            4   23[BANK0 ] unsigned long 
;;  raw             2   21[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   17[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       3       0       0       0
;;      Locals:         0       7       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      10       0       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	69
global __ptext9
__ptext9:	;psect for function _Adc_Norm
psect	text9
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	69
	global	__size_of_Adc_Norm
	__size_of_Adc_Norm	equ	__end_of_Adc_Norm-_Adc_Norm
	
_Adc_Norm:	
;incstack = 0
	opt	stack 3
; Regs used in _Adc_Norm: [wreg+status,2+status,0+pclath+cstack]
;Adc_Norm@ch stored from wreg
	movwf	(Adc_Norm@ch)
	line	74
	
l5286:	
;charge_mgr.c: 71: unsigned int raw;
;charge_mgr.c: 72: unsigned long norm;
;charge_mgr.c: 74: if(0xA5 != ADC_Sample(ch, 0))
	clrf	(ADC_Sample@adldo)
	movf	(Adc_Norm@ch),w
	fcall	_ADC_Sample
	xorlw	0A5h
	skipnz
	goto	u7381
	goto	u7380
u7381:
	goto	l5292
u7380:
	line	75
	
l5288:	
;charge_mgr.c: 75: return 0;
	clrf	(?_Adc_Norm)
	clrf	(?_Adc_Norm+1)
	goto	l503
	line	76
	
l5292:	
;charge_mgr.c: 76: raw = adresult;
	movf	(_adresult+1),w	;volatile
	movwf	(Adc_Norm@raw+1)
	movf	(_adresult),w	;volatile
	movwf	(Adc_Norm@raw)
	line	77
	
l5294:	
;charge_mgr.c: 77: if(g_vcc_mv == 0)
	movf	((_g_vcc_mv)),w	;volatile
iorwf	((_g_vcc_mv+1)),w	;volatile
	btfss	status,2
	goto	u7391
	goto	u7390
u7391:
	goto	l5300
u7390:
	line	78
	
l5296:	
;charge_mgr.c: 78: return raw;
	movf	(Adc_Norm@raw+1),w
	movwf	(?_Adc_Norm+1)
	movf	(Adc_Norm@raw),w
	movwf	(?_Adc_Norm)
	goto	l503
	line	80
	
l5300:	
;charge_mgr.c: 80: norm = (unsigned long)raw * g_vcc_mv / 5000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	movf	(Adc_Norm@raw),w
	movwf	(___lmul@multiplier)
	movf	(Adc_Norm@raw+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movf	(_g_vcc_mv),w	;volatile
	movwf	(___lmul@multiplicand)
	movf	(_g_vcc_mv+1),w	;volatile
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Adc_Norm@norm+3)
	movf	(2+(?___lldiv)),w
	movwf	(Adc_Norm@norm+2)
	movf	(1+(?___lldiv)),w
	movwf	(Adc_Norm@norm+1)
	movf	(0+(?___lldiv)),w
	movwf	(Adc_Norm@norm)

	line	81
	
l5302:	
;charge_mgr.c: 81: if(norm > 4095UL)
		movf	(Adc_Norm@norm+3),w
	btfss	status,2
	goto	u7400
	movf	(Adc_Norm@norm+2),w
	btfss	status,2
	goto	u7400
	movlw	16
	subwf	(Adc_Norm@norm+1),w
	skipz
	goto	u7403
	movlw	0
	subwf	(Adc_Norm@norm),w
	skipz
	goto	u7403
u7403:
	btfss	status,0
	goto	u7401
	goto	u7400

u7401:
	goto	l505
u7400:
	line	82
	
l5304:	
;charge_mgr.c: 82: norm = 4095UL;
	movlw	0
	movwf	(Adc_Norm@norm+3)
	movlw	0
	movwf	(Adc_Norm@norm+2)
	movlw	0Fh
	movwf	(Adc_Norm@norm+1)
	movlw	0FFh
	movwf	(Adc_Norm@norm)

	
l505:	
	line	83
;charge_mgr.c: 83: return (unsigned int)norm;
	movf	(Adc_Norm@norm+1),w
	movwf	(?_Adc_Norm+1)
	movf	(Adc_Norm@norm),w
	movwf	(?_Adc_Norm)
	line	84
	
l503:	
	return
	opt stack 0
GLOBAL	__end_of_Adc_Norm
	__end_of_Adc_Norm:
	signat	_Adc_Norm,4218
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 86 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   21[BANK0 ] unsigned long 
;;  temp_x10        2   27[BANK0 ] unsigned int 
;;  ntcVal          2   25[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   60[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/A00
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=0
	line	86
global __ptext10
__ptext10:	;psect for function _Read_Temperature
psect	text10
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	86
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 4
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	91
	
l6734:	
;charge_mgr.c: 88: unsigned int ntcVal;
;charge_mgr.c: 89: unsigned int temp_x10;
;charge_mgr.c: 91: test_adc = ADC_Sample(18, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	92
	
l6736:	
;charge_mgr.c: 92: if(0xA5 != test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u10241
	goto	u10240
u10241:
	goto	l6740
u10240:
	goto	l509
	line	95
	
l6740:	
;charge_mgr.c: 95: ntcVal = adresult;
	movf	(_adresult+1),w	;volatile
	movwf	(Read_Temperature@ntcVal+1)
	movf	(_adresult),w	;volatile
	movwf	(Read_Temperature@ntcVal)
	line	96
;charge_mgr.c: 96: if(ntcVal < 100 || ntcVal > 3996)
	movlw	0
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u10251
	goto	u10250
u10251:
	goto	l509
u10250:
	
l6742:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u10261
	goto	u10260
u10261:
	goto	l6744
u10260:
	goto	l509
	line	101
	
l6744:	
;charge_mgr.c: 99: {
;charge_mgr.c: 100: unsigned long rt;
;charge_mgr.c: 101: rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	010h
	movwf	(___lldiv@divisor+1)
	movlw	0
	movwf	(___lldiv@divisor)

	movf	(Read_Temperature@ntcVal),w
	movwf	((??_Read_Temperature+0)+0)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((??_Read_Temperature+0)+0+1)
	clrf	((??_Read_Temperature+0)+0+2)
	clrf	((??_Read_Temperature+0)+0+3)
	movf	0+(??_Read_Temperature+0)+0,w
	subwf	(___lldiv@divisor),f
	movf	1+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)+0,w
	goto	u10275
	goto	u10276
u10275:
	subwf	(___lldiv@divisor+1),f
u10276:
	movf	2+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)+0,w
	goto	u10277
	goto	u10278
u10277:
	subwf	(___lldiv@divisor+2),f
u10278:
	movf	3+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)+0,w
	goto	u10279
	goto	u10270
u10279:
	subwf	(___lldiv@divisor+3),f
u10270:

	movf	(Read_Temperature@ntcVal),w
	movwf	(___lmul@multiplier)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	027h
	movwf	(___lmul@multiplicand+1)
	movlw	010h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Read_Temperature@rt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Read_Temperature@rt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@rt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@rt)

	line	102
	
l6746:	
;charge_mgr.c: 102: if(rt >= 10000UL)
		movf	(Read_Temperature@rt+3),w
	btfss	status,2
	goto	u10280
	movf	(Read_Temperature@rt+2),w
	btfss	status,2
	goto	u10280
	movlw	39
	subwf	(Read_Temperature@rt+1),w
	skipz
	goto	u10283
	movlw	16
	subwf	(Read_Temperature@rt),w
	skipz
	goto	u10283
u10283:
	btfss	status,0
	goto	u10281
	goto	u10280

u10281:
	goto	l6752
u10280:
	line	103
	
l6748:	
;charge_mgr.c: 103: temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l6750:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0F0h
	movwf	((??_Read_Temperature+0)+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+3)
	movf	(Read_Temperature@rt),w
	addwf	(??_Read_Temperature+0)+0,f
	movf	(Read_Temperature@rt+1),w
	skipnc
	incfsz	(Read_Temperature@rt+1),w
	goto	u10290
	goto	u10291
u10290:
	addwf	(??_Read_Temperature+0)+1,f
u10291:
	movf	(Read_Temperature@rt+2),w
	skipnc
	incfsz	(Read_Temperature@rt+2),w
	goto	u10292
	goto	u10293
u10292:
	addwf	(??_Read_Temperature+0)+2,f
u10293:
	movf	(Read_Temperature@rt+3),w
	skipnc
	incf	(Read_Temperature@rt+3),w
	addwf	(??_Read_Temperature+0)+3,f
	movf	3+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+3)
	movf	2+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+2)
	movf	1+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+1)
	movf	0+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier)

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(0+(?___lldiv)),w
	subwf	(Read_Temperature@temp_x10),f
	movf	(1+(?___lldiv)),w
	skipc
	decf	(Read_Temperature@temp_x10+1),f
	subwf	(Read_Temperature@temp_x10+1),f
	goto	l6756
	line	105
	
l6752:	
;charge_mgr.c: 104: else
;charge_mgr.c: 105: temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0
	movwf	(___lmul@multiplier+3)
	movlw	0
	movwf	(___lmul@multiplier+2)
	movlw	027h
	movwf	(___lmul@multiplier+1)
	movlw	010h
	movwf	(___lmul@multiplier)

	movf	(Read_Temperature@rt),w
	subwf	(___lmul@multiplier),f
	movf	(Read_Temperature@rt+1),w
	skipc
	incfsz	(Read_Temperature@rt+1),w
	goto	u10305
	goto	u10306
u10305:
	subwf	(___lmul@multiplier+1),f
u10306:
	movf	(Read_Temperature@rt+2),w
	skipc
	incfsz	(Read_Temperature@rt+2),w
	goto	u10307
	goto	u10308
u10307:
	subwf	(___lmul@multiplier+2),f
u10308:
	movf	(Read_Temperature@rt+3),w
	skipc
	incfsz	(Read_Temperature@rt+3),w
	goto	u10309
	goto	u10300
u10309:
	subwf	(___lmul@multiplier+3),f
u10300:

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10)
	
l6754:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10),f
	skipnc
	incf	(Read_Temperature@temp_x10+1),f
	line	106
	
l6756:	
;charge_mgr.c: 106: if(temp_x10 < 100U) temp_x10 = 100U;
	movlw	0
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipnc
	goto	u10311
	goto	u10310
u10311:
	goto	l515
u10310:
	
l6758:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l515:	
	line	107
;charge_mgr.c: 107: if(temp_x10 > 750U) temp_x10 = 750U;
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipc
	goto	u10321
	goto	u10320
u10321:
	goto	l516
u10320:
	
l6760:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)
	movlw	02h
	movwf	((Read_Temperature@temp_x10))+1
	
l516:	
	line	110
;charge_mgr.c: 108: }
;charge_mgr.c: 110: g_temperature = temp_x10;
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(_g_temperature+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(_g_temperature)
	line	111
	
l6762:	
;charge_mgr.c: 111: if((temp_x10 / 10U) >= 60)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u10331
	goto	u10330
u10331:
	goto	l6766
u10330:
	line	112
	
l6764:	
;charge_mgr.c: 112: g_tempProtect = 1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	incf	(_g_tempProtect)^080h,f
	goto	l509
	line	113
	
l6766:	
;charge_mgr.c: 113: else if((temp_x10 / 10U) <= 50)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u10341
	goto	u10340
u10341:
	goto	l509
u10340:
	line	114
	
l6768:	
;charge_mgr.c: 114: g_tempProtect = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	line	117
	
l509:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 245 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  d               2   46[BANK0 ] int 
;;  t               1   45[BANK0 ] unsigned char 
;;  bat_mv_long     4   40[BANK0 ] unsigned long 
;;  tc              1   44[BANK0 ] unsigned char 
;;  vx_mv           4   34[BANK0 ] unsigned long 
;;  v               2   32[BANK0 ] unsigned int 
;;  s               1   29[BANK0 ] unsigned char 
;;  pt              4   25[BANK0 ] unsigned long 
;;  vcc_mv          2   38[BANK0 ] unsigned int 
;;  i               1   48[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/A00
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      28       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      32       0       0       0
;;Total ram usage:       32 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	245
global __ptext11
__ptext11:	;psect for function _Print_SystemStatus
psect	text11
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	245
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 3
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	250
	
l5404:	
;main.c: 247: unsigned char i;
;main.c: 248: unsigned int vcc_mv;
;main.c: 250: uart_send_string("\r\n== L1211 12CH CHARGER ");
	movlw	low(((STR_4)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	251
;main.c: 251: uart_send_string("V55F");
	movlw	low(((STR_5)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	252
;main.c: 252: uart_send_string(" ==\r\n");
	movlw	low(((STR_6)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	255
	
l5406:	
;main.c: 255: test_adc = ADC_Sample(31, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	256
	
l5408:	
;main.c: 256: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u7441
	goto	u7440
u7441:
	goto	l5414
u7440:
	line	258
	
l5410:	
;main.c: 257: {
;main.c: 258: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult),w	;volatile
	movwf	(___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt)

	line	259
	
l5412:	
;main.c: 259: vcc_mv = (unsigned int)pt;
	movf	(Print_SystemStatus@pt+1),w
	movwf	(Print_SystemStatus@vcc_mv+1)
	movf	(Print_SystemStatus@pt),w
	movwf	(Print_SystemStatus@vcc_mv)
	line	260
;main.c: 260: }
	goto	l361
	line	262
	
l5414:	
;main.c: 261: else
;main.c: 262: vcc_mv = 5000;
	movlw	088h
	movwf	(Print_SystemStatus@vcc_mv)
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv))+1
	
l361:	
	line	264
;main.c: 264: g_vcc_mv = vcc_mv;
	movf	(Print_SystemStatus@vcc_mv+1),w
	movwf	(_g_vcc_mv+1)	;volatile
	movf	(Print_SystemStatus@vcc_mv),w
	movwf	(_g_vcc_mv)	;volatile
	line	266
	
l5416:	
;main.c: 266: uart_send_string("VCC=");
	movlw	low(((STR_7)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	267
	
l5418:	
;main.c: 267: uart_send_number(vcc_mv);
	movf	(Print_SystemStatus@vcc_mv+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@vcc_mv),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	268
	
l5420:	
;main.c: 268: uart_send_string("mV T=");
	movlw	low(((STR_8)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	269
	
l5422:	
;main.c: 269: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(_Print_SystemStatus$709+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_Print_SystemStatus$709)
	
l5424:	
;main.c: 269: uart_send_number(g_temperature / 10U);
	movf	(_Print_SystemStatus$709+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$709),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	270
	
l5426:	
;main.c: 270: uart_send_string(".");
	movlw	low(((STR_9)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	271
	
l5428:	
;main.c: 271: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	movwf	(_Print_SystemStatus$710+1)
	movf	(0+(?___lwmod)),w
	movwf	(_Print_SystemStatus$710)
	
l5430:	
;main.c: 271: uart_send_number(g_temperature % 10U);
	movf	(_Print_SystemStatus$710+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$710),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	272
	
l5432:	
;main.c: 272: uart_send_string("C IMP_LOCK=");
	movlw	low(((STR_10)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	273
	
l5434:	
;main.c: 273: uart_send_number(g_impCheckSlot == 0xFF ? 0xFFU : (unsigned int)g_impCheckSlot);
		incf	((_g_impCheckSlot)),w
	btfsc	status,2
	goto	u7451
	goto	u7450
u7451:
	goto	l5438
u7450:
	
l5436:	
	movf	(_g_impCheckSlot),w
	movwf	(_Print_SystemStatus$265)
	clrf	(_Print_SystemStatus$265+1)
	goto	l5440
	
l5438:	
	movlw	0FFh
	movwf	(_Print_SystemStatus$265)
	clrf	(_Print_SystemStatus$265+1)
	
l5440:	
	movf	(_Print_SystemStatus$265+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$265),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	274
	
l5442:	
;main.c: 274: uart_send_string("\r\n");
	movlw	low(((STR_11)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	279
	
l5444:	
;main.c: 279: for(i = 0; i < 12; i++)
	clrf	(Print_SystemStatus@i)
	line	284
	
l5450:	
;main.c: 283: {
;main.c: 284: unsigned int v = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Print_SystemStatus@v)
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)
	line	285
;main.c: 285: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Print_SystemStatus@s)
	line	287
	
l5452:	
;main.c: 287: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	288
	
l5454:	
;main.c: 288: uart_send_number((unsigned int)i + 1U);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@i),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	289
;main.c: 289: uart_send_char('=');
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	290
	
l5456:	
;main.c: 290: uart_send_number(v);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@v+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@v),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	296
	
l5458:	
;main.c: 295: {
;main.c: 296: unsigned long vx_mv = (unsigned long)v * 5000UL / 4096UL;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@v),w
	movwf	(___lmul@multiplier)
	movf	(Print_SystemStatus@v+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv)

	
l5460:	
	movlw	0Ch
u7465:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3),f
	rrf	(Print_SystemStatus@vx_mv+2),f
	rrf	(Print_SystemStatus@vx_mv+1),f
	rrf	(Print_SystemStatus@vx_mv),f
	addlw	-1
	skipz
	goto	u7465

	line	297
	
l5462:	
;main.c: 297: if(vx_mv + 200U >= 5000UL)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+0)+0)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+3)
	movf	(Print_SystemStatus@vx_mv),w
	addwf	(??_Print_SystemStatus+0)+0,f
	movf	(Print_SystemStatus@vx_mv+1),w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1),w
	goto	u7470
	goto	u7471
u7470:
	addwf	(??_Print_SystemStatus+0)+1,f
u7471:
	movf	(Print_SystemStatus@vx_mv+2),w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2),w
	goto	u7472
	goto	u7473
u7472:
	addwf	(??_Print_SystemStatus+0)+2,f
u7473:
	movf	(Print_SystemStatus@vx_mv+3),w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3),w
	addwf	(??_Print_SystemStatus+0)+3,f
		movf	(??_Print_SystemStatus+0)+3,w
	btfss	status,2
	goto	u7480
	movf	(??_Print_SystemStatus+0)+2,w
	btfss	status,2
	goto	u7480
	movlw	19
	subwf	(??_Print_SystemStatus+0)+1,w
	skipz
	goto	u7483
	movlw	136
	subwf	(??_Print_SystemStatus+0)+0,w
	skipz
	goto	u7483
u7483:
	btfss	status,0
	goto	u7481
	goto	u7480

u7481:
	goto	l5466
u7480:
	line	299
	
l5464:	
;main.c: 298: {
;main.c: 299: uart_send_string(" OPEN");
	movlw	low(((STR_12)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	300
;main.c: 300: }
	goto	l5478
	line	303
	
l5466:	
;main.c: 301: else
;main.c: 302: {
;main.c: 303: unsigned long bat_mv_long = 124UL * vx_mv + 206UL * 5000UL;
	movf	(Print_SystemStatus@vx_mv+3),w
	movwf	(___lmul@multiplier+3)
	movf	(Print_SystemStatus@vx_mv+2),w
	movwf	(___lmul@multiplier+2)
	movf	(Print_SystemStatus@vx_mv+1),w
	movwf	(___lmul@multiplier+1)
	movf	(Print_SystemStatus@vx_mv),w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+3)
	movf	(2+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+2)
	movf	(1+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+1)
	movf	(0+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long)

	
l5468:	
	movlw	070h
	addwf	(Print_SystemStatus@bat_mv_long),f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Print_SystemStatus@bat_mv_long+1),f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Print_SystemStatus@bat_mv_long+2),f
	movlw	0
	skipnc
movlw 1
	addwf	(Print_SystemStatus@bat_mv_long+3),f
	line	304
	
l5470:	
;main.c: 304: bat_mv_long = (bat_mv_long + 1000UL/2UL) / 1000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Print_SystemStatus+0)+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+3)
	movf	(Print_SystemStatus@bat_mv_long),w
	addwf	(??_Print_SystemStatus+0)+0,f
	movf	(Print_SystemStatus@bat_mv_long+1),w
	skipnc
	incfsz	(Print_SystemStatus@bat_mv_long+1),w
	goto	u7490
	goto	u7491
u7490:
	addwf	(??_Print_SystemStatus+0)+1,f
u7491:
	movf	(Print_SystemStatus@bat_mv_long+2),w
	skipnc
	incfsz	(Print_SystemStatus@bat_mv_long+2),w
	goto	u7492
	goto	u7493
u7492:
	addwf	(??_Print_SystemStatus+0)+2,f
u7493:
	movf	(Print_SystemStatus@bat_mv_long+3),w
	skipnc
	incf	(Print_SystemStatus@bat_mv_long+3),w
	addwf	(??_Print_SystemStatus+0)+3,f
	movf	3+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+3)
	movf	(2+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+2)
	movf	(1+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+1)
	movf	(0+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long)

	line	305
	
l5472:	
;main.c: 305: uart_send_string(" BAT(");
	movlw	low(((STR_13)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	306
	
l5474:	
;main.c: 306: uart_send_number((unsigned int)bat_mv_long);
	movf	(Print_SystemStatus@bat_mv_long+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@bat_mv_long),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	307
	
l5476:	
;main.c: 307: uart_send_string("mV)");
	movlw	low(((STR_14)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	312
	
l5478:	
;main.c: 308: }
;main.c: 309: }
;main.c: 312: uart_send_char(' ');
	movlw	low(020h)
	fcall	_uart_send_char
	line	313
;main.c: 313: switch(s)
	goto	l5534
	line	315
	
l5480:	
	movlw	low(((STR_15)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5536
	line	317
	
l5482:	
;main.c: 317: uart_send_string("[DET]");
	movlw	low(((STR_16)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	318
	
l5484:	
;main.c: 318: if(g_slotRefV[i] > 0U)
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	((??_Print_SystemStatus+0)+0),w
iorwf	((??_Print_SystemStatus+0)+1),w
	btfsc	status,2
	goto	u7501
	goto	u7500
u7501:
	goto	l5536
u7500:
	line	320
	
l5486:	
;main.c: 319: {
;main.c: 320: uart_send_string(" ref=");
	movlw	low(((STR_17)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	321
	
l5488:	
;main.c: 321: uart_send_number(g_slotRefV[i]);
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(uart_send_number@num)
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	goto	l5536
	line	324
	
l5490:	
	movlw	low(((STR_18)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5536
	line	325
	
l5492:	
	movlw	low(((STR_19)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5536
	line	326
	
l5494:	
	movlw	low(((STR_20)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5536
	line	327
	
l5496:	
	movlw	low(((STR_21)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5536
	line	328
	
l5498:	
	movlw	low(((STR_22)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5536
	line	331
	
l5500:	
;main.c: 330: {
;main.c: 331: unsigned char t = g_slot[(unsigned char)(i)].type;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Print_SystemStatus@t)
	line	332
	
l5502:	
;main.c: 332: if(t == 2 || t == 3)
		movlw	2
	xorwf	((Print_SystemStatus@t)),w
	btfsc	status,2
	goto	u7511
	goto	u7510
u7511:
	goto	l5506
u7510:
	
l5504:	
		movlw	3
	xorwf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u7521
	goto	u7520
u7521:
	goto	l5508
u7520:
	line	333
	
l5506:	
;main.c: 333: uart_send_string("[Dry/NiMH ERR]");
	movlw	low(((STR_23)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5518
	line	334
	
l5508:	
;main.c: 334: else if(t == 1)
		decf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u7531
	goto	u7530
u7531:
	goto	l5512
u7530:
	line	335
	
l5510:	
;main.c: 335: uart_send_string("[Li-ion ERR]");
	movlw	low(((STR_24)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5518
	line	336
	
l5512:	
;main.c: 336: else if(t == 6)
		movlw	6
	xorwf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u7541
	goto	u7540
u7541:
	goto	l5516
u7540:
	line	337
	
l5514:	
;main.c: 337: uart_send_string("[Linear Li ERR]");
	movlw	low(((STR_25)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5518
	line	339
	
l5516:	
;main.c: 338: else
;main.c: 339: uart_send_string("[ERR]");
	movlw	low(((STR_26)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	340
	
l5518:	
;main.c: 340: if(g_slotRefV[i] > 0U)
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	((??_Print_SystemStatus+0)+0),w
iorwf	((??_Print_SystemStatus+0)+1),w
	btfsc	status,2
	goto	u7551
	goto	u7550
u7551:
	goto	l5536
u7550:
	line	342
	
l5520:	
;main.c: 341: {
;main.c: 342: uart_send_string(" ref=");
	movlw	low(((STR_27)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5488
	line	347
	
l5524:	
	movlw	low(((STR_28)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5536
	line	349
	
l5526:	
;main.c: 349: uart_send_string("[DIO]");
	movlw	low(((STR_29)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	350
;main.c: 350: uart_send_string(" pre=");
	movlw	low(((STR_30)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	351
	
l5528:	
;main.c: 351: uart_send_number(g_impData & 0x0FFFU);
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(uart_send_number@num)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(uart_send_number@num)
	fcall	_uart_send_number
	line	352
;main.c: 352: break;
	goto	l5536
	line	353
	
l5530:	
	movlw	low(((STR_31)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5536
	line	313
	
l5534:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@s),w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l5480
	xorlw	1^0	; case 1
	skipnz
	goto	l5482
	xorlw	2^1	; case 2
	skipnz
	goto	l5490
	xorlw	3^2	; case 3
	skipnz
	goto	l5492
	xorlw	4^3	; case 4
	skipnz
	goto	l5494
	xorlw	5^4	; case 5
	skipnz
	goto	l5496
	xorlw	6^5	; case 6
	skipnz
	goto	l5498
	xorlw	7^6	; case 7
	skipnz
	goto	l5500
	xorlw	8^7	; case 8
	skipnz
	goto	l5524
	xorlw	9^8	; case 9
	skipnz
	goto	l5526
	goto	l5530
	opt asmopt_pop

	line	357
	
l5536:	
;main.c: 357: uart_send_string(" ct=");
	movlw	low(((STR_32)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	358
	
l5538:	
;main.c: 358: uart_send_number(g_slot[(unsigned char)(i)].chargeTimer);
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	359
	
l5540:	
;main.c: 359: uart_send_string(" ty=");
	movlw	low(((STR_33)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	360
;main.c: 360: uart_send_number(g_slot[(unsigned char)(i)].type);
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	363
	
l5542:	
;main.c: 363: if(g_diodeTraceCnt > 0U && g_diodeTraceSlot == i)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_g_diodeTraceCnt)),w
	btfsc	status,2
	goto	u7561
	goto	u7560
u7561:
	goto	l5578
u7560:
	
l5544:	
	movf	(_g_diodeTraceSlot),w
	xorwf	(Print_SystemStatus@i),w
	skipz
	goto	u7571
	goto	u7570
u7571:
	goto	l5578
u7570:
	line	366
	
l5546:	
;main.c: 364: {
;main.c: 365: unsigned char tc;
;main.c: 366: uart_send_string(" tr=");
	movlw	low(((STR_34)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_34)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	367
	
l5548:	
;main.c: 367: for(tc = 0; tc < g_diodeTraceCnt; tc++)
	clrf	(Print_SystemStatus@tc)
	goto	l5572
	line	369
	
l5550:	
;main.c: 368: {
;main.c: 369: signed int d = (signed int)g_diodeTrace[tc] - 128;
	movf	(Print_SystemStatus@tc),w
	addlw	low(_g_diodeTrace|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	movwf	(Print_SystemStatus@d)
	clrf	(Print_SystemStatus@d+1)
	
l5552:	
	movlw	-128
	addwf	(Print_SystemStatus@d),f
	skipc
	decf	(Print_SystemStatus@d+1),f
	line	370
	
l5554:	
;main.c: 370: if(d < 0)
	btfss	(Print_SystemStatus@d+1),7
	goto	u7581
	goto	u7580
u7581:
	goto	l5560
u7580:
	line	372
	
l5556:	
;main.c: 371: {
;main.c: 372: uart_send_char('-');
	movlw	low(02Dh)
	fcall	_uart_send_char
	line	373
	
l5558:	
;main.c: 373: d = -d;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	comf	(Print_SystemStatus@d),f
	comf	(Print_SystemStatus@d+1),f
	incf	(Print_SystemStatus@d),f
	skipnz
	incf	(Print_SystemStatus@d+1),f
	line	374
;main.c: 374: }
	goto	l5564
	line	375
	
l5560:	
;main.c: 375: else if(d > 0)
	movf	(Print_SystemStatus@d+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u7595
	movlw	01h
	subwf	(Print_SystemStatus@d),w
u7595:

	skipc
	goto	u7591
	goto	u7590
u7591:
	goto	l5564
u7590:
	line	376
	
l5562:	
;main.c: 376: uart_send_char('+');
	movlw	low(02Bh)
	fcall	_uart_send_char
	line	377
	
l5564:	
;main.c: 377: uart_send_number((unsigned int)d * 4U);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@d+1),w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	(Print_SystemStatus@d),w
	movwf	(??_Print_SystemStatus+0)+0
	clrc
	rlf	(??_Print_SystemStatus+0)+0,f
	rlf	(??_Print_SystemStatus+0)+1,f
	clrc
	rlf	(??_Print_SystemStatus+0)+0,f
	rlf	(??_Print_SystemStatus+0)+1,f
	movf	0+(??_Print_SystemStatus+0)+0,w
	movwf	(uart_send_number@num)
	movf	1+(??_Print_SystemStatus+0)+0,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	378
	
l5566:	
;main.c: 378: if(tc + 1U < g_diodeTraceCnt)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_diodeTraceCnt),w
	movwf	(??_Print_SystemStatus+0)+0
	clrf	(??_Print_SystemStatus+0)+0+1
	movf	(Print_SystemStatus@tc),w
	addlw	low(01h)
	movwf	(??_Print_SystemStatus+2)+0
	movlw	high(01h)
	skipnc
	movlw	(high(01h)+1)&0ffh
	movwf	((??_Print_SystemStatus+2)+0)+1
	movf	1+(??_Print_SystemStatus+0)+0,w
	subwf	1+(??_Print_SystemStatus+2)+0,w
	skipz
	goto	u7605
	movf	0+(??_Print_SystemStatus+0)+0,w
	subwf	0+(??_Print_SystemStatus+2)+0,w
u7605:
	skipnc
	goto	u7601
	goto	u7600
u7601:
	goto	l5570
u7600:
	line	379
	
l5568:	
;main.c: 379: uart_send_char(',');
	movlw	low(02Ch)
	fcall	_uart_send_char
	line	367
	
l5570:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Print_SystemStatus@tc),f
	
l5572:	
	movf	(_g_diodeTraceCnt),w
	subwf	(Print_SystemStatus@tc),w
	skipc
	goto	u7611
	goto	u7610
u7611:
	goto	l5550
u7610:
	line	381
	
l5574:	
;main.c: 380: }
;main.c: 381: g_diodeTraceCnt = 0;
	clrf	(_g_diodeTraceCnt)
	line	382
	
l5576:	
;main.c: 382: g_diodeTraceSlot = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_diodeTraceSlot)
	line	386
	
l5578:	
;main.c: 383: }
;main.c: 386: uart_send_string("\r\n");
	movlw	low(((STR_35)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_35)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	279
	
l5580:	
	incf	(Print_SystemStatus@i),f
	
l5582:	
	movlw	low(0Ch)
	subwf	(Print_SystemStatus@i),w
	skipc
	goto	u7621
	goto	u7620
u7621:
	goto	l5450
u7620:
	line	389
	
l5584:	
;main.c: 388: }
;main.c: 389: uart_send_string("\r\n");
	movlw	low(((STR_36)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_36)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	390
	
l401:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    2[COMMON] unsigned long 
;;  multiplicand    4    6[COMMON] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    0[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    2[COMMON] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/100
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         8       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       4       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext12
__ptext12:	;psect for function ___lmul
psect	text12
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l5158:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l893:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u7181
	goto	u7180
u7181:
	goto	l5162
u7180:
	line	122
	
l5160:	
	movf	(___lmul@multiplicand),w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7191
	addwf	(___lmul@product+1),f
u7191:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7192
	addwf	(___lmul@product+2),f
u7192:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7193
	addwf	(___lmul@product+3),f
u7193:

	line	123
	
l5162:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l5164:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u7201
	goto	u7200
u7201:
	goto	l893
u7200:
	line	128
	
l5166:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l896:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    4[BANK0 ] unsigned long 
;;  dividend        4    8[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   12[BANK0 ] unsigned long 
;;  counter         1   16[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    4[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      13       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Slot_Charge_Ctrl
;;		_Get_Vcc
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext13
__ptext13:	;psect for function ___lldiv
psect	text13
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 4
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l5170:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l5172:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u7211
	goto	u7210
u7211:
	goto	l5192
u7210:
	line	16
	
l5174:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l5178
	line	18
	
l5176:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l5178:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u7221
	goto	u7220
u7221:
	goto	l5176
u7220:
	line	22
	
l5180:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l5182:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u7235
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u7235
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u7235
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u7235:
	skipc
	goto	u7231
	goto	u7230
u7231:
	goto	l5188
u7230:
	line	24
	
l5184:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l5186:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l5188:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l5190:	
	decfsz	(___lldiv@counter),f
	goto	u7241
	goto	u7240
u7241:
	goto	l5180
u7240:
	line	30
	
l5192:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l1168:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    2[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    1[BANK0 ] unsigned char 
;;  j               1    0[BANK0 ] unsigned char 
;;  adsum           4    3[BANK0 ] volatile unsigned long 
;;  ad_temp         2   11[BANK0 ] volatile unsigned int 
;;  admax           2    9[BANK0 ] volatile unsigned int 
;;  admin           2    7[BANK0 ] volatile unsigned int 
;;  i               1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      13       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Get_Vcc
;;		_Adc_Norm
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext14
__ptext14:	;psect for function _ADC_Sample
psect	text14
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(ADC_Sample@adch)
	line	51
	
l5068:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	52
	
l5070:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	58
	
l5072:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u7011
	goto	u7010
u7011:
	goto	l5078
u7010:
	
l5074:	
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u7021
	goto	u7020
u7021:
	goto	l5078
u7020:
	line	60
	
l5076:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??_ADC_Sample+0)+0),f
	u10417:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u10417
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	l5080
	line	64
	
l5078:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	67
	
l5080:	
;adc_drv.c: 67: if(adch & 0x10)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(ADC_Sample@adch),(4)&7
	goto	u7031
	goto	u7030
u7031:
	goto	l425
u7030:
	line	69
	
l5082:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l5084:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(ADC_Sample@adch),f
	line	71
;adc_drv.c: 71: }
	goto	l5086
	line	72
	
l425:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l5086:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@i)
	line	79
	
l5092:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(ADC_Sample@adch),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u7045:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u7045
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l5094:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	6
movwf	((??_ADC_Sample+0)+0),f
	u10427:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u10427
	nop
opt asmopt_pop

	line	81
	
l5096:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l5098:	
;adc_drv.c: 84: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	l429
	
l430:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u7051
	goto	u7050
u7051:
	goto	l429
u7050:
	line	89
	
l5100:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	l432
	line	90
	
l429:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u7061
	goto	u7060
u7061:
	goto	l430
u7060:
	line	93
	
l5104:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
l5106:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
l5108:	
;adc_drv.c: 96: if(0 == admax)
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u7071
	goto	u7070
u7071:
	goto	l5112
u7070:
	line	98
	
l5110:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	100
;adc_drv.c: 100: }
	goto	l435
	line	102
	
l5112:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u7085
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u7085:
	skipnc
	goto	u7081
	goto	u7080
u7081:
	goto	l5116
u7080:
	line	103
	
l5114:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	l435
	line	105
	
l5116:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u7095
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u7095:
	skipnc
	goto	u7091
	goto	u7090
u7091:
	goto	l435
u7090:
	line	106
	
l5118:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	108
	
l435:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7101
	addwf	(ADC_Sample@adsum+1),f	;volatile
u7101:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7102
	addwf	(ADC_Sample@adsum+2),f	;volatile
u7102:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7103
	addwf	(ADC_Sample@adsum+3),f	;volatile
u7103:

	line	76
	
l5120:	
	incf	(ADC_Sample@i),f
	
l5122:	
	movlw	low(022h)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u7111
	goto	u7110
u7111:
	goto	l5092
u7110:
	line	112
	
l5124:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u7125
	goto	u7126
u7125:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u7126:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u7127
	goto	u7128
u7127:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u7128:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u7129
	goto	u7120
u7129:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u7120:

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u7135
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u7135
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u7135
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u7135:
	skipc
	goto	u7131
	goto	u7130
u7131:
	goto	l439
u7130:
	line	114
	
l5126:	
;adc_drv.c: 114: adsum -= admin;
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u7145
	goto	u7146
u7145:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u7146:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u7147
	goto	u7148
u7147:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u7148:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u7149
	goto	u7140
u7149:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u7140:

	goto	l5128
	line	115
	
l439:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	118
	
l5128:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u7155:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u7150:
	addlw	-1
	skipz
	goto	u7155
	movf	1+(??_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
l5130:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
l432:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 224 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	224
global __ptext15
__ptext15:	;psect for function _Print_NtcTemp
psect	text15
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	224
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 3
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	226
	
l5392:	
;main.c: 226: uart_send_string("NTC=");
	movlw	low(((STR_1)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	227
	
l5394:	
;main.c: 227: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$707+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$707)
	
l5396:	
;main.c: 227: uart_send_number(g_temperature / 10U);
	movf	(_Print_NtcTemp$707+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$707),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	228
	
l5398:	
;main.c: 228: uart_send_string(".");
	movlw	low(((STR_2)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	229
	
l5400:	
;main.c: 229: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	movwf	(_Print_NtcTemp$708+1)
	movf	(0+(?___lwmod)),w
	movwf	(_Print_NtcTemp$708)
;main.c: 229: uart_send_number(g_temperature % 10U);
	movf	(_Print_NtcTemp$708+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$708),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	230
	
l5402:	
;main.c: 230: uart_send_string("C\r\n");
	movlw	low(((STR_3)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	231
	
l357:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2    5[COMMON] PTR const unsigned char 
;;		 -> STR_38(10), STR_37(21), STR_36(3), STR_35(3), 
;;		 -> STR_34(5), STR_33(5), STR_32(5), STR_31(6), 
;;		 -> STR_30(6), STR_29(6), STR_28(6), STR_27(6), 
;;		 -> STR_26(6), STR_25(16), STR_24(13), STR_23(15), 
;;		 -> STR_22(7), STR_21(5), STR_20(5), STR_19(6), 
;;		 -> STR_18(6), STR_17(6), STR_16(6), STR_15(7), 
;;		 -> STR_14(4), STR_13(6), STR_12(6), STR_11(3), 
;;		 -> STR_10(12), STR_9(2), STR_8(6), STR_7(5), 
;;		 -> STR_6(6), STR_5(5), STR_4(25), STR_3(4), 
;;		 -> STR_2(2), STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         2       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_main
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
global __ptext16
__ptext16:	;psect for function _uart_send_string
psect	text16
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 4
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l5242:	
;uart_dbg.c: 63: while(*str != '\0')
	goto	l5248
	line	65
	
l5244:	
;uart_dbg.c: 64: {
;uart_dbg.c: 65: uart_send_char(*str++);
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	fcall	_uart_send_char
	
l5246:	
	incf	(uart_send_string@str),f
	skipnz
	incf	(uart_send_string@str+1),f
	line	66
# 66 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
clrwdt ;# 
psect	text16
	line	63
	
l5248:	
	movf	(uart_send_string@str+1),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u7331
	goto	u7330
u7331:
	goto	l5244
u7330:
	line	68
	
l456:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2    0[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    2[BANK0 ] unsigned char [6]
;;  j               1    9[BANK0 ] unsigned char 
;;  i               1    8[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      10       0       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext17
__ptext17:	;psect for function _uart_send_number
psect	text17
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l5250:	
;uart_dbg.c: 79: unsigned char buf[6];
;uart_dbg.c: 80: unsigned char i = 0;
	clrf	(uart_send_number@i)
	line	84
	
l5252:	
;uart_dbg.c: 81: unsigned char j;
;uart_dbg.c: 84: if(num == 0)
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u7341
	goto	u7340
u7341:
	goto	l5264
u7340:
	line	86
	
l5254:	
;uart_dbg.c: 85: {
;uart_dbg.c: 86: uart_send_char('0');
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l460
	line	93
	
l5258:	
;uart_dbg.c: 92: {
;uart_dbg.c: 93: buf[i++] = '0' + (num % 10);
	movf	(uart_send_number@i),w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwmod@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank0
	movwf	indf
	
l5260:	
	incf	(uart_send_number@i),f
	line	94
	
l5262:	
;uart_dbg.c: 94: num /= 10;
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(uart_send_number@num+1)
	movf	(0+(?___lwdiv)),w
	movwf	(uart_send_number@num)
	line	91
	
l5264:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u7351
	goto	u7350
u7351:
	goto	l5258
u7350:
	line	98
	
l5266:	
;uart_dbg.c: 95: }
;uart_dbg.c: 98: for(j = i; j > 0; j--)
	movf	(uart_send_number@i),w
	movwf	(uart_send_number@j)
	
l5268:	
	movf	((uart_send_number@j)),w
	btfss	status,2
	goto	u7361
	goto	u7360
u7361:
	goto	l5272
u7360:
	goto	l460
	line	99
	
l5272:	
;uart_dbg.c: 99: uart_send_char(buf[(unsigned char)(j - 1)]);
	movf	(uart_send_number@j),w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l5274:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decf	(uart_send_number@j),f
	goto	l5268
	line	100
	
l460:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1    3[COMMON] unsigned char 
;;  i               1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          1       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext18
__ptext18:	;psect for function _uart_send_char
psect	text18
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 4
; Regs used in _uart_send_char: [wreg+status,2+status,0]
;uart_send_char@c stored from wreg
	movwf	(uart_send_char@c)
	line	38
	
l5134:	
;uart_dbg.c: 37: unsigned char i;
;uart_dbg.c: 38: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	39
;uart_dbg.c: 39: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l5136:	
;uart_dbg.c: 40: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u10437:
decfsz	(??_uart_send_char+0)+0,f
	goto	u10437
	nop
opt asmopt_pop

	line	41
	
l5138:	
;uart_dbg.c: 41: for(i = 0; i < 8; i++)
	clrf	(uart_send_char@i)
	line	42
	
l446:	
	line	43
;uart_dbg.c: 42: {
;uart_dbg.c: 43: if(c & 0x01)
	btfss	(uart_send_char@c),(0)&7
	goto	u7161
	goto	u7160
u7161:
	goto	l448
u7160:
	line	44
	
l5144:	
;uart_dbg.c: 44: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l5146
	line	45
	
l448:	
	line	46
;uart_dbg.c: 45: else
;uart_dbg.c: 46: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l5146:	
;uart_dbg.c: 47: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u10447:
decfsz	(??_uart_send_char+0)+0,f
	goto	u10447
	nop
opt asmopt_pop

	line	48
	
l5148:	
;uart_dbg.c: 48: c >>= 1;
	clrc
	rrf	(uart_send_char@c),f
	line	41
	
l5150:	
	incf	(uart_send_char@i),f
	
l5152:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u7171
	goto	u7170
u7171:
	goto	l446
u7170:
	
l447:	
	line	50
;uart_dbg.c: 49: }
;uart_dbg.c: 50: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l5154:	
;uart_dbg.c: 51: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u10457:
decfsz	(??_uart_send_char+0)+0,f
	goto	u10457
	nop
opt asmopt_pop

	line	52
	
l5156:	
;uart_dbg.c: 52: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l450:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] unsigned int 
;;  dividend        2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext19
__ptext19:	;psect for function ___lwmod
psect	text19
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l5222:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u7291
	goto	u7290
u7291:
	goto	l5238
u7290:
	line	14
	
l5224:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l5228
	line	16
	
l5226:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l5228:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u7301
	goto	u7300
u7301:
	goto	l5226
u7300:
	line	20
	
l5230:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u7315
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u7315:
	skipc
	goto	u7311
	goto	u7310
u7311:
	goto	l5234
u7310:
	line	21
	
l5232:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l5234:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l5236:	
	decfsz	(___lwmod@counter),f
	goto	u7321
	goto	u7320
u7321:
	goto	l5230
u7320:
	line	25
	
l5238:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1231:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] unsigned int 
;;  dividend        2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    7[COMMON] unsigned int 
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         3       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         7       0       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_Slot_Charge_Ctrl
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext20
__ptext20:	;psect for function ___lwdiv
psect	text20
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 4
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l5196:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l5198:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u7251
	goto	u7250
u7251:
	goto	l5218
u7250:
	line	16
	
l5200:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l5204
	line	18
	
l5202:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l5204:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u7261
	goto	u7260
u7261:
	goto	l5202
u7260:
	line	22
	
l5206:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l5208:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u7275
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u7275:
	skipc
	goto	u7271
	goto	u7270
u7271:
	goto	l5214
u7270:
	line	24
	
l5210:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l5212:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l5214:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l5216:	
	decfsz	(___lwdiv@counter),f
	goto	u7281
	goto	u7280
u7281:
	goto	l5206
u7280:
	line	30
	
l5218:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l1221:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 1267 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    8[BANK0 ] unsigned int 
;;  s               1   20[BANK0 ] unsigned char 
;;  duty            2   17[BANK0 ] int 
;;  error           2   12[BANK0 ] int 
;;  adjust          2    2[BANK0 ] int 
;;  duty_initial    1   16[BANK0 ] unsigned char 
;;  duty_target     1   15[BANK0 ] unsigned char 
;;  maxV            2   10[BANK0 ] unsigned int 
;;  i               1   19[BANK0 ] unsigned char 
;;  cvCount         1   14[BANK0 ] unsigned char 
;;  detectCount     1    7[BANK0 ] unsigned char 
;;  preCount        1    6[BANK0 ] unsigned char 
;;  ccCount         1    5[BANK0 ] unsigned char 
;;  hasCharging     1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      19       0       0       0
;;      Temps:          0       2       0       0       0
;;      Totals:         0      21       0       0       0
;;Total ram usage:       21 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___awdiv
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1267
global __ptext21
__ptext21:	;psect for function _CCCV_Control
psect	text21
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1267
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 4
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1270
	
l6546:	
;charge_mgr.c: 1269: unsigned char i;
;charge_mgr.c: 1270: unsigned char hasCharging = 0;
	clrf	(CCCV_Control@hasCharging)
	line	1271
;charge_mgr.c: 1271: unsigned int maxV = 0;
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	1272
;charge_mgr.c: 1272: unsigned char cvCount = 0;
	clrf	(CCCV_Control@cvCount)
	line	1273
;charge_mgr.c: 1273: unsigned char ccCount = 0;
	clrf	(CCCV_Control@ccCount)
	line	1274
;charge_mgr.c: 1274: unsigned char preCount = 0;
	clrf	(CCCV_Control@preCount)
	line	1275
;charge_mgr.c: 1275: unsigned char detectCount = 0;
	clrf	(CCCV_Control@detectCount)
	line	1278
	
l6548:	
;charge_mgr.c: 1278: if(g_vccProtect)
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u9801
	goto	u9800
u9801:
	goto	l6554
u9800:
	line	1280
	
l6550:	
;charge_mgr.c: 1279: {
;charge_mgr.c: 1280: if(g_vcc_mv >= 4600)
	movlw	011h
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_g_vcc_mv+1),w	;volatile
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv),w	;volatile
	skipc
	goto	u9811
	goto	u9810
u9811:
	goto	l6558
u9810:
	line	1281
	
l6552:	
;charge_mgr.c: 1281: g_vccProtect = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_vccProtect)^080h
	goto	l6558
	line	1285
	
l6554:	
;charge_mgr.c: 1283: else
;charge_mgr.c: 1284: {
;charge_mgr.c: 1285: if(g_vcc_mv < 4400)
	movlw	011h
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_g_vcc_mv+1),w	;volatile
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv),w	;volatile
	skipnc
	goto	u9821
	goto	u9820
u9821:
	goto	l6558
u9820:
	line	1286
	
l6556:	
;charge_mgr.c: 1286: g_vccProtect = 1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_vccProtect)^080h
	incf	(_g_vccProtect)^080h,f
	line	1290
	
l6558:	
;charge_mgr.c: 1287: }
;charge_mgr.c: 1290: if(g_tempProtect || g_vccProtect)
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u9831
	goto	u9830
u9831:
	goto	l6562
u9830:
	
l6560:	
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u9841
	goto	u9840
u9841:
	goto	l6566
u9840:
	line	1292
	
l6562:	
;charge_mgr.c: 1291: {
;charge_mgr.c: 1292: g_pwmDuty = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	1293
;charge_mgr.c: 1293: g_cvIntegral = 0;
	clrf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	l820
	line	1298
	
l6566:	
;charge_mgr.c: 1295: }
;charge_mgr.c: 1298: for(i = 0; i < 12; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(CCCV_Control@i)
	line	1300
	
l6572:	
;charge_mgr.c: 1299: {
;charge_mgr.c: 1300: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	1305
	
l6574:	
;charge_mgr.c: 1302: if(s == 2 || s == 3 ||
;charge_mgr.c: 1303: s == 4 || s == 5 ||
;charge_mgr.c: 1304: s == 8 || s == 1 ||
;charge_mgr.c: 1305: s == 9)
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9851
	goto	u9850
u9851:
	goto	l825
u9850:
	
l6576:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9861
	goto	u9860
u9861:
	goto	l825
u9860:
	
l6578:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9871
	goto	u9870
u9871:
	goto	l825
u9870:
	
l6580:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9881
	goto	u9880
u9881:
	goto	l825
u9880:
	
l6582:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9891
	goto	u9890
u9891:
	goto	l825
u9890:
	
l6584:	
		decf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9901
	goto	u9900
u9901:
	goto	l825
u9900:
	
l6586:	
		movlw	9
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9911
	goto	u9910
u9911:
	goto	l823
u9910:
	
l825:	
	line	1307
;charge_mgr.c: 1306: {
;charge_mgr.c: 1307: hasCharging = 1;
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	1309
	
l6588:	
;charge_mgr.c: 1308: {
;charge_mgr.c: 1309: unsigned int vt = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	1310
	
l6590:	
;charge_mgr.c: 1310: if(vt > maxV) maxV = vt;
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u9925
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u9925:
	skipnc
	goto	u9921
	goto	u9920
u9921:
	goto	l6594
u9920:
	
l6592:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	1312
	
l6594:	
;charge_mgr.c: 1311: }
;charge_mgr.c: 1312: if(s == 5)
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9931
	goto	u9930
u9931:
	goto	l6598
u9930:
	line	1313
	
l6596:	
;charge_mgr.c: 1313: cvCount++;
	incf	(CCCV_Control@cvCount),f
	line	1314
	
l6598:	
;charge_mgr.c: 1314: if(s == 4)
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9941
	goto	u9940
u9941:
	goto	l6602
u9940:
	line	1315
	
l6600:	
;charge_mgr.c: 1315: ccCount++;
	incf	(CCCV_Control@ccCount),f
	line	1316
	
l6602:	
;charge_mgr.c: 1316: if(s == 3 || s == 2)
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9951
	goto	u9950
u9951:
	goto	l6606
u9950:
	
l6604:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9961
	goto	u9960
u9961:
	goto	l6608
u9960:
	line	1317
	
l6606:	
;charge_mgr.c: 1317: preCount++;
	incf	(CCCV_Control@preCount),f
	line	1322
	
l6608:	
;charge_mgr.c: 1321: if(s == 8 || s == 1 ||
;charge_mgr.c: 1322: s == 9)
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9971
	goto	u9970
u9971:
	goto	l6614
u9970:
	
l6610:	
		decf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u9981
	goto	u9980
u9981:
	goto	l6614
u9980:
	
l6612:	
		movlw	9
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u9991
	goto	u9990
u9991:
	goto	l823
u9990:
	line	1323
	
l6614:	
;charge_mgr.c: 1323: detectCount++;
	incf	(CCCV_Control@detectCount),f
	line	1324
	
l823:	
	line	1298
	incf	(CCCV_Control@i),f
	
l6616:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u10001
	goto	u10000
u10001:
	goto	l6572
u10000:
	line	1328
	
l6618:	
;charge_mgr.c: 1324: }
;charge_mgr.c: 1325: }
;charge_mgr.c: 1328: if(!hasCharging)
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u10011
	goto	u10010
u10011:
	goto	l6624
u10010:
	goto	l6562
	line	1341
	
l6624:	
;charge_mgr.c: 1333: }
;charge_mgr.c: 1341: if(detectCount > 0 && cvCount > 0)
	movf	((CCCV_Control@detectCount)),w
	btfsc	status,2
	goto	u10021
	goto	u10020
u10021:
	goto	l6634
u10020:
	
l6626:	
	movf	((CCCV_Control@cvCount)),w
	btfsc	status,2
	goto	u10031
	goto	u10030
u10031:
	goto	l6634
u10030:
	line	1343
	
l6628:	
;charge_mgr.c: 1342: {
;charge_mgr.c: 1343: g_pwmDuty = 25;
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	line	1344
	
l6630:	
;charge_mgr.c: 1344: g_cvIntegral = 0;
	clrf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	l820
	line	1352
	
l6634:	
;charge_mgr.c: 1346: }
;charge_mgr.c: 1352: if(cvCount == 0)
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u10041
	goto	u10040
u10041:
	goto	l6664
u10040:
	line	1356
	
l6636:	
;charge_mgr.c: 1353: {
;charge_mgr.c: 1354: unsigned char duty_target, duty_initial;
;charge_mgr.c: 1356: if(ccCount > 0)
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u10051
	goto	u10050
u10051:
	goto	l6640
u10050:
	line	1359
	
l6638:	
;charge_mgr.c: 1357: {
;charge_mgr.c: 1359: duty_target = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	1360
;charge_mgr.c: 1360: duty_initial = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	1361
;charge_mgr.c: 1361: }
	goto	l6648
	line	1362
	
l6640:	
;charge_mgr.c: 1362: else if(preCount > 0)
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u10061
	goto	u10060
u10061:
	goto	l6644
u10060:
	line	1365
	
l6642:	
;charge_mgr.c: 1363: {
;charge_mgr.c: 1365: duty_target = 8;
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	1366
;charge_mgr.c: 1366: duty_initial = 5;
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	1367
;charge_mgr.c: 1367: }
	goto	l6648
	line	1372
	
l6644:	
;charge_mgr.c: 1368: else
;charge_mgr.c: 1369: {
;charge_mgr.c: 1372: g_pwmDuty = 25;
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	l820
	line	1376
	
l6648:	
;charge_mgr.c: 1374: }
;charge_mgr.c: 1376: if(g_pwmDuty < duty_initial)
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u10071
	goto	u10070
u10071:
	goto	l6656
u10070:
	line	1379
	
l6650:	
;charge_mgr.c: 1377: {
;charge_mgr.c: 1379: g_pwmDuty += 3;
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	1380
	
l6652:	
;charge_mgr.c: 1380: if(g_pwmDuty > duty_initial)
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u10081
	goto	u10080
u10081:
	goto	l820
u10080:
	line	1381
	
l6654:	
;charge_mgr.c: 1381: g_pwmDuty = duty_initial;
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	l820
	line	1383
	
l6656:	
	line	1386
	
l6658:	
;charge_mgr.c: 1384: {
;charge_mgr.c: 1386: g_pwmDuty = duty_target;
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	1387
;charge_mgr.c: 1387: }
	goto	l820
	line	1402
	
l6664:	
;charge_mgr.c: 1394: }
;charge_mgr.c: 1401: {
;charge_mgr.c: 1402: int error = (int)(3100) - (int)(maxV);
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	1405
;charge_mgr.c: 1405: g_cvIntegral += error * 1;
	movf	(CCCV_Control@error),w
	addwf	(_g_cvIntegral),f
	skipnc
	incf	(_g_cvIntegral+1),f
	movf	(CCCV_Control@error+1),w
	addwf	(_g_cvIntegral+1),f
	line	1406
	
l6666:	
;charge_mgr.c: 1406: if(g_cvIntegral > 200)
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u10095
	movlw	0C9h
	subwf	(_g_cvIntegral),w
u10095:

	skipc
	goto	u10091
	goto	u10090
u10091:
	goto	l6670
u10090:
	line	1407
	
l6668:	
;charge_mgr.c: 1407: g_cvIntegral = 200;
	movlw	0C8h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	l6674
	line	1408
	
l6670:	
;charge_mgr.c: 1408: else if(g_cvIntegral < -200)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u10105
	movlw	038h
	subwf	(_g_cvIntegral),w
u10105:

	skipnc
	goto	u10101
	goto	u10100
u10101:
	goto	l6674
u10100:
	line	1409
	
l6672:	
;charge_mgr.c: 1409: g_cvIntegral = -200;
	movlw	038h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	movlw	0FFh
	movwf	((_g_cvIntegral))+1
	line	1412
	
l6674:	
;charge_mgr.c: 1412: int adjust = (error * 4 + g_cvIntegral) / 8;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	movf	(_g_cvIntegral),w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1),w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	1413
	
l6676:	
;charge_mgr.c: 1413: int duty = (int)g_pwmDuty + adjust;
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
l6678:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	1416
	
l6680:	
;charge_mgr.c: 1416: if(duty > 32) duty = 32;
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u10115
	movlw	021h
	subwf	(CCCV_Control@duty),w
u10115:

	skipc
	goto	u10111
	goto	u10110
u10111:
	goto	l6684
u10110:
	
l6682:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1417
	
l6684:	
;charge_mgr.c: 1417: if(duty < 0) duty = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u10121
	goto	u10120
u10121:
	goto	l6688
u10120:
	
l6686:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1419
	
l6688:	
;charge_mgr.c: 1419: g_pwmDuty = (unsigned char)duty;
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	1421
	
l820:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    2[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    4[COMMON] unsigned char 
;;  product         1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Print_SystemStatus
;;		_Slot_Charge_Ctrl
;;		_CCCV_Control
;;		_Update_LED_Global
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext22
__ptext22:	;psect for function ___bmul
psect	text22
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	movwf	(___bmul@multiplier)
	line	6
	
l5308:	
	clrf	(___bmul@product)
	line	43
	
l5310:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u7411
	goto	u7410
u7411:
	goto	l5314
u7410:
	line	44
	
l5312:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l5314:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l5316:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u7421
	goto	u7420
u7421:
	goto	l5310
u7420:
	line	50
	
l5318:	
	movf	(___bmul@product),w
	line	51
	
l902:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] int 
;;  dividend        2    4[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    8[COMMON] int 
;;  sign            1    7[COMMON] unsigned char 
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext23
__ptext23:	;psect for function ___awdiv
psect	text23
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 4
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
l3464:	
	clrf	(___awdiv@sign)
	line	15
	
l3466:	
	btfss	(___awdiv@divisor+1),7
	goto	u3861
	goto	u3860
u3861:
	goto	l3472
u3860:
	line	16
	
l3468:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
l3470:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
l3472:	
	btfss	(___awdiv@dividend+1),7
	goto	u3871
	goto	u3870
u3871:
	goto	l3478
u3870:
	line	20
	
l3474:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
l3476:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
l3478:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
l3480:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u3881
	goto	u3880
u3881:
	goto	l3500
u3880:
	line	25
	
l3482:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	l3486
	line	27
	
l3484:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
l3486:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u3891
	goto	u3890
u3891:
	goto	l3484
u3890:
	line	31
	
l3488:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
l3490:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u3905
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u3905:
	skipc
	goto	u3901
	goto	u3900
u3901:
	goto	l3496
u3900:
	line	33
	
l3492:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
l3494:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
l3496:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
l3498:	
	decfsz	(___awdiv@counter),f
	goto	u3911
	goto	u3910
u3911:
	goto	l3488
u3910:
	line	39
	
l3500:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u3921
	goto	u3920
u3921:
	goto	l3504
u3920:
	line	40
	
l3502:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
l3504:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
l1014:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 158 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		_PowerOnLedSequence
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	158
global __ptext24
__ptext24:	;psect for function _Isr_Timer
psect	text24
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	158
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 3
; Regs used in _Isr_Timer: [wreg+status,2+status,0+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Isr_Timer+0)
	movf	pclath,w
	movwf	(??_Isr_Timer+1)
	ljmp	_Isr_Timer
psect	text24
	line	161
	
i1l4980:	
;main.c: 161: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u689_21
	goto	u689_20
u689_21:
	goto	i1l349
u689_20:
	line	163
	
i1l4982:	
;main.c: 162: {
;main.c: 163: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	164
	
i1l4984:	
;main.c: 164: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(129)^080h	;volatile
	line	165
# 165 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text24
	line	168
	
i1l4986:	
;main.c: 168: g_pwmCounter++;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	169
	
i1l4988:	
;main.c: 169: if(g_pwmCounter >= 32)
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u690_21
	goto	u690_20
u690_21:
	goto	i1l4992
u690_20:
	line	170
	
i1l4990:	
;main.c: 170: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	172
	
i1l4992:	
;main.c: 172: if(g_pwmDuty > 0 && g_pwmCounter < g_pwmDuty)
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u691_21
	goto	u691_20
u691_21:
	goto	i1l346
u691_20:
	
i1l4994:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u692_21
	goto	u692_20
u692_21:
	goto	i1l346
u692_20:
	line	173
	
i1l4996:	
;main.c: 173: RB7 = 1;
	bsf	(55/8),(55)&7	;volatile
	goto	i1l4998
	line	174
	
i1l346:	
	line	175
;main.c: 174: else
;main.c: 175: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	178
	
i1l4998:	
;main.c: 178: if(g_powerOnPhase < 2)
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u693_21
	goto	u693_20
u693_21:
	goto	i1l5004
u693_20:
	line	180
	
i1l5000:	
;main.c: 179: {
;main.c: 180: PowerOnLedSequence();
	fcall	_PowerOnLedSequence
	goto	i1l349
	line	185
	
i1l5004:	
;main.c: 182: }
;main.c: 185: if(g_tempPhase == 0)
	movf	((_g_tempPhase)),w	;volatile
	btfss	status,2
	goto	u694_21
	goto	u694_20
u694_21:
	goto	i1l5016
u694_20:
	line	187
	
i1l5006:	
;main.c: 186: {
;main.c: 187: g_tempReadRoundCnt++;
	incf	(_g_tempReadRoundCnt),f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1),f	;volatile
	line	188
	
i1l5008:	
;main.c: 188: if(g_tempReadRoundCnt >= 200)
	movlw	0
	subwf	(_g_tempReadRoundCnt+1),w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt),w	;volatile
	skipc
	goto	u695_21
	goto	u695_20
u695_21:
	goto	i1l5024
u695_20:
	line	190
	
i1l5010:	
;main.c: 189: {
;main.c: 190: g_tempReadRoundCnt = 0;
	clrf	(_g_tempReadRoundCnt)	;volatile
	clrf	(_g_tempReadRoundCnt+1)	;volatile
	line	191
	
i1l5012:	
;main.c: 191: g_tempPhase = 1;
	movlw	low(01h)
	movwf	(_g_tempPhase)	;volatile
	line	192
	
i1l5014:	
;main.c: 192: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)	;volatile
	clrf	(_g_tempSettleCnt+1)	;volatile
	goto	i1l5024
	line	197
	
i1l5016:	
;main.c: 195: else
;main.c: 196: {
;main.c: 197: g_tempSettleCnt++;
	incf	(_g_tempSettleCnt),f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1),f	;volatile
	line	198
	
i1l5018:	
;main.c: 198: if(g_tempSettleCnt >= 60)
	movlw	0
	subwf	(_g_tempSettleCnt+1),w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt),w	;volatile
	skipc
	goto	u696_21
	goto	u696_20
u696_21:
	goto	i1l5024
u696_20:
	line	200
	
i1l5020:	
;main.c: 199: {
;main.c: 200: g_doNtcRead = 1;
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	201
	
i1l5022:	
;main.c: 201: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)	;volatile
	clrf	(_g_tempSettleCnt+1)	;volatile
	line	202
;main.c: 202: g_tempPhase = 0;
	clrf	(_g_tempPhase)	;volatile
	line	210
	
i1l5024:	
;main.c: 203: }
;main.c: 204: }
;main.c: 210: if(++g_printTick >= 8000)
	incf	(_g_printTick),f	;volatile
	skipnz
	incf	(_g_printTick+1),f	;volatile
	movlw	01Fh
	subwf	((_g_printTick+1)),w	;volatile
	movlw	040h
	skipnz
	subwf	((_g_printTick)),w	;volatile
	skipc
	goto	u697_21
	goto	u697_20
u697_21:
	goto	i1l349
u697_20:
	line	212
	
i1l5026:	
;main.c: 211: {
;main.c: 212: g_printTick = 0;
	clrf	(_g_printTick)	;volatile
	clrf	(_g_printTick+1)	;volatile
	line	213
	
i1l5028:	
;main.c: 213: g_printFlag = 1;
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	217
	
i1l349:	
	movf	(??_Isr_Timer+1),w
	movwf	pclath
	swapf	(??_Isr_Timer+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 80 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	80
global __ptext25
__ptext25:	;psect for function _PowerOnLedSequence
psect	text25
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	80
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	82
	
i1l3578:	
;led.c: 82: g_powerOnTimer++;
	incf	(_g_powerOnTimer),f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1),f	;volatile
	line	84
	
i1l3580:	
;led.c: 84: if(g_powerOnPhase == 0)
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u394_21
	goto	u394_20
u394_21:
	goto	i1l3590
u394_20:
	line	89
	
i1l3582:	
;led.c: 85: {
;led.c: 89: RC5 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	90
;led.c: 90: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	91
	
i1l3584:	
;led.c: 91: if(g_powerOnTimer >= 8000)
	movlw	01Fh
	bcf	status, 6	;RP1=0, select bank0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	040h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u395_21
	goto	u395_20
u395_21:
	goto	i1l878
u395_20:
	line	93
	
i1l3586:	
;led.c: 92: {
;led.c: 93: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	94
	
i1l3588:	
;led.c: 94: g_powerOnPhase = 1;
	movlw	low(01h)
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l878
	line	97
	
i1l3590:	
;led.c: 97: else if(g_powerOnPhase == 1)
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u396_21
	goto	u396_20
u396_21:
	goto	i1l878
u396_20:
	line	100
	
i1l3592:	
;led.c: 98: {
;led.c: 100: RC5 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	101
;led.c: 101: RC4 = 0;
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	102
	
i1l3594:	
;led.c: 102: if(g_powerOnTimer >= 8000)
	movlw	01Fh
	bcf	status, 6	;RP1=0, select bank0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	040h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u397_21
	goto	u397_20
u397_21:
	goto	i1l878
u397_20:
	line	104
	
i1l3596:	
;led.c: 103: {
;led.c: 104: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	105
	
i1l3598:	
;led.c: 105: g_powerOnPhase = 2;
	movlw	low(02h)
	movwf	(_g_powerOnPhase)	;volatile
	line	109
	
i1l878:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
