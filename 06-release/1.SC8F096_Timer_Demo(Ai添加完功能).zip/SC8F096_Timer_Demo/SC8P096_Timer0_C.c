/*-------------------------------------------
  L1211 12槽充电器主程序
  MCU: SC8F096AD832 QFN32
  功能: 12通道恒压锂电池脉冲充电管理
  版本: 2026/06/01 <V2.0>
  
  原理图参考: L1211 TOP V2.0  
  需求参考: requirement_20260518.xlsx
  资源分配参考: resource_allocation.txt
  
  引脚分配:
    B1~B12  MOSFET栅极控制(AO3401 P沟道, Gate=Low导通, Gate=High关闭)
    B1  = RA0/AN0  /PWMA0  (pin31)
    B2  = RA1/AN1  /PWMA1  (pin30)
    B3  = RB3/AN11 /PWMD2  (pin12)
    B4  = RB2/AN10 /PWMD4  (pin13)
    B5  = RA3/AN3  /PWMA3  (pin28)
    B6  = RA2/AN2  /PWMA2  (pin29)
    B7  = RD1/AN23 /PWMD1  (pin22)
    B8  = RD3/AN25 /PWMD3  (pin20)
    B9  = RB0/AN8  /PWMD0  (pin15)
    B10 = RB1/AN9  /PWMD1  (pin14)
    B11 = RD2/AN24 /PWMD2  (pin21)
    B12 = RD0/AN22 /PWMD0  (pin23)
    NTC        : AN21(RC5)    温度检测(CMFA103J3950HANT,10K上拉)
    LED IO1    : RC5           LED电源控制1
    LED IO2    : RC4           LED电源控制2
    PWM        : RA6           PWM总控输出
    CD IO1     : RA4           充电控制1(B1-B6组)
    CD IO2     : RA5           充电控制2(B7-B12组)
    EN         : RA7           主电源使能(Q3 4435)
    VCC_SW     : RC0           电源切换(Q19 SS8050->Q17 9435A)
    UART TX    : RB3           UART发送(调试用,与B3共用RB3)
    UART RX    : RB4           UART接收
    CLK/DAT    : RC3/RC4       ICSP调试接口(与LED IO2共用RC4)
-------------------------------------------*/

#include <sc.h>
#pragma warning disable 752
#pragma warning disable 373

#ifndef _XTAL_FREQ
#define _XTAL_FREQ 16000000
#endif

#define POWER_RATIO        (4096UL*1.2*1000)
#define UART_PRINT_EN      1

#define BATTERY_SLOTS      12

/* 充电状态枚举 */
#define CHG_IDLE           0
#define CHG_DETECT         1
#define CHG_ACTIVATE       2
#define CHG_PRECHARGE      3
#define CHG_CC_CHARGE      4
#define CHG_CV_CHARGE      5
#define CHG_FULL           6
#define CHG_ERROR          7

/* 电池类型 */
#define BAT_TYPE_UNKNOWN   0
#define BAT_TYPE_LI_ION    1
#define BAT_TYPE_NIMH      2
#define BAT_TYPE_DRY       3
#define BAT_TYPE_SHORT     4

/* LED状态 */
#define LED_OFF            0
#define LED_RED_ON         1
#define LED_GREEN_ON       2
#define LED_RED_FLASH      3

/* 电压阈值(ADC原始值, LDO=3V参考, 12位ADC, 分压比1/11)
   电池电压 = ADC值 * 3V / 4096 * 11  */
#define ADC_V_FULL          188  /* 1.52V */
#define ADC_V_OVER          198  /* 1.60V */
#define ADC_V_PRE_MIN       62   /* 0.50V */
#define ADC_V_PRE_MAX       124  /* 1.00V */
#define ADC_V_ACTIVATE      12   /* 0.10V */
#define ADC_V_SHORT         5    /* 0.04V */
#define ADC_V_NIMH_LOW      136  /* 1.10V 镍氢下限 */
#define ADC_V_NIMH_HIGH     161  /* 1.30V 镍氢上限 */

/* 充电时间阈值(Timer0 tick约250us, 4000tick=1s) */
#define TICK_PER_SEC        4000
#define TIME_ACTIVATE_MAX   (60 * TICK_PER_SEC)     /* 激活超时60s */
#define TIME_PRECHARGE_MAX  (300 * TICK_PER_SEC)    /* 预充超时300s(5min) */
#define TIME_CHARGE_MAX     (10800 * TICK_PER_SEC)  /* 充电超时10800s(3h) */
#define TIME_DETECT_WAIT    (2 * TICK_PER_SEC)      /* 检测等待2s */
#define TIME_CV_HOLD        (600 * TICK_PER_SEC)    /* CV恒压保持600s(10min) */

/* 温度保护阈值 */
#define TEMP_STOP           60
#define TEMP_RESUME         50

/* ADC通道定义
   注: B1-B12的ADC通道与MOSFET控制引脚共用同一物理引脚,
   需在扫描时切换模拟/数字模式 */
#define ADC_CH_B1           0
#define ADC_CH_B2           1
#define ADC_CH_B3           11
#define ADC_CH_B4           10
#define ADC_CH_B5           3
#define ADC_CH_B6           2
#define ADC_CH_B7           23
#define ADC_CH_B8           25
#define ADC_CH_B9           8
#define ADC_CH_B10          9
#define ADC_CH_B11          24
#define ADC_CH_B12          22
#define ADC_CH_NTC          21
#define ADC_CH_VREF         31

/* 引脚宏 */
#define PIN_PWM             RA6
#define PIN_CD1             RA4
#define PIN_CD2             RA5
#define PIN_LED_IO1         RC5
#define PIN_LED_IO2         RC4
#define PIN_EN              RA7
#define PIN_VCC_SW          RC0

/* B1-B12 独立MOSFET栅极控制引脚 (AO3401 P沟道: 0=导通充电, 1=关闭)
   B1=RA0/AN0  B2=RA1/AN1  B3=RB3/AN11  B4=RB2/AN10
   B5=RA3/AN3  B6=RA2/AN2  B7=RD1/AN23  B8=RD3/AN25
   B9=RB0/AN8  B10=RB1/AN9 B11=RD2/AN24 B12=RD0/AN22 */
#define PIN_B1_CTRL         RA0
#define PIN_B2_CTRL         RA1
#define PIN_B3_CTRL         RB3
#define PIN_B4_CTRL         RB2
#define PIN_B5_CTRL         RA3
#define PIN_B6_CTRL         RA2
#define PIN_B7_CTRL         RD1
#define PIN_B8_CTRL         RD3
#define PIN_B9_CTRL         RB0
#define PIN_B10_CTRL        RB1
#define PIN_B11_CTRL        RD2
#define PIN_B12_CTRL        RD0

/* 每槽独立MOSFET控制: AO3401 P沟道, 0=导通充电, 1=关闭 */
#define SLOT_CHARGE_ON(idx)    do { \
	switch(idx) { \
	case 0: PIN_B1_CTRL=0; break;  case 1: PIN_B2_CTRL=0; break; \
	case 2: PIN_B3_CTRL=0; break;  case 3: PIN_B4_CTRL=0; break; \
	case 4: PIN_B5_CTRL=0; break;  case 5: PIN_B6_CTRL=0; break; \
	case 6: PIN_B7_CTRL=0; break;  case 7: PIN_B8_CTRL=0; break; \
	case 8: PIN_B9_CTRL=0; break;  case 9: PIN_B10_CTRL=0; break; \
	case 10: PIN_B11_CTRL=0; break; case 11: PIN_B12_CTRL=0; break; \
	} \
} while(0)

#define SLOT_CHARGE_OFF(idx)   do { \
	switch(idx) { \
	case 0: PIN_B1_CTRL=1; break;  case 1: PIN_B2_CTRL=1; break; \
	case 2: PIN_B3_CTRL=1; break;  case 3: PIN_B4_CTRL=1; break; \
	case 4: PIN_B5_CTRL=1; break;  case 5: PIN_B6_CTRL=1; break; \
	case 6: PIN_B7_CTRL=1; break;  case 7: PIN_B8_CTRL=1; break; \
	case 8: PIN_B9_CTRL=1; break;  case 9: PIN_B10_CTRL=1; break; \
	case 10: PIN_B11_CTRL=1; break; case 11: PIN_B12_CTRL=1; break; \
	} \
} while(0)

#define SLOT_ALL_OFF()  do { \
	PIN_B1_CTRL=1; PIN_B2_CTRL=1; PIN_B3_CTRL=1; PIN_B4_CTRL=1; \
	PIN_B5_CTRL=1; PIN_B6_CTRL=1; PIN_B7_CTRL=1; PIN_B8_CTRL=1; \
	PIN_B9_CTRL=1; PIN_B10_CTRL=1; PIN_B11_CTRL=1; PIN_B12_CTRL=1; \
} while(0)

/* 每槽数据结构 */
typedef struct {
	unsigned char type;
	unsigned char state;
	unsigned char ledState;
	unsigned int  voltage;
	unsigned int  chargeTimer;
	unsigned int  blinkTimer;
	unsigned char blinkPhase;
	unsigned int  stableCnt;
	unsigned int  activatePulseCnt;
} BatterySlot_t;

/* 全局变量 */
volatile unsigned int adresult;
volatile unsigned int power_ad;
volatile unsigned char test_adc;

static BatterySlot_t g_slot[BATTERY_SLOTS];

static unsigned int  g_timerTick = 0;
static unsigned int  g_systemTick = 0;
static unsigned int  g_ntcAdc = 0;
static unsigned char g_temperature = 25;
static unsigned char g_tempProtect = 0;
static unsigned char g_scanIndex = 0;
static unsigned char g_scanPhase = 0;
static unsigned int  g_powerOnTimer = 0;
static unsigned char g_powerOnPhase = 0;

unsigned char RxTable[10];
bit RXOK_f;

static const unsigned char s_adcChannels[BATTERY_SLOTS] = {
	ADC_CH_B1, ADC_CH_B2, ADC_CH_B3, ADC_CH_B4,
	ADC_CH_B5, ADC_CH_B6, ADC_CH_B7, ADC_CH_B8,
	ADC_CH_B9, ADC_CH_B10, ADC_CH_B11, ADC_CH_B12
};

typedef struct {
	volatile unsigned char *tris_reg;
	volatile unsigned char *port_reg;
	unsigned char pin_mask;
	volatile unsigned char *ansel_reg;
	unsigned char ansel_mask;
} SlotPinConfig_t;

static const SlotPinConfig_t s_slotPins[BATTERY_SLOTS] = {
	{ &TRISA, &PORTA, 0x01, &ANSEL0, 0x01 },
	{ &TRISA, &PORTA, 0x02, &ANSEL0, 0x02 },
	{ &TRISB, &PORTB, 0x08, &ANSEL1, 0x08 },
	{ &TRISB, &PORTB, 0x04, &ANSEL1, 0x04 },
	{ &TRISA, &PORTA, 0x08, &ANSEL0, 0x08 },
	{ &TRISA, &PORTA, 0x04, &ANSEL0, 0x04 },
	{ &TRISD, &PORTD, 0x02, &ANSEL3, 0x02 },
	{ &TRISD, &PORTD, 0x08, &ANSEL3, 0x08 },
	{ &TRISB, &PORTB, 0x01, &ANSEL1, 0x01 },
	{ &TRISB, &PORTB, 0x02, &ANSEL1, 0x02 },
	{ &TRISD, &PORTD, 0x04, &ANSEL3, 0x04 },
	{ &TRISD, &PORTD, 0x01, &ANSEL3, 0x01 }
};

static void SlotPin_ToAnalog(unsigned char idx)
{
	const SlotPinConfig_t *cfg = &s_slotPins[idx];
	*cfg->ansel_reg |= cfg->ansel_mask;
	*cfg->tris_reg |= cfg->pin_mask;
}

static void SlotPin_ToDigital(unsigned char idx)
{
	const SlotPinConfig_t *cfg = &s_slotPins[idx];
	*cfg->ansel_reg &= ~cfg->ansel_mask;
	*cfg->tris_reg &= ~cfg->pin_mask;
}

/*==========================================================
  ADC 驱动层(保留原始实现)
==========================================================*/
void AD_Init(void)
{
	CC0CON = 0;
	CC1CON = 0;
	ADCON0 = 0X41;
	ADCON1 = 0;
}

unsigned char ADC_Sample(unsigned char adch, unsigned char adldo)
{
	volatile unsigned long adsum = 0;
	volatile unsigned int admin = 0, admax = 0;
	volatile unsigned int ad_temp = 0;

	if ((!LDO_EN) && (adldo & 0x04))
	{
		ADCON1 = adldo;
		__delay_us(100);
	}
	else
		ADCON1 = adldo;

	if(adch & 0x10)
	{
		CHS4 = 1;
		adch &= 0x0f;
	}
	else
		CHS4 = 0;

	unsigned char i = 0;
	for (i = 0; i < 10; i++)
	{
		ADCON0 = (unsigned char)(0X41 | (adch << 2));
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		GODONE = 1;

		unsigned char j = 0;
		while (GODONE)
		{
			__delay_us(2);
			if (0 == (--j))
				return 0;
		}

		ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));

		if (0 == admax)
		{
			admax = ad_temp;
			admin = ad_temp;
		}
		else if (ad_temp > admax)
			admax = ad_temp;
		else if (ad_temp < admin)
			admin = ad_temp;

		adsum += ad_temp;
	}

	adsum -= admax;
	if (adsum >= admin)
		adsum -= admin;
	else
		adsum = 0;

	adresult = adsum >> 3;

	adsum = 0;
	admin = 0;
	admax = 0;
	return 0xA5;
}

unsigned int ADC_ReadChannel(unsigned char ch)
{
	test_adc = ADC_Sample(ch, 7);
	if (0xA5 == test_adc)
		return adresult;

	ADCON0 = 0;
	ADCON1 = 0;
	__delay_us(100);
	return 0;
}

/*==========================================================
  NTC 温度检测
  原理: NTC与10K上拉电阻分压, ADC读取分压值推算温度
  NTC型号: CMFA103J3950HANT (10K@25C, B=3950)
==========================================================*/
unsigned char Read_Temperature(void)
{
	unsigned int ntcVal = ADC_ReadChannel(ADC_CH_NTC);
	unsigned int ntcR;
	unsigned char temp = 25;

	g_ntcAdc = ntcVal;

	if(ntcVal == 0 || ntcVal >= 4095)
		return g_temperature;

	ntcR = (unsigned int)((unsigned long)ntcVal * 10000UL / (4096UL - ntcVal));

	     if(ntcR > 32950) temp = 10;
	else if(ntcR > 27330) temp = 15;
	else if(ntcR > 22060) temp = 20;
	else if(ntcR > 17950) temp = 25;
	else if(ntcR > 14710) temp = 30;
	else if(ntcR > 12120) temp = 35;
	else if(ntcR > 10000) temp = 40;
	else if(ntcR > 8330)  temp = 45;
	else if(ntcR > 6970)  temp = 50;
	else if(ntcR > 5860)  temp = 55;
	else if(ntcR > 4950)  temp = 60;
	else if(ntcR > 4200)  temp = 65;
	else if(ntcR > 3580)  temp = 70;
	else                  temp = 75;

	g_temperature = temp;

	if(temp >= TEMP_STOP)
		g_tempProtect = 1;
	else if(temp <= TEMP_RESUME)
		g_tempProtect = 0;

	return temp;
}

/*==========================================================
  电池类型检测
  通过开路电压判断电池类型:
    ~0V(短路)     -> 短路损坏
    0~0.1V        -> 过放锂电池(需激活)
    0.5~1.0V      -> 正常可充锂电池
    1.1~1.3V      -> 镍氢电池(不充电)
    1.3~1.52V     -> 锂电池(正常充电范围)
==========================================================*/
unsigned char Detect_BatteryType(unsigned int voltage)
{
	if(voltage <= ADC_V_SHORT)
		return BAT_TYPE_SHORT;

	if(voltage <= ADC_V_ACTIVATE)
		return BAT_TYPE_LI_ION;

	if(voltage >= ADC_V_NIMH_LOW && voltage <= ADC_V_NIMH_HIGH)
		return BAT_TYPE_NIMH;

	if(voltage >= ADC_V_PRE_MIN && voltage <= ADC_V_FULL)
		return BAT_TYPE_LI_ION;

	if(voltage > ADC_V_FULL && voltage < ADC_V_OVER)
		return BAT_TYPE_LI_ION;

	return BAT_TYPE_UNKNOWN;
}

/*==========================================================
  单槽充电状态机
  状态转换:
    IDLE -> DETECT(检测2s) -> 
      SHORT/NIMH/UNKNOWN -> ERROR(红灯闪)
      V<=0.1V -> ACTIVATE(脉冲激活,超时60s) -> PRECHARGE
      0.1V<V<0.5V -> PRECHARGE(小电流预充,超时5min) -> CC_CHARGE
      V>=0.5V -> CC_CHARGE(恒流充电,超时3h) -> CV_CHARGE
    CV_CHARGE(恒压保持10min) -> FULL(绿灯常亮)
    任意阶段 V>=1.6V -> ERROR(过充保护)
    FULL后 V跌落 -> CC_CHARGE(补充电)
==========================================================*/
static void ChargeProcess_Slot(unsigned char idx)
{
	BatterySlot_t *p = &g_slot[idx];
	unsigned int v = p->voltage;
	unsigned int tick = 1;

	switch(p->state)
	{
	case CHG_IDLE:
		p->chargeTimer = 0;
		p->stableCnt = 0;
		p->state = CHG_DETECT;
		break;

	case CHG_DETECT:
		p->chargeTimer += tick;
		if(p->chargeTimer < TIME_DETECT_WAIT)
			break;

		p->type = Detect_BatteryType(v);

		if(p->type == BAT_TYPE_SHORT || 
		   p->type == BAT_TYPE_NIMH || 
		   p->type == BAT_TYPE_UNKNOWN)
		{
			p->state = CHG_ERROR;
			break;
		}

		if(v <= ADC_V_ACTIVATE)
		{
			p->state = CHG_ACTIVATE;
			p->chargeTimer = 0;
			p->activatePulseCnt = 0;
		}
		else if(v < ADC_V_PRE_MIN)
		{
			p->state = CHG_PRECHARGE;
			p->chargeTimer = 0;
		}
		else
		{
			p->state = CHG_CC_CHARGE;
			p->chargeTimer = 0;
		}
		break;

	case CHG_ACTIVATE:
		p->chargeTimer += tick;
		if(p->chargeTimer > TIME_ACTIVATE_MAX)
		{
			p->state = CHG_ERROR;
			break;
		}
		if(v > ADC_V_ACTIVATE)
		{
			p->state = CHG_PRECHARGE;
			p->chargeTimer = 0;
			break;
		}
		if(v >= ADC_V_OVER)
		{
			p->state = CHG_ERROR;
			break;
		}
		break;

	case CHG_PRECHARGE:
		p->chargeTimer += tick;
		if(p->chargeTimer > TIME_PRECHARGE_MAX)
		{
			p->state = CHG_ERROR;
			break;
		}
		if(v >= ADC_V_OVER)
		{
			p->state = CHG_ERROR;
			break;
		}
		if(v >= ADC_V_PRE_MAX)
		{
			p->state = CHG_CC_CHARGE;
			p->chargeTimer = 0;
		}
		break;

	case CHG_CC_CHARGE:
		p->chargeTimer += tick;
		if(p->chargeTimer > TIME_CHARGE_MAX)
		{
			p->state = CHG_ERROR;
			break;
		}
		if(v >= ADC_V_OVER)
		{
			p->state = CHG_ERROR;
			break;
		}
		if(v >= ADC_V_FULL)
		{
			p->state = CHG_CV_CHARGE;
			p->chargeTimer = 0;
		}
		break;

	case CHG_CV_CHARGE:
		p->chargeTimer += tick;
		if(v >= ADC_V_OVER)
		{
			p->state = CHG_ERROR;
			break;
		}
		if(p->chargeTimer > TIME_CV_HOLD)
		{
			p->state = CHG_FULL;
		}
		break;

	case CHG_FULL:
		if(v < (ADC_V_FULL - 10))
		{
			p->state = CHG_CC_CHARGE;
			p->chargeTimer = 0;
		}
		break;

	case CHG_ERROR:
		if(v > ADC_V_ACTIVATE && v < ADC_V_OVER && 
		   p->type == BAT_TYPE_LI_ION)
		{
			p->state = CHG_DETECT;
			p->chargeTimer = 0;
		}
		break;

	default:
		p->state = CHG_IDLE;
		break;
	}
}

/*==========================================================
  LED状态更新
  需求12: 充电中->红灯亮, 充满->绿灯常亮, 报错->红灯闪
==========================================================*/
static void Update_LED_Slot(unsigned char idx)
{
	BatterySlot_t *p = &g_slot[idx];

	switch(p->state)
	{
	case CHG_IDLE:
		p->ledState = LED_OFF;
		break;
	case CHG_DETECT:
	case CHG_ACTIVATE:
	case CHG_PRECHARGE:
	case CHG_CC_CHARGE:
	case CHG_CV_CHARGE:
		p->ledState = LED_RED_ON;
		break;
	case CHG_FULL:
		p->ledState = LED_GREEN_ON;
		break;
	case CHG_ERROR:
		p->ledState = LED_RED_FLASH;
		break;
	default:
		p->ledState = LED_OFF;
		break;
	}
}

static void Led_BlinkProcess(void)
{
	unsigned char i;
	for(i = 0; i < BATTERY_SLOTS; i++)
	{
		if(g_slot[i].ledState == LED_RED_FLASH)
		{
			g_slot[i].blinkTimer++;
			if(g_slot[i].blinkTimer >= (TICK_PER_SEC / 2))
			{
				g_slot[i].blinkTimer = 0;
				g_slot[i].blinkPhase ^= 1;
			}
		}
	}
}

/*==========================================================
  充电使能控制(12路独立 + 2组总开关)
  每槽独立控制: 根据各槽充电状态独立打开/关闭对应MOSFET(AO3401)
  组开关: CD IO1/IO2 作为附加的总电源开关, 组内任一槽充电则打开
  温度保护: 触发则关闭所有槽充电
==========================================================*/
static void Charging_Control(void)
{
	unsigned char i;
	unsigned char chargeB1_6 = 0;
	unsigned char chargeB7_12 = 0;

	if(g_tempProtect)
	{
		SLOT_ALL_OFF();
		PIN_CD1 = 0;
		PIN_CD2 = 0;
		PIN_PWM = 0;
		return;
	}

	for(i = 0; i < BATTERY_SLOTS; i++)
	{
		unsigned char s = g_slot[i].state;

		if(s == CHG_ACTIVATE || s == CHG_PRECHARGE ||
		   s == CHG_CC_CHARGE || s == CHG_CV_CHARGE)
		{
			SLOT_CHARGE_ON(i);

			if(i < 6)
				chargeB1_6 = 1;
			else
				chargeB7_12 = 1;
		}
		else
		{
			SLOT_CHARGE_OFF(i);
		}
	}

	PIN_CD1 = chargeB1_6;
	PIN_CD2 = chargeB7_12;

	if(chargeB1_6 || chargeB7_12)
		PIN_PWM = 1;
	else
		PIN_PWM = 0;
}

/*==========================================================
  上电LED自检序列
  需求12: 上电后亮绿灯1秒, 后红灯亮1秒, 最后全灭
==========================================================*/
static void PowerOnLedSequence(void)
{
	g_powerOnTimer++;

	if(g_powerOnPhase == 0)
	{
		PIN_LED_IO1 = 1;
		PIN_LED_IO2 = 1;
		if(g_powerOnTimer >= TICK_PER_SEC)
		{
			g_powerOnTimer = 0;
			g_powerOnPhase = 1;
		}
	}
	else if(g_powerOnPhase == 1)
	{
		if(g_powerOnTimer >= TICK_PER_SEC)
		{
			g_powerOnTimer = 0;
			g_powerOnPhase = 2;
			PIN_LED_IO1 = 0;
			PIN_LED_IO2 = 0;
		}
	}
}

/*==========================================================
  系统初始化
==========================================================*/
void System_Init(void)
{
	unsigned char i;

	asm("nop");
	asm("clrwdt");
	OSCCON = 0x72;
	OPTION_REG = 0x00;
	asm("clrwdt");

	TRISA = 0B00000000;
	PORTA = 0B10001111;
	WPUA = 0B00000000;
	WPDA = 0B00000000;
	IOCA = 0B00000000;

	TRISB = 0B11110000;
	PORTB = 0B00001111;
	WPUB = 0B00000000;
	WPDB = 0B00000000;
	IOCB = 0B00000000;

	TRISC = 0B00001000;
	PORTC = 0B00000001;
	WPUC = 0B00000000;
	WPDC = 0B00000000;

	TRISD = 0B00000000;
	PORTD = 0B00001111;
	WPUD = 0B00000000;
	WPDD = 0B00000000;

	ANSEL0 = 0x00;
	ANSEL1 = 0x00;
	ANSEL2 = 0x00;
	ANSEL3 = 0x00;

	CC0CON = 0;
	CC1CON = 0;
	ADCON0 = 0X41;
	ADCON1 = 0;

	TXSTA1 = 0B10100000;
	RCSTA1 = 0B10010000;
	SPBRG1 = 103;

	TMR0 = 6;
	T0IF = 0;
	T0IE = 1;

	PEIE = 1;
	RC1IE = 1;
	GIE = 1;

	PIN_EN = 1;
	PIN_PWM = 0;
	PIN_CD1 = 0;
	PIN_CD2 = 0;
	PIN_LED_IO1 = 0;
	PIN_LED_IO2 = 0;
	PIN_VCC_SW = 1;

	for(i = 0; i < BATTERY_SLOTS; i++)
	{
		g_slot[i].state = CHG_IDLE;
		g_slot[i].type = BAT_TYPE_UNKNOWN;
		g_slot[i].voltage = 0;
		g_slot[i].chargeTimer = 0;
		g_slot[i].ledState = LED_OFF;
		g_slot[i].blinkTimer = 0;
		g_slot[i].blinkPhase = 0;
		g_slot[i].stableCnt = 0;
		g_slot[i].activatePulseCnt = 0;
	}

	g_scanIndex = 0;
	g_scanPhase = 0;
	g_systemTick = 0;
	g_timerTick = 0;
	g_powerOnTimer = 0;
	g_powerOnPhase = 0;
	g_tempProtect = 0;
	g_temperature = 25;
	RXOK_f = 0;
}

/*==========================================================
  UART调试输出
==========================================================*/
#if UART_PRINT_EN
void uart_send_char(unsigned char c)
{
	while(TRMT1 == 0);
	TXREG1 = c;
}

void uart_send_string(const unsigned char *str)
{
	while(*str != '\0')
		uart_send_char(*str++);
}

void uart_send_number(unsigned int num)
{
	unsigned char buf[6];
	unsigned char i = 0;
	unsigned char j;

	if(num == 0)
	{
		uart_send_char('0');
		return;
	}

	while(num > 0)
	{
		buf[i++] = '0' + (num % 10);
		num /= 10;
	}

	for(j = i; j > 0; j--)
		uart_send_char(buf[j-1]);
}

void Print_Status(void)
{
	unsigned char i;

	uart_send_string("T:");
	uart_send_number(g_temperature);
	uart_send_string("C VDD:");
	uart_send_number(power_ad);
	uart_send_string("mV\r\n");

	for(i = 0; i < BATTERY_SLOTS; i++)
	{
		uart_send_string("B");
		uart_send_number(i + 1);
		uart_send_string(":V=");
		uart_send_number(g_slot[i].voltage);
		uart_send_string(" S=");
		uart_send_number(g_slot[i].state);
		uart_send_string(" T=");
		uart_send_number(g_slot[i].type);

		if(g_slot[i].state == CHG_ERROR)
			uart_send_string(" ERR");
		else if(g_slot[i].state == CHG_FULL)
			uart_send_string(" FULL");
		else if(g_slot[i].state == CHG_CC_CHARGE || 
		        g_slot[i].state == CHG_CV_CHARGE)
			uart_send_string(" CHG");

		uart_send_string("\r\n");
	}
}
#endif

/*==========================================================
  主函数
==========================================================*/
void main(void)
{
	System_Init();

	TXREG1 = 0x55;
	while(TRMT1 == 0);
	TXREG1 = 0xAA;
	while(TRMT1 == 0);

	while(1)
	{
		asm("clrwdt");

		if(RXOK_f == 1)
		{
#if UART_PRINT_EN
			unsigned char i;
			for(i = 0; i < 10; i++)
			{
				while(TRMT1 == 0);
				TXREG1 = RxTable[i];
			}
#endif
			RXOK_f = 0;
		}
	}
}

/*==========================================================
  中断服务(Timer0 + UART)
  每250us触发一次, 采用扫描轮询:
    Phase 0: 读1个槽电压
    Phase 1: 处理该槽状态
    Phase 2: 处理NTC(每轮一次) + LED + 充电控制
  一次完整12槽扫描耗时约 12*3*250us = 9ms
==========================================================*/
void interrupt Interrupt_Isr(void)
{
	if(T0IF)
	{
		TMR0 += 6;
		T0IF = 0;

		g_timerTick++;

		if(g_powerOnPhase < 2)
		{
			PowerOnLedSequence();
		}
		else
		{
			switch(g_scanPhase)
		{
		case 0:
			SlotPin_ToAnalog(g_scanIndex);
			g_slot[g_scanIndex].voltage = 
				ADC_ReadChannel(s_adcChannels[g_scanIndex]);
			SlotPin_ToDigital(g_scanIndex);
			g_scanPhase = 1;
			break;

		case 1:
			ChargeProcess_Slot(g_scanIndex);
			Update_LED_Slot(g_scanIndex);
			g_scanPhase = 2;
			break;

		case 2:
			if(g_scanIndex == 0)
			{
				ANSEL2 |= 0x20;
				TRISC |= 0x20;
				Read_Temperature();
				ANSEL2 &= ~0x20;
				TRISC &= ~0x20;

				Led_BlinkProcess();
				Charging_Control();
			}

				g_scanIndex++;
				if(g_scanIndex >= BATTERY_SLOTS)
				{
					g_scanIndex = 0;
					g_systemTick++;
				}
				g_scanPhase = 0;

				if(g_systemTick >= 4000)
				{
					g_systemTick = 0;

					test_adc = ADC_Sample(ADC_CH_VREF, 0);
					if(0xA5 == test_adc)
					{
						volatile unsigned long power_temp;
						power_temp = (unsigned long)((POWER_RATIO)/adresult);
						power_ad = (unsigned int)(power_temp);
					}
					else
					{
						ADCON0 = 0;
						ADCON1 = 0;
						__delay_us(100);
					}

#if UART_PRINT_EN
					Print_Status();
#endif
				}
				break;

			default:
				g_scanPhase = 0;
				break;
			}
		}
	}

	if(RC1IF == 1)
	{
		static unsigned char RxNum = 0, TEMP;
		RC1IF = 0;

		if(RXOK_f == 0)
		{
			RxTable[RxNum] = RCREG1;
			RxNum++;
			if(RxNum > 9)
			{
				RxNum = 0;
				RXOK_f = 1;
			}
		}
		else
		{
			TEMP = RCREG1;
		}
	}
}