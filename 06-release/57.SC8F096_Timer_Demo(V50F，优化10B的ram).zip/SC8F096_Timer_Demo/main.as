opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ChargeProcess_Slot
	FNCALL	_main,_Do_AdcSample
	FNCALL	_main,_Do_NtcRead
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_System_Init
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_Do_NtcRead,_Read_Temperature
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Do_AdcSample,_ADC_Sample
	FNCALL	_Do_AdcSample,___bmul
	FNCALL	_ChargeProcess_Slot,_ADC_Sample
	FNCALL	_ChargeProcess_Slot,_Detect_BatteryType
	FNCALL	_ChargeProcess_Slot,___bmul
	FNCALL	_ChargeProcess_Slot,___lldiv
	FNCALL	_ChargeProcess_Slot,___lmul
	FNCALL	_ChargeProcess_Slot,___lwdiv
	FNCALL	_ChargeProcess_Slot,___wmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_CCCV_Control
	FNCALL	_Isr_Timer,_Charging_Control
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Update_LED_Slot
	FNCALL	_Isr_Timer,i1_ADC_Sample
	FNCALL	_Isr_Timer,i1___lldiv
	FNCALL	_Charging_Control,i1___bmul
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,i1___bmul
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_temperature
	global	_g_vcc_mv
	global	_g_impCheckSlot
psect	idataBANK0,class=CODE,space=0,delta=2,noexec
global __pidataBANK0
__pidataBANK0:
	file	"charge_mgr.c"
	line	12

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	file	"main.c"
	line	15

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

	file	"charge_mgr.c"
	line	19

;initializer for _g_impCheckSlot
	retlw	0FFh
	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"main.c"
	line	39
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_powerOnTimer
	global	_g_cvIntegral
	global	_g_vccProtect
	global	_g_tempProtect
	global	_g_tempPhase
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_scanPhase
	global	_g_scanIndex
	global	_test_adc
	global	_adresult
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_adcBusy
	global	_g_doAdcSample
	global	_g_stableCnt
	global	_g_detectLowCnt
	global	_g_highVFlag
	global	_g_impData
	global	_g_capFlag
	global	_g_slot
	global	_g_slotRefV
	global	_g_ovCnt
	global	_g_ccBlocks
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_GIE
_GIE	set	0x5F
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RC4
_RC4	set	0x834
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC5
_RC5	set	0x835
	global	_RC3
_RC3	set	0x833
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	0
psect	stringtext
	
STR_33:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_23:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	45	;'-'
	retlw	105	;'i'
	retlw	111	;'o'
	retlw	110	;'n'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	67	;'C'
	retlw	32	;' '
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	95	;'_'
	retlw	76	;'L'
	retlw	79	;'O'
	retlw	67	;'C'
	retlw	75	;'K'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_34:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_8:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_27:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	73	;'I'
	retlw	79	;'O'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_25:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_7:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_29:	
	retlw	32	;' '
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_30:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	53	;'5'
	retlw	48	;'0'
	retlw	69	;'E'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
STR_9	equ	STR_2+0
STR_11	equ	STR_34+7
STR_31	equ	STR_34+7
STR_32	equ	STR_34+7
; #config settings
	file	"main.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssBANK0,class=BANK0,bit,space=1,noexec
global __pbitbssBANK0
__pbitbssBANK0:
_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

_g_adcBusy:
       ds      1

_g_doAdcSample:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_powerOnTimer:
       ds      2

_g_cvIntegral:
       ds      2

_g_vccProtect:
       ds      1

_g_tempProtect:
       ds      1

_g_tempPhase:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_scanPhase:
       ds      1

_g_scanIndex:
       ds      1

_test_adc:
       ds      1

_adresult:
       ds      2

psect	dataBANK0,class=BANK0,space=1,noexec
global __pdataBANK0
__pdataBANK0:
	file	"charge_mgr.c"
	line	12
_g_temperature:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_stableCnt:
       ds      12

_g_detectLowCnt:
       ds      12

_g_highVFlag:
       ds      2

_g_impData:
       ds      2

_g_capFlag:
       ds      2

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"main.c"
	line	15
_g_vcc_mv:
       ds      2

psect	dataBANK1
	file	"charge_mgr.c"
	line	19
_g_impCheckSlot:
       ds      1

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slotRefV:
       ds      24

_g_ovCnt:
       ds      12

_g_ccBlocks:
       ds      12

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"main.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
	fcall	__pidataBANK1+2		;fetch initializer
	movwf	__pdataBANK1+2&07fh		
; Initialize objects allocated to BANK0
	global __pidataBANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	fcall	__pidataBANK0+0		;fetch initializer
	movwf	__pdataBANK0+0&07fh		
	fcall	__pidataBANK0+1		;fetch initializer
	movwf	__pdataBANK0+1&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+030h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+01Eh)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+015h)
	fcall	clear_ram0
; Clear objects allocated to BITBANK0
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssBANK0/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK3,class=BANK3,space=1,noexec
global __pcstackBANK3
__pcstackBANK3:
	global	_Print_SystemStatus$724
_Print_SystemStatus$724:	; 2 bytes @ 0x0
	global	ChargeProcess_Slot@vx_mv_371
ChargeProcess_Slot@vx_mv_371:	; 4 bytes @ 0x0
	ds	2
	global	_Print_SystemStatus$725
_Print_SystemStatus$725:	; 2 bytes @ 0x2
	ds	2
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x4
	global	ChargeProcess_Slot@bat_mv_long_372
ChargeProcess_Slot@bat_mv_long_372:	; 4 bytes @ 0x4
	ds	4
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x8
	global	ChargeProcess_Slot@v_ref
ChargeProcess_Slot@v_ref:	; 2 bytes @ 0x8
	ds	1
	global	_Print_SystemStatus$273
_Print_SystemStatus$273:	; 2 bytes @ 0x9
	ds	1
	global	ChargeProcess_Slot@bat_mv
ChargeProcess_Slot@bat_mv:	; 2 bytes @ 0xA
	ds	1
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0xB
	ds	1
	global	ChargeProcess_Slot@bat_mv_370
ChargeProcess_Slot@bat_mv_370:	; 2 bytes @ 0xC
	ds	1
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0xD
	ds	1
	global	ChargeProcess_Slot@bat_mv_373
ChargeProcess_Slot@bat_mv_373:	; 2 bytes @ 0xE
	ds	3
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0x11
	ds	1
	global	ChargeProcess_Slot@ty
ChargeProcess_Slot@ty:	; 1 bytes @ 0x12
	ds	1
	global	ChargeProcess_Slot@ct
ChargeProcess_Slot@ct:	; 2 bytes @ 0x13
	ds	2
	global	Print_SystemStatus@t
Print_SystemStatus@t:	; 1 bytes @ 0x15
	global	ChargeProcess_Slot@v
ChargeProcess_Slot@v:	; 2 bytes @ 0x15
	ds	1
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x16
	ds	1
	global	ChargeProcess_Slot@idx
ChargeProcess_Slot@idx:	; 1 bytes @ 0x17
	ds	1
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x18
	ds	1
??_main:	; 1 bytes @ 0x19
	ds	2
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
??_ADC_Sample:	; 1 bytes @ 0x0
?_uart_send_string:	; 1 bytes @ 0x0
	global	?___lmul
?___lmul:	; 4 bytes @ 0x0
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x0
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x0
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x0
	global	___wmul@product
___wmul@product:	; 2 bytes @ 0x0
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x0
	ds	1
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x1
	ds	2
?_uart_send_number:	; 1 bytes @ 0x3
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x3
	ds	1
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x4
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x4
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x5
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x5
	ds	1
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x6
	ds	1
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x7
	ds	1
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x8
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x8
	ds	3
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0xB
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0xB
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0xC
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0xC
	ds	1
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0xD
	global	_Print_NtcTemp$722
_Print_NtcTemp$722:	; 2 bytes @ 0xD
	ds	2
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0xF
	global	_Print_NtcTemp$723
_Print_NtcTemp$723:	; 2 bytes @ 0xF
	ds	1
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x10
	ds	1
	global	Do_AdcSample@ch
Do_AdcSample@ch:	; 1 bytes @ 0x11
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x11
	ds	1
	global	Do_AdcSample@ty
Do_AdcSample@ty:	; 1 bytes @ 0x12
	ds	1
	global	Do_AdcSample@dly
Do_AdcSample@dly:	; 1 bytes @ 0x13
	ds	1
	global	Do_AdcSample@st
Do_AdcSample@st:	; 1 bytes @ 0x14
	ds	1
??_Read_Temperature:	; 1 bytes @ 0x15
??_ChargeProcess_Slot:	; 1 bytes @ 0x15
??_Print_SystemStatus:	; 1 bytes @ 0x15
	ds	4
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x19
	ds	1
	global	ChargeProcess_Slot@v_init
ChargeProcess_Slot@v_init:	; 2 bytes @ 0x1A
	ds	2
	global	ChargeProcess_Slot@vx_mv
ChargeProcess_Slot@vx_mv:	; 4 bytes @ 0x1C
	ds	1
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x1D
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x1F
	ds	1
	global	ChargeProcess_Slot@bat_mv_long
ChargeProcess_Slot@bat_mv_long:	; 4 bytes @ 0x20
	ds	4
	global	ChargeProcess_Slot@vx_mv_368
ChargeProcess_Slot@vx_mv_368:	; 4 bytes @ 0x24
	ds	4
	global	ChargeProcess_Slot@bat_mv_long_369
ChargeProcess_Slot@bat_mv_long_369:	; 4 bytes @ 0x28
	ds	4
	global	_ChargeProcess_Slot$374
_ChargeProcess_Slot$374:	; 2 bytes @ 0x2C
	ds	2
	global	ChargeProcess_Slot@st
ChargeProcess_Slot@st:	; 1 bytes @ 0x2E
	ds	1
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Update_LED_Slot:	; 1 bytes @ 0x0
??_Update_LED_Slot:	; 1 bytes @ 0x0
?_Charging_Control:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_ChargeProcess_Slot:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Do_AdcSample:	; 1 bytes @ 0x0
?_Do_NtcRead:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?i1_ADC_Sample:	; 1 bytes @ 0x0
?i1___bmul:	; 1 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	?i1___lldiv
?i1___lldiv:	; 4 bytes @ 0x0
Update_LED_Slot@idx:	; 1 bytes @ 0x0
	global	i1ADC_Sample@adldo
i1ADC_Sample@adldo:	; 1 bytes @ 0x0
	global	i1___bmul@multiplicand
i1___bmul@multiplicand:	; 1 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	global	i1___lldiv@divisor
i1___lldiv@divisor:	; 4 bytes @ 0x0
	ds	1
??i1_ADC_Sample:	; 1 bytes @ 0x1
??i1___bmul:	; 1 bytes @ 0x1
	global	i1___bmul@multiplier
i1___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
	global	i1___bmul@product
i1___bmul@product:	; 1 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_Charging_Control:	; 1 bytes @ 0x3
	global	Charging_Control@chargeB1_6
Charging_Control@chargeB1_6:	; 1 bytes @ 0x3
	ds	1
??___awdiv:	; 1 bytes @ 0x4
	global	Charging_Control@chargeB7_12
Charging_Control@chargeB7_12:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	global	i1___lldiv@dividend
i1___lldiv@dividend:	; 4 bytes @ 0x4
	ds	1
	global	Charging_Control@s
Charging_Control@s:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	ds	1
	global	Charging_Control@i
Charging_Control@i:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	2
??_CCCV_Control:	; 1 bytes @ 0x8
??i1___lldiv:	; 1 bytes @ 0x8
	global	i1___lldiv@counter
i1___lldiv@counter:	; 1 bytes @ 0x8
	ds	1
	global	i1___lldiv@quotient
i1___lldiv@quotient:	; 4 bytes @ 0x9
	ds	4
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	i1ADC_Sample@adch
i1ADC_Sample@adch:	; 1 bytes @ 0x0
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x0
	ds	1
	global	i1ADC_Sample@j
i1ADC_Sample@j:	; 1 bytes @ 0x1
	ds	1
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x2
	global	i1ADC_Sample@i
i1ADC_Sample@i:	; 1 bytes @ 0x2
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x3
	global	i1ADC_Sample@adsum
i1ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0x4
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0x5
	ds	1
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x6
	ds	1
	global	i1ADC_Sample@admin
i1ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x8
	ds	1
	global	i1ADC_Sample@admax
i1ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	1
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xA
	ds	1
	global	i1ADC_Sample@ad_temp
i1ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0xC
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0xD
	ds	1
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0xE
	ds	2
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x10
	ds	1
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x11
	ds	1
??_Isr_Timer:	; 1 bytes @ 0x12
	ds	4
	global	Isr_Timer@pt
Isr_Timer@pt:	; 4 bytes @ 0x16
	ds	4
??_AD_Init:	; 1 bytes @ 0x1A
??_uart_init:	; 1 bytes @ 0x1A
?_ADC_Sample:	; 1 bytes @ 0x1A
??_uart_send_char:	; 1 bytes @ 0x1A
?_Detect_BatteryType:	; 1 bytes @ 0x1A
??___lmul:	; 1 bytes @ 0x1A
?___bmul:	; 1 bytes @ 0x1A
	global	?___wmul
?___wmul:	; 2 bytes @ 0x1A
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x1A
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x1A
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x1A
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x1A
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x1A
	global	___wmul@multiplier
___wmul@multiplier:	; 2 bytes @ 0x1A
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x1A
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x1A
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x1A
	ds	1
??___bmul:	; 1 bytes @ 0x1B
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x1B
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x1B
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x1C
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x1C
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x1C
	global	___wmul@multiplicand
___wmul@multiplicand:	; 2 bytes @ 0x1C
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x1C
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x1C
	ds	1
??_uart_send_string:	; 1 bytes @ 0x1D
??_System_Init:	; 1 bytes @ 0x1D
??_Do_AdcSample:	; 1 bytes @ 0x1D
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x1D
	ds	1
??_uart_send_number:	; 1 bytes @ 0x1E
??_Do_NtcRead:	; 1 bytes @ 0x1E
??_Print_NtcTemp:	; 1 bytes @ 0x1E
??___wmul:	; 1 bytes @ 0x1E
??___lldiv:	; 1 bytes @ 0x1E
??___lwdiv:	; 1 bytes @ 0x1E
??___lwmod:	; 1 bytes @ 0x1E
;!
;!Data Sizes:
;!    Strings     237
;!    Constant    12
;!    Data        5
;!    BSS         171
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     13      13
;!    BANK0            80     30      54
;!    BANK1            80     47      80
;!    BANK3            80     27      75
;!    BANK2            80      0      72

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 25
;!		 -> STR_34(CODE[10]), STR_33(CODE[21]), STR_32(CODE[3]), STR_31(CODE[3]), 
;!		 -> STR_30(CODE[5]), STR_29(CODE[5]), STR_28(CODE[6]), STR_27(CODE[6]), 
;!		 -> STR_26(CODE[6]), STR_25(CODE[6]), STR_24(CODE[16]), STR_23(CODE[13]), 
;!		 -> STR_22(CODE[15]), STR_21(CODE[7]), STR_20(CODE[5]), STR_19(CODE[5]), 
;!		 -> STR_18(CODE[6]), STR_17(CODE[6]), STR_16(CODE[6]), STR_15(CODE[7]), 
;!		 -> STR_14(CODE[4]), STR_13(CODE[6]), STR_12(CODE[6]), STR_11(CODE[3]), 
;!		 -> STR_10(CODE[12]), STR_9(CODE[2]), STR_8(CODE[6]), STR_7(CODE[5]), 
;!		 -> STR_6(CODE[6]), STR_5(CODE[5]), STR_4(CODE[25]), STR_3(CODE[4]), 
;!		 -> STR_2(CODE[2]), STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->i1___lldiv
;!    _Charging_Control->i1___bmul
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Do_AdcSample
;!    _main->_System_Init
;!    _System_Init->___bmul
;!    _Print_SystemStatus->___lmul
;!    _Print_SystemStatus->___lwdiv
;!    _Print_SystemStatus->___lwmod
;!    _Print_NtcTemp->___lwdiv
;!    _Print_NtcTemp->___lwmod
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _uart_send_number->___lwmod
;!    _Read_Temperature->___lmul
;!    _Read_Temperature->___lwdiv
;!    _Do_AdcSample->___bmul
;!    _ChargeProcess_Slot->___lmul
;!    _ChargeProcess_Slot->___lwdiv
;!    _ChargeProcess_Slot->___wmul
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    _Isr_Timer->_CCCV_Control
;!
;!Critical Paths under _main in BANK1
;!
;!    _main->_ChargeProcess_Slot
;!    _Print_SystemStatus->___lldiv
;!    _Print_NtcTemp->_uart_send_number
;!    _uart_send_number->___lwdiv
;!    _Do_NtcRead->_Read_Temperature
;!    _Read_Temperature->___lldiv
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->___lldiv
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    _main->_Print_SystemStatus
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 2     2      0   62779
;!                                             25 BANK3      2     2      0
;!                 _ChargeProcess_Slot
;!                       _Do_AdcSample
;!                         _Do_NtcRead
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                        _System_Init
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1533
;!                                             29 BANK0      1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  33    33      0   15852
;!                                             21 BANK1      8     8      0
;!                                              0 BANK3     25    25      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    7481
;!                                             13 BANK1      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    2878
;!                                              0 BANK1      2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_number                                    10     8      2    3051
;!                                              3 BANK1     10     8      2
;!                             ___bmul (ARG)
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     102
;!                                             26 BANK0      3     3      0
;! ---------------------------------------------------------------------------------
;! (3) ___lwmod                                              5     1      4     518
;!                                             26 BANK0      4     0      4
;!                                              0 BANK1      1     1      0
;! ---------------------------------------------------------------------------------
;! (1) _Do_NtcRead                                           0     0      0    7394
;!                   _Read_Temperature
;! ---------------------------------------------------------------------------------
;! (2) _Read_Temperature                                    12    12      0    7394
;!                                             21 BANK1     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (1) _Do_AdcSample                                         5     5      0    3437
;!                                             29 BANK0      1     1      0
;!                                             17 BANK1      4     4      0
;!                         _ADC_Sample
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _ChargeProcess_Slot                                  50    50      0   24204
;!                                             21 BANK1     26    26      0
;!                                              0 BANK3     24    24      0
;!                         _ADC_Sample
;!                 _Detect_BatteryType
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (2) ___wmul                                               6     2      4    2744
;!                                             26 BANK0      4     0      4
;!                                              0 BANK1      2     2      0
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4    1010
;!                                             26 BANK0      4     0      4
;!                                              0 BANK1      3     3      0
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8    2762
;!                                             26 BANK0      4     4      0
;!                                              0 BANK1      8     0      8
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1554
;!                                              8 BANK1     13     5      8
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1    1185
;!                                             26 BANK0      3     2      1
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     331
;!                                             26 BANK0      2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _ADC_Sample                                          18    17      1    1508
;!                                             26 BANK0      1     0      1
;!                                              0 BANK1     17    17      0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 3
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            8     8      0    3961
;!                                             18 BANK0      8     8      0
;!                       _CCCV_Control
;!                   _Charging_Control
;!                 _PowerOnLedSequence
;!                    _Update_LED_Slot
;!                       i1_ADC_Sample
;!                          i1___lldiv
;! ---------------------------------------------------------------------------------
;! (5) i1___lldiv                                           13     5      8      44
;!                                              0 COMMON    13     5      8
;! ---------------------------------------------------------------------------------
;! (5) i1_ADC_Sample                                        18    17      1     805
;!                                              0 COMMON     5     4      1
;!                                              0 BANK0     13    13      0
;! ---------------------------------------------------------------------------------
;! (5) _Update_LED_Slot                                      1     1      0       0
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Charging_Control                                     4     4      0     797
;!                                              3 COMMON     4     4      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _CCCV_Control                                        20    20      0    2267
;!                                              8 COMMON     2     2      0
;!                                              0 BANK0     18    18      0
;!                            ___awdiv
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (6) i1___bmul                                             3     2      1     125
;!                                              0 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (6) ___awdiv                                              8     4      4     606
;!                                              0 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ChargeProcess_Slot
;!     _ADC_Sample
;!     _Detect_BatteryType
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___wmul
;!   _Do_AdcSample
;!     _ADC_Sample
;!     ___bmul
;!   _Do_NtcRead
;!     _Read_Temperature
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!       ___lwdiv
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     i1___bmul
;!   _Charging_Control
;!     i1___bmul
;!   _PowerOnLedSequence
;!   _Update_LED_Slot
;!   i1_ADC_Sample
;!   i1___lldiv
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50     1B      4B       8       93.8%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      0      48      10       90.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50     2F      50       6      100.0%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     1E      36       4       67.5%
;!BITBANK0            50      0       1       3        1.3%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      D       D       1       92.9%
;!BITCOMMON            E      0       0       0        0.0%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     126      12        0.0%
;!ABS                  0      0     126      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 490 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       2       0
;;      Totals:         0       0       0       2       0
;;Total ram usage:        2 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ChargeProcess_Slot
;;		_Do_AdcSample
;;		_Do_NtcRead
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_System_Init
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"main.c"
	line	490
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"main.c"
	line	490
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	493
	
l8141:	
	opt asmopt_push
opt asmopt_off
movlw	52
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
movwf	((??_main+0)^0180h+0+1),f
	movlw	241
movwf	((??_main+0)^0180h+0),f
	u13077:
decfsz	((??_main+0)^0180h+0),f
	goto	u13077
	decfsz	((??_main+0)^0180h+0+1),f
	goto	u13077
opt asmopt_pop

	line	494
# 494 "main.c"
clrwdt ;# 
psect	maintext
	line	497
	
l8143:	
	fcall	_System_Init
	line	500
	
l8145:	
	movlw	low(((STR_33)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	501
	
l8147:	
	movlw	low(((STR_34)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_34)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	504
	
l448:	
	line	506
# 506 "main.c"
clrwdt ;# 
psect	maintext
	line	509
	
l8149:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u13041
	goto	u13040
u13041:
	goto	l8159
u13040:
	line	511
	
l8151:	
	bcf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	line	512
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	513
	
l8153:	
	fcall	_Do_AdcSample
	line	514
	
l8155:	
	movf	(_g_scanIndex),w	;volatile
	fcall	_ChargeProcess_Slot
	line	516
	
l8157:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	520
	
l8159:	
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u13051
	goto	u13050
u13051:
	goto	l8167
u13050:
	line	522
	
l8161:	
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	523
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	524
	
l8163:	
	fcall	_Do_NtcRead
	line	525
	
l8165:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	529
	
l8167:	
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u13061
	goto	u13060
u13061:
	goto	l448
u13060:
	line	531
	
l8169:	
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	532
	
l8171:	
	fcall	_Print_SystemStatus
	line	533
	fcall	_Print_NtcTemp
	goto	l448
	global	start
	ljmp	start
	opt stack 0
	line	536
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 60 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   29[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	60
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"main.c"
	line	60
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	65
	
l6831:	
# 65 "main.c"
nop ;# 
	line	66
# 66 "main.c"
clrwdt ;# 
psect	text1
	line	67
	
l6833:	
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	71
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	72
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	73
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l6835:	
	clrf	(262)^0100h	;volatile
	line	74
	
l6837:	
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l6839:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	77
	
l6841:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l6843:	
	clrf	(135)^080h	;volatile
	line	78
	
l6845:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l6847:	
	clrf	(7)	;volatile
	line	79
	
l6849:	
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	80
	
l6851:	
	clrf	(277)^0100h	;volatile
	line	83
	
l6853:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l6855:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	86
	
l6857:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	87
	
l6859:	
	clrf	(406)^0180h	;volatile
	line	94
	
l6861:	
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	95
	
l6863:	
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	96
	
l6865:	
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	97
	
l6867:	
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	100
	
l6869:	
	fcall	_AD_Init
	line	103
	
l6871:	
	fcall	_uart_init
	line	110
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	111
	
l6873:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	112
	
l6875:	
	bcf	(90/8),(90)&7	;volatile
	line	113
	
l6877:	
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	116
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	117
	clrf	(_g_pwmCounter)	;volatile
	line	118
	
l6879:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	119
	
l6881:	
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	120
	
l6883:	
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	121
	
l6885:	
	bcf	(55/8),(55)&7	;volatile
	line	124
	clrf	(System_Init@i)
	line	126
	
l6891:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	127
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	128
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	129
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	130
	
l6893:	
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	131
	
l6895:	
	movf	(System_Init@i),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	124
	
l6897:	
	incf	(System_Init@i),f
	
l6899:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u10531
	goto	u10530
u10531:
	goto	l6891
u10530:
	line	135
	
l339:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"uart_dbg.c"
	line	21
global __ptext2
__ptext2:	;psect for function _uart_init
psect	text2
	file	"uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_init: []
	line	23
	
l3143:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l484:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	23
global __ptext3
__ptext3:	;psect for function _AD_Init
psect	text3
	file	"adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l3137:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
	clrf	(406)^0180h	;volatile
	line	27
	
l3139:	
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l3141:	
	clrf	(150)^080h	;volatile
	line	29
	
l461:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 364 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  t               1   21[BANK3 ] unsigned char 
;;  bat_mv_long     4   17[BANK3 ] unsigned long 
;;  vx_mv           4   13[BANK3 ] unsigned long 
;;  v               2   11[BANK3 ] unsigned int 
;;  s               1    8[BANK3 ] unsigned char 
;;  pt              4    4[BANK3 ] unsigned long 
;;  vcc_mv          2   22[BANK3 ] unsigned int 
;;  i               1   24[BANK3 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0      25       0
;;      Temps:          0       0       8       0       0
;;      Totals:         0       0       8      25       0
;;Total ram usage:       33 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	364
global __ptext4
__ptext4:	;psect for function _Print_SystemStatus
psect	text4
	file	"main.c"
	line	364
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	369
	
l7147:	
	movlw	low(((STR_4)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	370
	movlw	low(((STR_5)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	371
	movlw	low(((STR_6)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	374
	
l7149:	
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	375
	
l7151:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u11081
	goto	u11080
u11081:
	goto	l7157
u11080:
	line	377
	
l7153:	
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@pt+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@pt+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@pt+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@pt)^0180h

	line	378
	
l7155:	
	movf	(Print_SystemStatus@pt+1)^0180h,w
	movwf	(Print_SystemStatus@vcc_mv+1)^0180h
	movf	(Print_SystemStatus@pt)^0180h,w
	movwf	(Print_SystemStatus@vcc_mv)^0180h
	line	379
	goto	l412
	line	381
	
l7157:	
	movlw	088h
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@vcc_mv)^0180h
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv)^0180h)+1
	
l412:	
	line	383
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_vcc_mv+1)^080h	;volatile
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_vcc_mv)^080h	;volatile
	line	385
	
l7159:	
	movlw	low(((STR_7)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	386
	
l7161:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	387
	
l7163:	
	movlw	low(((STR_8)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	388
	
l7165:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(_Print_SystemStatus$724+1)^0180h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(_Print_SystemStatus$724)^0180h
	
l7167:	
	movf	(_Print_SystemStatus$724+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(_Print_SystemStatus$724)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	389
	
l7169:	
	movlw	low(((STR_9)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	390
	
l7171:	
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(_Print_SystemStatus$725+1)^0180h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(0+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(_Print_SystemStatus$725)^0180h
	
l7173:	
	movf	(_Print_SystemStatus$725+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(_Print_SystemStatus$725)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	391
	
l7175:	
	movlw	low(((STR_10)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	392
	
l7177:	
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u11091
	goto	u11090
u11091:
	goto	l7181
u11090:
	
l7179:	
	movf	(_g_impCheckSlot)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(_Print_SystemStatus$273)^0180h
	clrf	(_Print_SystemStatus$273+1)^0180h
	goto	l7183
	
l7181:	
	movlw	0FFh
	bsf	status, 6	;RP1=1, select bank3
	movwf	(_Print_SystemStatus$273)^0180h
	clrf	(_Print_SystemStatus$273+1)^0180h
	
l7183:	
	movf	(_Print_SystemStatus$273+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(_Print_SystemStatus$273)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	393
	
l7185:	
	movlw	low(((STR_11)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	400
	
l7187:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(Print_SystemStatus@i)^0180h
	line	406
	
l7193:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@v)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)^0180h
	line	407
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@s)^0180h
	line	409
	
l7195:	
	movlw	low(042h)
	fcall	_uart_send_char
	line	410
	
l7197:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	incf	(uart_send_number@num)^080h,f
	skipnz
	incf	(uart_send_number@num+1)^080h,f
	fcall	_uart_send_number
	line	411
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	412
	
l7199:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	418
	
l7201:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@vx_mv+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@vx_mv+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@vx_mv+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@vx_mv)^0180h

	
l7203:	
	movlw	0Ch
u11105:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3)^0180h,f
	rrf	(Print_SystemStatus@vx_mv+2)^0180h,f
	rrf	(Print_SystemStatus@vx_mv+1)^0180h,f
	rrf	(Print_SystemStatus@vx_mv)^0180h,f
	addlw	-1
	skipz
	goto	u11105

	line	419
	
l7205:	
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+0)^080h+0)
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	clrf	((??_Print_SystemStatus+0)^080h+0+2)
	clrf	((??_Print_SystemStatus+0)^080h+0+3)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+4)^080h+0)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vx_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_Print_SystemStatus+4)^080h+0,f
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vx_mv+1)^0180h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1)^0180h,w
	goto	u11110
	goto	u11111
u11110:
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_Print_SystemStatus+4)^080h+1,f
u11111:
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vx_mv+2)^0180h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2)^0180h,w
	goto	u11112
	goto	u11113
u11112:
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_Print_SystemStatus+4)^080h+2,f
u11113:
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vx_mv+3)^0180h,w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_Print_SystemStatus+4)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	subwf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u11125
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	subwf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u11125
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	subwf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u11125
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	subwf	0+(??_Print_SystemStatus+4)^080h+0,w
u11125:
	skipc
	goto	u11121
	goto	u11120
u11121:
	goto	l7209
u11120:
	line	421
	
l7207:	
	movlw	low(((STR_12)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	422
	goto	l7219
	line	425
	
l7209:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vx_mv+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier+3)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vx_mv+2)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier+2)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vx_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vx_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long)^0180h

	line	426
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	(3+(?___lmul))^080h,w
	skipz
	goto	u11135
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long+2)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	(2+(?___lmul))^080h,w
	skipz
	goto	u11135
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	(1+(?___lmul))^080h,w
	skipz
	goto	u11135
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	(0+(?___lmul))^080h,w
u11135:
	skipnc
	goto	u11131
	goto	u11130
u11131:
	goto	l7219
u11130:
	line	428
	
l7211:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+3)
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+1)^080h
	movlw	032h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	addwf	(Print_SystemStatus@bat_mv_long)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+4)^080h+0+0)
	movlw	0
	skipnc
	movlw	1
	addwf	(1+(?___lmul))^080h,w
	clrf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	bsf	status, 6	;RP1=1, select bank3
	addwf	(Print_SystemStatus@bat_mv_long+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	movf	(2+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+2),w
	clrf	((??_Print_SystemStatus+4)^080h+0+3)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	bsf	status, 6	;RP1=1, select bank3
	addwf	(Print_SystemStatus@bat_mv_long+2)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	movf	(3+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+3),w
	bsf	status, 6	;RP1=1, select bank3
	addwf	(Print_SystemStatus@bat_mv_long+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	0+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+0,f
	movf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	1+(??_Print_SystemStatus+4)^080h+0,w
	goto	u11140
	goto	u11141
u11140:
	addwf	(??_Print_SystemStatus+0)^080h+1,f
u11141:
	movf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	2+(??_Print_SystemStatus+4)^080h+0,w
	goto	u11142
	goto	u11143
u11142:
	addwf	(??_Print_SystemStatus+0)^080h+2,f
u11143:
	movf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incf	3+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long)^0180h

	line	429
	
l7213:	
	movlw	low(((STR_13)|8000h))
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	430
	
l7215:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	431
	
l7217:	
	movlw	low(((STR_14)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	438
	
l7219:	
	movlw	low(020h)
	fcall	_uart_send_char
	line	439
	goto	l7261
	line	441
	
l7221:	
	movlw	low(((STR_15)|8000h))
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7263
	line	442
	
l7223:	
	movlw	low(((STR_16)|8000h))
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7263
	line	443
	
l7225:	
	movlw	low(((STR_17)|8000h))
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7263
	line	444
	
l7227:	
	movlw	low(((STR_18)|8000h))
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7263
	line	445
	
l7229:	
	movlw	low(((STR_19)|8000h))
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7263
	line	446
	
l7231:	
	movlw	low(((STR_20)|8000h))
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7263
	line	447
	
l7233:	
	movlw	low(((STR_21)|8000h))
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7263
	line	450
	
l7235:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@t)^0180h
	line	451
	
l7237:	
		movlw	2
	xorwf	((Print_SystemStatus@t)^0180h),w
	btfsc	status,2
	goto	u11151
	goto	u11150
u11151:
	goto	l7241
u11150:
	
l7239:	
		movlw	3
	xorwf	((Print_SystemStatus@t)^0180h),w
	btfss	status,2
	goto	u11161
	goto	u11160
u11161:
	goto	l7243
u11160:
	line	452
	
l7241:	
	movlw	low(((STR_22)|8000h))
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7263
	line	453
	
l7243:	
		decf	((Print_SystemStatus@t)^0180h),w
	btfss	status,2
	goto	u11171
	goto	u11170
u11171:
	goto	l7247
u11170:
	line	454
	
l7245:	
	movlw	low(((STR_23)|8000h))
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7263
	line	455
	
l7247:	
		movlw	6
	xorwf	((Print_SystemStatus@t)^0180h),w
	btfss	status,2
	goto	u11181
	goto	u11180
u11181:
	goto	l7251
u11180:
	line	456
	
l7249:	
	movlw	low(((STR_24)|8000h))
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7263
	line	458
	
l7251:	
	movlw	low(((STR_25)|8000h))
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7263
	line	461
	
l7253:	
	movlw	low(((STR_26)|8000h))
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7263
	line	462
	
l7255:	
	movlw	low(((STR_27)|8000h))
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7263
	line	463
	
l7257:	
	movlw	low(((STR_28)|8000h))
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7263
	line	439
	
l7261:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@s)^0180h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l7221
	xorlw	1^0	; case 1
	skipnz
	goto	l7223
	xorlw	2^1	; case 2
	skipnz
	goto	l7225
	xorlw	3^2	; case 3
	skipnz
	goto	l7227
	xorlw	4^3	; case 4
	skipnz
	goto	l7229
	xorlw	5^4	; case 5
	skipnz
	goto	l7231
	xorlw	6^5	; case 6
	skipnz
	goto	l7233
	xorlw	7^6	; case 7
	skipnz
	goto	l7235
	xorlw	8^7	; case 8
	skipnz
	goto	l7253
	xorlw	9^8	; case 9
	skipnz
	goto	l7255
	goto	l7257
	opt asmopt_pop

	line	467
	
l7263:	
	movlw	low(((STR_29)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	468
	
l7265:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	469
	
l7267:	
	movlw	low(((STR_30)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	470
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	473
	
l7269:	
	movlw	low(((STR_31)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	400
	
l7271:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	incf	(Print_SystemStatus@i)^0180h,f
	
l7273:	
	movlw	low(0Ch)
	subwf	(Print_SystemStatus@i)^0180h,w
	skipc
	goto	u11191
	goto	u11190
u11191:
	goto	l7193
u11190:
	line	476
	
l7275:	
	movlw	low(((STR_32)|8000h))
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	477
	
l443:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 344 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	344
global __ptext5
__ptext5:	;psect for function _Print_NtcTemp
psect	text5
	file	"main.c"
	line	344
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	346
	
l7135:	
	movlw	low(((STR_1)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	347
	
l7137:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_NtcTemp$722+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_NtcTemp$722)^080h
	
l7139:	
	movf	(_Print_NtcTemp$722+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$722)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	348
	
l7141:	
	movlw	low(((STR_2)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	349
	
l7143:	
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_NtcTemp$723+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_NtcTemp$723)^080h
	movf	(_Print_NtcTemp$723+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$723)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	350
	
l7145:	
	movlw	low(((STR_3)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	351
	
l408:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2    0[BANK1 ] PTR const unsigned char 
;;		 -> STR_34(10), STR_33(21), STR_32(3), STR_31(3), 
;;		 -> STR_30(5), STR_29(5), STR_28(6), STR_27(6), 
;;		 -> STR_26(6), STR_25(6), STR_24(16), STR_23(13), 
;;		 -> STR_22(15), STR_21(7), STR_20(5), STR_19(5), 
;;		 -> STR_18(6), STR_17(6), STR_16(6), STR_15(7), 
;;		 -> STR_14(4), STR_13(6), STR_12(6), STR_11(3), 
;;		 -> STR_10(12), STR_9(2), STR_8(6), STR_7(5), 
;;		 -> STR_6(6), STR_5(5), STR_4(25), STR_3(4), 
;;		 -> STR_2(2), STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	file	"uart_dbg.c"
	line	61
global __ptext6
__ptext6:	;psect for function _uart_send_string
psect	text6
	file	"uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l6733:	
	goto	l6739
	line	65
	
l6735:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	btemp+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str)^080h,w
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	fcall	stringtab
	fcall	_uart_send_char
	
l6737:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(uart_send_string@str)^080h,f
	skipnz
	incf	(uart_send_string@str+1)^080h,f
	line	66
# 66 "uart_dbg.c"
clrwdt ;# 
psect	text6
	line	63
	
l6739:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(uart_send_string@str+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	btemp+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str)^080h,w
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u10391
	goto	u10390
u10391:
	goto	l6735
u10390:
	line	68
	
l497:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2    3[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    5[BANK1 ] unsigned char [6]
;;  j               1   12[BANK1 ] unsigned char 
;;  i               1   11[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      10       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext7
__ptext7:	;psect for function _uart_send_number
psect	text7
	file	"uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 2
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l6741:	
	clrf	(uart_send_number@i)^080h
	line	84
	
l6743:	
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u10401
	goto	u10400
u10401:
	goto	l6755
u10400:
	line	86
	
l6745:	
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l501
	line	93
	
l6749:	
	movf	(uart_send_number@i)^080h,w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@num+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@num)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank1
	movwf	indf
	
l6751:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(uart_send_number@i)^080h,f
	line	94
	
l6753:	
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@num+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@num)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	line	91
	
l6755:	
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u10411
	goto	u10410
u10411:
	goto	l6749
u10410:
	line	98
	
l6757:	
	movf	(uart_send_number@i)^080h,w
	movwf	(uart_send_number@j)^080h
	
l6759:	
	movf	((uart_send_number@j)^080h),w
	btfss	status,2
	goto	u10421
	goto	u10420
u10421:
	goto	l6763
u10420:
	goto	l501
	line	99
	
l6763:	
	movf	(uart_send_number@j)^080h,w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l6765:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decf	(uart_send_number@j)^080h,f
	goto	l6759
	line	100
	
l501:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1   27[BANK0 ] unsigned char 
;;  i               1   28[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/B00
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext8
__ptext8:	;psect for function _uart_send_char
psect	text8
	file	"uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_char: [wreg+status,2+status,0]
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_char@c)
	line	38
	
l4831:	
	bcf	(95/8),(95)&7	;volatile
	line	39
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l4833:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u13087:
decfsz	(??_uart_send_char+0)+0,f
	goto	u13087
	nop2
opt asmopt_pop

	line	41
	
l4835:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(uart_send_char@i)
	line	42
	
l487:	
	line	43
	btfss	(uart_send_char@c),(0)&7
	goto	u6771
	goto	u6770
u6771:
	goto	l489
u6770:
	line	44
	
l4841:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l4843
	line	45
	
l489:	
	line	46
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l4843:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u13097:
decfsz	(??_uart_send_char+0)+0,f
	goto	u13097
	nop2
opt asmopt_pop

	line	48
	
l4845:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rrf	(uart_send_char@c),f
	line	41
	
l4847:	
	incf	(uart_send_char@i),f
	
l4849:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u6781
	goto	u6780
u6781:
	goto	l487
u6780:
	
l488:	
	line	50
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l4851:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u13107:
decfsz	(??_uart_send_char+0)+0,f
	goto	u13107
	nop2
opt asmopt_pop

	line	52
	
l4853:	
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l491:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   26[BANK0 ] unsigned int 
;;  dividend        2   28[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1    0[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   26[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       0       1       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       1       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext9
__ptext9:	;psect for function ___lwmod
psect	text9
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l6675:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u10251
	goto	u10250
u10251:
	goto	l6691
u10250:
	line	14
	
l6677:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___lwmod@counter)^080h
	incf	(___lwmod@counter)^080h,f
	line	15
	goto	l6681
	line	16
	
l6679:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	bsf	status, 5	;RP0=1, select bank1
	incf	(___lwmod@counter)^080h,f
	line	15
	
l6681:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u10261
	goto	u10260
u10261:
	goto	l6679
u10260:
	line	20
	
l6683:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u10275
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u10275:
	skipc
	goto	u10271
	goto	u10270
u10271:
	goto	l6687
u10270:
	line	21
	
l6685:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l6687:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l6689:	
	bsf	status, 5	;RP0=1, select bank1
	decfsz	(___lwmod@counter)^080h,f
	goto	u10281
	goto	u10280
u10281:
	goto	l6683
u10280:
	line	25
	
l6691:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1206:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	_Do_NtcRead

;; *************** function _Do_NtcRead *****************
;; Defined at:
;;		line 335 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Read_Temperature
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	335
global __ptext10
__ptext10:	;psect for function _Do_NtcRead
psect	text10
	file	"main.c"
	line	335
	global	__size_of_Do_NtcRead
	__size_of_Do_NtcRead	equ	__end_of_Do_NtcRead-_Do_NtcRead
	
_Do_NtcRead:	
;incstack = 0
	opt	stack 2
; Regs used in _Do_NtcRead: [wreg+status,2+status,0+pclath+cstack]
	line	337
	
l7133:	
	fcall	_Read_Temperature
	line	338
	
l405:	
	return
	opt stack 0
GLOBAL	__end_of_Do_NtcRead
	__end_of_Do_NtcRead:
	signat	_Do_NtcRead,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 30 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   25[BANK1 ] unsigned long 
;;  temp_x10        2   31[BANK1 ] unsigned int 
;;  ntcVal          2   29[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   62[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Do_NtcRead
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	30
global __ptext11
__ptext11:	;psect for function _Read_Temperature
psect	text11
	file	"charge_mgr.c"
	line	30
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 2
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	35
	
l6695:	
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	36
	
l6697:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u10291
	goto	u10290
u10291:
	goto	l6701
u10290:
	goto	l534
	line	39
	
l6701:	
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal)^080h
	line	40
	movlw	0
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u10301
	goto	u10300
u10301:
	goto	l534
u10300:
	
l6703:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u10311
	goto	u10310
u10311:
	goto	l6705
u10310:
	goto	l534
	line	45
	
l6705:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	010h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0
	movwf	(___lldiv@divisor)^080h

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0)
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0+1)
	clrf	((??_Read_Temperature+0)^080h+0+2)
	clrf	((??_Read_Temperature+0)^080h+0+3)
	movf	0+(??_Read_Temperature+0)^080h+0,w
	subwf	(___lldiv@divisor)^080h,f
	movf	1+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)^080h+0,w
	goto	u10325
	goto	u10326
u10325:
	subwf	(___lldiv@divisor+1)^080h,f
u10326:
	movf	2+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)^080h+0,w
	goto	u10327
	goto	u10328
u10327:
	subwf	(___lldiv@divisor+2)^080h,f
u10328:
	movf	3+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)^080h+0,w
	goto	u10329
	goto	u10320
u10329:
	subwf	(___lldiv@divisor+3)^080h,f
u10320:

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0
	movwf	(___lmul@multiplicand+2)^080h
	movlw	027h
	movwf	(___lmul@multiplicand+1)^080h
	movlw	010h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt)^080h

	line	46
	
l6707:	
		movf	(Read_Temperature@rt+3)^080h,w
	btfss	status,2
	goto	u10330
	movf	(Read_Temperature@rt+2)^080h,w
	btfss	status,2
	goto	u10330
	movlw	39
	subwf	(Read_Temperature@rt+1)^080h,w
	skipz
	goto	u10333
	movlw	16
	subwf	(Read_Temperature@rt)^080h,w
	skipz
	goto	u10333
u10333:
	btfss	status,0
	goto	u10331
	goto	u10330

u10331:
	goto	l6713
u10330:
	line	47
	
l6709:	
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l6711:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0F0h
	movwf	((??_Read_Temperature+0)^080h+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)^080h+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+3)
	movf	(Read_Temperature@rt)^080h,w
	addwf	(??_Read_Temperature+0)^080h+0,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+1)^080h,w
	goto	u10340
	goto	u10341
u10340:
	addwf	(??_Read_Temperature+0)^080h+1,f
u10341:
	movf	(Read_Temperature@rt+2)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+2)^080h,w
	goto	u10342
	goto	u10343
u10342:
	addwf	(??_Read_Temperature+0)^080h+2,f
u10343:
	movf	(Read_Temperature@rt+3)^080h,w
	skipnc
	incf	(Read_Temperature@rt+3)^080h,w
	addwf	(??_Read_Temperature+0)^080h+3,f
	movf	3+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+3)^080h
	movf	2+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+2)^080h
	movf	1+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+1)^080h
	movf	0+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier)^080h

	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(0+(?___lldiv))^080h,w
	subwf	(Read_Temperature@temp_x10)^080h,f
	movf	(1+(?___lldiv))^080h,w
	skipc
	decf	(Read_Temperature@temp_x10+1)^080h,f
	subwf	(Read_Temperature@temp_x10+1)^080h,f
	goto	l6717
	line	49
	
l6713:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0
	movwf	(___lmul@multiplier+3)^080h
	movlw	0
	movwf	(___lmul@multiplier+2)^080h
	movlw	027h
	movwf	(___lmul@multiplier+1)^080h
	movlw	010h
	movwf	(___lmul@multiplier)^080h

	movf	(Read_Temperature@rt)^080h,w
	subwf	(___lmul@multiplier)^080h,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+1)^080h,w
	subwf	(___lmul@multiplier+1)^080h,f
	movf	(Read_Temperature@rt+2)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+2)^080h,w
	subwf	(___lmul@multiplier+2)^080h,f
	movf	(Read_Temperature@rt+3)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+3)^080h,w
	subwf	(___lmul@multiplier+3)^080h,f
	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10)^080h
	
l6715:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10)^080h,f
	skipnc
	incf	(Read_Temperature@temp_x10+1)^080h,f
	line	50
	
l6717:	
	movlw	0
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipnc
	goto	u10351
	goto	u10350
u10351:
	goto	l540
u10350:
	
l6719:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l540:	
	line	51
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipc
	goto	u10361
	goto	u10360
u10361:
	goto	l541
u10360:
	
l6721:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)^080h
	movlw	02h
	movwf	((Read_Temperature@temp_x10)^080h)+1
	
l541:	
	line	54
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature)
	line	55
	
l6723:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u10371
	goto	u10370
u10371:
	goto	l6727
u10370:
	line	56
	
l6725:	
	clrf	(_g_tempProtect)
	incf	(_g_tempProtect),f
	goto	l534
	line	57
	
l6727:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u10381
	goto	u10380
u10381:
	goto	l534
u10380:
	line	58
	
l6729:	
	clrf	(_g_tempProtect)
	line	61
	
l534:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	_Do_AdcSample

;; *************** function _Do_AdcSample *****************
;; Defined at:
;;		line 263 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  st              1   20[BANK1 ] unsigned char 
;;  dly             1   19[BANK1 ] unsigned char 
;;  ty              1   18[BANK1 ] unsigned char 
;;  ch              1   17[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       1       4       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	263
global __ptext12
__ptext12:	;psect for function _Do_AdcSample
psect	text12
	file	"main.c"
	line	263
	global	__size_of_Do_AdcSample
	__size_of_Do_AdcSample	equ	__end_of_Do_AdcSample-_Do_AdcSample
	
_Do_AdcSample:	
;incstack = 0
	opt	stack 3
; Regs used in _Do_AdcSample: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	265
	
l7069:	
	movf	(_g_scanIndex),w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@ch)^080h
	line	266
	
l7071:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@ty)^080h
	line	267
	
l7073:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@st)^080h
	line	288
	
l7075:	
		movlw	6
	xorwf	((Do_AdcSample@ty)^080h),w
	btfss	status,2
	goto	u10911
	goto	u10910
u10911:
	goto	l7085
u10910:
	
l7077:	
		movlw	2
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10921
	goto	u10920
u10921:
	goto	l7091
u10920:
	
l7079:	
		movlw	3
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10931
	goto	u10930
u10931:
	goto	l7091
u10930:
	
l7081:	
		movlw	4
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10941
	goto	u10940
u10941:
	goto	l7091
u10940:
	
l7083:	
		movlw	5
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10951
	goto	u10950
u10951:
	goto	l7091
u10950:
	
l7085:	
		decf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10961
	goto	u10960
u10961:
	goto	l7091
u10960:
	
l7087:	
		movlw	8
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10971
	goto	u10970
u10971:
	goto	l7091
u10970:
	
l7089:	
		movlw	9
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u10981
	goto	u10980
u10981:
	goto	l7109
u10980:
	line	292
	
l7091:	
		decf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10991
	goto	u10990
u10991:
	goto	l7097
u10990:
	
l7093:	
		movlw	8
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11001
	goto	u11000
u11001:
	goto	l7097
u11000:
	
l7095:	
		movlw	9
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u11011
	goto	u11010
u11011:
	goto	l7109
u11010:
	line	294
	
l7097:	
	clrf	(Do_AdcSample@dly)^080h
	line	295
	
l7103:	
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Do_AdcSample+0)+0),f
	u13117:
decfsz	(??_Do_AdcSample+0)+0,f
	goto	u13117
	nop
opt asmopt_pop

	line	294
	
l7105:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(Do_AdcSample@dly)^080h,f
	
l7107:	
	movlw	low(014h)
	subwf	(Do_AdcSample@dly)^080h,w
	skipc
	goto	u11021
	goto	u11020
u11021:
	goto	l7103
u11020:
	goto	l7113
	line	299
	
l7109:	
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Do_AdcSample+0)+0),f
	u13127:
decfsz	(??_Do_AdcSample+0)+0,f
	goto	u13127
	nop
opt asmopt_pop

	line	307
	
l7113:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@adldo)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Do_AdcSample@ch)^080h,w
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	309
	
l7115:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u11031
	goto	u11030
u11031:
	goto	l7129
u11030:
	line	314
	
l7117:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	((Do_AdcSample@ty)^080h),w
	btfss	status,2
	goto	u11041
	goto	u11040
u11041:
	goto	l7127
u11040:
	
l7119:	
		movlw	4
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11051
	goto	u11050
u11051:
	goto	l7123
u11050:
	
l7121:	
		movlw	5
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u11061
	goto	u11060
u11061:
	goto	l7127
u11060:
	
l7123:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_adresult+1),w	;volatile
	movlw	096h
	skipnz
	subwf	(_adresult),w	;volatile
	skipc
	goto	u11071
	goto	u11070
u11071:
	goto	l7127
u11070:
	goto	l7131
	line	320
	
l7127:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	movf	(_adresult),w	;volatile
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_adresult+1),w	;volatile
	movwf	indf
	goto	l7131
	line	324
	
l7129:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	326
	
l7131:	
	movlw	low(01h)
	movwf	(_g_scanPhase)	;volatile
	line	327
	
l402:	
	return
	opt stack 0
GLOBAL	__end_of_Do_AdcSample
	__end_of_Do_AdcSample:
	signat	_Do_AdcSample,89
	global	_ChargeProcess_Slot

;; *************** function _ChargeProcess_Slot *****************
;; Defined at:
;;		line 133 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   23[BANK3 ] unsigned char 
;;  bat_mv_long     4   32[BANK1 ] unsigned long 
;;  vx_mv           4   28[BANK1 ] unsigned long 
;;  bat_mv          2   10[BANK3 ] unsigned int 
;;  bat_mv_long     4    4[BANK3 ] unsigned long 
;;  vx_mv           4    0[BANK3 ] unsigned long 
;;  bat_mv          2   14[BANK3 ] unsigned int 
;;  bat_mv_long     4   40[BANK1 ] unsigned long 
;;  vx_mv           4   36[BANK1 ] unsigned long 
;;  bat_mv          2   12[BANK3 ] unsigned int 
;;  v_ref           2    8[BANK3 ] unsigned int 
;;  v_init          2   26[BANK1 ] unsigned int 
;;  v               2   21[BANK3 ] unsigned int 
;;  ct              2   19[BANK3 ] unsigned int 
;;  tick            2    0        unsigned int 
;;  ty              1   18[BANK3 ] unsigned char 
;;  st              1   46[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/B00
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      21      24       0
;;      Temps:          0       0       5       0       0
;;      Totals:         0       0      26      24       0
;;Total ram usage:       50 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		_Detect_BatteryType
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___wmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	133
global __ptext13
__ptext13:	;psect for function _ChargeProcess_Slot
psect	text13
	file	"charge_mgr.c"
	line	133
	global	__size_of_ChargeProcess_Slot
	__size_of_ChargeProcess_Slot	equ	__end_of_ChargeProcess_Slot-_ChargeProcess_Slot
	
_ChargeProcess_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _ChargeProcess_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@idx)^0180h
	line	137
	
l7277:	
	line	139
	
l7279:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l7281:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	
l7283:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@v)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v+1)^0180h
	
l7285:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ct)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@ct+1)^0180h
	goto	l8021
	line	144
	
l7287:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	145
	
l7289:	
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@st)^080h
	incf	(ChargeProcess_Slot@st)^080h,f
	line	146
	
l7291:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11204
u11205:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11204:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11205
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	149
	
l7293:	
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11211
	goto	u11210
u11211:
	goto	l7297
u11210:
	line	150
	
l7295:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	goto	l8023
	line	152
	
l7297:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l8023
	line	156
	
l7299:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	159
	
l7301:	
		decf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u11221
	goto	u11220
u11221:
	goto	l7307
u11220:
	line	161
	
l7303:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	162
	
l7305:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11234
u11235:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11234:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11235
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	165
	
l7307:	
	movlw	0
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	01Eh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u11241
	goto	u11240
u11241:
	goto	l7321
u11240:
	line	172
	
l7309:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movlw	09h
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0C5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u11251
	goto	u11250
u11251:
	goto	l8023
u11250:
	
l7311:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(03E8h)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(03E8h)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	skipz
	goto	u11265
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
u11265:
	skipnc
	goto	u11261
	goto	u11260
u11261:
	goto	l8023
u11260:
	
l7313:	
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11271
	goto	u11270
u11271:
	goto	l8023
u11270:
	line	174
	
l7315:	
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	175
	movlw	low(07h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	176
	
l7317:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11284
u11285:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11284:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11285
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	177
	
l7319:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	178
	goto	l8023
	line	189
	
l7321:	
		movlw	30
	xorwf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u11291
	goto	u11290
u11291:
	goto	l7329
u11290:
	line	191
	
l7323:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	192
	
l7325:	
	movlw	0Bh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11301
	goto	u11300
u11301:
	goto	l8023
u11300:
	line	193
	
l7327:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11314
u11315:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11314:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11315
	
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_capFlag+1)^080h,f
	goto	l8023
	line	196
	
l7329:	
	movlw	0Bh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11321
	goto	u11320
u11321:
	goto	l7391
u11320:
	
l7331:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11331
	goto	u11330
u11331:
	goto	l7391
u11330:
	line	208
	
l7333:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11344
u11345:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11344:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11345
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfss	status,2
	goto	u11351
	goto	u11350
u11351:
	goto	l7347
u11350:
	
l7335:	
		movlw	5
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11361
	goto	u11360
u11361:
	goto	l7347
u11360:
	
l7337:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0ADh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11371
	goto	u11370
u11371:
	goto	l7347
u11370:
	line	210
	
l7339:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	211
	
l7341:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	212
	
l7343:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l7319
	line	224
	
l7347:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@v_init)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_init+1)^080h
	line	226
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	bcf	status, 7	;select IRP bank1
	subwf	indf,w
	skipc
	goto	u11381
	goto	u11380
u11381:
	goto	l7377
u11380:
	line	231
	
l7349:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11394
u11395:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11394:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11395
	
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_highVFlag+1)^080h,f
	line	233
	
l7351:	
	movlw	0Bh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11401
	goto	u11400
u11401:
	goto	l7359
u11400:
	line	236
	
l7353:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11414
u11415:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11414:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11415
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	237
	
l7355:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	238
	
l7357:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11424
u11425:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11424:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11425
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	239
	goto	l7403
	line	240
	
l7359:	
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	082h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u11431
	goto	u11430
u11431:
	goto	l7371
u11430:
	line	246
	
l7361:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11444
u11445:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11444:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11445
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u11451
	goto	u11450
u11451:
	goto	l7295
u11450:
	
l7363:	
	movlw	0
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	037h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11461
	goto	u11460
u11461:
	goto	l7295
u11460:
	line	259
	
l7371:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11474
u11475:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11474:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11475
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	260
	
l7373:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	261
	
l7375:	
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	262
	goto	l7427
	line	268
	
l7377:	
	movf	(ChargeProcess_Slot@v)^0180h,w
	addlw	low(032h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(ChargeProcess_Slot@v_init+1)^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11485
	movf	(ChargeProcess_Slot@v_init)^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11485:
	skipnc
	goto	u11481
	goto	u11480
u11481:
	goto	l7381
u11480:
	line	271
	
l7379:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	272
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	273
	goto	l581
	line	277
	
l7381:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	278
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	279
	
l581:	
	line	280
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u11491
	goto	u11490
u11491:
	goto	l7385
u11490:
	goto	l8023
	line	283
	
l7385:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11504
u11505:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11504:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11505
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u11511
	goto	u11510
u11511:
	goto	l7389
u11510:
	goto	l8023
	line	285
	
l7389:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7403
	line	288
	
l7391:	
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	082h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u11521
	goto	u11520
u11521:
	goto	l7403
u11520:
	
l7393:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11531
	goto	u11530
u11531:
	goto	l7403
u11530:
	line	290
	
l7395:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_ref)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_ref+1)^0180h
	line	291
	
l7397:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v_ref+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v_ref)^0180h,w
	skipnc
	goto	u11541
	goto	u11540
u11541:
	goto	l7403
u11540:
	
l7399:	
	movf	(ChargeProcess_Slot@v)^0180h,w
	addlw	low(032h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_ref+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11555
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_ref)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11555:
	skipnc
	goto	u11551
	goto	u11550
u11551:
	goto	l7403
u11550:
	goto	l7295
	line	301
	
l7403:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11564
u11565:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11564:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11565
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u11571
	goto	u11570
u11571:
	goto	l7411
u11570:
	line	303
	
l7405:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11584
u11585:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11584:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11585
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	304
	
l7407:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	305
	
l7409:	
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	306
	goto	l7413
	line	309
	
l7411:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Detect_BatteryType@voltage+1)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	314
	
l7413:	
	movlw	01h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0F4h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u11591
	goto	u11590
u11591:
	goto	l7419
u11590:
	line	316
	
l7415:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	317
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u11601
	goto	u11600
u11601:
	goto	l7427
u11600:
	goto	l8023
	line	321
	
l7419:	
		movlw	5
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11611
	goto	u11610
u11611:
	goto	l7427
u11610:
	
l7421:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11621
	goto	u11620
u11621:
	goto	l7427
u11620:
	
l7423:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11631
	goto	u11630
u11631:
	goto	l7427
u11630:
	line	323
	
l7425:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	327
	
l7427:	
		movlw	5
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11641
	goto	u11640
u11641:
	goto	l7457
u11640:
	line	334
	
l7429:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	335
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11651
	goto	u11650
u11651:
	goto	l7433
u11650:
	goto	l8023
	line	339
	
l7433:	
	bcf	status, 6	;RP1=0, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u11661
	goto	u11660
u11661:
	goto	l7439
u11660:
	
l7435:	
	movf	(_g_impCheckSlot)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	xorwf	(ChargeProcess_Slot@idx)^0180h,w
	skipnz
	goto	u11671
	goto	u11670
u11671:
	goto	l7439
u11670:
	goto	l8023
	line	341
	
l7439:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	345
	
l7441:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u11681
	goto	u11680
u11681:
	goto	l596
u11680:
	line	346
	
l7443:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(0+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	
l596:	
	line	350
	movlw	064h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_impData+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_impData)^080h
	
l7445:	
	movlw	0Ch
	
u11695:
	clrc
	rlf	(_g_impData)^080h,f
	rlf	(_g_impData+1)^080h,f
	addlw	-1
	skipz
	goto	u11695
	
l7447:	
	movlw	(0A000h >> 8)
	addwf	(_g_impData+1)^080h,f
	
l7449:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	iorwf	(_g_impData)^080h,f
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	iorwf	(_g_impData+1)^080h,f
	line	351
	
l7451:	
	movlw	low(08h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	352
	
l7453:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	353
	
l7455:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	355
	
l7457:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11701
	goto	u11700
u11701:
	goto	l7461
u11700:
	
l7459:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11711
	goto	u11710
u11711:
	goto	l7503
u11710:
	line	358
	
l7461:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	359
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11721
	goto	u11720
u11721:
	goto	l7465
u11720:
	goto	l8023
	line	361
	
l7465:	
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv)^080h

	
l7467:	
	movlw	0Ch
u11735:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u11735

	
l7469:	
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long)^080h

	
l7471:	
	movf	(ChargeProcess_Slot@vx_mv+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11741
	addwf	(ChargeProcess_Slot@bat_mv_long+1)^080h,f
u11741:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11742
	addwf	(ChargeProcess_Slot@bat_mv_long+2)^080h,f
u11742:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11743
	addwf	(ChargeProcess_Slot@bat_mv_long+3)^080h,f
u11743:

	
l7473:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	goto	u11750
	goto	u11751
u11750:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u11751:
	movf	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	goto	u11752
	goto	u11753
u11752:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u11753:
	movf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv)^0180h
	
l7475:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u11761
	goto	u11760
u11761:
	goto	l7479
u11760:
	
l7477:	
	movlw	low(02h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7497
	
l7479:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u11771
	goto	u11770
u11771:
	goto	l7483
u11770:
	
l7481:	
	movlw	low(03h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7497
	
l7483:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipc
	goto	u11781
	goto	u11780
u11781:
	goto	l7489
u11780:
	
l7485:	
	movlw	low(05h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l7487:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	goto	l7497
	
l7489:	
	movlw	low(04h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l7491:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l7493:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	
l7495:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	
l7497:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	
l7499:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l7319
	line	363
	
l7503:	
	movf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11791
	goto	u11790
u11791:
	goto	l7519
u11790:
	line	366
	
l7505:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11801
	goto	u11800
u11801:
	goto	l7515
u11800:
	line	370
	
l7507:	
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	082h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u11811
	goto	u11810
u11811:
	goto	l7375
u11810:
	goto	l8023
	line	380
	
l7515:	
	movlw	low(07h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7319
	line	384
	
l7519:	
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11821
	goto	u11820
u11821:
	goto	l7515
u11820:
	
l7521:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11831
	goto	u11830
u11831:
	goto	l8023
u11830:
	goto	l7515
	line	392
	
l7527:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	393
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	05h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u11841
	goto	u11840
u11841:
	goto	l7531
u11840:
	goto	l8023
	line	398
	
l7531:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u11851
	goto	u11850
u11851:
	goto	l7535
u11850:
	line	399
	
l7533:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(0+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	line	404
	
l7535:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11861
	goto	u11860
u11861:
	goto	l7545
u11860:
	
l7537:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	096h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u11871
	goto	u11870
u11871:
	goto	l7545
u11870:
	line	406
	
l7539:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	407
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@st)^080h
	line	408
	
l7541:	
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	line	409
	
l7543:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11884
u11885:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11884:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11885
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	410
	goto	l8023
	line	416
	
l7545:	
	bcf	status, 6	;RP1=0, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(012Ch)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(012Ch)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11895
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11895:
	skipnc
	goto	u11891
	goto	u11890
u11891:
	goto	l7553
u11890:
	
l7547:	
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u11901
	goto	u11900
u11901:
	goto	l7553
u11900:
	line	418
	
l7549:	
	movlw	low(02h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	419
	movlw	low(07h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	420
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	goto	l7543
	line	426
	
l7553:	
	bcf	status, 6	;RP1=0, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(0C8h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11915
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11915:
	skipnc
	goto	u11911
	goto	u11910
u11911:
	goto	l7557
u11910:
	goto	l7583
	line	431
	
l7557:	
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	skipz
	goto	u11925
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v)^0180h,w
u11925:
	skipnc
	goto	u11921
	goto	u11920
u11921:
	goto	l7567
u11920:
	
l7559:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	03h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0E9h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u11931
	goto	u11930
u11931:
	goto	l7567
u11930:
	line	433
	
l7561:	
	movlw	low(03h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	434
	movlw	low(07h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	435
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	goto	l7317
	line	445
	
l7567:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Dh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0ADh
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u11941
	goto	u11940
u11941:
	goto	l7573
u11940:
	
l7569:	
	swapf	(_g_impData+1)^080h,w
	andlw	15
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(0C8h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11955
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11955:
	skipc
	goto	u11951
	goto	u11950
u11951:
	goto	l7573
u11950:
	goto	l7577
	line	452
	
l7573:	
	line	458
	
l7577:	
	movlw	low(09h)
	movwf	(ChargeProcess_Slot@st)^080h
	line	459
	
l7579:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	goto	l7543
	line	466
	
l7583:	
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	line	467
	
l7585:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11964
u11965:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11964:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11965
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	468
	
l7587:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	incf	(ChargeProcess_Slot@ty)^0180h,f
	line	469
	
l7589:	
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_368+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_368+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_368+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_368)^080h

	
l7591:	
	movlw	0Ch
u11975:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_368+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_368+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_368+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_368)^080h,f
	addlw	-1
	skipz
	goto	u11975

	
l7593:	
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_369+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_369+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_369+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_369)^080h

	
l7595:	
	movf	(ChargeProcess_Slot@vx_mv_368+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv_368+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv_368+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv_368)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long_369)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11981
	addwf	(ChargeProcess_Slot@bat_mv_long_369+1)^080h,f
u11981:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11982
	addwf	(ChargeProcess_Slot@bat_mv_long_369+2)^080h,f
u11982:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11983
	addwf	(ChargeProcess_Slot@bat_mv_long_369+3)^080h,f
u11983:

	
l7597:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long_369)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long_369+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_369+1)^080h,w
	goto	u11990
	goto	u11991
u11990:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u11991:
	movf	(ChargeProcess_Slot@bat_mv_long_369+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_369+2)^080h,w
	goto	u11992
	goto	u11993
u11992:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u11993:
	movf	(ChargeProcess_Slot@bat_mv_long_369+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_369+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_370+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_370)^0180h
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_370+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_370)^0180h,w
	skipnc
	goto	u12001
	goto	u12000
u12001:
	goto	l7601
u12000:
	goto	l7477
	
l7601:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_370+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_370)^0180h,w
	skipnc
	goto	u12011
	goto	u12010
u12011:
	goto	l7605
u12010:
	goto	l7481
	
l7605:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_370+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_370)^0180h,w
	skipc
	goto	u12021
	goto	u12020
u12021:
	goto	l7489
u12020:
	goto	l7485
	line	480
	
l7625:	
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	481
	
l7627:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12034
u12035:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12034:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12035
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	482
	
l7629:	
	movlw	low(06h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	483
	
l7631:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(___lmul@multiplier)^080h
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(___lmul@multiplier)^080h
	clrf	2+(___lmul@multiplier)^080h
	clrf	3+(___lmul@multiplier)^080h
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@vx_mv_371+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@vx_mv_371+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@vx_mv_371+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@vx_mv_371)^0180h

	
l7633:	
	movlw	0Ch
u12045:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_371+3)^0180h,f
	rrf	(ChargeProcess_Slot@vx_mv_371+2)^0180h,f
	rrf	(ChargeProcess_Slot@vx_mv_371+1)^0180h,f
	rrf	(ChargeProcess_Slot@vx_mv_371)^0180h,f
	addlw	-1
	skipz
	goto	u12045

	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long_372+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long_372+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long_372+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long_372)^0180h

	movf	(ChargeProcess_Slot@vx_mv_371+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier+3)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@vx_mv_371+2)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier+2)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@vx_mv_371+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@vx_mv_371)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long_372)^0180h,f
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12051
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long_372+1)^0180h,f
u12051:
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12052
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long_372+2)^0180h,f
u12052:
	bcf	status, 6	;RP1=0, select bank1
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12053
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long_372+3)^0180h,f
u12053:
	bcf	status, 6	;RP1=0, select bank1
	bsf	status, 6	;RP1=1, select bank3

	movlw	0
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long_372)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long_372+1)^0180h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_372+1)^0180h,w
	goto	u12060
	goto	u12061
u12060:
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u12061:
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long_372+2)^0180h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_372+2)^0180h,w
	goto	u12062
	goto	u12063
u12062:
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u12063:
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long_372+3)^0180h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_372+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_373+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_373)^0180h
	
l7635:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_373+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_373)^0180h,w
	skipnc
	goto	u12071
	goto	u12070
u12071:
	goto	l7639
u12070:
	goto	l7477
	
l7639:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_373+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_373)^0180h,w
	skipnc
	goto	u12081
	goto	u12080
u12081:
	goto	l7643
u12080:
	goto	l7481
	
l7643:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_373+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_373)^0180h,w
	skipc
	goto	u12091
	goto	u12090
u12091:
	goto	l7649
u12090:
	
l7645:	
	movlw	low(05h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l7647:	
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	goto	l7497
	
l7649:	
	movlw	low(04h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l7651:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l7653:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	goto	l7495
	line	493
	
l7663:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	502
	
l7667:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(0384h)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(0384h)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	skipz
	goto	u12105
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
u12105:
	skipnc
	goto	u12101
	goto	u12100
u12101:
	goto	l7675
u12100:
	line	506
	
l7669:	
	swapf	(_g_impData+1)^080h,w
	andlw	15
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(096h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u12115
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u12115:
	skipnc
	goto	u12111
	goto	u12110
u12111:
	goto	l7625
u12110:
	goto	l7583
	line	520
	
l7675:	
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Bh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0B9h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u12121
	goto	u12120
u12121:
	goto	l7683
u12120:
	
l7677:	
	movlw	0Bh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12131
	goto	u12130
u12131:
	goto	l7683
u12130:
	
l7679:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	skipz
	goto	u12145
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v)^0180h,w
u12145:
	skipnc
	goto	u12141
	goto	u12140
u12141:
	goto	l7683
u12140:
	goto	l7625
	line	527
	
l7683:	
	movlw	0Bh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12151
	goto	u12150
u12151:
	goto	l7693
u12150:
	
l7685:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	08h
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	goto	u12161
	goto	u12160
u12161:
	goto	l7693
u12160:
	goto	l7561
	line	542
	
l7693:	
	movlw	0
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	014h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12171
	goto	u12170
u12171:
	goto	l7701
u12170:
	
l7695:	
	movlw	08h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	035h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12181
	goto	u12180
u12181:
	goto	l7701
u12180:
	
l7697:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	addlw	low(064h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipnc
	addlw	1
	addlw	high(064h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	skipz
	goto	u12195
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
u12195:
	skipc
	goto	u12191
	goto	u12190
u12191:
	goto	l7701
u12190:
	goto	l7625
	line	546
	
l7701:	
	movlw	0
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	01Eh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12201
	goto	u12200
u12201:
	goto	l8023
u12200:
	goto	l7561
	line	558
	
l7709:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	559
	movlw	017h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	071h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12211
	goto	u12210
u12211:
	goto	l7713
u12210:
	line	561
	
l7711:	
	movlw	low(07h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	562
	goto	l8023
	line	564
	
l7713:	
	movlw	02h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12221
	goto	u12220
u12221:
	goto	l7719
u12220:
	line	566
	
l7715:	
	movlw	low(03h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	567
	
l7717:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	568
	goto	l8023
	line	570
	
l7719:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12231
	goto	u12230
u12231:
	goto	l8023
u12230:
	goto	l7711
	line	578
	
l7723:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	579
	movlw	075h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	031h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12241
	goto	u12240
u12241:
	goto	l7727
u12240:
	goto	l7711
	line	584
	
l7727:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12251
	goto	u12250
u12251:
	goto	l7733
u12250:
	line	586
	
l7729:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	587
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u12261
	goto	u12260
u12261:
	goto	l7735
u12260:
	goto	l7711
	line	595
	
l7733:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	597
	
l7735:	
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	08Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12271
	goto	u12270
u12271:
	goto	l8023
u12270:
	line	599
	
l7737:	
	movlw	low(04h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	600
	
l7739:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	601
	
l7741:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	602
	
l7743:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	603
	
l7745:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	604
	
l7747:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l8023
	line	609
	
l7749:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	610
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	060h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12281
	goto	u12280
u12281:
	goto	l7755
u12280:
	line	612
	
l7751:	
	movlw	060h
	subwf	(ChargeProcess_Slot@ct)^0180h,f
	movlw	0EAh
	skipc
	decf	(ChargeProcess_Slot@ct+1)^0180h,f
	subwf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	613
	
l7753:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	615
	
l7755:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(012h)
	subwf	indf,w
	skipc
	goto	u12291
	goto	u12290
u12291:
	goto	l7759
u12290:
	goto	l7711
	line	624
	
l7759:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12301
	goto	u12300
u12301:
	goto	l7765
u12300:
	
l7761:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12311
	goto	u12310
u12311:
	goto	l7765
u12310:
	goto	l7775
	line	628
	
l7765:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12321
	goto	u12320
u12321:
	goto	l7771
u12320:
	
l7767:	
	movlw	02h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u12331
	goto	u12330
u12331:
	goto	l7771
u12330:
	goto	l7775
	line	636
	
l7771:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u12345
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u12345:
	skipnc
	goto	u12341
	goto	u12340
u12341:
	goto	l7775
u12340:
	
l7773:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	646
	
l7775:	
		movlw	6
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12351
	goto	u12350
u12351:
	goto	l7795
u12350:
	line	648
	
l7777:	
	movlw	07h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0D0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u12361
	goto	u12360
u12361:
	goto	l7787
u12360:
	line	650
	
l7779:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	651
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u12371
	goto	u12370
u12371:
	goto	l7789
u12370:
	line	653
	
l7781:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	654
	
l7783:	
	movlw	low(07h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7717
	line	661
	
l7787:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	666
	
l7789:	
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0C8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12381
	goto	u12380
u12381:
	goto	l7829
u12380:
	goto	l7783
	line	678
	
l7795:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	skipz
	goto	u12395
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v)^0180h,w
u12395:
	skipnc
	goto	u12391
	goto	u12390
u12391:
	goto	l7799
u12390:
	
l7797:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipnc
	goto	u12401
	goto	u12400
u12401:
	goto	l7801
u12400:
	
l7799:	
	movlw	07h
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0D0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u12411
	goto	u12410
u12411:
	goto	l7813
u12410:
	line	680
	
l7801:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	681
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12421
	goto	u12420
u12421:
	goto	l7805
u12420:
	goto	l8023
	line	683
	
l7805:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	684
	
l7807:	
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@st)^080h
	incf	(ChargeProcess_Slot@st)^080h,f
	goto	l7717
	line	690
	
l7813:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	702
	
l7815:	
	movlw	02h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u12431
	goto	u12430
u12431:
	goto	l7821
u12430:
	line	704
	
l7817:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(01Eh)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	skipz
	goto	u12445
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v)^0180h,w
u12445:
	skipc
	goto	u12441
	goto	u12440
u12441:
	goto	l7821
u12440:
	line	705
	
l7819:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	indf,f
	line	707
	
l7821:	
	movlw	02h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12451
	goto	u12450
u12451:
	goto	l7829
u12450:
	
l7823:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	(indf),w
	btfss	status,2
	goto	u12461
	goto	u12460
u12461:
	goto	l7829
u12460:
	goto	l7783
	line	721
	
l7829:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12471
	goto	u12470
u12471:
	goto	l7837
u12470:
	
l7831:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12481
	goto	u12480
u12481:
	goto	l7837
u12480:
	line	723
	
l7833:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7717
	line	731
	
l7837:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12491
	goto	u12490
u12491:
	goto	l7845
u12490:
	
l7839:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12501
	goto	u12500
u12501:
	goto	l7845
u12500:
	line	733
	
l7841:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	734
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u12511
	goto	u12510
u12511:
	goto	l562
u12510:
	goto	l7711
	line	742
	
l7845:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	744
	
l7847:	
	movlw	0Ch
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	01Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12521
	goto	u12520
u12521:
	goto	l562
u12520:
	
l7849:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12531
	goto	u12530
u12531:
	goto	l7853
u12530:
	
l7851:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12541
	goto	u12540
u12541:
	goto	l562
u12540:
	line	746
	
l7853:	
	movlw	low(05h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	goto	l7717
	line	753
	
l7857:	
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	754
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	061h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12551
	goto	u12550
u12551:
	goto	l697
u12550:
	line	755
	
l7859:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	
l697:	
	line	763
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12561
	goto	u12560
u12561:
	goto	l7865
u12560:
	
l7861:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12571
	goto	u12570
u12571:
	goto	l7865
u12570:
	goto	l8023
	line	767
	
l7865:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u12585
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u12585:
	skipnc
	goto	u12581
	goto	u12580
u12581:
	goto	l7869
u12580:
	
l7867:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0180h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	line	772
	
l7869:	
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12591
	goto	u12590
u12591:
	goto	l7895
u12590:
	line	774
	
l7871:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12601
	goto	u12600
u12601:
	goto	l7883
u12600:
	line	776
	
l7873:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	777
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12611
	goto	u12610
u12611:
	goto	l7877
u12610:
	goto	l8023
	line	779
	
l7877:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7833
	line	784
	
l7883:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	785
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12621
	goto	u12620
u12621:
	goto	l7887
u12620:
	goto	l8023
	line	787
	
l7887:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	788
	
l7889:	
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	789
	
l7891:	
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@st)^080h
	goto	l7717
	line	800
	
l7895:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12631
	goto	u12630
u12631:
	goto	l7909
u12630:
	line	802
	
l7897:	
	movlw	07h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0D0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u12641
	goto	u12640
u12641:
	goto	l7907
u12640:
	line	804
	
l7899:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	805
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u12651
	goto	u12650
u12651:
	goto	l7923
u12650:
	goto	l7781
	line	815
	
l7907:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l7923
	line	820
	
l7909:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u12661
	goto	u12660
u12661:
	goto	l7907
u12660:
	line	822
	
l7911:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	823
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipc
	goto	u12671
	goto	u12670
u12671:
	goto	l7923
u12670:
	line	825
	
l7913:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	826
	
l7915:	
	clrf	(ChargeProcess_Slot@ty)^0180h
	goto	l7807
	line	839
	
l7923:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12681
	goto	u12680
u12681:
	goto	l7929
u12680:
	line	841
	
l7925:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	842
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u12691
	goto	u12690
u12691:
	goto	l562
u12690:
	goto	l7711
	line	850
	
l7929:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l8023
	line	861
	
l7931:	
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12701
	goto	u12700
u12701:
	goto	l7949
u12700:
	line	863
	
l7933:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	864
	
l7935:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12711
	goto	u12710
u12711:
	goto	l7939
u12710:
	
l7937:	
	movlw	02h
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_ChargeProcess_Slot$374)^080h
	clrf	(_ChargeProcess_Slot$374+1)^080h
	goto	l7941
	
l7939:	
	movlw	032h
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_ChargeProcess_Slot$374)^080h
	clrf	(_ChargeProcess_Slot$374+1)^080h
	
l7941:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 6	;RP1=0, select bank1
	movf	(_ChargeProcess_Slot$374+1)^080h,w
	xorlw	80h
	sublw	080h
	skipz
	goto	u12725
	movf	(_ChargeProcess_Slot$374)^080h,w
	subwf	indf,w
u12725:

	skipc
	goto	u12721
	goto	u12720
u12721:
	goto	l8023
u12720:
	line	866
	
l7943:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l7891
	line	875
	
l7949:	
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipnc
	goto	u12731
	goto	u12730
u12731:
	goto	l7319
u12730:
	line	877
	
l7951:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	878
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12741
	goto	u12740
u12741:
	goto	l7955
u12740:
	goto	l8023
	line	880
	
l7955:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	881
	
l7957:	
	movlw	low(04h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@st)^080h
	line	882
	
l7959:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	goto	l7743
	line	895
	
l7969:	
	movlw	0Fh
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12751
	goto	u12750
u12751:
	goto	l7983
u12750:
	line	897
	
l7971:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	898
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12761
	goto	u12760
u12761:
	goto	l7887
u12760:
	goto	l8023
	line	914
	
l7983:	
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12771
	goto	u12770
u12771:
	goto	l7987
u12770:
	
l7985:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12781
	goto	u12780
u12781:
	goto	l8003
u12780:
	line	916
	
l7987:	
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	08Dh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12791
	goto	u12790
u12791:
	goto	l7319
u12790:
	
l7989:	
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12804
u12805:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12804:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12805
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u12811
	goto	u12810
u12811:
	goto	l7319
u12810:
	line	918
	
l7991:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	919
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12821
	goto	u12820
u12821:
	goto	l7805
u12820:
	goto	l8023
	line	932
	
l8003:	
	movlw	02h
	subwf	(ChargeProcess_Slot@v+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0180h,w
	skipc
	goto	u12831
	goto	u12830
u12831:
	goto	l7319
u12830:
	line	934
	
l8005:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	935
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12841
	goto	u12840
u12841:
	goto	l7805
u12840:
	goto	l8023
	line	948
	
l8017:	
	clrf	(ChargeProcess_Slot@st)^080h
	line	949
	goto	l8023
	line	141
	
l8021:	
	bcf	status, 6	;RP1=0, select bank1
	movf	(ChargeProcess_Slot@st)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l7287
	xorlw	1^0	; case 1
	skipnz
	goto	l7299
	xorlw	2^1	; case 2
	skipnz
	goto	l7709
	xorlw	3^2	; case 3
	skipnz
	goto	l7723
	xorlw	4^3	; case 4
	skipnz
	goto	l7749
	xorlw	5^4	; case 5
	skipnz
	goto	l7857
	xorlw	6^5	; case 6
	skipnz
	goto	l7931
	xorlw	7^6	; case 7
	skipnz
	goto	l7969
	xorlw	8^7	; case 8
	skipnz
	goto	l7527
	xorlw	9^8	; case 9
	skipnz
	goto	l7663
	goto	l8017
	opt asmopt_pop

	line	950
	
l562:	
	line	952
	
l8023:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@st)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ty)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0180h,w
	movwf	indf
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ct)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@ct+1)^0180h,w
	movwf	indf
	line	953
	
l740:	
	return
	opt stack 0
GLOBAL	__end_of_ChargeProcess_Slot
	__end_of_ChargeProcess_Slot:
	signat	_ChargeProcess_Slot,4217
	global	___wmul

;; *************** function ___wmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
;; Parameters:    Size  Location     Type
;;  multiplier      2   26[BANK0 ] unsigned int 
;;  multiplicand    2   28[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  product         2    0[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   26[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       0       2       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       2       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
global __ptext14
__ptext14:	;psect for function ___wmul
psect	text14
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
	global	__size_of___wmul
	__size_of___wmul	equ	__end_of___wmul-___wmul
	
___wmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___wmul: [wreg+status,2+status,0]
	line	43
	
l6801:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___wmul@product)^080h
	clrf	(___wmul@product+1)^080h
	line	45
	
l6803:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(___wmul@multiplier),(0)&7
	goto	u10491
	goto	u10490
u10491:
	goto	l6807
u10490:
	line	46
	
l6805:	
	movf	(___wmul@multiplicand),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(___wmul@product)^080h,f
	skipnc
	incf	(___wmul@product+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(___wmul@multiplicand+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(___wmul@product+1)^080h,f
	line	47
	
l6807:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(___wmul@multiplicand),f
	rlf	(___wmul@multiplicand+1),f
	line	48
	
l6809:	
	clrc
	rrf	(___wmul@multiplier+1),f
	rrf	(___wmul@multiplier),f
	line	49
	
l6811:	
	movf	((___wmul@multiplier)),w
iorwf	((___wmul@multiplier+1)),w
	btfss	status,2
	goto	u10501
	goto	u10500
u10501:
	goto	l6803
u10500:
	line	52
	
l6813:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___wmul@product+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___wmul+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(___wmul@product)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___wmul)
	line	53
	
l859:	
	return
	opt stack 0
GLOBAL	__end_of___wmul
	__end_of___wmul:
	signat	___wmul,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   26[BANK0 ] unsigned int 
;;  dividend        2   28[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    1[BANK1 ] unsigned int 
;;  counter         1    0[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   26[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       0       3       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       3       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext15
__ptext15:	;psect for function ___lwdiv
psect	text15
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l6649:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___lwdiv@quotient)^080h
	clrf	(___lwdiv@quotient+1)^080h
	line	15
	
l6651:	
	bcf	status, 5	;RP0=0, select bank0
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u10211
	goto	u10210
u10211:
	goto	l6671
u10210:
	line	16
	
l6653:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___lwdiv@counter)^080h
	incf	(___lwdiv@counter)^080h,f
	line	17
	goto	l6657
	line	18
	
l6655:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	bsf	status, 5	;RP0=1, select bank1
	incf	(___lwdiv@counter)^080h,f
	line	17
	
l6657:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u10221
	goto	u10220
u10221:
	goto	l6655
u10220:
	line	22
	
l6659:	
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(___lwdiv@quotient)^080h,f
	rlf	(___lwdiv@quotient+1)^080h,f
	line	23
	
l6661:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u10235
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u10235:
	skipc
	goto	u10231
	goto	u10230
u10231:
	goto	l6667
u10230:
	line	24
	
l6663:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l6665:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(___lwdiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l6667:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l6669:	
	bsf	status, 5	;RP0=1, select bank1
	decfsz	(___lwdiv@counter)^080h,f
	goto	u10241
	goto	u10240
u10241:
	goto	l6659
u10240:
	line	30
	
l6671:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lwdiv@quotient+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lwdiv+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lwdiv@quotient)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lwdiv)
	line	31
	
l1196:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    0[BANK1 ] unsigned long 
;;  multiplicand    4    4[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4   26[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    0[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       8       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext16
__ptext16:	;psect for function ___lmul
psect	text16
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l6611:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l868:	
	line	121
	bsf	status, 5	;RP0=1, select bank1
	btfss	(___lmul@multiplier)^080h,(0)&7
	goto	u10141
	goto	u10140
u10141:
	goto	l6615
u10140:
	line	122
	
l6613:	
	movf	(___lmul@multiplicand)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product),f
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lmul@multiplicand+1)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10151
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product+1),f
u10151:
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lmul@multiplicand+2)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10152
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product+2),f
u10152:
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lmul@multiplicand+3)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10153
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product+3),f
u10153:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 5	;RP0=0, select bank0

	line	123
	
l6615:	
	clrc
	bsf	status, 5	;RP0=1, select bank1
	rlf	(___lmul@multiplicand)^080h,f
	rlf	(___lmul@multiplicand+1)^080h,f
	rlf	(___lmul@multiplicand+2)^080h,f
	rlf	(___lmul@multiplicand+3)^080h,f
	line	124
	
l6617:	
	clrc
	rrf	(___lmul@multiplier+3)^080h,f
	rrf	(___lmul@multiplier+2)^080h,f
	rrf	(___lmul@multiplier+1)^080h,f
	rrf	(___lmul@multiplier)^080h,f
	line	125
	movf	(___lmul@multiplier+3)^080h,w
	iorwf	(___lmul@multiplier+2)^080h,w
	iorwf	(___lmul@multiplier+1)^080h,w
	iorwf	(___lmul@multiplier)^080h,w
	skipz
	goto	u10161
	goto	u10160
u10161:
	goto	l868
u10160:
	line	128
	
l6619:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+3),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+2),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul)^080h

	line	129
	
l871:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    8[BANK1 ] unsigned long 
;;  dividend        4   12[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   17[BANK1 ] unsigned long 
;;  counter         1   16[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    8[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       0       5       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext17
__ptext17:	;psect for function ___lldiv
psect	text17
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l6623:	
	clrf	(___lldiv@quotient)^080h
	clrf	(___lldiv@quotient+1)^080h
	clrf	(___lldiv@quotient+2)^080h
	clrf	(___lldiv@quotient+3)^080h
	line	15
	
l6625:	
	movf	(___lldiv@divisor+3)^080h,w
	iorwf	(___lldiv@divisor+2)^080h,w
	iorwf	(___lldiv@divisor+1)^080h,w
	iorwf	(___lldiv@divisor)^080h,w
	skipnz
	goto	u10171
	goto	u10170
u10171:
	goto	l6645
u10170:
	line	16
	
l6627:	
	clrf	(___lldiv@counter)^080h
	incf	(___lldiv@counter)^080h,f
	line	17
	goto	l6631
	line	18
	
l6629:	
	clrc
	rlf	(___lldiv@divisor)^080h,f
	rlf	(___lldiv@divisor+1)^080h,f
	rlf	(___lldiv@divisor+2)^080h,f
	rlf	(___lldiv@divisor+3)^080h,f
	line	19
	incf	(___lldiv@counter)^080h,f
	line	17
	
l6631:	
	btfss	(___lldiv@divisor+3)^080h,(31)&7
	goto	u10181
	goto	u10180
u10181:
	goto	l6629
u10180:
	line	22
	
l6633:	
	clrc
	rlf	(___lldiv@quotient)^080h,f
	rlf	(___lldiv@quotient+1)^080h,f
	rlf	(___lldiv@quotient+2)^080h,f
	rlf	(___lldiv@quotient+3)^080h,f
	line	23
	
l6635:	
	movf	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,w
	skipz
	goto	u10195
	movf	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,w
	skipz
	goto	u10195
	movf	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,w
	skipz
	goto	u10195
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,w
u10195:
	skipc
	goto	u10191
	goto	u10190
u10191:
	goto	l6641
u10190:
	line	24
	
l6637:	
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,f
	movf	(___lldiv@divisor+1)^080h,w
	skipc
	incfsz	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,f
	movf	(___lldiv@divisor+2)^080h,w
	skipc
	incfsz	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,f
	movf	(___lldiv@divisor+3)^080h,w
	skipc
	incfsz	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,f
	line	25
	
l6639:	
	bsf	(___lldiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l6641:	
	clrc
	rrf	(___lldiv@divisor+3)^080h,f
	rrf	(___lldiv@divisor+2)^080h,f
	rrf	(___lldiv@divisor+1)^080h,f
	rrf	(___lldiv@divisor)^080h,f
	line	28
	
l6643:	
	decfsz	(___lldiv@counter)^080h,f
	goto	u10201
	goto	u10200
u10201:
	goto	l6633
u10200:
	line	30
	
l6645:	
	movf	(___lldiv@quotient+3)^080h,w
	movwf	(?___lldiv+3)^080h
	movf	(___lldiv@quotient+2)^080h,w
	movwf	(?___lldiv+2)^080h
	movf	(___lldiv@quotient+1)^080h,w
	movwf	(?___lldiv+1)^080h
	movf	(___lldiv@quotient)^080h,w
	movwf	(?___lldiv)^080h

	line	31
	
l1143:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1   26[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1   28[BANK0 ] unsigned char 
;;  product         1   27[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext18
__ptext18:	;psect for function ___bmul
psect	text18
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___bmul: [wreg+status,2+status,0]
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplier)
	line	6
	
l6817:	
	clrf	(___bmul@product)
	line	43
	
l6819:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u10511
	goto	u10510
u10511:
	goto	l6823
u10510:
	line	44
	
l6821:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l6823:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l6825:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u10521
	goto	u10520
u10521:
	goto	l6819
u10520:
	line	50
	
l6827:	
	movf	(___bmul@product),w
	line	51
	
l877:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 63 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2   26[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	63
global __ptext19
__ptext19:	;psect for function _Detect_BatteryType
psect	text19
	file	"charge_mgr.c"
	line	63
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	65
	
l6769:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u10431
	goto	u10430
u10431:
	goto	l6775
u10430:
	line	66
	
l6771:	
	movlw	low(0)
	goto	l548
	line	67
	
l6775:	
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u10441
	goto	u10440
u10441:
	goto	l6781
u10440:
	goto	l6771
	line	82
	
l6781:	
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u10451
	goto	u10450
u10451:
	goto	l6789
u10450:
	
l6783:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u10461
	goto	u10460
u10461:
	goto	l6789
u10460:
	line	83
	
l6785:	
	movlw	low(05h)
	goto	l548
	line	88
	
l6789:	
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u10471
	goto	u10470
u10471:
	goto	l6771
u10470:
	
l6791:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u10481
	goto	u10480
u10481:
	goto	l6771
u10480:
	line	89
	
l6793:	
	movlw	low(01h)
	line	92
	
l548:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1   26[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    5[BANK1 ] unsigned char 
;;  j               1    4[BANK1 ] unsigned char 
;;  adsum           4    7[BANK1 ] volatile unsigned long 
;;  ad_temp         2   15[BANK1 ] volatile unsigned int 
;;  admax           2   13[BANK1 ] volatile unsigned int 
;;  admin           2   11[BANK1 ] volatile unsigned int 
;;  i               1    6[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       0      13       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       1      17       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	49
global __ptext20
__ptext20:	;psect for function _ADC_Sample
psect	text20
	file	"adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ADC_Sample@adch)^080h
	line	51
	
l6545:	
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	52
	
l6547:	
	clrf	(ADC_Sample@admin)^080h	;volatile
	clrf	(ADC_Sample@admin+1)^080h	;volatile
	line	53
	clrf	(ADC_Sample@admax)^080h	;volatile
	clrf	(ADC_Sample@admax+1)^080h	;volatile
	line	54
	clrf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	line	58
	
l6549:	
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u9991
	goto	u9990
u9991:
	goto	l6555
u9990:
	
l6551:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u10001
	goto	u10000
u10001:
	goto	l6555
u10000:
	line	60
	
l6553:	
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	61
	opt asmopt_push
opt asmopt_off
	movlw	132
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_ADC_Sample+0)^080h+0),f
	u13137:
decfsz	(??_ADC_Sample+0)^080h+0,f
	goto	u13137
	nop
opt asmopt_pop

	line	62
	goto	l6557
	line	64
	
l6555:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	67
	
l6557:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	btfss	(ADC_Sample@adch)^080h,(4)&7
	goto	u10011
	goto	u10010
u10011:
	goto	l466
u10010:
	line	69
	
l6559:	
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l6561:	
	movlw	low(0Fh)
	andwf	(ADC_Sample@adch)^080h,f
	line	71
	goto	l6563
	line	72
	
l466:	
	line	73
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l6563:	
	clrf	(ADC_Sample@i)^080h
	line	79
	
l6569:	
	movf	(ADC_Sample@adch)^080h,w
	movwf	(??_ADC_Sample+0)^080h+0
	movlw	(02h)-1
u10025:
	clrc
	rlf	(??_ADC_Sample+0)^080h+0,f
	addlw	-1
	skipz
	goto	u10025
	clrc
	rlf	(??_ADC_Sample+0)^080h+0,w
	iorlw	081h
	movwf	(149)^080h	;volatile
	line	80
	
l6571:	
	opt asmopt_push
opt asmopt_off
	movlw	5
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_ADC_Sample+0)^080h+0),f
	u13147:
decfsz	(??_ADC_Sample+0)^080h+0,f
	goto	u13147
	nop2
opt asmopt_pop

	line	81
	
l6573:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l6575:	
	clrf	(ADC_Sample@j)^080h
	line	85
	goto	l470
	
l471:	
	line	87
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decfsz	(ADC_Sample@j)^080h,f
	goto	u10031
	goto	u10030
u10031:
	goto	l470
u10030:
	line	89
	
l6577:	
	movlw	low(0)
	goto	l473
	line	90
	
l470:	
	line	85
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u10041
	goto	u10040
u10041:
	goto	l471
u10040:
	line	93
	
l6581:	
	movf	(153)^080h,w	;volatile
	movwf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	swapf	(ADC_Sample@ad_temp)^080h,f	;volatile
	swapf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	
l6583:	
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	addwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	line	96
	
l6585:	
	movf	((ADC_Sample@admax)^080h),w	;volatile
iorwf	((ADC_Sample@admax+1)^080h),w	;volatile
	btfss	status,2
	goto	u10051
	goto	u10050
u10051:
	goto	l6589
u10050:
	line	98
	
l6587:	
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	line	99
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	100
	goto	l476
	line	102
	
l6589:	
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	subwf	(ADC_Sample@admax+1)^080h,w	;volatile
	skipz
	goto	u10065
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	subwf	(ADC_Sample@admax)^080h,w	;volatile
u10065:
	skipnc
	goto	u10061
	goto	u10060
u10061:
	goto	l6593
u10060:
	line	103
	
l6591:	
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	goto	l476
	line	105
	
l6593:	
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	skipz
	goto	u10075
	movf	(ADC_Sample@admin)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp)^080h,w	;volatile
u10075:
	skipnc
	goto	u10071
	goto	u10070
u10071:
	goto	l476
u10070:
	line	106
	
l6595:	
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	108
	
l476:	
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	0+(??_ADC_Sample+0)^080h+0,w
	addwf	(ADC_Sample@adsum)^080h,f	;volatile
	movf	1+(??_ADC_Sample+0)^080h+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10081
	addwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u10081:
	movf	2+(??_ADC_Sample+0)^080h+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10082
	addwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u10082:
	movf	3+(??_ADC_Sample+0)^080h+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10083
	addwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u10083:

	line	76
	
l6597:	
	incf	(ADC_Sample@i)^080h,f
	
l6599:	
	movlw	low(022h)
	subwf	(ADC_Sample@i)^080h,w
	skipc
	goto	u10091
	goto	u10090
u10091:
	goto	l6569
u10090:
	line	112
	
l6601:	
	movf	(ADC_Sample@admax)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@admax+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	0+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	movf	1+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)^080h+0,w
	goto	u10105
	goto	u10106
u10105:
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u10106:
	movf	2+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)^080h+0,w
	goto	u10107
	goto	u10108
u10107:
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u10108:
	movf	3+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)^080h+0,w
	goto	u10109
	goto	u10100
u10109:
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u10100:

	line	113
	movf	(ADC_Sample@admin)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	3+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum+3)^080h,w	;volatile
	skipz
	goto	u10115
	movf	2+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum+2)^080h,w	;volatile
	skipz
	goto	u10115
	movf	1+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum+1)^080h,w	;volatile
	skipz
	goto	u10115
	movf	0+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum)^080h,w	;volatile
u10115:
	skipc
	goto	u10111
	goto	u10110
u10111:
	goto	l480
u10110:
	line	114
	
l6603:	
	movf	(ADC_Sample@admin)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	0+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	movf	1+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)^080h+0,w
	goto	u10125
	goto	u10126
u10125:
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u10126:
	movf	2+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)^080h+0,w
	goto	u10127
	goto	u10128
u10127:
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u10128:
	movf	3+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)^080h+0,w
	goto	u10129
	goto	u10120
u10129:
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u10120:

	goto	l6605
	line	115
	
l480:	
	line	116
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	118
	
l6605:	
	movf	(ADC_Sample@adsum)^080h,w	;volatile
	movwf	(??_ADC_Sample+0)^080h+0
	movf	(ADC_Sample@adsum+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	movf	(ADC_Sample@adsum+2)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+2)
	movf	(ADC_Sample@adsum+3)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+3)
	movlw	05h
u10135:
	clrc
	rrf	(??_ADC_Sample+0)^080h+3,f
	rrf	(??_ADC_Sample+0)^080h+2,f
	rrf	(??_ADC_Sample+0)^080h+1,f
	rrf	(??_ADC_Sample+0)^080h+0,f
u10130:
	addlw	-1
	skipz
	goto	u10135
	movf	1+(??_ADC_Sample+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_adresult+1)	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(??_ADC_Sample+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_adresult)	;volatile
	line	119
	
l6607:	
	movlw	low(0A5h)
	line	120
	
l473:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 147 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   22[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0       8       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_CCCV_Control
;;		_Charging_Control
;;		_PowerOnLedSequence
;;		_Update_LED_Slot
;;		i1_ADC_Sample
;;		i1___lldiv
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	147
global __ptext21
__ptext21:	;psect for function _Isr_Timer
psect	text21
	file	"main.c"
	line	147
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 2
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	movf	btemp+1,w
	movwf	(??_Isr_Timer+3)
	ljmp	_Isr_Timer
psect	text21
	line	150
	
i1l8051:	
	btfss	(90/8),(90)&7	;volatile
	goto	u1289_21
	goto	u1289_20
u1289_21:
	goto	i1l349
u1289_20:
	line	152
	
i1l8053:	
	bcf	(90/8),(90)&7	;volatile
	line	153
	
i1l8055:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	154
# 154 "main.c"
clrwdt ;# 
psect	text21
	line	157
	
i1l8057:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	158
	
i1l8059:	
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u1290_21
	goto	u1290_20
u1290_21:
	goto	i1l8063
u1290_20:
	line	159
	
i1l8061:	
	clrf	(_g_pwmCounter)	;volatile
	line	162
	
i1l8063:	
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u1291_21
	goto	u1291_20
u1291_21:
	goto	i1l346
u1291_20:
	
i1l8065:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u1292_21
	goto	u1292_20
u1292_21:
	goto	i1l346
u1292_20:
	line	163
	
i1l8067:	
	bsf	(55/8),(55)&7	;volatile
	goto	i1l8069
	line	164
	
i1l346:	
	line	165
	bcf	(55/8),(55)&7	;volatile
	line	168
	
i1l8069:	
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u1293_21
	goto	u1293_20
u1293_21:
	goto	i1l8139
u1293_20:
	line	170
	
i1l8071:	
	fcall	_PowerOnLedSequence
	goto	i1l349
	line	177
	
i1l351:	
	line	179
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u1294_21
	goto	u1294_20
u1294_21:
	goto	i1l349
u1294_20:
	
i1l8075:	
	btfsc	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u1295_21
	goto	u1295_20
u1295_21:
	goto	i1l349
u1295_20:
	goto	i1l8079
	line	181
	
i1l355:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l368
	
i1l357:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l368
	
i1l358:	
	bsf	(51/8),(51)&7	;volatile
	goto	i1l368
	
i1l359:	
	bsf	(50/8),(50)&7	;volatile
	goto	i1l368
	
i1l360:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l368
	
i1l361:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l368
	
i1l362:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l368
	
i1l363:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l368
	
i1l364:	
	bsf	(48/8),(48)&7	;volatile
	goto	i1l368
	
i1l365:	
	bsf	(49/8),(49)&7	;volatile
	goto	i1l368
	
i1l366:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l368
	
i1l367:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l368
	
i1l8079:	
	movf	(_g_scanIndex),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l355
	xorlw	1^0	; case 1
	skipnz
	goto	i1l357
	xorlw	2^1	; case 2
	skipnz
	goto	i1l358
	xorlw	3^2	; case 3
	skipnz
	goto	i1l359
	xorlw	4^3	; case 4
	skipnz
	goto	i1l360
	xorlw	5^4	; case 5
	skipnz
	goto	i1l361
	xorlw	6^5	; case 6
	skipnz
	goto	i1l362
	xorlw	7^6	; case 7
	skipnz
	goto	i1l363
	xorlw	8^7	; case 8
	skipnz
	goto	i1l364
	xorlw	9^8	; case 9
	skipnz
	goto	i1l365
	xorlw	10^9	; case 10
	skipnz
	goto	i1l366
	xorlw	11^10	; case 11
	skipnz
	goto	i1l367
	goto	i1l368
	opt asmopt_pop

	
i1l368:	
	line	182
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	i1l349
	line	188
	
i1l8081:	
	movf	(_g_scanIndex),w	;volatile
	fcall	_Update_LED_Slot
	line	190
	
i1l8083:	
	movlw	low(02h)
	movwf	(_g_scanPhase)	;volatile
	line	191
	goto	i1l349
	line	194
	
i1l8085:	
	movf	((_g_scanIndex)),w	;volatile
	btfss	status,2
	goto	u1296_21
	goto	u1296_20
u1296_21:
	goto	i1l8131
u1296_20:
	line	197
	
i1l8087:	
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u1297_21
	goto	u1297_20
u1297_21:
	goto	i1l8101
u1297_20:
	line	199
	
i1l8089:	
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	200
	
i1l8091:	
	clrf	(i1ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	i1_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	201
	
i1l8093:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u1298_21
	goto	u1298_20
u1298_21:
	goto	i1l8099
u1298_20:
	line	203
	
i1l8095:	
	movf	(_adresult),w	;volatile
	movwf	(i1___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((i1___lldiv@divisor))+1
	clrf	2+((i1___lldiv@divisor))
	clrf	3+((i1___lldiv@divisor))
	movlw	0
	movwf	(i1___lldiv@dividend+3)
	movlw	04Bh
	movwf	(i1___lldiv@dividend+2)
	movlw	0
	movwf	(i1___lldiv@dividend+1)
	movlw	0
	movwf	(i1___lldiv@dividend)

	fcall	i1___lldiv
	movf	(3+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+3)
	movf	(2+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+2)
	movf	(1+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+1)
	movf	(0+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt)

	line	204
	
i1l8097:	
	movf	(Isr_Timer@pt+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv+1)^080h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(Isr_Timer@pt),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv)^080h	;volatile
	line	206
	
i1l8099:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	209
	
i1l8101:	
	fcall	_Charging_Control
	line	210
	
i1l8103:	
	fcall	_CCCV_Control
	line	214
	
i1l8105:	
	movf	((_g_tempPhase)),w	;volatile
	btfss	status,2
	goto	u1299_21
	goto	u1299_20
u1299_21:
	goto	i1l8117
u1299_20:
	line	216
	
i1l8107:	
	incf	(_g_tempReadRoundCnt),f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1),f	;volatile
	line	217
	
i1l8109:	
	movlw	0
	subwf	(_g_tempReadRoundCnt+1),w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt),w	;volatile
	skipc
	goto	u1300_21
	goto	u1300_20
u1300_21:
	goto	i1l8125
u1300_20:
	line	219
	
i1l8111:	
	clrf	(_g_tempReadRoundCnt)	;volatile
	clrf	(_g_tempReadRoundCnt+1)	;volatile
	line	220
	
i1l8113:	
	movlw	low(01h)
	movwf	(_g_tempPhase)	;volatile
	line	221
	
i1l8115:	
	clrf	(_g_tempSettleCnt)	;volatile
	clrf	(_g_tempSettleCnt+1)	;volatile
	goto	i1l8125
	line	226
	
i1l8117:	
	incf	(_g_tempSettleCnt),f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1),f	;volatile
	line	227
	
i1l8119:	
	movlw	0
	subwf	(_g_tempSettleCnt+1),w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt),w	;volatile
	skipc
	goto	u1301_21
	goto	u1301_20
u1301_21:
	goto	i1l8125
u1301_20:
	line	229
	
i1l8121:	
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	230
	
i1l8123:	
	clrf	(_g_tempSettleCnt)	;volatile
	clrf	(_g_tempSettleCnt+1)	;volatile
	line	231
	clrf	(_g_tempPhase)	;volatile
	line	237
	
i1l8125:	
	incf	(_g_printTick),f	;volatile
	skipnz
	incf	(_g_printTick+1),f	;volatile
	movlw	0
	subwf	((_g_printTick+1)),w	;volatile
	movlw	064h
	skipnz
	subwf	((_g_printTick)),w	;volatile
	skipc
	goto	u1302_21
	goto	u1302_20
u1302_21:
	goto	i1l8131
u1302_20:
	line	239
	
i1l8127:	
	clrf	(_g_printTick)	;volatile
	clrf	(_g_printTick+1)	;volatile
	line	240
	
i1l8129:	
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	245
	
i1l8131:	
	movlw	low(0Ch)
	incf	(_g_scanIndex),f	;volatile
	subwf	((_g_scanIndex)),w	;volatile
	skipc
	goto	u1303_21
	goto	u1303_20
u1303_21:
	goto	i1l380
u1303_20:
	line	246
	
i1l8133:	
	clrf	(_g_scanIndex)	;volatile
	
i1l380:	
	line	247
	clrf	(_g_scanPhase)	;volatile
	line	248
	goto	i1l349
	line	175
	
i1l8139:	
	movf	(_g_scanPhase),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 2
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           17     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l351
	xorlw	1^0	; case 1
	skipnz
	goto	i1l8081
	xorlw	2^1	; case 2
	skipnz
	goto	i1l8085
	goto	i1l380
	opt asmopt_pop

	line	255
	
i1l349:	
	movf	(??_Isr_Timer+3),w
	movwf	btemp+1
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^00h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	i1___lldiv

;; *************** function i1___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    0[COMMON] unsigned long 
;;  dividend        4    4[COMMON] unsigned long 
;; Auto vars:     Size  Location     Type
;;  __lldiv         4    9[COMMON] unsigned long 
;;  __lldiv         1    8[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    0[COMMON] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         8       0       0       0       0
;;      Locals:         5       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:        13       0       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext22
__ptext22:	;psect for function i1___lldiv
psect	text22
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_ofi1___lldiv
	__size_ofi1___lldiv	equ	__end_ofi1___lldiv-i1___lldiv
	
i1___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in i1___lldiv: [wreg+status,2+status,0]
	line	14
	
i1l8025:	
	clrf	(i1___lldiv@quotient)
	clrf	(i1___lldiv@quotient+1)
	clrf	(i1___lldiv@quotient+2)
	clrf	(i1___lldiv@quotient+3)
	line	15
	
i1l8027:	
	movf	(i1___lldiv@divisor+3),w
	iorwf	(i1___lldiv@divisor+2),w
	iorwf	(i1___lldiv@divisor+1),w
	iorwf	(i1___lldiv@divisor),w
	skipnz
	goto	u1285_21
	goto	u1285_20
u1285_21:
	goto	i1l8047
u1285_20:
	line	16
	
i1l8029:	
	clrf	(i1___lldiv@counter)
	incf	(i1___lldiv@counter),f
	line	17
	goto	i1l8033
	line	18
	
i1l8031:	
	clrc
	rlf	(i1___lldiv@divisor),f
	rlf	(i1___lldiv@divisor+1),f
	rlf	(i1___lldiv@divisor+2),f
	rlf	(i1___lldiv@divisor+3),f
	line	19
	incf	(i1___lldiv@counter),f
	line	17
	
i1l8033:	
	btfss	(i1___lldiv@divisor+3),(31)&7
	goto	u1286_21
	goto	u1286_20
u1286_21:
	goto	i1l8031
u1286_20:
	line	22
	
i1l8035:	
	clrc
	rlf	(i1___lldiv@quotient),f
	rlf	(i1___lldiv@quotient+1),f
	rlf	(i1___lldiv@quotient+2),f
	rlf	(i1___lldiv@quotient+3),f
	line	23
	
i1l8037:	
	movf	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),w
	skipz
	goto	u1287_25
	movf	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),w
	skipz
	goto	u1287_25
	movf	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),w
	skipz
	goto	u1287_25
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),w
u1287_25:
	skipc
	goto	u1287_21
	goto	u1287_20
u1287_21:
	goto	i1l8043
u1287_20:
	line	24
	
i1l8039:	
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),f
	movf	(i1___lldiv@divisor+1),w
	skipc
	incfsz	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),f
	movf	(i1___lldiv@divisor+2),w
	skipc
	incfsz	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),f
	movf	(i1___lldiv@divisor+3),w
	skipc
	incfsz	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),f
	line	25
	
i1l8041:	
	bsf	(i1___lldiv@quotient)+(0/8),(0)&7
	line	27
	
i1l8043:	
	clrc
	rrf	(i1___lldiv@divisor+3),f
	rrf	(i1___lldiv@divisor+2),f
	rrf	(i1___lldiv@divisor+1),f
	rrf	(i1___lldiv@divisor),f
	line	28
	
i1l8045:	
	decfsz	(i1___lldiv@counter),f
	goto	u1288_21
	goto	u1288_20
u1288_21:
	goto	i1l8035
u1288_20:
	line	30
	
i1l8047:	
	movf	(i1___lldiv@quotient+3),w
	movwf	(?i1___lldiv+3)
	movf	(i1___lldiv@quotient+2),w
	movwf	(?i1___lldiv+2)
	movf	(i1___lldiv@quotient+1),w
	movwf	(?i1___lldiv+1)
	movf	(i1___lldiv@quotient),w
	movwf	(?i1___lldiv)

	line	31
	
i1l1143:	
	return
	opt stack 0
GLOBAL	__end_ofi1___lldiv
	__end_ofi1___lldiv:
	signat	i1___lldiv,92
	global	i1_ADC_Sample

;; *************** function i1_ADC_Sample *****************
;; Defined at:
;;		line 49 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    0[BANK0 ] unsigned char 
;;  ADC_Sample      4    3[BANK0 ] volatile unsigned long 
;;  ADC_Sample      2   11[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    9[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    7[BANK0 ] volatile unsigned int 
;;  ADC_Sample      1    2[BANK0 ] unsigned char 
;;  ADC_Sample      1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      13       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	49
global __ptext23
__ptext23:	;psect for function i1_ADC_Sample
psect	text23
	file	"adc_drv.c"
	line	49
	global	__size_ofi1_ADC_Sample
	__size_ofi1_ADC_Sample	equ	__end_ofi1_ADC_Sample-i1_ADC_Sample
	
i1_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in i1_ADC_Sample: [wreg+status,2+status,0]
	movwf	(i1ADC_Sample@adch)
	line	51
	
i1l6331:	
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	52
	
i1l6333:	
	clrf	(i1ADC_Sample@admin)	;volatile
	clrf	(i1ADC_Sample@admin+1)	;volatile
	line	53
	clrf	(i1ADC_Sample@admax)	;volatile
	clrf	(i1ADC_Sample@admax+1)	;volatile
	line	54
	clrf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	line	58
	
i1l6335:	
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u962_21
	goto	u962_20
u962_21:
	goto	i1l6341
u962_20:
	
i1l6337:	
	btfss	(i1ADC_Sample@adldo),(2)&7
	goto	u963_21
	goto	u963_20
u963_21:
	goto	i1l6341
u963_20:
	line	60
	
i1l6339:	
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	61
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??i1_ADC_Sample+0)+0),f
	u1315_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u1315_27
opt asmopt_pop

	line	62
	goto	i1l6343
	line	64
	
i1l6341:	
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	67
	
i1l6343:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(i1ADC_Sample@adch),(4)&7
	goto	u964_21
	goto	u964_20
u964_21:
	goto	i1l466
u964_20:
	line	69
	
i1l6345:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
i1l6347:	
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(i1ADC_Sample@adch),f
	line	71
	goto	i1l6349
	line	72
	
i1l466:	
	line	73
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
i1l6349:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@i)
	
i1l6351:	
	movlw	low(022h)
	subwf	(i1ADC_Sample@i),w
	skipc
	goto	u965_21
	goto	u965_20
u965_21:
	goto	i1l6355
u965_20:
	goto	i1l6387
	line	79
	
i1l6355:	
	movf	(i1ADC_Sample@adch),w
	movwf	(??i1_ADC_Sample+0)+0
	movlw	(02h)-1
u966_25:
	clrc
	rlf	(??i1_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u966_25
	clrc
	rlf	(??i1_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
i1l6357:	
	opt asmopt_push
opt asmopt_off
	movlw	6
movwf	((??i1_ADC_Sample+0)+0),f
	u1316_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u1316_27
	nop
opt asmopt_pop

	line	81
	
i1l6359:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
i1l6361:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@j)
	line	85
	goto	i1l470
	
i1l471:	
	line	87
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(i1ADC_Sample@j),f
	goto	u967_21
	goto	u967_20
u967_21:
	goto	i1l470
u967_20:
	line	89
	
i1l6363:	
	movlw	low(0)
	goto	i1l473
	line	90
	
i1l470:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u968_21
	goto	u968_20
u968_21:
	goto	i1l471
u968_20:
	line	93
	
i1l6367:	
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	swapf	(i1ADC_Sample@ad_temp),f	;volatile
	swapf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp),f	;volatile
	
i1l6369:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(i1ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(i1ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
i1l6371:	
	movf	((i1ADC_Sample@admax)),w	;volatile
iorwf	((i1ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u969_21
	goto	u969_20
u969_21:
	goto	i1l6375
u969_20:
	line	98
	
i1l6373:	
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	line	99
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	100
	goto	i1l476
	line	102
	
i1l6375:	
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	subwf	(i1ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u970_25
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	subwf	(i1ADC_Sample@admax),w	;volatile
u970_25:
	skipnc
	goto	u970_21
	goto	u970_20
u970_21:
	goto	i1l6379
u970_20:
	line	103
	
i1l6377:	
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	goto	i1l476
	line	105
	
i1l6379:	
	movf	(i1ADC_Sample@admin+1),w	;volatile
	subwf	(i1ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u971_25
	movf	(i1ADC_Sample@admin),w	;volatile
	subwf	(i1ADC_Sample@ad_temp),w	;volatile
u971_25:
	skipnc
	goto	u971_21
	goto	u971_20
u971_21:
	goto	i1l476
u971_20:
	line	106
	
i1l6381:	
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	108
	
i1l476:	
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	addwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u972_21
	addwf	(i1ADC_Sample@adsum+1),f	;volatile
u972_21:
	movf	2+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u972_22
	addwf	(i1ADC_Sample@adsum+2),f	;volatile
u972_22:
	movf	3+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u972_23
	addwf	(i1ADC_Sample@adsum+3),f	;volatile
u972_23:

	line	76
	
i1l6383:	
	incf	(i1ADC_Sample@i),f
	goto	i1l6351
	line	112
	
i1l6387:	
	movf	(i1ADC_Sample@admax),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admax+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u973_25
	goto	u973_26
u973_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u973_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u973_27
	goto	u973_28
u973_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u973_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u973_29
	goto	u973_20
u973_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u973_20:

	line	113
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	3+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u974_25
	movf	2+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u974_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u974_25
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),w	;volatile
u974_25:
	skipc
	goto	u974_21
	goto	u974_20
u974_21:
	goto	i1l480
u974_20:
	line	114
	
i1l6389:	
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u975_25
	goto	u975_26
u975_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u975_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u975_27
	goto	u975_28
u975_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u975_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u975_29
	goto	u975_20
u975_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u975_20:

	goto	i1l6391
	line	115
	
i1l480:	
	line	116
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	118
	
i1l6391:	
	movf	(i1ADC_Sample@adsum),w	;volatile
	movwf	(??i1_ADC_Sample+0)+0
	movf	(i1ADC_Sample@adsum+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	movf	(i1ADC_Sample@adsum+2),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+2)
	movf	(i1ADC_Sample@adsum+3),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+3)
	movlw	05h
u976_25:
	clrc
	rrf	(??i1_ADC_Sample+0)+3,f
	rrf	(??i1_ADC_Sample+0)+2,f
	rrf	(??i1_ADC_Sample+0)+1,f
	rrf	(??i1_ADC_Sample+0)+0,f
u976_20:
	addlw	-1
	skipz
	goto	u976_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
i1l6393:	
	movlw	low(0A5h)
	line	120
	
i1l473:	
	return
	opt stack 0
GLOBAL	__end_ofi1_ADC_Sample
	__end_ofi1_ADC_Sample:
	signat	i1_ADC_Sample,89
	global	_Update_LED_Slot

;; *************** function _Update_LED_Slot *****************
;; Defined at:
;;		line 31 in file "led.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    0[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	file	"led.c"
	line	31
global __ptext24
__ptext24:	;psect for function _Update_LED_Slot
psect	text24
	file	"led.c"
	line	31
	global	__size_of_Update_LED_Slot
	__size_of_Update_LED_Slot	equ	__end_of_Update_LED_Slot-_Update_LED_Slot
	
_Update_LED_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _Update_LED_Slot: [wreg]
	line	35
	
i1l845:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Slot
	__end_of_Update_LED_Slot:
	signat	_Update_LED_Slot,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 45 in file "led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	line	45
global __ptext25
__ptext25:	;psect for function _PowerOnLedSequence
psect	text25
	file	"led.c"
	line	45
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	47
	
i1l5189:	
	incf	(_g_powerOnTimer),f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1),f	;volatile
	line	49
	
i1l5191:	
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u727_21
	goto	u727_20
u727_21:
	goto	i1l5199
u727_20:
	line	52
	
i1l5193:	
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u728_21
	goto	u728_20
u728_21:
	goto	i1l853
u728_20:
	line	54
	
i1l5195:	
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	55
	
i1l5197:	
	movlw	low(01h)
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l853
	line	58
	
i1l5199:	
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u729_21
	goto	u729_20
u729_21:
	goto	i1l853
u729_20:
	line	61
	
i1l5201:	
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u730_21
	goto	u730_20
u730_21:
	goto	i1l853
u730_20:
	line	63
	
i1l5203:	
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	64
	
i1l5205:	
	movlw	low(02h)
	movwf	(_g_powerOnPhase)	;volatile
	line	68
	
i1l853:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
	global	_Charging_Control

;; *************** function _Charging_Control *****************
;; Defined at:
;;		line 967 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    5[COMMON] unsigned char 
;;  i               1    6[COMMON] unsigned char 
;;  chargeB7_12     1    4[COMMON] unsigned char 
;;  chargeB1_6      1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 100/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	967
global __ptext26
__ptext26:	;psect for function _Charging_Control
psect	text26
	file	"charge_mgr.c"
	line	967
	global	__size_of_Charging_Control
	__size_of_Charging_Control	equ	__end_of_Charging_Control-_Charging_Control
	
_Charging_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _Charging_Control: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	970
	
i1l6901:	
	clrf	(Charging_Control@chargeB1_6)
	line	971
	clrf	(Charging_Control@chargeB7_12)
	line	974
	
i1l6903:	
	movf	((_g_tempProtect)),w
	btfsc	status,2
	goto	u1054_21
	goto	u1054_20
u1054_21:
	goto	i1l6909
u1054_20:
	line	976
	
i1l744:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	bsf	(1073/8)^080h,(1073)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	bsf	(50/8),(50)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	bsf	(1074/8)^080h,(1074)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	bsf	(49/8),(49)&7	;volatile
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	
i1l745:	
	line	977
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	978
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	979
	
i1l6905:	
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	goto	i1l746
	line	986
	
i1l6909:	
	movf	((_g_vccProtect)),w
	btfsc	status,2
	goto	u1055_21
	goto	u1055_20
u1055_21:
	goto	i1l6919
u1055_20:
	line	988
	
i1l6911:	
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u1056_21
	goto	u1056_20
u1056_21:
	goto	i1l6917
u1056_20:
	goto	i1l744
	line	996
	
i1l6917:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	line	997
	goto	i1l6927
	line	1000
	
i1l6919:	
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u1057_21
	goto	u1057_20
u1057_21:
	goto	i1l6927
u1057_20:
	line	1002
	
i1l6921:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	incf	(_g_vccProtect),f
	goto	i1l744
	line	1012
	
i1l6927:	
	clrf	(Charging_Control@i)
	line	1014
	
i1l6933:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Charging_Control@s)
	line	1019
	
i1l6935:	
		movlw	2
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1058_21
	goto	u1058_20
u1058_21:
	goto	i1l6947
u1058_20:
	
i1l6937:	
		movlw	3
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1059_21
	goto	u1059_20
u1059_21:
	goto	i1l6947
u1059_20:
	
i1l6939:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1060_21
	goto	u1060_20
u1060_21:
	goto	i1l6947
u1060_20:
	
i1l6941:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1061_21
	goto	u1061_20
u1061_21:
	goto	i1l6947
u1061_20:
	
i1l6943:	
		movlw	8
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u1062_21
	goto	u1062_20
u1062_21:
	goto	i1l6953
u1062_20:
	goto	i1l6947
	line	1021
	
i1l762:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l6949
	
i1l764:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l6949
	
i1l765:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l6949
	
i1l766:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l6949
	
i1l767:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l6949
	
i1l768:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l6949
	
i1l769:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l6949
	
i1l770:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l6949
	
i1l771:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l6949
	
i1l772:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l6949
	
i1l773:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l6949
	
i1l774:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l6949
	
i1l6947:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l762
	xorlw	1^0	; case 1
	skipnz
	goto	i1l764
	xorlw	2^1	; case 2
	skipnz
	goto	i1l765
	xorlw	3^2	; case 3
	skipnz
	goto	i1l766
	xorlw	4^3	; case 4
	skipnz
	goto	i1l767
	xorlw	5^4	; case 5
	skipnz
	goto	i1l768
	xorlw	6^5	; case 6
	skipnz
	goto	i1l769
	xorlw	7^6	; case 7
	skipnz
	goto	i1l770
	xorlw	8^7	; case 8
	skipnz
	goto	i1l771
	xorlw	9^8	; case 9
	skipnz
	goto	i1l772
	xorlw	10^9	; case 10
	skipnz
	goto	i1l773
	xorlw	11^10	; case 11
	skipnz
	goto	i1l774
	goto	i1l6949
	opt asmopt_pop

	line	1024
	
i1l6949:	
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipnc
	goto	u1063_21
	goto	u1063_20
u1063_21:
	goto	i1l776
u1063_20:
	line	1025
	
i1l6951:	
	clrf	(Charging_Control@chargeB1_6)
	incf	(Charging_Control@chargeB1_6),f
	goto	i1l6963
	line	1026
	
i1l776:	
	line	1027
	clrf	(Charging_Control@chargeB7_12)
	incf	(Charging_Control@chargeB7_12),f
	goto	i1l6963
	line	1031
	
i1l6953:	
		decf	((Charging_Control@s)),w
	btfss	status,2
	goto	u1064_21
	goto	u1064_20
u1064_21:
	goto	i1l6961
u1064_20:
	goto	i1l6957
	line	1033
	
i1l782:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l6963
	
i1l784:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l6963
	
i1l785:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l6963
	
i1l786:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l6963
	
i1l787:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l6963
	
i1l788:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l6963
	
i1l789:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l6963
	
i1l790:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l6963
	
i1l791:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l6963
	
i1l792:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l6963
	
i1l793:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l6963
	
i1l794:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l6963
	
i1l6957:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l782
	xorlw	1^0	; case 1
	skipnz
	goto	i1l784
	xorlw	2^1	; case 2
	skipnz
	goto	i1l785
	xorlw	3^2	; case 3
	skipnz
	goto	i1l786
	xorlw	4^3	; case 4
	skipnz
	goto	i1l787
	xorlw	5^4	; case 5
	skipnz
	goto	i1l788
	xorlw	6^5	; case 6
	skipnz
	goto	i1l789
	xorlw	7^6	; case 7
	skipnz
	goto	i1l790
	xorlw	8^7	; case 8
	skipnz
	goto	i1l791
	xorlw	9^8	; case 9
	skipnz
	goto	i1l792
	xorlw	10^9	; case 10
	skipnz
	goto	i1l793
	xorlw	11^10	; case 11
	skipnz
	goto	i1l794
	goto	i1l6963
	opt asmopt_pop

	line	1037
	
i1l799:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l6963
	
i1l801:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l6963
	
i1l802:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	i1l6963
	
i1l803:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	i1l6963
	
i1l804:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l6963
	
i1l805:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l6963
	
i1l806:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l6963
	
i1l807:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l6963
	
i1l808:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	i1l6963
	
i1l809:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	i1l6963
	
i1l810:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l6963
	
i1l811:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l6963
	
i1l6961:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l799
	xorlw	1^0	; case 1
	skipnz
	goto	i1l801
	xorlw	2^1	; case 2
	skipnz
	goto	i1l802
	xorlw	3^2	; case 3
	skipnz
	goto	i1l803
	xorlw	4^3	; case 4
	skipnz
	goto	i1l804
	xorlw	5^4	; case 5
	skipnz
	goto	i1l805
	xorlw	6^5	; case 6
	skipnz
	goto	i1l806
	xorlw	7^6	; case 7
	skipnz
	goto	i1l807
	xorlw	8^7	; case 8
	skipnz
	goto	i1l808
	xorlw	9^8	; case 9
	skipnz
	goto	i1l809
	xorlw	10^9	; case 10
	skipnz
	goto	i1l810
	xorlw	11^10	; case 11
	skipnz
	goto	i1l811
	goto	i1l6963
	opt asmopt_pop

	line	1012
	
i1l6963:	
	incf	(Charging_Control@i),f
	
i1l6965:	
	movlw	low(0Ch)
	subwf	(Charging_Control@i),w
	skipc
	goto	u1065_21
	goto	u1065_20
u1065_21:
	goto	i1l6933
u1065_20:
	
i1l756:	
	line	1042
	btfsc	(Charging_Control@chargeB1_6),0
	goto	u1066_21
	goto	u1066_20
	
u1066_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2099/8)^0100h,(2099)&7	;volatile
	goto	u1067_24
u1066_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
u1067_24:
	line	1043
	btfsc	(Charging_Control@chargeB7_12),0
	goto	u1068_21
	goto	u1068_20
	
u1068_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u1069_24
u1068_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u1069_24:
	line	1046
	
i1l746:	
	return
	opt stack 0
GLOBAL	__end_of_Charging_Control
	__end_of_Charging_Control:
	signat	_Charging_Control,89
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 1064 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    6[BANK0 ] unsigned int 
;;  s               1   17[BANK0 ] unsigned char 
;;  duty            2   14[BANK0 ] int 
;;  error           2   10[BANK0 ] int 
;;  adjust          2    0[BANK0 ] int 
;;  duty_initial    1   13[BANK0 ] unsigned char 
;;  duty_target     1   12[BANK0 ] unsigned char 
;;  maxV            2    8[BANK0 ] unsigned int 
;;  i               1   16[BANK0 ] unsigned char 
;;  preCount        1    5[BANK0 ] unsigned char 
;;  ccCount         1    4[BANK0 ] unsigned char 
;;  cvCount         1    3[BANK0 ] unsigned char 
;;  hasCharging     1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 100/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2      18       0       0       0
;;Total ram usage:       20 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___awdiv
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=0
	line	1064
global __ptext27
__ptext27:	;psect for function _CCCV_Control
psect	text27
	file	"charge_mgr.c"
	line	1064
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1067
	
i1l6967:	
	bcf	status, 6	;RP1=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	1068
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	1069
	clrf	(CCCV_Control@cvCount)
	line	1070
	clrf	(CCCV_Control@ccCount)
	line	1071
	clrf	(CCCV_Control@preCount)
	line	1074
	clrf	(CCCV_Control@i)
	line	1076
	
i1l6973:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	1080
	
i1l6975:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1070_21
	goto	u1070_20
u1070_21:
	goto	i1l819
u1070_20:
	
i1l6977:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1071_21
	goto	u1071_20
u1071_21:
	goto	i1l819
u1071_20:
	
i1l6979:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1072_21
	goto	u1072_20
u1072_21:
	goto	i1l819
u1072_20:
	
i1l6981:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1073_21
	goto	u1073_20
u1073_21:
	goto	i1l819
u1073_20:
	
i1l6983:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1074_21
	goto	u1074_20
u1074_21:
	goto	i1l817
u1074_20:
	
i1l819:	
	line	1082
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	1084
	
i1l6985:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	1085
	
i1l6987:	
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u1075_25
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u1075_25:
	skipnc
	goto	u1075_21
	goto	u1075_20
u1075_21:
	goto	i1l6991
u1075_20:
	
i1l6989:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	1087
	
i1l6991:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1076_21
	goto	u1076_20
u1076_21:
	goto	i1l6995
u1076_20:
	line	1088
	
i1l6993:	
	incf	(CCCV_Control@cvCount),f
	line	1089
	
i1l6995:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1077_21
	goto	u1077_20
u1077_21:
	goto	i1l6999
u1077_20:
	line	1090
	
i1l6997:	
	incf	(CCCV_Control@ccCount),f
	line	1091
	
i1l6999:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1078_21
	goto	u1078_20
u1078_21:
	goto	i1l7003
u1078_20:
	
i1l7001:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1079_21
	goto	u1079_20
u1079_21:
	goto	i1l817
u1079_20:
	line	1092
	
i1l7003:	
	incf	(CCCV_Control@preCount),f
	line	1093
	
i1l817:	
	line	1074
	incf	(CCCV_Control@i),f
	
i1l7005:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u1080_21
	goto	u1080_20
u1080_21:
	goto	i1l6973
u1080_20:
	line	1097
	
i1l7007:	
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u1081_21
	goto	u1081_20
u1081_21:
	goto	i1l7013
u1081_20:
	line	1099
	
i1l7009:	
	clrf	(_g_pwmDuty)	;volatile
	line	1100
	clrf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l827
	line	1108
	
i1l7013:	
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u1082_21
	goto	u1082_20
u1082_21:
	goto	i1l7043
u1082_20:
	line	1112
	
i1l7015:	
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u1083_21
	goto	u1083_20
u1083_21:
	goto	i1l7019
u1083_20:
	line	1115
	
i1l7017:	
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	1116
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	1117
	goto	i1l7027
	line	1118
	
i1l7019:	
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u1084_21
	goto	u1084_20
u1084_21:
	goto	i1l7023
u1084_20:
	line	1121
	
i1l7021:	
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	1122
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	1123
	goto	i1l7027
	line	1128
	
i1l7023:	
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l827
	line	1132
	
i1l7027:	
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u1085_21
	goto	u1085_20
u1085_21:
	goto	i1l7035
u1085_20:
	line	1135
	
i1l7029:	
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	1136
	
i1l7031:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u1086_21
	goto	u1086_20
u1086_21:
	goto	i1l827
u1086_20:
	line	1137
	
i1l7033:	
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l827
	line	1139
	
i1l7035:	
	line	1142
	
i1l7037:	
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	1143
	goto	i1l827
	line	1158
	
i1l7043:	
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	1161
	movf	(CCCV_Control@error),w
	addwf	(_g_cvIntegral),f
	skipnc
	incf	(_g_cvIntegral+1),f
	movf	(CCCV_Control@error+1),w
	addwf	(_g_cvIntegral+1),f
	line	1162
	
i1l7045:	
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u1087_25
	movlw	0C9h
	subwf	(_g_cvIntegral),w
u1087_25:

	skipc
	goto	u1087_21
	goto	u1087_20
u1087_21:
	goto	i1l7049
u1087_20:
	line	1163
	
i1l7047:	
	movlw	0C8h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l7053
	line	1164
	
i1l7049:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u1088_25
	movlw	038h
	subwf	(_g_cvIntegral),w
u1088_25:

	skipnc
	goto	u1088_21
	goto	u1088_20
u1088_21:
	goto	i1l7053
u1088_20:
	line	1165
	
i1l7051:	
	movlw	038h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	movlw	0FFh
	movwf	((_g_cvIntegral))+1
	line	1168
	
i1l7053:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	movf	(_g_cvIntegral),w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1),w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	1169
	
i1l7055:	
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
i1l7057:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	1172
	
i1l7059:	
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u1089_25
	movlw	021h
	subwf	(CCCV_Control@duty),w
u1089_25:

	skipc
	goto	u1089_21
	goto	u1089_20
u1089_21:
	goto	i1l7063
u1089_20:
	
i1l7061:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1173
	
i1l7063:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u1090_21
	goto	u1090_20
u1090_21:
	goto	i1l7067
u1090_20:
	
i1l7065:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1175
	
i1l7067:	
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	1177
	
i1l827:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	i1___bmul

;; *************** function i1___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[COMMON] unsigned char 
;;  __bmul          1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Charging_Control
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext28
__ptext28:	;psect for function i1___bmul
psect	text28
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_ofi1___bmul
	__size_ofi1___bmul	equ	__end_ofi1___bmul-i1___bmul
	
i1___bmul:	
;incstack = 0
	opt	stack 2
; Regs used in i1___bmul: [wreg+status,2+status,0]
	movwf	(i1___bmul@multiplier)
	line	6
	
i1l3325:	
	clrf	(i1___bmul@product)
	line	43
	
i1l3327:	
	btfss	(i1___bmul@multiplier),(0)&7
	goto	u387_21
	goto	u387_20
u387_21:
	goto	i1l3331
u387_20:
	line	44
	
i1l3329:	
	movf	(i1___bmul@multiplicand),w
	addwf	(i1___bmul@product),f
	line	45
	
i1l3331:	
	clrc
	rlf	(i1___bmul@multiplicand),f
	line	46
	
i1l3333:	
	clrc
	rrf	(i1___bmul@multiplier),f
	line	47
	movf	((i1___bmul@multiplier)),w
	btfss	status,2
	goto	u388_21
	goto	u388_20
u388_21:
	goto	i1l3327
u388_20:
	line	50
	
i1l3335:	
	movf	(i1___bmul@product),w
	line	51
	
i1l877:	
	return
	opt stack 0
GLOBAL	__end_ofi1___bmul
	__end_ofi1___bmul:
	signat	i1___bmul,89
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] int 
;;  dividend        2    2[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] int 
;;  sign            1    5[COMMON] unsigned char 
;;  counter         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext29
__ptext29:	;psect for function ___awdiv
psect	text29
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
i1l5075:	
	clrf	(___awdiv@sign)
	line	15
	
i1l5077:	
	btfss	(___awdiv@divisor+1),7
	goto	u719_21
	goto	u719_20
u719_21:
	goto	i1l5083
u719_20:
	line	16
	
i1l5079:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
i1l5081:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
i1l5083:	
	btfss	(___awdiv@dividend+1),7
	goto	u720_21
	goto	u720_20
u720_21:
	goto	i1l5089
u720_20:
	line	20
	
i1l5085:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
i1l5087:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
i1l5089:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
i1l5091:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u721_21
	goto	u721_20
u721_21:
	goto	i1l5111
u721_20:
	line	25
	
i1l5093:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	i1l5097
	line	27
	
i1l5095:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
i1l5097:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u722_21
	goto	u722_20
u722_21:
	goto	i1l5095
u722_20:
	line	31
	
i1l5099:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
i1l5101:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u723_25
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u723_25:
	skipc
	goto	u723_21
	goto	u723_20
u723_21:
	goto	i1l5107
u723_20:
	line	33
	
i1l5103:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
i1l5105:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
i1l5107:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
i1l5109:	
	decfsz	(___awdiv@counter),f
	goto	u724_21
	goto	u724_20
u724_21:
	goto	i1l5099
u724_20:
	line	39
	
i1l5111:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u725_21
	goto	u725_20
u725_21:
	goto	i1l5115
u725_20:
	line	40
	
i1l5113:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
i1l5115:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
i1l989:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
