/*-------------------------------------------
  L1211 12槽充电器 - 全局配置文件
  MCU: SC8F096AD832 QFN32
  功能: 12通道恒压锂电池脉冲充电管理
  版本: 2026/06/01 <V2.0>

  固件版本字符串(烧录后通过串口输出, 每次修改代码后迭代)
  格式: Vxx[字母], 例如 V48A, V48B, V49
*/
#define FIRMWARE_VERSION  "V0.0.17"

/*
  原理图参考: L1211 TOP V2.3 (20260624)
  需求参考: requirement_20260518.xlsx
  资源分配参考: resource_allocation.txt

  引脚分配:
    B1~B12  MOSFET栅极控制(AO3401 P沟道, Gate=Low导通, Gate=High关闭)
    B1  = RA0/AN0  /PWMA0  (pin31)
    B2  = RA1/AN1  /PWMA1  (pin30)
    B3  = RB3/AN11 /PWMD2  (pin12)
    B4  = RB2/AN10 /PWMD4  (pin13)
    B5  = RA3/AN3  /PWMA3  (pin28)
    B6  = RA2/AN2  /PWMA2  (pin29)
    B7  = RD1/AN23 /PWMD1  (pin22)
    B8  = RD3/AN25 /PWMD3  (pin20)
    B9  = RB0/AN8  /PWMD0  (pin15)
    B10 = RB1/AN9  /PWMD1  (pin14)
    B11 = RD2/AN24 /PWMD2  (pin21)
    B12 = RD0/AN22 /PWMD0  (pin23)
    注: B1~B12为纯数字输出(仅控制MOSFET开关), ADC采样由独立BxAD引脚完成
    B1AD    : RC1/AN17      B1电压采样(独立ADC通道, 不受MOSFET状态影响)
    B2AD    : RC0/AN16      B2电压采样
    B3AD    : RB4/AN12      B3电压采样
    B4AD    : RB5/AN13      B4电压采样
    B5AD    : RA5/AN5       B5电压采样
    B6AD    : RA4/AN4       B6电压采样
    B7AD    : AN28          B7电压采样(高通道, 模拟专用)
    B8AD    : AN29          B8电压采样(高通道, 模拟专用)
    B9AD    : AN27          B9电压采样(高通道, 模拟专用)
    B10AD   : AN26          B10电压采样(高通道, 模拟专用)
    B11AD   : RA7/AN7       B11电压采样
    B12AD   : RA6/AN6       B12电压采样
    NTC     : RC2/AN18      温度检测(CMFA103J3950HANT,10K上拉至VDD)
    LED_IO1 : RC5/AN21      红灯全局驱动(Q11 AO3401 P沟道, 低有效)
    LED_IO2 : RC4/AN20      绿灯全局驱动(Q8 AO3401 P沟道, 低有效)
    PWM     : RB7/AN15       PWM总控输出(pin8)
    CD      : RC3/AN19       V2.3无分时组控电路(CD网标未接D-FET使能, 保持低电平)
    EN      : RB6/AN14       主电源使能(Q3 4435)
    SW UART TX : RC4/AN20    UART发送(软件模拟9600bps, 仅调试用, 与LED_IO2复用, 默认禁用)
-------------------------------------------*/
#ifndef __CONFIG_H__
#define __CONFIG_H__

#include <sc.h>

/* 抑制良性编译器警告(8-bit MCU通用类型转换) */
#pragma warning disable 752   /* conversion to shorter data type */
#pragma warning disable 765   /* degenerate unsigned comparison */
#pragma warning disable 764   /* mismatched comparison */

/* --- 系统时钟配置 --- */
#ifndef _XTAL_FREQ
#define _XTAL_FREQ 16000000     /* 系统时钟: 16MHz */
#endif

/* --- 电源电压检测参数 --- */
/* 电源电压 = ADC值 * 1.2V(内部参考) / 4096 * 1000(转mV) */
#define POWER_RATIO        (4096UL * 1200UL)   /* 4096 * 1.2 * 1000 = VREF反推VCC */

/* VCC 归一化基准: 所有阈值/判定均基于 VCC=5000mV 标定.
   Adc_Norm() 将原始 ADC(参考VDD) 缩放到该基准, 消除电源波动(4600~5180mV)
   导致的电池检测漂移与跨槽读数不一致. */
#define VCC_REF_MV         5000UL

/* --- 电池电压双参数线性标定 ---
   标定点: ADC=1885→1.33V(NiMH), ADC=3307→1.55V(恒压锂) @VCC≈5070mV
   公式: V_BAT_mV = (124 * V_BxAD_mV + 206 * VCC_mV) / 1000
   验证: NiMH 1.33V→1331mV, 恒压锂 1.55V→1552mV
   ⚠TODO: 低压区(<1.0V)外推不可靠, 需补充深度过放恒压锂标定点 */
#define ALPHA_NUM           124UL    /* α * 1000 */
#define BETA_NUM            206UL    /* β * 1000 (注意: 公式改为加法, β为正) */
#define CAL_DEN             1000UL
#define UART_PRINT_EN       0       /* UART调试输出开关: 1=启用, 0=禁用
                                       V2.3中RC4=LED_IO2(绿灯), 与UART TX冲突,
                                       生产固件必须=0; 调试时置1会占用绿灯引脚 *///Justin
#define SW_TX              RC4     /* 软件UART TX引脚(复用CLK, 9600bps) */
#define BIT_TIME           104     /* 9600bps @16MHz */

/* --- 充电槽位数量 --- */
#define BATTERY_SLOTS      12      /* 12路独立充电槽位 */

/*========================================================================
  充电状态枚举
  状态转换流程: IDLE -> DETECT -> ACTIVATE/PRECHARGE/CC_CHARGE -> CV_CHARGE -> FULL
  异常状态: ERROR(短路/镍氢/未知电池/超时/过压)
========================================================================*/
#define CHG_IDLE           0       /* 空闲: 初始状态, 等待插入电池 */
#define CHG_DETECT         1       /* 检测: 等待2s稳定后判断电池类型 */
#define CHG_ACTIVATE       2       /* 激活: 过放电池脉冲激活(电压<0.1V) */
#define CHG_PRECHARGE      3       /* 预充: 小电流预充电(0.1V~0.5V) */
#define CHG_CC_CHARGE      4       /* 恒流充电: 正常充电阶段(0.5V~满电) */
#define CHG_CV_CHARGE      5       /* 恒压充电: 到达满电后保持10min */
#define CHG_FULL           6       /* 充满: 充电完成, 绿灯常亮 */
#define CHG_ERROR          7       /* 错误: 异常状态, 红灯闪烁 */
#define CHG_IMP_CHECK      8       /* 阻抗检测: 短脉冲MOSFET测量内阻 */
#define CHG_IMP_DIODE_TEST 9       /* 体二极管检测: MOSFET关断, 观察电容充电爬升区分线性锂/干电池 */

/*========================================================================
  电池类型枚举
  通过开路电压判断电池类型, 决定是否充电
========================================================================*/
#define BAT_TYPE_UNKNOWN     0       /* 未知类型 */
#define BAT_TYPE_LI_ION      1       /* 恒压锂电池(含charger IC): 正常充电 */
#define BAT_TYPE_NIMH        2       /* 镍氢电池: 不充电, 报错 */
#define BAT_TYPE_DRY         3       /* 干电池: 不充电, 报错 */
#define BAT_TYPE_SHORT       4       /* 短路: 不充电, 报错 */
#define BAT_TYPE_AMBIGUOUS   5       /* 模糊: 电压在镍氢范围, 需阻抗+监视判断 */
#define BAT_TYPE_LINEAR_LI   6       /* 线性锂电池(无charger IC): 正常充电, 
                                       在IMP_CHECK中VCC不塌但电压稳定, 
                                       区别于碳性去极化大跳变 */

/*========================================================================
  LED状态枚举
  红灯亮=充电中, 绿灯亮=充满, 红灯闪=错误
========================================================================*/
#define LED_OFF            0       /* LED关闭 */
#define LED_RED_ON         1       /* 红灯常亮(充电中) */
#define LED_GREEN_ON       2       /* 绿灯常亮(充满) */
#define LED_RED_FLASH      3       /* 红灯闪烁(错误) */

/*========================================================================
  电压阈值(ADC原始值)
  标定: V_BAT = (124×BxAD_mV + 206×VCC_mV)/1000, 反推 ADC = (1000×V_BAT/VCC - 206)×4096/124
  基准 VCC=5070mV (典型值)
  空槽: Bx被100K上拉到VCC, ADC≈4095
  ⚠TODO: 低压阈值(SHORT/ACTIVATE/PRE_MIN/PRE_MAX)仅2点标定外推, 需补采标定点修正
========================================================================*/
#define ADC_V_FULL          3100   /*  1.52V 满电阈值(CV切入), 公式: bat_mV≈1518 */
#define ADC_V_OVER          3850   /*  1.64V 过压保护, 恒压锂charger IC高阻抗特性导致
                                       ADC读数偏高(实测~3766), 3850留足裕量同时
                                       低于OPEN(3990), 确保真实过压仍可检出. */
#define ADC_V_OPEN          3990   /*  空槽判为开路(ADC=4095≈VCC) */
#define ADC_V_NEAR_OPEN     3500   /*  准开路阈值: 碳性/碱性电池开槽后电容虚高,
                                       电压可接近OPEN但内阻大, 需与低内阻锂电区分 */

/* TODO: 低压阈值基于2点标定外推, 准确性有限, 需补充低压标定点后修正 */
#define ADC_V_PRE_MIN       1200   /* ~0.70V 预充下限(估算值) */
#define ADC_V_PRE_MAX       2700   /* ~1.00V 预充上限(估算值, 达到后进入CC) */
#define ADC_V_ACTIVATE       750   /* ~0.30V 激活阈值(估算值, 过放电池) */
#define ADC_V_SHORT          500   /* ~0.00V 短路阈值(估算值) */

/* ── NiMH 电压窗口(基于 1.33V NiMH 标定点: ADC=1885) ── */
#define ADC_V_NIMH_LOW      1015   /* ~1.20V NiMH电压范围下限 */
#define ADC_V_NIMH_MAX      2900   /* NiMH开路电压上限(~1.45V@VCC=5V时ADC≈2775, 留余量)
                                      高于此值的电池不进入IMP_CHECK, 直接作LI_ION处理
                                      碳性/碱性若漏入CC, PEAK_DROP会在数秒内纠正 */
#define ADC_V_NIMH_HIGH     ADC_V_OVER  /* 扩展至过压上限, 覆盖碳性/碱性~1.60V */

/* --- DETECT路由用校准mV阈值(替代原始ADC判断) ---
   ⚠TODO: 2点标定公式在低压区外推不可靠, bat_mv最低约1.0V
   导致ACTIVATE(100mV)/PRECHARGE(900mV)阈值暂时无法触发
   低压电池将直接进入CC_CHARGE, 需补采标定点后修正 */
#define BAT_MV_ACTIVATE      100    /* 0.10V: 激活阈值(脉冲激活过放电池) [暂不可达] */
#define BAT_MV_PRECHARGE     900    /* 0.90V: 低于此值进入预充电 [暂不可达] */
#define BAT_MV_FULL         1520    /* 1.52V: 满电阈值(DETECT中检测到满电直接进CV) */

/* (V58I/V58L)DETECT后锂电路由的"满电"ADC阈值: 由 BAT_MV_FULL(1520mV) 在上述两点线性
   标定公式下离线穷举反解(穷举 slot_v 全域, 与 bat_mv>=1520 的等价失配数=0):
       bat_mv >= 1520   ⟺   slot_v >= 3235
   ⚠ 与 ADC_V_FULL(3100) 不是同一个阈值: 后者是CC阶段"电压达标进CV"的ADC阈值
     (≈1499mV), 本值是DETECT路由"直接进CV"的mV标定等效值(1520mV), 语义与来源不同.
   ⚠ ACTIVATE(100)/PRECHARGE(900) 分支不可达(bat_mv 恒 >=1030), 故未设对应ADC阈值. */
#define ADC_V_ROUTE_FULL    3235    /* = BAT_MV_FULL(1520mV) 的ADC等效阈值 */

/*========================================================================
  充电时间阈值
  说明: 状态机计时采用"显式10ms节拍"(ISR维护g_hwTick, chargeTimer
  按真实经过的10ms数累加), 与主循环轮速/UART打印阻塞完全解耦.
  因此 TICK_PER_SEC=100 精确表示 100tick=1秒(10ms/tick),
  下方常量按注释标注的设计物理时长校准.
  ========================================================================*/
#define TICK_PER_SEC        100         /* 1秒对应的tick数(10ms/tick, 显式硬件节拍) */
#define TIME_ACTIVATE_MAX   (60 * TICK_PER_SEC)            /* 激活超时: 60秒 */
#define TIME_PRECHARGE_MAX  (300 * TICK_PER_SEC)           /* 预充超时: 300秒(5分钟) */
#define TIME_CHARGE_MAX     (10800UL * TICK_PER_SEC)       /* 充电超时: 10800秒(3h), 16bit溢出→由CC_BLOCK机制实现 */
#define TIME_DETECT_WAIT    (240)                          /* 检测等待: 2.4秒 */
#define TIME_DETECT_SETTLE  (800)                          /* 高内阻电池额外稳定等待: 8秒 */
#define DETECT_SETTLE_DROP  50                             /* 稳定判定: ADC下降<50视为已稳定 */
#define TIME_CV_HOLD        (60 * TICK_PER_SEC)            /* CV恒压保持: 60秒(1分钟) *///Justin
#define IDLE_POLL_TICKS     (2400)                          /* 空槽IDLE轮询停留: 24秒,
                                                               避免空槽DETECT红灯周期性常亮 */
#define PRINT_INTERVAL_TICKS (200)  /* UART打印间隔: 200×10ms=2秒(与状态机节拍解耦,
                                        阻塞式打印每2s一次, PWM冻结占比从86%降至~35%) */

#define CC_BLOCK_TICKS      (600 * TICK_PER_SEC)   /* CC超时分块: 10分钟tick数(60000<65535) */
#define CC_MAX_BLOCKS       18                     /* 18块=180分钟=3小时 */

/* CC无进展检测: 漏洞A闭环
   进入CC后窗口期内电压未上升≥CC_NO_PROGRESS_RISE → 停滞于中压高位
   (2000~3100)不升不降 → ERROR, 而非等CC_MAX_BLOCKS(最长3h)超时
   适用对象: 仅LI_ION(LINEAR_LI已有16s超时路径, 不重复检测)
   校准: 6000tick=60秒; 30ADC≈37mV */
#define CC_NO_PROGRESS_TICKS (6000)   /* 无进展检测窗口: 60秒 */
#define CC_NO_PROGRESS_RISE  (30)    /* 窗口内最小电压上升: 30ADC */

/* CV上爬检测: 漏洞B加固
   进入CV后窗口期内电压相对起点持续爬升超阈值 → 过充特征
   (碳性/碱性/镍氢误判锂电进CV), 直接ERROR而非等TIME_CV_HOLD(10分钟)误判FULL.
   正常满电锂电进CV后电压被PI钳位在ADC_V_FULL附近不再爬升, 不会误报.
   校准: 6000tick=60秒; 50ADC≈61mV */
#define CV_NO_PROGRESS_TICKS (6000)   /* CV上爬检测窗口: 60秒 */
#define CV_NO_PROGRESS_RISE  (50)    /* 窗口内相对起点上升超此值判过充: 50ADC */
#define CV_NO_PROGRESS_CNT   3       /* 连续超限帧数消抖(防采样噪声误杀) */

/* CV崩溃循环上限: 漏洞B加固
   碳性/碱性误判进CV后电压崩溃下跌→PEAK_DROP回DET→再误判进CV的死循环.
   g_ccBlocks复用为CV崩溃计数(PEAK_DROP回DET时+1), 累计达此值后
   Route_DetectLi再进CV直接ERROR, 杜绝无限循环占用充电资源. */
#define CV_DROP_LOOP_MAX     2       /* CV崩溃→回DET循环次数上限 */

#define OV_DEBOUNCE_CNT     5                      /* 过压消抖次数: 连续N次过压才报ERROR */
#define DETECT_LOW_DEBOUNCE 5                      /* DETECT低电压消抖: 连续N次读到低ADC才判UNKNOWN */

/* CC/CV电压跌落重判: 充电中电压从峰值跌落超过此阈值 → 回DETECT重新判断
   B1 NiMH接触不良实测: ADC从3949(误判为LI_ION)跌至1899(真实NiMH), 跌落2050 */
#define PEAK_DROP_THRESH    500     /* ADC跌落阈值: >500counts≈610mV 触发重判 */

/*========================================================================
  CC-CV 充电控制参数
========================================================================*/
/* 软件PWM参数 (RB7/VT_PWM1, 基于Timer0 ISR生成)
   PWM周期 = 32 × 125us = 4ms, 频率 = 250Hz, 占空比分辨率: 3.125%/step */
#define PWM_RESOLUTION      32     /* PWM分辨率(32级) */
#define PWM_MAX             32     /* 100%占空比 */

/* LED显示窗(AD脚时分下沉点灯)参数
   PWM周期4ms(32×125µs), 取帧尾计数值28~31(合计4拍=0.5ms)为显示窗,
   此时位于PWM关断相内, 下沉不影响充电电流. 为保证该段恒为关断相,
   主循环把 g_pwmDuty 上限钳到 PWM_DISPLAY_SAFE_MAX(28), 留出≥0.5ms关断相. */
#define PWM_DISPLAY_START   28     /* 显示窗起点(计数值), 窗外=采样窗 */
#define PWM_DISPLAY_SAFE_MAX 28    /* 占空比钳位上限(保证帧尾28~31恒为关断相) */

/* CC恒流阶段: 固定占空比(无电流检测时用电压监控替代闭环) */
#define CC_DUTY_INITIAL     25     /* CC初始占空比(25/32≈78%), 软启动起点 */
#define CC_DUTY_TARGET      25     /* CC目标占空比(25/32≈78%) */
#define CC_DUTY_RAMP_STEP   3      /* 软启动每步增量 */

/* PRECHARGE预充阶段: 低占空比(仅ACTIVATE/PRECHARGE槽位, 无CC槽时生效)
   8/32=25%, 避免78%PWM对高内阻深度过放电池造成充电异常 */
#define PRE_DUTY_TARGET     8      /* 预充目标占空比(8/32=25%) */
#define PRE_DUTY_INITIAL    5      /* 预充初始占空比(5/32≈16%), 软启动起点 */

/* CV恒压阶段: PI闭环控制参数
   error = ADC_V_FULL - 当前电压
   duty += error * CV_KP / CV_DIV
   CV_KI用于慢速积分修正 */
#define CV_KP               4      /* 比例系数 */
#define CV_KI               1      /* 积分系数 */
#define CV_KI_LIMIT         200    /* 积分限幅, 防止积分饱和 */

/* --- 调试配置 --- */
#define NIMH_DETECT_ENABLE  1       /* 1=识别镍氢/干电池并拒充, 0=所有电池按锂电池处理 */

/*========================================================================
  多阶段电池识别参数(NIMH_DETECT_ENABLE=1时生效)
  流程: 电压分区 → 阻抗脉冲(区分干电池/NiMH/Li-ion)
  ========================================================================*/
/* 脉冲方向检测: 短暂导通MOSFET, 判断电特性
   NiMH: 极低内阻→B1AD被拉至近VCC→ADC飙至≥3990(且脉冲前<3990)
   Li-ion: 充电管理芯片切模式→电压小幅上升, VCC跌落>200mV
   干电池: 高内阻→B1AD无飙升, 电压不上升, VCC不塌
   5tick=50ms给恒压锂charger IC足够时间拉低VCC,
   同时避免镍氢/恒压锂因脉冲太短被误判 */
#define IMP_PULSE_TICKS     5       /* 脉冲持续tick数(5×10ms=50ms) */
#define IMP_NOISE_THRESH     50      /* 电压上升判定阈值: 碳性电池噪声~40, 锂电激活>100 */

/* 体二极管检测(IMP_CHECK方法3): MOSFET关断后BxAD电容通过100K上拉充电,
   线性锂(体二极管阻断)→电压持续爬升, 干电池(体二极管导通)→电压稳定
   DIODE_RISE_THRESH=900避免碱性/碳性误判, 240tick=2.4秒给线性锂完成电容充电,
   干电池/镍氢因体二极管钳位不会误触发 */
#define DIODE_TEST_TICKS     240     /* 最长等待2.4秒 */
#define DIODE_RISE_THRESH    900            /* 电压上升>900ADC判为线性锂爬升
                                                镍氢/干电池体二极管导通, 爬升<此值
                                                可避免碱性/碳性/镍氢误判为线性锂.
                                                阈值不宜再降, 过低会放行碳性/碱性. */
#define DIODE_TOP_MARGIN     150     /* 钳位到顶容差: 归一化读数距当前VCC满量程
                                       (VCC_norm=g_vcc_mv*4096/5000)150ADC以内,
                                       视为BxAD电容被100K上拉至VCC. IMP_CHECK用此
                                       判空槽(pre与v均接近各自VCC_norm, 消除低VCC
                                       时空槽误放行); DIODE_TEST超时用v接近VCC_norm
                                       判线性锂(体二极管阻断爬升至顶, 消除中压锂电
                                       爬升量不足900ADC的盲区). */
#define DIODE_PRE_MIN       2100    /* 爬升提前放行/中压钳位放行的脉冲前电压下界
                                       (V57E log 5次测试标定): 实测锂电pre≥2271,
                                       碳性pre≤1936, 2100落在空档. 阻止低压碳性
                                       电容被100K自由浮空(爬升快且无界, B10 T2
                                       pre=1389越过+900被误放行)冒充锂电. */
#define DIODE_MID_MIN       2600    /* 中压锂电放行绝对下界(V57E log标定): 实测锂电
                                       超时slot_v≥2637, 镍氢停留2300~2500不爬升,
                                       2600落在空档. 避免镍氢(B2 T3 pre≈2350持稳
                                       2300~2500)被中压钳位误放行进CC. */
#define DIODE_PRE_DRY_MAX   1936    /* 干电池(碳性)脉冲前电压实测上沿(V57E log标定):
                                       低于此值视为干电池特征, 作为低压锂电预充放行的
                                       pre下界. 深度过放锂电(B12 pre=1977~2152)高于
                                       此值且DIODE_TEST中slot_v爬升超钳位→预充放行,
                                       隔离碳性(pre≤1936)自由爬升冒充锂电. */
#define DIODE_CLIMB_MIN     50      /* 高压/中压放行所需slot_v相对pre的最小爬升(ADC):
                                       锂电体二极管阻断使slot_v持续爬升(实测≥80),
                                       碱性/空槽平直(slot_v≈pre, 实测差≤6), 以此
                                       隔离平直高值非锂电(碱性pre≈3500/空槽轨偏置
                                       ≈3500). */
#define DIODE_MID_FLAT_MAX  3000    /* 中压平直放行的pre上界(实测平直锂电pre≤2849):
                                       pre低于此值且slot_v未跌破pre-150即视为持稳锂电
                                       放行(爬升缓慢的V57E中压锂电); pre≥此值必须真实
                                       爬升, 挡碱性/空槽平直高值冒充锂电. */

/*========================================================================
  温度保护阈值
  NTC型号: CMFA103J3950HANT (10K@25C, B=3950)
  温度>=60C停止充电, 温度<=50C恢复充电(10C回差防抖)
========================================================================*/
#define TEMP_STOP           60      /* 停止充电温度 */
#define TEMP_RESUME         50      /* 恢复充电温度 */

/* VCC 低压保护: 电源过载时 VCC 跌落 → 关闭所有充电防止 ADC 读数异常连锁误判
   B1 NiMH 被误判为 LI_ION 时实测 VCC 从 5061mV 跌至 4032mV (跌落>1000mV) */
#define VCC_UVLO_STOP       4400    /* VCC低于此值(mV): 停止所有充电 */
#define VCC_UVLO_RESUME     4600    /* VCC高于此值(mV): 恢复充电(200mV回差) */

/* NTC ADC配置 (RC2独立引脚, C12=22uF滤波, τ≈110ms, 5τ≈550ms) */
#define NTC_SETTLE_ROUNDS    60
#define TEMP_READ_INTERVAL   200

/*========================================================================
  ADC通道定义
  B1AD~B12AD: 独立ADC采样引脚(纯模拟输入), 与B1~B12 MOSFET控制引脚分离
  注: B1~B12为纯数字输出，无需分时复用切换模拟/数字模式
========================================================================*/
#define ADC_CH_B1AD         17    /* B1AD: RC1/AN17 */
#define ADC_CH_B2AD         16    /* B2AD: RC0/AN16 */
#define ADC_CH_B3AD         12    /* B3AD: RB4/AN12 */
#define ADC_CH_B4AD         13    /* B4AD: RB5/AN13 */
#define ADC_CH_B5AD         5     /* B5AD: RA5/AN5 */
#define ADC_CH_B6AD         4     /* B6AD: RA4/AN4 */
#define ADC_CH_B7AD         28    /* B7AD: AN28(高通道, 模拟专用) */
#define ADC_CH_B8AD         29    /* B8AD: AN29(高通道, 模拟专用) */
#define ADC_CH_B9AD         27    /* B9AD: AN27(高通道, 模拟专用) */
#define ADC_CH_B10AD        26    /* B10AD: AN26(高通道, 模拟专用) */
#define ADC_CH_B11AD        7     /* B11AD: RA7/AN7 */
#define ADC_CH_B12AD        6     /* B12AD: RA6/AN6 */
#define ADC_CH_NTC          18    /* NTC: RC2/AN18, VDD参考 */
#define ADC_CH_VREF         31    /* 内部1.2V参考电压(用于计算VDD) */

#define ADC_OK              0xA5  /* ADC采样完成标志: 移位累加32次后返回 */

/*========================================================================
  GPIO引脚宏定义
========================================================================*/
/* 总控引脚 */
#define PIN_PWM             RB7     /* PWM总控输出(VT_PWM1, pin8=RB7/AN15) */
#define PIN_LED_IO1         RC4     /* LED_IO1: 红灯全局驱动(经Q11 AO3401 P沟道, 低有效)
                                       注: 按实际硬件接线, 红色MOSFET栅接RC4, 绿色接RC5 */
#define PIN_LED_IO2         RC5     /* LED_IO2: 绿灯全局驱动(经Q8 AO3401 P沟道, 低有效) */
#define PIN_EN              RB6     /* 主电源使能(Q3 4435) */

/* B1-B12 独立MOSFET栅极控制引脚
   AO3401 P沟道MOSFET: Gate=Low(0)时导通充电, Gate=High(1)时关闭
   B1=RA0/AN0  B2=RA1/AN1  B3=RB3/AN11  B4=RB2/AN10
   B5=RA3/AN3  B6=RA2/AN2  B7=RD1/AN23  B8=RD3/AN25
   B9=RB0/AN8  B10=RB1/AN9 B11=RD2/AN24 B12=RD0/AN22 */
#define PIN_B1_CTRL         RA0     /* B1: RA0 */
#define PIN_B2_CTRL         RA1     /* B2: RA1 */
#define PIN_B3_CTRL         RB3     /* B3: RB3 */
#define PIN_B4_CTRL         RB2     /* B4: RB2 */
#define PIN_B5_CTRL         RA3     /* B5: RA3 */
#define PIN_B6_CTRL         RA2     /* B6: RA2 */
#define PIN_B7_CTRL         RD1     /* B7: RD1 */
#define PIN_B8_CTRL         RD3     /* B8: RD3 */
#define PIN_B9_CTRL         RB0     /* B9: RB0 */
#define PIN_B10_CTRL        RB1     /* B10: RB1 */
#define PIN_B11_CTRL        RD2     /* B11: RD2 */
#define PIN_B12_CTRL        RD0     /* B12: RD0 */

/*========================================================================
  每槽独立MOSFET控制宏
  AO3401 P沟道: Gate=0时导通充电, Gate=1时关闭
========================================================================*/
/* 打开指定槽位充电(Gate=0, MOSFET导通) */
#define SLOT_CHARGE_ON(idx)    do { \
	switch(idx) { \
	case 0: PIN_B1_CTRL=0; break;  case 1: PIN_B2_CTRL=0; break; \
	case 2: PIN_B3_CTRL=0; break;  case 3: PIN_B4_CTRL=0; break; \
	case 4: PIN_B5_CTRL=0; break;  case 5: PIN_B6_CTRL=0; break; \
	case 6: PIN_B7_CTRL=0; break;  case 7: PIN_B8_CTRL=0; break; \
	case 8: PIN_B9_CTRL=0; break;  case 9: PIN_B10_CTRL=0; break; \
	case 10: PIN_B11_CTRL=0; break; case 11: PIN_B12_CTRL=0; break; \
	} \
} while(0)

/* 关闭指定槽位充电(Gate=1, MOSFET关闭) */
#define SLOT_CHARGE_OFF(idx)   do { \
	switch(idx) { \
	case 0: PIN_B1_CTRL=1; break;  case 1: PIN_B2_CTRL=1; break; \
	case 2: PIN_B3_CTRL=1; break;  case 3: PIN_B4_CTRL=1; break; \
	case 4: PIN_B5_CTRL=1; break;  case 5: PIN_B6_CTRL=1; break; \
	case 6: PIN_B7_CTRL=1; break;  case 7: PIN_B8_CTRL=1; break; \
	case 8: PIN_B9_CTRL=1; break;  case 9: PIN_B10_CTRL=1; break; \
	case 10: PIN_B11_CTRL=1; break; case 11: PIN_B12_CTRL=1; break; \
	} \
} while(0)

/*========================================================================
  数据结构定义
========================================================================*/
/* 核心充电状态结构体(6字节) - 仅包含状态机必需字段 */
typedef struct {
	unsigned char state;            /* 充电状态(CHG_xxx) */
	unsigned char type;             /* 电池类型(BAT_TYPE_xxx) */
	unsigned int  voltage;          /* 当前ADC电压值 */
	unsigned int  chargeTimer;      /* 充电计时器(tick) */
} BatterySlot_t;

/*========================================================================
  全局变量声明(extern)
  定义分散在各模块.c文件中, 避免单Bank内存不足
========================================================================*/
extern unsigned int adresult;               /* ADC采样结果(去极值平均后); 仅主循环读写, 无需volatile */
extern unsigned char test_adc;              /* ADC采样状态标记; 仅主循环读写, 无需volatile */

extern BatterySlot_t g_slot[12];            /* 仅主循环读写(ISR不触碰), 无需volatile */

#define S_STATE(i) g_slot[(unsigned char)(i)].state
#define S_TYPE(i)  g_slot[(unsigned char)(i)].type
#define S_VOLT(i)  g_slot[(unsigned char)(i)].voltage
#define S_TIMER(i) g_slot[(unsigned char)(i)].chargeTimer

/* 系统计时变量 */
extern unsigned int g_temperature;          /* 当前温度(0.1°C), 存储temp_x10 */
extern unsigned char g_tempProtect;         /* 温度保护标志: 1=保护中, 0=正常 */
extern unsigned char g_ccBlocks[12];        /* CC阶段10分钟块计数 */
extern unsigned char g_ovCnt[12];           /* 过压消抖计数器 */

/* g_slotRefV[12]: 槽位参考电压(DETECT初始值+CC/CV峰值), g_capFlag: 电容虚高标记, g_impData: IMP_CHECK共享数据 */
extern unsigned int g_slotRefV[BATTERY_SLOTS];  /* 槽位参考电压(DETECT基准/CC-CV峰值, 打印ref用) */
extern unsigned char g_detectOwner;        /* 检测链令牌: 0xFF=空闲, 其他=持有令牌的槽号.
                                              同一时间仅持令牌槽可执行 DETECT→IMP_CHECK→
                                              DIODE_TEST 全链, 其余IDLE槽等待入链,
                                              避免多槽共轨检测相互串扰 */
extern unsigned char g_detectWaiter;       /* 检测链等待者: 0xFF=无, 其他=被冻结等待令牌的槽号.
                                              有等待者时IDLE空槽不再抢令牌, 使等待槽优先
                                              获令牌, 避免重判槽在连续空槽间长期饥饿 */
extern unsigned int g_impData;              /* IMP_CHECK共享数据: 低12位脉冲前电压+高4位VCC编码 */
extern unsigned char g_diodeTrace[4];  /* DIODE_TEST共享轨迹缓冲(单槽独占, 复用不新增RAM):
                                          4点(ct=7,14,21,28)槽压轨迹, 每点1字节存
                                          (v-pre)/4+128; cnt=1~4 */
extern unsigned char g_diodeTraceCnt;  /* DIODE_TEST轨迹点数(1~4), 主循环打印后清零 */
extern unsigned char g_diodeTraceSlot; /* 轨迹归属槽号(打印时匹配) */
extern unsigned int  g_vcc_mv;                /* 系统电压(mV), 由VREF反推, 每轮采样更新; 仅主循环读写 */
extern volatile unsigned int  g_powerOnTimer;  /* 上电自检计时器 */
extern volatile unsigned char g_powerOnPhase;  /* 上电自检阶段(0/1/2) */

/* NTC读温状态机变量 */
extern volatile unsigned char g_tempPhase;     /* NTC读温状态: 0=等待间隔, 1=建立中 */
extern volatile unsigned int  g_tempSettleCnt; /* NTC建立等待计数器(轮) */
extern volatile unsigned int  g_tempReadRoundCnt; /* 温度读取间隔计数器(轮) */

/* PWM/CC-CV 控制变量 */
extern volatile unsigned char g_pwmDuty;       /* 当前PWM占空比(0~PWM_MAX) */
extern volatile unsigned char g_pwmCounter;    /* PWM计数器(ISR中递增, 0~31循环) */
extern signed int g_cvIntegral;                /* CV PI积分累加器 */

/* LED显示窗/按槽下沉(AD脚时分复用点灯)
   g_sinkMask: led.c 每轮计算"该点亮的槽掩码"(全局配色由 led.c 直接驱动红/绿轨);
   ISR 在显示窗内按掩码把对应槽的AD脚切为数字输出低(灌流点灯), 窗外恢复模拟输入;
   g_adcBusy 由主循环在采样(稳定延时+ADC)期间置位, ISR 见其置位则不进入显示窗,
   保证"采样窗(模拟输入)与显示窗(下沉)"时分互斥; g_dispWin 由ISR置位, 主循环避让. */
extern volatile unsigned int g_sinkMask;   /* 12bit下沉掩码: bit0=B1 ... bit11=B12 */
extern volatile bit  g_dispWin;        /* ISR: 1=显示窗进行中 */
extern volatile bit  g_adcBusy;        /* 主循环: 1=采样进行中, ISR暂不进显示窗 */

/* FULL槽周期熄灯采样(由 led.c 计算, 供主循环避让; 详见 led.c Update_LED_Global)
   FULL槽下沉点亮绿灯会把AD节点从~2937拉到~2732(<2800) → 若同拍采样会被误判"欠压"
   触发FULL→CC补电; 故点亮期不采样, 仅熄灭且回稳后的采样窗口才推进FULL状态机. */
extern volatile bit  g_fullDark;       /* led.c: 1=FULL槽熄灭相位(回稳+采样) */
extern volatile bit  g_fullSample;     /* led.c: 1=FULL槽可采样(节点已回稳且未下沉) */

/* 显式10ms节拍: ISR维护硬件节拍, 状态机计时与打印/主循环轮速解耦 */
extern volatile unsigned int  g_hwTick;        /* 10ms硬件节拍(ISR递增) */
extern unsigned int  g_elapsedTicks;          /* 主循环本轮经过的10ms节拍数; 仅主循环读写 */

/* UART通信变量 */
extern volatile bit g_printFlag;

/* 只读配置表(存放于ROM) */
extern const unsigned char s_adcChannels[BATTERY_SLOTS];   /* 12槽BxAD ADC通道映射表 */

/*========================================================================
  函数声明
========================================================================*/
/* 系统初始化与引脚控制 */
void System_Init(void);                     /* 系统初始化(时钟/IO/ADC/UART/Timer) */

/* ADC驱动 */
void AD_Init(void);                         /* ADC模块初始化 */
unsigned char ADC_Sample(unsigned char adch, unsigned char adldo);  /* ADC单次采样(去极值平均) */

/* 充电管理 */
unsigned int Read_Temperature(void);        /* 读取NTC温度(0.1°C), 返回temp_x10 */
unsigned char Detect_BatteryType(unsigned int voltage); /* 根据电压判断电池类型 */
unsigned int Get_Vcc(void);                 /* 采样VREF反推实时VCC(mV), 写回g_vcc_mv */
unsigned int Adc_Norm(unsigned char ch);    /* 采样ADC通道并归一化到VCC_REF_MV(5000) */
unsigned char Route_DetectLi(unsigned char idx, unsigned int slot_v); /* 锂电DETECT后统一充电路由(原DETECT_LI_ROUTE宏) */
unsigned char Route_LiIon(unsigned char idx);                       /* 恒压锂路由(原imp_li_ion共用尾块) */
unsigned char Route_LinearLi(unsigned char idx, unsigned int pre);  /* 线性锂路由(原imp_linear_li共用尾块) */
void Detect_Classify(unsigned char idx, unsigned char fromHighV);   /* DETECT类型分类路由(原amb_check尾块); fromHighV=1走原amb_shortcut */
void Enter_DiodeTest(unsigned char idx);                            /* 进入DIODE_TEST(原imp_diode_test_entry尾块) */
void Slot_Charge_Ctrl(unsigned char idx);   /* 单槽同步控制: 采样+检测+充电+MOSFET */
void CCCV_Control(void);                    /* CC-CV恒流恒压PWM占空比调节 */

/* LED控制 */
void Update_LED_Global(void);               /* 根据12槽状态更新全局LED显示 */
void PowerOnLedSequence(void);              /* 上电LED自检序列 */

/* UART调试输出 */
#if UART_PRINT_EN
void uart_init(void);                       /* 软件UART初始化(RC4) */
void uart_send_char(unsigned char c);       /* 发送单字符 */
void uart_send_string(const unsigned char *str); /* 发送字符串 */
void uart_send_number(unsigned int num);    /* 发送数字 */
#endif

#endif