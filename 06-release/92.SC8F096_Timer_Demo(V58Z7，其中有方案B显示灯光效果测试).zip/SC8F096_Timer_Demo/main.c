/*-------------------------------------------
  L1211 12槽充电器 - 主程序
  MCU: SC8F096AD832 QFN32 @ 16MHz
  功能: 系统初始化 + Timer0 ISR(软件PWM/上电自检/NTC计时/UART计时) + 主循环轮询
  版本: V58C
  计时架构: 显式10ms硬件节拍(ISR维护g_hwTick), 状态机chargeTimer按真实经过的
  10ms数累加, 与主循环轮速/UART打印阻塞完全解耦; UART打印每2秒一次.
-------------------------------------------*/
#include "config.h"

/*========================================================================
  全局变量定义 (符合config.h extern声明)
========================================================================*/
/* 系统电压与PWM控制 */
unsigned int  g_vcc_mv = 5000;                  /* 系统电压(mV), VREF反推, 每轮采样更新(仅主循环) */
volatile unsigned char g_pwmDuty = 0;           /* PWM占空比(0~PWM_MAX) */
volatile unsigned char g_pwmCounter = 0;        /* PWM计数器(ISR自增) */
signed int g_cvIntegral = 0;                    /* CV PI积分累加器 */

/* (V59C) V59B 实验用的"门控意图掩码 / 逐槽显示渲染"框架已删除。
   删除原因: 该方案由 ISR 按 PWM 窗口驱动门控引脚, 会破坏
   DETECT / IMP_CHECK / IMP_DIODE_TEST 依赖的 MOSFET 脉冲时序
   (实测: 镍氢判型卡死在 DET, 见 config.h 中的说明与现场日志)。
   ⇒ 结论(重要): 逐槽LED显示若要再做, 必须满足两个条件:
       ① 只在"没有任何槽处于测量态(DETECT/IMP/DIODE)"时才接管门控;
       ② 显示帧只遍历"有内容"的槽(否则每个槽只分到1/12时间, 肉眼看不见)。 */

/* === (V60A) 门控意图 + 逐槽LED显示 (按上述两条约束重新实现) === */
volatile unsigned int  g_gateWant = 0;              /* 充电器声明的门控意图(bit0..11) */
/* (V60R)原 g_dispColor[12]/g_dispIdx/g_dispTick/g_railApplied/Render_Disp 已全部废弃:
   显示改为"整机色 + 逐槽掩码灌电流", 这几个变量不再被引用, 删除以释放RAM(共15字节)。 */

volatile unsigned char g_dispEnable = 0;            /* (V58W原样)判型侧每轮写0, 灯侧写1 */

#if LED_MODULE_EN
/* --- 灯模块变量(仅生产版 UART_PRINT_EN=0 编译; 调试版完全不存在 ⇒ 零干扰) --- */
unsigned int           g_ledMaskRed = 0;      /* 需显示红色的槽掩码(bit0=B1) */
unsigned int           g_ledMaskGreen = 0;    /* 需显示绿色的槽掩码(bit0=B1) */
unsigned int           g_ledMaskSink = 0;     /* 允许灌电流的槽(有电池且非充电非测量) */
static unsigned char   g_ledPhase = 0;        /* 红/绿相位: 每PWM周期翻转一次 */
static unsigned int    g_sinkAppliedMask = 0; /* 已写入引脚的灌电流掩码 */
#endif

/* --- (V60G)掩码式显示: 颜色轨定颜色 + 采样脚灌电流定"哪几个槽亮" --- */
/* (V60J)显示窗口: 窗口内才开颜色轨+灌电流(灯亮), 窗口间隔内全关(测量干净) */
#if LED_MODULE_EN
volatile unsigned char g_ledWin = 0;
#endif
volatile unsigned char g_adcBusy = 0;         /* (V60T)1=ADC采样中(期间禁止灌电流) */

static unsigned char   g_pwmOn = 0;                 /* 本tick的PWM窗口: 1=导通 */
static unsigned int    g_gateApplied = 0xFFFFU;     /* 已写入引脚的意图(0xFFFF=未应用) */


/*========================================================================
  函数: Apply_Gate_Want   (V60A)
  功能: 按"意图"驱动12个门控引脚(仅在显示不接管门控时调用)
========================================================================*/
static void Apply_Gate_Want(void)
{
	PIN_B1_CTRL  = (g_gateWant & 0x001U) ? 0 : 1;
	PIN_B2_CTRL  = (g_gateWant & 0x002U) ? 0 : 1;
	PIN_B3_CTRL  = (g_gateWant & 0x004U) ? 0 : 1;
	PIN_B4_CTRL  = (g_gateWant & 0x008U) ? 0 : 1;
	PIN_B5_CTRL  = (g_gateWant & 0x010U) ? 0 : 1;
	PIN_B6_CTRL  = (g_gateWant & 0x020U) ? 0 : 1;
	PIN_B7_CTRL  = (g_gateWant & 0x040U) ? 0 : 1;
	PIN_B8_CTRL  = (g_gateWant & 0x080U) ? 0 : 1;
	PIN_B9_CTRL  = (g_gateWant & 0x100U) ? 0 : 1;
	PIN_B10_CTRL = (g_gateWant & 0x200U) ? 0 : 1;
	PIN_B11_CTRL = (g_gateWant & 0x400U) ? 0 : 1;
	PIN_B12_CTRL = (g_gateWant & 0x800U) ? 0 : 1;
}

/*========================================================================
  函数: Sink_ApplyMask   (V60G)
  功能: 按12位掩码设置"哪几个槽的采样脚灌电流"(bit0=B1)。需要灌电流的槽: 采样脚
        改为数字输出低电平(给该槽LED一条确定的低阻回流); 其余槽: 恢复模拟输入。
  原理(现场实测定位): 每槽双色LED的"第2脚"经顶针压在该槽采样节点Bn上, 灯回路为
        LED_VCCx(颜色轨, 由Q11/Q8供电) → 管芯 → R(5.1k) → Bn → (该槽电池) → GND
        空槽: Bn被外部上拉浮到近VCC ⇒ 无压差 ⇒ 灯灭(正确)
        有电池: Bn被电池钳住 ⇒ 灯亮, 但"钳住力度"差异极大(ADC读数稳定性即其度量):
          B6  镍氢直连  读数1071~1076(极稳) ⇒ 灯很亮
          B1  线性锂    读数2334~2947跳动   ⇒ 灯微亮   (现场现象)
          B12 恒压锂    读数2638~3436跳动   ⇒ 灯几乎不亮(现场现象)
        ⇒ 亮度差异来自"该槽回流阻抗", 与显示时间分配无关(V60B~V60E四版因此无效),
          用MCU采样脚灌电流把它统一。
  安全: ① 只在PWM关断窗口灌电流(该窗口内无充电电流, 不会给电池充电);
        ② PWM导通窗口、以及每次ADC采样前(见adc_drv.c调用)都释放;
        ③ 灌电流 ≈ (5.1-1.9)/5.1k ≈ 0.6mA, 远在引脚能力内;
           上电自检期12脚同时灌电流(含插电池)已多轮实测, 无异常。
  ⚠ 只对8个"确定是独立端口引脚"的采样脚生效:
       B1=RC1  B2=RC0  B3=RB4  B4=RB5  B5=RA5  B6=RA4  B11=RA7  B12=RA6
     B7~B10 不参与(B7AD/B8AD为高通道模拟专用; B9AD/B10AD与RD3/RD2栅极控制脚复用,
     不可拉低), 其亮度仍由该槽回流阻抗决定。
  ⚠ 端口写采用"只改本端口相关位"的读改写, 低/高无关位(栅极、PWM、EN、颜色轨、
     NTC)全部保持原值。
========================================================================*/
void Sink_ApplyMask(unsigned int mask)
{
#if !LED_MODULE_EN
	(void)mask;
	return;         /* 调试版(开串口): 灯模块不工作 ⇒ 绝不碰采样脚, 与UART/判型零冲突 */
#else
	unsigned char pa = 0U, pb = 0U, pc = 0U;

	if(mask == g_sinkAppliedMask)
		return;
	g_sinkAppliedMask = mask;

	if(mask & 0x0001U) pc |= 0x02U;                /* B1  RC1 */
	if(mask & 0x0002U) pc |= 0x01U;                /* B2  RC0 */
	if(mask & 0x0004U) pb |= 0x10U;                /* B3  RB4 */
	if(mask & 0x0008U) pb |= 0x20U;                /* B4  RB5 */
	if(mask & 0x0010U) pa |= 0x20U;                /* B5  RA5 */
	if(mask & 0x0020U) pa |= 0x10U;                /* B6  RA4 */
	if(mask & 0x0400U) pa |= 0x80U;                /* B11 RA7 */
	if(mask & 0x0800U) pa |= 0x40U;                /* B12 RA6 */

	/* 端口A: 仅RA4-7参与(RA0-3为栅极输出, 保持) */
	ANSEL0 = (unsigned char)((ANSEL0 & 0x0FU) | (unsigned char)((unsigned char)(~pa) & 0xF0U));
	TRISA  = (unsigned char)((TRISA  & 0x0FU) | (unsigned char)((unsigned char)(~pa) & 0xF0U));
	PORTA  = (unsigned char)((PORTA  & 0x0FU) | (unsigned char)(pa & 0xF0U));

	/* 端口B: 仅RB4-5参与(RB6=EN, RB7=PWM 保持) */
	ANSEL1 = (unsigned char)((ANSEL1 & 0xCFU) | (unsigned char)((unsigned char)(~pb) & 0x30U));
	TRISB  = (unsigned char)((TRISB  & 0xCFU) | (unsigned char)((unsigned char)(~pb) & 0x30U));
	PORTB  = (unsigned char)((PORTB  & 0xCFU) | (unsigned char)(pb & 0x30U));

	/* 端口C: 仅RC0-1参与(RC2=NTC, RC3=CD, RC4/5=颜色轨 保持) */
	ANSEL2 = (unsigned char)((ANSEL2 & 0xFCU) | (unsigned char)((unsigned char)(~pc) & 0x03U));
	TRISC  = (unsigned char)((TRISC  & 0xF8U) | (unsigned char)((unsigned char)(~pc) & 0x03U));
	PORTC  = (unsigned char)((PORTC  & 0xF8U) | (unsigned char)(pc & 0x03U));
#endif  /* LED_MODULE_EN */
}

/*========================================================================
  函数: Set_Rail   (V60A)
  功能: 设置颜色轨: 0=灭 1=红 2=绿 (低有效: 0=亮)
========================================================================*/
static void Set_Rail(unsigned char c)
{
#if UART_PRINT_EN
	/* ⚠ (V60U)调试版禁止驱动 RC4: 软件UART的TX与绿灯轨栅极是【同一引脚】
	   (config.h已注明"UART TX : RC4/AN20 与 LED_IO2 复用")。
	   若显示去写它, UART字节之间该脚会被拉到"绿轨电平": 接上电池后显示色点亮,
	   绿相位把 RC4 拉低 ⇒ 接收端看到持续低电平 ⇒ 【打印立即乱码】(现场现象)。
	   ⇒ 调试版只驱动红轨(RC5, 与UART无关), 绿色状态统一以"红"呈现, 仅供判型调试。 */
	if(c == 2U)
		c = 1U;                          /* 绿 ⇒ 用红呈现 */
	if(c == 1U)
		PIN_LED_IO1 = 0;                 /* 红亮 */
	else
		PIN_LED_IO1 = 1;                 /* 灭 */
	/* RC4(绿轨栅极)留给UART独占, 此处绝不写 */
#else
	if(c == 1U)      { PIN_LED_IO1 = 0; PIN_LED_IO2 = 1; }   /* 红 */
	else if(c == 2U) { PIN_LED_IO1 = 1; PIN_LED_IO2 = 0; }   /* 绿 */
	else             { PIN_LED_IO1 = 1; PIN_LED_IO2 = 1; }   /* 灭 */
#endif
}



/* 系统计时 */
volatile unsigned char g_powerOnTimer = 0;      /* 上电自检计时器(最大 TICK_PER_SEC=100, 1字节足够) */
volatile unsigned char g_powerOnPhase = 0;      /* 上电自检阶段: V58R=0→1→2(仅绿1s→仅红1s→正常)
                                                   ⚠ 相位总数必须与 led.c/main.c 的门限一致 */

/* 显式10ms节拍: ISR维护硬件节拍, 主循环每轮计算经过的节拍数,
   状态机chargeTimer按真实时间累加(charge_mgr.c), 与打印阻塞/轮速解耦 */
volatile unsigned int  g_hwTick = 0;            /* 10ms硬件节拍(ISR递增) */
volatile unsigned char g_hwTickDiv = 0;         /* 125us中断分频计数(80次=10ms) */
unsigned int  g_elapsedTicks = 1;               /* 主循环本轮经过的10ms节拍数(仅主循环读写) */
unsigned int  g_lastHwTick = 0;                 /* 上一轮记录的g_hwTick快照(仅主循环读写) */

/* NTC温度读取状态机(ISR中计时, 主循环中执行ADC) */
volatile unsigned char g_tempPhase = 0;         /* 0=等待间隔, 1=建立中 */
volatile unsigned int  g_tempSettleCnt = 0;     /* NTC建立等待计数器(轮) */
volatile unsigned int  g_tempReadRoundCnt = 0;  /* 温度读取间隔计数器(轮) */
volatile bit g_doNtcRead = 0;                   /* NTC读取请求标志 */

/* UART打印(仅调试用, 生产固件UART_PRINT_EN=0时整体移除, 释放RAM) */
#if UART_PRINT_EN
volatile bit g_printFlag = 0;
volatile unsigned char g_printTick = 0;   /* (V60U)PRINT_INTERVAL_TICKS=200<256 ⇒ 1字节足够 */
#endif

/* ADC通道映射表(ROM) */
const unsigned char s_adcChannels[BATTERY_SLOTS] = {
	ADC_CH_B1AD,   /* B1  = AN17 (RC1) */
	ADC_CH_B2AD,   /* B2  = AN16 (RC0) */
	ADC_CH_B3AD,   /* B3  = AN12 (RB4) */
	ADC_CH_B4AD,   /* B4  = AN13 (RB5) */
	ADC_CH_B5AD,   /* B5  = AN5  (RA5) */
	ADC_CH_B6AD,   /* B6  = AN4  (RA4) */
	ADC_CH_B7AD,   /* B7  = AN28 (高通道) */
	ADC_CH_B8AD,   /* B8  = AN29 (高通道) */
	ADC_CH_B9AD,   /* B9  = AN27 (高通道) */
	ADC_CH_B10AD,  /* B10 = AN26 (高通道) */
	ADC_CH_B11AD,  /* B11 = AN7  (RA7) */
	ADC_CH_B12AD   /* B12 = AN6  (RA6) */
};

/*========================================================================
  函数: System_Init
  功能: 系统初始化 - 时钟/GPIO/ANSEL/ADC/UART/Timer0
  引脚状态: MOSFET全部关闭(Gate=High), ADC输入高阻, LED灭
  参考: 09-test GPIO已验证配置
========================================================================*/
void System_Init(void)
{
	unsigned char i;

	/* 1. 时钟: 16MHz内部RC */
	asm("nop");
	asm("clrwdt");
	OSCCON = 0x72;

	/* 2. GPIO初始化: MOSFET Gate=High(关闭AO3401 P沟道)
	   TRIS=1→输入(模拟引脚), TRIS=0→输出(数字控制) */
	TRISA = 0xF0;  PORTA = 0x0F;   /* RA4-7模拟输入, RA0-3=High(B1/B2/B5/B6关) */
	TRISB = 0x30;  PORTB = 0x4F;   /* RB4-5输入, RB6(EN)=1, RB7(PWM)=0, RB0-3=High */
	TRISC = 0x07;  PORTC = 0x00;   /* RC0-2模拟输入(B2AD/B1AD/NTC), RC3(CD)=0,
	                                   RC4(LED_IO2绿)=0, RC5(LED_IO1红)=0 */
	TRISD = 0xF0;  PORTD = 0x0F;   /* RD4-7模拟输入, RD0-3=High(B12/B7/B11/B8关) */

	/* 3. 弱上拉/下拉全关 */
	WPUA = 0x00;  WPDA = 0x00;
	WPUB = 0x00;  WPDB = 0x00;
	WPUC = 0x00;
	WPUD = 0x00;

	/* 4. 中断边沿全关 */
	IOCA = 0x00;  IOCB = 0x00;

	/* 5. 比较器全关 */
	CC0CON = 0;
	CC1CON = 0;

	/* 6. ANSEL: 模拟输入引脚配置
	   AN4=RA4, AN5=RA5, AN6=RA6, AN7=RA7 → ANSEL0
	   AN12=RB4, AN13=RB5                → ANSEL1
	   AN16=RC0, AN17=RC1, AN18=RC2(NTC) → ANSEL2
	   AN26=RD2, AN27=RD3, AN28=RD4, AN29=RD5 → ANSEL3 */
	ANSEL0 = 0xF0;   /* RA4-7: B6AD/B5AD/B12AD/B11AD */
	ANSEL1 = 0x30;   /* RB4-5: B3AD/B8AD */
	ANSEL2 = 0x07;   /* RC0-1: B2AD/B1AD, RC2: NTC(AN18) */
	ANSEL3 = 0x3C;   /* RD2-5: B10AD/B9AD/B7AD/B4AD */

	/* 7. ADC模块初始化 (Fosc/32, Tad=2μs) */
	AD_Init();

#if UART_PRINT_EN
	/* 8. 软件UART初始化 (RC4, 9600bps, 与LED_IO2复用) */
	uart_init();
#endif

	/* 9. Timer0配置: 125μs周期
	   Fosc=16MHz, Tcy=0.25μs, 预分频1:2
	   TMR0 reload = 256 - 125μs/(0.25μs×2) = 256 - 250 = 6
	   OPTION_REG: T0LSE_EN=0(正常模式), T0CS=0, PSA=0, PS2:0=000(1:2) */
	OPTION_REG = 0x00;      /* T0LSE_EN=0(正常), T0CS=0, PSA=0, PS2:0=000(1:2) */
	TMR0 = 6;
	T0IF = 0;
	INTCON = 0xE0;          /* 一次写入: GIE=1, PEIE=1, T0IE=1, 其余清零 */

	/* 10. 初始状态: 所有充电关闭, PWM=0, LED灭
	   V2.3 LED低有效(0=亮): IO1=1(红灭), IO2=1(绿灭) */
	g_pwmDuty = 0;
	g_pwmCounter = 0;
	PIN_LED_IO1 = 1;
	PIN_LED_IO2 = 1;
	PIN_EN = 1;             /* 主电源使能(Q3 4435) */
	PIN_PWM = 0;

	/* 11. 初始化槽位数据 */
	for(i = 0; i < 12; i++)
	{
		g_slot[i].state = CHG_IDLE;
		g_slot[i].type = BAT_TYPE_UNKNOWN;
		g_slot[i].voltage = 0;
		g_slot[i].chargeTimer = 0;
		g_ccBlocks[i] = 0;
		g_ovCnt[i] = 0;
	}

	/* 12. 开全局中断(已在INTCON中设置) */
}

/*========================================================================
  Timer0 中断服务程序
  周期: ~125μs (Timer0重载值6, 预分频1:2)
  功能:
    1. 软件PWM生成(RB7, 250Hz, 32级分辨率)
    2. 上电自检序列(前2秒)
    3. NTC温度读取计时(仅计时, ADC由主循环执行)
    4. UART打印触发(每秒一次)
  说明: 槽位采样/检测/充电均在主循环 Slot_Charge_Ctrl 中同步执行, ISR不再扫描槽位.
========================================================================*/
void interrupt Isr_Timer(void)
{
	/* --- Timer0中断处理 --- */
	if(T0IF)
	{
		T0IF = 0;
		TMR0 = 6;                   /* 重载125μs周期 */
		asm("clrwdt");              /* 喂狗 */

		/* === 1. 软件PWM生成(RB7, 250Hz, 4ms周期) + (V60A)门控/显示分时 ===
		   规则(详见config.h):
		     测量态(g_dispEnable==0) → 每tick严格按意图驱动门控 + 整机颜色
		                               (延迟≤125µs, 判型时序与已验证的V59C一致);
		     非测量态(g_dispEnable==1) · PWM导通窗口 → 按意图驱动(充电照常)
		                              · PWM关断窗口 → LED逐槽显示扫描 */
		g_pwmCounter++;
		if(g_pwmCounter >= PWM_RESOLUTION)
		{
			g_pwmCounter = 0;
	#if LED_MODULE_EN
			g_ledPhase ^= 1U;   /* (V60G)每PWM周期翻转一次颜色相位(红/绿交替合成) */
#endif
		}

		/* (V60Q)⚠ 绝不再因显示而暂停充电脉冲: 现场硬性约束"灯光显示不得影响充电"。
		   安全性改由"充电槽只在PWM关断窗口灌电流"保证(见显示段) ⇒ 充电完全不受影响。 */
		if(g_pwmDuty > 0 && g_pwmCounter < g_pwmDuty)
		{
			PIN_PWM = 1;
			g_pwmOn = 1;
		}
		else
		{
			PIN_PWM = 0;
			g_pwmOn = 0;
		}

		if(g_powerOnPhase >= 2U)
		{
			/* --- (V60G)门控: 始终严格按充电意图驱动, 显示不再接管门控 ---
			   (V59B教训: 用显示去改门控时序会破坏 DETECT/IMP 判型。) */
			if(g_gateWant != g_gateApplied)
			{
				Apply_Gate_Want();
				g_gateApplied = g_gateWant;
			}

			/* --- (V60O)常态显示 = 整机色 + 12个采样脚全部灌电流(照自检期的做法) ---
			   依据(现场实测): 自检期"无条件给12个采样脚灌电流"时, 不论B6接什么电池,
			   12颗灯都一样亮 ⇒ 亮度完全可以由MCU独立决定, 不该受电池电压/回流影响。
			   做法: ① 颜色轨按整机状态点亮(红/绿/红闪)
			         ② 12个采样脚全部拉低灌电流 ⇒ 12颗灯亮度完全一致(≈590µA),
			            与电池种类/电压无关(不再逐槽判断, 判断错就弱/灭)。
			   安全: 窗口内强制关闭充电脉冲(PIN_PWM=0) —— 12脚全灌电流时若充电脉冲同时
			         到来会形成大电流; 窗口外不灌电流, 充电与采样照常进行。
			   代价: 无法逐槽区分(两条颜色轨硬件本就做不到逐槽独立显示);
			         单槽排查请用"逐槽点灯自检"模式。 */
#if LED_MODULE_EN
			/* --- (V60S)显示: 颜色轨【常亮】(与判型调校期一致) + 灌电流只在显示窗口内 ---
			   ⚠ 硬性约束: 灯光绝不允许影响已调校好的电池类型判断(300~400轮调校的成果)。
			   判型的调校是在"颜色轨常亮"的条件下完成的 ⇒ 为保证判型看到的电气环境与
			   调校时【完全一致】, 此处颜色轨保持常亮, 不随显示窗口开关。
			   唯一新增的扰动量是"采样脚灌电流", 它被严格限制在显示窗口内, 且窗口内
			   主循环不做任何采样(Slot_Charge_Ctrl/CCCV_Control 跳过) ⇒
			   窗口外的采样条件 = 调校时的条件(颜色轨常亮 + 无灌电流) ⇒ 判型零影响 ✓
			   灌电流分类: ①非充电槽全窗口灌(亮度固定, 与电池无关);
			              ②充电槽只在PWM关断窗口灌(充电通路断开 ⇒ 电气安全, 不动脉冲)。 */
			{
				unsigned char c;
				unsigned int  m;
				unsigned int  sinkNow = 0U;

				if((unsigned int)(g_ledMaskRed | g_ledMaskGreen) == 0U)
				{
					c = 0U;  m = 0U;      /* 无任何显示内容 ⇒ 灭 */
				}
				else if(g_ledPhase != 0U && g_ledMaskGreen != 0U)
				{
					c = 2U;  m = g_ledMaskGreen;
				}
				else if(g_ledPhase == 0U && g_ledMaskRed != 0U)
				{
					c = 1U;  m = g_ledMaskRed;
				}
				else if(g_ledMaskGreen != 0U)
				{
					c = 2U;  m = g_ledMaskGreen;
				}
				else if(g_ledMaskRed != 0U)
				{
					c = 1U;  m = g_ledMaskRed;
				}
				else
				{
					c = 0U;  m = 0U;
				}

				Set_Rail(c);                     /* 常亮: 与判型调校期保持一致 */

				if(g_ledWin != 0U)               /* 灌电流: 只在显示窗口内 */
				{
					sinkNow = (unsigned int)(m & g_ledMaskSink);       /* ①非充电槽 */
					if(g_pwmOn == 0U)                                   /* ②充电槽: 关断窗口 */
						sinkNow |= (unsigned int)(m & (unsigned int)(~g_ledMaskSink));
				}
				/* ⚠ (V60T)ADC采样期间一律不灌电流 ⇒ 任何读数都取在"无灌电流"条件下,
				   与判型调校期的条件完全一致(采样结束后下个tick自动恢复)。 */
				Sink_ApplyMask((g_adcBusy == 0U) ? sinkNow : 0U);
			}
#endif  /* LED_MODULE_EN: 调试版(开串口)时整个显示段不编译 ⇒ 与UART零冲突 */
		}

		/* === 2. 显式10ms节拍(状态机计时基准, 与打印解耦) ===
		   125us×80=10ms → g_hwTick++; chargeTimer按此节拍累加,
		   状态机计时不受UART打印阻塞/主循环轮速影响.
		   打印触发与上电自检计时同样挂在10ms节拍上(打印每2秒, 自检每阶段1秒). */
		if(++g_hwTickDiv >= 80U)
		{
			g_hwTickDiv = 0;
			g_hwTick++;

#if LED_MODULE_EN
			/* (V60U)显示窗口: 由10ms节拍最低位直接推导 ⇒ 10ms窗口/10ms间隔 = 50Hz,
			   无频闪, 且不占额外RAM(原计数器已删除)。
			   窗口内才给采样脚灌电流点亮LED; 间隔内无灌电流 ⇒ 采样条件与调校期一致。 */
			g_ledWin = (unsigned char)((g_hwTick & 0x0001U) != 0U);
#endif

			if(g_powerOnPhase < 2U)     /* (V58Q)自检2段: 相位0/1 */
				g_powerOnTimer++;
#if UART_PRINT_EN
			if(++g_printTick >= PRINT_INTERVAL_TICKS)
			{
				g_printTick = 0;
				g_printFlag = 1;
			}
#endif
		}

		/* === 3. 上电自检序列 ===
		   (V58Q)相位0 = 仅红3s → 相位1 = 仅绿3s → 正常显示(各3s便于目视)
		   注意: LED为单槽两脚双色灯, 灯回路经该槽电池与MOSFET(见led.c/原理图),
		         所以自检图案必须在"插有电池且该槽导通"的槽上才能看到. */
		if(g_powerOnPhase < 2)
		{
			PowerOnLedSequence();   /* 仅延时稳定电路, 无其他功能 */
			return;                 /* 自检期间不进行槽位/温度/打印计时 */
		}

		/* === 4. NTC温度读取状态机(仅计时) === */
		if(g_tempPhase == 0)
		{
			g_tempReadRoundCnt++;
			if(g_tempReadRoundCnt >= TEMP_READ_INTERVAL)
			{
				g_tempReadRoundCnt = 0;
				g_tempPhase = 1;
				g_tempSettleCnt = 0;
			}
		}
		else
		{
			g_tempSettleCnt++;
			if(g_tempSettleCnt >= NTC_SETTLE_ROUNDS)
			{
				g_doNtcRead = 1;
				g_tempSettleCnt = 0;
				g_tempPhase = 0;
			}
		}
	}
}

#if UART_PRINT_EN
/*========================================================================
  函数: Print_NtcTemp
  功能: 打印NTC温度(每秒一次, 独立于系统状态打印)
========================================================================*/
void Print_NtcTemp(void)
{
	uart_send_string("NTC=");
	uart_send_number(g_temperature / 10U);
	uart_send_string(".");
	uart_send_number(g_temperature % 10U);
	uart_send_string("C\r\n");
}

/*========================================================================
  函数: Print_SystemStatus
  功能: 打印12槽系统状态(每秒一次)
  输出: VCC=电压 T=温度 B1~B12 ADC值(归一化)/电池mV/状态
  说明: BxAD打印值为 VCC=5000mV 基准归一化ADC, 与实时VCC一起打印,
        便于同一电池在不同槽位/不同电源下直接对比.
========================================================================*/
/* B2-B12打印开关: 0=仅B1详细, 1=全部12槽 */
#define PRINT_ALL_SLOTS     1
/* B1-B6打印开关: 1=B1~B6逐行打印 */
#define PRINT_B1_B6         0

void Print_SystemStatus(void)
{
	unsigned char i;
	unsigned int vcc_mv;

	uart_send_string("\r\n== L1211 12CH CHARGER ");
	uart_send_string(FIRMWARE_VERSION);
	uart_send_string(" ==\r\n");

	/* VCC测量(内部1.2V参考反推, 真实mV) —— (V60U)内联ADC_Sample, 省去test_adc变量 */
	if(ADC_OK == ADC_Sample(ADC_CH_VREF, 0))
	{
		unsigned long pt = POWER_RATIO / adresult;
		vcc_mv = (unsigned int)pt;
	}
	else
		vcc_mv = 5000;

	g_vcc_mv = vcc_mv;

	uart_send_string("VCC=");
	uart_send_number(vcc_mv);
	uart_send_string("mV T=");
	uart_send_number(g_temperature / 10U);
	uart_send_string(".");
	uart_send_number(g_temperature % 10U);
	uart_send_string("C TOKEN=");
	uart_send_number(g_detectOwner == 0xFF ? 0xFFU : (unsigned int)g_detectOwner);
	uart_send_string("\r\n");

#if PRINT_B1_B6
	for(i = 0; i < 6; i++)
#elif PRINT_ALL_SLOTS
	for(i = 0; i < 12; i++)
#else
	for(i = 0; i < 1; i++)
#endif
	{
		unsigned int v = S_VOLT(i);
		unsigned char s = S_STATE(i);

		uart_send_char('B');
		uart_send_number((unsigned int)i + 1U);
		uart_send_char('=');
		uart_send_number(v);

		/* 电池mV校准(归一化基准 VCC_REF_MV=5000):
		   vx_mv = ADC_norm * 5000 / 4096 → BxAD引脚mV
		   bat_mv = (124 * vx_mv + 206 * 5000) / 1000 */
		{
			unsigned long vx_mv = (unsigned long)v * VCC_REF_MV / 4096UL;
			if(vx_mv + 200U >= VCC_REF_MV)
			{
				uart_send_string(" OPEN");
			}
			else
			{
				unsigned long bat_mv_long = ALPHA_NUM * vx_mv + BETA_NUM * VCC_REF_MV;
				bat_mv_long = (bat_mv_long + CAL_DEN/2UL) / CAL_DEN;
				uart_send_string(" BAT(");
				uart_send_number((unsigned int)bat_mv_long);
				uart_send_string("mV)");
			}
		}

		/* 状态缩写 */
		uart_send_char(' ');
		switch(s)
		{
		case CHG_IDLE:       uart_send_string("[IDLE]"); break;
		case CHG_DETECT:
			uart_send_string("[DET]");
			if(g_slotRefV[i] > 0U)
			{
				uart_send_string(" ref=");
				uart_send_number(g_slotRefV[i]);
			}
			break;
		case CHG_ACTIVATE:   uart_send_string("[ACT]");  break;
		case CHG_PRECHARGE:  uart_send_string("[PRE]");  break;
		case CHG_CC_CHARGE:  uart_send_string("[CC]");   break;
		case CHG_CV_CHARGE:  uart_send_string("[CV]");   break;
		case CHG_FULL:       uart_send_string("[FULL]"); break;
		case CHG_ERROR:
		{
			unsigned char t = S_TYPE(i);
			if(t == BAT_TYPE_NIMH || t == BAT_TYPE_DRY)
				uart_send_string("[Dry/NiMH ERR]");
			else if(t == BAT_TYPE_LI_ION)
				uart_send_string("[Li-ion ERR]");
			else if(t == BAT_TYPE_LINEAR_LI)
				uart_send_string("[Linear Li ERR]");
			else
				uart_send_string("[ERR]");
			if(g_slotRefV[i] > 0U)
			{
				uart_send_string(" ref=");
				uart_send_number(g_slotRefV[i]);
			}
			break;
		}
		case CHG_IMP_CHECK:  uart_send_string("[IMP]");  break;
		case CHG_IMP_DIODE_TEST:
			uart_send_string("[DIO]");
			uart_send_string(" pre=");
			uart_send_number(g_impData & 0x0FFFU);
			break;
		default:             uart_send_string("[???]");  break;
		}

		/* 打印 ct(chargeTimer) 和 ty(电池类型) */
		uart_send_string(" ct=");
		uart_send_number(S_TIMER(i));
		uart_send_string(" ty=");
		uart_send_number(S_TYPE(i));

		/* DIODE_TEST v偏移轨迹打印 */
		if(g_diodeTraceCnt > 0U && g_diodeTraceSlot == i)
		{
			unsigned char tc;
			uart_send_string(" tr=");
			for(tc = 0; tc < g_diodeTraceCnt; tc++)
			{
				signed int d = (signed int)g_diodeTrace[tc] - 128;
				if(d < 0)
				{
					uart_send_char('-');
					d = -d;
				}
				else if(d > 0)
					uart_send_char('+');
				uart_send_number((unsigned int)d * 4U);
				if(tc + 1U < g_diodeTraceCnt)
					uart_send_char(',');
			}
			g_diodeTraceCnt = 0;
			g_diodeTraceSlot = 0xFF;
		}

#if PRINT_B1_B6 || PRINT_ALL_SLOTS
		uart_send_string("\r\n");
#endif
	}
	uart_send_string("\r\n");
}

#endif

/*========================================================================
  主函数
  流程:
    1. System_Init() - 初始化所有模块, 启动Timer0 ISR
    2. 上电自检2秒(ISR中处理)
    3. 主循环:
       - 每轮采样一次 VCC 作为归一化基准
       - 顺序调用 Slot_Charge_Ctrl(i) 处理12槽(采样/检测/充电/MOSFET)
       - CCCV_Control() 更新全局PWM占空比
       - Update_LED_Global() 更新全局LED
       - NTC温度读取(g_doNtcRead标志)
       - UART状态打印(g_printFlag标志)
       - 喂狗
========================================================================*/
/*========================================================================
  函数: Sense_Sink_Only / Sense_Pins_Restore   (V58W→V58Y)
  功能: 上电自检期(相位0/1)把12个槽采样引脚临时改为数字输出并驱动低电平, 自检
        结束后恢复为模拟输入.
  原因: 每槽双色LED(红管芯+绿管芯各一颗2脚LED)的"第2脚"经顶针压在该槽采样节点
        上; 两条颜色公共轨"LED VCC1"/"LED VCC2"由Q11/Q8(P沟道, 源=VCC)供电.
        有电池时LED回流走"电池+ → 电池- → GND"; 空板时该节点到GND的唯一通路
        就是MCU采样引脚本身:
          · 采样脚保持模拟高阻 ⇒ 空板无回流 ⇒ 灯不亮(现场现象: 有电池才看得到)
          · 采样脚拉低(灌电流)   ⇒ 空板也有回流 ⇒ 灯亮
        槽内AO3401是高边开关(源=VCC), 导通只会把节点抬到VCC而熄灭该槽LED, 所以
        自检期必须让它保持关闭(见主循环说明).
  安全: 灌电流 ≈ (5.1-1.9)V / (5.1k + 分压串联电阻) ⇒ 亚mA级, 远在引脚能力内;
        分压网络把采样脚与电池隔离, 不会对电池形成低阻放电. 自检期不采样/不充电.
========================================================================*/
static void Sense_Pins_Restore(void)
{
	TRISA |= 0xF0;   /* RA4-7 回输入 */
	TRISB |= 0x30;   /* RB4-5 回输入 */
	TRISD |= 0xF0;   /* RD2-5 回输入 */
	TRISC |= 0x07;   /* RC0-2 回输入 */
	ANSEL0 = 0xF0;   /* RA4-7 模拟 */
	ANSEL1 = 0x30;   /* RB4-5 模拟 */
	ANSEL2 = 0x07;   /* RC0-1 + RC2(NTC) 模拟 */
	ANSEL3 = 0x3C;   /* RD2-5 模拟 */
}

/*========================================================================
  函数: Sense_Pins_AllSink   (V59B, 恢复V58W的"12脚全拉低")
  功能: 12个槽采样脚全部改为数字输出并拉低(灌电流), 为该槽LED提供回流.
  用途: 上电自检期让"12颗灯同时亮" —— 空板靠采样脚灌电流, 插电池靠电池,
        两种情况下12颗都亮(自检期门控保持关断, 无充电电流, 安全).
========================================================================*/
static void Sense_Pins_AllSink(void)
{
	/* RA4-7 = B6AD/B5AD/B12AD/B11AD */
	ANSEL0 &= 0x0F;  TRISA &= 0x0F;  RA4 = 0; RA5 = 0; RA6 = 0; RA7 = 0;
	/* RB4-5 = B3AD/B8AD */
	ANSEL1 &= 0xCF;  TRISB &= 0xCF;  RB4 = 0; RB5 = 0;
	/* RD2-5 = B10AD/B9AD/B7AD/B4AD */
	ANSEL3 &= 0xC3;  TRISD &= 0xC3;  RD2 = 0; RD3 = 0; RD4 = 0; RD5 = 0;
	/* RC0-1 = B2AD/B1AD (RC2=NTC 保持模拟输入不动) */
	ANSEL2 &= 0xFC;  TRISC &= 0xFC;  RC0 = 0; RC1 = 0;
}

/* (V59C) Sense_Sink_Only() 已删除(未被调用, 占ROM)。
   说明: 它是V58Y逐槽扫描诊断用的"只拉低某一槽采样脚"函数; V59C 的
   自检只使用 Sense_Pins_AllSink()(12脚同时拉低) ⇒ 该函数不再需要。
   若将来做"逐槽显示/逐槽自检", 可参照本文件 git/历史重新加入。 */

void main(void)
{
	unsigned char i;
	static unsigned char s_pinsRestored = 0U;   /* (V60Q)自检后的一次性引脚恢复标志 */

	/* ICSP烧录保护延时 */
	__delay_ms(10);
	asm("clrwdt");

	/* 系统初始化 */
	System_Init();

#if UART_PRINT_EN
	uart_send_string("L1211 Charger V2.1\r\n");
	uart_send_string("Init...\r\n");
#endif

/* 主循环 */
	while(1)
	{
		asm("clrwdt");

		/* --- 显式节拍: 计算本轮到现在的真实经过时间(10ms节拍) ---
		   主循环一轮耗时<10ms时硬件节拍可能未跨越10ms边界,
		   对0值兜底为1(每轮至少推进1tick), 保证状态机时间单调前进,
		   与打印阻塞/主循环轮速解耦. */
		g_elapsedTicks = g_hwTick - g_lastHwTick;
		if(g_elapsedTicks == 0U)
			g_elapsedTicks = 1U;
		g_lastHwTick = g_hwTick;

		/* --- 每轮一次 VCC 采样: 作为归一化基准(VCC为慢变量) --- */
		Get_Vcc();

		/* --- 自检相位0/1 与 正常运行 的分界 ---
		   (V58W)空板可见自检的两个必要条件, 缺一不可:
		     ① 12槽MOSFET必须全关 —— 槽内AO3401是P沟道高边开关(源=VCC), 导通会把
		        槽节点抬到VCC, 与LED公共轨"LED VCC1/2"等电位 ⇒ 该槽LED两端压差≈0
		        而熄灭. 所以自检期不扫描12槽(避免正在检测的槽其MOSFET被打开),
		        更不能像V58T那样把12槽MOSFET全部打开"增亮"(那会让空板全黑);
		     ② 12个槽采样引脚必须改为数字输出并拉低 —— 每槽LED第2脚经顶针压在该槽
		        采样节点上, 有电池时回流走电池, 空板时该节点到GND的唯一通路就是
		        MCU采样引脚本身; 若它保持模拟高阻, 空板就没有回流路径(现场现象:
		        有电池才看得到灯). 自检结束必须恢复模拟输入, 否则无法采样电池电压.
		   LED引脚由ISR的PowerOnLedSequence独占, 此处不驱动. */
		if(g_powerOnPhase >= 2U)
		{
			/* 自检后的引脚恢复(12个采样脚回模拟输入)。
			   (V60W)分两种配置:
			     生产版(灯模块启用): 只做一次 —— 之后采样脚由ISR的 Sink_ApplyMask 独占
			       管理; 若每轮都恢复会与灌电流打架, 且使掩码缓存与实际引脚不一致(灯可能不亮)。
			     调试版(开串口, 灯模块不编译): 保持与原版一致 —— 每轮都恢复,
			       保证采样路径行为与"无灯版本"完全相同(现场: 镍氢在B6曾识别不出来)。 */
#if LED_MODULE_EN
			if(s_pinsRestored == 0U)
			{
				Sense_Pins_Restore();
				s_pinsRestored = 1U;
			}
#else
			Sense_Pins_Restore();
			(void)s_pinsRestored;
#endif

			/* --- (V60J)显示窗口调度 ---
			   为什么必须分时(现场实测定位):
			     灯回路 = 颜色轨(≈5.19V) → 管芯(≈1.9V) → R11(5.1k) → 该槽节点 → 电池
			     1.5V可充锂电池(内含电芯+稳压/单向电路)不会吸收LED这点回流电流
			     ⇒ 节点被LED电流顶到≈3.3V ⇒ ①灯不亮 ②该槽ADC读数被污染(判型出错)。
			     ★关键实验: 同一个槽(B6)只换电池 —— 镍氢亮、两种1.5V锂电都不亮
			       ⇒ 与槽位/接触/软件无关, 只取决于电池能否吸收LED回流。
			   因此: 窗口内(20ms/100ms)才开颜色轨+采样脚灌电流 ⇒ 灯靠灌电流回流而亮;
			         窗口外两条颜色轨全关 ⇒ LED不再给节点注流 ⇒ 判型/充电读数干净 ✓
			   窗口内不做任何采样(跳过Slot_Charge_Ctrl/CCCV_Control), 且ISR禁充电脉冲。 */
			/* (V60T)刷新显示掩码(每轮都算, 与显示窗口无关; 窗口调度已移入ISR的10ms节拍) */
			Led_Display_Update();

			/* (V60T)⚠ 采样不再跳过显示窗口 ⇒ 采样节奏与"无灯版本"100%一致。
			   显示与采样的隔离改由 ISR 完成: 采样期间(g_adcBusy)不灌电流;
			   且正在测量(DETECT/IMP)的槽本就不在灌电流掩码内(见led.c) ⇒
			   判型/稳压的读数条件与调校期完全相同 ✓ */
			for(i = 0; i < BATTERY_SLOTS; i++)
			{
				Slot_Charge_Ctrl(i);
			}

			/* --- 全局PWM占空比调节 --- */
			CCCV_Control();
		}
		else
		{
			/* (V59B)上电自检期(相位0/1): 12个采样脚全部拉低灌电流 ⇒ 12颗灯同时亮
			   (空板靠采样脚灌电流, 插电池靠电池提供回流, 两种情况都亮).
			   颜色由ISR的PowerOnLedSequence按 绿1s→红1s 控制;
			   自检期门控保持关断(System_Init已置High), 无充电电流, 安全. */
			Sense_Pins_AllSink();
		}

		/* --- NTC温度读取: ISR建立完成后触发 --- */
		if(g_doNtcRead)
		{
			g_doNtcRead = 0;
			Read_Temperature();
		}

#if UART_PRINT_EN
		/* --- UART打印: 每秒触发一次 --- */
		if(g_printFlag)
		{
			g_printFlag = 0;
			Print_SystemStatus();
			Print_NtcTemp();
		}
#endif
	}
}

/*========================================================================
  合并编译: 以下模块通过#include方式并入main.c
  SCMCU IDE单文件编译模式下, 所有.c文件需合并为一个翻译单元
========================================================================*/
#include "adc_drv.c"       /* ADC驱动: adresult, test_adc, ADC_Sample, AD_Init */
#include "uart_dbg.c"      /* 软件UART: uart_init, uart_send_char/string/number */
#include "charge_mgr.c"    /* 充电管理: Read_Temperature, Get_Vcc, Adc_Norm, Slot_Charge_Ctrl, CCCV_Control */
#include "led.c"           /* LED控制: Update_LED_Global, PowerOnLedSequence */
