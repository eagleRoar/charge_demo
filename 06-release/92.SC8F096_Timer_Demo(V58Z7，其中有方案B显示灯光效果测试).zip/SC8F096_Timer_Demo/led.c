/*-------------------------------------------
  L1211 12槽充电器 - LED控制模块 (V2.3原理图适配版)
  功能: 全局双色LED状态显示、红灯闪烁、上电自检序列
  硬件: V2.3中12槽LED红/绿脚各自共用全局网络, 由两个P沟道MOSFET总控:
    PIN_LED_IO1(RC5) → Q11(AO3401, S=VCC1) → 红灯全局网络 (低有效: 0=亮)
    PIN_LED_IO2(RC4) → Q8 (AO3401, S=VCC2) → 绿灯全局网络 (低有效: 0=亮)
  显示规则(V59C: 整机级, 优先级从高到低):
    1. 任何槽ERROR              → 红灯闪烁(2Hz), 绿灯灭
    2. 任何槽"有电池且在检测/充电中" → 红灯常亮, 绿灯灭
    3. 12槽全部充满             → 绿灯常亮
    4. 其余(空槽/空闲/未满)      → 全灭
  说明: 颜色只有红/绿两条全局总线 ⇒ 只能整机显示。逐槽显示需ISR接管门控,
        会破坏测量时序(V59B实测), 故暂缓(方案见config.h注释)。
  上电自检: Phase0=绿1s → Phase1=红1s → Phase2=正常显示 (V58U起顺序为绿→红)
  注: s_ledBlinkCnt作红灯闪烁节拍(1字节)

  V58O LED缺陷修复:
    ①闪烁时间基准: 原按"主循环轮数"计数, 而TICK_PER_SEC是10ms节拍数(=100),
      实测单轮仅3~6ms → 实际周期≈0.15~0.3s(3~7Hz快闪), 且随轮速漂移
      (UART打印阻塞的0.65s长轮会改变轮速, 关掉UART后频率又变) → 现改为按
      g_elapsedTicks(真实10ms节拍)累加, 与状态机计时同一基准, 与轮速解耦.
    ②空槽误点亮红灯: 空槽轮询也会进DETECT, 原判据把检测态一律算"充电中" →
      12个空槽时几乎总有一个在DETECT → 红灯常亮, 违反"全部空闲→全灭".
      现仅当该槽有电池(S_VOLT < ADC_V_OPEN)时才计为"忙".
    ③上电自检期间主循环不再驱动LED(main.c加 g_powerOnPhase>=2 门控),
      自检与正常显示不再争抢同一对引脚.
  -------------------------------------------*/
  #include "config.h"

  /* (V60V)⚠ 灯模块整体条件编译:
     调试版(UART_PRINT_EN=1)时, 软件UART的TX(RC4)与绿灯轨栅极是同一引脚, 灯与串口
     必然互相干扰(实测: 接电池即乱码) ⇒ 直接把整个灯模块关掉: 零代码、零变量、零干扰。
     生产版(UART_PRINT_EN=0)时灯模块完整编译, 具备"与电池电压无关"的逐槽点亮能力。 */
  #if LED_MODULE_EN

  /* 红灯闪烁半周期(10ms节拍数): TICK_PER_SEC/2 = 50节拍 = 0.5s,
    亮 LED_BLINK_HALF/2 = 25节拍 = 0.25s, 灭 0.25s ⇒ 周期0.5s = 2Hz(占空比50%).
    (V58X)按需求把"报错红灯闪"定为2Hz. 此前取值 TICK_PER_SEC/4(=25节拍)
    ⇒ 周期仅0.25s = 4Hz, 与注释声称的"2Hz"不符, 本次一并纠正.
    ⚠ 单位必须是"10ms节拍", 不是"主循环轮数"(见上方缺陷①) */
  #define LED_BLINK_HALF      (TICK_PER_SEC / 2)

  static unsigned char s_ledBlinkCnt = 0;   /* 红灯闪烁累积节拍数(仅主循环访问) */

  /* --- (V60M)占用锁存: 消除 1.5V 可充锂电池"休眠/无负载时读数跳到开路电平"造成的
     瞬时误判(现场: 判型完成后 B6 突然变灭 —— 其实是该槽那一刻被读成"空槽")。
     规则: 读到有电池(读数<开路阈值) ⇒ 立即锁存; 连续两次读到开路 ⇒ 才确认空槽。 */
  static unsigned int s_occLatch = 0U;      /* 曾读到有电池(锁存标志, 1位/槽) */
  static unsigned int s_openOnce = 0U;      /* 已连续读到1次开路(1位/槽) */
  static unsigned char s_blinkActive = 0U;  /* (V60U)上一轮是否有"需要红闪"的槽 */

  /*========================================================================
   函数: Led_Display_Update   (V59C, 原 Update_LED_Global)
   功能: 整机LED显示(每轮调用一次): 统计12槽状态后直接驱动红/绿两条总线
   说明: ⚠ V59B 的"逐槽显示"已回退 —— 它需要ISR按PWM窗口接管门控, 会破坏
         DETECT/IMP_CHECK/IMP_DIODE_TEST 的测量时序(实测导致镍氢判型异常)。
         本版恢复整机显示, 门控仍由充电器直接驱动(时序与V58M一致)。
         自检期间(前2秒)本函数不被调用, 引脚由ISR的PowerOnLedSequence独占
  ========================================================================*/
  void Led_Display_Update(void)
  {
  unsigned char i;
  unsigned char anyBat = 0;      /* 是否有槽读到电池(V60U起省去hasErr/hasChg/fullCnt/measuring) */
  unsigned char anyBlink = 0;    /* 本轮是否有槽需要"红闪"(报错/不可充) */

#if !LED_MODULE_EN
  /* (V60V)调试版(UART_PRINT_EN=1): 灯模块整体不工作 —— 软件UART的TX(RC4)与绿灯轨
     栅极是同一引脚, 灯与串口必然互相干扰 ⇒ 直接关灯, 换日志稳定+判型零影响。 */
  (void)i;  (void)anyBat;  (void)anyBlink;
  return;
#endif

  /* 报错闪烁相位: 按真实10ms节拍累加, 与主循环轮速解耦(见V58O缺陷①) */
  if(s_blinkActive != 0U)
  {
  s_ledBlinkCnt = (unsigned char)(s_ledBlinkCnt + g_elapsedTicks);
  if(s_ledBlinkCnt >= LED_BLINK_HALF)
  s_ledBlinkCnt = 0;
  }
  else
  {
  s_ledBlinkCnt = 0;   /* 上一轮无报错 ⇒ 相位归零, 下次进入报错必从"亮"开始 */
  }
  s_blinkActive = 0U;  /* 本轮重新统计(见函数末尾) */

  /* --- (V60G)逐槽显示色 → 红/绿掩码(bit0=B1) ---
     显示方式: 颜色轨(LED_VCC1/2)定颜色 + 该槽采样脚灌电流定"哪个槽亮"(见main.c ISR)。
     为什么用掩码而不是逐槽时隙: V2.3 一条颜色轨ON时, 所有"节点被电池钳住"的槽会同时亮,
     无法逐槽隔离; 而亮度又由各槽"节点→GND回流阻抗"决定 ⇒ 用灌电流把回流统一。
     ⚠ 处于测量态(DETECT/IMP_CHECK/IMP_DIODE_TEST)的槽不参与: 这些测量依赖节点的
       电压/阻抗动态响应, 给节点灌电流会干扰判型(自检期外不碰它们)。 */
  g_ledMaskRed = 0U;
  g_ledMaskGreen = 0U;
  g_ledMaskSink = 0U;     /* (V60N)允许灌电流的槽: 有电池 且 不在充电态 */
  for(i = 0; i < BATTERY_SLOTS; i++)
  {
  unsigned char s = S_STATE(i);
  unsigned int  bitMask = (unsigned int)(1U << i);
  unsigned char hasBat;

  /* (V60M)占用判定(带锁存) */
  if(S_VOLT(i) < ADC_V_OPEN)
  {
  s_occLatch |= bitMask;                      /* 读到有电池 ⇒ 锁存 */
  s_openOnce &= (unsigned int)(~(bitMask));
  }
  else if((s_openOnce & bitMask) != 0U)
  {
  s_occLatch &= (unsigned int)(~(bitMask));   /* 连续两次开路 ⇒ 确认空槽 */
  s_openOnce &= (unsigned int)(~(bitMask));
  }
  else
  {
  s_openOnce |= bitMask;                      /* 首次开路: 先不下结论 */
  }
  hasBat = ((s_occLatch & bitMask) != 0U) ? 1U : 0U;

  if(hasBat != 0U)
  anyBat = 1U;

  /* (V60T)允许灌电流的槽: 有电池, 且既不在充电态、也不在测量态。
     ⚠ 排除充电态: 该槽门控导通, 充电脉冲会与灌电流叠加成大电流;
       充电槽的显示由"颜色轨+电池回路"承担(略暗, 但充电功能零影响)。
     ⚠ 排除测量态(DETECT/IMP_CHECK/IMP_DIODE_TEST): 这些测量的读数最敏感,
       该槽的采样脚在整个检测链期间都不灌电流 ⇒ 判型读数绝对不受显示影响 ✓ */
  if((hasBat != 0U) && (s != CHG_ACTIVATE) && (s != CHG_PRECHARGE) &&
  (s != CHG_CC_CHARGE) && (s != CHG_CV_CHARGE) &&
  (s != CHG_DETECT) && (s != CHG_IMP_CHECK) && (s != CHG_IMP_DIODE_TEST))
  g_ledMaskSink |= bitMask;

  if((s == CHG_ERROR) || (S_TYPE(i) == BAT_TYPE_NIMH) ||
  (S_TYPE(i) == BAT_TYPE_DRY)  || (S_TYPE(i) == BAT_TYPE_SHORT))
  {
  anyBlink = 1U;      /* 本轮有需要红闪的槽(供闪烁相位统计) */
  /* 需求"报错 ⇒ 红灯闪"、"镍氢不充电/报警"、"干电池报警"、"短路报警红灯":
     除 ERROR 状态外, 只要类型已被判为不可充(NiMH/干电池/短路)就立即闪红,
     不必等状态机慢慢转到 ERROR(现场: B6镍氢长期停在检测态, 显示不出来)。 */
  if(s_ledBlinkCnt < (LED_BLINK_HALF / 2))
  g_ledMaskRed |= bitMask;
  }
  else if(s == CHG_ACTIVATE || s == CHG_PRECHARGE ||
  s == CHG_CC_CHARGE || s == CHG_CV_CHARGE)
  {
  g_ledMaskRed |= bitMask;            /* 需求"充电中 ⇒ 红灯亮" */
  }
  else if((s == CHG_FULL) ||
  (hasBat && (S_VOLT(i) >= ADC_V_ROUTE_FULL) && (S_VOLT(i) < ADC_V_OPEN) &&
  (S_TYPE(i) != BAT_TYPE_NIMH) && (S_TYPE(i) != BAT_TYPE_DRY) &&
  (S_TYPE(i) != BAT_TYPE_SHORT)))
  {
  /* 需求"充满 ⇒ 绿灯常亮"。
     ⚠ 不能只认 CHG_FULL 状态: 1.5V可充锂电池常常"插上就是满的"
       (现场实测 B12=3355 码 ≈1.54V > 满电 1.52V), 充电器判为 IDLE(无需充电)
       ⇒ 若只认 CHG_FULL, 该槽永远不会显示绿灯(现场现象: B12不亮)。
     故以"电压达到满电阈值(ADC_V_ROUTE_FULL, 1.52V等效)"作为满电依据;
     同时排除不可充类型(NiMH/干电池/短路), 避免它们被误显示成绿。 */
  g_ledMaskGreen |= bitMask;
  }
  else if(hasBat != 0U)
  {
  /* (V60K)只要"该槽有电池"(未满/非报错/非充电中) ⇒ 红灯常亮。
     ⚠ 为什么不能按需求字面"其余全灭": 现场要求"放任何电池进去都要看得到灯",
       用来确认该槽通路/接触正常; 而且 1.5V 可充锂电池槽的灯必须靠采样脚灌电流
       才能亮(该电池不吸收LED回流) ⇒ 只要给"有电池"的槽点灯, 它就一定会显示。
     ⚠ 与"未判型完成"无关: 检测中(DETECT/IMP)也照常显示, 避免出现"什么都不显示"。 */
  g_ledMaskRed |= bitMask;
  }
  /* 空槽: 两掩码都不置位 ⇒ 灯灭 */
  }

  s_blinkActive = anyBlink;   /* 记下本轮是否需要红闪(供下一轮相位统计) */

  /* (V60U)整机显示色 g_dispGlobal 已删除 —— 显示色完全由上面两个掩码表达:
       报错/不可充 ⇒ 只在"亮相"进入红掩码(⇒红闪); 充电中 ⇒ 红掩码(⇒红灯亮);
       全充满 ⇒ 绿掩码(⇒绿灯常亮); 有电池 ⇒ 红掩码(⇒红灯亮); 空盘 ⇒ 两掩码皆空(⇒灭)。
     ISR 用 (g_ledMaskRed | g_ledMaskGreen) 判定"是否有显示内容" ⇒ 单一来源, 不会不一致。 */

  /* --- (V60A)显示使能: 只有确认"没有任何槽在测量"才允许显示接管门控 ---
     ⚠ 禁止侧由 charge_mgr.c 在进入测量态的瞬间置0(实时), 本侧只负责放宽;
        两侧配合保证: 测量期间引脚严格跟随充电意图, 判型不受显示影响。 */
  /* (V60U)g_dispEnable 已彻底删除(经grep确认只写不读, 属V60A"显示接管门控"遗留)
     ⇒ 省1字节RAM。显示与判型的隔离改由三条硬机制保证:
        ① 灌电流只在显示窗口内(见main.c ISR);
        ② ADC采样期间(g_adcBusy)与"正在测量的槽"一律不灌电流;
        ③ 颜色轨保持常亮, 与判型调校期环境一致。 */
  }

/*========================================================================
  函数: PowerOnLedSequence
  功能: 上电LED自检序列(ISR中g_powerOnPhase<2时每125us调用一次)
  流程(V58U): Phase0 = 仅绿1s → Phase1 = 仅红1s → Phase2 = 正常显示
  可见性(V59A修正模型, 实测定标):
    灯回路: LED_VCCx(Q11/Q8导通, 源=VCC) → 管芯 → R11(5.1k) → 该槽节点Bn
            → 【该槽门控MOSFET】 → GND
    ⇒ 该槽门控MOSFET = "该槽LED回路的总开关":
       · 门控关断(默认) → 该槽回路断开 → 该槽灯灭(不论有无电池)
         [实证: B2插锂电时自检扫描不受影响 ⇒ 关断门控即可把该槽熄灭]
       · 门控导通      → 该槽回路接通 → 该槽灯亮
         (有电池: 电流经电池流过, µA级; 无电池: 需同时把该槽采样脚拉低灌电流)
       · 门控导通且PWM正给电流 → 节点被抬到VCC → 该槽灯灭(充电导通瞬间)
    空板自检(V58W起): 由"各槽采样脚拉低灌电流"提供回流, 故空板也能12颗同亮.
    ⚠ 旧结论作废: 此前写"MOSFET导通会把Bn抬到VCC⇒该槽灯灭, 故自检期必须全关" ——
       该结论是由"V58T: 12栅极全开+空板=全黑"误推成"高边开关", 但空板时两种
       接法都会全黑, 那个实验根本无法区分. 正确关系见上.
    ⚠ 逐槽显示(实现中): 点亮第n槽 = 该槽门控ON(+采样脚拉低); 熄灭 = 门控OFF;
       颜色由两条全局总线决定 ⇒ 必须分时扫描. 给不可充电电池(干电池/碳性/镍氢)
       开门时必须保证充电电流为0(落在脉冲充电的关断窗口内), 否则等于给它充电.
  硬件(V2.3, 见原理图LED区):
    每槽1颗两脚双色LED(反并联红/绿管芯), 红端接全局轨LED_VCC1(经Q11, 栅=LED_IO1),
    绿端接LED_VCC2(经Q8, 栅=LED_IO2); 回路为
    LED_VCCx → R11(5.1k) → 该槽节点Bn → 该槽门控MOSFET → GND (有电池时经电池).
    ⇒ 颜色由全局轨决定, "亮不亮"由该槽门控决定:
       · 门控关断(空槽/ERROR/FULL默认态) → 该槽灯灭
       · 门控导通 → 该槽灯亮(充电且PWM正在给电流的瞬间除外)
  注: 低有效, 0=亮; 相位时长3s(生产版可把 3U 改为 1U)
  ⚠ 相位总数必须与 main.c 三处门限(g_powerOnPhase < 2U / >= 2U)一致,
     否则 Update_LED_Global 会因相位到不了2而永不执行(LED被冻结).
========================================================================*/
void PowerOnLedSequence(void)
{
#if !LED_MODULE_EN
	/* (V60V)调试版(开串口): 自检也不点灯 —— 绿灯轨(RC4)与UART TX同脚, 点灯必乱码 */
	return;
#endif
	/* g_powerOnTimer已由ISR按10ms显式节拍递增, 此处不再自增 */

	if(g_powerOnPhase == 0)
	{
		/* (V58R)Phase 0: 仅绿1秒(LED_VCC2经Q8上电)
		   顺序按现场实测要求: 先绿后红(此前代码是先红后绿, 属顺序不符)
		   ⚠ (V60U)调试版(UART_PRINT_EN=1)禁止驱动绿灯轨: RC4=UART TX同一引脚,
		     开机打印会被拉低 ⇒ 横幅乱码。调试版本相位保持全灭。 */
		PIN_LED_IO1 = 1;    /* 红灯灭 */
#if !UART_PRINT_EN
		PIN_LED_IO2 = 0;    /* 绿灯亮(生产版) */
#endif
		if(g_powerOnTimer >= TICK_PER_SEC)   /* 1秒(规格) */
		{
			g_powerOnTimer = 0;
			g_powerOnPhase = 1;
		}
	}
	else if(g_powerOnPhase == 1)
	{
		/* Phase 1: 仅红1秒(LED_VCC1经Q11上电) */
		PIN_LED_IO1 = 0;    /* 红灯亮 */
#if !UART_PRINT_EN
		PIN_LED_IO2 = 1;    /* 绿灯灭(生产版) */
#endif
		if(g_powerOnTimer >= TICK_PER_SEC)
		{
			g_powerOnTimer = 0;
			g_powerOnPhase = 2;         /* 自检完成, 进入正常显示(空盘→全灭) */
		}
	}
	/* Phase 2: 由Update_LED_Global按槽状态驱动 */
}

  #else

  /* ---- 调试版(开串口): 灯不点, 但"自检计时/相位推进"必须保留! ----
     ⚠ V60U缺陷: 曾把本函数做成完全空实现 ⇒ 自检相位永远停在0/1 ⇒
       主循环的 `if(g_powerOnPhase >= 2U)` 永不成立 ⇒ 槽位扫描/判型/充电全部不执行
       (现场: 12槽全 IDLE、ADC读0、TOKEN=255)。本版修正: 相位推进逻辑与生产版一致,
       仅去掉一切灯引脚驱动。 */
  void Led_Display_Update(void)
  {
  }
  void PowerOnLedSequence(void)
  {
  if(g_powerOnPhase == 0)
  {
  if(g_powerOnTimer >= TICK_PER_SEC)
  {
  g_powerOnTimer = 0;
  g_powerOnPhase = 1;
  }
  }
  else if(g_powerOnPhase == 1)
  {
  if(g_powerOnTimer >= TICK_PER_SEC)
  {
  g_powerOnTimer = 0;
  g_powerOnPhase = 2;      /* 自检完成 ⇒ 进入正常扫描/判型/充电 */
  }
  }
  }

  #endif  /* LED_MODULE_EN */
