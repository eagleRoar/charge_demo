opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_CCCV_Control
	FNCALL	_main,_Get_Vcc
	FNCALL	_main,_Led_Display_Update
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_Read_Temperature
	FNCALL	_main,_Sense_Pins_AllSink
	FNCALL	_main,_Sense_Pins_Restore
	FNCALL	_main,_Slot_Charge_Ctrl
	FNCALL	_main,_System_Init
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Slot_Charge_Ctrl,_Adc_Norm
	FNCALL	_Slot_Charge_Ctrl,_Detect_BatteryType
	FNCALL	_Slot_Charge_Ctrl,_Detect_Classify
	FNCALL	_Slot_Charge_Ctrl,_Enter_DiodeTest
	FNCALL	_Slot_Charge_Ctrl,_Get_Vcc
	FNCALL	_Slot_Charge_Ctrl,_Route_LiIon
	FNCALL	_Slot_Charge_Ctrl,_Route_LinearLi
	FNCALL	_Slot_Charge_Ctrl,___bmul
	FNCALL	_Slot_Charge_Ctrl,___lldiv
	FNCALL	_Slot_Charge_Ctrl,___wmul
	FNCALL	_Route_LinearLi,_Route_DetectLi
	FNCALL	_Route_LiIon,_Route_DetectLi
	FNCALL	_Detect_Classify,_Get_Vcc
	FNCALL	_Detect_Classify,_Route_DetectLi
	FNCALL	_Detect_Classify,___lwdiv
	FNCALL	_Route_DetectLi,___lldiv
	FNCALL	_Route_DetectLi,___lmul
	FNCALL	_Get_Vcc,_ADC_Sample
	FNCALL	_Get_Vcc,___lldiv
	FNCALL	_Adc_Norm,_ADC_Sample
	FNCALL	_Adc_Norm,___lldiv
	FNCALL	_Adc_Norm,___lmul
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,___bmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_Apply_Gate_Want
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_elapsedTicks
	global	_g_gateApplied
	global	_g_temperature
	global	_g_detectWaiter
	global	_g_detectOwner
	global	_g_vcc_mv
psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	174

;initializer for _g_elapsedTicks
	retlw	01h
	retlw	0

	line	52

;initializer for _g_gateApplied
	retlw	0FFh
	retlw	0FFh

	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	21

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

	line	35

;initializer for _g_detectWaiter
	retlw	0FFh
	line	29

;initializer for _g_detectOwner
	retlw	0FFh
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	15

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	190
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_powerOnPhase
	global	_g_printFlag
	global	_g_doNtcRead
	global	_s_work
	global	_g_pwmDuty
	global	_g_slotRefV
	global	_g_detectLowCnt
	global	_g_highVFlag
	global	_g_capFlag
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_lastHwTick
	global	_g_hwTick
	global	_g_gateWant
	global	_g_cvIntegral
	global	_g_impData
	global	_g_vccProtect
	global	_g_tempProtect
	global	_test_adc
	global	_g_printTick
	global	_g_tempPhase
	global	_g_hwTickDiv
	global	_g_powerOnTimer
	global	_g_adcBusy
	global	_g_dispEnable
	global	_g_pwmCounter
	global	_g_diodeTraceSlot
	global	_g_diodeTraceCnt
	global	_adresult
	global	_g_slot
	global	_g_stableCnt
	global	_g_ovCnt
	global	_g_ccBlocks
	global	_g_diodeTrace
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_GIE
_GIE	set	0x5F
	global	_RB5
_RB5	set	0x35
	global	_RB4
_RB4	set	0x34
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA7
_RA7	set	0x437
	global	_RA6
_RA6	set	0x436
	global	_RA5
_RA5	set	0x435
	global	_RA4
_RA4	set	0x434
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RC1
_RC1	set	0x831
	global	_RC0
_RC0	set	0x830
	global	_RD5
_RD5	set	0x83D
	global	_RD4
_RD4	set	0x83C
	global	_RC5
_RC5	set	0x835
	global	_RC4
_RC4	set	0x834
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	0
psect	stringtext
	
STR_37:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_25:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_23:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	45	;'-'
	retlw	105	;'i'
	retlw	111	;'o'
	retlw	110	;'n'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_38:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	67	;'C'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	79	;'O'
	retlw	75	;'K'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_8:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_30:	
	retlw	32	;' '
	retlw	112	;'p'
	retlw	114	;'r'
	retlw	101	;'e'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	32	;' '
	retlw	114	;'r'
	retlw	101	;'e'
	retlw	102	;'f'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_31:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_29:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	73	;'I'
	retlw	79	;'O'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_7:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_34:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	114	;'r'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_32:	
	retlw	32	;' '
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_33:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	54	;'6'
	retlw	48	;'0'
	retlw	87	;'W'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
STR_27	equ	STR_17+0
STR_9	equ	STR_2+0
STR_11	equ	STR_38+7
STR_35	equ	STR_38+7
STR_36	equ	STR_38+7
; #config settings
	file	"SC8F096_Timer_Demo.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_g_powerOnPhase:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_s_work:
       ds      6

_g_pwmDuty:
       ds      1

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_slotRefV:
       ds      24

_g_detectLowCnt:
       ds      12

_g_highVFlag:
       ds      2

_g_capFlag:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_lastHwTick:
       ds      2

_g_hwTick:
       ds      2

_g_gateWant:
       ds      2

_g_cvIntegral:
       ds      2

_g_impData:
       ds      2

_g_vccProtect:
       ds      1

_g_tempProtect:
       ds      1

_test_adc:
       ds      1

_g_printTick:
       ds      1

_g_tempPhase:
       ds      1

_g_hwTickDiv:
       ds      1

_g_powerOnTimer:
       ds      1

_g_adcBusy:
       ds      1

_g_dispEnable:
       ds      1

_g_pwmCounter:
       ds      1

_g_diodeTraceSlot:
       ds      1

_g_diodeTraceCnt:
       ds      1

_adresult:
       ds      2

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	174
_g_elapsedTicks:
       ds      2

psect	dataBANK1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	52
_g_gateApplied:
       ds      2

psect	dataBANK1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	21
_g_temperature:
       ds      2

psect	dataBANK1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	35
_g_detectWaiter:
       ds      1

psect	dataBANK1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	29
_g_detectOwner:
       ds      1

psect	dataBANK1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	15
_g_vcc_mv:
       ds      2

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_stableCnt:
       ds      12

_g_ovCnt:
       ds      12

_g_ccBlocks:
       ds      12

_g_diodeTrace:
       ds      4

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"SC8F096_Timer_Demo.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
	fcall	__pidataBANK1+2		;fetch initializer
	movwf	__pdataBANK1+2&07fh		
	fcall	__pidataBANK1+3		;fetch initializer
	movwf	__pdataBANK1+3&07fh		
	fcall	__pidataBANK1+4		;fetch initializer
	movwf	__pdataBANK1+4&07fh		
	fcall	__pidataBANK1+5		;fetch initializer
	movwf	__pdataBANK1+5&07fh		
	fcall	__pidataBANK1+6		;fetch initializer
	movwf	__pdataBANK1+6&07fh		
	fcall	__pidataBANK1+7		;fetch initializer
	movwf	__pdataBANK1+7&07fh		
	fcall	__pidataBANK1+8		;fetch initializer
	movwf	__pdataBANK1+8&07fh		
	fcall	__pidataBANK1+9		;fetch initializer
	movwf	__pdataBANK1+9&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+028h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+044h)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	clrf	((__pbssBANK0)+0)&07Fh
	clrf	((__pbssBANK0)+1)&07Fh
	clrf	((__pbssBANK0)+2)&07Fh
	clrf	((__pbssBANK0)+3)&07Fh
	clrf	((__pbssBANK0)+4)&07Fh
	clrf	((__pbssBANK0)+5)&07Fh
	clrf	((__pbssBANK0)+6)&07Fh
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
	global	main@i
main@i:	; 1 bytes @ 0x0
	ds	1
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_Led_Display_Update:	; 1 bytes @ 0x0
?_Slot_Charge_Ctrl:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Apply_Gate_Want:	; 1 bytes @ 0x0
??_Apply_Gate_Want:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
??_Isr_Timer:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_Sense_Pins_Restore:	; 1 bytes @ 0x0
?_Sense_Pins_AllSink:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?_Route_LiIon:	; 1 bytes @ 0x0
?_Enter_DiodeTest:	; 1 bytes @ 0x0
?_Get_Vcc:	; 2 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	ds	2
??_AD_Init:	; 1 bytes @ 0x2
??_uart_init:	; 1 bytes @ 0x2
?_ADC_Sample:	; 1 bytes @ 0x2
??_uart_send_char:	; 1 bytes @ 0x2
??_Led_Display_Update:	; 1 bytes @ 0x2
??_Sense_Pins_Restore:	; 1 bytes @ 0x2
??_Sense_Pins_AllSink:	; 1 bytes @ 0x2
?_Detect_BatteryType:	; 1 bytes @ 0x2
??_Enter_DiodeTest:	; 1 bytes @ 0x2
?___bmul:	; 1 bytes @ 0x2
	global	?___wmul
?___wmul:	; 2 bytes @ 0x2
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x2
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x2
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x2
	global	?___lmul
?___lmul:	; 4 bytes @ 0x2
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x2
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x2
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x2
	global	___wmul@multiplier
___wmul@multiplier:	; 2 bytes @ 0x2
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x2
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x2
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x2
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x2
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x3
??___bmul:	; 1 bytes @ 0x3
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x3
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x3
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x4
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x4
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x4
	global	___wmul@multiplicand
___wmul@multiplicand:	; 2 bytes @ 0x4
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x4
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x4
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x4
	ds	1
?_uart_send_string:	; 1 bytes @ 0x5
??_System_Init:	; 1 bytes @ 0x5
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x5
	global	Enter_DiodeTest@idx
Enter_DiodeTest@idx:	; 1 bytes @ 0x5
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x5
	ds	1
??___wmul:	; 1 bytes @ 0x6
??___awdiv:	; 1 bytes @ 0x6
??___lwdiv:	; 1 bytes @ 0x6
??___lwmod:	; 1 bytes @ 0x6
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x6
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x6
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x6
	global	___wmul@product
___wmul@product:	; 2 bytes @ 0x6
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x6
	ds	1
??_uart_send_string:	; 1 bytes @ 0x7
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x7
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x7
	ds	1
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x8
	ds	1
??_uart_send_number:	; 1 bytes @ 0x9
??_Print_NtcTemp:	; 1 bytes @ 0x9
	ds	1
??_Get_Vcc:	; 1 bytes @ 0xA
??_Adc_Norm:	; 1 bytes @ 0xA
??___lmul:	; 1 bytes @ 0xA
??___lldiv:	; 1 bytes @ 0xA
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
?_uart_send_number:	; 1 bytes @ 0x0
??_CCCV_Control:	; 1 bytes @ 0x0
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x0
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x0
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x0
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x1
	ds	1
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x2
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x2
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x2
	ds	1
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x4
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x4
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x4
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x5
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0x6
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0x7
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0x8
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x8
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x8
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x9
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0xA
	global	_Print_NtcTemp$769
_Print_NtcTemp$769:	; 2 bytes @ 0xA
	ds	1
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xC
	global	_Print_NtcTemp$770
_Print_NtcTemp$770:	; 2 bytes @ 0xC
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0xC
	ds	2
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0xE
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0xF
	ds	1
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x10
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0x10
	ds	1
??_Read_Temperature:	; 1 bytes @ 0x11
??_Print_SystemStatus:	; 1 bytes @ 0x11
?_Route_DetectLi:	; 1 bytes @ 0x11
	global	?_Adc_Norm
?_Adc_Norm:	; 2 bytes @ 0x11
	global	Route_DetectLi@slot_v
Route_DetectLi@slot_v:	; 2 bytes @ 0x11
	global	Get_Vcc@pt
Get_Vcc@pt:	; 4 bytes @ 0x11
	ds	1
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x12
	ds	1
??_Route_DetectLi:	; 1 bytes @ 0x13
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x13
	ds	1
	global	Adc_Norm@ch
Adc_Norm@ch:	; 1 bytes @ 0x14
	ds	1
	global	Adc_Norm@raw
Adc_Norm@raw:	; 2 bytes @ 0x15
	global	_Print_SystemStatus$771
_Print_SystemStatus$771:	; 2 bytes @ 0x15
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x15
	ds	2
	global	Route_DetectLi@bat_mv
Route_DetectLi@bat_mv:	; 2 bytes @ 0x17
	global	_Print_SystemStatus$772
_Print_SystemStatus$772:	; 2 bytes @ 0x17
	ds	2
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x19
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x19
	global	Route_DetectLi@vx_mv
Route_DetectLi@vx_mv:	; 4 bytes @ 0x19
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x1B
	ds	2
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x1D
	global	Route_DetectLi@bat_mv_long
Route_DetectLi@bat_mv_long:	; 4 bytes @ 0x1D
	ds	1
	global	_Print_SystemStatus$289
_Print_SystemStatus$289:	; 2 bytes @ 0x1E
	ds	2
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x20
	ds	1
	global	Route_DetectLi@st
Route_DetectLi@st:	; 1 bytes @ 0x21
	ds	1
	global	Route_DetectLi@idx
Route_DetectLi@idx:	; 1 bytes @ 0x22
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0x22
	ds	1
??_Route_LiIon:	; 1 bytes @ 0x23
?_Route_LinearLi:	; 1 bytes @ 0x23
?_Detect_Classify:	; 1 bytes @ 0x23
	global	Detect_Classify@fromHighV
Detect_Classify@fromHighV:	; 1 bytes @ 0x23
	global	Route_LinearLi@pre
Route_LinearLi@pre:	; 2 bytes @ 0x23
	ds	1
??_Detect_Classify:	; 1 bytes @ 0x24
	ds	1
??_Route_LinearLi:	; 1 bytes @ 0x25
	ds	1
	global	Route_LiIon@idx
Route_LiIon@idx:	; 1 bytes @ 0x26
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x26
	ds	1
	global	Detect_Classify@idx
Detect_Classify@idx:	; 1 bytes @ 0x27
	ds	1
	global	Route_LinearLi@idx
Route_LinearLi@idx:	; 1 bytes @ 0x28
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0x28
	ds	1
??_Slot_Charge_Ctrl:	; 1 bytes @ 0x29
	ds	3
	global	Print_SystemStatus@tc
Print_SystemStatus@tc:	; 1 bytes @ 0x2C
	ds	1
	global	Print_SystemStatus@t
Print_SystemStatus@t:	; 1 bytes @ 0x2D
	ds	1
	global	Print_SystemStatus@d
Print_SystemStatus@d:	; 2 bytes @ 0x2E
	global	Slot_Charge_Ctrl@v_init
Slot_Charge_Ctrl@v_init:	; 2 bytes @ 0x2E
	ds	2
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x30
	global	Slot_Charge_Ctrl@vcc_norm_pre
Slot_Charge_Ctrl@vcc_norm_pre:	; 2 bytes @ 0x30
	ds	2
	global	Slot_Charge_Ctrl@vcc_norm_now
Slot_Charge_Ctrl@vcc_norm_now:	; 2 bytes @ 0x32
	ds	2
	global	Slot_Charge_Ctrl@ptTick
Slot_Charge_Ctrl@ptTick:	; 2 bytes @ 0x34
	ds	2
	global	Slot_Charge_Ctrl@vcc_norm
Slot_Charge_Ctrl@vcc_norm:	; 2 bytes @ 0x36
	ds	2
	global	Slot_Charge_Ctrl@pt
Slot_Charge_Ctrl@pt:	; 1 bytes @ 0x38
	ds	1
	global	_Slot_Charge_Ctrl$433
_Slot_Charge_Ctrl$433:	; 2 bytes @ 0x39
	ds	2
	global	Slot_Charge_Ctrl@charge_ticks_prev
Slot_Charge_Ctrl@charge_ticks_prev:	; 2 bytes @ 0x3B
	ds	2
	global	Slot_Charge_Ctrl@newv
Slot_Charge_Ctrl@newv:	; 2 bytes @ 0x3D
	ds	2
	global	Slot_Charge_Ctrl@v_ref
Slot_Charge_Ctrl@v_ref:	; 2 bytes @ 0x3F
	ds	2
	global	Slot_Charge_Ctrl@dly
Slot_Charge_Ctrl@dly:	; 1 bytes @ 0x41
	ds	1
	global	Slot_Charge_Ctrl@diff
Slot_Charge_Ctrl@diff:	; 2 bytes @ 0x42
	ds	2
	global	Slot_Charge_Ctrl@pre
Slot_Charge_Ctrl@pre:	; 2 bytes @ 0x44
	ds	2
	global	Slot_Charge_Ctrl@idx
Slot_Charge_Ctrl@idx:	; 1 bytes @ 0x46
	ds	1
??_main:	; 1 bytes @ 0x47
	ds	2
;!
;!Data Sizes:
;!    Strings     251
;!    Constant    12
;!    Data        10
;!    BSS         188
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     10      12
;!    BANK0            80     73      80
;!    BANK1            80      1      79
;!    BANK3            80      0      40
;!    BANK2            80      0      72

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 25
;!		 -> STR_38(CODE[10]), STR_37(CODE[21]), STR_36(CODE[3]), STR_35(CODE[3]), 
;!		 -> STR_34(CODE[5]), STR_33(CODE[5]), STR_32(CODE[5]), STR_31(CODE[6]), 
;!		 -> STR_30(CODE[6]), STR_29(CODE[6]), STR_28(CODE[6]), STR_27(CODE[6]), 
;!		 -> STR_26(CODE[6]), STR_25(CODE[16]), STR_24(CODE[13]), STR_23(CODE[15]), 
;!		 -> STR_22(CODE[7]), STR_21(CODE[5]), STR_20(CODE[5]), STR_19(CODE[6]), 
;!		 -> STR_18(CODE[6]), STR_17(CODE[6]), STR_16(CODE[6]), STR_15(CODE[7]), 
;!		 -> STR_14(CODE[4]), STR_13(CODE[6]), STR_12(CODE[6]), STR_11(CODE[3]), 
;!		 -> STR_10(CODE[9]), STR_9(CODE[2]), STR_8(CODE[6]), STR_7(CODE[5]), 
;!		 -> STR_6(CODE[6]), STR_5(CODE[5]), STR_4(CODE[25]), STR_3(CODE[4]), 
;!		 -> STR_2(CODE[2]), STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    _System_Init->___bmul
;!    _Route_DetectLi->___lmul
;!    _Adc_Norm->___lmul
;!    _Read_Temperature->___lmul
;!    _Print_SystemStatus->___lmul
;!    ___lldiv->___lmul
;!    _Print_NtcTemp->___lwdiv
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    None.
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Slot_Charge_Ctrl
;!    _Slot_Charge_Ctrl->_Route_LinearLi
;!    _Route_LinearLi->_Route_DetectLi
;!    _Route_LiIon->_Route_DetectLi
;!    _Detect_Classify->_Route_DetectLi
;!    _Route_DetectLi->___lldiv
;!    _Get_Vcc->___lldiv
;!    _Adc_Norm->___lldiv
;!    _Read_Temperature->___lldiv
;!    _Print_SystemStatus->___lldiv
;!    ___lldiv->___lmul
;!    _Print_NtcTemp->_uart_send_number
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    None.
;!
;!Critical Paths under _main in BANK1
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 3     3      0   63424
;!                                             71 BANK0      2     2      0
;!                                              0 BANK1      1     1      0
;!                       _CCCV_Control
;!                            _Get_Vcc
;!                 _Led_Display_Update
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                   _Read_Temperature
;!                 _Sense_Pins_AllSink
;!                 _Sense_Pins_Restore
;!                   _Slot_Charge_Ctrl
;!                        _System_Init
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0     880
;!                                              5 COMMON     1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Slot_Charge_Ctrl                                    30    30      0   31833
;!                                             41 BANK0     30    30      0
;!                           _Adc_Norm
;!                 _Detect_BatteryType
;!                    _Detect_Classify
;!                    _Enter_DiodeTest
;!                            _Get_Vcc
;!                        _Route_LiIon
;!                     _Route_LinearLi
;!                             ___bmul
;!                            ___lldiv
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (2) ___wmul                                               6     2      4    2450
;!                                              2 COMMON     6     2      4
;! ---------------------------------------------------------------------------------
;! (2) _Route_LinearLi                                       6     4      2    3930
;!                                             35 BANK0      6     4      2
;!                     _Route_DetectLi
;! ---------------------------------------------------------------------------------
;! (2) _Route_LiIon                                          4     4      0    3413
;!                                             35 BANK0      4     4      0
;!                     _Route_DetectLi
;! ---------------------------------------------------------------------------------
;! (2) _Enter_DiodeTest                                      4     4      0      62
;!                                              2 COMMON     4     4      0
;! ---------------------------------------------------------------------------------
;! (2) _Detect_Classify                                      5     4      1    7222
;!                                             35 BANK0      5     4      1
;!                            _Get_Vcc
;!                     _Route_DetectLi
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (3) _Route_DetectLi                                      18    16      2    3351
;!                                             17 BANK0     18    16      2
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (2) _Get_Vcc                                              4     4      0    2462
;!                                             17 BANK0      4     4      0
;!                         _ADC_Sample
;!                            ___lldiv
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     251
;!                                              2 COMMON     2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _Adc_Norm                                             6     3      3    3731
;!                                             17 BANK0      6     3      3
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (1) _Sense_Pins_Restore                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Sense_Pins_AllSink                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Read_Temperature                                    12    12      0    4815
;!                                             17 BANK0     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  32    32      0   11938
;!                                             17 BANK0     32    32      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (4) ___lmul                                              12     4      8    1207
;!                                              2 COMMON     8     0      8
;!                                              0 BANK0      4     4      0
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1398
;!                                              4 BANK0     13     5      8
;!                             ___lmul (ARG)
;!                             ___wmul (ARG)
;! ---------------------------------------------------------------------------------
;! (3) _ADC_Sample                                          18    17      1    1030
;!                                              2 COMMON     5     4      1
;!                                              0 BANK0     13    13      0
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    6430
;!                                             10 BANK0      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    2637
;!                                              5 COMMON     2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_number                                    10     8      2    2628
;!                                              0 BANK0     10     8      2
;!                             ___bmul (ARG)
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     102
;!                                              2 COMMON     3     3      0
;! ---------------------------------------------------------------------------------
;! (3) ___lwmod                                              5     1      4     378
;!                                              2 COMMON     5     1      4
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4     777
;!                                              2 COMMON     7     3      4
;! ---------------------------------------------------------------------------------
;! (1) _Led_Display_Update                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _CCCV_Control                                        20    20      0    2330
;!                                              0 BANK0     20    20      0
;!                            ___awdiv
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1     626
;!                                              2 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (2) ___awdiv                                              8     4      4     606
;!                                              2 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 4
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (5) _Isr_Timer                                            2     2      0       0
;!                                              0 COMMON     2     2      0
;!                    _Apply_Gate_Want
;!                 _PowerOnLedSequence
;! ---------------------------------------------------------------------------------
;! (6) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (6) _Apply_Gate_Want                                      0     0      0       0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     ___bmul
;!   _Get_Vcc
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!       ___wmul (ARG)
;!   _Led_Display_Update
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!       ___wmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Read_Temperature
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!       ___wmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!   _Sense_Pins_AllSink
;!   _Sense_Pins_Restore
;!   _Slot_Charge_Ctrl
;!     _Adc_Norm
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!         ___wmul (ARG)
;!       ___lmul
;!     _Detect_BatteryType
;!     _Detect_Classify
;!       _Get_Vcc
;!         _ADC_Sample
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!       _Route_DetectLi
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!         ___lmul
;!       ___lwdiv
;!     _Enter_DiodeTest
;!     _Get_Vcc
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!         ___wmul (ARG)
;!     _Route_LiIon
;!       _Route_DetectLi
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!         ___lmul
;!     _Route_LinearLi
;!       _Route_DetectLi
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!         ___lmul
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!       ___wmul (ARG)
;!     ___wmul
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _Apply_Gate_Want
;!   _PowerOnLedSequence
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50      0      28       8       50.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      0      48      10       90.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50      1      4F       6       98.8%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     49      50       4      100.0%
;!BITBANK0            50      0       0       3        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      A       C       1       85.7%
;!BITCOMMON            E      0       1       0        7.1%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     11B      12        0.0%
;!ABS                  0      0     11B      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 712 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1    0[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       1       0       0
;;      Temps:          0       2       0       0       0
;;      Totals:         0       2       1       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_CCCV_Control
;;		_Get_Vcc
;;		_Led_Display_Update
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_Sense_Pins_AllSink
;;		_Sense_Pins_Restore
;;		_Slot_Charge_Ctrl
;;		_System_Init
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	712
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	712
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	718
	
l6879:	
;main.c: 714: unsigned char i;
;main.c: 715: static unsigned char s_pinsRestored = 0U;
;main.c: 718: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_main+0)+0+1),f
	movlw	241
movwf	((??_main+0)+0),f
	u11357:
decfsz	((??_main+0)+0),f
	goto	u11357
	decfsz	((??_main+0)+0+1),f
	goto	u11357
opt asmopt_pop

	line	719
# 719 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	722
	
l6881:	
;main.c: 722: System_Init();
	fcall	_System_Init
	line	725
	
l6883:	
;main.c: 725: uart_send_string("L1211 Charger V2.1\r\n");
	movlw	low(((STR_37)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_37)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	726
	
l6885:	
;main.c: 726: uart_send_string("Init...\r\n");
	movlw	low(((STR_38)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_38)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	730
;main.c: 730: while(1)
	
l466:	
	line	732
# 732 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	738
	
l6887:	
;main.c: 738: g_elapsedTicks = g_hwTick - g_lastHwTick;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_hwTick+1)^080h,w	;volatile
	movwf	(_g_elapsedTicks+1)^080h
	movf	(_g_hwTick)^080h,w	;volatile
	movwf	(_g_elapsedTicks)^080h
	
l6889:	
	movf	(_g_lastHwTick)^080h,w
	subwf	(_g_elapsedTicks)^080h,f
	movf	(_g_lastHwTick+1)^080h,w
	skipc
	decf	(_g_elapsedTicks+1)^080h,f
	subwf	(_g_elapsedTicks+1)^080h,f
	line	739
	
l6891:	
;main.c: 739: if(g_elapsedTicks == 0U)
	movf	((_g_elapsedTicks)^080h),w
iorwf	((_g_elapsedTicks+1)^080h),w
	btfss	status,2
	goto	u11301
	goto	u11300
u11301:
	goto	l6895
u11300:
	line	740
	
l6893:	
;main.c: 740: g_elapsedTicks = 1U;
	clrf	(_g_elapsedTicks)^080h
	incf	(_g_elapsedTicks)^080h,f
	clrf	(_g_elapsedTicks+1)^080h
	line	741
	
l6895:	
;main.c: 741: g_lastHwTick = g_hwTick;
	movf	(_g_hwTick+1)^080h,w	;volatile
	movwf	(_g_lastHwTick+1)^080h
	movf	(_g_hwTick)^080h,w	;volatile
	movwf	(_g_lastHwTick)^080h
	line	744
	
l6897:	
;main.c: 744: Get_Vcc();
	fcall	_Get_Vcc
	line	757
	
l6899:	
;main.c: 757: if(g_powerOnPhase >= 2U)
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w
	skipc
	goto	u11311
	goto	u11310
u11311:
	goto	l6919
u11310:
	line	772
	
l6901:	
;main.c: 758: {
;main.c: 772: Sense_Pins_Restore();
	fcall	_Sense_Pins_Restore
	line	787
	
l6903:	
;main.c: 787: Led_Display_Update();
	fcall	_Led_Display_Update
	line	793
	
l6905:	
;main.c: 793: for(i = 0; i < 12; i++)
	clrf	(main@i)^080h
	line	795
	
l6911:	
;main.c: 794: {
;main.c: 795: Slot_Charge_Ctrl(i);
	movf	(main@i)^080h,w
	fcall	_Slot_Charge_Ctrl
	line	793
	
l6913:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(main@i)^080h,f
	
l6915:	
	movlw	low(0Ch)
	subwf	(main@i)^080h,w
	skipc
	goto	u11321
	goto	u11320
u11321:
	goto	l6911
u11320:
	line	799
	
l6917:	
;main.c: 796: }
;main.c: 799: CCCV_Control();
	fcall	_CCCV_Control
	line	800
;main.c: 800: }
	goto	l6921
	line	807
	
l6919:	
;main.c: 801: else
;main.c: 802: {
;main.c: 807: Sense_Pins_AllSink();
	fcall	_Sense_Pins_AllSink
	line	811
	
l6921:	
;main.c: 808: }
;main.c: 811: if(g_doNtcRead)
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u11331
	goto	u11330
u11331:
	goto	l6927
u11330:
	line	813
	
l6923:	
;main.c: 812: {
;main.c: 813: g_doNtcRead = 0;
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	814
	
l6925:	
;main.c: 814: Read_Temperature();
	fcall	_Read_Temperature
	line	819
	
l6927:	
;main.c: 815: }
;main.c: 819: if(g_printFlag)
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u11341
	goto	u11340
u11341:
	goto	l466
u11340:
	line	821
	
l6929:	
;main.c: 820: {
;main.c: 821: g_printFlag = 0;
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	822
	
l6931:	
;main.c: 822: Print_SystemStatus();
	fcall	_Print_SystemStatus
	line	823
;main.c: 823: Print_NtcTemp();
	fcall	_Print_NtcTemp
	goto	l466
	global	start
	ljmp	start
	opt stack 0
	line	827
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 211 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         1       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	211
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	211
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 4
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	216
	
l5587:	
# 216 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	217
# 217 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text1
	line	218
	
l5589:	
;main.c: 218: OSCCON = 0x72;
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	222
;main.c: 222: TRISA = 0xF0; PORTA = 0x0F;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	223
;main.c: 223: TRISB = 0x30; PORTB = 0x4F;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	224
;main.c: 224: TRISC = 0x07; PORTC = 0x00;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l5591:	
	clrf	(262)^0100h	;volatile
	line	226
	
l5593:	
;main.c: 226: TRISD = 0xF0; PORTD = 0x0F;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l5595:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	229
	
l5597:	
;main.c: 229: WPUA = 0x00; WPDA = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l5599:	
	clrf	(135)^080h	;volatile
	line	230
	
l5601:	
;main.c: 230: WPUB = 0x00; WPDB = 0x00;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l5603:	
	clrf	(7)	;volatile
	line	231
	
l5605:	
;main.c: 231: WPUC = 0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	232
	
l5607:	
;main.c: 232: WPUD = 0x00;
	clrf	(277)^0100h	;volatile
	line	235
	
l5609:	
;main.c: 235: IOCA = 0x00; IOCB = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l5611:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	238
	
l5613:	
;main.c: 238: CC0CON = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	239
	
l5615:	
;main.c: 239: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	246
	
l5617:	
;main.c: 246: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	247
	
l5619:	
;main.c: 247: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	248
	
l5621:	
;main.c: 248: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	249
	
l5623:	
;main.c: 249: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	252
	
l5625:	
;main.c: 252: AD_Init();
	fcall	_AD_Init
	line	256
	
l5627:	
;main.c: 256: uart_init();
	fcall	_uart_init
	line	263
;main.c: 263: OPTION_REG = 0x00;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	264
	
l5629:	
;main.c: 264: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	265
	
l5631:	
;main.c: 265: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	266
	
l5633:	
;main.c: 266: INTCON = 0xE0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	270
;main.c: 270: g_pwmDuty = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	271
;main.c: 271: g_pwmCounter = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_pwmCounter)^080h	;volatile
	line	272
	
l5635:	
;main.c: 272: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	273
	
l5637:	
;main.c: 273: RC5 = 1;
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	274
	
l5639:	
;main.c: 274: RB6 = 1;
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	275
	
l5641:	
;main.c: 275: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	278
;main.c: 278: for(i = 0; i < 12; i++)
	clrf	(System_Init@i)
	line	280
	
l5647:	
;main.c: 279: {
;main.c: 280: g_slot[i].state = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	281
;main.c: 281: g_slot[i].type = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	282
;main.c: 282: g_slot[i].voltage = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	283
;main.c: 283: g_slot[i].chargeTimer = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	284
	
l5649:	
;main.c: 284: g_ccBlocks[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	285
	
l5651:	
;main.c: 285: g_ovCnt[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	278
	
l5653:	
	incf	(System_Init@i),f
	
l5655:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u8481
	goto	u8480
u8481:
	goto	l5647
u8480:
	line	289
	
l387:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
global __ptext2
__ptext2:	;psect for function _uart_init
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 4
; Regs used in _uart_init: []
	line	23
	
l5327:	
;uart_dbg.c: 23: TRISC &= (unsigned char)~0x10;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
;uart_dbg.c: 24: ANSEL2 &= (unsigned char)~0x10;
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
;uart_dbg.c: 25: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l506:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
global __ptext3
__ptext3:	;psect for function _AD_Init
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 4
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l5321:	
;adc_drv.c: 25: CC0CON = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
;adc_drv.c: 26: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	27
	
l5323:	
;adc_drv.c: 27: ADCON0 = 0X81;
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l5325:	
;adc_drv.c: 28: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	29
	
l483:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Slot_Charge_Ctrl

;; *************** function _Slot_Charge_Ctrl *****************
;; Defined at:
;;		line 427 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   70[BANK0 ] unsigned char 
;;  vcc_norm        2   54[BANK0 ] unsigned int 
;;  pre             2   68[BANK0 ] unsigned int 
;;  diff            2   66[BANK0 ] int 
;;  vcc_norm_now    2   50[BANK0 ] unsigned int 
;;  vcc_norm_pre    2   48[BANK0 ] unsigned int 
;;  ptTick          2   52[BANK0 ] unsigned int 
;;  pt              1   56[BANK0 ] unsigned char 
;;  v_ref           2   63[BANK0 ] unsigned int 
;;  v_init          2   46[BANK0 ] unsigned int 
;;  newv            2   61[BANK0 ] unsigned int 
;;  charge_ticks    2   59[BANK0 ] unsigned int 
;;  dly             1   65[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : A00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      25       0       0       0
;;      Temps:          0       5       0       0       0
;;      Totals:         0      30       0       0       0
;;Total ram usage:       30 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Adc_Norm
;;		_Detect_BatteryType
;;		_Detect_Classify
;;		_Enter_DiodeTest
;;		_Get_Vcc
;;		_Route_LiIon
;;		_Route_LinearLi
;;		___bmul
;;		___lldiv
;;		___wmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	427
global __ptext4
__ptext4:	;psect for function _Slot_Charge_Ctrl
psect	text4
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	427
	global	__size_of_Slot_Charge_Ctrl
	__size_of_Slot_Charge_Ctrl	equ	__end_of_Slot_Charge_Ctrl-_Slot_Charge_Ctrl
	
_Slot_Charge_Ctrl:	
;incstack = 0
	opt	stack 2
; Regs used in _Slot_Charge_Ctrl: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
;Slot_Charge_Ctrl@idx stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@idx)
	line	433
	
l5885:	
;charge_mgr.c: 429: unsigned int charge_ticks_prev;
;charge_mgr.c: 430: unsigned char dly;
;charge_mgr.c: 433: s_work = g_slot[idx];
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(_s_work)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	6
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
u8680:
	
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	((??_Slot_Charge_Ctrl+0)+0+2)
	incf	fsr,w
	movwf	((??_Slot_Charge_Ctrl+0)+0+3)
	movf	(??_Slot_Charge_Ctrl+0)+0,w
	movwf	fsr
	bcf	status, 7	;select IRP bank0
	
	movf	((??_Slot_Charge_Ctrl+0)+0+2),w
	movwf	indf
	incf	fsr,w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	((??_Slot_Charge_Ctrl+0)+0+3),w
	movwf	fsr
	decfsz	((??_Slot_Charge_Ctrl+0)+0+1),f
	goto	u8680
	
	line	438
	
l5887:	
;charge_mgr.c: 438: charge_ticks_prev = s_work.chargeTimer;
	movf	1+(_s_work)+04h,w
	movwf	(Slot_Charge_Ctrl@charge_ticks_prev+1)
	movf	0+(_s_work)+04h,w
	movwf	(Slot_Charge_Ctrl@charge_ticks_prev)
	line	439
	
l5889:	
;charge_mgr.c: 439: s_work.chargeTimer += (unsigned int)g_elapsedTicks;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_elapsedTicks)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	0+(_s_work)+04h,f
	skipnc
	incf	1+(_s_work)+04h,f
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_elapsedTicks+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	1+(_s_work)+04h,f
	line	447
	
l5891:	
;charge_mgr.c: 446: if((s_work.state == 1 || s_work.state == 8 || s_work.state == 9) &&
;charge_mgr.c: 447: g_detectOwner != 0xFF && g_detectOwner != idx)
		decf	((_s_work)),w
	btfsc	status,2
	goto	u8691
	goto	u8690
u8691:
	goto	l5897
u8690:
	
l5893:	
		movlw	8
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u8701
	goto	u8700
u8701:
	goto	l5897
u8700:
	
l5895:	
		movlw	9
	xorwf	((_s_work)),w
	btfss	status,2
	goto	u8711
	goto	u8710
u8711:
	goto	l5911
u8710:
	
l5897:	
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectOwner)^080h),w
	btfsc	status,2
	goto	u8721
	goto	u8720
u8721:
	goto	l5911
u8720:
	
l5899:	
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipnz
	goto	u8731
	goto	u8730
u8731:
	goto	l5911
u8730:
	line	451
	
l5901:	
;charge_mgr.c: 448: {
;charge_mgr.c: 451: if(g_detectWaiter == 0xFF)
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectWaiter)^080h),w
	btfss	status,2
	goto	u8741
	goto	u8740
u8741:
	goto	l5905
u8740:
	line	452
	
l5903:	
;charge_mgr.c: 452: g_detectWaiter = idx;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectWaiter)^080h
	line	453
	
l5905:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8754
u8755:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8754:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8755
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_gateWant)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_gateWant+1)^080h,f	;volatile
	line	454
	
l5907:	
;charge_mgr.c: 454: g_slot[idx] = s_work;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_s_work),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+4,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+5,w
	movwf	indf
	goto	l638
	line	459
	
l5911:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8764
u8765:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8764:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8765
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_gateWant)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_gateWant+1)^080h,f	;volatile
	
l640:	
	line	467
;charge_mgr.c: 466: if(s_work.state == 1 || s_work.state == 8 ||
;charge_mgr.c: 467: s_work.state == 9)
	bcf	status, 5	;RP0=0, select bank0
		decf	((_s_work)),w
	btfsc	status,2
	goto	u8771
	goto	u8770
u8771:
	goto	l5917
u8770:
	
l5913:	
		movlw	8
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u8781
	goto	u8780
u8781:
	goto	l5917
u8780:
	
l5915:	
		movlw	9
	xorwf	((_s_work)),w
	btfss	status,2
	goto	u8791
	goto	u8790
u8791:
	goto	l5919
u8790:
	line	468
	
l5917:	
;charge_mgr.c: 468: g_dispEnable = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_dispEnable)^080h	;volatile
	line	469
	
l5919:	
;charge_mgr.c: 469: if(s_work.state == 1 || s_work.state == 8 || s_work.state == 9)
	bcf	status, 5	;RP0=0, select bank0
		decf	((_s_work)),w
	btfsc	status,2
	goto	u8801
	goto	u8800
u8801:
	goto	l5925
u8800:
	
l5921:	
		movlw	8
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u8811
	goto	u8810
u8811:
	goto	l5925
u8810:
	
l5923:	
		movlw	9
	xorwf	((_s_work)),w
	btfss	status,2
	goto	u8821
	goto	u8820
u8821:
	goto	l5937
u8820:
	line	472
	
l5925:	
;charge_mgr.c: 470: {
;charge_mgr.c: 472: for(dly = 0; dly < 20; dly++)
	clrf	(Slot_Charge_Ctrl@dly)
	
l5927:	
	movlw	low(014h)
	subwf	(Slot_Charge_Ctrl@dly),w
	skipc
	goto	u8831
	goto	u8830
u8831:
	goto	l5931
u8830:
	goto	l5939
	line	473
	
l5931:	
;charge_mgr.c: 473: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u11367:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u11367
	nop
opt asmopt_pop

	line	472
	
l5933:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Slot_Charge_Ctrl@dly),f
	goto	l5927
	line	477
	
l5937:	
;charge_mgr.c: 475: else
;charge_mgr.c: 476: {
;charge_mgr.c: 477: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u11377:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u11377
	nop
opt asmopt_pop

	line	481
	
l5939:	
;charge_mgr.c: 478: }
;charge_mgr.c: 480: {
;charge_mgr.c: 481: unsigned int newv = Adc_Norm(s_adcChannels[idx]);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	fcall	_Adc_Norm
	movf	(1+(?_Adc_Norm)),w
	movwf	(Slot_Charge_Ctrl@newv+1)
	movf	(0+(?_Adc_Norm)),w
	movwf	(Slot_Charge_Ctrl@newv)
	line	485
	
l5941:	
;charge_mgr.c: 483: if(!(s_work.type == 6 &&
;charge_mgr.c: 484: (s_work.state == 4 || s_work.state == 5) &&
;charge_mgr.c: 485: newv >= 3990))
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u8841
	goto	u8840
u8841:
	goto	l5949
u8840:
	
l5943:	
		movlw	4
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u8851
	goto	u8850
u8851:
	goto	l5947
u8850:
	
l5945:	
		movlw	5
	xorwf	((_s_work)),w
	btfss	status,2
	goto	u8861
	goto	u8860
u8861:
	goto	l5949
u8860:
	
l5947:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@newv+1),w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@newv),w
	skipnc
	goto	u8871
	goto	u8870
u8871:
	goto	l6659
u8870:
	line	487
	
l5949:	
;charge_mgr.c: 486: {
;charge_mgr.c: 487: s_work.voltage = newv;
	movf	(Slot_Charge_Ctrl@newv+1),w
	movwf	1+(_s_work)+02h
	movf	(Slot_Charge_Ctrl@newv),w
	movwf	0+(_s_work)+02h
	goto	l6659
	line	496
	
l5951:	
;charge_mgr.c: 496: if(s_work.voltage >= 3990)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8881
	goto	u8880
u8881:
	goto	l5957
u8880:
	line	498
	
l5953:	
;charge_mgr.c: 497: {
;charge_mgr.c: 498: if(s_work.chargeTimer < (2400))
	movlw	09h
	subwf	1+(_s_work)+04h,w
	movlw	060h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipnc
	goto	u8891
	goto	u8890
u8891:
	goto	l5957
u8890:
	goto	l6661
	line	506
	
l5957:	
;charge_mgr.c: 500: }
;charge_mgr.c: 505: if((g_detectOwner != 0xFF && g_detectOwner != idx) ||
;charge_mgr.c: 506: (g_detectWaiter != 0xFF && g_detectWaiter != idx))
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectOwner)^080h),w
	btfsc	status,2
	goto	u8901
	goto	u8900
u8901:
	goto	l5961
u8900:
	
l5959:	
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u8911
	goto	u8910
u8911:
	goto	l6661
u8910:
	
l5961:	
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectWaiter)^080h),w
	btfsc	status,2
	goto	u8921
	goto	u8920
u8921:
	goto	l5965
u8920:
	
l5963:	
	movf	(_g_detectWaiter)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipnz
	goto	u8931
	goto	u8930
u8931:
	goto	l5965
u8930:
	goto	l6661
	line	509
	
l5965:	
;charge_mgr.c: 509: s_work.chargeTimer = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	510
	
l5967:	
;charge_mgr.c: 510: s_work.state = 1;
	clrf	(_s_work)
	incf	(_s_work),f
	line	511
	
l5969:	
;charge_mgr.c: 511: g_ccBlocks[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	512
	
l5971:	
;charge_mgr.c: 512: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8944
u8945:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8944:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8945
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	515
	
l5973:	
;charge_mgr.c: 515: if(s_work.voltage < 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u8951
	goto	u8950
u8951:
	goto	l5977
u8950:
	line	516
	
l5975:	
;charge_mgr.c: 516: g_slotRefV[idx] = s_work.voltage;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	0+(_s_work)+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)+02h,w
	movwf	indf
	goto	l6661
	line	518
	
l5977:	
;charge_mgr.c: 517: else
;charge_mgr.c: 518: g_slotRefV[idx] = 0;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l6661
	line	525
	
l5979:	
;charge_mgr.c: 525: if(charge_ticks_prev < 1U && s_work.chargeTimer >= 1U)
	movf	((Slot_Charge_Ctrl@charge_ticks_prev)),w
iorwf	((Slot_Charge_Ctrl@charge_ticks_prev+1)),w
	btfss	status,2
	goto	u8961
	goto	u8960
u8961:
	goto	l5987
u8960:
	
l5981:	
	movf	(0+(_s_work)+04h),w
iorwf	(1+(_s_work)+04h),w
	btfsc	status,2
	goto	u8971
	goto	u8970
u8971:
	goto	l5987
u8970:
	line	527
	
l5983:	
;charge_mgr.c: 526: {
;charge_mgr.c: 527: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	528
	
l5985:	
;charge_mgr.c: 528: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u8984
u8985:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u8984:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8985
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	531
	
l5987:	
;charge_mgr.c: 529: }
;charge_mgr.c: 531: if(s_work.chargeTimer < (240))
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(_s_work)+04h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipnc
	goto	u8991
	goto	u8990
u8991:
	goto	l5991
u8990:
	goto	l6661
	line	546
	
l5991:	
;charge_mgr.c: 538: }
;charge_mgr.c: 546: if(charge_ticks_prev < (240) && s_work.chargeTimer >= (240))
	movlw	0
	subwf	(Slot_Charge_Ctrl@charge_ticks_prev+1),w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@charge_ticks_prev),w
	skipnc
	goto	u9001
	goto	u9000
u9001:
	goto	l6001
u9000:
	
l5993:	
	movlw	0
	subwf	1+(_s_work)+04h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u9011
	goto	u9010
u9011:
	goto	l6001
u9010:
	line	548
	
l5995:	
;charge_mgr.c: 547: {
;charge_mgr.c: 548: g_slotRefV[idx] = s_work.voltage;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	0+(_s_work)+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)+02h,w
	movwf	indf
	line	549
	
l5997:	
;charge_mgr.c: 549: if(s_work.voltage > 2900)
	movlw	0Bh
	subwf	1+(_s_work)+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9021
	goto	u9020
u9021:
	goto	l6661
u9020:
	line	550
	
l5999:	
;charge_mgr.c: 550: g_capFlag |= (unsigned int)1 << idx;
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9034
u9035:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9034:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9035
	
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag+1)^080h,f
	goto	l6661
	line	553
	
l6001:	
;charge_mgr.c: 552: }
;charge_mgr.c: 553: if(s_work.voltage > 2900 && s_work.voltage < 3990)
	movlw	0Bh
	subwf	1+(_s_work)+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9041
	goto	u9040
u9041:
	goto	l6063
u9040:
	
l6003:	
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u9051
	goto	u9050
u9051:
	goto	l6063
u9050:
	line	565
	
l6005:	
;charge_mgr.c: 554: {
;charge_mgr.c: 564: if(!(g_capFlag & ((unsigned int)1 << idx)) && s_work.type != 5 &&
;charge_mgr.c: 565: s_work.voltage <= 3500)
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9064
u9065:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9064:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9065
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfss	status,2
	goto	u9071
	goto	u9070
u9071:
	goto	l6019
u9070:
	
l6007:	
		movlw	5
	xorwf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u9081
	goto	u9080
u9081:
	goto	l6019
u9080:
	
l6009:	
	movlw	0Dh
	subwf	1+(_s_work)+02h,w
	movlw	0ADh
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u9091
	goto	u9090
u9091:
	goto	l6019
u9090:
	line	567
	
l6011:	
;charge_mgr.c: 566: {
;charge_mgr.c: 567: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	568
	
l6013:	
;charge_mgr.c: 568: g_slotRefV[idx] = 0;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	569
	
l6015:	
;charge_mgr.c: 569: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	570
	
l6017:	
;charge_mgr.c: 570: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	571
;charge_mgr.c: 571: break;
	goto	l6661
	line	581
	
l6019:	
;charge_mgr.c: 572: }
;charge_mgr.c: 581: unsigned int v_init = g_slotRefV[idx];
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_init)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_init+1)
	line	583
;charge_mgr.c: 583: if((g_stableCnt[idx]) >= 20)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u9101
	goto	u9100
u9101:
	goto	l6043
u9100:
	line	588
	
l6021:	
;charge_mgr.c: 584: {
;charge_mgr.c: 588: g_highVFlag |= (unsigned int)1 << idx;
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9114
u9115:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9114:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9115
	
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag+1)^080h,f
	line	590
	
l6023:	
;charge_mgr.c: 590: if(s_work.voltage <= 2900)
	movlw	0Bh
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(_s_work)+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u9121
	goto	u9120
u9121:
	goto	l6031
u9120:
	line	593
	
l6025:	
;charge_mgr.c: 591: {
;charge_mgr.c: 593: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9134
u9135:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9134:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9135
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	594
	
l6027:	
;charge_mgr.c: 594: (g_stableCnt[idx]) = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	595
	
l6029:	
;charge_mgr.c: 595: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9144
u9145:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9144:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9145
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	596
;charge_mgr.c: 596: }
	goto	l6075
	line	597
	
l6031:	
;charge_mgr.c: 597: else if(s_work.chargeTimer < (240) + (800))
	movlw	04h
	subwf	1+(_s_work)+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipnc
	goto	u9151
	goto	u9150
u9151:
	goto	l6041
u9150:
	line	604
	
l6033:	
;charge_mgr.c: 598: {
;charge_mgr.c: 604: if(s_work.chargeTimer >= (240) + 25U)
	movlw	01h
	subwf	1+(_s_work)+04h,w
	movlw	09h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u9161
	goto	u9160
u9161:
	goto	l5975
u9160:
	line	606
	
l6035:	
;charge_mgr.c: 605: {
;charge_mgr.c: 606: Detect_Classify(idx, 1);
	clrf	(Detect_Classify@fromHighV)
	incf	(Detect_Classify@fromHighV),f
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	607
;charge_mgr.c: 607: break;
	goto	l6661
	line	616
	
l6041:	
;charge_mgr.c: 613: else
;charge_mgr.c: 614: {
;charge_mgr.c: 616: Detect_Classify(idx, 1);
	clrf	(Detect_Classify@fromHighV)
	incf	(Detect_Classify@fromHighV),f
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	617
;charge_mgr.c: 617: break;
	goto	l6661
	line	625
	
l6043:	
;charge_mgr.c: 620: else
;charge_mgr.c: 621: {
;charge_mgr.c: 625: if(s_work.chargeTimer >= (240) + (800))
	movlw	04h
	subwf	1+(_s_work)+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u9171
	goto	u9170
u9171:
	goto	l6047
u9170:
	line	627
	
l6045:	
;charge_mgr.c: 626: {
;charge_mgr.c: 627: Detect_Classify(idx, 1);
	clrf	(Detect_Classify@fromHighV)
	incf	(Detect_Classify@fromHighV),f
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	628
;charge_mgr.c: 628: break;
	goto	l6661
	line	633
	
l6047:	
;charge_mgr.c: 629: }
;charge_mgr.c: 633: g_slotRefV[idx] = s_work.voltage;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	0+(_s_work)+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)+02h,w
	movwf	indf
	line	634
	
l6049:	
;charge_mgr.c: 634: if(s_work.voltage + 50 < v_init)
	movf	0+(_s_work)+02h,w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	1+(_s_work)+02h,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v_init+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9185
	movf	(Slot_Charge_Ctrl@v_init),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9185:
	skipnc
	goto	u9181
	goto	u9180
u9181:
	goto	l6053
u9180:
	line	635
	
l6051:	
;charge_mgr.c: 635: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l683
	line	637
	
l6053:	
;charge_mgr.c: 636: else
;charge_mgr.c: 637: (g_stableCnt[idx])++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	
l683:	
	line	638
;charge_mgr.c: 638: if((g_stableCnt[idx]) < 20)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u9191
	goto	u9190
u9191:
	goto	l6057
u9190:
	goto	l6661
	line	641
	
l6057:	
;charge_mgr.c: 641: if(g_capFlag & ((unsigned int)1 << idx))
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9204
u9205:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9204:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9205
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u9211
	goto	u9210
u9211:
	goto	l6061
u9210:
	goto	l6661
	line	643
	
l6061:	
;charge_mgr.c: 643: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6075
	line	646
	
l6063:	
;charge_mgr.c: 646: else if(s_work.chargeTimer < (240) + (800) && s_work.voltage < 3990)
	movlw	04h
	subwf	1+(_s_work)+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipnc
	goto	u9221
	goto	u9220
u9221:
	goto	l6075
u9220:
	
l6065:	
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u9231
	goto	u9230
u9231:
	goto	l6075
u9230:
	line	648
	
l6067:	
;charge_mgr.c: 647: {
;charge_mgr.c: 648: unsigned int v_ref = g_slotRefV[idx];
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_ref)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_ref+1)
	line	649
	
l6069:	
;charge_mgr.c: 649: if(v_ref < 3990 && s_work.voltage + 50 < v_ref)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v_ref+1),w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v_ref),w
	skipnc
	goto	u9241
	goto	u9240
u9241:
	goto	l6075
u9240:
	
l6071:	
	movf	0+(_s_work)+02h,w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	1+(_s_work)+02h,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v_ref+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9255
	movf	(Slot_Charge_Ctrl@v_ref),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9255:
	skipnc
	goto	u9251
	goto	u9250
u9251:
	goto	l6075
u9250:
	goto	l5975
	line	659
	
l6075:	
;charge_mgr.c: 653: }
;charge_mgr.c: 654: }
;charge_mgr.c: 659: if(g_capFlag & ((unsigned int)1 << idx))
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9264
u9265:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9264:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9265
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u9271
	goto	u9270
u9271:
	goto	l6083
u9270:
	line	661
	
l6077:	
;charge_mgr.c: 660: {
;charge_mgr.c: 661: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9284
u9285:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9284:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9285
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	662
	
l6079:	
;charge_mgr.c: 662: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	663
	
l6081:	
;charge_mgr.c: 663: s_work.type = 5;
	movlw	low(05h)
	movwf	0+(_s_work)+01h
	line	664
;charge_mgr.c: 664: }
	goto	l690
	line	667
	
l6083:	
;charge_mgr.c: 665: else
;charge_mgr.c: 666: {
;charge_mgr.c: 667: s_work.type = Detect_BatteryType(s_work.voltage);
	movf	1+(_s_work)+02h,w
	movwf	(Detect_BatteryType@voltage+1)
	movf	0+(_s_work)+02h,w
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	movwf	0+(_s_work)+01h
	line	673
	
l6085:	
;charge_mgr.c: 672: if(s_work.type == 0 && s_work.voltage >= 3990 &&
;charge_mgr.c: 673: s_work.chargeTimer >= (240) + (800))
	movf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u9291
	goto	u9290
u9291:
	goto	l690
u9290:
	
l6087:	
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9301
	goto	u9300
u9301:
	goto	l690
u9300:
	
l6089:	
	movlw	04h
	subwf	1+(_s_work)+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u9311
	goto	u9310
u9311:
	goto	l690
u9310:
	goto	l6081
	line	675
	
l690:	
	line	679
;charge_mgr.c: 675: }
;charge_mgr.c: 679: if(s_work.voltage < 500)
	movlw	01h
	subwf	1+(_s_work)+02h,w
	movlw	0F4h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u9321
	goto	u9320
u9321:
	goto	l6097
u9320:
	line	681
	
l6093:	
;charge_mgr.c: 680: {
;charge_mgr.c: 681: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	682
;charge_mgr.c: 682: if(g_detectLowCnt[idx] < 5)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u9331
	goto	u9330
u9331:
	goto	l6105
u9330:
	goto	l6661
	line	686
	
l6097:	
;charge_mgr.c: 686: else if(s_work.type != 5 && s_work.type != 1 && s_work.type != 6)
		movlw	5
	xorwf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u9341
	goto	u9340
u9341:
	goto	l6105
u9340:
	
l6099:	
		decf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u9351
	goto	u9350
u9351:
	goto	l6105
u9350:
	
l6101:	
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u9361
	goto	u9360
u9361:
	goto	l6105
u9360:
	line	688
	
l6103:	
;charge_mgr.c: 687: {
;charge_mgr.c: 688: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	695
	
l6105:	
;charge_mgr.c: 689: }
;charge_mgr.c: 695: Detect_Classify(idx, 0);
	clrf	(Detect_Classify@fromHighV)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	696
;charge_mgr.c: 696: break;
	goto	l6661
	line	701
	
l6107:	
;charge_mgr.c: 701: if(s_work.chargeTimer < 5)
	movlw	0
	subwf	1+(_s_work)+04h,w
	movlw	05h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipnc
	goto	u9371
	goto	u9370
u9371:
	goto	l6111
u9370:
	goto	l6661
	line	706
	
l6111:	
;charge_mgr.c: 704: {
;charge_mgr.c: 706: Get_Vcc();
	fcall	_Get_Vcc
	line	712
	
l6113:	
;charge_mgr.c: 712: if(s_work.voltage >= 4050U && ((g_impData) & 0x0FFFU) >= 4050U)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(_s_work)+02h,w
	movlw	0D2h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9381
	goto	u9380
u9381:
	goto	l6123
u9380:
	
l6115:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0D2h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u9391
	goto	u9390
u9391:
	goto	l6123
u9390:
	line	714
	
l6117:	
;charge_mgr.c: 713: {
;charge_mgr.c: 714: s_work.type = 0;
	clrf	0+(_s_work)+01h
	line	715
;charge_mgr.c: 715: s_work.state = 0;
	clrf	(_s_work)
	line	716
	
l6119:	
;charge_mgr.c: 716: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	717
	
l6121:	
;charge_mgr.c: 717: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9404
u9405:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9404:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9405
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	718
;charge_mgr.c: 718: break;
	goto	l6661
	line	728
	
l6123:	
;charge_mgr.c: 719: }
;charge_mgr.c: 727: {
;charge_mgr.c: 728: unsigned int vcc_norm_pre = ((unsigned int)(((unsigned long)((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U)) * 4096UL) / 5000UL));
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	bsf	status, 5	;RP0=1, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(0+(?___wmul)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_Slot_Charge_Ctrl+0)+0)
	movf	(1+(?___wmul)),w
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
	clrf	((??_Slot_Charge_Ctrl+0)+0+2)
	clrf	((??_Slot_Charge_Ctrl+0)+0+3)
	movlw	0Ch
u9415:
	clrc
	rlf	(??_Slot_Charge_Ctrl+0)+0,f
	rlf	(??_Slot_Charge_Ctrl+0)+1,f
	rlf	(??_Slot_Charge_Ctrl+0)+2,f
	rlf	(??_Slot_Charge_Ctrl+0)+3,f
u9410:
	addlw	-1
	skipz
	goto	u9415
	movf	3+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_pre+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_pre)
	line	729
;charge_mgr.c: 729: unsigned int vcc_norm_now = ((unsigned int)(((unsigned long)(g_vcc_mv) * 4096UL) / 5000UL));
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lldiv@dividend))+1
	clrf	2+((___lldiv@dividend))
	clrf	3+((___lldiv@dividend))
	movlw	0Ch
	movwf	(??_Slot_Charge_Ctrl+0)+0
u9425:
	clrc
	rlf	(___lldiv@dividend),f
	rlf	(___lldiv@dividend+1),f
	rlf	(___lldiv@dividend+2),f
	rlf	(___lldiv@dividend+3),f
	decfsz	(??_Slot_Charge_Ctrl+0)+0
	goto	u9425
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_now+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_now)
	line	731
	
l6125:	
;charge_mgr.c: 730: if((((g_impData) & 0x0FFFU) + 150 >= vcc_norm_pre) &&
;charge_mgr.c: 731: (s_work.voltage + 150 >= vcc_norm_now))
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	(Slot_Charge_Ctrl@vcc_norm_pre+1),w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u9435
	movf	(Slot_Charge_Ctrl@vcc_norm_pre),w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u9435:
	skipc
	goto	u9431
	goto	u9430
u9431:
	goto	l6135
u9430:
	
l6127:	
	movf	0+(_s_work)+02h,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	1+(_s_work)+02h,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@vcc_norm_now+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9445
	movf	(Slot_Charge_Ctrl@vcc_norm_now),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9445:
	skipc
	goto	u9441
	goto	u9440
u9441:
	goto	l6135
u9440:
	goto	l6117
	line	744
	
l6135:	
;charge_mgr.c: 738: }
;charge_mgr.c: 739: }
;charge_mgr.c: 744: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 300U && s_work.voltage >= 3990)
	bsf	status, 5	;RP0=1, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	addlw	low(012Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w
	skipnc
	addlw	1
	addlw	high(012Ch)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9455
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9455:
	skipnc
	goto	u9451
	goto	u9450
u9451:
	goto	l6143
u9450:
	
l6137:	
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9461
	goto	u9460
u9461:
	goto	l6143
u9460:
	line	746
	
l6139:	
;charge_mgr.c: 745: {
;charge_mgr.c: 746: s_work.type = 2;
	movlw	low(02h)
	movwf	0+(_s_work)+01h
	line	747
;charge_mgr.c: 747: s_work.state = 7;
	movlw	low(07h)
	movwf	(_s_work)
	line	748
;charge_mgr.c: 748: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	goto	l6121
	line	758
	
l6143:	
;charge_mgr.c: 751: }
;charge_mgr.c: 757: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 200U &&
;charge_mgr.c: 758: ((g_impData) & 0x0FFFU) < 3100U)
	bsf	status, 5	;RP0=1, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	addlw	low(0C8h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w
	skipnc
	addlw	1
	addlw	high(0C8h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9475
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9475:
	skipnc
	goto	u9471
	goto	u9470
u9471:
	goto	l6149
u9470:
	
l6145:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Ch
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	01Ch
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u9481
	goto	u9480
u9481:
	goto	l6149
u9480:
	line	760
	
l6147:	
;charge_mgr.c: 759: {
;charge_mgr.c: 760: s_work.state = Route_LiIon(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	movwf	(_s_work)
	line	761
;charge_mgr.c: 761: break;
	goto	l6661
	line	770
	
l6149:	
;charge_mgr.c: 762: }
;charge_mgr.c: 768: if(!(g_highVFlag & ((unsigned int)1 << idx)) &&
;charge_mgr.c: 769: (((g_impData) & 0x0FFFU) > s_work.voltage) &&
;charge_mgr.c: 770: (((g_impData) & 0x0FFFU) - s_work.voltage) > 1000U)
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9494
u9495:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9494:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9495
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfss	status,2
	goto	u9501
	goto	u9500
u9501:
	goto	l6161
u9500:
	
l6151:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u9515
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(_s_work)+02h,w
u9515:
	skipnc
	goto	u9511
	goto	u9510
u9511:
	goto	l6161
u9510:
	
l6153:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(_s_work)+02h,w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(_s_work)+02h,w
	skipc
	incf	1+(_s_work)+02h,w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	03h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0E9h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipc
	goto	u9521
	goto	u9520
u9521:
	goto	l6161
u9520:
	line	772
	
l6155:	
;charge_mgr.c: 771: {
;charge_mgr.c: 772: s_work.type = 3;
	movlw	low(03h)
	movwf	0+(_s_work)+01h
	line	773
;charge_mgr.c: 773: s_work.state = 7;
	movlw	low(07h)
	movwf	(_s_work)
	line	774
;charge_mgr.c: 774: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	775
	
l6157:	
;charge_mgr.c: 775: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9534
u9535:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9534:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9535
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	goto	l6017
	line	784
	
l6161:	
;charge_mgr.c: 778: }
;charge_mgr.c: 783: if((((g_impData) & 0x0FFFU) > 3500) &&
;charge_mgr.c: 784: ((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) <= g_vcc_mv + 200U))
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Dh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0ADh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u9541
	goto	u9540
u9541:
	goto	l6167
u9540:
	
l6163:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	addlw	low(0C8h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w
	skipnc
	addlw	1
	addlw	high(0C8h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9555
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9555:
	skipc
	goto	u9551
	goto	u9550
u9551:
	goto	l6167
u9550:
	line	786
	
l6165:	
;charge_mgr.c: 785: {
;charge_mgr.c: 786: Enter_DiodeTest(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Enter_DiodeTest
	line	787
;charge_mgr.c: 787: break;
	goto	l6661
	line	795
	
l6167:	
;charge_mgr.c: 788: }
;charge_mgr.c: 795: Enter_DiodeTest(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Enter_DiodeTest
	line	797
;charge_mgr.c: 796: }
;charge_mgr.c: 797: break;
	goto	l6661
	line	813
	
l6169:	
;charge_mgr.c: 812: {
;charge_mgr.c: 813: unsigned char pt = (unsigned char)(g_diodeTraceCnt + 1U);
	movf	(_g_diodeTraceCnt)^080h,w
	addlw	01h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@pt)
	line	814
	
l6171:	
;charge_mgr.c: 814: unsigned int ptTick = (unsigned int)pt * 7U;
	movf	(Slot_Charge_Ctrl@pt),w
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	07h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(1+(?___wmul)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@ptTick+1)
	movf	(0+(?___wmul)),w
	movwf	(Slot_Charge_Ctrl@ptTick)
	line	815
	
l6173:	
;charge_mgr.c: 815: if(s_work.chargeTimer < ptTick)
	movf	(Slot_Charge_Ctrl@ptTick+1),w
	subwf	1+(_s_work)+04h,w
	skipz
	goto	u9565
	movf	(Slot_Charge_Ctrl@ptTick),w
	subwf	0+(_s_work)+04h,w
u9565:
	skipnc
	goto	u9561
	goto	u9560
u9561:
	goto	l6177
u9560:
	goto	l6193
	line	818
	
l6177:	
;charge_mgr.c: 817: {
;charge_mgr.c: 818: signed int diff = (signed int)s_work.voltage - (signed int)((g_impData) & 0x0FFFU);
	movf	1+(_s_work)+02h,w
	movwf	(Slot_Charge_Ctrl@diff+1)
	movf	0+(_s_work)+02h,w
	movwf	(Slot_Charge_Ctrl@diff)
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	(Slot_Charge_Ctrl@diff),f
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	decf	(Slot_Charge_Ctrl@diff+1),f
	subwf	(Slot_Charge_Ctrl@diff+1),f
	line	819
;charge_mgr.c: 819: diff >>= 2;
	rlf	(Slot_Charge_Ctrl@diff+1),w
	rrf	(Slot_Charge_Ctrl@diff+1),f
	rrf	(Slot_Charge_Ctrl@diff),f
	rlf	(Slot_Charge_Ctrl@diff+1),w
	rrf	(Slot_Charge_Ctrl@diff+1),f
	rrf	(Slot_Charge_Ctrl@diff),f
	line	820
	
l6179:	
;charge_mgr.c: 820: if(diff > 127) diff = 127;
	movf	(Slot_Charge_Ctrl@diff+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u9575
	movlw	080h
	subwf	(Slot_Charge_Ctrl@diff),w
u9575:

	skipc
	goto	u9571
	goto	u9570
u9571:
	goto	l6183
u9570:
	
l6181:	
	movlw	07Fh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff)
	clrf	(Slot_Charge_Ctrl@diff+1)
	line	821
	
l6183:	
;charge_mgr.c: 821: if(diff < -128) diff = -128;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@diff+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u9585
	movlw	080h
	subwf	(Slot_Charge_Ctrl@diff),w
u9585:

	skipnc
	goto	u9581
	goto	u9580
u9581:
	goto	l6187
u9580:
	
l6185:	
	movlw	080h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff)
	movlw	0FFh
	movwf	((Slot_Charge_Ctrl@diff))+1
	line	822
	
l6187:	
;charge_mgr.c: 822: g_diodeTrace[g_diodeTraceCnt++] = (unsigned char)(diff + 128);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_diodeTraceCnt)^080h,w
	addlw	low(_g_diodeTrace|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@diff),w
	addlw	080h
	bsf	status, 7	;select IRP bank3
	movwf	indf
	
l6189:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_diodeTraceCnt)^080h,f
	line	811
	
l6191:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_diodeTraceCnt)^080h,w
	skipc
	goto	u9591
	goto	u9590
u9591:
	goto	l6169
u9590:
	line	835
	
l6193:	
;charge_mgr.c: 823: }
;charge_mgr.c: 824: }
;charge_mgr.c: 825: {
;charge_mgr.c: 834: if(((g_impData) & 0x0FFFU) >= 2100 &&
;charge_mgr.c: 835: s_work.voltage > ((g_impData) & 0x0FFFU) + 900)
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	034h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u9601
	goto	u9600
u9601:
	goto	l6203
u9600:
	
l6195:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(0384h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(0384h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(_s_work)+02h,w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u9615
	movf	0+(_s_work)+02h,w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u9615:
	skipnc
	goto	u9611
	goto	u9610
u9611:
	goto	l6203
u9610:
	line	839
	
l6197:	
;charge_mgr.c: 836: {
;charge_mgr.c: 839: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150U)
	bsf	status, 5	;RP0=1, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9625
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9625:
	skipnc
	goto	u9621
	goto	u9620
u9621:
	goto	l6201
u9620:
	line	840
	
l6199:	
;charge_mgr.c: 840: s_work.state = Route_LiIon(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	movwf	(_s_work)
	goto	l6661
	line	842
	
l6201:	
;charge_mgr.c: 841: else
;charge_mgr.c: 842: s_work.state = Route_LinearLi(idx, (unsigned int)((g_impData) & 0x0FFFU));
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_LinearLi@pre)
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	movwf	(_s_work)
	goto	l6661
	line	854
	
l6203:	
;charge_mgr.c: 844: }
;charge_mgr.c: 852: if((((g_impData) & 0x0FFFU) > 3000U) &&
;charge_mgr.c: 853: (s_work.voltage > 2900) &&
;charge_mgr.c: 854: (s_work.voltage < ((g_impData) & 0x0FFFU)))
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Bh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0B9h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u9631
	goto	u9630
u9631:
	goto	l6211
u9630:
	
l6205:	
	movlw	0Bh
	subwf	1+(_s_work)+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9641
	goto	u9640
u9641:
	goto	l6211
u9640:
	
l6207:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u9655
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(_s_work)+02h,w
u9655:
	skipnc
	goto	u9651
	goto	u9650
u9651:
	goto	l6211
u9650:
	line	856
	
l6209:	
;charge_mgr.c: 855: {
;charge_mgr.c: 856: s_work.state = Route_LinearLi(idx, (unsigned int)((g_impData) & 0x0FFFU));
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_LinearLi@pre)
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	movwf	(_s_work)
	line	857
;charge_mgr.c: 857: break;
	goto	l6661
	line	867
	
l6211:	
;charge_mgr.c: 858: }
;charge_mgr.c: 866: if((s_work.voltage > 2900) &&
;charge_mgr.c: 867: (((g_impData) & 0x0FFFU) < 2100))
	movlw	0Bh
	subwf	1+(_s_work)+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9661
	goto	u9660
u9661:
	goto	l6221
u9660:
	
l6213:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	034h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u9671
	goto	u9670
u9671:
	goto	l6221
u9670:
	goto	l6155
	line	888
	
l6221:	
;charge_mgr.c: 875: }
;charge_mgr.c: 885: if(s_work.chargeTimer >= 20U && s_work.voltage > 2100U &&
;charge_mgr.c: 886: ((g_impData) & 0x0FFFU) <= 2300U &&
;charge_mgr.c: 887: s_work.voltage + 160U >= ((g_impData) & 0x0FFFU) &&
;charge_mgr.c: 888: s_work.voltage <= ((g_impData) & 0x0FFFU) + 150)
	movlw	0
	subwf	1+(_s_work)+04h,w
	movlw	014h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u9681
	goto	u9680
u9681:
	goto	l6233
u9680:
	
l6223:	
	movlw	08h
	subwf	1+(_s_work)+02h,w
	movlw	035h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9691
	goto	u9690
u9691:
	goto	l6233
u9690:
	
l6225:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u9701
	goto	u9700
u9701:
	goto	l6233
u9700:
	
l6227:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(_s_work)+02h,w
	addlw	low(0A0h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(_s_work)+02h,w
	skipnc
	addlw	1
	addlw	high(0A0h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u9715
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u9715:
	skipc
	goto	u9711
	goto	u9710
u9711:
	goto	l6233
u9710:
	
l6229:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(_s_work)+02h,w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u9725
	movf	0+(_s_work)+02h,w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u9725:
	skipc
	goto	u9721
	goto	u9720
u9721:
	goto	l6233
u9720:
	line	890
	
l6231:	
;charge_mgr.c: 889: {
;charge_mgr.c: 890: s_work.state = Route_LinearLi(idx, (unsigned int)((g_impData) & 0x0FFFU));
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_LinearLi@pre)
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	movwf	(_s_work)
	line	891
;charge_mgr.c: 891: break;
	goto	l6661
	line	899
	
l6233:	
;charge_mgr.c: 892: }
;charge_mgr.c: 899: if(s_work.chargeTimer >= 240)
	movlw	0
	subwf	1+(_s_work)+04h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u9731
	goto	u9730
u9731:
	goto	l6661
u9730:
	line	901
	
l6235:	
;charge_mgr.c: 900: {
;charge_mgr.c: 901: unsigned int pre = (unsigned int)((g_impData) & 0x0FFFU);
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@pre)
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(Slot_Charge_Ctrl@pre)
	line	910
	
l6237:	
;charge_mgr.c: 909: {
;charge_mgr.c: 910: unsigned int vcc_norm = ((unsigned int)(((unsigned long)(g_vcc_mv) * 4096UL) / 5000UL));
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lldiv@dividend))+1
	clrf	2+((___lldiv@dividend))
	clrf	3+((___lldiv@dividend))
	movlw	0Ch
	movwf	(??_Slot_Charge_Ctrl+0)+0
u9745:
	clrc
	rlf	(___lldiv@dividend),f
	rlf	(___lldiv@dividend+1),f
	rlf	(___lldiv@dividend+2),f
	rlf	(___lldiv@dividend+3),f
	decfsz	(??_Slot_Charge_Ctrl+0)+0
	goto	u9745
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm)
	line	911
	
l6239:	
;charge_mgr.c: 911: if(s_work.voltage + 150 >= vcc_norm)
	movf	0+(_s_work)+02h,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	1+(_s_work)+02h,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@vcc_norm+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9755
	movf	(Slot_Charge_Ctrl@vcc_norm),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9755:
	skipc
	goto	u9751
	goto	u9750
u9751:
	goto	l6247
u9750:
	line	913
	
l6241:	
;charge_mgr.c: 912: {
;charge_mgr.c: 913: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150U)
	bsf	status, 5	;RP0=1, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9765
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9765:
	skipnc
	goto	u9761
	goto	u9760
u9761:
	goto	l6245
u9760:
	line	914
	
l6243:	
;charge_mgr.c: 914: s_work.state = Route_LiIon(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	movwf	(_s_work)
	goto	l6661
	line	916
	
l6245:	
;charge_mgr.c: 915: else
;charge_mgr.c: 916: s_work.state = Route_LinearLi(idx, pre);
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	movwf	(_s_work)
	goto	l6661
	line	927
	
l6247:	
;charge_mgr.c: 918: }
;charge_mgr.c: 919: }
;charge_mgr.c: 926: if(pre > 3500 && pre < 3990 &&
;charge_mgr.c: 927: s_work.voltage >= pre + 50)
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0ADh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipc
	goto	u9771
	goto	u9770
u9771:
	goto	l6259
u9770:
	
l6249:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u9781
	goto	u9780
u9781:
	goto	l6259
u9780:
	
l6251:	
	movf	(Slot_Charge_Ctrl@pre),w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u9795
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(_s_work)+02h,w
u9795:
	skipc
	goto	u9791
	goto	u9790
u9791:
	goto	l6259
u9790:
	line	929
	
l6253:	
;charge_mgr.c: 928: {
;charge_mgr.c: 929: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150U)
	bsf	status, 5	;RP0=1, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9805
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9805:
	skipnc
	goto	u9801
	goto	u9800
u9801:
	goto	l6257
u9800:
	line	930
	
l6255:	
;charge_mgr.c: 930: s_work.state = Route_LiIon(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	movwf	(_s_work)
	goto	l6661
	line	932
	
l6257:	
;charge_mgr.c: 931: else
;charge_mgr.c: 932: s_work.state = Route_LinearLi(idx, pre);
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	movwf	(_s_work)
	goto	l6661
	line	953
	
l6259:	
;charge_mgr.c: 934: }
;charge_mgr.c: 950: if(s_work.voltage > 2600 && s_work.voltage < 3990 &&
;charge_mgr.c: 951: pre >= 2100 && pre < 3500U &&
;charge_mgr.c: 952: ((pre < 3000 && s_work.voltage + 150U >= pre) ||
;charge_mgr.c: 953: s_work.voltage >= pre + 50))
	movlw	0Ah
	subwf	1+(_s_work)+02h,w
	movlw	029h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9811
	goto	u9810
u9811:
	goto	l6275
u9810:
	
l6261:	
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u9821
	goto	u9820
u9821:
	goto	l6275
u9820:
	
l6263:	
	movlw	08h
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	034h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipc
	goto	u9831
	goto	u9830
u9831:
	goto	l6275
u9830:
	
l6265:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0ACh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u9841
	goto	u9840
u9841:
	goto	l6275
u9840:
	
l6267:	
	movlw	0Bh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0B8h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u9851
	goto	u9850
u9851:
	goto	l6271
u9850:
	
l6269:	
	movf	0+(_s_work)+02h,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	1+(_s_work)+02h,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9865
	movf	(Slot_Charge_Ctrl@pre),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9865:
	skipnc
	goto	u9861
	goto	u9860
u9861:
	goto	l6273
u9860:
	
l6271:	
	movf	(Slot_Charge_Ctrl@pre),w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u9875
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(_s_work)+02h,w
u9875:
	skipc
	goto	u9871
	goto	u9870
u9871:
	goto	l6275
u9870:
	line	955
	
l6273:	
;charge_mgr.c: 954: {
;charge_mgr.c: 955: s_work.state = Route_LinearLi(idx, pre);
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	movwf	(_s_work)
	line	956
;charge_mgr.c: 956: break;
	goto	l6661
	line	964
	
l6275:	
;charge_mgr.c: 957: }
;charge_mgr.c: 963: if(s_work.voltage > pre + 150 && s_work.voltage < 3990 &&
;charge_mgr.c: 964: pre > 1936 && pre < 3500U)
	movf	(Slot_Charge_Ctrl@pre),w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(_s_work)+02h,w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9885
	movf	0+(_s_work)+02h,w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9885:
	skipnc
	goto	u9881
	goto	u9880
u9881:
	goto	l6155
u9880:
	
l6277:	
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u9891
	goto	u9890
u9891:
	goto	l6155
u9890:
	
l6279:	
	movlw	07h
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	091h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipc
	goto	u9901
	goto	u9900
u9901:
	goto	l6155
u9900:
	
l6281:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0ACh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u9911
	goto	u9910
u9911:
	goto	l6155
u9910:
	line	966
	
l6283:	
;charge_mgr.c: 965: {
;charge_mgr.c: 966: s_work.state = Route_LinearLi(idx, pre);
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	movwf	(_s_work)
	line	967
;charge_mgr.c: 967: break;
	goto	l6661
	line	980
	
l6291:	
;charge_mgr.c: 980: if(s_work.chargeTimer > (60 * 100))
	movlw	017h
	subwf	1+(_s_work)+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u9921
	goto	u9920
u9921:
	goto	l6295
u9920:
	line	982
	
l6293:	
;charge_mgr.c: 981: {
;charge_mgr.c: 982: s_work.state = 7;
	movlw	low(07h)
	movwf	(_s_work)
	line	983
;charge_mgr.c: 983: break;
	goto	l6661
	line	985
	
l6295:	
;charge_mgr.c: 984: }
;charge_mgr.c: 985: if(s_work.voltage > 750)
	movlw	02h
	subwf	1+(_s_work)+02h,w
	movlw	0EFh
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9931
	goto	u9930
u9931:
	goto	l6301
u9930:
	line	987
	
l6297:	
;charge_mgr.c: 986: {
;charge_mgr.c: 987: s_work.state = 3;
	movlw	low(03h)
	movwf	(_s_work)
	line	988
	
l6299:	
;charge_mgr.c: 988: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	989
;charge_mgr.c: 989: break;
	goto	l6661
	line	991
	
l6301:	
;charge_mgr.c: 990: }
;charge_mgr.c: 991: if(s_work.voltage >= 3850)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9941
	goto	u9940
u9941:
	goto	l6661
u9940:
	goto	l6293
	line	1000
	
l6305:	
;charge_mgr.c: 1000: if(s_work.chargeTimer > (300 * 100))
	movlw	075h
	subwf	1+(_s_work)+04h,w
	movlw	031h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u9951
	goto	u9950
u9951:
	goto	l6309
u9950:
	goto	l6293
	line	1005
	
l6309:	
;charge_mgr.c: 1004: }
;charge_mgr.c: 1005: if(s_work.voltage >= 3850)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9961
	goto	u9960
u9961:
	goto	l6315
u9960:
	line	1007
	
l6311:	
;charge_mgr.c: 1006: {
;charge_mgr.c: 1007: g_ovCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1008
;charge_mgr.c: 1008: if(g_ovCnt[idx] >= 5)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u9971
	goto	u9970
u9971:
	goto	l6317
u9970:
	goto	l6293
	line	1016
	
l6315:	
;charge_mgr.c: 1014: else
;charge_mgr.c: 1015: {
;charge_mgr.c: 1016: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	1018
	
l6317:	
;charge_mgr.c: 1017: }
;charge_mgr.c: 1018: if(s_work.voltage >= 2700)
	movlw	0Ah
	subwf	1+(_s_work)+02h,w
	movlw	08Ch
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u9981
	goto	u9980
u9981:
	goto	l6661
u9980:
	line	1020
	
l6319:	
;charge_mgr.c: 1019: {
;charge_mgr.c: 1020: s_work.state = 4;
	movlw	low(04h)
	movwf	(_s_work)
	line	1021
	
l6321:	
;charge_mgr.c: 1021: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	1022
	
l6323:	
;charge_mgr.c: 1022: g_ccBlocks[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1023
	
l6325:	
;charge_mgr.c: 1023: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1024
	
l6327:	
;charge_mgr.c: 1024: g_slotRefV[idx] = s_work.voltage;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	0+(_s_work)+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)+02h,w
	movwf	indf
	line	1025
	
l6329:	
;charge_mgr.c: 1025: g_stableCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6661
	line	1031
	
l6331:	
;charge_mgr.c: 1031: if(s_work.chargeTimer >= (600 * 100))
	movlw	0EAh
	subwf	1+(_s_work)+04h,w
	movlw	060h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u9991
	goto	u9990
u9991:
	goto	l6337
u9990:
	line	1033
	
l6333:	
;charge_mgr.c: 1032: {
;charge_mgr.c: 1033: s_work.chargeTimer -= (600 * 100);
	movlw	060h
	subwf	0+(_s_work)+04h,f
	movlw	0EAh
	skipc
	decf	1+(_s_work)+04h,f
	subwf	1+(_s_work)+04h,f
	line	1034
	
l6335:	
;charge_mgr.c: 1034: (g_ccBlocks[idx]++);
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1039
	
l6337:	
;charge_mgr.c: 1035: }
;charge_mgr.c: 1039: if(((g_ccBlocks[idx]) & 0x7FU) >= 18)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(07Fh)
	bsf	status, 7	;select IRP bank3
	andwf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	low(012h)
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u10001
	goto	u10000
u10001:
	goto	l6341
u10000:
	goto	l6293
	line	1048
	
l6341:	
;charge_mgr.c: 1043: }
;charge_mgr.c: 1048: if(s_work.voltage >= 3990 && s_work.type == 6)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u10011
	goto	u10010
u10011:
	goto	l6347
u10010:
	
l6343:	
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u10021
	goto	u10020
u10021:
	goto	l6347
u10020:
	goto	l6355
	line	1052
	
l6347:	
;charge_mgr.c: 1052: else if(s_work.chargeTimer <= (6000))
	movlw	017h
	subwf	1+(_s_work)+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipnc
	goto	u10031
	goto	u10030
u10031:
	goto	l6351
u10030:
	goto	l6355
	line	1060
	
l6351:	
;charge_mgr.c: 1058: else
;charge_mgr.c: 1059: {
;charge_mgr.c: 1060: if(s_work.voltage > g_slotRefV[idx]) g_slotRefV[idx] = s_work.voltage;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(_s_work)+02h,w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u10045
	movf	0+(_s_work)+02h,w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u10045:
	skipnc
	goto	u10041
	goto	u10040
u10041:
	goto	l6355
u10040:
	
l6353:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	0+(_s_work)+02h,w
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)+02h,w
	movwf	indf
	line	1067
	
l6355:	
;charge_mgr.c: 1061: }
;charge_mgr.c: 1067: if(s_work.type == 6)
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u10051
	goto	u10050
u10051:
	goto	l6401
u10050:
	line	1069
	
l6357:	
;charge_mgr.c: 1068: {
;charge_mgr.c: 1069: if(s_work.voltage < 2000U)
	movlw	07h
	subwf	1+(_s_work)+02h,w
	movlw	0D0h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u10061
	goto	u10060
u10061:
	goto	l6367
u10060:
	line	1071
	
l6359:	
;charge_mgr.c: 1070: {
;charge_mgr.c: 1071: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1072
;charge_mgr.c: 1072: if(g_detectLowCnt[idx] >= 33U)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u10071
	goto	u10070
u10071:
	goto	l6369
u10070:
	line	1074
	
l6361:	
;charge_mgr.c: 1073: {
;charge_mgr.c: 1074: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1075
	
l6363:	
;charge_mgr.c: 1075: s_work.state = 7;
	movlw	low(07h)
	movwf	(_s_work)
	goto	l6299
	line	1082
	
l6367:	
;charge_mgr.c: 1080: else
;charge_mgr.c: 1081: {
;charge_mgr.c: 1082: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	1092
	
l6369:	
;charge_mgr.c: 1083: }
;charge_mgr.c: 1092: if(s_work.chargeTimer >= 1600)
	movlw	06h
	subwf	1+(_s_work)+04h,w
	movlw	040h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u10081
	goto	u10080
u10081:
	goto	l6435
u10080:
	line	1094
	
l6371:	
;charge_mgr.c: 1093: {
;charge_mgr.c: 1094: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	1095
	
l6373:	
;charge_mgr.c: 1095: if(s_work.voltage >= 2800U && s_work.voltage < 3990)
	movlw	0Ah
	subwf	1+(_s_work)+02h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u10091
	goto	u10090
u10091:
	goto	l6385
u10090:
	
l6375:	
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u10101
	goto	u10100
u10101:
	goto	l6385
u10100:
	line	1097
	
l6377:	
;charge_mgr.c: 1096: {
;charge_mgr.c: 1097: s_work.state = 5;
	movlw	low(05h)
	movwf	(_s_work)
	line	1098
	
l6379:	
;charge_mgr.c: 1098: g_ccBlocks[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6327
	line	1102
	
l6385:	
;charge_mgr.c: 1102: else if(s_work.voltage >= g_slotRefV[idx] + (30))
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u10115
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	0+(_s_work)+02h,w
u10115:
	skipc
	goto	u10111
	goto	u10110
u10111:
	goto	l6389
u10110:
	line	1104
	
l6387:	
;charge_mgr.c: 1103: {
;charge_mgr.c: 1104: (g_stableCnt[idx]) = 1;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	indf,f
	line	1105
;charge_mgr.c: 1105: g_slotRefV[idx] = s_work.voltage;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	0+(_s_work)+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)+02h,w
	movwf	indf
	line	1106
;charge_mgr.c: 1106: }
	goto	l6661
	line	1107
	
l6389:	
;charge_mgr.c: 1107: else if((g_stableCnt[idx]) != 0)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfsc	status,2
	goto	u10121
	goto	u10120
u10121:
	goto	l6393
u10120:
	goto	l5975
	line	1111
	
l6393:	
;charge_mgr.c: 1111: else if(((g_ccBlocks[idx]) & 0x80))
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	btfss	indf,(7)&7
	goto	u10131
	goto	u10130
u10131:
	goto	l6397
u10130:
	goto	l6293
	line	1117
	
l6397:	
;charge_mgr.c: 1115: else
;charge_mgr.c: 1116: {
;charge_mgr.c: 1117: (g_ccBlocks[idx] |= 0x80);
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(7/8),(7)&7
	line	1118
	
l6399:	
;charge_mgr.c: 1118: s_work.state = 1;
	clrf	(_s_work)
	incf	(_s_work),f
	line	1119
;charge_mgr.c: 1119: g_slotRefV[idx] = 0;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	1120
;charge_mgr.c: 1120: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6661
	line	1129
	
l6401:	
;charge_mgr.c: 1125: else
;charge_mgr.c: 1126: {
;charge_mgr.c: 1129: if((s_work.voltage < g_slotRefV[idx] && g_slotRefV[idx] - s_work.voltage > 500) || s_work.voltage < 2000U)
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u10145
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(_s_work)+02h,w
u10145:
	skipnc
	goto	u10141
	goto	u10140
u10141:
	goto	l6405
u10140:
	
l6403:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(_s_work)+02h,w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(_s_work)+02h,w
	skipc
	incf	1+(_s_work)+02h,w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	01h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipnc
	goto	u10151
	goto	u10150
u10151:
	goto	l6407
u10150:
	
l6405:	
	movlw	07h
	subwf	1+(_s_work)+02h,w
	movlw	0D0h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u10161
	goto	u10160
u10161:
	goto	l6419
u10160:
	line	1131
	
l6407:	
;charge_mgr.c: 1130: {
;charge_mgr.c: 1131: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	1132
;charge_mgr.c: 1132: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u10171
	goto	u10170
u10171:
	goto	l6411
u10170:
	goto	l6661
	line	1134
	
l6411:	
;charge_mgr.c: 1134: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1135
	
l6413:	
;charge_mgr.c: 1135: s_work.state = 1;
	clrf	(_s_work)
	incf	(_s_work),f
	goto	l6299
	line	1141
	
l6419:	
;charge_mgr.c: 1139: else
;charge_mgr.c: 1140: {
;charge_mgr.c: 1141: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1149
	
l6421:	
;charge_mgr.c: 1142: }
;charge_mgr.c: 1149: if(s_work.chargeTimer <= (6000))
	movlw	017h
	subwf	1+(_s_work)+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipnc
	goto	u10181
	goto	u10180
u10181:
	goto	l6427
u10180:
	line	1151
	
l6423:	
;charge_mgr.c: 1150: {
;charge_mgr.c: 1151: if(s_work.voltage >= g_slotRefV[idx] + (30))
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u10195
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	0+(_s_work)+02h,w
u10195:
	skipc
	goto	u10191
	goto	u10190
u10191:
	goto	l6427
u10190:
	line	1152
	
l6425:	
;charge_mgr.c: 1152: (g_stableCnt[idx]) = 1;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	indf,f
	line	1154
	
l6427:	
;charge_mgr.c: 1153: }
;charge_mgr.c: 1154: if(s_work.chargeTimer > (6000) && (g_stableCnt[idx]) == 0)
	movlw	017h
	subwf	1+(_s_work)+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u10201
	goto	u10200
u10201:
	goto	l6435
u10200:
	
l6429:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfss	status,2
	goto	u10211
	goto	u10210
u10211:
	goto	l6435
u10210:
	goto	l6363
	line	1168
	
l6435:	
;charge_mgr.c: 1159: }
;charge_mgr.c: 1160: }
;charge_mgr.c: 1168: if(s_work.voltage >= 3990 && s_work.type == 1)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u10221
	goto	u10220
u10221:
	goto	l6443
u10220:
	
l6437:	
		decf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u10231
	goto	u10230
u10231:
	goto	l6443
u10230:
	line	1170
	
l6439:	
;charge_mgr.c: 1169: {
;charge_mgr.c: 1170: s_work.state = 6;
	movlw	low(06h)
	movwf	(_s_work)
	goto	l6299
	line	1178
	
l6443:	
;charge_mgr.c: 1173: }
;charge_mgr.c: 1178: if(s_work.voltage >= 3850 && s_work.type != 6)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u10241
	goto	u10240
u10241:
	goto	l6451
u10240:
	
l6445:	
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u10251
	goto	u10250
u10251:
	goto	l6451
u10250:
	line	1180
	
l6447:	
;charge_mgr.c: 1179: {
;charge_mgr.c: 1180: g_ovCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1181
;charge_mgr.c: 1181: if(g_ovCnt[idx] >= 5)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u10261
	goto	u10260
u10261:
	goto	l6661
u10260:
	goto	l6293
	line	1189
	
l6451:	
;charge_mgr.c: 1187: else
;charge_mgr.c: 1188: {
;charge_mgr.c: 1189: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	1191
	
l6453:	
;charge_mgr.c: 1191: if(s_work.voltage >= 3100 && !(s_work.voltage >= 3990 && s_work.type == 6))
	movlw	0Ch
	subwf	1+(_s_work)+02h,w
	movlw	01Ch
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u10271
	goto	u10270
u10271:
	goto	l6661
u10270:
	
l6455:	
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u10281
	goto	u10280
u10281:
	goto	l6459
u10280:
	
l6457:	
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u10291
	goto	u10290
u10291:
	goto	l6661
u10290:
	line	1193
	
l6459:	
;charge_mgr.c: 1192: {
;charge_mgr.c: 1193: s_work.state = 5;
	movlw	low(05h)
	movwf	(_s_work)
	line	1194
	
l6461:	
;charge_mgr.c: 1194: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	1195
	
l6463:	
;charge_mgr.c: 1195: g_ccBlocks[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6661
	line	1202
	
l6465:	
;charge_mgr.c: 1202: if(s_work.chargeTimer > (600 * 100))
	movlw	0EAh
	subwf	1+(_s_work)+04h,w
	movlw	061h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipc
	goto	u10301
	goto	u10300
u10301:
	goto	l780
u10300:
	line	1203
	
l6467:	
;charge_mgr.c: 1203: s_work.state = 6;
	movlw	low(06h)
	movwf	(_s_work)
	
l780:	
	line	1211
;charge_mgr.c: 1211: if(s_work.voltage >= 3990 && s_work.type == 6)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u10311
	goto	u10310
u10311:
	goto	l6473
u10310:
	
l6469:	
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u10321
	goto	u10320
u10321:
	goto	l6473
u10320:
	goto	l6661
	line	1221
	
l6473:	
;charge_mgr.c: 1221: if(s_work.voltage < 3990 && s_work.chargeTimer <= (6000) && s_work.type == 1)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u10331
	goto	u10330
u10331:
	goto	l6495
u10330:
	
l6475:	
	movlw	017h
	subwf	1+(_s_work)+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)+04h,w
	skipnc
	goto	u10341
	goto	u10340
u10341:
	goto	l6495
u10340:
	
l6477:	
		decf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u10351
	goto	u10350
u10351:
	goto	l6495
u10350:
	line	1223
	
l6479:	
;charge_mgr.c: 1222: {
;charge_mgr.c: 1223: if((g_ccBlocks[idx]) == 0)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfss	status,2
	goto	u10361
	goto	u10360
u10361:
	goto	l6483
u10360:
	line	1225
	
l6481:	
;charge_mgr.c: 1224: {
;charge_mgr.c: 1225: g_slotRefV[idx] = s_work.voltage;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	0+(_s_work)+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)+02h,w
	movwf	indf
	line	1226
;charge_mgr.c: 1226: (g_ccBlocks[idx]) = 1;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	indf,f
	line	1227
;charge_mgr.c: 1227: }
	goto	l6495
	line	1228
	
l6483:	
;charge_mgr.c: 1228: else if(s_work.voltage >= g_slotRefV[idx] + (50))
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u10375
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	subwf	0+(_s_work)+02h,w
u10375:
	skipc
	goto	u10371
	goto	u10370
u10371:
	goto	l6493
u10370:
	line	1230
	
l6485:	
;charge_mgr.c: 1229: {
;charge_mgr.c: 1230: if(++(g_stableCnt[idx]) >= 3)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	movlw	low(03h)
	subwf	(indf),w
	skipc
	goto	u10381
	goto	u10380
u10381:
	goto	l784
u10380:
	line	1232
	
l6487:	
;charge_mgr.c: 1231: {
;charge_mgr.c: 1232: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6363
	line	1240
	
l6493:	
;charge_mgr.c: 1238: else
;charge_mgr.c: 1239: {
;charge_mgr.c: 1240: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6495
	line	1241
	
l784:	
	line	1249
	
l6495:	
;charge_mgr.c: 1241: }
;charge_mgr.c: 1242: }
;charge_mgr.c: 1249: if(s_work.voltage >= 3990)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u10391
	goto	u10390
u10391:
	goto	l6525
u10390:
	line	1251
	
l6497:	
;charge_mgr.c: 1250: {
;charge_mgr.c: 1251: if(s_work.type == 1)
		decf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u10401
	goto	u10400
u10401:
	goto	l6509
u10400:
	line	1253
	
l6499:	
;charge_mgr.c: 1252: {
;charge_mgr.c: 1253: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1254
;charge_mgr.c: 1254: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u10411
	goto	u10410
u10411:
	goto	l6503
u10410:
	goto	l6661
	line	1256
	
l6503:	
;charge_mgr.c: 1256: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6439
	line	1261
	
l6509:	
;charge_mgr.c: 1260: }
;charge_mgr.c: 1261: if(s_work.type == 6)
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u10421
	goto	u10420
u10421:
	goto	l6513
u10420:
	goto	l6661
	line	1266
	
l6513:	
;charge_mgr.c: 1265: }
;charge_mgr.c: 1266: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1267
;charge_mgr.c: 1267: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u10431
	goto	u10430
u10431:
	goto	l6517
u10430:
	goto	l6661
	line	1269
	
l6517:	
;charge_mgr.c: 1269: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1270
	
l6519:	
;charge_mgr.c: 1270: s_work.type = 0;
	clrf	0+(_s_work)+01h
	line	1271
	
l6521:	
;charge_mgr.c: 1271: s_work.state = 0;
	clrf	(_s_work)
	goto	l6299
	line	1281
	
l6525:	
;charge_mgr.c: 1274: }
;charge_mgr.c: 1281: if(s_work.type == 6)
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u10441
	goto	u10440
u10441:
	goto	l6539
u10440:
	line	1283
	
l6527:	
;charge_mgr.c: 1282: {
;charge_mgr.c: 1283: if(s_work.voltage < 2000U)
	movlw	07h
	subwf	1+(_s_work)+02h,w
	movlw	0D0h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u10451
	goto	u10450
u10451:
	goto	l6537
u10450:
	line	1285
	
l6529:	
;charge_mgr.c: 1284: {
;charge_mgr.c: 1285: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1286
;charge_mgr.c: 1286: if(g_detectLowCnt[idx] >= 33U)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u10461
	goto	u10460
u10461:
	goto	l6555
u10460:
	goto	l6361
	line	1296
	
l6537:	
;charge_mgr.c: 1294: else
;charge_mgr.c: 1295: {
;charge_mgr.c: 1296: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l6555
	line	1301
	
l6539:	
;charge_mgr.c: 1299: else
;charge_mgr.c: 1300: {
;charge_mgr.c: 1301: if(s_work.voltage < g_slotRefV[idx] && g_slotRefV[idx] - s_work.voltage > 500)
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(_s_work)+02h,w
	skipz
	goto	u10475
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(_s_work)+02h,w
u10475:
	skipnc
	goto	u10471
	goto	u10470
u10471:
	goto	l6537
u10470:
	
l6541:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(_s_work)+02h,w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(_s_work)+02h,w
	skipc
	incf	1+(_s_work)+02h,w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	01h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipc
	goto	u10481
	goto	u10480
u10481:
	goto	l6537
u10480:
	line	1303
	
l6543:	
;charge_mgr.c: 1302: {
;charge_mgr.c: 1303: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	1304
;charge_mgr.c: 1304: if(g_detectLowCnt[idx] >= 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipc
	goto	u10491
	goto	u10490
u10491:
	goto	l6555
u10490:
	line	1306
	
l6545:	
;charge_mgr.c: 1305: {
;charge_mgr.c: 1306: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1307
;charge_mgr.c: 1307: (g_ccBlocks[idx])++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1309
	
l6547:	
;charge_mgr.c: 1309: s_work.type = 0;
	clrf	0+(_s_work)+01h
	goto	l6413
	line	1325
	
l6555:	
;charge_mgr.c: 1318: }
;charge_mgr.c: 1319: }
;charge_mgr.c: 1325: if(s_work.voltage >= 3850 && s_work.type == 1)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u10501
	goto	u10500
u10501:
	goto	l6563
u10500:
	
l6557:	
		decf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u10511
	goto	u10510
u10511:
	goto	l6563
u10510:
	line	1327
	
l6559:	
;charge_mgr.c: 1326: {
;charge_mgr.c: 1327: g_ovCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1328
;charge_mgr.c: 1328: if(g_ovCnt[idx] >= 5)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u10521
	goto	u10520
u10521:
	goto	l6661
u10520:
	goto	l6293
	line	1336
	
l6563:	
;charge_mgr.c: 1334: else
;charge_mgr.c: 1335: {
;charge_mgr.c: 1336: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6661
	line	1347
	
l6565:	
;charge_mgr.c: 1347: if(s_work.voltage >= 3990)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u10531
	goto	u10530
u10531:
	goto	l6583
u10530:
	line	1349
	
l6567:	
;charge_mgr.c: 1348: {
;charge_mgr.c: 1349: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1350
	
l6569:	
;charge_mgr.c: 1350: if(g_detectLowCnt[idx] >= (s_work.type == 6 ? 50 : 2))
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u10541
	goto	u10540
u10541:
	goto	l6573
u10540:
	
l6571:	
	movlw	02h
	movwf	(_Slot_Charge_Ctrl$433)
	clrf	(_Slot_Charge_Ctrl$433+1)
	goto	l6575
	
l6573:	
	movlw	032h
	movwf	(_Slot_Charge_Ctrl$433)
	clrf	(_Slot_Charge_Ctrl$433+1)
	
l6575:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(_Slot_Charge_Ctrl$433+1),w
	xorlw	80h
	sublw	080h
	skipz
	goto	u10555
	movf	(_Slot_Charge_Ctrl$433),w
	subwf	indf,w
u10555:

	skipc
	goto	u10551
	goto	u10550
u10551:
	goto	l6661
u10550:
	line	1352
	
l6577:	
;charge_mgr.c: 1351: {
;charge_mgr.c: 1352: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l6521
	line	1361
	
l6583:	
;charge_mgr.c: 1357: }
;charge_mgr.c: 1361: if(s_work.voltage < 2800U)
	movlw	0Ah
	subwf	1+(_s_work)+02h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u10561
	goto	u10560
u10561:
	goto	l6017
u10560:
	line	1363
	
l6585:	
;charge_mgr.c: 1362: {
;charge_mgr.c: 1363: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1364
;charge_mgr.c: 1364: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u10571
	goto	u10570
u10571:
	goto	l6589
u10570:
	goto	l6661
	line	1366
	
l6589:	
;charge_mgr.c: 1366: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1367
	
l6591:	
;charge_mgr.c: 1367: s_work.state = 4;
	movlw	low(04h)
	movwf	(_s_work)
	line	1368
	
l6593:	
;charge_mgr.c: 1368: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	1369
	
l6595:	
;charge_mgr.c: 1369: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6379
	line	1382
	
l6605:	
;charge_mgr.c: 1382: if(s_work.voltage >= 3990)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u10581
	goto	u10580
u10581:
	goto	l6621
u10580:
	line	1384
	
l6607:	
;charge_mgr.c: 1383: {
;charge_mgr.c: 1384: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1385
;charge_mgr.c: 1385: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u10591
	goto	u10590
u10591:
	goto	l6611
u10590:
	goto	l6661
	line	1387
	
l6611:	
;charge_mgr.c: 1387: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1388
	
l6613:	
;charge_mgr.c: 1388: s_work.type = 0;
	clrf	0+(_s_work)+01h
	line	1389
	
l6615:	
;charge_mgr.c: 1389: s_work.state = 0;
	clrf	(_s_work)
	goto	l6461
	line	1402
	
l6621:	
;charge_mgr.c: 1393: }
;charge_mgr.c: 1402: if(s_work.type == 2 || s_work.type == 3)
		movlw	2
	xorwf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u10601
	goto	u10600
u10601:
	goto	l6625
u10600:
	
l6623:	
		movlw	3
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u10611
	goto	u10610
u10611:
	goto	l6641
u10610:
	line	1404
	
l6625:	
;charge_mgr.c: 1403: {
;charge_mgr.c: 1404: if(s_work.voltage > 2700U && (g_highVFlag & ((unsigned int)1 << idx)))
	movlw	0Ah
	subwf	1+(_s_work)+02h,w
	movlw	08Dh
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u10621
	goto	u10620
u10621:
	goto	l6017
u10620:
	
l6627:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u10634
u10635:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u10634:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u10635
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u10641
	goto	u10640
u10641:
	goto	l6017
u10640:
	line	1406
	
l6629:	
;charge_mgr.c: 1405: {
;charge_mgr.c: 1406: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1407
;charge_mgr.c: 1407: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u10651
	goto	u10650
u10651:
	goto	l6411
u10650:
	goto	l6661
	line	1420
	
l6641:	
;charge_mgr.c: 1418: }
;charge_mgr.c: 1420: if(s_work.voltage > 750)
	movlw	02h
	subwf	1+(_s_work)+02h,w
	movlw	0EFh
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u10661
	goto	u10660
u10661:
	goto	l6017
u10660:
	line	1422
	
l6643:	
;charge_mgr.c: 1421: {
;charge_mgr.c: 1422: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1423
;charge_mgr.c: 1423: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u10671
	goto	u10670
u10671:
	goto	l6411
u10670:
	goto	l6661
	line	1436
	
l6655:	
;charge_mgr.c: 1436: s_work.state = 0;
	clrf	(_s_work)
	line	1437
;charge_mgr.c: 1437: break;
	goto	l6661
	line	491
	
l6659:	
	movf	(_s_work),w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l5951
	xorlw	1^0	; case 1
	skipnz
	goto	l5979
	xorlw	2^1	; case 2
	skipnz
	goto	l6291
	xorlw	3^2	; case 3
	skipnz
	goto	l6305
	xorlw	4^3	; case 4
	skipnz
	goto	l6331
	xorlw	5^4	; case 5
	skipnz
	goto	l6465
	xorlw	6^5	; case 6
	skipnz
	goto	l6565
	xorlw	7^6	; case 7
	skipnz
	goto	l6605
	xorlw	8^7	; case 8
	skipnz
	goto	l6107
	xorlw	9^8	; case 9
	skipnz
	goto	l6191
	goto	l6655
	opt asmopt_pop

	line	1449
	
l6661:	
;charge_mgr.c: 1448: if(s_work.state == 1 || s_work.state == 8 ||
;charge_mgr.c: 1449: s_work.state == 9)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
		decf	((_s_work)),w
	btfsc	status,2
	goto	u10681
	goto	u10680
u10681:
	goto	l6667
u10680:
	
l6663:	
		movlw	8
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u10691
	goto	u10690
u10691:
	goto	l6667
u10690:
	
l6665:	
		movlw	9
	xorwf	((_s_work)),w
	btfss	status,2
	goto	u10701
	goto	u10700
u10701:
	goto	l6671
u10700:
	line	1451
	
l6667:	
;charge_mgr.c: 1450: {
;charge_mgr.c: 1451: if(g_detectOwner == 0xFF)
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectOwner)^080h),w
	btfss	status,2
	goto	u10711
	goto	u10710
u10711:
	goto	l831
u10710:
	line	1452
	
l6669:	
;charge_mgr.c: 1452: g_detectOwner = idx;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	goto	l831
	line	1456
	
l6671:	
;charge_mgr.c: 1454: else
;charge_mgr.c: 1455: {
;charge_mgr.c: 1456: if(g_detectOwner == idx)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u10721
	goto	u10720
u10721:
	goto	l831
u10720:
	line	1457
	
l6673:	
;charge_mgr.c: 1457: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	1458
	
l831:	
	line	1464
;charge_mgr.c: 1458: }
;charge_mgr.c: 1462: if(g_detectWaiter == idx &&
;charge_mgr.c: 1463: !(s_work.state == 1 || s_work.state == 8 ||
;charge_mgr.c: 1464: s_work.state == 9))
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_detectWaiter)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u10731
	goto	u10730
u10731:
	goto	l6683
u10730:
	
l6675:	
		decf	((_s_work)),w
	btfsc	status,2
	goto	u10741
	goto	u10740
u10741:
	goto	l6683
u10740:
	
l6677:	
		movlw	8
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u10751
	goto	u10750
u10751:
	goto	l6683
u10750:
	
l6679:	
		movlw	9
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u10761
	goto	u10760
u10761:
	goto	l6683
u10760:
	line	1465
	
l6681:	
;charge_mgr.c: 1465: g_detectWaiter = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectWaiter)^080h
	line	1467
	
l6683:	
;charge_mgr.c: 1467: g_slot[idx] = s_work;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_s_work),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+4,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)+5,w
	movwf	indf
	line	1476
	
l6685:	
;charge_mgr.c: 1474: if((s_work.state == 2 || s_work.state == 3 ||
;charge_mgr.c: 1475: s_work.state == 4 || s_work.state == 5) &&
;charge_mgr.c: 1476: g_detectOwner != 0xFF)
		movlw	2
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u10771
	goto	u10770
u10771:
	goto	l6693
u10770:
	
l6687:	
		movlw	3
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u10781
	goto	u10780
u10781:
	goto	l6693
u10780:
	
l6689:	
		movlw	4
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u10791
	goto	u10790
u10791:
	goto	l6693
u10790:
	
l6691:	
		movlw	5
	xorwf	((_s_work)),w
	btfss	status,2
	goto	u10801
	goto	u10800
u10801:
	goto	l6697
u10800:
	
l6693:	
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectOwner)^080h),w
	btfsc	status,2
	goto	u10811
	goto	u10810
u10811:
	goto	l6697
u10810:
	line	1478
	
l6695:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u10824
u10825:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u10824:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u10825
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_gateWant)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_gateWant+1)^080h,f	;volatile
	goto	l638
	line	1483
	
l6697:	
;charge_mgr.c: 1480: else if((s_work.state == 2 || s_work.state == 3 ||
;charge_mgr.c: 1481: s_work.state == 4 || s_work.state == 5 ||
;charge_mgr.c: 1482: ((s_work.state == 8 || s_work.state == 1) && g_detectOwner == idx)) &&
;charge_mgr.c: 1483: !g_tempProtect && !g_vccProtect)
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u10831
	goto	u10830
u10831:
	goto	l6711
u10830:
	
l6699:	
		movlw	3
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u10841
	goto	u10840
u10841:
	goto	l6711
u10840:
	
l6701:	
		movlw	4
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u10851
	goto	u10850
u10851:
	goto	l6711
u10850:
	
l6703:	
		movlw	5
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u10861
	goto	u10860
u10861:
	goto	l6711
u10860:
	
l6705:	
		movlw	8
	xorwf	((_s_work)),w
	btfsc	status,2
	goto	u10871
	goto	u10870
u10871:
	goto	l6709
u10870:
	
l6707:	
		decf	((_s_work)),w
	btfss	status,2
	goto	u10881
	goto	u10880
u10881:
	goto	l6695
u10880:
	
l6709:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u10891
	goto	u10890
u10891:
	goto	l6695
u10890:
	
l6711:	
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u10901
	goto	u10900
u10901:
	goto	l6695
u10900:
	
l6713:	
	movf	((_g_vccProtect)^080h),w
	btfss	status,2
	goto	u10911
	goto	u10910
u10911:
	goto	l6695
u10910:
	line	1485
	
l6715:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u10924
u10925:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u10924:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u10925
	
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_gateWant)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_gateWant+1)^080h,f	;volatile
	line	1491
	
l638:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_Charge_Ctrl
	__end_of_Slot_Charge_Ctrl:
	signat	_Slot_Charge_Ctrl,4217
	global	___wmul

;; *************** function ___wmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
;; Parameters:    Size  Location     Type
;;  multiplier      2    2[COMMON] unsigned int 
;;  multiplicand    2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  product         2    6[COMMON] unsigned int 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/100
;;		On exit  : 200/0
;;		Unchanged: 200/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         6       0       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
global __ptext5
__ptext5:	;psect for function ___wmul
psect	text5
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
	global	__size_of___wmul
	__size_of___wmul	equ	__end_of___wmul-___wmul
	
___wmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___wmul: [wreg+status,2+status,0]
	line	43
	
l5513:	
	clrf	(___wmul@product)
	clrf	(___wmul@product+1)
	line	45
	
l5515:	
	btfss	(___wmul@multiplier),(0)&7
	goto	u8371
	goto	u8370
u8371:
	goto	l5519
u8370:
	line	46
	
l5517:	
	movf	(___wmul@multiplicand),w
	addwf	(___wmul@product),f
	skipnc
	incf	(___wmul@product+1),f
	movf	(___wmul@multiplicand+1),w
	addwf	(___wmul@product+1),f
	line	47
	
l5519:	
	clrc
	rlf	(___wmul@multiplicand),f
	rlf	(___wmul@multiplicand+1),f
	line	48
	
l5521:	
	clrc
	rrf	(___wmul@multiplier+1),f
	rrf	(___wmul@multiplier),f
	line	49
	
l5523:	
	movf	((___wmul@multiplier)),w
iorwf	((___wmul@multiplier+1)),w
	btfss	status,2
	goto	u8381
	goto	u8380
u8381:
	goto	l5515
u8380:
	line	52
	
l5525:	
	movf	(___wmul@product+1),w
	movwf	(?___wmul+1)
	movf	(___wmul@product),w
	movwf	(?___wmul)
	line	53
	
l903:	
	return
	opt stack 0
GLOBAL	__end_of___wmul
	__end_of___wmul:
	signat	___wmul,8314
	global	_Route_LinearLi

;; *************** function _Route_LinearLi *****************
;; Defined at:
;;		line 315 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  pre             2   35[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1   40[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       6       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Route_DetectLi
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	315
global __ptext6
__ptext6:	;psect for function _Route_LinearLi
psect	text6
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	315
	global	__size_of_Route_LinearLi
	__size_of_Route_LinearLi	equ	__end_of_Route_LinearLi-_Route_LinearLi
	
_Route_LinearLi:	
;incstack = 0
	opt	stack 2
; Regs used in _Route_LinearLi: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Route_LinearLi@idx stored from wreg
	movwf	(Route_LinearLi@idx)
	line	317
	
l5427:	
;charge_mgr.c: 317: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	318
	
l5429:	
;charge_mgr.c: 318: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Route_LinearLi@idx),w
	movwf	(??_Route_LinearLi+0)+0
	movlw	01h
	movwf	(??_Route_LinearLi+1)+0
	movlw	0
	movwf	(??_Route_LinearLi+1)+0+1
	goto	u8234
u8235:
	clrc
	rlf	(??_Route_LinearLi+1)+0,f
	rlf	(??_Route_LinearLi+1)+1,f
u8234:
	decfsz	(??_Route_LinearLi+0)+0,f
	goto	u8235
	
	comf	(??_Route_LinearLi+1)+0,f
	comf	(??_Route_LinearLi+1)+1,f
	movf	0+(??_Route_LinearLi+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Route_LinearLi+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	319
	
l5431:	
;charge_mgr.c: 319: if(((g_ccBlocks[idx]) & 0x80))
	bcf	status, 5	;RP0=0, select bank0
	movf	(Route_LinearLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	btfss	indf,(7)&7
	goto	u8241
	goto	u8240
u8241:
	goto	l5437
u8240:
	line	321
	
l5433:	
;charge_mgr.c: 320: {
;charge_mgr.c: 321: s_work.type = 3;
	movlw	low(03h)
	movwf	0+(_s_work)+01h
	line	322
;charge_mgr.c: 322: return 7;
	movlw	low(07h)
	goto	l610
	line	324
	
l5437:	
;charge_mgr.c: 323: }
;charge_mgr.c: 324: s_work.type = 6;
	movlw	low(06h)
	movwf	0+(_s_work)+01h
	line	325
	
l5439:	
;charge_mgr.c: 325: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	326
	
l5441:	
;charge_mgr.c: 326: return Route_DetectLi(idx, pre);
	movf	(Route_LinearLi@pre+1),w
	movwf	(Route_DetectLi@slot_v+1)
	movf	(Route_LinearLi@pre),w
	movwf	(Route_DetectLi@slot_v)
	movf	(Route_LinearLi@idx),w
	fcall	_Route_DetectLi
	line	327
	
l610:	
	return
	opt stack 0
GLOBAL	__end_of_Route_LinearLi
	__end_of_Route_LinearLi:
	signat	_Route_LinearLi,8313
	global	_Route_LiIon

;; *************** function _Route_LiIon *****************
;; Defined at:
;;		line 290 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   38[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Route_DetectLi
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	line	290
global __ptext7
__ptext7:	;psect for function _Route_LiIon
psect	text7
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	290
	global	__size_of_Route_LiIon
	__size_of_Route_LiIon	equ	__end_of_Route_LiIon-_Route_LiIon
	
_Route_LiIon:	
;incstack = 0
	opt	stack 2
; Regs used in _Route_LiIon: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Route_LiIon@idx stored from wreg
	movwf	(Route_LiIon@idx)
	line	292
	
l5415:	
;charge_mgr.c: 292: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	293
	
l5417:	
;charge_mgr.c: 293: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Route_LiIon@idx),w
	movwf	(??_Route_LiIon+0)+0
	movlw	01h
	movwf	(??_Route_LiIon+1)+0
	movlw	0
	movwf	(??_Route_LiIon+1)+0+1
	goto	u8224
u8225:
	clrc
	rlf	(??_Route_LiIon+1)+0,f
	rlf	(??_Route_LiIon+1)+1,f
u8224:
	decfsz	(??_Route_LiIon+0)+0,f
	goto	u8225
	
	comf	(??_Route_LiIon+1)+0,f
	comf	(??_Route_LiIon+1)+1,f
	movf	0+(??_Route_LiIon+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Route_LiIon+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	294
	
l5419:	
;charge_mgr.c: 294: s_work.type = 1;
	bcf	status, 5	;RP0=0, select bank0
	clrf	0+(_s_work)+01h
	incf	0+(_s_work)+01h,f
	line	295
	
l5421:	
;charge_mgr.c: 295: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	296
	
l5423:	
;charge_mgr.c: 296: return Route_DetectLi(idx, s_work.voltage);
	movf	1+(_s_work)+02h,w
	movwf	(Route_DetectLi@slot_v+1)
	movf	0+(_s_work)+02h,w
	movwf	(Route_DetectLi@slot_v)
	movf	(Route_LiIon@idx),w
	fcall	_Route_DetectLi
	line	297
	
l606:	
	return
	opt stack 0
GLOBAL	__end_of_Route_LiIon
	__end_of_Route_LiIon:
	signat	_Route_LiIon,4217
	global	_Enter_DiodeTest

;; *************** function _Enter_DiodeTest *****************
;; Defined at:
;;		line 406 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          3       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	406
global __ptext8
__ptext8:	;psect for function _Enter_DiodeTest
psect	text8
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	406
	global	__size_of_Enter_DiodeTest
	__size_of_Enter_DiodeTest	equ	__end_of_Enter_DiodeTest-_Enter_DiodeTest
	
_Enter_DiodeTest:	
;incstack = 0
	opt	stack 4
; Regs used in _Enter_DiodeTest: [wreg+status,2+status,0]
;Enter_DiodeTest@idx stored from wreg
	movwf	(Enter_DiodeTest@idx)
	line	408
	
l5505:	
;charge_mgr.c: 408: s_work.state = 9;
	movlw	low(09h)
	movwf	(_s_work)
	line	409
	
l5507:	
;charge_mgr.c: 409: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	410
	
l5509:	
;charge_mgr.c: 410: g_diodeTraceCnt = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_diodeTraceCnt)^080h
	line	411
;charge_mgr.c: 411: g_diodeTraceSlot = (unsigned char)idx;
	movf	(Enter_DiodeTest@idx),w
	movwf	(_g_diodeTraceSlot)^080h
	line	412
	
l5511:	
;charge_mgr.c: 412: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(Enter_DiodeTest@idx),w
	movwf	(??_Enter_DiodeTest+0)+0
	movlw	01h
	movwf	(??_Enter_DiodeTest+1)+0
	movlw	0
	movwf	(??_Enter_DiodeTest+1)+0+1
	goto	u8364
u8365:
	clrc
	rlf	(??_Enter_DiodeTest+1)+0,f
	rlf	(??_Enter_DiodeTest+1)+1,f
u8364:
	decfsz	(??_Enter_DiodeTest+0)+0,f
	goto	u8365
	
	comf	(??_Enter_DiodeTest+1)+0,f
	comf	(??_Enter_DiodeTest+1)+1,f
	movf	0+(??_Enter_DiodeTest+1)+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_Enter_DiodeTest+1)+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	413
	
l629:	
	return
	opt stack 0
GLOBAL	__end_of_Enter_DiodeTest
	__end_of_Enter_DiodeTest:
	signat	_Enter_DiodeTest,4217
	global	_Detect_Classify

;; *************** function _Detect_Classify *****************
;; Defined at:
;;		line 342 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  fromHighV       1   35[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   39[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       5       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Get_Vcc
;;		_Route_DetectLi
;;		___lwdiv
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	342
global __ptext9
__ptext9:	;psect for function _Detect_Classify
psect	text9
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	342
	global	__size_of_Detect_Classify
	__size_of_Detect_Classify	equ	__end_of_Detect_Classify-_Detect_Classify
	
_Detect_Classify:	
;incstack = 0
	opt	stack 2
; Regs used in _Detect_Classify: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Detect_Classify@idx stored from wreg
	movwf	(Detect_Classify@idx)
	line	344
	
l5445:	
;charge_mgr.c: 344: if(fromHighV)
	movf	((Detect_Classify@fromHighV)),w
	btfsc	status,2
	goto	u8251
	goto	u8250
u8251:
	goto	l5453
u8250:
	line	352
	
l5447:	
;charge_mgr.c: 345: {
;charge_mgr.c: 352: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Detect_Classify@idx),w
	movwf	(??_Detect_Classify+0)+0
	movlw	01h
	movwf	(??_Detect_Classify+1)+0
	movlw	0
	movwf	(??_Detect_Classify+1)+0+1
	goto	u8264
u8265:
	clrc
	rlf	(??_Detect_Classify+1)+0,f
	rlf	(??_Detect_Classify+1)+1,f
u8264:
	decfsz	(??_Detect_Classify+0)+0,f
	goto	u8265
	
	comf	(??_Detect_Classify+1)+0,f
	comf	(??_Detect_Classify+1)+1,f
	movf	0+(??_Detect_Classify+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Detect_Classify+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	353
	
l5449:	
;charge_mgr.c: 353: g_stableCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Detect_Classify@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	354
	
l5451:	
;charge_mgr.c: 354: s_work.type = 5;
	movlw	low(05h)
	movwf	0+(_s_work)+01h
	line	356
	
l5453:	
;charge_mgr.c: 355: }
;charge_mgr.c: 356: if(s_work.type == 5)
		movlw	5
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u8271
	goto	u8270
u8271:
	goto	l5475
u8270:
	line	360
	
l5455:	
;charge_mgr.c: 357: {
;charge_mgr.c: 360: g_detectLowCnt[idx]++;
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	361
;charge_mgr.c: 361: if(g_detectLowCnt[idx] < 2)
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8281
	goto	u8280
u8281:
	goto	l5459
u8280:
	goto	l616
	line	365
	
l5459:	
;charge_mgr.c: 365: g_detectOwner = idx;
	movf	(Detect_Classify@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	366
	
l5461:	
;charge_mgr.c: 366: Get_Vcc();
	fcall	_Get_Vcc
	line	368
	
l5463:	
;charge_mgr.c: 368: g_impData = ((((s_work.voltage) > 0x0FFFU) ? 0x0FFFU : (s_work.voltage)) | ((unsigned int)((((g_vcc_mv) + 50U) / 100U) - 38U) << 12));
	movlw	064h
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	addlw	low(032h)
	movwf	(___lwdiv@dividend)
	movf	(_g_vcc_mv+1)^080h,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_impData+1)^080h
	movf	(0+(?___lwdiv)),w
	movwf	(_g_impData)^080h
	movlw	0Ch
	
u8295:
	clrc
	rlf	(_g_impData)^080h,f
	rlf	(_g_impData+1)^080h,f
	addlw	-1
	skipz
	goto	u8295
	movlw	(0A000h >> 8)
	addwf	(_g_impData+1)^080h,f
	movlw	010h
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(_s_work)+02h,w
	movlw	0
	skipnz
	subwf	0+(_s_work)+02h,w
	skipnc
	goto	u8301
	goto	u8300
u8301:
	goto	l5467
u8300:
	
l5465:	
	movf	0+(_s_work)+02h,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_impData)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(_s_work)+02h,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_impData+1)^080h,f
	goto	l620
	
l5467:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_impData)^080h,f
	movlw	0Fh
	iorwf	(_g_impData+1)^080h,f
	
l620:	
	line	369
;charge_mgr.c: 369: s_work.state = 8;
	movlw	low(08h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_s_work)
	line	370
	
l5469:	
;charge_mgr.c: 370: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	line	371
	
l5471:	
;charge_mgr.c: 371: g_detectLowCnt[idx] = 0;
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l616
	line	374
	
l5475:	
;charge_mgr.c: 373: }
;charge_mgr.c: 374: if(s_work.type == 1 || s_work.type == 6)
		decf	(0+(_s_work)+01h),w
	btfsc	status,2
	goto	u8311
	goto	u8310
u8311:
	goto	l5479
u8310:
	
l5477:	
		movlw	6
	xorwf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u8321
	goto	u8320
u8321:
	goto	l5489
u8320:
	line	377
	
l5479:	
;charge_mgr.c: 375: {
;charge_mgr.c: 377: g_detectLowCnt[idx]++;
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	378
;charge_mgr.c: 378: if(g_detectLowCnt[idx] < 2)
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8331
	goto	u8330
u8331:
	goto	l5483
u8330:
	goto	l616
	line	380
	
l5483:	
;charge_mgr.c: 380: s_work.state = Route_DetectLi(idx, s_work.voltage);
	movf	1+(_s_work)+02h,w
	movwf	(Route_DetectLi@slot_v+1)
	movf	0+(_s_work)+02h,w
	movwf	(Route_DetectLi@slot_v)
	movf	(Detect_Classify@idx),w
	fcall	_Route_DetectLi
	movwf	(_s_work)
	line	381
	
l5485:	
;charge_mgr.c: 381: s_work.chargeTimer = 0;
	clrf	0+(_s_work)+04h
	clrf	1+(_s_work)+04h
	goto	l616
	line	384
	
l5489:	
;charge_mgr.c: 383: }
;charge_mgr.c: 384: if(s_work.type == 0)
	movf	(0+(_s_work)+01h),w
	btfss	status,2
	goto	u8341
	goto	u8340
u8341:
	goto	l5495
u8340:
	line	387
	
l5491:	
;charge_mgr.c: 385: {
;charge_mgr.c: 387: if(s_work.voltage >= 3990)
	movlw	0Fh
	subwf	1+(_s_work)+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)+02h,w
	skipc
	goto	u8351
	goto	u8350
u8351:
	goto	l5495
u8350:
	goto	l616
	line	389
	
l5495:	
;charge_mgr.c: 389: s_work.state = 7;
	movlw	low(07h)
	movwf	(_s_work)
	goto	l5471
	line	396
	
l616:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_Classify
	__end_of_Detect_Classify:
	signat	_Detect_Classify,8313
	global	_Route_DetectLi

;; *************** function _Route_DetectLi *****************
;; Defined at:
;;		line 218 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  slot_v          2   17[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1   34[BANK0 ] unsigned char 
;;  bat_mv_long     4   29[BANK0 ] unsigned long 
;;  vx_mv           4   25[BANK0 ] unsigned long 
;;  bat_mv          2   23[BANK0 ] unsigned int 
;;  st              1   33[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0      12       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      18       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_Route_LiIon
;;		_Route_LinearLi
;;		_Detect_Classify
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=0
	line	218
global __ptext10
__ptext10:	;psect for function _Route_DetectLi
psect	text10
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	218
	global	__size_of_Route_DetectLi
	__size_of_Route_DetectLi	equ	__end_of_Route_DetectLi-_Route_DetectLi
	
_Route_DetectLi:	
;incstack = 0
	opt	stack 2
; Regs used in _Route_DetectLi: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Route_DetectLi@idx stored from wreg
	movwf	(Route_DetectLi@idx)
	line	231
	
l5233:	
;charge_mgr.c: 226: unsigned long vx_mv;
;charge_mgr.c: 227: unsigned long bat_mv_long;
;charge_mgr.c: 228: unsigned int bat_mv;
;charge_mgr.c: 229: unsigned char st;
;charge_mgr.c: 231: vx_mv = (unsigned long)slot_v * 5000UL / 4096UL;
	movf	(Route_DetectLi@slot_v),w
	movwf	(___lmul@multiplier)
	movf	(Route_DetectLi@slot_v+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv)

	
l5235:	
	movlw	0Ch
u7975:
	clrc
	rrf	(Route_DetectLi@vx_mv+3),f
	rrf	(Route_DetectLi@vx_mv+2),f
	rrf	(Route_DetectLi@vx_mv+1),f
	rrf	(Route_DetectLi@vx_mv),f
	addlw	-1
	skipz
	goto	u7975

	line	232
	
l5237:	
;charge_mgr.c: 232: bat_mv_long = 124UL * vx_mv + 206UL * 5000UL;
	movf	(Route_DetectLi@vx_mv+3),w
	movwf	(___lmul@multiplier+3)
	movf	(Route_DetectLi@vx_mv+2),w
	movwf	(___lmul@multiplier+2)
	movf	(Route_DetectLi@vx_mv+1),w
	movwf	(___lmul@multiplier+1)
	movf	(Route_DetectLi@vx_mv),w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long+3)
	movf	(2+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long+2)
	movf	(1+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long+1)
	movf	(0+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long)

	
l5239:	
	movlw	070h
	addwf	(Route_DetectLi@bat_mv_long),f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Route_DetectLi@bat_mv_long+1),f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Route_DetectLi@bat_mv_long+2),f
	movlw	0
	skipnc
movlw 1
	addwf	(Route_DetectLi@bat_mv_long+3),f
	line	233
	
l5241:	
;charge_mgr.c: 233: bat_mv = (unsigned int)((bat_mv_long + 1000UL/2UL) / 1000UL);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Route_DetectLi+0)+0)
	movlw	01h
	movwf	((??_Route_DetectLi+0)+0+1)
	movlw	0
	movwf	((??_Route_DetectLi+0)+0+2)
	movlw	0
	movwf	((??_Route_DetectLi+0)+0+3)
	movf	(Route_DetectLi@bat_mv_long),w
	addwf	(??_Route_DetectLi+0)+0,f
	movf	(Route_DetectLi@bat_mv_long+1),w
	skipnc
	incfsz	(Route_DetectLi@bat_mv_long+1),w
	goto	u7980
	goto	u7981
u7980:
	addwf	(??_Route_DetectLi+0)+1,f
u7981:
	movf	(Route_DetectLi@bat_mv_long+2),w
	skipnc
	incfsz	(Route_DetectLi@bat_mv_long+2),w
	goto	u7982
	goto	u7983
u7982:
	addwf	(??_Route_DetectLi+0)+2,f
u7983:
	movf	(Route_DetectLi@bat_mv_long+3),w
	skipnc
	incf	(Route_DetectLi@bat_mv_long+3),w
	addwf	(??_Route_DetectLi+0)+3,f
	movf	3+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Route_DetectLi@bat_mv+1)
	movf	(0+(?___lldiv)),w
	movwf	(Route_DetectLi@bat_mv)
	line	236
	
l5243:	
;charge_mgr.c: 236: if(slot_v >= 3235 || bat_mv > 60000U)
	movlw	0Ch
	subwf	(Route_DetectLi@slot_v+1),w
	movlw	0A3h
	skipnz
	subwf	(Route_DetectLi@slot_v),w
	skipnc
	goto	u7991
	goto	u7990
u7991:
	goto	l5247
u7990:
	
l5245:	
	movlw	0EAh
	subwf	(Route_DetectLi@bat_mv+1),w
	movlw	061h
	skipnz
	subwf	(Route_DetectLi@bat_mv),w
	skipc
	goto	u8001
	goto	u8000
u8001:
	goto	l5259
u8000:
	line	238
	
l5247:	
;charge_mgr.c: 237: {
;charge_mgr.c: 238: if((g_ccBlocks[idx]) >= 2)
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u8011
	goto	u8010
u8011:
	goto	l5251
u8010:
	line	240
	
l5249:	
;charge_mgr.c: 239: {
;charge_mgr.c: 240: st = 7;
	movlw	low(07h)
	movwf	(Route_DetectLi@st)
	line	241
;charge_mgr.c: 241: }
	goto	l5267
	line	244
	
l5251:	
;charge_mgr.c: 242: else
;charge_mgr.c: 243: {
;charge_mgr.c: 244: st = 5;
	movlw	low(05h)
	movwf	(Route_DetectLi@st)
	line	245
	
l5253:	
;charge_mgr.c: 245: g_slotRefV[idx] = slot_v;
	clrc
	rlf	(Route_DetectLi@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Route_DetectLi@slot_v),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	(Route_DetectLi@slot_v+1),w
	movwf	indf
	line	246
	
l5255:	
;charge_mgr.c: 246: g_ccBlocks[idx] = 0;
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	247
	
l5257:	
;charge_mgr.c: 247: g_stableCnt[idx] = 0;
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l5267
	line	252
	
l5259:	
;charge_mgr.c: 250: else
;charge_mgr.c: 251: {
;charge_mgr.c: 252: st = 4;
	movlw	low(04h)
	movwf	(Route_DetectLi@st)
	line	253
	
l5261:	
;charge_mgr.c: 253: (g_ccBlocks[idx] &= 0x80);
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(080h)
	bsf	status, 7	;select IRP bank3
	andwf	indf,f
	line	255
	
l5263:	
;charge_mgr.c: 255: g_slotRefV[idx] = slot_v;
	clrc
	rlf	(Route_DetectLi@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Route_DetectLi@slot_v),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	(Route_DetectLi@slot_v+1),w
	movwf	indf
	goto	l5257
	line	258
	
l5267:	
;charge_mgr.c: 257: }
;charge_mgr.c: 258: g_ovCnt[idx] = 0;
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	259
	
l5269:	
;charge_mgr.c: 259: g_detectLowCnt[idx] = 0;
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	260
	
l5271:	
;charge_mgr.c: 260: return st;
	movf	(Route_DetectLi@st),w
	line	261
	
l603:	
	return
	opt stack 0
GLOBAL	__end_of_Route_DetectLi
	__end_of_Route_DetectLi:
	signat	_Route_DetectLi,8313
	global	_Get_Vcc

;; *************** function _Get_Vcc *****************
;; Defined at:
;;		line 81 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   17[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  2   94[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/900
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;; This function is called by:
;;		_main
;;		_Detect_Classify
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	line	81
global __ptext11
__ptext11:	;psect for function _Get_Vcc
psect	text11
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	81
	global	__size_of_Get_Vcc
	__size_of_Get_Vcc	equ	__end_of_Get_Vcc-_Get_Vcc
	
_Get_Vcc:	
;incstack = 0
	opt	stack 3
; Regs used in _Get_Vcc: [wreg+status,2+status,0+pclath+cstack]
	line	83
	
l5225:	
;charge_mgr.c: 83: if(0xA5 == ADC_Sample(31, 0))
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u7961
	goto	u7960
u7961:
	goto	l564
u7960:
	line	85
	
l5227:	
;charge_mgr.c: 84: {
;charge_mgr.c: 85: unsigned long pt = (4096UL * 1200UL) / adresult;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Get_Vcc@pt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Get_Vcc@pt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Get_Vcc@pt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Get_Vcc@pt)

	line	86
	
l5229:	
;charge_mgr.c: 86: g_vcc_mv = (unsigned int)pt;
	movf	(Get_Vcc@pt+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(Get_Vcc@pt),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv)^080h
	line	89
	
l564:	
	return
	opt stack 0
GLOBAL	__end_of_Get_Vcc
	__end_of_Get_Vcc:
	signat	_Get_Vcc,90
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 142 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2    2[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         2       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	line	142
global __ptext12
__ptext12:	;psect for function _Detect_BatteryType
psect	text12
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	142
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 4
; Regs used in _Detect_BatteryType: [wreg]
	line	144
	
l5383:	
;charge_mgr.c: 144: if(voltage >= 3990)
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u8161
	goto	u8160
u8161:
	goto	l5389
u8160:
	line	145
	
l5385:	
;charge_mgr.c: 145: return 0;
	movlw	low(0)
	goto	l587
	line	146
	
l5389:	
;charge_mgr.c: 146: if(voltage < 500)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u8171
	goto	u8170
u8171:
	goto	l5395
u8170:
	goto	l5385
	line	161
	
l5395:	
;charge_mgr.c: 161: if(voltage >= 1015 && voltage < 3990)
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u8181
	goto	u8180
u8181:
	goto	l5403
u8180:
	
l5397:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u8191
	goto	u8190
u8191:
	goto	l5403
u8190:
	line	162
	
l5399:	
;charge_mgr.c: 162: return 5;
	movlw	low(05h)
	goto	l587
	line	167
	
l5403:	
;charge_mgr.c: 167: if(voltage >= 500 && voltage < 3990)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u8201
	goto	u8200
u8201:
	goto	l5385
u8200:
	
l5405:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u8211
	goto	u8210
u8211:
	goto	l5385
u8210:
	line	168
	
l5407:	
;charge_mgr.c: 168: return 1;
	movlw	low(01h)
	line	171
	
l587:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_Adc_Norm

;; *************** function _Adc_Norm *****************
;; Defined at:
;;		line 98 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  ch              1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  ch              1   20[BANK0 ] unsigned char 
;;  raw             2   21[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   17[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       3       0       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       6       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=0
	line	98
global __ptext13
__ptext13:	;psect for function _Adc_Norm
psect	text13
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	98
	global	__size_of_Adc_Norm
	__size_of_Adc_Norm	equ	__end_of_Adc_Norm-_Adc_Norm
	
_Adc_Norm:	
;incstack = 0
	opt	stack 3
; Regs used in _Adc_Norm: [wreg+status,2+status,0+pclath+cstack]
;Adc_Norm@ch stored from wreg
	movwf	(Adc_Norm@ch)
	line	101
	
l5365:	
;charge_mgr.c: 100: unsigned int raw;
;charge_mgr.c: 101: if(0xA5 != ADC_Sample(ch, 0))
	clrf	(ADC_Sample@adldo)
	movf	(Adc_Norm@ch),w
	fcall	_ADC_Sample
	xorlw	0A5h
	skipnz
	goto	u8141
	goto	u8140
u8141:
	goto	l5371
u8140:
	line	102
	
l5367:	
;charge_mgr.c: 102: return 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(?_Adc_Norm)
	clrf	(?_Adc_Norm+1)
	goto	l568
	line	103
	
l5371:	
;charge_mgr.c: 103: raw = adresult;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Adc_Norm@raw+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Adc_Norm@raw)
	line	104
	
l5373:	
;charge_mgr.c: 104: if(g_vcc_mv == 0)
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_vcc_mv)^080h),w
iorwf	((_g_vcc_mv+1)^080h),w
	btfss	status,2
	goto	u8151
	goto	u8150
u8151:
	goto	l5379
u8150:
	line	105
	
l5375:	
;charge_mgr.c: 105: return raw;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Adc_Norm@raw+1),w
	movwf	(?_Adc_Norm+1)
	movf	(Adc_Norm@raw),w
	movwf	(?_Adc_Norm)
	goto	l568
	line	106
	
l5379:	
;charge_mgr.c: 106: return (unsigned int)(((unsigned long)raw * (unsigned long)g_vcc_mv) / 5000UL);
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	movf	(Adc_Norm@raw),w
	movwf	(___lmul@multiplier)
	movf	(Adc_Norm@raw+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w
	movwf	(___lmul@multiplicand)
	movf	(_g_vcc_mv+1)^080h,w
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(?_Adc_Norm+1)
	movf	(0+(?___lldiv)),w
	movwf	(?_Adc_Norm)
	line	107
	
l568:	
	return
	opt stack 0
GLOBAL	__end_of_Adc_Norm
	__end_of_Adc_Norm:
	signat	_Adc_Norm,4218
	global	_Sense_Pins_Restore

;; *************** function _Sense_Pins_Restore *****************
;; Defined at:
;;		line 677 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	677
global __ptext14
__ptext14:	;psect for function _Sense_Pins_Restore
psect	text14
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	677
	global	__size_of_Sense_Pins_Restore
	__size_of_Sense_Pins_Restore	equ	__end_of_Sense_Pins_Restore-_Sense_Pins_Restore
	
_Sense_Pins_Restore:	
;incstack = 0
	opt	stack 5
; Regs used in _Sense_Pins_Restore: [wreg+status,2+status,0]
	line	679
	
l5849:	
;main.c: 679: TRISA |= 0xF0;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(133)^080h,f	;volatile
	line	680
;main.c: 680: TRISB |= 0x30;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(5),f	;volatile
	line	681
;main.c: 681: TRISD |= 0xF0;
	movlw	low(0F0h)
	bsf	status, 6	;RP1=1, select bank2
	iorwf	(276)^0100h,f	;volatile
	line	682
;main.c: 682: TRISC |= 0x07;
	movlw	low(07h)
	iorwf	(261)^0100h,f	;volatile
	line	683
	
l5851:	
;main.c: 683: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	684
	
l5853:	
;main.c: 684: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	685
	
l5855:	
;main.c: 685: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	686
	
l5857:	
;main.c: 686: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	687
	
l456:	
	return
	opt stack 0
GLOBAL	__end_of_Sense_Pins_Restore
	__end_of_Sense_Pins_Restore:
	signat	_Sense_Pins_Restore,89
	global	_Sense_Pins_AllSink

;; *************** function _Sense_Pins_AllSink *****************
;; Defined at:
;;		line 695 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/900
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=0
	line	695
global __ptext15
__ptext15:	;psect for function _Sense_Pins_AllSink
psect	text15
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	695
	global	__size_of_Sense_Pins_AllSink
	__size_of_Sense_Pins_AllSink	equ	__end_of_Sense_Pins_AllSink-_Sense_Pins_AllSink
	
_Sense_Pins_AllSink:	
;incstack = 0
	opt	stack 5
; Regs used in _Sense_Pins_AllSink: [wreg+status,2+status,0]
	line	698
	
l5859:	
;main.c: 698: ANSEL0 &= 0x0F; TRISA &= 0x0F; RA4 = 0; RA5 = 0; RA6 = 0; RA7 = 0;
	movlw	low(0Fh)
	bsf	status, 5	;RP0=1, select bank1
	andwf	(147)^080h,f	;volatile
	movlw	low(0Fh)
	andwf	(133)^080h,f	;volatile
	
l5861:	
	bcf	(1076/8)^080h,(1076)&7	;volatile
	
l5863:	
	bcf	(1077/8)^080h,(1077)&7	;volatile
	
l5865:	
	bcf	(1078/8)^080h,(1078)&7	;volatile
	
l5867:	
	bcf	(1079/8)^080h,(1079)&7	;volatile
	line	700
;main.c: 700: ANSEL1 &= 0xCF; TRISB &= 0xCF; RB4 = 0; RB5 = 0;
	movlw	low(0CFh)
	andwf	(148)^080h,f	;volatile
	movlw	low(0CFh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(5),f	;volatile
	
l5869:	
	bcf	(52/8),(52)&7	;volatile
	
l5871:	
	bcf	(53/8),(53)&7	;volatile
	line	702
;main.c: 702: ANSEL3 &= 0xC3; TRISD &= 0xC3; RD2 = 0; RD3 = 0; RD4 = 0; RD5 = 0;
	movlw	low(0C3h)
	bsf	status, 5	;RP0=1, select bank1
	andwf	(140)^080h,f	;volatile
	movlw	low(0C3h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	andwf	(276)^0100h,f	;volatile
	
l5873:	
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	
l5875:	
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	
l5877:	
	bcf	(2108/8)^0100h,(2108)&7	;volatile
	
l5879:	
	bcf	(2109/8)^0100h,(2109)&7	;volatile
	line	704
;main.c: 704: ANSEL2 &= 0xFC; TRISC &= 0xFC; RC0 = 0; RC1 = 0;
	movlw	low(0FCh)
	andwf	(265)^0100h,f	;volatile
	movlw	low(0FCh)
	andwf	(261)^0100h,f	;volatile
	
l5881:	
	bcf	(2096/8)^0100h,(2096)&7	;volatile
	
l5883:	
	bcf	(2097/8)^0100h,(2097)&7	;volatile
	line	705
	
l459:	
	return
	opt stack 0
GLOBAL	__end_of_Sense_Pins_AllSink
	__end_of_Sense_Pins_AllSink:
	signat	_Sense_Pins_AllSink,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 109 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   21[BANK0 ] unsigned long 
;;  temp_x10        2   27[BANK0 ] unsigned int 
;;  ntcVal          2   25[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2  102[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/900
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	109
global __ptext16
__ptext16:	;psect for function _Read_Temperature
psect	text16
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	109
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 4
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	114
	
l6841:	
;charge_mgr.c: 111: unsigned int ntcVal;
;charge_mgr.c: 112: unsigned int temp_x10;
;charge_mgr.c: 114: test_adc = ADC_Sample(18, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_test_adc)^080h
	line	115
	
l6843:	
;charge_mgr.c: 115: if(0xA5 != test_adc)
		movlw	165
	xorwf	((_test_adc)^080h),w
	btfsc	status,2
	goto	u11191
	goto	u11190
u11191:
	goto	l6847
u11190:
	goto	l573
	line	118
	
l6847:	
;charge_mgr.c: 118: ntcVal = adresult;
	movf	(_adresult+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Read_Temperature@ntcVal+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Read_Temperature@ntcVal)
	line	119
;charge_mgr.c: 119: if(ntcVal < 100 || ntcVal > 3996)
	movlw	0
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u11201
	goto	u11200
u11201:
	goto	l573
u11200:
	
l6849:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u11211
	goto	u11210
u11211:
	goto	l6851
u11210:
	goto	l573
	line	124
	
l6851:	
;charge_mgr.c: 122: {
;charge_mgr.c: 123: unsigned long rt;
;charge_mgr.c: 124: rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	010h
	movwf	(___lldiv@divisor+1)
	movlw	0
	movwf	(___lldiv@divisor)

	movf	(Read_Temperature@ntcVal),w
	movwf	((??_Read_Temperature+0)+0)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((??_Read_Temperature+0)+0+1)
	clrf	((??_Read_Temperature+0)+0+2)
	clrf	((??_Read_Temperature+0)+0+3)
	movf	0+(??_Read_Temperature+0)+0,w
	subwf	(___lldiv@divisor),f
	movf	1+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)+0,w
	goto	u11225
	goto	u11226
u11225:
	subwf	(___lldiv@divisor+1),f
u11226:
	movf	2+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)+0,w
	goto	u11227
	goto	u11228
u11227:
	subwf	(___lldiv@divisor+2),f
u11228:
	movf	3+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)+0,w
	goto	u11229
	goto	u11220
u11229:
	subwf	(___lldiv@divisor+3),f
u11220:

	movf	(Read_Temperature@ntcVal),w
	movwf	(___lmul@multiplier)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	027h
	movwf	(___lmul@multiplicand+1)
	movlw	010h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Read_Temperature@rt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Read_Temperature@rt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@rt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@rt)

	line	125
	
l6853:	
;charge_mgr.c: 125: if(rt >= 10000UL)
		movf	(Read_Temperature@rt+3),w
	btfss	status,2
	goto	u11230
	movf	(Read_Temperature@rt+2),w
	btfss	status,2
	goto	u11230
	movlw	39
	subwf	(Read_Temperature@rt+1),w
	skipz
	goto	u11233
	movlw	16
	subwf	(Read_Temperature@rt),w
	skipz
	goto	u11233
u11233:
	btfss	status,0
	goto	u11231
	goto	u11230

u11231:
	goto	l6859
u11230:
	line	126
	
l6855:	
;charge_mgr.c: 126: temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l6857:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0F0h
	movwf	((??_Read_Temperature+0)+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+3)
	movf	(Read_Temperature@rt),w
	addwf	(??_Read_Temperature+0)+0,f
	movf	(Read_Temperature@rt+1),w
	skipnc
	incfsz	(Read_Temperature@rt+1),w
	goto	u11240
	goto	u11241
u11240:
	addwf	(??_Read_Temperature+0)+1,f
u11241:
	movf	(Read_Temperature@rt+2),w
	skipnc
	incfsz	(Read_Temperature@rt+2),w
	goto	u11242
	goto	u11243
u11242:
	addwf	(??_Read_Temperature+0)+2,f
u11243:
	movf	(Read_Temperature@rt+3),w
	skipnc
	incf	(Read_Temperature@rt+3),w
	addwf	(??_Read_Temperature+0)+3,f
	movf	3+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+3)
	movf	2+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+2)
	movf	1+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+1)
	movf	0+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier)

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(0+(?___lldiv)),w
	subwf	(Read_Temperature@temp_x10),f
	movf	(1+(?___lldiv)),w
	skipc
	decf	(Read_Temperature@temp_x10+1),f
	subwf	(Read_Temperature@temp_x10+1),f
	goto	l6863
	line	128
	
l6859:	
;charge_mgr.c: 127: else
;charge_mgr.c: 128: temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0
	movwf	(___lmul@multiplier+3)
	movlw	0
	movwf	(___lmul@multiplier+2)
	movlw	027h
	movwf	(___lmul@multiplier+1)
	movlw	010h
	movwf	(___lmul@multiplier)

	movf	(Read_Temperature@rt),w
	subwf	(___lmul@multiplier),f
	movf	(Read_Temperature@rt+1),w
	skipc
	incfsz	(Read_Temperature@rt+1),w
	goto	u11255
	goto	u11256
u11255:
	subwf	(___lmul@multiplier+1),f
u11256:
	movf	(Read_Temperature@rt+2),w
	skipc
	incfsz	(Read_Temperature@rt+2),w
	goto	u11257
	goto	u11258
u11257:
	subwf	(___lmul@multiplier+2),f
u11258:
	movf	(Read_Temperature@rt+3),w
	skipc
	incfsz	(Read_Temperature@rt+3),w
	goto	u11259
	goto	u11250
u11259:
	subwf	(___lmul@multiplier+3),f
u11250:

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10)
	
l6861:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10),f
	skipnc
	incf	(Read_Temperature@temp_x10+1),f
	line	129
	
l6863:	
;charge_mgr.c: 129: if(temp_x10 < 100U) temp_x10 = 100U;
	movlw	0
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipnc
	goto	u11261
	goto	u11260
u11261:
	goto	l579
u11260:
	
l6865:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l579:	
	line	130
;charge_mgr.c: 130: if(temp_x10 > 750U) temp_x10 = 750U;
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipc
	goto	u11271
	goto	u11270
u11271:
	goto	l580
u11270:
	
l6867:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)
	movlw	02h
	movwf	((Read_Temperature@temp_x10))+1
	
l580:	
	line	133
;charge_mgr.c: 131: }
;charge_mgr.c: 133: g_temperature = temp_x10;
	movf	(Read_Temperature@temp_x10+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_temperature+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(Read_Temperature@temp_x10),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_temperature)^080h
	line	134
	
l6869:	
;charge_mgr.c: 134: if((temp_x10 / 10U) >= 60)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bcf	status, 5	;RP0=0, select bank0
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u11281
	goto	u11280
u11281:
	goto	l6873
u11280:
	line	135
	
l6871:	
;charge_mgr.c: 135: g_tempProtect = 1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	incf	(_g_tempProtect)^080h,f
	goto	l573
	line	136
	
l6873:	
;charge_mgr.c: 136: else if((temp_x10 / 10U) <= 50)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bcf	status, 5	;RP0=0, select bank0
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u11291
	goto	u11290
u11291:
	goto	l573
u11290:
	line	137
	
l6875:	
;charge_mgr.c: 137: g_tempProtect = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	line	140
	
l573:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 500 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  d               2   46[BANK0 ] int 
;;  t               1   45[BANK0 ] unsigned char 
;;  bat_mv_long     4   40[BANK0 ] unsigned long 
;;  tc              1   44[BANK0 ] unsigned char 
;;  vx_mv           4   34[BANK0 ] unsigned long 
;;  v               2   32[BANK0 ] unsigned int 
;;  s               1   29[BANK0 ] unsigned char 
;;  pt              4   25[BANK0 ] unsigned long 
;;  vcc_mv          2   38[BANK0 ] unsigned int 
;;  i               1   48[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/900
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      28       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      32       0       0       0
;;Total ram usage:       32 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	500
global __ptext17
__ptext17:	;psect for function _Print_SystemStatus
psect	text17
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	500
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 3
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	505
	
l5669:	
;main.c: 502: unsigned char i;
;main.c: 503: unsigned int vcc_mv;
;main.c: 505: uart_send_string("\r\n== L1211 12CH CHARGER ");
	movlw	low(((STR_4)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	506
;main.c: 506: uart_send_string("V60W");
	movlw	low(((STR_5)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	507
;main.c: 507: uart_send_string(" ==\r\n");
	movlw	low(((STR_6)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	510
	
l5671:	
;main.c: 510: if(0xA5 == ADC_Sample(31, 0))
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u8491
	goto	u8490
u8491:
	goto	l5677
u8490:
	line	512
	
l5673:	
;main.c: 511: {
;main.c: 512: unsigned long pt = (4096UL * 1200UL) / adresult;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt)

	line	513
	
l5675:	
;main.c: 513: vcc_mv = (unsigned int)pt;
	movf	(Print_SystemStatus@pt+1),w
	movwf	(Print_SystemStatus@vcc_mv+1)
	movf	(Print_SystemStatus@pt),w
	movwf	(Print_SystemStatus@vcc_mv)
	line	514
;main.c: 514: }
	goto	l413
	line	516
	
l5677:	
;main.c: 515: else
;main.c: 516: vcc_mv = 5000;
	movlw	088h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Print_SystemStatus@vcc_mv)
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv))+1
	
l413:	
	line	518
;main.c: 518: g_vcc_mv = vcc_mv;
	movf	(Print_SystemStatus@vcc_mv+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(Print_SystemStatus@vcc_mv),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv)^080h
	line	520
	
l5679:	
;main.c: 520: uart_send_string("VCC=");
	movlw	low(((STR_7)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	521
	
l5681:	
;main.c: 521: uart_send_number(vcc_mv);
	movf	(Print_SystemStatus@vcc_mv+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@vcc_mv),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	522
	
l5683:	
;main.c: 522: uart_send_string("mV T=");
	movlw	low(((STR_8)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	523
	
l5685:	
;main.c: 523: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature)^080h,w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_SystemStatus$771+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_Print_SystemStatus$771)
	
l5687:	
;main.c: 523: uart_send_number(g_temperature / 10U);
	movf	(_Print_SystemStatus$771+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$771),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	524
	
l5689:	
;main.c: 524: uart_send_string(".");
	movlw	low(((STR_9)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	525
	
l5691:	
;main.c: 525: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature)^080h,w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_SystemStatus$772+1)
	movf	(0+(?___lwmod)),w
	movwf	(_Print_SystemStatus$772)
	
l5693:	
;main.c: 525: uart_send_number(g_temperature % 10U);
	movf	(_Print_SystemStatus$772+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$772),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	526
	
l5695:	
;main.c: 526: uart_send_string("C TOKEN=");
	movlw	low(((STR_10)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	527
	
l5697:	
;main.c: 527: uart_send_number(g_detectOwner == 0xFF ? 0xFFU : (unsigned int)g_detectOwner);
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectOwner)^080h),w
	btfsc	status,2
	goto	u8501
	goto	u8500
u8501:
	goto	l5701
u8500:
	
l5699:	
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_SystemStatus$289)
	clrf	(_Print_SystemStatus$289+1)
	goto	l5703
	
l5701:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_SystemStatus$289)
	clrf	(_Print_SystemStatus$289+1)
	
l5703:	
	movf	(_Print_SystemStatus$289+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$289),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	528
	
l5705:	
;main.c: 528: uart_send_string("\r\n");
	movlw	low(((STR_11)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	533
	
l5707:	
;main.c: 533: for(i = 0; i < 12; i++)
	clrf	(Print_SystemStatus@i)
	line	538
	
l5713:	
;main.c: 537: {
;main.c: 538: unsigned int v = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Print_SystemStatus@v)
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)
	line	539
;main.c: 539: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Print_SystemStatus@s)
	line	541
	
l5715:	
;main.c: 541: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	542
	
l5717:	
;main.c: 542: uart_send_number((unsigned int)i + 1U);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@i),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	543
;main.c: 543: uart_send_char('=');
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	544
	
l5719:	
;main.c: 544: uart_send_number(v);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@v+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@v),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	550
	
l5721:	
;main.c: 549: {
;main.c: 550: unsigned long vx_mv = (unsigned long)v * 5000UL / 4096UL;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@v),w
	movwf	(___lmul@multiplier)
	movf	(Print_SystemStatus@v+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv)

	
l5723:	
	movlw	0Ch
u8515:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3),f
	rrf	(Print_SystemStatus@vx_mv+2),f
	rrf	(Print_SystemStatus@vx_mv+1),f
	rrf	(Print_SystemStatus@vx_mv),f
	addlw	-1
	skipz
	goto	u8515

	line	551
	
l5725:	
;main.c: 551: if(vx_mv + 200U >= 5000UL)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+0)+0)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+3)
	movf	(Print_SystemStatus@vx_mv),w
	addwf	(??_Print_SystemStatus+0)+0,f
	movf	(Print_SystemStatus@vx_mv+1),w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1),w
	goto	u8520
	goto	u8521
u8520:
	addwf	(??_Print_SystemStatus+0)+1,f
u8521:
	movf	(Print_SystemStatus@vx_mv+2),w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2),w
	goto	u8522
	goto	u8523
u8522:
	addwf	(??_Print_SystemStatus+0)+2,f
u8523:
	movf	(Print_SystemStatus@vx_mv+3),w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3),w
	addwf	(??_Print_SystemStatus+0)+3,f
		movf	(??_Print_SystemStatus+0)+3,w
	btfss	status,2
	goto	u8530
	movf	(??_Print_SystemStatus+0)+2,w
	btfss	status,2
	goto	u8530
	movlw	19
	subwf	(??_Print_SystemStatus+0)+1,w
	skipz
	goto	u8533
	movlw	136
	subwf	(??_Print_SystemStatus+0)+0,w
	skipz
	goto	u8533
u8533:
	btfss	status,0
	goto	u8531
	goto	u8530

u8531:
	goto	l5729
u8530:
	line	553
	
l5727:	
;main.c: 552: {
;main.c: 553: uart_send_string(" OPEN");
	movlw	low(((STR_12)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	554
;main.c: 554: }
	goto	l5741
	line	557
	
l5729:	
;main.c: 555: else
;main.c: 556: {
;main.c: 557: unsigned long bat_mv_long = 124UL * vx_mv + 206UL * 5000UL;
	movf	(Print_SystemStatus@vx_mv+3),w
	movwf	(___lmul@multiplier+3)
	movf	(Print_SystemStatus@vx_mv+2),w
	movwf	(___lmul@multiplier+2)
	movf	(Print_SystemStatus@vx_mv+1),w
	movwf	(___lmul@multiplier+1)
	movf	(Print_SystemStatus@vx_mv),w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+3)
	movf	(2+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+2)
	movf	(1+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+1)
	movf	(0+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long)

	
l5731:	
	movlw	070h
	addwf	(Print_SystemStatus@bat_mv_long),f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Print_SystemStatus@bat_mv_long+1),f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Print_SystemStatus@bat_mv_long+2),f
	movlw	0
	skipnc
movlw 1
	addwf	(Print_SystemStatus@bat_mv_long+3),f
	line	558
	
l5733:	
;main.c: 558: bat_mv_long = (bat_mv_long + 1000UL/2UL) / 1000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Print_SystemStatus+0)+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+3)
	movf	(Print_SystemStatus@bat_mv_long),w
	addwf	(??_Print_SystemStatus+0)+0,f
	movf	(Print_SystemStatus@bat_mv_long+1),w
	skipnc
	incfsz	(Print_SystemStatus@bat_mv_long+1),w
	goto	u8540
	goto	u8541
u8540:
	addwf	(??_Print_SystemStatus+0)+1,f
u8541:
	movf	(Print_SystemStatus@bat_mv_long+2),w
	skipnc
	incfsz	(Print_SystemStatus@bat_mv_long+2),w
	goto	u8542
	goto	u8543
u8542:
	addwf	(??_Print_SystemStatus+0)+2,f
u8543:
	movf	(Print_SystemStatus@bat_mv_long+3),w
	skipnc
	incf	(Print_SystemStatus@bat_mv_long+3),w
	addwf	(??_Print_SystemStatus+0)+3,f
	movf	3+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+3)
	movf	(2+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+2)
	movf	(1+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+1)
	movf	(0+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long)

	line	559
	
l5735:	
;main.c: 559: uart_send_string(" BAT(");
	movlw	low(((STR_13)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	560
	
l5737:	
;main.c: 560: uart_send_number((unsigned int)bat_mv_long);
	movf	(Print_SystemStatus@bat_mv_long+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@bat_mv_long),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	561
	
l5739:	
;main.c: 561: uart_send_string("mV)");
	movlw	low(((STR_14)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	566
	
l5741:	
;main.c: 562: }
;main.c: 563: }
;main.c: 566: uart_send_char(' ');
	movlw	low(020h)
	fcall	_uart_send_char
	line	567
;main.c: 567: switch(s)
	goto	l5797
	line	569
	
l5743:	
	movlw	low(((STR_15)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5799
	line	571
	
l5745:	
;main.c: 571: uart_send_string("[DET]");
	movlw	low(((STR_16)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	572
	
l5747:	
;main.c: 572: if(g_slotRefV[i] > 0U)
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	((??_Print_SystemStatus+0)+0),w
iorwf	((??_Print_SystemStatus+0)+1),w
	btfsc	status,2
	goto	u8551
	goto	u8550
u8551:
	goto	l5799
u8550:
	line	574
	
l5749:	
;main.c: 573: {
;main.c: 574: uart_send_string(" ref=");
	movlw	low(((STR_17)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	575
	
l5751:	
;main.c: 575: uart_send_number(g_slotRefV[i]);
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(uart_send_number@num)
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	goto	l5799
	line	578
	
l5753:	
	movlw	low(((STR_18)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5799
	line	579
	
l5755:	
	movlw	low(((STR_19)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5799
	line	580
	
l5757:	
	movlw	low(((STR_20)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5799
	line	581
	
l5759:	
	movlw	low(((STR_21)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5799
	line	582
	
l5761:	
	movlw	low(((STR_22)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5799
	line	585
	
l5763:	
;main.c: 584: {
;main.c: 585: unsigned char t = g_slot[(unsigned char)(i)].type;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Print_SystemStatus@t)
	line	586
	
l5765:	
;main.c: 586: if(t == 2 || t == 3)
		movlw	2
	xorwf	((Print_SystemStatus@t)),w
	btfsc	status,2
	goto	u8561
	goto	u8560
u8561:
	goto	l5769
u8560:
	
l5767:	
		movlw	3
	xorwf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u8571
	goto	u8570
u8571:
	goto	l5771
u8570:
	line	587
	
l5769:	
;main.c: 587: uart_send_string("[Dry/NiMH ERR]");
	movlw	low(((STR_23)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5781
	line	588
	
l5771:	
;main.c: 588: else if(t == 1)
		decf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u8581
	goto	u8580
u8581:
	goto	l5775
u8580:
	line	589
	
l5773:	
;main.c: 589: uart_send_string("[Li-ion ERR]");
	movlw	low(((STR_24)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5781
	line	590
	
l5775:	
;main.c: 590: else if(t == 6)
		movlw	6
	xorwf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u8591
	goto	u8590
u8591:
	goto	l5779
u8590:
	line	591
	
l5777:	
;main.c: 591: uart_send_string("[Linear Li ERR]");
	movlw	low(((STR_25)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5781
	line	593
	
l5779:	
;main.c: 592: else
;main.c: 593: uart_send_string("[ERR]");
	movlw	low(((STR_26)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	594
	
l5781:	
;main.c: 594: if(g_slotRefV[i] > 0U)
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	((??_Print_SystemStatus+0)+0),w
iorwf	((??_Print_SystemStatus+0)+1),w
	btfsc	status,2
	goto	u8601
	goto	u8600
u8601:
	goto	l5799
u8600:
	line	596
	
l5783:	
;main.c: 595: {
;main.c: 596: uart_send_string(" ref=");
	movlw	low(((STR_27)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5751
	line	601
	
l5787:	
	movlw	low(((STR_28)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5799
	line	603
	
l5789:	
;main.c: 603: uart_send_string("[DIO]");
	movlw	low(((STR_29)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	604
;main.c: 604: uart_send_string(" pre=");
	movlw	low(((STR_30)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	605
	
l5791:	
;main.c: 605: uart_send_number(g_impData & 0x0FFFU);
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(uart_send_number@num)
	fcall	_uart_send_number
	line	606
;main.c: 606: break;
	goto	l5799
	line	607
	
l5793:	
	movlw	low(((STR_31)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l5799
	line	567
	
l5797:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@s),w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l5743
	xorlw	1^0	; case 1
	skipnz
	goto	l5745
	xorlw	2^1	; case 2
	skipnz
	goto	l5753
	xorlw	3^2	; case 3
	skipnz
	goto	l5755
	xorlw	4^3	; case 4
	skipnz
	goto	l5757
	xorlw	5^4	; case 5
	skipnz
	goto	l5759
	xorlw	6^5	; case 6
	skipnz
	goto	l5761
	xorlw	7^6	; case 7
	skipnz
	goto	l5763
	xorlw	8^7	; case 8
	skipnz
	goto	l5787
	xorlw	9^8	; case 9
	skipnz
	goto	l5789
	goto	l5793
	opt asmopt_pop

	line	611
	
l5799:	
;main.c: 611: uart_send_string(" ct=");
	movlw	low(((STR_32)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	612
	
l5801:	
;main.c: 612: uart_send_number(g_slot[(unsigned char)(i)].chargeTimer);
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	613
	
l5803:	
;main.c: 613: uart_send_string(" ty=");
	movlw	low(((STR_33)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	614
;main.c: 614: uart_send_number(g_slot[(unsigned char)(i)].type);
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	617
	
l5805:	
;main.c: 617: if(g_diodeTraceCnt > 0U && g_diodeTraceSlot == i)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	((_g_diodeTraceCnt)^080h),w
	btfsc	status,2
	goto	u8611
	goto	u8610
u8611:
	goto	l5841
u8610:
	
l5807:	
	movf	(_g_diodeTraceSlot)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Print_SystemStatus@i),w
	skipz
	goto	u8621
	goto	u8620
u8621:
	goto	l5841
u8620:
	line	620
	
l5809:	
;main.c: 618: {
;main.c: 619: unsigned char tc;
;main.c: 620: uart_send_string(" tr=");
	movlw	low(((STR_34)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_34)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	621
	
l5811:	
;main.c: 621: for(tc = 0; tc < g_diodeTraceCnt; tc++)
	clrf	(Print_SystemStatus@tc)
	goto	l5835
	line	623
	
l5813:	
;main.c: 622: {
;main.c: 623: signed int d = (signed int)g_diodeTrace[tc] - 128;
	movf	(Print_SystemStatus@tc),w
	addlw	low(_g_diodeTrace|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(Print_SystemStatus@d)
	clrf	(Print_SystemStatus@d+1)
	
l5815:	
	movlw	-128
	addwf	(Print_SystemStatus@d),f
	skipc
	decf	(Print_SystemStatus@d+1),f
	line	624
	
l5817:	
;main.c: 624: if(d < 0)
	btfss	(Print_SystemStatus@d+1),7
	goto	u8631
	goto	u8630
u8631:
	goto	l5823
u8630:
	line	626
	
l5819:	
;main.c: 625: {
;main.c: 626: uart_send_char('-');
	movlw	low(02Dh)
	fcall	_uart_send_char
	line	627
	
l5821:	
;main.c: 627: d = -d;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	comf	(Print_SystemStatus@d),f
	comf	(Print_SystemStatus@d+1),f
	incf	(Print_SystemStatus@d),f
	skipnz
	incf	(Print_SystemStatus@d+1),f
	line	628
;main.c: 628: }
	goto	l5827
	line	629
	
l5823:	
;main.c: 629: else if(d > 0)
	movf	(Print_SystemStatus@d+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u8645
	movlw	01h
	subwf	(Print_SystemStatus@d),w
u8645:

	skipc
	goto	u8641
	goto	u8640
u8641:
	goto	l5827
u8640:
	line	630
	
l5825:	
;main.c: 630: uart_send_char('+');
	movlw	low(02Bh)
	fcall	_uart_send_char
	line	631
	
l5827:	
;main.c: 631: uart_send_number((unsigned int)d * 4U);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@d+1),w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	(Print_SystemStatus@d),w
	movwf	(??_Print_SystemStatus+0)+0
	clrc
	rlf	(??_Print_SystemStatus+0)+0,f
	rlf	(??_Print_SystemStatus+0)+1,f
	clrc
	rlf	(??_Print_SystemStatus+0)+0,f
	rlf	(??_Print_SystemStatus+0)+1,f
	movf	0+(??_Print_SystemStatus+0)+0,w
	movwf	(uart_send_number@num)
	movf	1+(??_Print_SystemStatus+0)+0,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	632
	
l5829:	
;main.c: 632: if(tc + 1U < g_diodeTraceCnt)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_diodeTraceCnt)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Print_SystemStatus+0)+0
	clrf	(??_Print_SystemStatus+0)+0+1
	movf	(Print_SystemStatus@tc),w
	addlw	low(01h)
	movwf	(??_Print_SystemStatus+2)+0
	movlw	high(01h)
	skipnc
	movlw	(high(01h)+1)&0ffh
	movwf	((??_Print_SystemStatus+2)+0)+1
	movf	1+(??_Print_SystemStatus+0)+0,w
	subwf	1+(??_Print_SystemStatus+2)+0,w
	skipz
	goto	u8655
	movf	0+(??_Print_SystemStatus+0)+0,w
	subwf	0+(??_Print_SystemStatus+2)+0,w
u8655:
	skipnc
	goto	u8651
	goto	u8650
u8651:
	goto	l5833
u8650:
	line	633
	
l5831:	
;main.c: 633: uart_send_char(',');
	movlw	low(02Ch)
	fcall	_uart_send_char
	line	621
	
l5833:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Print_SystemStatus@tc),f
	
l5835:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_diodeTraceCnt)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Print_SystemStatus@tc),w
	skipc
	goto	u8661
	goto	u8660
u8661:
	goto	l5813
u8660:
	line	635
	
l5837:	
;main.c: 634: }
;main.c: 635: g_diodeTraceCnt = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_diodeTraceCnt)^080h
	line	636
	
l5839:	
;main.c: 636: g_diodeTraceSlot = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_diodeTraceSlot)^080h
	line	640
	
l5841:	
;main.c: 637: }
;main.c: 640: uart_send_string("\r\n");
	movlw	low(((STR_35)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_35)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	533
	
l5843:	
	incf	(Print_SystemStatus@i),f
	
l5845:	
	movlw	low(0Ch)
	subwf	(Print_SystemStatus@i),w
	skipc
	goto	u8671
	goto	u8670
u8671:
	goto	l5713
u8670:
	line	643
	
l5847:	
;main.c: 642: }
;main.c: 643: uart_send_string("\r\n");
	movlw	low(((STR_36)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_36)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	644
	
l453:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    2[COMMON] unsigned long 
;;  multiplicand    4    6[COMMON] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    0[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    2[COMMON] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         8       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       4       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Route_DetectLi
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext18
__ptext18:	;psect for function ___lmul
psect	text18
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 2
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l5163:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l912:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u7871
	goto	u7870
u7871:
	goto	l5167
u7870:
	line	122
	
l5165:	
	movf	(___lmul@multiplicand),w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7881
	addwf	(___lmul@product+1),f
u7881:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7882
	addwf	(___lmul@product+2),f
u7882:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7883
	addwf	(___lmul@product+3),f
u7883:

	line	123
	
l5167:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l5169:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u7891
	goto	u7890
u7891:
	goto	l912
u7890:
	line	128
	
l5171:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l915:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    4[BANK0 ] unsigned long 
;;  dividend        4    8[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   12[BANK0 ] unsigned long 
;;  counter         1   16[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    4[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      13       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Route_DetectLi
;;		_Slot_Charge_Ctrl
;;		_Get_Vcc
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext19
__ptext19:	;psect for function ___lldiv
psect	text19
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 4
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l5175:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l5177:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u7901
	goto	u7900
u7901:
	goto	l5197
u7900:
	line	16
	
l5179:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l5183
	line	18
	
l5181:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l5183:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u7911
	goto	u7910
u7911:
	goto	l5181
u7910:
	line	22
	
l5185:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l5187:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u7925
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u7925
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u7925
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u7925:
	skipc
	goto	u7921
	goto	u7920
u7921:
	goto	l5193
u7920:
	line	24
	
l5189:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l5191:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l5193:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l5195:	
	decfsz	(___lldiv@counter),f
	goto	u7931
	goto	u7930
u7931:
	goto	l5185
u7930:
	line	30
	
l5197:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l1187:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    2[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    1[BANK0 ] unsigned char 
;;  j               1    0[BANK0 ] unsigned char 
;;  adsum           4    3[BANK0 ] volatile unsigned long 
;;  ad_temp         2   11[BANK0 ] volatile unsigned int 
;;  admax           2    9[BANK0 ] volatile unsigned int 
;;  admin           2    7[BANK0 ] volatile unsigned int 
;;  i               1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/900
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      13       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Get_Vcc
;;		_Adc_Norm
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext20
__ptext20:	;psect for function _ADC_Sample
psect	text20
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(ADC_Sample@adch)
	line	51
	
l5097:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	52
	
l5099:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	67
	
l5101:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 67: if((!LDO_EN) && (adldo & 0x04))
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u7721
	goto	u7720
u7721:
	goto	l5107
u7720:
	
l5103:	
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u7731
	goto	u7730
u7731:
	goto	l5107
u7730:
	line	69
	
l5105:	
;adc_drv.c: 68: {
;adc_drv.c: 69: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	70
;adc_drv.c: 70: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??_ADC_Sample+0)+0),f
	u11387:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u11387
opt asmopt_pop

	line	71
;adc_drv.c: 71: }
	goto	l5109
	line	73
	
l5107:	
;adc_drv.c: 72: else
;adc_drv.c: 73: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	76
	
l5109:	
;adc_drv.c: 76: if(adch & 0x10)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(ADC_Sample@adch),(4)&7
	goto	u7741
	goto	u7740
u7741:
	goto	l488
u7740:
	line	78
	
l5111:	
;adc_drv.c: 77: {
;adc_drv.c: 78: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	79
	
l5113:	
;adc_drv.c: 79: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(ADC_Sample@adch),f
	line	80
;adc_drv.c: 80: }
	goto	l5115
	line	81
	
l488:	
	line	82
;adc_drv.c: 81: else
;adc_drv.c: 82: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	85
	
l5115:	
;adc_drv.c: 85: for(i = 0; i < 34; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@i)
	line	88
	
l5121:	
;adc_drv.c: 86: {
;adc_drv.c: 88: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(ADC_Sample@adch),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u7755:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u7755
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	89
	
l5123:	
;adc_drv.c: 89: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	6
movwf	((??_ADC_Sample+0)+0),f
	u11397:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u11397
	nop
opt asmopt_pop

	line	90
	
l5125:	
;adc_drv.c: 90: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	93
	
l5127:	
;adc_drv.c: 93: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	94
;adc_drv.c: 94: while(GODONE)
	goto	l492
	
l493:	
	line	96
;adc_drv.c: 95: {
;adc_drv.c: 96: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	97
;adc_drv.c: 97: if(0 == (--j))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u7761
	goto	u7760
u7761:
	goto	l492
u7760:
	line	102
	
l5129:	
;adc_drv.c: 98: {
;adc_drv.c: 102: return 0;
	movlw	low(0)
	goto	l495
	line	104
	
l492:	
	line	94
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u7771
	goto	u7770
u7771:
	goto	l493
u7770:
	line	107
	
l5133:	
;adc_drv.c: 103: }
;adc_drv.c: 104: }
;adc_drv.c: 107: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
l5135:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	110
	
l5137:	
;adc_drv.c: 110: if(0 == admax)
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u7781
	goto	u7780
u7781:
	goto	l5141
u7780:
	line	112
	
l5139:	
;adc_drv.c: 111: {
;adc_drv.c: 112: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	113
;adc_drv.c: 113: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	114
;adc_drv.c: 114: }
	goto	l498
	line	116
	
l5141:	
;adc_drv.c: 116: else if(ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u7795
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u7795:
	skipnc
	goto	u7791
	goto	u7790
u7791:
	goto	l5145
u7790:
	line	117
	
l5143:	
;adc_drv.c: 117: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	l498
	line	119
	
l5145:	
;adc_drv.c: 119: else if(ad_temp < admin)
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u7805
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u7805:
	skipnc
	goto	u7801
	goto	u7800
u7801:
	goto	l498
u7800:
	line	120
	
l5147:	
;adc_drv.c: 120: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	122
	
l498:	
;adc_drv.c: 122: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7811
	addwf	(ADC_Sample@adsum+1),f	;volatile
u7811:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7812
	addwf	(ADC_Sample@adsum+2),f	;volatile
u7812:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7813
	addwf	(ADC_Sample@adsum+3),f	;volatile
u7813:

	line	85
	
l5149:	
	incf	(ADC_Sample@i),f
	
l5151:	
	movlw	low(022h)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u7821
	goto	u7820
u7821:
	goto	l5121
u7820:
	line	126
	
l5153:	
;adc_drv.c: 123: }
;adc_drv.c: 126: adsum -= admax;
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u7835
	goto	u7836
u7835:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u7836:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u7837
	goto	u7838
u7837:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u7838:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u7839
	goto	u7830
u7839:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u7830:

	line	127
;adc_drv.c: 127: if(adsum >= admin)
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u7845
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u7845
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u7845
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u7845:
	skipc
	goto	u7841
	goto	u7840
u7841:
	goto	l502
u7840:
	line	128
	
l5155:	
;adc_drv.c: 128: adsum -= admin;
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u7855
	goto	u7856
u7855:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u7856:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u7857
	goto	u7858
u7857:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u7858:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u7859
	goto	u7850
u7859:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u7850:

	goto	l5157
	line	129
	
l502:	
	line	130
;adc_drv.c: 129: else
;adc_drv.c: 130: adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	132
	
l5157:	
;adc_drv.c: 132: adresult = adsum >> 5;
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u7865:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u7860:
	addlw	-1
	skipz
	goto	u7865
	movf	1+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_adresult+1)^080h
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)^080h
	line	136
	
l5159:	
;adc_drv.c: 136: return 0xA5;
	movlw	low(0A5h)
	line	137
	
l495:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 479 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	479
global __ptext21
__ptext21:	;psect for function _Print_NtcTemp
psect	text21
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	479
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 3
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	481
	
l5657:	
;main.c: 481: uart_send_string("NTC=");
	movlw	low(((STR_1)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	482
	
l5659:	
;main.c: 482: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature)^080h,w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_NtcTemp$769+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$769)
	
l5661:	
;main.c: 482: uart_send_number(g_temperature / 10U);
	movf	(_Print_NtcTemp$769+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$769),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	483
	
l5663:	
;main.c: 483: uart_send_string(".");
	movlw	low(((STR_2)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	484
	
l5665:	
;main.c: 484: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature)^080h,w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_NtcTemp$770+1)
	movf	(0+(?___lwmod)),w
	movwf	(_Print_NtcTemp$770)
;main.c: 484: uart_send_number(g_temperature % 10U);
	movf	(_Print_NtcTemp$770+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$770),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	485
	
l5667:	
;main.c: 485: uart_send_string("C\r\n");
	movlw	low(((STR_3)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	486
	
l409:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2    5[COMMON] PTR const unsigned char 
;;		 -> STR_38(10), STR_37(21), STR_36(3), STR_35(3), 
;;		 -> STR_34(5), STR_33(5), STR_32(5), STR_31(6), 
;;		 -> STR_30(6), STR_29(6), STR_28(6), STR_27(6), 
;;		 -> STR_26(6), STR_25(16), STR_24(13), STR_23(15), 
;;		 -> STR_22(7), STR_21(5), STR_20(5), STR_19(6), 
;;		 -> STR_18(6), STR_17(6), STR_16(6), STR_15(7), 
;;		 -> STR_14(4), STR_13(6), STR_12(6), STR_11(3), 
;;		 -> STR_10(9), STR_9(2), STR_8(6), STR_7(5), 
;;		 -> STR_6(6), STR_5(5), STR_4(25), STR_3(4), 
;;		 -> STR_2(2), STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         2       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_main
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
global __ptext22
__ptext22:	;psect for function _uart_send_string
psect	text22
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 4
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l5329:	
;uart_dbg.c: 63: while(*str != '\0')
	goto	l5335
	line	65
	
l5331:	
;uart_dbg.c: 64: {
;uart_dbg.c: 65: uart_send_char(*str++);
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	fcall	_uart_send_char
	
l5333:	
	incf	(uart_send_string@str),f
	skipnz
	incf	(uart_send_string@str+1),f
	line	66
# 66 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
clrwdt ;# 
psect	text22
	line	63
	
l5335:	
	movf	(uart_send_string@str+1),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u8101
	goto	u8100
u8101:
	goto	l5331
u8100:
	line	68
	
l519:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2    0[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    2[BANK0 ] unsigned char [6]
;;  j               1    9[BANK0 ] unsigned char 
;;  i               1    8[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      10       0       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext23
__ptext23:	;psect for function _uart_send_number
psect	text23
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l5337:	
;uart_dbg.c: 79: unsigned char buf[6];
;uart_dbg.c: 80: unsigned char i = 0;
	clrf	(uart_send_number@i)
	line	84
	
l5339:	
;uart_dbg.c: 81: unsigned char j;
;uart_dbg.c: 84: if(num == 0)
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u8111
	goto	u8110
u8111:
	goto	l5351
u8110:
	line	86
	
l5341:	
;uart_dbg.c: 85: {
;uart_dbg.c: 86: uart_send_char('0');
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l523
	line	93
	
l5345:	
;uart_dbg.c: 92: {
;uart_dbg.c: 93: buf[i++] = '0' + (num % 10);
	movf	(uart_send_number@i),w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwmod@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank0
	movwf	indf
	
l5347:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(uart_send_number@i),f
	line	94
	
l5349:	
;uart_dbg.c: 94: num /= 10;
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	movf	(0+(?___lwdiv)),w
	movwf	(uart_send_number@num)
	line	91
	
l5351:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u8121
	goto	u8120
u8121:
	goto	l5345
u8120:
	line	98
	
l5353:	
;uart_dbg.c: 95: }
;uart_dbg.c: 98: for(j = i; j > 0; j--)
	movf	(uart_send_number@i),w
	movwf	(uart_send_number@j)
	
l5355:	
	movf	((uart_send_number@j)),w
	btfss	status,2
	goto	u8131
	goto	u8130
u8131:
	goto	l5359
u8130:
	goto	l523
	line	99
	
l5359:	
;uart_dbg.c: 99: uart_send_char(buf[(unsigned char)(j - 1)]);
	movf	(uart_send_number@j),w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l5361:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decf	(uart_send_number@j),f
	goto	l5355
	line	100
	
l523:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1    3[COMMON] unsigned char 
;;  i               1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          1       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext24
__ptext24:	;psect for function _uart_send_char
psect	text24
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 4
; Regs used in _uart_send_char: [wreg+status,2+status,0]
;uart_send_char@c stored from wreg
	movwf	(uart_send_char@c)
	line	38
	
l5201:	
;uart_dbg.c: 37: unsigned char i;
;uart_dbg.c: 38: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	39
;uart_dbg.c: 39: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l5203:	
;uart_dbg.c: 40: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u11407:
decfsz	(??_uart_send_char+0)+0,f
	goto	u11407
	nop
opt asmopt_pop

	line	41
	
l5205:	
;uart_dbg.c: 41: for(i = 0; i < 8; i++)
	clrf	(uart_send_char@i)
	line	42
	
l509:	
	line	43
;uart_dbg.c: 42: {
;uart_dbg.c: 43: if(c & 0x01)
	btfss	(uart_send_char@c),(0)&7
	goto	u7941
	goto	u7940
u7941:
	goto	l511
u7940:
	line	44
	
l5211:	
;uart_dbg.c: 44: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l5213
	line	45
	
l511:	
	line	46
;uart_dbg.c: 45: else
;uart_dbg.c: 46: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l5213:	
;uart_dbg.c: 47: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u11417:
decfsz	(??_uart_send_char+0)+0,f
	goto	u11417
	nop
opt asmopt_pop

	line	48
	
l5215:	
;uart_dbg.c: 48: c >>= 1;
	clrc
	rrf	(uart_send_char@c),f
	line	41
	
l5217:	
	incf	(uart_send_char@i),f
	
l5219:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u7951
	goto	u7950
u7951:
	goto	l509
u7950:
	
l510:	
	line	50
;uart_dbg.c: 49: }
;uart_dbg.c: 50: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l5221:	
;uart_dbg.c: 51: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	138
movwf	((??_uart_send_char+0)+0),f
	u11427:
decfsz	(??_uart_send_char+0)+0,f
	goto	u11427
	nop
opt asmopt_pop

	line	52
	
l5223:	
;uart_dbg.c: 52: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l513:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] unsigned int 
;;  dividend        2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/900
;;		On exit  : 200/0
;;		Unchanged: 200/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         5       0       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext25
__ptext25:	;psect for function ___lwmod
psect	text25
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l5301:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u8061
	goto	u8060
u8061:
	goto	l5317
u8060:
	line	14
	
l5303:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l5307
	line	16
	
l5305:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l5307:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u8071
	goto	u8070
u8071:
	goto	l5305
u8070:
	line	20
	
l5309:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u8085
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u8085:
	skipc
	goto	u8081
	goto	u8080
u8081:
	goto	l5313
u8080:
	line	21
	
l5311:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l5313:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l5315:	
	decfsz	(___lwmod@counter),f
	goto	u8091
	goto	u8090
u8091:
	goto	l5309
u8090:
	line	25
	
l5317:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1250:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] unsigned int 
;;  dividend        2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    7[COMMON] unsigned int 
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/100
;;		On exit  : 200/0
;;		Unchanged: 200/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         3       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         7       0       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_Detect_Classify
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext26
__ptext26:	;psect for function ___lwdiv
psect	text26
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l5275:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l5277:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u8021
	goto	u8020
u8021:
	goto	l5297
u8020:
	line	16
	
l5279:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l5283
	line	18
	
l5281:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l5283:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u8031
	goto	u8030
u8031:
	goto	l5281
u8030:
	line	22
	
l5285:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l5287:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u8045
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u8045:
	skipc
	goto	u8041
	goto	u8040
u8041:
	goto	l5293
u8040:
	line	24
	
l5289:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l5291:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l5293:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l5295:	
	decfsz	(___lwdiv@counter),f
	goto	u8051
	goto	u8050
u8051:
	goto	l5285
u8050:
	line	30
	
l5297:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l1240:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	_Led_Display_Update

;; *************** function _Led_Display_Update *****************
;; Defined at:
;;		line 266 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	266
global __ptext27
__ptext27:	;psect for function _Led_Display_Update
psect	text27
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	266
	global	__size_of_Led_Display_Update
	__size_of_Led_Display_Update	equ	__end_of_Led_Display_Update-_Led_Display_Update
	
_Led_Display_Update:	
;incstack = 0
	opt	stack 5
; Regs used in _Led_Display_Update: []
	line	268
	
l889:	
	return
	opt stack 0
GLOBAL	__end_of_Led_Display_Update
	__end_of_Led_Display_Update:
	signat	_Led_Display_Update,89
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 1509 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    8[BANK0 ] unsigned int 
;;  s               1   19[BANK0 ] unsigned char 
;;  duty            2   16[BANK0 ] int 
;;  error           2   12[BANK0 ] int 
;;  adjust          2    2[BANK0 ] int 
;;  duty_initial    1   15[BANK0 ] unsigned char 
;;  duty_target     1   14[BANK0 ] unsigned char 
;;  maxV            2   10[BANK0 ] unsigned int 
;;  i               1   18[BANK0 ] unsigned char 
;;  preCount        1    7[BANK0 ] unsigned char 
;;  ccCount         1    6[BANK0 ] unsigned char 
;;  cvCount         1    5[BANK0 ] unsigned char 
;;  hasCharging     1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/900
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          0       2       0       0       0
;;      Totals:         0      20       0       0       0
;;Total ram usage:       20 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		___awdiv
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1509
global __ptext28
__ptext28:	;psect for function _CCCV_Control
psect	text28
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1509
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 4
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1512
	
l6719:	
;charge_mgr.c: 1511: unsigned char i;
;charge_mgr.c: 1512: unsigned char hasCharging = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	1513
;charge_mgr.c: 1513: unsigned int maxV = 0;
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	1514
;charge_mgr.c: 1514: unsigned char cvCount = 0;
	clrf	(CCCV_Control@cvCount)
	line	1515
;charge_mgr.c: 1515: unsigned char ccCount = 0;
	clrf	(CCCV_Control@ccCount)
	line	1516
;charge_mgr.c: 1516: unsigned char preCount = 0;
	clrf	(CCCV_Control@preCount)
	line	1519
	
l6721:	
;charge_mgr.c: 1519: if(g_vccProtect)
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u10931
	goto	u10930
u10931:
	goto	l6727
u10930:
	line	1521
	
l6723:	
;charge_mgr.c: 1520: {
;charge_mgr.c: 1521: if(g_vcc_mv >= 4600)
	movlw	011h
	subwf	(_g_vcc_mv+1)^080h,w
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv)^080h,w
	skipc
	goto	u10941
	goto	u10940
u10941:
	goto	l6731
u10940:
	line	1522
	
l6725:	
;charge_mgr.c: 1522: g_vccProtect = 0;
	clrf	(_g_vccProtect)^080h
	goto	l6731
	line	1526
	
l6727:	
;charge_mgr.c: 1524: else
;charge_mgr.c: 1525: {
;charge_mgr.c: 1526: if(g_vcc_mv < 4400)
	movlw	011h
	subwf	(_g_vcc_mv+1)^080h,w
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv)^080h,w
	skipnc
	goto	u10951
	goto	u10950
u10951:
	goto	l6731
u10950:
	line	1527
	
l6729:	
;charge_mgr.c: 1527: g_vccProtect = 1;
	clrf	(_g_vccProtect)^080h
	incf	(_g_vccProtect)^080h,f
	line	1531
	
l6731:	
;charge_mgr.c: 1528: }
;charge_mgr.c: 1531: if(g_tempProtect || g_vccProtect)
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u10961
	goto	u10960
u10961:
	goto	l6735
u10960:
	
l6733:	
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u10971
	goto	u10970
u10971:
	goto	l6739
u10970:
	line	1533
	
l6735:	
;charge_mgr.c: 1532: {
;charge_mgr.c: 1533: g_pwmDuty = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	1534
;charge_mgr.c: 1534: g_cvIntegral = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	l859
	line	1539
	
l6739:	
;charge_mgr.c: 1536: }
;charge_mgr.c: 1539: for(i = 0; i < 12; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(CCCV_Control@i)
	line	1541
	
l6745:	
;charge_mgr.c: 1540: {
;charge_mgr.c: 1541: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	1545
	
l6747:	
;charge_mgr.c: 1543: if(s == 2 || s == 3 ||
;charge_mgr.c: 1544: s == 4 || s == 5 ||
;charge_mgr.c: 1545: s == 8)
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u10981
	goto	u10980
u10981:
	goto	l864
u10980:
	
l6749:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u10991
	goto	u10990
u10991:
	goto	l864
u10990:
	
l6751:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u11001
	goto	u11000
u11001:
	goto	l864
u11000:
	
l6753:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u11011
	goto	u11010
u11011:
	goto	l864
u11010:
	
l6755:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u11021
	goto	u11020
u11021:
	goto	l862
u11020:
	
l864:	
	line	1547
;charge_mgr.c: 1546: {
;charge_mgr.c: 1547: hasCharging = 1;
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	1549
	
l6757:	
;charge_mgr.c: 1548: {
;charge_mgr.c: 1549: unsigned int vt = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	1550
	
l6759:	
;charge_mgr.c: 1550: if(vt > maxV) maxV = vt;
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u11035
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u11035:
	skipnc
	goto	u11031
	goto	u11030
u11031:
	goto	l6763
u11030:
	
l6761:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	1552
	
l6763:	
;charge_mgr.c: 1551: }
;charge_mgr.c: 1552: if(s == 5)
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u11041
	goto	u11040
u11041:
	goto	l6767
u11040:
	line	1553
	
l6765:	
;charge_mgr.c: 1553: cvCount++;
	incf	(CCCV_Control@cvCount),f
	line	1554
	
l6767:	
;charge_mgr.c: 1554: if(s == 4)
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u11051
	goto	u11050
u11051:
	goto	l6771
u11050:
	line	1555
	
l6769:	
;charge_mgr.c: 1555: ccCount++;
	incf	(CCCV_Control@ccCount),f
	line	1556
	
l6771:	
;charge_mgr.c: 1556: if(s == 3 || s == 2)
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u11061
	goto	u11060
u11061:
	goto	l6775
u11060:
	
l6773:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u11071
	goto	u11070
u11071:
	goto	l862
u11070:
	line	1557
	
l6775:	
;charge_mgr.c: 1557: preCount++;
	incf	(CCCV_Control@preCount),f
	line	1558
	
l862:	
	line	1539
	incf	(CCCV_Control@i),f
	
l6777:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u11081
	goto	u11080
u11081:
	goto	l6745
u11080:
	line	1562
	
l6779:	
;charge_mgr.c: 1558: }
;charge_mgr.c: 1559: }
;charge_mgr.c: 1562: if(!hasCharging)
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u11091
	goto	u11090
u11091:
	goto	l6785
u11090:
	goto	l6735
	line	1573
	
l6785:	
;charge_mgr.c: 1567: }
;charge_mgr.c: 1573: if(cvCount == 0)
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u11101
	goto	u11100
u11101:
	goto	l6815
u11100:
	line	1577
	
l6787:	
;charge_mgr.c: 1574: {
;charge_mgr.c: 1575: unsigned char duty_target, duty_initial;
;charge_mgr.c: 1577: if(ccCount > 0)
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u11111
	goto	u11110
u11111:
	goto	l6791
u11110:
	line	1580
	
l6789:	
;charge_mgr.c: 1578: {
;charge_mgr.c: 1580: duty_target = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	1581
;charge_mgr.c: 1581: duty_initial = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	1582
;charge_mgr.c: 1582: }
	goto	l6799
	line	1583
	
l6791:	
;charge_mgr.c: 1583: else if(preCount > 0)
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u11121
	goto	u11120
u11121:
	goto	l6795
u11120:
	line	1586
	
l6793:	
;charge_mgr.c: 1584: {
;charge_mgr.c: 1586: duty_target = 8;
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	1587
;charge_mgr.c: 1587: duty_initial = 5;
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	1588
;charge_mgr.c: 1588: }
	goto	l6799
	line	1593
	
l6795:	
;charge_mgr.c: 1589: else
;charge_mgr.c: 1590: {
;charge_mgr.c: 1593: g_pwmDuty = 25;
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	l859
	line	1597
	
l6799:	
;charge_mgr.c: 1595: }
;charge_mgr.c: 1597: if(g_pwmDuty < duty_initial)
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u11131
	goto	u11130
u11131:
	goto	l6807
u11130:
	line	1600
	
l6801:	
;charge_mgr.c: 1598: {
;charge_mgr.c: 1600: g_pwmDuty += 3;
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	1601
	
l6803:	
;charge_mgr.c: 1601: if(g_pwmDuty > duty_initial)
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u11141
	goto	u11140
u11141:
	goto	l859
u11140:
	line	1602
	
l6805:	
;charge_mgr.c: 1602: g_pwmDuty = duty_initial;
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	l859
	line	1604
	
l6807:	
	line	1607
	
l6809:	
;charge_mgr.c: 1605: {
;charge_mgr.c: 1607: g_pwmDuty = duty_target;
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	1608
;charge_mgr.c: 1608: }
	goto	l859
	line	1623
	
l6815:	
;charge_mgr.c: 1615: }
;charge_mgr.c: 1622: {
;charge_mgr.c: 1623: int error = (int)(3100) - (int)(maxV);
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	1626
;charge_mgr.c: 1626: g_cvIntegral += error * 1;
	movf	(CCCV_Control@error),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral)^080h,f
	skipnc
	incf	(_g_cvIntegral+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(CCCV_Control@error+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral+1)^080h,f
	line	1627
	
l6817:	
;charge_mgr.c: 1627: if(g_cvIntegral > 200)
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u11155
	movlw	0C9h
	subwf	(_g_cvIntegral)^080h,w
u11155:

	skipc
	goto	u11151
	goto	u11150
u11151:
	goto	l6821
u11150:
	line	1628
	
l6819:	
;charge_mgr.c: 1628: g_cvIntegral = 200;
	movlw	0C8h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	l6825
	line	1629
	
l6821:	
;charge_mgr.c: 1629: else if(g_cvIntegral < -200)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u11165
	movlw	038h
	subwf	(_g_cvIntegral)^080h,w
u11165:

	skipnc
	goto	u11161
	goto	u11160
u11161:
	goto	l6825
u11160:
	line	1630
	
l6823:	
;charge_mgr.c: 1630: g_cvIntegral = -200;
	movlw	038h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	movlw	0FFh
	movwf	((_g_cvIntegral)^080h)+1
	line	1633
	
l6825:	
;charge_mgr.c: 1633: int adjust = (error * 4 + g_cvIntegral) / 8;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_cvIntegral)^080h,w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1)^080h,w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	1634
	
l6827:	
;charge_mgr.c: 1634: int duty = (int)g_pwmDuty + adjust;
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
l6829:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	1637
	
l6831:	
;charge_mgr.c: 1637: if(duty > 32) duty = 32;
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u11175
	movlw	021h
	subwf	(CCCV_Control@duty),w
u11175:

	skipc
	goto	u11171
	goto	u11170
u11171:
	goto	l6835
u11170:
	
l6833:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1638
	
l6835:	
;charge_mgr.c: 1638: if(duty < 0) duty = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u11181
	goto	u11180
u11181:
	goto	l6839
u11180:
	
l6837:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1640
	
l6839:	
;charge_mgr.c: 1640: g_pwmDuty = (unsigned char)duty;
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	1642
	
l859:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    2[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    4[COMMON] unsigned char 
;;  product         1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Print_SystemStatus
;;		_Slot_Charge_Ctrl
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext29
__ptext29:	;psect for function ___bmul
psect	text29
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	movwf	(___bmul@multiplier)
	line	6
	
l5529:	
	clrf	(___bmul@product)
	line	43
	
l5531:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u8391
	goto	u8390
u8391:
	goto	l5535
u8390:
	line	44
	
l5533:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l5535:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l5537:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u8401
	goto	u8400
u8401:
	goto	l5531
u8400:
	line	50
	
l5539:	
	movf	(___bmul@product),w
	line	51
	
l921:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    2[COMMON] int 
;;  dividend        2    4[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    8[COMMON] int 
;;  sign            1    7[COMMON] unsigned char 
;;  counter         1    6[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    2[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text30,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext30
__ptext30:	;psect for function ___awdiv
psect	text30
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 4
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
l5543:	
	clrf	(___awdiv@sign)
	line	15
	
l5545:	
	btfss	(___awdiv@divisor+1),7
	goto	u8411
	goto	u8410
u8411:
	goto	l5551
u8410:
	line	16
	
l5547:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
l5549:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
l5551:	
	btfss	(___awdiv@dividend+1),7
	goto	u8421
	goto	u8420
u8421:
	goto	l5557
u8420:
	line	20
	
l5553:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
l5555:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
l5557:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
l5559:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u8431
	goto	u8430
u8431:
	goto	l5579
u8430:
	line	25
	
l5561:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	l5565
	line	27
	
l5563:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
l5565:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u8441
	goto	u8440
u8441:
	goto	l5563
u8440:
	line	31
	
l5567:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
l5569:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u8455
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u8455:
	skipc
	goto	u8451
	goto	u8450
u8451:
	goto	l5575
u8450:
	line	33
	
l5571:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
l5573:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
l5575:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
l5577:	
	decfsz	(___awdiv@counter),f
	goto	u8461
	goto	u8460
u8461:
	goto	l5567
u8460:
	line	39
	
l5579:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u8471
	goto	u8470
u8471:
	goto	l5583
u8470:
	line	40
	
l5581:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
l5583:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
l1033:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 301 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		_Apply_Gate_Want
;;		_PowerOnLedSequence
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text31,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	301
global __ptext31
__ptext31:	;psect for function _Isr_Timer
psect	text31
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	301
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 2
; Regs used in _Isr_Timer: [wreg+status,2+status,0+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Isr_Timer+0)
	movf	pclath,w
	movwf	(??_Isr_Timer+1)
	ljmp	_Isr_Timer
psect	text31
	line	304
	
i1l4975:	
;main.c: 304: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u754_21
	goto	u754_20
u754_21:
	goto	i1l402
u754_20:
	line	306
	
i1l4977:	
;main.c: 305: {
;main.c: 306: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	307
	
i1l4979:	
;main.c: 307: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(129)^080h	;volatile
	line	308
# 308 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text31
	line	316
	
i1l4981:	
;main.c: 316: g_pwmCounter++;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(_g_pwmCounter)^080h,f	;volatile
	line	317
	
i1l4983:	
;main.c: 317: if(g_pwmCounter >= 32)
	movlw	low(020h)
	subwf	(_g_pwmCounter)^080h,w	;volatile
	skipc
	goto	u755_21
	goto	u755_20
u755_21:
	goto	i1l4987
u755_20:
	line	319
	
i1l4985:	
;main.c: 318: {
;main.c: 319: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)^080h	;volatile
	line	327
	
i1l4987:	
;main.c: 323: }
;main.c: 327: if(g_pwmDuty > 0 && g_pwmCounter < g_pwmDuty)
	bcf	status, 5	;RP0=0, select bank0
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u756_21
	goto	u756_20
u756_21:
	goto	i1l394
u756_20:
	
i1l4989:	
	movf	(_g_pwmDuty),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_pwmCounter)^080h,w	;volatile
	skipnc
	goto	u757_21
	goto	u757_20
u757_21:
	goto	i1l394
u757_20:
	line	329
	
i1l4991:	
;main.c: 330: g_pwmOn = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(55/8),(55)&7	;volatile
	line	331
;main.c: 331: }
	goto	i1l4993
	line	332
	
i1l394:	
	line	334
;main.c: 335: g_pwmOn = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(55/8),(55)&7	;volatile
	line	338
	
i1l4993:	
;main.c: 336: }
;main.c: 338: if(g_powerOnPhase >= 2U)
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w
	skipc
	goto	u758_21
	goto	u758_20
u758_21:
	goto	i1l5001
u758_20:
	line	342
	
i1l4995:	
;main.c: 339: {
;main.c: 342: if(g_gateWant != g_gateApplied)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_gateApplied+1)^080h,w
	xorwf	(_g_gateWant+1)^080h,w	;volatile
	skipz
	goto	u759_25
	movf	(_g_gateApplied)^080h,w
	xorwf	(_g_gateWant)^080h,w	;volatile
u759_25:

	skipnz
	goto	u759_21
	goto	u759_20
u759_21:
	goto	i1l5001
u759_20:
	line	344
	
i1l4997:	
;main.c: 343: {
;main.c: 344: Apply_Gate_Want();
	fcall	_Apply_Gate_Want
	line	345
	
i1l4999:	
;main.c: 345: g_gateApplied = g_gateWant;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_gateWant+1)^080h,w	;volatile
	movwf	(_g_gateApplied+1)^080h
	movf	(_g_gateWant)^080h,w	;volatile
	movwf	(_g_gateApplied)^080h
	line	417
	
i1l5001:	
;main.c: 346: }
;main.c: 411: }
;main.c: 417: if(++g_hwTickDiv >= 80U)
	movlw	low(050h)
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_hwTickDiv)^080h,f	;volatile
	subwf	((_g_hwTickDiv)^080h),w	;volatile
	skipc
	goto	u760_21
	goto	u760_20
u760_21:
	goto	i1l5017
u760_20:
	line	419
	
i1l5003:	
;main.c: 418: {
;main.c: 419: g_hwTickDiv = 0;
	clrf	(_g_hwTickDiv)^080h	;volatile
	line	420
	
i1l5005:	
;main.c: 420: g_hwTick++;
	incf	(_g_hwTick)^080h,f	;volatile
	skipnz
	incf	(_g_hwTick+1)^080h,f	;volatile
	line	429
	
i1l5007:	
;main.c: 429: if(g_powerOnPhase < 2U)
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w
	skipnc
	goto	u761_21
	goto	u761_20
u761_21:
	goto	i1l5011
u761_20:
	line	430
	
i1l5009:	
;main.c: 430: g_powerOnTimer++;
	incf	(_g_powerOnTimer)^080h,f	;volatile
	line	432
	
i1l5011:	
;main.c: 432: if(++g_printTick >= (200))
	movlw	low(0C8h)
	incf	(_g_printTick)^080h,f	;volatile
	subwf	((_g_printTick)^080h),w	;volatile
	skipc
	goto	u762_21
	goto	u762_20
u762_21:
	goto	i1l5017
u762_20:
	line	434
	
i1l5013:	
;main.c: 433: {
;main.c: 434: g_printTick = 0;
	clrf	(_g_printTick)^080h	;volatile
	line	435
	
i1l5015:	
;main.c: 435: g_printFlag = 1;
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	444
	
i1l5017:	
;main.c: 436: }
;main.c: 438: }
;main.c: 444: if(g_powerOnPhase < 2)
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u763_21
	goto	u763_20
u763_21:
	goto	i1l5023
u763_20:
	line	446
	
i1l5019:	
;main.c: 445: {
;main.c: 446: PowerOnLedSequence();
	fcall	_PowerOnLedSequence
	goto	i1l402
	line	451
	
i1l5023:	
;main.c: 448: }
;main.c: 451: if(g_tempPhase == 0)
	movf	((_g_tempPhase)^080h),w	;volatile
	btfss	status,2
	goto	u764_21
	goto	u764_20
u764_21:
	goto	i1l5035
u764_20:
	line	453
	
i1l5025:	
;main.c: 452: {
;main.c: 453: g_tempReadRoundCnt++;
	incf	(_g_tempReadRoundCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1)^080h,f	;volatile
	line	454
	
i1l5027:	
;main.c: 454: if(g_tempReadRoundCnt >= 200)
	movlw	0
	subwf	(_g_tempReadRoundCnt+1)^080h,w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt)^080h,w	;volatile
	skipc
	goto	u765_21
	goto	u765_20
u765_21:
	goto	i1l402
u765_20:
	line	456
	
i1l5029:	
;main.c: 455: {
;main.c: 456: g_tempReadRoundCnt = 0;
	clrf	(_g_tempReadRoundCnt)^080h	;volatile
	clrf	(_g_tempReadRoundCnt+1)^080h	;volatile
	line	457
	
i1l5031:	
;main.c: 457: g_tempPhase = 1;
	movlw	low(01h)
	movwf	(_g_tempPhase)^080h	;volatile
	line	458
	
i1l5033:	
;main.c: 458: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	goto	i1l402
	line	463
	
i1l5035:	
;main.c: 461: else
;main.c: 462: {
;main.c: 463: g_tempSettleCnt++;
	incf	(_g_tempSettleCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1)^080h,f	;volatile
	line	464
	
i1l5037:	
;main.c: 464: if(g_tempSettleCnt >= 60)
	movlw	0
	subwf	(_g_tempSettleCnt+1)^080h,w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt)^080h,w	;volatile
	skipc
	goto	u766_21
	goto	u766_20
u766_21:
	goto	i1l402
u766_20:
	line	466
	
i1l5039:	
;main.c: 465: {
;main.c: 466: g_doNtcRead = 1;
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	467
	
i1l5041:	
;main.c: 467: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	line	468
;main.c: 468: g_tempPhase = 0;
	clrf	(_g_tempPhase)^080h	;volatile
	line	472
	
i1l402:	
	movf	(??_Isr_Timer+1),w
	movwf	pclath
	swapf	(??_Isr_Timer+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 269 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text32,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	269
global __ptext32
__ptext32:	;psect for function _PowerOnLedSequence
psect	text32
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	269
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 2
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	271
	
i1l3737:	
;led.c: 271: if(g_powerOnPhase == 0)
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u469_21
	goto	u469_20
u469_21:
	goto	i1l3745
u469_20:
	line	273
	
i1l3739:	
;led.c: 272: {
;led.c: 273: if(g_powerOnTimer >= 100)
	movlw	low(064h)
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u470_21
	goto	u470_20
u470_21:
	goto	i1l897
u470_20:
	line	275
	
i1l3741:	
;led.c: 274: {
;led.c: 275: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)^080h	;volatile
	line	276
	
i1l3743:	
;led.c: 276: g_powerOnPhase = 1;
	movlw	low(01h)
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l897
	line	279
	
i1l3745:	
;led.c: 279: else if(g_powerOnPhase == 1)
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u471_21
	goto	u471_20
u471_21:
	goto	i1l897
u471_20:
	line	281
	
i1l3747:	
;led.c: 280: {
;led.c: 281: if(g_powerOnTimer >= 100)
	movlw	low(064h)
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u472_21
	goto	u472_20
u472_21:
	goto	i1l897
u472_20:
	line	283
	
i1l3749:	
;led.c: 282: {
;led.c: 283: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)^080h	;volatile
	line	284
	
i1l3751:	
;led.c: 284: g_powerOnPhase = 2;
	movlw	low(02h)
	movwf	(_g_powerOnPhase)	;volatile
	line	287
	
i1l897:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
	global	_Apply_Gate_Want

;; *************** function _Apply_Gate_Want *****************
;; Defined at:
;;		line 59 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text33,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	59
global __ptext33
__ptext33:	;psect for function _Apply_Gate_Want
psect	text33
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	59
	global	__size_of_Apply_Gate_Want
	__size_of_Apply_Gate_Want	equ	__end_of_Apply_Gate_Want-_Apply_Gate_Want
	
_Apply_Gate_Want:	
;incstack = 0
	opt	stack 2
; Regs used in _Apply_Gate_Want: []
	line	61
	
i1l3665:	
;main.c: 61: RA0 = (g_gateWant & 0x001U) ? 0 : 1;
	btfss	(_g_gateWant)^080h,(0)&7	;volatile
	goto	u444_21
	goto	u444_20
	
u444_21:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	u445_24
u444_20:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
u445_24:
	line	62
;main.c: 62: RA1 = (g_gateWant & 0x002U) ? 0 : 1;
	btfss	(_g_gateWant)^080h,(1)&7	;volatile
	goto	u446_21
	goto	u446_20
	
u446_21:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	u447_24
u446_20:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
u447_24:
	line	63
;main.c: 63: RB3 = (g_gateWant & 0x004U) ? 0 : 1;
	btfss	(_g_gateWant)^080h,(2)&7	;volatile
	goto	u448_21
	goto	u448_20
	
u448_21:
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	u449_24
u448_20:
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
u449_24:
	line	64
;main.c: 64: RB2 = (g_gateWant & 0x008U) ? 0 : 1;
	bsf	status, 5	;RP0=1, select bank1
	btfss	(_g_gateWant)^080h,(3)&7	;volatile
	goto	u450_21
	goto	u450_20
	
u450_21:
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	u451_24
u450_20:
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
u451_24:
	line	65
;main.c: 65: RA3 = (g_gateWant & 0x010U) ? 0 : 1;
	bsf	status, 5	;RP0=1, select bank1
	btfss	(_g_gateWant)^080h,(4)&7	;volatile
	goto	u452_21
	goto	u452_20
	
u452_21:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	u453_24
u452_20:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
u453_24:
	line	66
;main.c: 66: RA2 = (g_gateWant & 0x020U) ? 0 : 1;
	btfss	(_g_gateWant)^080h,(5)&7	;volatile
	goto	u454_21
	goto	u454_20
	
u454_21:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	u455_24
u454_20:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
u455_24:
	line	67
;main.c: 67: RD1 = (g_gateWant & 0x040U) ? 0 : 1;
	btfss	(_g_gateWant)^080h,(6)&7	;volatile
	goto	u456_21
	goto	u456_20
	
u456_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	u457_24
u456_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
u457_24:
	line	68
;main.c: 68: RD3 = (g_gateWant & 0x080U) ? 0 : 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	btfss	(_g_gateWant)^080h,(7)&7	;volatile
	goto	u458_21
	goto	u458_20
	
u458_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	u459_24
u458_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
u459_24:
	line	69
;main.c: 69: RB0 = (g_gateWant & 0x100U) ? 0 : 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	btfss	(_g_gateWant+1)^080h,(8)&7	;volatile
	goto	u460_21
	goto	u460_20
	
u460_21:
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	u461_24
u460_20:
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
u461_24:
	line	70
;main.c: 70: RB1 = (g_gateWant & 0x200U) ? 0 : 1;
	bsf	status, 5	;RP0=1, select bank1
	btfss	(_g_gateWant+1)^080h,(9)&7	;volatile
	goto	u462_21
	goto	u462_20
	
u462_21:
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	u463_24
u462_20:
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
u463_24:
	line	71
;main.c: 71: RD2 = (g_gateWant & 0x400U) ? 0 : 1;
	bsf	status, 5	;RP0=1, select bank1
	btfss	(_g_gateWant+1)^080h,(10)&7	;volatile
	goto	u464_21
	goto	u464_20
	
u464_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	u465_24
u464_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
u465_24:
	line	72
;main.c: 72: RD0 = (g_gateWant & 0x800U) ? 0 : 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	btfss	(_g_gateWant+1)^080h,(11)&7	;volatile
	goto	u466_21
	goto	u466_20
	
u466_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	u467_24
u466_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
u467_24:
	line	73
	
i1l347:	
	return
	opt stack 0
GLOBAL	__end_of_Apply_Gate_Want
	__end_of_Apply_Gate_Want:
	signat	_Apply_Gate_Want,89
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
