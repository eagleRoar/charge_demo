opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ChargeProcess_Slot
	FNCALL	_main,_Do_AdcSample
	FNCALL	_main,_Do_NtcRead
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_System_Init
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_Do_NtcRead,_Read_Temperature
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Do_AdcSample,_ADC_Sample
	FNCALL	_Do_AdcSample,___bmul
	FNCALL	_ChargeProcess_Slot,_ADC_Sample
	FNCALL	_ChargeProcess_Slot,_Detect_BatteryType
	FNCALL	_ChargeProcess_Slot,___bmul
	FNCALL	_ChargeProcess_Slot,___lldiv
	FNCALL	_ChargeProcess_Slot,___lmul
	FNCALL	_ChargeProcess_Slot,___lwdiv
	FNCALL	_ChargeProcess_Slot,___wmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_CCCV_Control
	FNCALL	_Isr_Timer,_Charging_Control
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Update_LED_Slot
	FNCALL	_Isr_Timer,i1_ADC_Sample
	FNCALL	_Isr_Timer,i1___lldiv
	FNCALL	_Update_LED_Slot,i1___bmul
	FNCALL	_Charging_Control,i1___bmul
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,i1___bmul
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_temperature
	global	_g_vcc_mv
	global	_g_impCheckSlot
psect	idataBANK0,class=CODE,space=0,delta=2,noexec
global __pidataBANK0
__pidataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	18

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	29

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	26

;initializer for _g_impCheckSlot
	retlw	0FFh
	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	55
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_s_ledBlinkCnt
	global	_g_tempProtect
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_adcBusy
	global	_g_doAdcSample
	global	_g_detectLowCnt
	global	_g_powerOnTimer
	global	_g_cvIntegral
	global	_g_vccProtect
	global	_g_tempPhase
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_scanPhase
	global	_g_scanIndex
	global	_test_adc
	global	_adresult
	global	_g_diodeTrace
	global	_g_highVFlag
	global	_g_capFlag
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_impData
	global	_g_diodeTraceSlot
	global	_g_diodeTraceCnt
	global	_g_slot
	global	_g_slotRefV
	global	_g_stableCnt
	global	_g_ovCnt
	global	_g_ccBlocks
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_GIE
_GIE	set	0x5F
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC4
_RC4	set	0x834
	global	_RC5
_RC5	set	0x835
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	0
psect	stringtext
	
STR_37:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_25:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_23:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	45	;'-'
	retlw	105	;'i'
	retlw	111	;'o'
	retlw	110	;'n'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	67	;'C'
	retlw	32	;' '
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	95	;'_'
	retlw	76	;'L'
	retlw	79	;'O'
	retlw	67	;'C'
	retlw	75	;'K'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_38:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_8:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_30:	
	retlw	32	;' '
	retlw	112	;'p'
	retlw	114	;'r'
	retlw	101	;'e'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	32	;' '
	retlw	114	;'r'
	retlw	101	;'e'
	retlw	102	;'f'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_31:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_29:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	73	;'I'
	retlw	79	;'O'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_7:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_34:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	114	;'r'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_32:	
	retlw	32	;' '
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_33:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	53	;'5'
	retlw	52	;'4'
	retlw	82	;'R'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
STR_27	equ	STR_17+0
STR_9	equ	STR_2+0
STR_11	equ	STR_38+7
STR_35	equ	STR_38+7
STR_36	equ	STR_38+7
; #config settings
	file	"SC8F096_Timer_Demo.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

_g_adcBusy:
       ds      1

_g_doAdcSample:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_s_ledBlinkCnt:
       ds      1

_g_tempProtect:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_detectLowCnt:
       ds      12

_g_powerOnTimer:
       ds      2

_g_cvIntegral:
       ds      2

_g_vccProtect:
       ds      1

_g_tempPhase:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_scanPhase:
       ds      1

_g_scanIndex:
       ds      1

_test_adc:
       ds      1

_adresult:
       ds      2

psect	dataBANK0,class=BANK0,space=1,noexec
global __pdataBANK0
__pdataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	18
_g_temperature:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_diodeTrace:
       ds      4

_g_highVFlag:
       ds      2

_g_capFlag:
       ds      2

_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_impData:
       ds      2

_g_diodeTraceSlot:
       ds      1

_g_diodeTraceCnt:
       ds      1

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	29
_g_vcc_mv:
       ds      2

psect	dataBANK1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	26
_g_impCheckSlot:
       ds      1

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slotRefV:
       ds      24

_g_stableCnt:
       ds      12

_g_ovCnt:
       ds      12

_g_ccBlocks:
       ds      12

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"SC8F096_Timer_Demo.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
	fcall	__pidataBANK1+2		;fetch initializer
	movwf	__pdataBANK1+2&07fh		
; Initialize objects allocated to BANK0
	global __pidataBANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	fcall	__pidataBANK0+0		;fetch initializer
	movwf	__pdataBANK0+0&07fh		
	fcall	__pidataBANK0+1		;fetch initializer
	movwf	__pdataBANK0+1&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+03Ch)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+012h)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+01Ah)
	fcall	clear_ram0
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
	clrf	((__pbssCOMMON)+1)&07Fh
; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK3,class=BANK3,space=1,noexec
global __pcstackBANK3
__pcstackBANK3:
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x0
	global	ChargeProcess_Slot@v_ref
ChargeProcess_Slot@v_ref:	; 2 bytes @ 0x0
	ds	2
	global	ChargeProcess_Slot@tc
ChargeProcess_Slot@tc:	; 1 bytes @ 0x2
	ds	1
	global	ChargeProcess_Slot@bat_mv
ChargeProcess_Slot@bat_mv:	; 2 bytes @ 0x3
	ds	2
	global	ChargeProcess_Slot@bat_mv_383
ChargeProcess_Slot@bat_mv_383:	; 2 bytes @ 0x5
	ds	2
	global	ChargeProcess_Slot@bat_mv_386
ChargeProcess_Slot@bat_mv_386:	; 2 bytes @ 0x7
	ds	2
	global	ChargeProcess_Slot@diff
ChargeProcess_Slot@diff:	; 2 bytes @ 0x9
	ds	2
	global	ChargeProcess_Slot@pre
ChargeProcess_Slot@pre:	; 2 bytes @ 0xB
	ds	4
	global	ChargeProcess_Slot@st
ChargeProcess_Slot@st:	; 1 bytes @ 0xF
	ds	1
	global	ChargeProcess_Slot@ty
ChargeProcess_Slot@ty:	; 1 bytes @ 0x10
	ds	1
	global	ChargeProcess_Slot@ct
ChargeProcess_Slot@ct:	; 2 bytes @ 0x11
	ds	2
	global	ChargeProcess_Slot@idx
ChargeProcess_Slot@idx:	; 1 bytes @ 0x13
	ds	1
psect	cstackBANK2,class=BANK2,space=1,noexec
global __pcstackBANK2
__pcstackBANK2:
	global	ChargeProcess_Slot@v
ChargeProcess_Slot@v:	; 2 bytes @ 0x0
	ds	2
??_main:	; 1 bytes @ 0x2
	ds	2
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
?_ADC_Sample:	; 1 bytes @ 0x0
??_uart_send_char:	; 1 bytes @ 0x0
?_Detect_BatteryType:	; 1 bytes @ 0x0
?___bmul:	; 1 bytes @ 0x0
	global	?___wmul
?___wmul:	; 2 bytes @ 0x0
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x0
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x0
	global	?___lmul
?___lmul:	; 4 bytes @ 0x0
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x0
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x0
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x0
	global	___wmul@multiplier
___wmul@multiplier:	; 2 bytes @ 0x0
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x0
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x0
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x0
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x1
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x1
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x1
	ds	1
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x2
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x2
	global	___wmul@multiplicand
___wmul@multiplicand:	; 2 bytes @ 0x2
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x2
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x2
	ds	1
?_uart_send_string:	; 1 bytes @ 0x3
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x3
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x3
	ds	1
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x4
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x4
	global	___wmul@product
___wmul@product:	; 2 bytes @ 0x4
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x4
	ds	1
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x5
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x5
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x6
	ds	1
?_uart_send_number:	; 1 bytes @ 0x7
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x7
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x7
	ds	1
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x8
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x8
	ds	1
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x9
	ds	3
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0xC
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0xC
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0xC
	ds	2
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0xE
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0xF
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x10
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0x10
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x10
	ds	1
	global	_Print_NtcTemp$743
_Print_NtcTemp$743:	; 2 bytes @ 0x11
	ds	1
??_Do_AdcSample:	; 1 bytes @ 0x12
	ds	1
	global	Do_AdcSample@ch
Do_AdcSample@ch:	; 1 bytes @ 0x13
	global	_Print_NtcTemp$744
_Print_NtcTemp$744:	; 2 bytes @ 0x13
	ds	1
	global	Do_AdcSample@ty
Do_AdcSample@ty:	; 1 bytes @ 0x14
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x14
	ds	1
	global	Do_AdcSample@dly
Do_AdcSample@dly:	; 1 bytes @ 0x15
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x15
	ds	1
	global	Do_AdcSample@st
Do_AdcSample@st:	; 1 bytes @ 0x16
	ds	3
??_Read_Temperature:	; 1 bytes @ 0x19
??_ChargeProcess_Slot:	; 1 bytes @ 0x19
??_Print_SystemStatus:	; 1 bytes @ 0x19
	ds	4
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x1D
	ds	1
	global	ChargeProcess_Slot@v_init
ChargeProcess_Slot@v_init:	; 2 bytes @ 0x1E
	ds	2
	global	ChargeProcess_Slot@vx_mv
ChargeProcess_Slot@vx_mv:	; 4 bytes @ 0x20
	ds	1
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x21
	global	_Print_SystemStatus$745
_Print_SystemStatus$745:	; 2 bytes @ 0x21
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x23
	global	_Print_SystemStatus$746
_Print_SystemStatus$746:	; 2 bytes @ 0x23
	ds	1
	global	ChargeProcess_Slot@bat_mv_long
ChargeProcess_Slot@bat_mv_long:	; 4 bytes @ 0x24
	ds	1
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x25
	ds	3
	global	ChargeProcess_Slot@vx_mv_381
ChargeProcess_Slot@vx_mv_381:	; 4 bytes @ 0x28
	ds	1
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x29
	ds	1
	global	_Print_SystemStatus$277
_Print_SystemStatus$277:	; 2 bytes @ 0x2A
	ds	2
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x2C
	global	ChargeProcess_Slot@bat_mv_long_382
ChargeProcess_Slot@bat_mv_long_382:	; 4 bytes @ 0x2C
	ds	2
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0x2E
	ds	2
	global	ChargeProcess_Slot@vx_mv_384
ChargeProcess_Slot@vx_mv_384:	; 4 bytes @ 0x30
	ds	2
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0x32
	ds	2
	global	ChargeProcess_Slot@bat_mv_long_385
ChargeProcess_Slot@bat_mv_long_385:	; 4 bytes @ 0x34
	ds	2
	global	Print_SystemStatus@tc
Print_SystemStatus@tc:	; 1 bytes @ 0x36
	ds	1
	global	Print_SystemStatus@t
Print_SystemStatus@t:	; 1 bytes @ 0x37
	ds	1
	global	Print_SystemStatus@d
Print_SystemStatus@d:	; 2 bytes @ 0x38
	global	_ChargeProcess_Slot$391
_ChargeProcess_Slot$391:	; 2 bytes @ 0x38
	ds	2
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x3A
	global	ChargeProcess_Slot@hasRise
ChargeProcess_Slot@hasRise:	; 1 bytes @ 0x3A
	ds	1
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Update_LED_Slot:	; 1 bytes @ 0x0
?_Charging_Control:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_ChargeProcess_Slot:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Do_AdcSample:	; 1 bytes @ 0x0
?_Do_NtcRead:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?i1_ADC_Sample:	; 1 bytes @ 0x0
?i1___bmul:	; 1 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	?i1___lldiv
?i1___lldiv:	; 4 bytes @ 0x0
	global	i1ADC_Sample@adldo
i1ADC_Sample@adldo:	; 1 bytes @ 0x0
	global	i1___bmul@multiplicand
i1___bmul@multiplicand:	; 1 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	global	i1___lldiv@divisor
i1___lldiv@divisor:	; 4 bytes @ 0x0
	ds	1
??i1_ADC_Sample:	; 1 bytes @ 0x1
??i1___bmul:	; 1 bytes @ 0x1
	global	i1___bmul@multiplier
i1___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
	global	i1___bmul@product
i1___bmul@product:	; 1 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_Update_LED_Slot:	; 1 bytes @ 0x3
??_Charging_Control:	; 1 bytes @ 0x3
	global	Charging_Control@s
Charging_Control@s:	; 1 bytes @ 0x3
	global	Update_LED_Slot@idx
Update_LED_Slot@idx:	; 1 bytes @ 0x3
	ds	1
??___awdiv:	; 1 bytes @ 0x4
	global	Charging_Control@i
Charging_Control@i:	; 1 bytes @ 0x4
	global	Update_LED_Slot@hasErr
Update_LED_Slot@hasErr:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	global	i1___lldiv@dividend
i1___lldiv@dividend:	; 4 bytes @ 0x4
	ds	1
	global	Update_LED_Slot@hasChg
Update_LED_Slot@hasChg:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	ds	1
	global	Update_LED_Slot@hasFull
Update_LED_Slot@hasFull:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	1
	global	Update_LED_Slot@i
Update_LED_Slot@i:	; 1 bytes @ 0x7
	ds	1
??_CCCV_Control:	; 1 bytes @ 0x8
??i1___lldiv:	; 1 bytes @ 0x8
	global	Update_LED_Slot@s
Update_LED_Slot@s:	; 1 bytes @ 0x8
	ds	2
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	i1ADC_Sample@adch
i1ADC_Sample@adch:	; 1 bytes @ 0x0
	global	i1___lldiv@counter
i1___lldiv@counter:	; 1 bytes @ 0x0
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x0
	ds	1
	global	i1ADC_Sample@j
i1ADC_Sample@j:	; 1 bytes @ 0x1
	global	i1___lldiv@quotient
i1___lldiv@quotient:	; 4 bytes @ 0x1
	ds	1
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x2
	global	i1ADC_Sample@i
i1ADC_Sample@i:	; 1 bytes @ 0x2
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x3
	global	i1ADC_Sample@adsum
i1ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0x4
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0x5
	ds	1
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x6
	ds	1
	global	i1ADC_Sample@admin
i1ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x8
	ds	1
	global	i1ADC_Sample@admax
i1ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	1
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xA
	ds	1
	global	i1ADC_Sample@ad_temp
i1ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0xC
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0xD
	ds	1
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0xE
	ds	2
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x10
	ds	1
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x11
	ds	1
??_Isr_Timer:	; 1 bytes @ 0x12
	ds	4
	global	Isr_Timer@pt
Isr_Timer@pt:	; 4 bytes @ 0x16
	ds	4
??_AD_Init:	; 1 bytes @ 0x1A
??_uart_init:	; 1 bytes @ 0x1A
??_uart_send_string:	; 1 bytes @ 0x1A
??_uart_send_number:	; 1 bytes @ 0x1A
??_System_Init:	; 1 bytes @ 0x1A
??_Do_NtcRead:	; 1 bytes @ 0x1A
??_Print_NtcTemp:	; 1 bytes @ 0x1A
??_Detect_BatteryType:	; 1 bytes @ 0x1A
??___wmul:	; 1 bytes @ 0x1A
??___lmul:	; 1 bytes @ 0x1A
??___bmul:	; 1 bytes @ 0x1A
??___lldiv:	; 1 bytes @ 0x1A
??___lwdiv:	; 1 bytes @ 0x1A
??___lwmod:	; 1 bytes @ 0x1A
;!
;!Data Sizes:
;!    Strings     254
;!    Constant    12
;!    Data        5
;!    BSS         178
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     10      13
;!    BANK0            80     26      54
;!    BANK1            80     59      80
;!    BANK3            80     20      80
;!    BANK2            80      4      76

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 25
;!		 -> STR_38(CODE[10]), STR_37(CODE[21]), STR_36(CODE[3]), STR_35(CODE[3]), 
;!		 -> STR_34(CODE[5]), STR_33(CODE[5]), STR_32(CODE[5]), STR_31(CODE[6]), 
;!		 -> STR_30(CODE[6]), STR_29(CODE[6]), STR_28(CODE[6]), STR_27(CODE[6]), 
;!		 -> STR_26(CODE[6]), STR_25(CODE[16]), STR_24(CODE[13]), STR_23(CODE[15]), 
;!		 -> STR_22(CODE[7]), STR_21(CODE[5]), STR_20(CODE[5]), STR_19(CODE[6]), 
;!		 -> STR_18(CODE[6]), STR_17(CODE[6]), STR_16(CODE[6]), STR_15(CODE[7]), 
;!		 -> STR_14(CODE[4]), STR_13(CODE[6]), STR_12(CODE[6]), STR_11(CODE[3]), 
;!		 -> STR_10(CODE[12]), STR_9(CODE[2]), STR_8(CODE[6]), STR_7(CODE[5]), 
;!		 -> STR_6(CODE[6]), STR_5(CODE[5]), STR_4(CODE[25]), STR_3(CODE[4]), 
;!		 -> STR_2(CODE[2]), STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->_CCCV_Control
;!    _Update_LED_Slot->i1___bmul
;!    _Charging_Control->i1___bmul
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _main in BANK0
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    _Isr_Timer->_CCCV_Control
;!
;!Critical Paths under _main in BANK1
;!
;!    _main->_ChargeProcess_Slot
;!    _main->_Print_SystemStatus
;!    _System_Init->___bmul
;!    _Print_SystemStatus->___lldiv
;!    _Print_NtcTemp->_uart_send_number
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _Do_NtcRead->_Read_Temperature
;!    _Read_Temperature->___lldiv
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->___lldiv
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    _main->_ChargeProcess_Slot
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    _main->_ChargeProcess_Slot
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 2     2      0   65865
;!                                              2 BANK2      2     2      0
;!                 _ChargeProcess_Slot
;!                       _Do_AdcSample
;!                         _Do_NtcRead
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                        _System_Init
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1542
;!                                              3 BANK1      1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  36    36      0   16504
;!                                             25 BANK1     34    34      0
;!                                              0 BANK3      2     2      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    8113
;!                                             17 BANK1      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    3194
;!                                              3 BANK1      2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_number                                    10     8      2    3367
;!                                              7 BANK1     10     8      2
;!                             ___bmul (ARG)
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     102
;!                                              0 BANK1      3     3      0
;! ---------------------------------------------------------------------------------
;! (3) ___lwmod                                              5     1      4     518
;!                                              0 BANK1      5     1      4
;! ---------------------------------------------------------------------------------
;! (1) _Do_NtcRead                                           0     0      0    6871
;!                   _Read_Temperature
;! ---------------------------------------------------------------------------------
;! (2) _Read_Temperature                                    12    12      0    6871
;!                                             25 BANK1     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (1) _Do_AdcSample                                         5     5      0    3063
;!                                             18 BANK1      5     5      0
;!                         _ADC_Sample
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _ChargeProcess_Slot                                  56    56      0   26578
;!                                             25 BANK1     34    34      0
;!                                              0 BANK3     20    20      0
;!                                              0 BANK2      2     2      0
;!                         _ADC_Sample
;!                 _Detect_BatteryType
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (2) ___wmul                                               6     2      4    3052
;!                                              0 BANK1      6     2      4
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4    1010
;!                                              0 BANK1      7     3      4
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8    2622
;!                                              0 BANK1     12     4      8
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1554
;!                                             12 BANK1     13     5      8
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1    1194
;!                                              0 BANK1      3     2      1
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     331
;!                                              0 BANK1      2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _ADC_Sample                                          18    17      1    1125
;!                                              0 BANK1     18    17      1
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 3
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            8     8      0    4077
;!                                             18 BANK0      8     8      0
;!                       _CCCV_Control
;!                   _Charging_Control
;!                 _PowerOnLedSequence
;!                    _Update_LED_Slot
;!                       i1_ADC_Sample
;!                          i1___lldiv
;! ---------------------------------------------------------------------------------
;! (5) i1___lldiv                                           13     5      8      44
;!                                              0 COMMON     8     0      8
;!                                              0 BANK0      5     5      0
;! ---------------------------------------------------------------------------------
;! (5) i1_ADC_Sample                                        18    17      1     551
;!                                              0 COMMON     5     4      1
;!                                              0 BANK0     13    13      0
;! ---------------------------------------------------------------------------------
;! (5) _Update_LED_Slot                                      6     6      0     660
;!                                              3 COMMON     6     6      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Charging_Control                                     2     2      0     666
;!                                              3 COMMON     2     2      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _CCCV_Control                                        20    20      0    2108
;!                                              8 COMMON     2     2      0
;!                                              0 BANK0     18    18      0
;!                            ___awdiv
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (6) i1___bmul                                             3     2      1     144
;!                                              0 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (6) ___awdiv                                              8     4      4     428
;!                                              0 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ChargeProcess_Slot
;!     _ADC_Sample
;!     _Detect_BatteryType
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___wmul
;!   _Do_AdcSample
;!     _ADC_Sample
;!     ___bmul
;!   _Do_NtcRead
;!     _Read_Temperature
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!       ___lwdiv
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     i1___bmul
;!   _Charging_Control
;!     i1___bmul
;!   _PowerOnLedSequence
;!   _Update_LED_Slot
;!     i1___bmul
;!   i1_ADC_Sample
;!   i1___lldiv
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50     14      50       8      100.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      4      4C      10       95.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50     3B      50       6      100.0%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     1A      36       4       67.5%
;!BITBANK0            50      0       0       3        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      A       D       1       92.9%
;!BITCOMMON            E      0       1       0        7.1%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     12F      12        0.0%
;!ABS                  0      0     12F      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 561 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       2
;;      Totals:         0       0       0       0       2
;;Total ram usage:        2 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ChargeProcess_Slot
;;		_Do_AdcSample
;;		_Do_NtcRead
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_System_Init
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	561
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	561
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	564
	
l8958:	
;main.c: 564: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
movwf	((??_main+0)^0100h+0+1),f
	movlw	241
movwf	((??_main+0)^0100h+0),f
	u14537:
decfsz	((??_main+0)^0100h+0),f
	goto	u14537
	decfsz	((??_main+0)^0100h+0+1),f
	goto	u14537
opt asmopt_pop

	line	565
# 565 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	568
	
l8960:	
;main.c: 568: System_Init();
	fcall	_System_Init
	line	572
	
l8962:	
;main.c: 572: uart_send_string("L1211 Charger V2.1\r\n");
	movlw	low(((STR_37)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_37)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	573
	
l8964:	
;main.c: 573: uart_send_string("Init...\r\n");
	movlw	low(((STR_38)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_38)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	577
;main.c: 577: while(1)
	
l466:	
	line	579
# 579 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	582
	
l8966:	
;main.c: 582: if(g_doAdcSample)
	btfss	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u14501
	goto	u14500
u14501:
	goto	l8974
u14500:
	line	584
	
l8968:	
;main.c: 583: {
;main.c: 584: g_doAdcSample = 0;
	bcf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	line	585
;main.c: 585: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	586
	
l8970:	
;main.c: 586: Do_AdcSample();
	fcall	_Do_AdcSample
	line	587
;main.c: 587: ChargeProcess_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_ChargeProcess_Slot
	line	589
	
l8972:	
;main.c: 589: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	593
	
l8974:	
;main.c: 590: }
;main.c: 593: if(g_doNtcRead)
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u14511
	goto	u14510
u14511:
	goto	l8982
u14510:
	line	595
	
l8976:	
;main.c: 594: {
;main.c: 595: g_doNtcRead = 0;
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	596
;main.c: 596: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	597
	
l8978:	
;main.c: 597: Do_NtcRead();
	fcall	_Do_NtcRead
	line	598
	
l8980:	
;main.c: 598: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	603
	
l8982:	
;main.c: 599: }
;main.c: 603: if(g_printFlag)
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u14521
	goto	u14520
u14521:
	goto	l466
u14520:
	line	605
	
l8984:	
;main.c: 604: {
;main.c: 605: g_printFlag = 0;
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	606
	
l8986:	
;main.c: 606: Print_SystemStatus();
	fcall	_Print_SystemStatus
	line	607
;main.c: 607: Print_NtcTemp();
	fcall	_Print_NtcTemp
	goto	l466
	global	start
	ljmp	start
	opt stack 0
	line	611
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 76 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1    3[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/900
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       1       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	76
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	76
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	81
	
l7412:	
# 81 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	82
# 82 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text1
	line	83
	
l7414:	
;main.c: 83: OSCCON = 0x72;
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	87
;main.c: 87: TRISA = 0xF0; PORTA = 0x0F;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	88
;main.c: 88: TRISB = 0x30; PORTB = 0x4F;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	89
;main.c: 89: TRISC = 0x07; PORTC = 0x00;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l7416:	
	clrf	(262)^0100h	;volatile
	line	91
	
l7418:	
;main.c: 91: TRISD = 0xF0; PORTD = 0x0F;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l7420:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	94
	
l7422:	
;main.c: 94: WPUA = 0x00; WPDA = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l7424:	
	clrf	(135)^080h	;volatile
	line	95
	
l7426:	
;main.c: 95: WPUB = 0x00; WPDB = 0x00;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l7428:	
	clrf	(7)	;volatile
	line	96
	
l7430:	
;main.c: 96: WPUC = 0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	97
	
l7432:	
;main.c: 97: WPUD = 0x00;
	clrf	(277)^0100h	;volatile
	line	100
	
l7434:	
;main.c: 100: IOCA = 0x00; IOCB = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l7436:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	103
	
l7438:	
;main.c: 103: CC0CON = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	104
	
l7440:	
;main.c: 104: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	111
	
l7442:	
;main.c: 111: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	112
	
l7444:	
;main.c: 112: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	113
	
l7446:	
;main.c: 113: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	114
	
l7448:	
;main.c: 114: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	117
	
l7450:	
;main.c: 117: AD_Init();
	fcall	_AD_Init
	line	121
	
l7452:	
;main.c: 121: uart_init();
	fcall	_uart_init
	line	129
;main.c: 129: OPTION_REG = 0x00;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	130
	
l7454:	
;main.c: 130: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	131
	
l7456:	
;main.c: 131: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	132
	
l7458:	
;main.c: 132: INTCON = 0xE0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	136
;main.c: 136: g_pwmDuty = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	137
;main.c: 137: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	138
	
l7460:	
;main.c: 138: RC5 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	139
	
l7462:	
;main.c: 139: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	140
	
l7464:	
;main.c: 140: RB6 = 1;
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	141
	
l7466:	
;main.c: 141: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	144
;main.c: 144: for(i = 0; i < 12; i++)
	bsf	status, 5	;RP0=1, select bank1
	clrf	(System_Init@i)^080h
	line	146
	
l7472:	
;main.c: 145: {
;main.c: 146: g_slot[i].state = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	147
;main.c: 147: g_slot[i].type = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	148
;main.c: 148: g_slot[i].voltage = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	149
;main.c: 149: g_slot[i].chargeTimer = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(System_Init@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	150
	
l7474:	
;main.c: 150: g_ccBlocks[i] = 0;
	movf	(System_Init@i)^080h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	151
	
l7476:	
;main.c: 151: g_ovCnt[i] = 0;
	movf	(System_Init@i)^080h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	144
	
l7478:	
	incf	(System_Init@i)^080h,f
	
l7480:	
	movlw	low(0Ch)
	subwf	(System_Init@i)^080h,w
	skipc
	goto	u11461
	goto	u11460
u11461:
	goto	l7472
u11460:
	line	155
	
l347:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
global __ptext2
__ptext2:	;psect for function _uart_init
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_init: []
	line	23
	
l7274:	
;uart_dbg.c: 23: TRISC &= (unsigned char)~0x10;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
;uart_dbg.c: 24: ANSEL2 &= (unsigned char)~0x10;
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
;uart_dbg.c: 25: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l502:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
global __ptext3
__ptext3:	;psect for function _AD_Init
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l7268:	
;adc_drv.c: 25: CC0CON = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
;adc_drv.c: 26: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	27
	
l7270:	
;adc_drv.c: 27: ADCON0 = 0X81;
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l7272:	
;adc_drv.c: 28: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	29
	
l479:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 387 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  d               2   56[BANK1 ] int 
;;  t               1   55[BANK1 ] unsigned char 
;;  bat_mv_long     4   50[BANK1 ] unsigned long 
;;  tc              1   54[BANK1 ] unsigned char 
;;  vx_mv           4   46[BANK1 ] unsigned long 
;;  v               2   44[BANK1 ] unsigned int 
;;  s               1   41[BANK1 ] unsigned char 
;;  pt              4   37[BANK1 ] unsigned long 
;;  vcc_mv          2    0[BANK3 ] unsigned int 
;;  i               1   58[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      26       2       0
;;      Temps:          0       0       8       0       0
;;      Totals:         0       0      34       2       0
;;Total ram usage:       36 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	387
global __ptext4
__ptext4:	;psect for function _Print_SystemStatus
psect	text4
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	387
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	392
	
l7768:	
;main.c: 389: unsigned char i;
;main.c: 390: unsigned int vcc_mv;
;main.c: 392: uart_send_string("\r\n== L1211 12CH CHARGER ");
	movlw	low(((STR_4)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	393
;main.c: 393: uart_send_string("V54R");
	movlw	low(((STR_5)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	394
;main.c: 394: uart_send_string(" ==\r\n");
	movlw	low(((STR_6)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	397
	
l7770:	
;main.c: 397: test_adc = ADC_Sample(31, 0);
	bsf	status, 5	;RP0=1, select bank1
	clrf	(ADC_Sample@adldo)^080h
	movlw	low(01Fh)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	398
	
l7772:	
;main.c: 398: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u12081
	goto	u12080
u12081:
	goto	l7778
u12080:
	line	400
	
l7774:	
;main.c: 399: {
;main.c: 400: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt)^080h

	line	401
	
l7776:	
;main.c: 401: vcc_mv = (unsigned int)pt;
	movf	(Print_SystemStatus@pt+1)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@vcc_mv+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@pt)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@vcc_mv)^0180h
	line	402
;main.c: 402: }
	goto	l420
	line	404
	
l7778:	
;main.c: 403: else
;main.c: 404: vcc_mv = 5000;
	movlw	088h
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@vcc_mv)^0180h
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv)^0180h)+1
	
l420:	
	line	406
;main.c: 406: g_vcc_mv = vcc_mv;
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_vcc_mv+1)^080h	;volatile
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_vcc_mv)^080h	;volatile
	line	408
	
l7780:	
;main.c: 408: uart_send_string("VCC=");
	movlw	low(((STR_7)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	409
	
l7782:	
;main.c: 409: uart_send_number(vcc_mv);
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	410
	
l7784:	
;main.c: 410: uart_send_string("mV T=");
	movlw	low(((STR_8)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	411
	
l7786:	
;main.c: 411: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(_Print_SystemStatus$745+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(_Print_SystemStatus$745)^080h
	
l7788:	
;main.c: 411: uart_send_number(g_temperature / 10U);
	movf	(_Print_SystemStatus$745+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$745)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	412
	
l7790:	
;main.c: 412: uart_send_string(".");
	movlw	low(((STR_9)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	413
	
l7792:	
;main.c: 413: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@divisor)^080h
	clrf	(___lwmod@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend)^080h
	fcall	___lwmod
	movf	(1+(?___lwmod))^080h,w
	movwf	(_Print_SystemStatus$746+1)^080h
	movf	(0+(?___lwmod))^080h,w
	movwf	(_Print_SystemStatus$746)^080h
	
l7794:	
;main.c: 413: uart_send_number(g_temperature % 10U);
	movf	(_Print_SystemStatus$746+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$746)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	414
	
l7796:	
;main.c: 414: uart_send_string("C IMP_LOCK=");
	movlw	low(((STR_10)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	415
	
l7798:	
;main.c: 415: uart_send_number(g_impCheckSlot == 0xFF ? 0xFFU : (unsigned int)g_impCheckSlot);
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u12091
	goto	u12090
u12091:
	goto	l7802
u12090:
	
l7800:	
	movf	(_g_impCheckSlot)^080h,w
	movwf	(_Print_SystemStatus$277)^080h
	clrf	(_Print_SystemStatus$277+1)^080h
	goto	l7804
	
l7802:	
	movlw	0FFh
	movwf	(_Print_SystemStatus$277)^080h
	clrf	(_Print_SystemStatus$277+1)^080h
	
l7804:	
	movf	(_Print_SystemStatus$277+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$277)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	416
	
l7806:	
;main.c: 416: uart_send_string("\r\n");
	movlw	low(((STR_11)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	423
	
l7808:	
;main.c: 423: for(i = 0; i < 12; i++)
	bsf	status, 5	;RP0=1, select bank1
	clrf	(Print_SystemStatus@i)^080h
	line	429
	
l7814:	
;main.c: 428: {
;main.c: 429: unsigned int v = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Print_SystemStatus@v)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)^080h
	line	430
;main.c: 430: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Print_SystemStatus@s)^080h
	line	432
	
l7816:	
;main.c: 432: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	433
	
l7818:	
;main.c: 433: uart_send_number((unsigned int)i + 1U);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@i)^080h,w
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	incf	(uart_send_number@num)^080h,f
	skipnz
	incf	(uart_send_number@num+1)^080h,f
	fcall	_uart_send_number
	line	434
;main.c: 434: uart_send_char('=');
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	435
	
l7820:	
;main.c: 435: uart_send_number(v);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(Print_SystemStatus@v)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	441
	
l7822:	
;main.c: 440: {
;main.c: 441: unsigned long vx_mv = (unsigned long)v * (unsigned long)vcc_mv / 4096UL;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Print_SystemStatus@v+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv)^080h

	
l7824:	
	movlw	0Ch
u12105:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3)^080h,f
	rrf	(Print_SystemStatus@vx_mv+2)^080h,f
	rrf	(Print_SystemStatus@vx_mv+1)^080h,f
	rrf	(Print_SystemStatus@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u12105

	line	442
	
l7826:	
;main.c: 442: if(vx_mv + 200U >= (unsigned long)vcc_mv)
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+0)^080h+0)
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	clrf	((??_Print_SystemStatus+0)^080h+0+2)
	clrf	((??_Print_SystemStatus+0)^080h+0+3)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+4)^080h+0)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	(Print_SystemStatus@vx_mv)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+0,f
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1)^080h,w
	goto	u12110
	goto	u12111
u12110:
	addwf	(??_Print_SystemStatus+4)^080h+1,f
u12111:
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2)^080h,w
	goto	u12112
	goto	u12113
u12112:
	addwf	(??_Print_SystemStatus+4)^080h+2,f
u12113:
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	subwf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u12125
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	subwf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u12125
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	subwf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u12125
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	subwf	0+(??_Print_SystemStatus+4)^080h+0,w
u12125:
	skipc
	goto	u12121
	goto	u12120
u12121:
	goto	l7830
u12120:
	line	444
	
l7828:	
;main.c: 443: {
;main.c: 444: uart_send_string(" OPEN");
	movlw	low(((STR_12)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	445
;main.c: 445: }
	goto	l7840
	line	448
	
l7830:	
;main.c: 446: else
;main.c: 447: {
;main.c: 448: unsigned long bat_mv_long = 124UL * vx_mv;
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(Print_SystemStatus@vx_mv)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long)^080h

	line	449
;main.c: 449: if(bat_mv_long > (206UL * (unsigned long)vcc_mv))
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(Print_SystemStatus@bat_mv_long+3)^080h,w
	subwf	(3+(?___lmul))^080h,w
	skipz
	goto	u12135
	movf	(Print_SystemStatus@bat_mv_long+2)^080h,w
	subwf	(2+(?___lmul))^080h,w
	skipz
	goto	u12135
	movf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	subwf	(1+(?___lmul))^080h,w
	skipz
	goto	u12135
	movf	(Print_SystemStatus@bat_mv_long)^080h,w
	subwf	(0+(?___lmul))^080h,w
u12135:
	skipnc
	goto	u12131
	goto	u12130
u12131:
	goto	l7840
u12130:
	line	451
	
l7832:	
;main.c: 450: {
;main.c: 451: bat_mv_long = (bat_mv_long - 206UL * (unsigned long)vcc_mv + 1000UL/2UL) / 1000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+3)
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@vcc_mv+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+1)^080h
	movlw	032h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(Print_SystemStatus@bat_mv_long)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+0)
	movlw	0
	skipnc
	movlw	1
	addwf	(1+(?___lmul))^080h,w
	clrf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	addwf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	movf	(2+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+2),w
	clrf	((??_Print_SystemStatus+4)^080h+0+3)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	addwf	(Print_SystemStatus@bat_mv_long+2)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	movf	(3+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+3),w
	addwf	(Print_SystemStatus@bat_mv_long+3)^080h,w
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	0+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+0,f
	movf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	1+(??_Print_SystemStatus+4)^080h+0,w
	goto	u12140
	goto	u12141
u12140:
	addwf	(??_Print_SystemStatus+0)^080h+1,f
u12141:
	movf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	2+(??_Print_SystemStatus+4)^080h+0,w
	goto	u12142
	goto	u12143
u12142:
	addwf	(??_Print_SystemStatus+0)^080h+2,f
u12143:
	movf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incf	3+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@bat_mv_long)^080h

	line	452
	
l7834:	
;main.c: 452: uart_send_string(" BAT(");
	movlw	low(((STR_13)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	453
	
l7836:	
;main.c: 453: uart_send_number((unsigned int)bat_mv_long);
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@bat_mv_long+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(Print_SystemStatus@bat_mv_long)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	454
	
l7838:	
;main.c: 454: uart_send_string("mV)");
	movlw	low(((STR_14)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	461
	
l7840:	
;main.c: 455: }
;main.c: 457: }
;main.c: 458: }
;main.c: 461: uart_send_char(' ');
	movlw	low(020h)
	fcall	_uart_send_char
	line	462
;main.c: 462: switch(s)
	goto	l7896
	line	464
	
l7842:	
	movlw	low(((STR_15)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7898
	line	466
	
l7844:	
;main.c: 466: uart_send_string("[DET]");
	movlw	low(((STR_16)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	469
	
l7846:	
;main.c: 469: if(g_slotRefV[i] > 0U)
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Print_SystemStatus@i)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)^080h+0+1
	movf	((??_Print_SystemStatus+0)^080h+0),w
iorwf	((??_Print_SystemStatus+0)^080h+1),w
	btfsc	status,2
	goto	u12151
	goto	u12150
u12151:
	goto	l7898
u12150:
	line	471
	
l7848:	
;main.c: 470: {
;main.c: 471: uart_send_string(" ref=");
	movlw	low(((STR_17)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	472
	
l7850:	
;main.c: 472: uart_send_number(g_slotRefV[i]);
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Print_SystemStatus@i)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(uart_send_number@num)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	goto	l7898
	line	475
	
l7852:	
	movlw	low(((STR_18)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7898
	line	476
	
l7854:	
	movlw	low(((STR_19)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7898
	line	477
	
l7856:	
	movlw	low(((STR_20)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7898
	line	478
	
l7858:	
	movlw	low(((STR_21)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7898
	line	479
	
l7860:	
	movlw	low(((STR_22)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7898
	line	482
	
l7862:	
;main.c: 481: {
;main.c: 482: unsigned char t = g_slot[(unsigned char)(i)].type;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Print_SystemStatus@t)^080h
	line	483
	
l7864:	
;main.c: 483: if(t == 2 || t == 3)
		movlw	2
	xorwf	((Print_SystemStatus@t)^080h),w
	btfsc	status,2
	goto	u12161
	goto	u12160
u12161:
	goto	l7868
u12160:
	
l7866:	
		movlw	3
	xorwf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u12171
	goto	u12170
u12171:
	goto	l7870
u12170:
	line	484
	
l7868:	
;main.c: 484: uart_send_string("[Dry/NiMH ERR]");
	movlw	low(((STR_23)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7880
	line	485
	
l7870:	
;main.c: 485: else if(t == 1)
		decf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u12181
	goto	u12180
u12181:
	goto	l7874
u12180:
	line	486
	
l7872:	
;main.c: 486: uart_send_string("[Li-ion ERR]");
	movlw	low(((STR_24)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7880
	line	487
	
l7874:	
;main.c: 487: else if(t == 6)
		movlw	6
	xorwf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u12191
	goto	u12190
u12191:
	goto	l7878
u12190:
	line	488
	
l7876:	
;main.c: 488: uart_send_string("[Linear Li ERR]");
	movlw	low(((STR_25)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7880
	line	490
	
l7878:	
;main.c: 489: else
;main.c: 490: uart_send_string("[ERR]");
	movlw	low(((STR_26)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	493
	
l7880:	
;main.c: 493: if(g_slotRefV[i] > 0U)
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(Print_SystemStatus@i)^080h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)^080h+0+1
	movf	((??_Print_SystemStatus+0)^080h+0),w
iorwf	((??_Print_SystemStatus+0)^080h+1),w
	btfsc	status,2
	goto	u12201
	goto	u12200
u12201:
	goto	l7898
u12200:
	line	495
	
l7882:	
;main.c: 494: {
;main.c: 495: uart_send_string(" ref=");
	movlw	low(((STR_27)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7850
	line	500
	
l7886:	
	movlw	low(((STR_28)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7898
	line	502
	
l7888:	
;main.c: 502: uart_send_string("[DIO]");
	movlw	low(((STR_29)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	504
;main.c: 504: uart_send_string(" pre=");
	movlw	low(((STR_30)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	505
	
l7890:	
;main.c: 505: uart_send_number(g_impData & 0x0FFFU);
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(uart_send_number@num)^080h
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	506
;main.c: 506: break;
	goto	l7898
	line	507
	
l7892:	
	movlw	low(((STR_31)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	goto	l7898
	line	462
	
l7896:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@s)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l7842
	xorlw	1^0	; case 1
	skipnz
	goto	l7844
	xorlw	2^1	; case 2
	skipnz
	goto	l7852
	xorlw	3^2	; case 3
	skipnz
	goto	l7854
	xorlw	4^3	; case 4
	skipnz
	goto	l7856
	xorlw	5^4	; case 5
	skipnz
	goto	l7858
	xorlw	6^5	; case 6
	skipnz
	goto	l7860
	xorlw	7^6	; case 7
	skipnz
	goto	l7862
	xorlw	8^7	; case 8
	skipnz
	goto	l7886
	xorlw	9^8	; case 9
	skipnz
	goto	l7888
	goto	l7892
	opt asmopt_pop

	line	511
	
l7898:	
;main.c: 511: uart_send_string(" ct=");
	movlw	low(((STR_32)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	512
	
l7900:	
;main.c: 512: uart_send_number(g_slot[(unsigned char)(i)].chargeTimer);
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(uart_send_number@num)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	513
	
l7902:	
;main.c: 513: uart_send_string(" ty=");
	movlw	low(((STR_33)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	514
;main.c: 514: uart_send_number(g_slot[(unsigned char)(i)].type);
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	movf	(Print_SystemStatus@i)^080h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	519
	
l7904:	
;main.c: 519: if(g_diodeTraceCnt > 0U && g_diodeTraceSlot == i)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	((_g_diodeTraceCnt)^080h),w
	btfsc	status,2
	goto	u12211
	goto	u12210
u12211:
	goto	l7940
u12210:
	
l7906:	
	movf	(_g_diodeTraceSlot)^080h,w
	xorwf	(Print_SystemStatus@i)^080h,w
	skipz
	goto	u12221
	goto	u12220
u12221:
	goto	l7940
u12220:
	line	522
	
l7908:	
;main.c: 520: {
;main.c: 521: unsigned char tc;
;main.c: 522: uart_send_string(" tr=");
	movlw	low(((STR_34)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_34)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	523
	
l7910:	
;main.c: 523: for(tc = 0; tc < g_diodeTraceCnt; tc++)
	bsf	status, 5	;RP0=1, select bank1
	clrf	(Print_SystemStatus@tc)^080h
	goto	l7934
	line	525
	
l7912:	
;main.c: 524: {
;main.c: 525: signed int d = (signed int)g_diodeTrace[tc] - 128;
	movf	(Print_SystemStatus@tc)^080h,w
	addlw	low(_g_diodeTrace|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(Print_SystemStatus@d)^080h
	clrf	(Print_SystemStatus@d+1)^080h
	
l7914:	
	movlw	-128
	addwf	(Print_SystemStatus@d)^080h,f
	skipc
	decf	(Print_SystemStatus@d+1)^080h,f
	line	526
	
l7916:	
;main.c: 526: if(d < 0)
	btfss	(Print_SystemStatus@d+1)^080h,7
	goto	u12231
	goto	u12230
u12231:
	goto	l7922
u12230:
	line	528
	
l7918:	
;main.c: 527: {
;main.c: 528: uart_send_char('-');
	movlw	low(02Dh)
	fcall	_uart_send_char
	line	529
	
l7920:	
;main.c: 529: d = -d;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	comf	(Print_SystemStatus@d)^080h,f
	comf	(Print_SystemStatus@d+1)^080h,f
	incf	(Print_SystemStatus@d)^080h,f
	skipnz
	incf	(Print_SystemStatus@d+1)^080h,f
	line	530
;main.c: 530: }
	goto	l7926
	line	531
	
l7922:	
;main.c: 531: else if(d > 0)
	movf	(Print_SystemStatus@d+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u12245
	movlw	01h
	subwf	(Print_SystemStatus@d)^080h,w
u12245:

	skipc
	goto	u12241
	goto	u12240
u12241:
	goto	l7926
u12240:
	line	532
	
l7924:	
;main.c: 532: uart_send_char('+');
	movlw	low(02Bh)
	fcall	_uart_send_char
	line	533
	
l7926:	
;main.c: 533: uart_send_number((unsigned int)d * 4U);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@d+1)^080h,w
	movwf	(??_Print_SystemStatus+0)^080h+0+1
	movf	(Print_SystemStatus@d)^080h,w
	movwf	(??_Print_SystemStatus+0)^080h+0
	clrc
	rlf	(??_Print_SystemStatus+0)^080h+0,f
	rlf	(??_Print_SystemStatus+0)^080h+1,f
	clrc
	rlf	(??_Print_SystemStatus+0)^080h+0,f
	rlf	(??_Print_SystemStatus+0)^080h+1,f
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(uart_send_number@num)^080h
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	534
	
l7928:	
;main.c: 534: if(tc + 1U < g_diodeTraceCnt)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_diodeTraceCnt)^080h,w
	movwf	(??_Print_SystemStatus+0)^080h+0
	clrf	(??_Print_SystemStatus+0)^080h+0+1
	movf	(Print_SystemStatus@tc)^080h,w
	addlw	low(01h)
	movwf	(??_Print_SystemStatus+2)^080h+0
	movlw	high(01h)
	skipnc
	movlw	(high(01h)+1)&0ffh
	movwf	((??_Print_SystemStatus+2)^080h+0)+1
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	subwf	1+(??_Print_SystemStatus+2)^080h+0,w
	skipz
	goto	u12255
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	subwf	0+(??_Print_SystemStatus+2)^080h+0,w
u12255:
	skipnc
	goto	u12251
	goto	u12250
u12251:
	goto	l7932
u12250:
	line	535
	
l7930:	
;main.c: 535: uart_send_char(',');
	movlw	low(02Ch)
	fcall	_uart_send_char
	line	523
	
l7932:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(Print_SystemStatus@tc)^080h,f
	
l7934:	
	movf	(_g_diodeTraceCnt)^080h,w
	subwf	(Print_SystemStatus@tc)^080h,w
	skipc
	goto	u12261
	goto	u12260
u12261:
	goto	l7912
u12260:
	line	537
	
l7936:	
;main.c: 536: }
;main.c: 537: g_diodeTraceCnt = 0;
	clrf	(_g_diodeTraceCnt)^080h
	line	538
	
l7938:	
;main.c: 538: g_diodeTraceSlot = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_diodeTraceSlot)^080h
	line	542
	
l7940:	
;main.c: 539: }
;main.c: 542: uart_send_string("\r\n");
	movlw	low(((STR_35)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_35)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	423
	
l7942:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(Print_SystemStatus@i)^080h,f
	
l7944:	
	movlw	low(0Ch)
	subwf	(Print_SystemStatus@i)^080h,w
	skipc
	goto	u12271
	goto	u12270
u12271:
	goto	l7814
u12270:
	line	545
	
l7946:	
;main.c: 544: }
;main.c: 545: uart_send_string("\r\n");
	movlw	low(((STR_36)|8000h))
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_36)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	546
	
l461:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 367 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	367
global __ptext5
__ptext5:	;psect for function _Print_NtcTemp
psect	text5
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	367
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	369
	
l7756:	
;main.c: 369: uart_send_string("NTC=");
	movlw	low(((STR_1)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	370
	
l7758:	
;main.c: 370: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(_Print_NtcTemp$743+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(_Print_NtcTemp$743)^080h
	
l7760:	
;main.c: 370: uart_send_number(g_temperature / 10U);
	movf	(_Print_NtcTemp$743+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$743)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	371
	
l7762:	
;main.c: 371: uart_send_string(".");
	movlw	low(((STR_2)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	372
	
l7764:	
;main.c: 372: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@divisor)^080h
	clrf	(___lwmod@divisor+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_temperature),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwmod@dividend)^080h
	fcall	___lwmod
	movf	(1+(?___lwmod))^080h,w
	movwf	(_Print_NtcTemp$744+1)^080h
	movf	(0+(?___lwmod))^080h,w
	movwf	(_Print_NtcTemp$744)^080h
;main.c: 372: uart_send_number(g_temperature % 10U);
	movf	(_Print_NtcTemp$744+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$744)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	373
	
l7766:	
;main.c: 373: uart_send_string("C\r\n");
	movlw	low(((STR_3)|8000h))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_string@str)^080h
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str)^080h)+1
	fcall	_uart_send_string
	line	374
	
l416:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2    3[BANK1 ] PTR const unsigned char 
;;		 -> STR_38(10), STR_37(21), STR_36(3), STR_35(3), 
;;		 -> STR_34(5), STR_33(5), STR_32(5), STR_31(6), 
;;		 -> STR_30(6), STR_29(6), STR_28(6), STR_27(6), 
;;		 -> STR_26(6), STR_25(16), STR_24(13), STR_23(15), 
;;		 -> STR_22(7), STR_21(5), STR_20(5), STR_19(6), 
;;		 -> STR_18(6), STR_17(6), STR_16(6), STR_15(7), 
;;		 -> STR_14(4), STR_13(6), STR_12(6), STR_11(3), 
;;		 -> STR_10(12), STR_9(2), STR_8(6), STR_7(5), 
;;		 -> STR_6(6), STR_5(5), STR_4(25), STR_3(4), 
;;		 -> STR_2(2), STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
global __ptext6
__ptext6:	;psect for function _uart_send_string
psect	text6
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l7314:	
;uart_dbg.c: 63: while(*str != '\0')
	goto	l7320
	line	65
	
l7316:	
;uart_dbg.c: 64: {
;uart_dbg.c: 65: uart_send_char(*str++);
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	btemp+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str)^080h,w
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	fcall	stringtab
	fcall	_uart_send_char
	
l7318:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(uart_send_string@str)^080h,f
	skipnz
	incf	(uart_send_string@str+1)^080h,f
	line	66
# 66 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
clrwdt ;# 
psect	text6
	line	63
	
l7320:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(uart_send_string@str+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	btemp+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_string@str)^080h,w
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u11321
	goto	u11320
u11321:
	goto	l7316
u11320:
	line	68
	
l515:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2    7[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    9[BANK1 ] unsigned char [6]
;;  j               1   16[BANK1 ] unsigned char 
;;  i               1   15[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      10       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext7
__ptext7:	;psect for function _uart_send_number
psect	text7
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 2
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l7322:	
;uart_dbg.c: 79: unsigned char buf[6];
;uart_dbg.c: 80: unsigned char i = 0;
	clrf	(uart_send_number@i)^080h
	line	84
	
l7324:	
;uart_dbg.c: 81: unsigned char j;
;uart_dbg.c: 84: if(num == 0)
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u11331
	goto	u11330
u11331:
	goto	l7336
u11330:
	line	86
	
l7326:	
;uart_dbg.c: 85: {
;uart_dbg.c: 86: uart_send_char('0');
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l519
	line	93
	
l7330:	
;uart_dbg.c: 92: {
;uart_dbg.c: 93: buf[i++] = '0' + (num % 10);
	movf	(uart_send_number@i)^080h,w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)^080h
	clrf	(___lwmod@divisor+1)^080h
	movf	(uart_send_number@num+1)^080h,w
	movwf	(___lwmod@dividend+1)^080h
	movf	(uart_send_number@num)^080h,w
	movwf	(___lwmod@dividend)^080h
	fcall	___lwmod
	movf	(0+(?___lwmod))^080h,w
	addlw	030h
	bcf	status, 7	;select IRP bank1
	movwf	indf
	
l7332:	
	incf	(uart_send_number@i)^080h,f
	line	94
	
l7334:	
;uart_dbg.c: 94: num /= 10;
	movlw	0Ah
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(uart_send_number@num+1)^080h,w
	movwf	(___lwdiv@dividend+1)^080h
	movf	(uart_send_number@num)^080h,w
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(uart_send_number@num)^080h
	line	91
	
l7336:	
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u11341
	goto	u11340
u11341:
	goto	l7330
u11340:
	line	98
	
l7338:	
;uart_dbg.c: 95: }
;uart_dbg.c: 98: for(j = i; j > 0; j--)
	movf	(uart_send_number@i)^080h,w
	movwf	(uart_send_number@j)^080h
	
l7340:	
	movf	((uart_send_number@j)^080h),w
	btfss	status,2
	goto	u11351
	goto	u11350
u11351:
	goto	l7344
u11350:
	goto	l519
	line	99
	
l7344:	
;uart_dbg.c: 99: uart_send_char(buf[(unsigned char)(j - 1)]);
	movf	(uart_send_number@j)^080h,w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l7346:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decf	(uart_send_number@j)^080h,f
	goto	l7340
	line	100
	
l519:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1    1[BANK1 ] unsigned char 
;;  i               1    2[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       2       0       0
;;      Temps:          0       0       1       0       0
;;      Totals:         0       0       3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext8
__ptext8:	;psect for function _uart_send_char
psect	text8
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_char: [wreg+status,2+status,0]
;uart_send_char@c stored from wreg
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_char@c)^080h
	line	38
	
l5356:	
;uart_dbg.c: 37: unsigned char i;
;uart_dbg.c: 38: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	39
;uart_dbg.c: 39: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l5358:	
;uart_dbg.c: 40: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_uart_send_char+0)^080h+0),f
	u14547:
decfsz	(??_uart_send_char+0)^080h+0,f
	goto	u14547
	nop2
opt asmopt_pop

	line	41
	
l5360:	
;uart_dbg.c: 41: for(i = 0; i < 8; i++)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(uart_send_char@i)^080h
	line	42
	
l505:	
	line	43
;uart_dbg.c: 42: {
;uart_dbg.c: 43: if(c & 0x01)
	btfss	(uart_send_char@c)^080h,(0)&7
	goto	u7591
	goto	u7590
u7591:
	goto	l507
u7590:
	line	44
	
l5366:	
;uart_dbg.c: 44: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l5368
	line	45
	
l507:	
	line	46
;uart_dbg.c: 45: else
;uart_dbg.c: 46: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l5368:	
;uart_dbg.c: 47: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_uart_send_char+0)^080h+0),f
	u14557:
decfsz	(??_uart_send_char+0)^080h+0,f
	goto	u14557
	nop2
opt asmopt_pop

	line	48
	
l5370:	
;uart_dbg.c: 48: c >>= 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrc
	rrf	(uart_send_char@c)^080h,f
	line	41
	
l5372:	
	incf	(uart_send_char@i)^080h,f
	
l5374:	
	movlw	low(08h)
	subwf	(uart_send_char@i)^080h,w
	skipc
	goto	u7601
	goto	u7600
u7601:
	goto	l505
u7600:
	
l506:	
	line	50
;uart_dbg.c: 49: }
;uart_dbg.c: 50: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l5376:	
;uart_dbg.c: 51: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_uart_send_char+0)^080h+0),f
	u14567:
decfsz	(??_uart_send_char+0)^080h+0,f
	goto	u14567
	nop2
opt asmopt_pop

	line	52
	
l5378:	
;uart_dbg.c: 52: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l509:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK1 ] unsigned int 
;;  dividend        2    2[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1    4[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK1 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       4       0       0
;;      Locals:         0       0       1       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       5       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext9
__ptext9:	;psect for function ___lwmod
psect	text9
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l7248:	
	movf	((___lwmod@divisor)^080h),w
iorwf	((___lwmod@divisor+1)^080h),w
	btfsc	status,2
	goto	u11181
	goto	u11180
u11181:
	goto	l7264
u11180:
	line	14
	
l7250:	
	clrf	(___lwmod@counter)^080h
	incf	(___lwmod@counter)^080h,f
	line	15
	goto	l7254
	line	16
	
l7252:	
	clrc
	rlf	(___lwmod@divisor)^080h,f
	rlf	(___lwmod@divisor+1)^080h,f
	line	17
	incf	(___lwmod@counter)^080h,f
	line	15
	
l7254:	
	btfss	(___lwmod@divisor+1)^080h,(15)&7
	goto	u11191
	goto	u11190
u11191:
	goto	l7252
u11190:
	line	20
	
l7256:	
	movf	(___lwmod@divisor+1)^080h,w
	subwf	(___lwmod@dividend+1)^080h,w
	skipz
	goto	u11205
	movf	(___lwmod@divisor)^080h,w
	subwf	(___lwmod@dividend)^080h,w
u11205:
	skipc
	goto	u11201
	goto	u11200
u11201:
	goto	l7260
u11200:
	line	21
	
l7258:	
	movf	(___lwmod@divisor)^080h,w
	subwf	(___lwmod@dividend)^080h,f
	movf	(___lwmod@divisor+1)^080h,w
	skipc
	decf	(___lwmod@dividend+1)^080h,f
	subwf	(___lwmod@dividend+1)^080h,f
	line	22
	
l7260:	
	clrc
	rrf	(___lwmod@divisor+1)^080h,f
	rrf	(___lwmod@divisor)^080h,f
	line	23
	
l7262:	
	decfsz	(___lwmod@counter)^080h,f
	goto	u11211
	goto	u11210
u11211:
	goto	l7256
u11210:
	line	25
	
l7264:	
	movf	(___lwmod@dividend+1)^080h,w
	movwf	(?___lwmod+1)^080h
	movf	(___lwmod@dividend)^080h,w
	movwf	(?___lwmod)^080h
	line	26
	
l1273:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	_Do_NtcRead

;; *************** function _Do_NtcRead *****************
;; Defined at:
;;		line 357 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Read_Temperature
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	357
global __ptext10
__ptext10:	;psect for function _Do_NtcRead
psect	text10
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	357
	global	__size_of_Do_NtcRead
	__size_of_Do_NtcRead	equ	__end_of_Do_NtcRead-_Do_NtcRead
	
_Do_NtcRead:	
;incstack = 0
	opt	stack 2
; Regs used in _Do_NtcRead: [wreg+status,2+status,0+pclath+cstack]
	line	359
	
l7754:	
;main.c: 359: Read_Temperature();
	fcall	_Read_Temperature
	line	360
	
l413:	
	return
	opt stack 0
GLOBAL	__end_of_Do_NtcRead
	__end_of_Do_NtcRead:
	signat	_Do_NtcRead,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 43 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   29[BANK1 ] unsigned long 
;;  temp_x10        2   35[BANK1 ] unsigned int 
;;  ntcVal          2   33[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   62[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Do_NtcRead
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	43
global __ptext11
__ptext11:	;psect for function _Read_Temperature
psect	text11
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	43
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 2
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	48
	
l7276:	
;charge_mgr.c: 45: unsigned int ntcVal;
;charge_mgr.c: 46: unsigned int temp_x10;
;charge_mgr.c: 48: test_adc = ADC_Sample(18, 0);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ADC_Sample@adldo)^080h
	movlw	low(012h)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	49
	
l7278:	
;charge_mgr.c: 49: if(0xA5 != test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u11221
	goto	u11220
u11221:
	goto	l7282
u11220:
	goto	l558
	line	52
	
l7282:	
;charge_mgr.c: 52: ntcVal = adresult;
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal)^080h
	line	53
;charge_mgr.c: 53: if(ntcVal < 100 || ntcVal > 3996)
	movlw	0
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u11231
	goto	u11230
u11231:
	goto	l558
u11230:
	
l7284:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u11241
	goto	u11240
u11241:
	goto	l7286
u11240:
	goto	l558
	line	58
	
l7286:	
;charge_mgr.c: 56: {
;charge_mgr.c: 57: unsigned long rt;
;charge_mgr.c: 58: rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	010h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0
	movwf	(___lldiv@divisor)^080h

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0)
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0+1)
	clrf	((??_Read_Temperature+0)^080h+0+2)
	clrf	((??_Read_Temperature+0)^080h+0+3)
	movf	0+(??_Read_Temperature+0)^080h+0,w
	subwf	(___lldiv@divisor)^080h,f
	movf	1+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)^080h+0,w
	goto	u11255
	goto	u11256
u11255:
	subwf	(___lldiv@divisor+1)^080h,f
u11256:
	movf	2+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)^080h+0,w
	goto	u11257
	goto	u11258
u11257:
	subwf	(___lldiv@divisor+2)^080h,f
u11258:
	movf	3+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)^080h+0,w
	goto	u11259
	goto	u11250
u11259:
	subwf	(___lldiv@divisor+3)^080h,f
u11250:

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0
	movwf	(___lmul@multiplicand+2)^080h
	movlw	027h
	movwf	(___lmul@multiplicand+1)^080h
	movlw	010h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt)^080h

	line	59
	
l7288:	
;charge_mgr.c: 59: if(rt >= 10000UL)
		movf	(Read_Temperature@rt+3)^080h,w
	btfss	status,2
	goto	u11260
	movf	(Read_Temperature@rt+2)^080h,w
	btfss	status,2
	goto	u11260
	movlw	39
	subwf	(Read_Temperature@rt+1)^080h,w
	skipz
	goto	u11263
	movlw	16
	subwf	(Read_Temperature@rt)^080h,w
	skipz
	goto	u11263
u11263:
	btfss	status,0
	goto	u11261
	goto	u11260

u11261:
	goto	l7294
u11260:
	line	60
	
l7290:	
;charge_mgr.c: 60: temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l7292:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0F0h
	movwf	((??_Read_Temperature+0)^080h+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)^080h+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+3)
	movf	(Read_Temperature@rt)^080h,w
	addwf	(??_Read_Temperature+0)^080h+0,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+1)^080h,w
	goto	u11270
	goto	u11271
u11270:
	addwf	(??_Read_Temperature+0)^080h+1,f
u11271:
	movf	(Read_Temperature@rt+2)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+2)^080h,w
	goto	u11272
	goto	u11273
u11272:
	addwf	(??_Read_Temperature+0)^080h+2,f
u11273:
	movf	(Read_Temperature@rt+3)^080h,w
	skipnc
	incf	(Read_Temperature@rt+3)^080h,w
	addwf	(??_Read_Temperature+0)^080h+3,f
	movf	3+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+3)^080h
	movf	2+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+2)^080h
	movf	1+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+1)^080h
	movf	0+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier)^080h

	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(0+(?___lldiv))^080h,w
	subwf	(Read_Temperature@temp_x10)^080h,f
	movf	(1+(?___lldiv))^080h,w
	skipc
	decf	(Read_Temperature@temp_x10+1)^080h,f
	subwf	(Read_Temperature@temp_x10+1)^080h,f
	goto	l7298
	line	62
	
l7294:	
;charge_mgr.c: 61: else
;charge_mgr.c: 62: temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0
	movwf	(___lmul@multiplier+3)^080h
	movlw	0
	movwf	(___lmul@multiplier+2)^080h
	movlw	027h
	movwf	(___lmul@multiplier+1)^080h
	movlw	010h
	movwf	(___lmul@multiplier)^080h

	movf	(Read_Temperature@rt)^080h,w
	subwf	(___lmul@multiplier)^080h,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+1)^080h,w
	subwf	(___lmul@multiplier+1)^080h,f
	movf	(Read_Temperature@rt+2)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+2)^080h,w
	subwf	(___lmul@multiplier+2)^080h,f
	movf	(Read_Temperature@rt+3)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+3)^080h,w
	subwf	(___lmul@multiplier+3)^080h,f
	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10)^080h
	
l7296:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10)^080h,f
	skipnc
	incf	(Read_Temperature@temp_x10+1)^080h,f
	line	63
	
l7298:	
;charge_mgr.c: 63: if(temp_x10 < 100U) temp_x10 = 100U;
	movlw	0
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipnc
	goto	u11281
	goto	u11280
u11281:
	goto	l564
u11280:
	
l7300:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l564:	
	line	64
;charge_mgr.c: 64: if(temp_x10 > 750U) temp_x10 = 750U;
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipc
	goto	u11291
	goto	u11290
u11291:
	goto	l565
u11290:
	
l7302:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)^080h
	movlw	02h
	movwf	((Read_Temperature@temp_x10)^080h)+1
	
l565:	
	line	67
;charge_mgr.c: 65: }
;charge_mgr.c: 67: g_temperature = temp_x10;
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature)
	line	68
	
l7304:	
;charge_mgr.c: 68: if((temp_x10 / 10U) >= 60)
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(Read_Temperature@temp_x10+1)^080h,w
	movwf	(___lwdiv@dividend+1)^080h
	movf	(Read_Temperature@temp_x10)^080h,w
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv))^080h,w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv))^080h,w
	skipc
	goto	u11301
	goto	u11300
u11301:
	goto	l7308
u11300:
	line	69
	
l7306:	
;charge_mgr.c: 69: g_tempProtect = 1;
	clrf	(_g_tempProtect)
	incf	(_g_tempProtect),f
	goto	l558
	line	70
	
l7308:	
;charge_mgr.c: 70: else if((temp_x10 / 10U) <= 50)
	movlw	0Ah
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(Read_Temperature@temp_x10+1)^080h,w
	movwf	(___lwdiv@dividend+1)^080h
	movf	(Read_Temperature@temp_x10)^080h,w
	movwf	(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv))^080h,w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv))^080h,w
	skipnc
	goto	u11311
	goto	u11310
u11311:
	goto	l558
u11310:
	line	71
	
l7310:	
;charge_mgr.c: 71: g_tempProtect = 0;
	clrf	(_g_tempProtect)
	line	74
	
l558:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	_Do_AdcSample

;; *************** function _Do_AdcSample *****************
;; Defined at:
;;		line 285 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  st              1   22[BANK1 ] unsigned char 
;;  dly             1   21[BANK1 ] unsigned char 
;;  ty              1   20[BANK1 ] unsigned char 
;;  ch              1   19[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       0       1       0       0
;;      Totals:         0       0       5       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	285
global __ptext12
__ptext12:	;psect for function _Do_AdcSample
psect	text12
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	285
	global	__size_of_Do_AdcSample
	__size_of_Do_AdcSample	equ	__end_of_Do_AdcSample-_Do_AdcSample
	
_Do_AdcSample:	
;incstack = 0
	opt	stack 3
; Regs used in _Do_AdcSample: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	287
	
l7690:	
;main.c: 287: unsigned char ch = s_adcChannels[g_scanIndex];
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_scanIndex),w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@ch)^080h
	line	288
	
l7692:	
;main.c: 288: unsigned char ty = g_slot[(unsigned char)(g_scanIndex)].type;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Do_AdcSample@ty)^080h
	line	289
	
l7694:	
;main.c: 289: unsigned char st = g_slot[(unsigned char)(g_scanIndex)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Do_AdcSample@st)^080h
	line	310
	
l7696:	
;main.c: 290: unsigned char dly;
;main.c: 305: if((ty == 6 &&
;main.c: 306: (st == 2 || st == 3 ||
;main.c: 307: st == 4 || st == 5)) ||
;main.c: 308: st == 1 ||
;main.c: 309: st == 8 ||
;main.c: 310: st == 9)
		movlw	6
	xorwf	((Do_AdcSample@ty)^080h),w
	btfss	status,2
	goto	u11911
	goto	u11910
u11911:
	goto	l7706
u11910:
	
l7698:	
		movlw	2
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11921
	goto	u11920
u11921:
	goto	l7712
u11920:
	
l7700:	
		movlw	3
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11931
	goto	u11930
u11931:
	goto	l7712
u11930:
	
l7702:	
		movlw	4
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11941
	goto	u11940
u11941:
	goto	l7712
u11940:
	
l7704:	
		movlw	5
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11951
	goto	u11950
u11951:
	goto	l7712
u11950:
	
l7706:	
		decf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11961
	goto	u11960
u11961:
	goto	l7712
u11960:
	
l7708:	
		movlw	8
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11971
	goto	u11970
u11971:
	goto	l7712
u11970:
	
l7710:	
		movlw	9
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u11981
	goto	u11980
u11981:
	goto	l7730
u11980:
	line	314
	
l7712:	
;main.c: 311: {
;main.c: 314: if(st == 1 || st == 8 || st == 9)
		decf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u11991
	goto	u11990
u11991:
	goto	l7718
u11990:
	
l7714:	
		movlw	8
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u12001
	goto	u12000
u12001:
	goto	l7718
u12000:
	
l7716:	
		movlw	9
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u12011
	goto	u12010
u12011:
	goto	l7730
u12010:
	line	316
	
l7718:	
;main.c: 315: {
;main.c: 316: for(dly = 0; dly < 20; dly++)
	clrf	(Do_AdcSample@dly)^080h
	line	317
	
l7724:	
;main.c: 317: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_Do_AdcSample+0)^080h+0),f
	u14577:
decfsz	(??_Do_AdcSample+0)^080h+0,f
	goto	u14577
	nop
opt asmopt_pop

	line	316
	
l7726:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(Do_AdcSample@dly)^080h,f
	
l7728:	
	movlw	low(014h)
	subwf	(Do_AdcSample@dly)^080h,w
	skipc
	goto	u12021
	goto	u12020
u12021:
	goto	l7724
u12020:
	goto	l7734
	line	321
	
l7730:	
;main.c: 319: else
;main.c: 320: {
;main.c: 321: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_Do_AdcSample+0)^080h+0),f
	u14587:
decfsz	(??_Do_AdcSample+0)^080h+0,f
	goto	u14587
	nop
opt asmopt_pop

	line	329
	
l7734:	
;main.c: 327: }
;main.c: 329: test_adc = ADC_Sample(ch, 0);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ADC_Sample@adldo)^080h
	movf	(Do_AdcSample@ch)^080h,w
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	331
	
l7736:	
;main.c: 331: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u12031
	goto	u12030
u12031:
	goto	l7750
u12030:
	line	336
	
l7738:	
;main.c: 332: {
;main.c: 335: if(ty == 6 && (st == 4 || st == 5)
;main.c: 336: && adresult >= 3990)
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	((Do_AdcSample@ty)^080h),w
	btfss	status,2
	goto	u12041
	goto	u12040
u12041:
	goto	l7748
u12040:
	
l7740:	
		movlw	4
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u12051
	goto	u12050
u12051:
	goto	l7744
u12050:
	
l7742:	
		movlw	5
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u12061
	goto	u12060
u12061:
	goto	l7748
u12060:
	
l7744:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_adresult+1),w	;volatile
	movlw	096h
	skipnz
	subwf	(_adresult),w	;volatile
	skipc
	goto	u12071
	goto	u12070
u12071:
	goto	l7748
u12070:
	goto	l7752
	line	342
	
l7748:	
;main.c: 340: else
;main.c: 341: {
;main.c: 342: g_slot[g_scanIndex].voltage = adresult;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_adresult+1),w	;volatile
	movwf	indf
	goto	l7752
	line	346
	
l7750:	
;main.c: 345: else
;main.c: 346: g_slot[g_scanIndex].voltage = 0;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___bmul@multiplicand)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	348
	
l7752:	
;main.c: 348: g_scanPhase = 1;
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_scanPhase)	;volatile
	line	349
	
l410:	
	return
	opt stack 0
GLOBAL	__end_of_Do_AdcSample
	__end_of_Do_AdcSample:
	signat	_Do_AdcSample,89
	global	_ChargeProcess_Slot

;; *************** function _ChargeProcess_Slot *****************
;; Defined at:
;;		line 153 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   19[BANK3 ] unsigned char 
;;  tc              1    2[BANK3 ] unsigned char 
;;  hasRise         1   58[BANK1 ] unsigned char 
;;  pre             2   11[BANK3 ] unsigned int 
;;  bat_mv_long     4   36[BANK1 ] unsigned long 
;;  vx_mv           4   32[BANK1 ] unsigned long 
;;  bat_mv          2    3[BANK3 ] unsigned int 
;;  diff            2    9[BANK3 ] int 
;;  bat_mv_long     4   52[BANK1 ] unsigned long 
;;  vx_mv           4   48[BANK1 ] unsigned long 
;;  bat_mv          2    7[BANK3 ] unsigned int 
;;  bat_mv_long     4   44[BANK1 ] unsigned long 
;;  vx_mv           4   40[BANK1 ] unsigned long 
;;  bat_mv          2    5[BANK3 ] unsigned int 
;;  v_ref           2    0[BANK3 ] unsigned int 
;;  v_init          2   30[BANK1 ] unsigned int 
;;  v               2    0[BANK2 ] unsigned int 
;;  ct              2   17[BANK3 ] unsigned int 
;;  tick            2    0        unsigned int 
;;  ty              1   16[BANK3 ] unsigned char 
;;  st              1   15[BANK3 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/B00
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      29      20       2
;;      Temps:          0       0       5       0       0
;;      Totals:         0       0      34      20       2
;;Total ram usage:       56 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		_Detect_BatteryType
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___wmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	153
global __ptext13
__ptext13:	;psect for function _ChargeProcess_Slot
psect	text13
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	153
	global	__size_of_ChargeProcess_Slot
	__size_of_ChargeProcess_Slot	equ	__end_of_ChargeProcess_Slot-_ChargeProcess_Slot
	
_ChargeProcess_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _ChargeProcess_Slot: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
;ChargeProcess_Slot@idx stored from wreg
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@idx)^0180h
	line	157
	
l7948:	
	line	159
	
l7950:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	
l7952:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	
l7954:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(ChargeProcess_Slot@v)^0100h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v+1)^0100h
	
l7956:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ct)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@ct+1)^0180h
	goto	l8838
	line	168
	
l7958:	
;charge_mgr.c: 168: if(v >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12281
	goto	u12280
u12281:
	goto	l7964
u12280:
	line	170
	
l7960:	
;charge_mgr.c: 169: {
;charge_mgr.c: 170: if(ct < (300))
	movlw	01h
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	02Ch
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u12291
	goto	u12290
u12291:
	goto	l7964
u12290:
	line	172
	
l7962:	
;charge_mgr.c: 171: {
;charge_mgr.c: 172: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	173
;charge_mgr.c: 173: break;
	goto	l8840
	line	176
	
l7964:	
;charge_mgr.c: 174: }
;charge_mgr.c: 175: }
;charge_mgr.c: 176: ct = 0;
	bsf	status, 5	;RP0=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	177
	
l7966:	
;charge_mgr.c: 177: st = 1;
	clrf	(ChargeProcess_Slot@st)^0180h
	incf	(ChargeProcess_Slot@st)^0180h,f
	line	178
	
l7968:	
;charge_mgr.c: 178: g_ccBlocks[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	180
	
l7970:	
;charge_mgr.c: 180: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12304
u12305:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12304:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12305
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	183
	
l7972:	
;charge_mgr.c: 183: if(v < 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12311
	goto	u12310
u12311:
	goto	l7976
u12310:
	line	184
	
l7974:	
;charge_mgr.c: 184: g_slotRefV[idx] = v;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	goto	l8840
	line	186
	
l7976:	
;charge_mgr.c: 185: else
;charge_mgr.c: 186: g_slotRefV[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l8840
	line	190
	
l7978:	
;charge_mgr.c: 190: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	193
	
l7980:	
;charge_mgr.c: 193: if(ct == 1)
		decf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u12321
	goto	u12320
u12321:
	goto	l7986
u12320:
	line	195
	
l7982:	
;charge_mgr.c: 194: {
;charge_mgr.c: 195: g_stableCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	196
	
l7984:	
;charge_mgr.c: 196: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12334
u12335:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12334:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12335
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	199
	
l7986:	
;charge_mgr.c: 197: }
;charge_mgr.c: 199: if(ct < (30))
	movlw	0
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	01Eh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u12341
	goto	u12340
u12341:
	goto	l7990
u12340:
	goto	l8840
	line	217
	
l7990:	
;charge_mgr.c: 209: }
;charge_mgr.c: 217: if(ct == (30))
		movlw	30
	xorwf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u12351
	goto	u12350
u12351:
	goto	l7998
u12350:
	line	219
	
l7992:	
;charge_mgr.c: 218: {
;charge_mgr.c: 219: g_slotRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	220
	
l7994:	
;charge_mgr.c: 220: if(v > 2900)
	movlw	0Bh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12361
	goto	u12360
u12361:
	goto	l8840
u12360:
	line	221
	
l7996:	
;charge_mgr.c: 221: g_capFlag |= (unsigned int)1 << idx;
	bsf	status, 5	;RP0=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12374
u12375:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12374:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12375
	
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_capFlag+1)^080h,f
	goto	l8840
	line	224
	
l7998:	
;charge_mgr.c: 223: }
;charge_mgr.c: 224: if(v > 2900 && v < 3990)
	movlw	0Bh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12381
	goto	u12380
u12381:
	goto	l8060
u12380:
	
l8000:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12391
	goto	u12390
u12391:
	goto	l8060
u12390:
	line	236
	
l8002:	
;charge_mgr.c: 225: {
;charge_mgr.c: 235: if(!(g_capFlag & ((unsigned int)1 << idx)) && ty != 5 &&
;charge_mgr.c: 236: v <= 3500)
	bsf	status, 5	;RP0=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12404
u12405:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12404:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12405
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfss	status,2
	goto	u12411
	goto	u12410
u12411:
	goto	l8016
u12410:
	
l8004:	
		movlw	5
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12421
	goto	u12420
u12421:
	goto	l8016
u12420:
	
l8006:	
	movlw	0Dh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0ADh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12431
	goto	u12430
u12431:
	goto	l8016
u12430:
	line	238
	
l8008:	
;charge_mgr.c: 237: {
;charge_mgr.c: 238: ct = 0;
	bsf	status, 5	;RP0=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	239
	
l8010:	
;charge_mgr.c: 239: g_slotRefV[idx] = 0;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	240
	
l8012:	
;charge_mgr.c: 240: g_stableCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	241
	
l8014:	
;charge_mgr.c: 241: g_detectLowCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	clrf	indf
	line	242
;charge_mgr.c: 242: break;
	goto	l8840
	line	252
	
l8016:	
;charge_mgr.c: 243: }
;charge_mgr.c: 252: unsigned int v_init = g_slotRefV[idx];
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@v_init)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_init+1)^080h
	line	254
;charge_mgr.c: 254: if(g_stableCnt[idx] >= 20)
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipc
	goto	u12441
	goto	u12440
u12441:
	goto	l8046
u12440:
	line	259
	
l8018:	
;charge_mgr.c: 255: {
;charge_mgr.c: 259: g_highVFlag |= (unsigned int)1 << idx;
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12454
u12455:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12454:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12455
	
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_highVFlag+1)^080h,f
	line	261
	
l8020:	
;charge_mgr.c: 261: if(v <= 2900)
	movlw	0Bh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12461
	goto	u12460
u12461:
	goto	l8028
u12460:
	line	264
	
l8022:	
;charge_mgr.c: 262: {
;charge_mgr.c: 264: g_capFlag &= ~((unsigned int)1 << idx);
	bsf	status, 5	;RP0=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12474
u12475:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12474:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12475
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	265
	
l8024:	
;charge_mgr.c: 265: g_stableCnt[idx] = 0;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	266
	
l8026:	
;charge_mgr.c: 266: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12484
u12485:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12484:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12485
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	267
;charge_mgr.c: 267: }
	goto	l8072
	line	268
	
l8028:	
;charge_mgr.c: 268: else if(ct < (30) + (100))
	movlw	0
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	082h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u12491
	goto	u12490
u12491:
	goto	l8040
u12490:
	line	277
	
l8030:	
;charge_mgr.c: 269: {
;charge_mgr.c: 276: if((g_highVFlag & ((unsigned int)1 << idx)) &&
;charge_mgr.c: 277: ct >= (30) + 25U)
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12504
u12505:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12504:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12505
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u12511
	goto	u12510
u12511:
	goto	l7974
u12510:
	
l8032:	
	movlw	0
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	037h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12521
	goto	u12520
u12521:
	goto	l7974
u12520:
	line	290
	
l8040:	
;charge_mgr.c: 290: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12534
u12535:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12534:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12535
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	291
	
l8042:	
;charge_mgr.c: 291: g_stableCnt[idx] = 0;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	292
	
l8044:	
;charge_mgr.c: 292: ty = 5;
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	293
;charge_mgr.c: 293: goto amb_check;
	goto	l8102
	line	299
	
l8046:	
;charge_mgr.c: 296: else
;charge_mgr.c: 297: {
;charge_mgr.c: 299: if(v + 50 < v_init)
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	addlw	low(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(ChargeProcess_Slot@v_init+1)^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u12545
	movf	(ChargeProcess_Slot@v_init)^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u12545:
	skipnc
	goto	u12541
	goto	u12540
u12541:
	goto	l8050
u12540:
	line	302
	
l8048:	
;charge_mgr.c: 300: {
;charge_mgr.c: 302: g_slotRefV[idx] = v;
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	303
;charge_mgr.c: 303: g_stableCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	304
;charge_mgr.c: 304: }
	goto	l606
	line	308
	
l8050:	
;charge_mgr.c: 305: else
;charge_mgr.c: 306: {
;charge_mgr.c: 308: g_slotRefV[idx] = v;
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	309
;charge_mgr.c: 309: g_stableCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	310
	
l606:	
	line	311
;charge_mgr.c: 310: }
;charge_mgr.c: 311: if(g_stableCnt[idx] < 20)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u12551
	goto	u12550
u12551:
	goto	l8054
u12550:
	goto	l8840
	line	314
	
l8054:	
;charge_mgr.c: 314: if(g_capFlag & ((unsigned int)1 << idx))
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12564
u12565:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12564:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12565
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u12571
	goto	u12570
u12571:
	goto	l8058
u12570:
	goto	l8840
	line	316
	
l8058:	
;charge_mgr.c: 316: g_stableCnt[idx] = 0;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8072
	line	319
	
l8060:	
;charge_mgr.c: 319: else if(ct < (30) + (100) && v < 3990)
	movlw	0
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	082h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u12581
	goto	u12580
u12581:
	goto	l8072
u12580:
	
l8062:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12591
	goto	u12590
u12591:
	goto	l8072
u12590:
	line	321
	
l8064:	
;charge_mgr.c: 320: {
;charge_mgr.c: 321: unsigned int v_ref = g_slotRefV[idx];
	bsf	status, 5	;RP0=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_ref)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_ref+1)^0180h
	line	322
	
l8066:	
;charge_mgr.c: 322: if(v_ref < 3990 && v + 50 < v_ref)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v_ref+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v_ref)^0180h,w
	skipnc
	goto	u12601
	goto	u12600
u12601:
	goto	l8072
u12600:
	
l8068:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	addlw	low(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_ref+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u12615
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_ref)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u12615:
	skipnc
	goto	u12611
	goto	u12610
u12611:
	goto	l8072
u12610:
	goto	l7974
	line	332
	
l8072:	
;charge_mgr.c: 326: }
;charge_mgr.c: 327: }
;charge_mgr.c: 332: if(g_capFlag & ((unsigned int)1 << idx))
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12624
u12625:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12624:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12625
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u12631
	goto	u12630
u12631:
	goto	l8080
u12630:
	line	334
	
l8074:	
;charge_mgr.c: 333: {
;charge_mgr.c: 334: g_capFlag &= ~((unsigned int)1 << idx);
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12644
u12645:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12644:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12645
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	335
	
l8076:	
;charge_mgr.c: 335: g_detectLowCnt[idx] = 0;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	clrf	indf
	line	336
	
l8078:	
;charge_mgr.c: 336: ty = 5;
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	337
;charge_mgr.c: 337: }
	goto	l613
	line	340
	
l8080:	
;charge_mgr.c: 338: else
;charge_mgr.c: 339: {
;charge_mgr.c: 340: ty = Detect_BatteryType(v);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Detect_BatteryType@voltage+1)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(Detect_BatteryType@voltage)^080h
	fcall	_Detect_BatteryType
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	348
	
l8082:	
;charge_mgr.c: 347: if(ty == 0 && v >= 3990 &&
;charge_mgr.c: 348: ct >= (30) + (100))
	movf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12651
	goto	u12650
u12651:
	goto	l613
u12650:
	
l8084:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12661
	goto	u12660
u12661:
	goto	l613
u12660:
	
l8086:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	082h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u12671
	goto	u12670
u12671:
	goto	l613
u12670:
	goto	l8078
	line	350
	
l613:	
	line	354
;charge_mgr.c: 350: }
;charge_mgr.c: 354: if(v < 500)
	movlw	01h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0F4h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u12681
	goto	u12680
u12681:
	goto	l8094
u12680:
	line	356
	
l8090:	
;charge_mgr.c: 355: {
;charge_mgr.c: 356: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	incf	indf,f
	line	357
;charge_mgr.c: 357: if(g_detectLowCnt[idx] < 5)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u12691
	goto	u12690
u12691:
	goto	l8102
u12690:
	goto	l8840
	line	361
	
l8094:	
;charge_mgr.c: 361: else if(ty != 5 && ty != 1 && ty != 6)
		movlw	5
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12701
	goto	u12700
u12701:
	goto	l8102
u12700:
	
l8096:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12711
	goto	u12710
u12711:
	goto	l8102
u12710:
	
l8098:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12721
	goto	u12720
u12721:
	goto	l8102
u12720:
	line	363
	
l8100:	
;charge_mgr.c: 362: {
;charge_mgr.c: 363: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	clrf	indf
	line	367
	
l8102:	
;charge_mgr.c: 367: if(ty == 5)
		movlw	5
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12731
	goto	u12730
u12731:
	goto	l8132
u12730:
	line	374
	
l8104:	
;charge_mgr.c: 368: {
;charge_mgr.c: 374: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	incf	indf,f
	line	375
;charge_mgr.c: 375: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12741
	goto	u12740
u12741:
	goto	l8108
u12740:
	goto	l8840
	line	379
	
l8108:	
;charge_mgr.c: 379: if(g_impCheckSlot != 0xFF && g_impCheckSlot != idx)
	bcf	status, 6	;RP1=0, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u12751
	goto	u12750
u12751:
	goto	l8114
u12750:
	
l8110:	
	movf	(_g_impCheckSlot)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	xorwf	(ChargeProcess_Slot@idx)^0180h,w
	skipnz
	goto	u12761
	goto	u12760
u12761:
	goto	l8114
u12760:
	goto	l8840
	line	381
	
l8114:	
;charge_mgr.c: 381: g_impCheckSlot = idx;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	385
	
l8116:	
;charge_mgr.c: 385: if(0xA5 == ADC_Sample(31, 0))
	clrf	(ADC_Sample@adldo)^080h
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u12771
	goto	u12770
u12771:
	goto	l622
u12770:
	line	386
	
l8118:	
;charge_mgr.c: 386: g_vcc_mv = (unsigned int)((4096UL * 1200UL) / adresult);
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(0+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	
l622:	
	line	390
;charge_mgr.c: 390: g_impData = v | ((unsigned int)(((g_vcc_mv + 50U) / 100U) - 38U) << 12);
	movlw	064h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lwdiv@divisor)^080h
	clrf	(___lwdiv@divisor+1)^080h
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(032h)
	movwf	(___lwdiv@dividend)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(___lwdiv@dividend)^080h
	fcall	___lwdiv
	movf	(1+(?___lwdiv))^080h,w
	movwf	(_g_impData+1)^080h
	movf	(0+(?___lwdiv))^080h,w
	movwf	(_g_impData)^080h
	
l8120:	
	movlw	0Ch
	
u12785:
	clrc
	rlf	(_g_impData)^080h,f
	rlf	(_g_impData+1)^080h,f
	addlw	-1
	skipz
	goto	u12785
	
l8122:	
	movlw	(0A000h >> 8)
	addwf	(_g_impData+1)^080h,f
	
l8124:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	iorwf	(_g_impData)^080h,f
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	iorwf	(_g_impData+1)^080h,f
	line	391
	
l8126:	
;charge_mgr.c: 391: st = 8;
	movlw	low(08h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	392
	
l8128:	
;charge_mgr.c: 392: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	393
	
l8130:	
;charge_mgr.c: 393: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	clrf	indf
	line	395
	
l8132:	
;charge_mgr.c: 394: }
;charge_mgr.c: 395: if(ty == 1 || ty == 6)
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12791
	goto	u12790
u12791:
	goto	l8136
u12790:
	
l8134:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12801
	goto	u12800
u12801:
	goto	l8188
u12800:
	line	398
	
l8136:	
;charge_mgr.c: 396: {
;charge_mgr.c: 398: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	incf	indf,f
	line	399
;charge_mgr.c: 399: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u12811
	goto	u12810
u12811:
	goto	l8140
u12810:
	goto	l8840
	line	401
	
l8140:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv)^080h

	
l8142:	
	movlw	0Ch
u12825:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u12825

	
l8144:	
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long)^080h

	
l8146:	
	movf	(ChargeProcess_Slot@vx_mv+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12831
	addwf	(ChargeProcess_Slot@bat_mv_long+1)^080h,f
u12831:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12832
	addwf	(ChargeProcess_Slot@bat_mv_long+2)^080h,f
u12832:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u12833
	addwf	(ChargeProcess_Slot@bat_mv_long+3)^080h,f
u12833:

	
l8148:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	goto	u12840
	goto	u12841
u12840:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u12841:
	movf	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	goto	u12842
	goto	u12843
u12842:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u12843:
	movf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv)^0180h
	
l8150:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u12851
	goto	u12850
u12851:
	goto	l8154
u12850:
	
l8152:	
	movlw	low(02h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l8180
	
l8154:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u12861
	goto	u12860
u12861:
	goto	l8158
u12860:
	
l8156:	
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l8180
	
l8158:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipc
	goto	u12871
	goto	u12870
u12871:
	goto	l8172
u12870:
	
l8160:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u12881
	goto	u12880
u12881:
	goto	l8164
u12880:
	
l8162:	
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l8180
	
l8164:	
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l8166:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	
l8168:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l8170:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8180
	
l8172:	
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l8174:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l8176:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	goto	l8170
	
l8180:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	
l8182:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l8184:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	clrf	indf
	
l8186:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	bcf	indf+(7/8),(7)&7
	goto	l8840
	line	403
	
l8188:	
;charge_mgr.c: 403: else if(ty == 0)
	movf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12891
	goto	u12890
u12891:
	goto	l8198
u12890:
	line	408
	
l8190:	
;charge_mgr.c: 404: {
;charge_mgr.c: 408: if(v >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12901
	goto	u12900
u12901:
	goto	l8194
u12900:
	goto	l8840
	line	410
	
l8194:	
;charge_mgr.c: 410: st = 7;
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l8014
	line	413
	
l8198:	
;charge_mgr.c: 413: else if(ty == 2 || ty == 3)
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u12911
	goto	u12910
u12911:
	goto	l8194
u12910:
	
l8200:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u12921
	goto	u12920
u12921:
	goto	l8840
u12920:
	goto	l8194
	line	421
	
l8206:	
;charge_mgr.c: 421: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	422
;charge_mgr.c: 422: if(ct < 5)
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	05h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u12931
	goto	u12930
u12931:
	goto	l8210
u12930:
	goto	l8840
	line	427
	
l8210:	
;charge_mgr.c: 425: {
;charge_mgr.c: 427: if(0xA5 == ADC_Sample(31, 0))
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ADC_Sample@adldo)^080h
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u12941
	goto	u12940
u12941:
	goto	l8214
u12940:
	line	428
	
l8212:	
;charge_mgr.c: 428: g_vcc_mv = (unsigned int)((4096UL * 1200UL) / adresult);
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(0+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	line	434
	
l8214:	
;charge_mgr.c: 434: if(v >= 4050U && (g_impData & 0x0FFFU) >= 4050U)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0D2h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12951
	goto	u12950
u12951:
	goto	l8224
u12950:
	
l8216:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0D2h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u12961
	goto	u12960
u12961:
	goto	l8224
u12960:
	line	436
	
l8218:	
;charge_mgr.c: 435: {
;charge_mgr.c: 436: ty = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	437
;charge_mgr.c: 437: st = 0;
	clrf	(ChargeProcess_Slot@st)^0180h
	line	438
	
l8220:	
;charge_mgr.c: 438: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	439
	
l8222:	
;charge_mgr.c: 439: g_highVFlag &= ~((unsigned int)1 << idx);
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u12974
u12975:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u12974:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u12975
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	440
;charge_mgr.c: 440: break;
	goto	l8840
	line	446
	
l8224:	
;charge_mgr.c: 441: }
;charge_mgr.c: 446: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 300U && v >= 3990)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)^080h
	clrf	(___wmul@multiplier+1)^080h
	movlw	0Fh
	andwf	(___wmul@multiplier)^080h,f
	clrf	(___wmul@multiplier+1)^080h
	movlw	026h
	addwf	(___wmul@multiplier)^080h,f
	skipnc
	incf	(___wmul@multiplier+1)^080h,f
	movlw	064h
	movwf	(___wmul@multiplicand)^080h
	clrf	(___wmul@multiplicand+1)^080h
	fcall	___wmul
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(012Ch)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(012Ch)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(1+(?___wmul))^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u12985
	movf	(0+(?___wmul))^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u12985:
	skipnc
	goto	u12981
	goto	u12980
u12981:
	goto	l8232
u12980:
	
l8226:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u12991
	goto	u12990
u12991:
	goto	l8232
u12990:
	line	448
	
l8228:	
;charge_mgr.c: 447: {
;charge_mgr.c: 448: ty = 2;
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	449
;charge_mgr.c: 449: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	450
;charge_mgr.c: 450: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	goto	l8222
	line	461
	
l8232:	
;charge_mgr.c: 453: }
;charge_mgr.c: 460: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 200U &&
;charge_mgr.c: 461: (g_impData & 0x0FFFU) < 3100U)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)^080h
	clrf	(___wmul@multiplier+1)^080h
	movlw	0Fh
	andwf	(___wmul@multiplier)^080h,f
	clrf	(___wmul@multiplier+1)^080h
	movlw	026h
	addwf	(___wmul@multiplier)^080h,f
	skipnc
	incf	(___wmul@multiplier+1)^080h,f
	movlw	064h
	movwf	(___wmul@multiplicand)^080h
	clrf	(___wmul@multiplicand+1)^080h
	fcall	___wmul
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(0C8h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(1+(?___wmul))^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u13005
	movf	(0+(?___wmul))^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u13005:
	skipnc
	goto	u13001
	goto	u13000
u13001:
	goto	l8238
u13000:
	
l8234:	
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Ch
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	01Ch
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	goto	u13011
	goto	u13010
u13011:
	goto	l8238
u13010:
	goto	l8268
	line	472
	
l8238:	
;charge_mgr.c: 470: if(!(g_highVFlag & ((unsigned int)1 << idx)) &&
;charge_mgr.c: 471: ((g_impData & 0x0FFFU) > v) &&
;charge_mgr.c: 472: ((g_impData & 0x0FFFU) - v) > 1000U)
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u13024
u13025:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u13024:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u13025
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfss	status,2
	goto	u13031
	goto	u13030
u13031:
	goto	l8250
u13030:
	
l8240:	
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	skipz
	goto	u13045
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v)^0100h,w
u13045:
	skipnc
	goto	u13041
	goto	u13040
u13041:
	goto	l8250
u13040:
	
l8242:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	03h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0E9h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u13051
	goto	u13050
u13051:
	goto	l8250
u13050:
	line	474
	
l8244:	
;charge_mgr.c: 473: {
;charge_mgr.c: 474: ty = 3;
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	475
;charge_mgr.c: 475: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	476
;charge_mgr.c: 476: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	477
	
l8246:	
;charge_mgr.c: 477: g_highVFlag &= ~((unsigned int)1 << idx);
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u13064
u13065:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u13064:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u13065
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	goto	l8014
	line	486
	
l8250:	
;charge_mgr.c: 480: }
;charge_mgr.c: 485: if(((g_impData & 0x0FFFU) > 3500) &&
;charge_mgr.c: 486: ((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) <= g_vcc_mv + 200U))
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Dh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0ADh
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u13071
	goto	u13070
u13071:
	goto	l8256
u13070:
	
l8252:	
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)^080h
	clrf	(___wmul@multiplier+1)^080h
	movlw	0Fh
	andwf	(___wmul@multiplier)^080h,f
	clrf	(___wmul@multiplier+1)^080h
	movlw	026h
	addwf	(___wmul@multiplier)^080h,f
	skipnc
	incf	(___wmul@multiplier+1)^080h,f
	movlw	064h
	movwf	(___wmul@multiplicand)^080h
	clrf	(___wmul@multiplicand+1)^080h
	fcall	___wmul
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(0C8h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(1+(?___wmul))^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u13085
	movf	(0+(?___wmul))^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u13085:
	skipc
	goto	u13081
	goto	u13080
u13081:
	goto	l8256
u13080:
	goto	l8260
	line	493
	
l8256:	
	line	499
	
l8260:	
;charge_mgr.c: 499: st = 9;
	movlw	low(09h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	500
	
l8262:	
;charge_mgr.c: 500: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	501
	
l8264:	
;charge_mgr.c: 501: g_diodeTraceCnt = 0;
	bcf	status, 6	;RP1=0, select bank1
	clrf	(_g_diodeTraceCnt)^080h
	line	502
;charge_mgr.c: 502: g_diodeTraceSlot = (unsigned char)idx;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_diodeTraceSlot)^080h
	goto	l8222
	line	509
	
l8268:	
;charge_mgr.c: 509: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	line	510
	
l8270:	
;charge_mgr.c: 510: g_highVFlag &= ~((unsigned int)1 << idx);
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u13094
u13095:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u13094:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u13095
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	511
	
l8272:	
;charge_mgr.c: 511: ty = 1;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	incf	(ChargeProcess_Slot@ty)^0180h,f
	line	512
	
l8274:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_381+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_381+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_381+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_381)^080h

	
l8276:	
	movlw	0Ch
u13105:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_381+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_381+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_381+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_381)^080h,f
	addlw	-1
	skipz
	goto	u13105

	
l8278:	
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_382+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_382+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_382+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_382)^080h

	
l8280:	
	movf	(ChargeProcess_Slot@vx_mv_381+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv_381+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv_381+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv_381)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long_382)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u13111
	addwf	(ChargeProcess_Slot@bat_mv_long_382+1)^080h,f
u13111:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u13112
	addwf	(ChargeProcess_Slot@bat_mv_long_382+2)^080h,f
u13112:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u13113
	addwf	(ChargeProcess_Slot@bat_mv_long_382+3)^080h,f
u13113:

	
l8282:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long_382)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long_382+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_382+1)^080h,w
	goto	u13120
	goto	u13121
u13120:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u13121:
	movf	(ChargeProcess_Slot@bat_mv_long_382+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_382+2)^080h,w
	goto	u13122
	goto	u13123
u13122:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u13123:
	movf	(ChargeProcess_Slot@bat_mv_long_382+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_382+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_383+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_383)^0180h
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_383+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_383)^0180h,w
	skipnc
	goto	u13131
	goto	u13130
u13131:
	goto	l8286
u13130:
	goto	l8152
	
l8286:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_383+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_383)^0180h,w
	skipnc
	goto	u13141
	goto	u13140
u13141:
	goto	l8290
u13140:
	goto	l8156
	
l8290:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_383+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_383)^0180h,w
	skipc
	goto	u13151
	goto	u13150
u13151:
	goto	l8172
u13150:
	
l8292:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u13161
	goto	u13160
u13161:
	goto	l8164
u13160:
	goto	l8162
	line	523
	
l8320:	
;charge_mgr.c: 523: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	524
	
l8322:	
;charge_mgr.c: 524: g_highVFlag &= ~((unsigned int)1 << idx);
	bsf	status, 6	;RP1=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u13174
u13175:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u13174:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u13175
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	525
	
l8324:	
;charge_mgr.c: 525: ty = 6;
	movlw	low(06h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	526
	
l8326:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(___lmul@multiplier)^080h
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(___lmul@multiplier)^080h
	clrf	2+(___lmul@multiplier)^080h
	clrf	3+(___lmul@multiplier)^080h
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_384+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_384+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_384+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_384)^080h

	
l8328:	
	movlw	0Ch
u13185:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_384+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_384+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_384+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_384)^080h,f
	addlw	-1
	skipz
	goto	u13185

	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_385+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_385+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_385+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_385)^080h

	movf	(ChargeProcess_Slot@vx_mv_384+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv_384+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv_384+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv_384)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long_385)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u13191
	addwf	(ChargeProcess_Slot@bat_mv_long_385+1)^080h,f
u13191:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u13192
	addwf	(ChargeProcess_Slot@bat_mv_long_385+2)^080h,f
u13192:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u13193
	addwf	(ChargeProcess_Slot@bat_mv_long_385+3)^080h,f
u13193:

	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long_385)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long_385+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_385+1)^080h,w
	goto	u13200
	goto	u13201
u13200:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u13201:
	movf	(ChargeProcess_Slot@bat_mv_long_385+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_385+2)^080h,w
	goto	u13202
	goto	u13203
u13202:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u13203:
	movf	(ChargeProcess_Slot@bat_mv_long_385+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_385+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_386+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_386)^0180h
	
l8330:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_386+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_386)^0180h,w
	skipnc
	goto	u13211
	goto	u13210
u13211:
	goto	l8334
u13210:
	goto	l8152
	
l8334:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_386+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_386)^0180h,w
	skipnc
	goto	u13221
	goto	u13220
u13221:
	goto	l8338
u13220:
	goto	l8156
	
l8338:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_386+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_386)^0180h,w
	skipc
	goto	u13231
	goto	u13230
u13231:
	goto	l8352
u13230:
	
l8340:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u13241
	goto	u13240
u13241:
	goto	l8344
u13240:
	goto	l8162
	
l8344:	
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l8346:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	goto	l8168
	
l8352:	
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l8354:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l8356:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	goto	l8170
	line	536
	
l8368:	
;charge_mgr.c: 536: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	542
	
l8370:	
;charge_mgr.c: 541: if((ct == 7U || ct == 14U || ct == 21U || ct == 28U) &&
;charge_mgr.c: 542: g_diodeTraceCnt < 4U)
		movlw	7
	xorwf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfsc	status,2
	goto	u13251
	goto	u13250
u13251:
	goto	l8378
u13250:
	
l8372:	
		movlw	14
	xorwf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfsc	status,2
	goto	u13261
	goto	u13260
u13261:
	goto	l8378
u13260:
	
l8374:	
		movlw	21
	xorwf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfsc	status,2
	goto	u13271
	goto	u13270
u13271:
	goto	l8378
u13270:
	
l8376:	
		movlw	28
	xorwf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u13281
	goto	u13280
u13281:
	goto	l8394
u13280:
	
l8378:	
	movlw	low(04h)
	bcf	status, 6	;RP1=0, select bank1
	subwf	(_g_diodeTraceCnt)^080h,w
	skipnc
	goto	u13291
	goto	u13290
u13291:
	goto	l8394
u13290:
	line	544
	
l8380:	
;charge_mgr.c: 543: {
;charge_mgr.c: 544: signed int diff = (signed int)v - (signed int)(g_impData & 0x0FFFU);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@diff+1)^0180h
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@diff)^0180h
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@diff)^0180h,f
	bcf	status, 6	;RP1=0, select bank1
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 6	;RP1=1, select bank3
	skipc
	decf	(ChargeProcess_Slot@diff+1)^0180h,f
	subwf	(ChargeProcess_Slot@diff+1)^0180h,f
	line	545
;charge_mgr.c: 545: diff >>= 2;
	rlf	(ChargeProcess_Slot@diff+1)^0180h,w
	rrf	(ChargeProcess_Slot@diff+1)^0180h,f
	rrf	(ChargeProcess_Slot@diff)^0180h,f
	rlf	(ChargeProcess_Slot@diff+1)^0180h,w
	rrf	(ChargeProcess_Slot@diff+1)^0180h,f
	rrf	(ChargeProcess_Slot@diff)^0180h,f
	line	546
	
l8382:	
;charge_mgr.c: 546: if(diff > 127) diff = 127;
	movf	(ChargeProcess_Slot@diff+1)^0180h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u13305
	movlw	080h
	subwf	(ChargeProcess_Slot@diff)^0180h,w
u13305:

	skipc
	goto	u13301
	goto	u13300
u13301:
	goto	l8386
u13300:
	
l8384:	
	movlw	07Fh
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@diff)^0180h
	clrf	(ChargeProcess_Slot@diff+1)^0180h
	line	547
	
l8386:	
;charge_mgr.c: 547: if(diff < -128) diff = -128;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@diff+1)^0180h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u13315
	movlw	080h
	subwf	(ChargeProcess_Slot@diff)^0180h,w
u13315:

	skipnc
	goto	u13311
	goto	u13310
u13311:
	goto	l8390
u13310:
	
l8388:	
	movlw	080h
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@diff)^0180h
	movlw	0FFh
	movwf	((ChargeProcess_Slot@diff)^0180h)+1
	line	548
	
l8390:	
;charge_mgr.c: 548: g_diodeTrace[g_diodeTraceCnt++] = (unsigned char)(diff + 128);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_diodeTraceCnt)^080h,w
	addlw	low(_g_diodeTrace|((0x0)<<8))&0ffh
	movwf	fsr0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@diff)^0180h,w
	addlw	080h
	bcf	status, 7	;select IRP bank1
	movwf	indf
	
l8392:	
	bcf	status, 6	;RP1=0, select bank1
	incf	(_g_diodeTraceCnt)^080h,f
	goto	l8398
	line	552
	
l8394:	
	line	558
	
l8398:	
;charge_mgr.c: 555: }
;charge_mgr.c: 558: if(v > (g_impData & 0x0FFFU) + 900)
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(0384h)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(0384h)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	skipz
	goto	u13325
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
u13325:
	skipnc
	goto	u13321
	goto	u13320
u13321:
	goto	l8406
u13320:
	line	562
	
l8400:	
;charge_mgr.c: 559: {
;charge_mgr.c: 562: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150U)
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)^080h
	clrf	(___wmul@multiplier+1)^080h
	movlw	0Fh
	andwf	(___wmul@multiplier)^080h,f
	clrf	(___wmul@multiplier+1)^080h
	movlw	026h
	addwf	(___wmul@multiplier)^080h,f
	skipnc
	incf	(___wmul@multiplier+1)^080h,f
	movlw	064h
	movwf	(___wmul@multiplicand)^080h
	clrf	(___wmul@multiplicand+1)^080h
	fcall	___wmul
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(096h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(1+(?___wmul))^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u13335
	movf	(0+(?___wmul))^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u13335:
	skipnc
	goto	u13331
	goto	u13330
u13331:
	goto	l8320
u13330:
	goto	l8268
	line	579
	
l8406:	
;charge_mgr.c: 566: }
;charge_mgr.c: 577: if(((g_impData & 0x0FFFU) > 3000U) &&
;charge_mgr.c: 578: (v > 2900) &&
;charge_mgr.c: 579: (v < (g_impData & 0x0FFFU)))
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Bh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0B9h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u13341
	goto	u13340
u13341:
	goto	l8414
u13340:
	
l8408:	
	movlw	0Bh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13351
	goto	u13350
u13351:
	goto	l8414
u13350:
	
l8410:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	skipz
	goto	u13365
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v)^0100h,w
u13365:
	skipnc
	goto	u13361
	goto	u13360
u13361:
	goto	l8414
u13360:
	goto	l8320
	line	586
	
l8414:	
;charge_mgr.c: 585: if((v > 2900) &&
;charge_mgr.c: 586: ((g_impData & 0x0FFFU) <= 2300U))
	movlw	0Bh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13371
	goto	u13370
u13371:
	goto	l8424
u13370:
	
l8416:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	08h
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	goto	u13381
	goto	u13380
u13381:
	goto	l8424
u13380:
	goto	l8244
	line	612
	
l8424:	
;charge_mgr.c: 594: }
;charge_mgr.c: 609: if(ct >= 20U && v > 2100U &&
;charge_mgr.c: 610: (g_impData & 0x0FFFU) <= 2300U &&
;charge_mgr.c: 611: v + 100U >= (g_impData & 0x0FFFU) &&
;charge_mgr.c: 612: v <= (g_impData & 0x0FFFU) + 150)
	movlw	0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	014h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u13391
	goto	u13390
u13391:
	goto	l8436
u13390:
	
l8426:	
	movlw	08h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	035h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13401
	goto	u13400
u13401:
	goto	l8436
u13400:
	
l8428:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	08h
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	goto	u13411
	goto	u13410
u13411:
	goto	l8436
u13410:
	
l8430:	
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	addlw	low(064h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipnc
	addlw	1
	addlw	high(064h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	skipz
	goto	u13425
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
u13425:
	skipc
	goto	u13421
	goto	u13420
u13421:
	goto	l8436
u13420:
	
l8432:	
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(096h)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	skipz
	goto	u13435
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
u13435:
	skipc
	goto	u13431
	goto	u13430
u13431:
	goto	l8436
u13430:
	goto	l8320
	line	622
	
l8436:	
;charge_mgr.c: 622: if(ct >= 30)
	movlw	0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	01Eh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u13441
	goto	u13440
u13441:
	goto	l8840
u13440:
	line	624
	
l8438:	
;charge_mgr.c: 623: {
;charge_mgr.c: 624: unsigned int pre = (unsigned int)(g_impData & 0x0FFFU);
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@pre)^0180h
	movlw	0Fh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData+1)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	1+(ChargeProcess_Slot@pre)^0180h
	line	630
;charge_mgr.c: 630: if(pre > 3500 && pre < 3990)
	movlw	0Dh
	subwf	(ChargeProcess_Slot@pre+1)^0180h,w
	movlw	0ADh
	skipnz
	subwf	(ChargeProcess_Slot@pre)^0180h,w
	skipc
	goto	u13451
	goto	u13450
u13451:
	goto	l8464
u13450:
	
l8440:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@pre+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@pre)^0180h,w
	skipnc
	goto	u13461
	goto	u13460
u13461:
	goto	l8464
u13460:
	line	633
	
l8442:	
;charge_mgr.c: 631: {
;charge_mgr.c: 632: unsigned char tc;
;charge_mgr.c: 633: unsigned char hasRise = 0;
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@hasRise)^080h
	line	634
;charge_mgr.c: 634: for(tc = 0; tc < g_diodeTraceCnt; tc++)
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@tc)^0180h
	goto	l8450
	line	636
	
l8444:	
;charge_mgr.c: 635: {
;charge_mgr.c: 636: if(g_diodeTrace[tc] >= 136U)
	movf	(ChargeProcess_Slot@tc)^0180h,w
	addlw	low(_g_diodeTrace|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(088h)
	bcf	status, 7	;select IRP bank1
	subwf	indf,w
	skipc
	goto	u13471
	goto	u13470
u13471:
	goto	l8448
u13470:
	line	638
	
l8446:	
;charge_mgr.c: 637: {
;charge_mgr.c: 638: hasRise = 1;
	bcf	status, 6	;RP1=0, select bank1
	clrf	(ChargeProcess_Slot@hasRise)^080h
	incf	(ChargeProcess_Slot@hasRise)^080h,f
	line	639
;charge_mgr.c: 639: break;
	goto	l8452
	line	634
	
l8448:	
	incf	(ChargeProcess_Slot@tc)^0180h,f
	
l8450:	
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_diodeTraceCnt)^080h,w
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@tc)^0180h,w
	skipc
	goto	u13481
	goto	u13480
u13481:
	goto	l8444
u13480:
	line	642
	
l8452:	
;charge_mgr.c: 640: }
;charge_mgr.c: 641: }
;charge_mgr.c: 642: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150U)
	bcf	status, 6	;RP1=0, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	movwf	(___wmul@multiplier)^080h
	clrf	(___wmul@multiplier+1)^080h
	movlw	0Fh
	andwf	(___wmul@multiplier)^080h,f
	clrf	(___wmul@multiplier+1)^080h
	movlw	026h
	addwf	(___wmul@multiplier)^080h,f
	skipnc
	incf	(___wmul@multiplier+1)^080h,f
	movlw	064h
	movwf	(___wmul@multiplicand)^080h
	clrf	(___wmul@multiplicand+1)^080h
	fcall	___wmul
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(096h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(1+(?___wmul))^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u13495
	movf	(0+(?___wmul))^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u13495:
	skipnc
	goto	u13491
	goto	u13490
u13491:
	goto	l8456
u13490:
	goto	l8268
	line	644
	
l8456:	
;charge_mgr.c: 644: if(!hasRise)
	movf	((ChargeProcess_Slot@hasRise)^080h),w
	btfss	status,2
	goto	u13501
	goto	u13500
u13501:
	goto	l8320
u13500:
	goto	l8244
	line	655
	
l8464:	
;charge_mgr.c: 654: }
;charge_mgr.c: 655: if(v > 3500 && v < 3990)
	movlw	0Dh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0ADh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13511
	goto	u13510
u13511:
	goto	l8470
u13510:
	
l8466:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u13521
	goto	u13520
u13521:
	goto	l8470
u13520:
	goto	l8320
	line	660
	
l8470:	
;charge_mgr.c: 658: }
;charge_mgr.c: 659: if(v > 2800U && v < 3100U && pre < 3100U &&
;charge_mgr.c: 660: v + 150U >= pre && pre + 150U >= v)
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0F1h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13531
	goto	u13530
u13531:
	goto	l8244
u13530:
	
l8472:	
	movlw	0Ch
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	01Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u13541
	goto	u13540
u13541:
	goto	l8244
u13540:
	
l8474:	
	movlw	0Ch
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@pre+1)^0180h,w
	movlw	01Ch
	skipnz
	subwf	(ChargeProcess_Slot@pre)^0180h,w
	skipnc
	goto	u13551
	goto	u13550
u13551:
	goto	l8244
u13550:
	
l8476:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	addlw	low(096h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@pre+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u13565
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@pre)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u13565:
	skipc
	goto	u13561
	goto	u13560
u13561:
	goto	l8244
u13560:
	
l8478:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@pre)^0180h,w
	addlw	low(096h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@pre+1)^0180h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u13575
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u13575:
	skipc
	goto	u13571
	goto	u13570
u13571:
	goto	l8244
u13570:
	goto	l8320
	line	674
	
l8488:	
;charge_mgr.c: 674: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	675
;charge_mgr.c: 675: if(ct > (60 * 100))
	movlw	017h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	071h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u13581
	goto	u13580
u13581:
	goto	l8492
u13580:
	line	677
	
l8490:	
;charge_mgr.c: 676: {
;charge_mgr.c: 677: st = 7;
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	678
;charge_mgr.c: 678: break;
	goto	l8840
	line	680
	
l8492:	
;charge_mgr.c: 679: }
;charge_mgr.c: 680: if(v > 750)
	movlw	02h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13591
	goto	u13590
u13591:
	goto	l8498
u13590:
	line	682
	
l8494:	
;charge_mgr.c: 681: {
;charge_mgr.c: 682: st = 3;
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	683
	
l8496:	
;charge_mgr.c: 683: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	684
;charge_mgr.c: 684: break;
	goto	l8840
	line	686
	
l8498:	
;charge_mgr.c: 685: }
;charge_mgr.c: 686: if(v >= 3850)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13601
	goto	u13600
u13601:
	goto	l8840
u13600:
	goto	l8490
	line	694
	
l8502:	
;charge_mgr.c: 694: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	695
;charge_mgr.c: 695: if(ct > (300 * 100))
	movlw	075h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	031h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u13611
	goto	u13610
u13611:
	goto	l8506
u13610:
	goto	l8490
	line	700
	
l8506:	
;charge_mgr.c: 699: }
;charge_mgr.c: 700: if(v >= 3850)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13621
	goto	u13620
u13621:
	goto	l8512
u13620:
	line	702
	
l8508:	
;charge_mgr.c: 701: {
;charge_mgr.c: 702: g_ovCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	703
;charge_mgr.c: 703: if(g_ovCnt[idx] >= 5)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u13631
	goto	u13630
u13631:
	goto	l8514
u13630:
	goto	l8490
	line	711
	
l8512:	
;charge_mgr.c: 709: else
;charge_mgr.c: 710: {
;charge_mgr.c: 711: g_ovCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	713
	
l8514:	
;charge_mgr.c: 712: }
;charge_mgr.c: 713: if(v >= 2700)
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	08Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13641
	goto	u13640
u13641:
	goto	l8840
u13640:
	line	715
	
l8516:	
;charge_mgr.c: 714: {
;charge_mgr.c: 715: st = 4;
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	716
	
l8518:	
;charge_mgr.c: 716: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	717
	
l8520:	
;charge_mgr.c: 717: g_ccBlocks[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	718
	
l8522:	
;charge_mgr.c: 718: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	719
	
l8524:	
;charge_mgr.c: 719: g_slotRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	720
	
l8526:	
;charge_mgr.c: 720: g_stableCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8840
	line	725
	
l8528:	
;charge_mgr.c: 725: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	726
;charge_mgr.c: 726: if(ct >= (600 * 100))
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	060h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u13651
	goto	u13650
u13651:
	goto	l8534
u13650:
	line	728
	
l8530:	
;charge_mgr.c: 727: {
;charge_mgr.c: 728: ct -= (600 * 100);
	movlw	060h
	subwf	(ChargeProcess_Slot@ct)^0180h,f
	movlw	0EAh
	skipc
	decf	(ChargeProcess_Slot@ct+1)^0180h,f
	subwf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	729
	
l8532:	
;charge_mgr.c: 729: g_ccBlocks[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	731
	
l8534:	
;charge_mgr.c: 730: }
;charge_mgr.c: 731: if(g_ccBlocks[idx] >= 18)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(012h)
	subwf	indf,w
	skipc
	goto	u13661
	goto	u13660
u13661:
	goto	l8538
u13660:
	goto	l8490
	line	740
	
l8538:	
;charge_mgr.c: 735: }
;charge_mgr.c: 740: if(v >= 3990 && ty == 6)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13671
	goto	u13670
u13671:
	goto	l8544
u13670:
	
l8540:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u13681
	goto	u13680
u13681:
	goto	l8544
u13680:
	goto	l8554
	line	744
	
l8544:	
;charge_mgr.c: 744: else if(ty == 1 && ct <= (750))
	bsf	status, 5	;RP0=1, select bank3
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u13691
	goto	u13690
u13691:
	goto	l8550
u13690:
	
l8546:	
	movlw	02h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u13701
	goto	u13700
u13701:
	goto	l8550
u13700:
	goto	l8554
	line	752
	
l8550:	
;charge_mgr.c: 750: else
;charge_mgr.c: 751: {
;charge_mgr.c: 752: if(v > g_slotRefV[idx]) g_slotRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u13715
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u13715:
	skipnc
	goto	u13711
	goto	u13710
u13711:
	goto	l8554
u13710:
	
l8552:	
	bsf	status, 6	;RP1=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	762
	
l8554:	
;charge_mgr.c: 753: }
;charge_mgr.c: 762: if(ty == 6)
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u13721
	goto	u13720
u13721:
	goto	l8580
u13720:
	line	764
	
l8556:	
;charge_mgr.c: 763: {
;charge_mgr.c: 764: if(v < 2000U)
	movlw	07h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0D0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u13731
	goto	u13730
u13731:
	goto	l8566
u13730:
	line	766
	
l8558:	
;charge_mgr.c: 765: {
;charge_mgr.c: 766: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	incf	indf,f
	line	767
;charge_mgr.c: 767: if(g_detectLowCnt[idx] >= 33U)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u13741
	goto	u13740
u13741:
	goto	l8568
u13740:
	line	769
	
l8560:	
;charge_mgr.c: 768: {
;charge_mgr.c: 769: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	770
	
l8562:	
;charge_mgr.c: 770: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l8496
	line	777
	
l8566:	
;charge_mgr.c: 775: else
;charge_mgr.c: 776: {
;charge_mgr.c: 777: g_detectLowCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	clrf	indf
	line	785
	
l8568:	
;charge_mgr.c: 778: }
;charge_mgr.c: 785: if(ct >= 200U)
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0C8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u13751
	goto	u13750
u13751:
	goto	l8614
u13750:
	line	787
	
l8570:	
;charge_mgr.c: 786: {
;charge_mgr.c: 787: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	788
	
l8572:	
;charge_mgr.c: 788: if(g_ccBlocks[idx] & 0x80)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	btfss	indf,(7)&7
	goto	u13761
	goto	u13760
u13761:
	goto	l8576
u13760:
	goto	l8490
	line	794
	
l8576:	
;charge_mgr.c: 792: else
;charge_mgr.c: 793: {
;charge_mgr.c: 794: g_ccBlocks[idx] |= 0x80;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(7/8),(7)&7
	line	795
	
l8578:	
;charge_mgr.c: 795: st = 1;
	clrf	(ChargeProcess_Slot@st)^0180h
	incf	(ChargeProcess_Slot@st)^0180h,f
	line	796
;charge_mgr.c: 796: g_slotRefV[idx] = 0;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	797
;charge_mgr.c: 797: g_stableCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8840
	line	807
	
l8580:	
;charge_mgr.c: 802: else
;charge_mgr.c: 803: {
;charge_mgr.c: 807: if((v < g_slotRefV[idx] && g_slotRefV[idx] - v > 500) || v < 2000U)
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	skipz
	goto	u13775
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v)^0100h,w
u13775:
	skipnc
	goto	u13771
	goto	u13770
u13771:
	goto	l8584
u13770:
	
l8582:	
	bsf	status, 5	;RP0=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipnc
	goto	u13781
	goto	u13780
u13781:
	goto	l8586
u13780:
	
l8584:	
	movlw	07h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0D0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u13791
	goto	u13790
u13791:
	goto	l8598
u13790:
	line	809
	
l8586:	
;charge_mgr.c: 808: {
;charge_mgr.c: 809: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	incf	indf,f
	line	810
;charge_mgr.c: 810: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u13801
	goto	u13800
u13801:
	goto	l8590
u13800:
	goto	l8840
	line	812
	
l8590:	
;charge_mgr.c: 812: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	813
	
l8592:	
;charge_mgr.c: 813: st = 1;
	clrf	(ChargeProcess_Slot@st)^0180h
	incf	(ChargeProcess_Slot@st)^0180h,f
	goto	l8496
	line	819
	
l8598:	
;charge_mgr.c: 817: else
;charge_mgr.c: 818: {
;charge_mgr.c: 819: g_detectLowCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	clrf	indf
	line	831
	
l8600:	
;charge_mgr.c: 820: }
;charge_mgr.c: 831: if(ct <= (750))
	movlw	02h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u13811
	goto	u13810
u13811:
	goto	l8606
u13810:
	line	833
	
l8602:	
;charge_mgr.c: 832: {
;charge_mgr.c: 833: if(v >= g_slotRefV[idx] + (30))
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(01Eh)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	skipz
	goto	u13825
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v)^0100h,w
u13825:
	skipc
	goto	u13821
	goto	u13820
u13821:
	goto	l8606
u13820:
	line	834
	
l8604:	
;charge_mgr.c: 834: g_stableCnt[idx] = 1;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	836
	
l8606:	
;charge_mgr.c: 835: }
;charge_mgr.c: 836: if(ct > (750) && g_stableCnt[idx] == 0)
	movlw	02h
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u13831
	goto	u13830
u13831:
	goto	l8614
u13830:
	
l8608:	
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfss	status,2
	goto	u13841
	goto	u13840
u13841:
	goto	l8614
u13840:
	goto	l8562
	line	850
	
l8614:	
;charge_mgr.c: 841: }
;charge_mgr.c: 842: }
;charge_mgr.c: 850: if(v >= 3990 && ty == 1)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13851
	goto	u13850
u13851:
	goto	l8622
u13850:
	
l8616:	
	bsf	status, 5	;RP0=1, select bank3
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u13861
	goto	u13860
u13861:
	goto	l8622
u13860:
	line	852
	
l8618:	
;charge_mgr.c: 851: {
;charge_mgr.c: 852: st = 6;
	movlw	low(06h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l8496
	line	860
	
l8622:	
;charge_mgr.c: 855: }
;charge_mgr.c: 860: if(v >= 3850 && ty != 6)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13871
	goto	u13870
u13871:
	goto	l8630
u13870:
	
l8624:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u13881
	goto	u13880
u13881:
	goto	l8630
u13880:
	line	862
	
l8626:	
;charge_mgr.c: 861: {
;charge_mgr.c: 862: g_ovCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	863
;charge_mgr.c: 863: if(g_ovCnt[idx] >= 5)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u13891
	goto	u13890
u13891:
	goto	l586
u13890:
	goto	l8490
	line	871
	
l8630:	
;charge_mgr.c: 869: else
;charge_mgr.c: 870: {
;charge_mgr.c: 871: g_ovCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	873
	
l8632:	
;charge_mgr.c: 873: if(v >= 3100 && !(v >= 3990 && ty == 6))
	movlw	0Ch
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	01Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13901
	goto	u13900
u13901:
	goto	l586
u13900:
	
l8634:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13911
	goto	u13910
u13911:
	goto	l8638
u13910:
	
l8636:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u13921
	goto	u13920
u13921:
	goto	l586
u13920:
	line	875
	
l8638:	
;charge_mgr.c: 874: {
;charge_mgr.c: 875: st = 5;
	movlw	low(05h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	876
	
l8640:	
;charge_mgr.c: 876: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	877
	
l8642:	
;charge_mgr.c: 877: g_ccBlocks[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l8840
	line	884
	
l8644:	
;charge_mgr.c: 884: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	885
;charge_mgr.c: 885: if(ct > (600 * 100))
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	061h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u13931
	goto	u13930
u13931:
	goto	l743
u13930:
	line	886
	
l8646:	
;charge_mgr.c: 886: st = 6;
	movlw	low(06h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l743:	
	line	894
;charge_mgr.c: 894: if(v >= 3990 && ty == 6)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u13941
	goto	u13940
u13941:
	goto	l8652
u13940:
	
l8648:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u13951
	goto	u13950
u13951:
	goto	l8652
u13950:
	goto	l8840
	line	907
	
l8652:	
;charge_mgr.c: 907: if(v < 3990 && ct <= (750) && ty == 1)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u13961
	goto	u13960
u13961:
	goto	l8674
u13960:
	
l8654:	
	movlw	02h
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u13971
	goto	u13970
u13971:
	goto	l8674
u13970:
	
l8656:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u13981
	goto	u13980
u13981:
	goto	l8674
u13980:
	line	909
	
l8658:	
;charge_mgr.c: 908: {
;charge_mgr.c: 909: if(g_ccBlocks[idx] == 0)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(indf),w
	btfss	status,2
	goto	u13991
	goto	u13990
u13991:
	goto	l8662
u13990:
	line	911
	
l8660:	
;charge_mgr.c: 910: {
;charge_mgr.c: 911: g_slotRefV[idx] = v;
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	912
;charge_mgr.c: 912: g_ccBlocks[idx] = 1;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	913
;charge_mgr.c: 913: }
	goto	l8674
	line	914
	
l8662:	
;charge_mgr.c: 914: else if(v >= g_slotRefV[idx] + (50))
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(032h)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	skipz
	goto	u14005
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v)^0100h,w
u14005:
	skipc
	goto	u14001
	goto	u14000
u14001:
	goto	l8672
u14000:
	line	916
	
l8664:	
;charge_mgr.c: 915: {
;charge_mgr.c: 916: if(++g_stableCnt[idx] >= 3)
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	movlw	low(03h)
	subwf	(indf),w
	skipc
	goto	u14011
	goto	u14010
u14011:
	goto	l747
u14010:
	line	918
	
l8666:	
;charge_mgr.c: 917: {
;charge_mgr.c: 918: g_stableCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8562
	line	926
	
l8672:	
;charge_mgr.c: 924: else
;charge_mgr.c: 925: {
;charge_mgr.c: 926: g_stableCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8674
	line	927
	
l747:	
	line	935
	
l8674:	
;charge_mgr.c: 927: }
;charge_mgr.c: 928: }
;charge_mgr.c: 935: if(v >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u14021
	goto	u14020
u14021:
	goto	l8704
u14020:
	line	937
	
l8676:	
;charge_mgr.c: 936: {
;charge_mgr.c: 937: if(ty == 1)
	bsf	status, 5	;RP0=1, select bank3
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u14031
	goto	u14030
u14031:
	goto	l8688
u14030:
	line	939
	
l8678:	
;charge_mgr.c: 938: {
;charge_mgr.c: 939: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	incf	indf,f
	line	940
;charge_mgr.c: 940: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u14041
	goto	u14040
u14041:
	goto	l8682
u14040:
	goto	l8840
	line	942
	
l8682:	
;charge_mgr.c: 942: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8618
	line	947
	
l8688:	
;charge_mgr.c: 946: }
;charge_mgr.c: 947: if(ty == 6)
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u14051
	goto	u14050
u14051:
	goto	l8692
u14050:
	goto	l8840
	line	952
	
l8692:	
;charge_mgr.c: 951: }
;charge_mgr.c: 952: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	incf	indf,f
	line	953
;charge_mgr.c: 953: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u14061
	goto	u14060
u14061:
	goto	l8696
u14060:
	goto	l8840
	line	955
	
l8696:	
;charge_mgr.c: 955: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	956
	
l8698:	
;charge_mgr.c: 956: ty = 0;
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	957
	
l8700:	
;charge_mgr.c: 957: st = 0;
	clrf	(ChargeProcess_Slot@st)^0180h
	goto	l8496
	line	968
	
l8704:	
;charge_mgr.c: 960: }
;charge_mgr.c: 968: if(ty == 6)
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u14071
	goto	u14070
u14071:
	goto	l8718
u14070:
	line	970
	
l8706:	
;charge_mgr.c: 969: {
;charge_mgr.c: 970: if(v < 2000U)
	movlw	07h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0D0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u14081
	goto	u14080
u14081:
	goto	l8716
u14080:
	line	972
	
l8708:	
;charge_mgr.c: 971: {
;charge_mgr.c: 972: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	incf	indf,f
	line	973
;charge_mgr.c: 973: if(g_detectLowCnt[idx] >= 33U)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u14091
	goto	u14090
u14091:
	goto	l8734
u14090:
	goto	l8560
	line	983
	
l8716:	
;charge_mgr.c: 981: else
;charge_mgr.c: 982: {
;charge_mgr.c: 983: g_detectLowCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	clrf	indf
	goto	l8734
	line	988
	
l8718:	
;charge_mgr.c: 986: else
;charge_mgr.c: 987: {
;charge_mgr.c: 988: if(v < g_slotRefV[idx] && g_slotRefV[idx] - v > 500)
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	skipz
	goto	u14105
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v)^0100h,w
u14105:
	skipnc
	goto	u14101
	goto	u14100
u14101:
	goto	l8716
u14100:
	
l8720:	
	bsf	status, 5	;RP0=1, select bank3
	clrc
	rlf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u14111
	goto	u14110
u14111:
	goto	l8716
u14110:
	line	990
	
l8722:	
;charge_mgr.c: 989: {
;charge_mgr.c: 990: g_detectLowCnt[idx]++;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	incf	indf,f
	line	991
;charge_mgr.c: 991: if(g_detectLowCnt[idx] >= 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipc
	goto	u14121
	goto	u14120
u14121:
	goto	l8734
u14120:
	line	993
	
l8724:	
;charge_mgr.c: 992: {
;charge_mgr.c: 993: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	994
;charge_mgr.c: 994: g_ccBlocks[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	997
	
l8726:	
;charge_mgr.c: 997: ty = 0;
	clrf	(ChargeProcess_Slot@ty)^0180h
	goto	l8592
	line	1013
	
l8734:	
;charge_mgr.c: 1006: }
;charge_mgr.c: 1007: }
;charge_mgr.c: 1013: if(v >= 3850 && ty == 1)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u14131
	goto	u14130
u14131:
	goto	l8742
u14130:
	
l8736:	
	bsf	status, 5	;RP0=1, select bank3
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u14141
	goto	u14140
u14141:
	goto	l8742
u14140:
	line	1015
	
l8738:	
;charge_mgr.c: 1014: {
;charge_mgr.c: 1015: g_ovCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1016
;charge_mgr.c: 1016: if(g_ovCnt[idx] >= 5)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u14151
	goto	u14150
u14151:
	goto	l586
u14150:
	goto	l8490
	line	1024
	
l8742:	
;charge_mgr.c: 1022: else
;charge_mgr.c: 1023: {
;charge_mgr.c: 1024: g_ovCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l8840
	line	1035
	
l8744:	
;charge_mgr.c: 1035: if(v >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u14161
	goto	u14160
u14161:
	goto	l8762
u14160:
	line	1037
	
l8746:	
;charge_mgr.c: 1036: {
;charge_mgr.c: 1037: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	incf	indf,f
	line	1038
	
l8748:	
;charge_mgr.c: 1038: if(g_detectLowCnt[idx] >= (ty == 6 ? 50 : 2))
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u14171
	goto	u14170
u14171:
	goto	l8752
u14170:
	
l8750:	
	movlw	02h
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_ChargeProcess_Slot$391)^080h
	clrf	(_ChargeProcess_Slot$391+1)^080h
	goto	l8754
	
l8752:	
	movlw	032h
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_ChargeProcess_Slot$391)^080h
	clrf	(_ChargeProcess_Slot$391+1)^080h
	
l8754:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 6	;RP1=0, select bank1
	movf	(_ChargeProcess_Slot$391+1)^080h,w
	xorlw	80h
	sublw	080h
	skipz
	goto	u14185
	movf	(_ChargeProcess_Slot$391)^080h,w
	subwf	indf,w
u14185:

	skipc
	goto	u14181
	goto	u14180
u14181:
	goto	l8840
u14180:
	line	1040
	
l8756:	
;charge_mgr.c: 1039: {
;charge_mgr.c: 1040: g_detectLowCnt[idx] = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	clrf	indf
	goto	l8700
	line	1049
	
l8762:	
;charge_mgr.c: 1045: }
;charge_mgr.c: 1049: if(v < 2800U)
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u14191
	goto	u14190
u14191:
	goto	l8014
u14190:
	line	1051
	
l8764:	
;charge_mgr.c: 1050: {
;charge_mgr.c: 1051: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	incf	indf,f
	line	1052
;charge_mgr.c: 1052: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u14201
	goto	u14200
u14201:
	goto	l8768
u14200:
	goto	l8840
	line	1054
	
l8768:	
;charge_mgr.c: 1054: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1055
	
l8770:	
;charge_mgr.c: 1055: st = 4;
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	1056
	
l8772:	
;charge_mgr.c: 1056: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	1057
	
l8774:	
;charge_mgr.c: 1057: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	1058
	
l8776:	
;charge_mgr.c: 1058: g_ccBlocks[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l8524
	line	1071
	
l8784:	
;charge_mgr.c: 1071: if(v >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u14211
	goto	u14210
u14211:
	goto	l8800
u14210:
	line	1073
	
l8786:	
;charge_mgr.c: 1072: {
;charge_mgr.c: 1073: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	incf	indf,f
	line	1074
;charge_mgr.c: 1074: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u14221
	goto	u14220
u14221:
	goto	l8790
u14220:
	goto	l8840
	line	1076
	
l8790:	
;charge_mgr.c: 1076: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1077
	
l8792:	
;charge_mgr.c: 1077: ty = 0;
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	1078
	
l8794:	
;charge_mgr.c: 1078: st = 0;
	clrf	(ChargeProcess_Slot@st)^0180h
	goto	l8640
	line	1091
	
l8800:	
;charge_mgr.c: 1082: }
;charge_mgr.c: 1091: if(ty == 2 || ty == 3)
		movlw	2
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u14231
	goto	u14230
u14231:
	goto	l8804
u14230:
	
l8802:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u14241
	goto	u14240
u14241:
	goto	l8820
u14240:
	line	1093
	
l8804:	
;charge_mgr.c: 1092: {
;charge_mgr.c: 1093: if(v > 2700U && (g_highVFlag & ((unsigned int)1 << idx)))
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	08Dh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u14251
	goto	u14250
u14251:
	goto	l8014
u14250:
	
l8806:	
	bsf	status, 5	;RP0=1, select bank3
	incf	(ChargeProcess_Slot@idx)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u14264
u14265:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u14264:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u14265
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u14271
	goto	u14270
u14271:
	goto	l8014
u14270:
	line	1095
	
l8808:	
;charge_mgr.c: 1094: {
;charge_mgr.c: 1095: g_detectLowCnt[idx]++;
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	incf	indf,f
	line	1096
;charge_mgr.c: 1096: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u14281
	goto	u14280
u14281:
	goto	l8590
u14280:
	goto	l8840
	line	1109
	
l8820:	
;charge_mgr.c: 1107: }
;charge_mgr.c: 1109: if(v > 750)
	movlw	02h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u14291
	goto	u14290
u14291:
	goto	l8014
u14290:
	line	1111
	
l8822:	
;charge_mgr.c: 1110: {
;charge_mgr.c: 1111: g_detectLowCnt[idx]++;
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	incf	indf,f
	line	1112
;charge_mgr.c: 1112: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0180h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u14301
	goto	u14300
u14301:
	goto	l8590
u14300:
	goto	l8840
	line	1125
	
l8834:	
;charge_mgr.c: 1125: st = 0;
	clrf	(ChargeProcess_Slot@st)^0180h
	line	1126
;charge_mgr.c: 1126: break;
	goto	l8840
	line	161
	
l8838:	
	movf	(ChargeProcess_Slot@st)^0180h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l7958
	xorlw	1^0	; case 1
	skipnz
	goto	l7978
	xorlw	2^1	; case 2
	skipnz
	goto	l8488
	xorlw	3^2	; case 3
	skipnz
	goto	l8502
	xorlw	4^3	; case 4
	skipnz
	goto	l8528
	xorlw	5^4	; case 5
	skipnz
	goto	l8644
	xorlw	6^5	; case 6
	skipnz
	goto	l8744
	xorlw	7^6	; case 7
	skipnz
	goto	l8784
	xorlw	8^7	; case 8
	skipnz
	goto	l8206
	xorlw	9^8	; case 9
	skipnz
	goto	l8368
	goto	l8834
	opt asmopt_pop

	line	1127
	
l586:	
	line	1129
	
l8840:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@st)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ty)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplicand)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@idx)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ct)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@ct+1)^0180h,w
	movwf	indf
	line	1130
	
l792:	
	return
	opt stack 0
GLOBAL	__end_of_ChargeProcess_Slot
	__end_of_ChargeProcess_Slot:
	signat	_ChargeProcess_Slot,4217
	global	___wmul

;; *************** function ___wmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
;; Parameters:    Size  Location     Type
;;  multiplier      2    0[BANK1 ] unsigned int 
;;  multiplicand    2    2[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  product         2    4[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2    0[BANK1 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       4       0       0
;;      Locals:         0       0       2       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       6       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
global __ptext14
__ptext14:	;psect for function ___wmul
psect	text14
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
	global	__size_of___wmul
	__size_of___wmul	equ	__end_of___wmul-___wmul
	
___wmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___wmul: [wreg+status,2+status,0]
	line	43
	
l7382:	
	clrf	(___wmul@product)^080h
	clrf	(___wmul@product+1)^080h
	line	45
	
l7384:	
	btfss	(___wmul@multiplier)^080h,(0)&7
	goto	u11421
	goto	u11420
u11421:
	goto	l7388
u11420:
	line	46
	
l7386:	
	movf	(___wmul@multiplicand)^080h,w
	addwf	(___wmul@product)^080h,f
	skipnc
	incf	(___wmul@product+1)^080h,f
	movf	(___wmul@multiplicand+1)^080h,w
	addwf	(___wmul@product+1)^080h,f
	line	47
	
l7388:	
	clrc
	rlf	(___wmul@multiplicand)^080h,f
	rlf	(___wmul@multiplicand+1)^080h,f
	line	48
	
l7390:	
	clrc
	rrf	(___wmul@multiplier+1)^080h,f
	rrf	(___wmul@multiplier)^080h,f
	line	49
	
l7392:	
	movf	((___wmul@multiplier)^080h),w
iorwf	((___wmul@multiplier+1)^080h),w
	btfss	status,2
	goto	u11431
	goto	u11430
u11431:
	goto	l7384
u11430:
	line	52
	
l7394:	
	movf	(___wmul@product+1)^080h,w
	movwf	(?___wmul+1)^080h
	movf	(___wmul@product)^080h,w
	movwf	(?___wmul)^080h
	line	53
	
l926:	
	return
	opt stack 0
GLOBAL	__end_of___wmul
	__end_of___wmul:
	signat	___wmul,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK1 ] unsigned int 
;;  dividend        2    2[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    5[BANK1 ] unsigned int 
;;  counter         1    4[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK1 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       4       0       0
;;      Locals:         0       0       3       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       7       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext15
__ptext15:	;psect for function ___lwdiv
psect	text15
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l7222:	
	clrf	(___lwdiv@quotient)^080h
	clrf	(___lwdiv@quotient+1)^080h
	line	15
	
l7224:	
	movf	((___lwdiv@divisor)^080h),w
iorwf	((___lwdiv@divisor+1)^080h),w
	btfsc	status,2
	goto	u11141
	goto	u11140
u11141:
	goto	l7244
u11140:
	line	16
	
l7226:	
	clrf	(___lwdiv@counter)^080h
	incf	(___lwdiv@counter)^080h,f
	line	17
	goto	l7230
	line	18
	
l7228:	
	clrc
	rlf	(___lwdiv@divisor)^080h,f
	rlf	(___lwdiv@divisor+1)^080h,f
	line	19
	incf	(___lwdiv@counter)^080h,f
	line	17
	
l7230:	
	btfss	(___lwdiv@divisor+1)^080h,(15)&7
	goto	u11151
	goto	u11150
u11151:
	goto	l7228
u11150:
	line	22
	
l7232:	
	clrc
	rlf	(___lwdiv@quotient)^080h,f
	rlf	(___lwdiv@quotient+1)^080h,f
	line	23
	
l7234:	
	movf	(___lwdiv@divisor+1)^080h,w
	subwf	(___lwdiv@dividend+1)^080h,w
	skipz
	goto	u11165
	movf	(___lwdiv@divisor)^080h,w
	subwf	(___lwdiv@dividend)^080h,w
u11165:
	skipc
	goto	u11161
	goto	u11160
u11161:
	goto	l7240
u11160:
	line	24
	
l7236:	
	movf	(___lwdiv@divisor)^080h,w
	subwf	(___lwdiv@dividend)^080h,f
	movf	(___lwdiv@divisor+1)^080h,w
	skipc
	decf	(___lwdiv@dividend+1)^080h,f
	subwf	(___lwdiv@dividend+1)^080h,f
	line	25
	
l7238:	
	bsf	(___lwdiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l7240:	
	clrc
	rrf	(___lwdiv@divisor+1)^080h,f
	rrf	(___lwdiv@divisor)^080h,f
	line	28
	
l7242:	
	decfsz	(___lwdiv@counter)^080h,f
	goto	u11171
	goto	u11170
u11171:
	goto	l7232
u11170:
	line	30
	
l7244:	
	movf	(___lwdiv@quotient+1)^080h,w
	movwf	(?___lwdiv+1)^080h
	movf	(___lwdiv@quotient)^080h,w
	movwf	(?___lwdiv)^080h
	line	31
	
l1263:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    0[BANK1 ] unsigned long 
;;  multiplicand    4    4[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    8[BANK1 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    0[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext16
__ptext16:	;psect for function ___lmul
psect	text16
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l7184:	
	clrf	(___lmul@product)^080h
	clrf	(___lmul@product+1)^080h
	clrf	(___lmul@product+2)^080h
	clrf	(___lmul@product+3)^080h
	line	120
	
l935:	
	line	121
	btfss	(___lmul@multiplier)^080h,(0)&7
	goto	u11071
	goto	u11070
u11071:
	goto	l7188
u11070:
	line	122
	
l7186:	
	movf	(___lmul@multiplicand)^080h,w
	addwf	(___lmul@product)^080h,f
	movf	(___lmul@multiplicand+1)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11081
	addwf	(___lmul@product+1)^080h,f
u11081:
	movf	(___lmul@multiplicand+2)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11082
	addwf	(___lmul@product+2)^080h,f
u11082:
	movf	(___lmul@multiplicand+3)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11083
	addwf	(___lmul@product+3)^080h,f
u11083:

	line	123
	
l7188:	
	clrc
	rlf	(___lmul@multiplicand)^080h,f
	rlf	(___lmul@multiplicand+1)^080h,f
	rlf	(___lmul@multiplicand+2)^080h,f
	rlf	(___lmul@multiplicand+3)^080h,f
	line	124
	
l7190:	
	clrc
	rrf	(___lmul@multiplier+3)^080h,f
	rrf	(___lmul@multiplier+2)^080h,f
	rrf	(___lmul@multiplier+1)^080h,f
	rrf	(___lmul@multiplier)^080h,f
	line	125
	movf	(___lmul@multiplier+3)^080h,w
	iorwf	(___lmul@multiplier+2)^080h,w
	iorwf	(___lmul@multiplier+1)^080h,w
	iorwf	(___lmul@multiplier)^080h,w
	skipz
	goto	u11091
	goto	u11090
u11091:
	goto	l935
u11090:
	line	128
	
l7192:	
	movf	(___lmul@product+3)^080h,w
	movwf	(?___lmul+3)^080h
	movf	(___lmul@product+2)^080h,w
	movwf	(?___lmul+2)^080h
	movf	(___lmul@product+1)^080h,w
	movwf	(?___lmul+1)^080h
	movf	(___lmul@product)^080h,w
	movwf	(?___lmul)^080h

	line	129
	
l938:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4   12[BANK1 ] unsigned long 
;;  dividend        4   16[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   21[BANK1 ] unsigned long 
;;  counter         1   20[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4   12[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       0       5       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext17
__ptext17:	;psect for function ___lldiv
psect	text17
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l7196:	
	clrf	(___lldiv@quotient)^080h
	clrf	(___lldiv@quotient+1)^080h
	clrf	(___lldiv@quotient+2)^080h
	clrf	(___lldiv@quotient+3)^080h
	line	15
	
l7198:	
	movf	(___lldiv@divisor+3)^080h,w
	iorwf	(___lldiv@divisor+2)^080h,w
	iorwf	(___lldiv@divisor+1)^080h,w
	iorwf	(___lldiv@divisor)^080h,w
	skipnz
	goto	u11101
	goto	u11100
u11101:
	goto	l7218
u11100:
	line	16
	
l7200:	
	clrf	(___lldiv@counter)^080h
	incf	(___lldiv@counter)^080h,f
	line	17
	goto	l7204
	line	18
	
l7202:	
	clrc
	rlf	(___lldiv@divisor)^080h,f
	rlf	(___lldiv@divisor+1)^080h,f
	rlf	(___lldiv@divisor+2)^080h,f
	rlf	(___lldiv@divisor+3)^080h,f
	line	19
	incf	(___lldiv@counter)^080h,f
	line	17
	
l7204:	
	btfss	(___lldiv@divisor+3)^080h,(31)&7
	goto	u11111
	goto	u11110
u11111:
	goto	l7202
u11110:
	line	22
	
l7206:	
	clrc
	rlf	(___lldiv@quotient)^080h,f
	rlf	(___lldiv@quotient+1)^080h,f
	rlf	(___lldiv@quotient+2)^080h,f
	rlf	(___lldiv@quotient+3)^080h,f
	line	23
	
l7208:	
	movf	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,w
	skipz
	goto	u11125
	movf	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,w
	skipz
	goto	u11125
	movf	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,w
	skipz
	goto	u11125
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,w
u11125:
	skipc
	goto	u11121
	goto	u11120
u11121:
	goto	l7214
u11120:
	line	24
	
l7210:	
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,f
	movf	(___lldiv@divisor+1)^080h,w
	skipc
	incfsz	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,f
	movf	(___lldiv@divisor+2)^080h,w
	skipc
	incfsz	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,f
	movf	(___lldiv@divisor+3)^080h,w
	skipc
	incfsz	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,f
	line	25
	
l7212:	
	bsf	(___lldiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l7214:	
	clrc
	rrf	(___lldiv@divisor+3)^080h,f
	rrf	(___lldiv@divisor+2)^080h,f
	rrf	(___lldiv@divisor+1)^080h,f
	rrf	(___lldiv@divisor)^080h,f
	line	28
	
l7216:	
	decfsz	(___lldiv@counter)^080h,f
	goto	u11131
	goto	u11130
u11131:
	goto	l7206
u11130:
	line	30
	
l7218:	
	movf	(___lldiv@quotient+3)^080h,w
	movwf	(?___lldiv+3)^080h
	movf	(___lldiv@quotient+2)^080h,w
	movwf	(?___lldiv+2)^080h
	movf	(___lldiv@quotient+1)^080h,w
	movwf	(?___lldiv+1)^080h
	movf	(___lldiv@quotient)^080h,w
	movwf	(?___lldiv)^080h

	line	31
	
l1210:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[BANK1 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    2[BANK1 ] unsigned char 
;;  product         1    1[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       1       0       0
;;      Locals:         0       0       2       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext18
__ptext18:	;psect for function ___bmul
psect	text18
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___bmul@multiplier)^080h
	line	6
	
l7398:	
	clrf	(___bmul@product)^080h
	line	43
	
l7400:	
	btfss	(___bmul@multiplier)^080h,(0)&7
	goto	u11441
	goto	u11440
u11441:
	goto	l7404
u11440:
	line	44
	
l7402:	
	movf	(___bmul@multiplicand)^080h,w
	addwf	(___bmul@product)^080h,f
	line	45
	
l7404:	
	clrc
	rlf	(___bmul@multiplicand)^080h,f
	line	46
	
l7406:	
	clrc
	rrf	(___bmul@multiplier)^080h,f
	line	47
	movf	((___bmul@multiplier)^080h),w
	btfss	status,2
	goto	u11451
	goto	u11450
u11451:
	goto	l7400
u11450:
	line	50
	
l7408:	
	movf	(___bmul@product)^080h,w
	line	51
	
l944:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 76 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2    0[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	76
global __ptext19
__ptext19:	;psect for function _Detect_BatteryType
psect	text19
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	76
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	78
	
l7350:	
;charge_mgr.c: 78: if(voltage >= 3990)
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipc
	goto	u11361
	goto	u11360
u11361:
	goto	l7356
u11360:
	line	79
	
l7352:	
;charge_mgr.c: 79: return 0;
	movlw	low(0)
	goto	l572
	line	80
	
l7356:	
;charge_mgr.c: 80: if(voltage < 500)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipnc
	goto	u11371
	goto	u11370
u11371:
	goto	l7362
u11370:
	goto	l7352
	line	95
	
l7362:	
;charge_mgr.c: 95: if(voltage >= 1015 && voltage < 3990)
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipc
	goto	u11381
	goto	u11380
u11381:
	goto	l7370
u11380:
	
l7364:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipnc
	goto	u11391
	goto	u11390
u11391:
	goto	l7370
u11390:
	line	96
	
l7366:	
;charge_mgr.c: 96: return 5;
	movlw	low(05h)
	goto	l572
	line	101
	
l7370:	
;charge_mgr.c: 101: if(voltage >= 500 && voltage < 3990)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipc
	goto	u11401
	goto	u11400
u11401:
	goto	l7352
u11400:
	
l7372:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1)^080h,w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage)^080h,w
	skipnc
	goto	u11411
	goto	u11410
u11411:
	goto	l7352
u11410:
	line	102
	
l7374:	
;charge_mgr.c: 102: return 1;
	movlw	low(01h)
	line	105
	
l572:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    0[BANK1 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    6[BANK1 ] unsigned char 
;;  j               1    5[BANK1 ] unsigned char 
;;  adsum           4    8[BANK1 ] volatile unsigned long 
;;  ad_temp         2   16[BANK1 ] volatile unsigned int 
;;  admax           2   14[BANK1 ] volatile unsigned int 
;;  admin           2   12[BANK1 ] volatile unsigned int 
;;  i               1    7[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       1       0       0
;;      Locals:         0       0      13       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       0      18       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext20
__ptext20:	;psect for function _ADC_Sample
psect	text20
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	movwf	(ADC_Sample@adch)^080h
	line	51
	
l5290:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	52
	
l5292:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(ADC_Sample@admin)^080h	;volatile
	clrf	(ADC_Sample@admin+1)^080h	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(ADC_Sample@admax)^080h	;volatile
	clrf	(ADC_Sample@admax+1)^080h	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	line	58
	
l5294:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u7441
	goto	u7440
u7441:
	goto	l5300
u7440:
	
l5296:	
	btfss	(ADC_Sample@adldo)^080h,(2)&7
	goto	u7451
	goto	u7450
u7451:
	goto	l5300
u7450:
	line	60
	
l5298:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(ADC_Sample@adldo)^080h,w
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_ADC_Sample+0)^080h+0),f
	u14597:
decfsz	(??_ADC_Sample+0)^080h+0,f
	goto	u14597
	nop
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	l5302
	line	64
	
l5300:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	movf	(ADC_Sample@adldo)^080h,w
	movwf	(150)^080h	;volatile
	line	67
	
l5302:	
;adc_drv.c: 67: if(adch & 0x10)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	btfss	(ADC_Sample@adch)^080h,(4)&7
	goto	u7461
	goto	u7460
u7461:
	goto	l484
u7460:
	line	69
	
l5304:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l5306:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	andwf	(ADC_Sample@adch)^080h,f
	line	71
;adc_drv.c: 71: }
	goto	l5308
	line	72
	
l484:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l5308:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	clrf	(ADC_Sample@i)^080h
	line	79
	
l5314:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(ADC_Sample@adch)^080h,w
	movwf	(??_ADC_Sample+0)^080h+0
	movlw	(02h)-1
u7475:
	clrc
	rlf	(??_ADC_Sample+0)^080h+0,f
	addlw	-1
	skipz
	goto	u7475
	clrc
	rlf	(??_ADC_Sample+0)^080h+0,w
	iorlw	081h
	movwf	(149)^080h	;volatile
	line	80
	
l5316:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	5
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_ADC_Sample+0)^080h+0),f
	u14607:
decfsz	(??_ADC_Sample+0)^080h+0,f
	goto	u14607
	nop2
opt asmopt_pop

	line	81
	
l5318:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l5320:	
;adc_drv.c: 84: unsigned char j = 0;
	clrf	(ADC_Sample@j)^080h
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	l488
	
l489:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decfsz	(ADC_Sample@j)^080h,f
	goto	u7481
	goto	u7480
u7481:
	goto	l488
u7480:
	line	89
	
l5322:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	l491
	line	90
	
l488:	
	line	85
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u7491
	goto	u7490
u7491:
	goto	l489
u7490:
	line	93
	
l5326:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	movwf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	swapf	(ADC_Sample@ad_temp)^080h,f	;volatile
	swapf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	
l5328:	
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	addwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	line	96
	
l5330:	
;adc_drv.c: 96: if(0 == admax)
	movf	((ADC_Sample@admax)^080h),w	;volatile
iorwf	((ADC_Sample@admax+1)^080h),w	;volatile
	btfss	status,2
	goto	u7501
	goto	u7500
u7501:
	goto	l5334
u7500:
	line	98
	
l5332:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	100
;adc_drv.c: 100: }
	goto	l494
	line	102
	
l5334:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	subwf	(ADC_Sample@admax+1)^080h,w	;volatile
	skipz
	goto	u7515
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	subwf	(ADC_Sample@admax)^080h,w	;volatile
u7515:
	skipnc
	goto	u7511
	goto	u7510
u7511:
	goto	l5338
u7510:
	line	103
	
l5336:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	goto	l494
	line	105
	
l5338:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	skipz
	goto	u7525
	movf	(ADC_Sample@admin)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp)^080h,w	;volatile
u7525:
	skipnc
	goto	u7521
	goto	u7520
u7521:
	goto	l494
u7520:
	line	106
	
l5340:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	108
	
l494:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	0+(??_ADC_Sample+0)^080h+0,w
	addwf	(ADC_Sample@adsum)^080h,f	;volatile
	movf	1+(??_ADC_Sample+0)^080h+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7531
	addwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u7531:
	movf	2+(??_ADC_Sample+0)^080h+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7532
	addwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u7532:
	movf	3+(??_ADC_Sample+0)^080h+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u7533
	addwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u7533:

	line	76
	
l5342:	
	incf	(ADC_Sample@i)^080h,f
	
l5344:	
	movlw	low(022h)
	subwf	(ADC_Sample@i)^080h,w
	skipc
	goto	u7541
	goto	u7540
u7541:
	goto	l5314
u7540:
	line	112
	
l5346:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(ADC_Sample@admax)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@admax+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	0+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	movf	1+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)^080h+0,w
	goto	u7555
	goto	u7556
u7555:
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u7556:
	movf	2+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)^080h+0,w
	goto	u7557
	goto	u7558
u7557:
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u7558:
	movf	3+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)^080h+0,w
	goto	u7559
	goto	u7550
u7559:
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u7550:

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(ADC_Sample@admin)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	3+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum+3)^080h,w	;volatile
	skipz
	goto	u7565
	movf	2+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum+2)^080h,w	;volatile
	skipz
	goto	u7565
	movf	1+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum+1)^080h,w	;volatile
	skipz
	goto	u7565
	movf	0+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum)^080h,w	;volatile
u7565:
	skipc
	goto	u7561
	goto	u7560
u7561:
	goto	l498
u7560:
	line	114
	
l5348:	
;adc_drv.c: 114: adsum -= admin;
	movf	(ADC_Sample@admin)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0)
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	clrf	((??_ADC_Sample+0)^080h+0+2)
	clrf	((??_ADC_Sample+0)^080h+0+3)
	movf	0+(??_ADC_Sample+0)^080h+0,w
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	movf	1+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)^080h+0,w
	goto	u7575
	goto	u7576
u7575:
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u7576:
	movf	2+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)^080h+0,w
	goto	u7577
	goto	u7578
u7577:
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u7578:
	movf	3+(??_ADC_Sample+0)^080h+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)^080h+0,w
	goto	u7579
	goto	u7570
u7579:
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u7570:

	goto	l5350
	line	115
	
l498:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	118
	
l5350:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(ADC_Sample@adsum)^080h,w	;volatile
	movwf	(??_ADC_Sample+0)^080h+0
	movf	(ADC_Sample@adsum+1)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+1)
	movf	(ADC_Sample@adsum+2)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+2)
	movf	(ADC_Sample@adsum+3)^080h,w	;volatile
	movwf	((??_ADC_Sample+0)^080h+0+3)
	movlw	05h
u7585:
	clrc
	rrf	(??_ADC_Sample+0)^080h+3,f
	rrf	(??_ADC_Sample+0)^080h+2,f
	rrf	(??_ADC_Sample+0)^080h+1,f
	rrf	(??_ADC_Sample+0)^080h+0,f
u7580:
	addlw	-1
	skipz
	goto	u7585
	movf	1+(??_ADC_Sample+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_adresult+1)	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(??_ADC_Sample+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_adresult)	;volatile
	line	119
	
l5352:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
l491:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 167 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   22[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0       8       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_CCCV_Control
;;		_Charging_Control
;;		_PowerOnLedSequence
;;		_Update_LED_Slot
;;		i1_ADC_Sample
;;		i1___lldiv
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	167
global __ptext21
__ptext21:	;psect for function _Isr_Timer
psect	text21
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	167
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 2
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	movf	btemp+1,w
	movwf	(??_Isr_Timer+3)
	ljmp	_Isr_Timer
psect	text21
	line	170
	
i1l8868:	
;main.c: 170: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u1435_21
	goto	u1435_20
u1435_21:
	goto	i1l357
u1435_20:
	line	172
	
i1l8870:	
;main.c: 171: {
;main.c: 172: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	173
	
i1l8872:	
;main.c: 173: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	174
# 174 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text21
	line	177
	
i1l8874:	
;main.c: 177: g_pwmCounter++;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	178
	
i1l8876:	
;main.c: 178: if(g_pwmCounter >= 32)
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u1436_21
	goto	u1436_20
u1436_21:
	goto	i1l8880
u1436_20:
	line	179
	
i1l8878:	
;main.c: 179: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	182
	
i1l8880:	
;main.c: 182: if(g_pwmDuty > 0 && g_pwmCounter < g_pwmDuty)
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u1437_21
	goto	u1437_20
u1437_21:
	goto	i1l354
u1437_20:
	
i1l8882:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u1438_21
	goto	u1438_20
u1438_21:
	goto	i1l354
u1438_20:
	line	183
	
i1l8884:	
;main.c: 183: RB7 = 1;
	bsf	(55/8),(55)&7	;volatile
	goto	i1l8886
	line	184
	
i1l354:	
	line	185
;main.c: 184: else
;main.c: 185: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	188
	
i1l8886:	
;main.c: 188: if(g_powerOnPhase < 2)
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u1439_21
	goto	u1439_20
u1439_21:
	goto	i1l8956
u1439_20:
	line	190
	
i1l8888:	
;main.c: 189: {
;main.c: 190: PowerOnLedSequence();
	fcall	_PowerOnLedSequence
	goto	i1l357
	line	197
;main.c: 196: {
;main.c: 197: case 0:
	
i1l359:	
	line	199
;main.c: 199: if(!g_adcBusy && !g_doAdcSample)
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u1440_21
	goto	u1440_20
u1440_21:
	goto	i1l357
u1440_20:
	
i1l8892:	
	btfsc	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u1441_21
	goto	u1441_20
u1441_21:
	goto	i1l357
u1441_20:
	goto	i1l8896
	line	201
	
i1l363:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l376
	
i1l365:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l376
	
i1l366:	
	bsf	(51/8),(51)&7	;volatile
	goto	i1l376
	
i1l367:	
	bsf	(50/8),(50)&7	;volatile
	goto	i1l376
	
i1l368:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l376
	
i1l369:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l376
	
i1l370:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l376
	
i1l371:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l376
	
i1l372:	
	bsf	(48/8),(48)&7	;volatile
	goto	i1l376
	
i1l373:	
	bsf	(49/8),(49)&7	;volatile
	goto	i1l376
	
i1l374:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l376
	
i1l375:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l376
	
i1l8896:	
	movf	(_g_scanIndex),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l363
	xorlw	1^0	; case 1
	skipnz
	goto	i1l365
	xorlw	2^1	; case 2
	skipnz
	goto	i1l366
	xorlw	3^2	; case 3
	skipnz
	goto	i1l367
	xorlw	4^3	; case 4
	skipnz
	goto	i1l368
	xorlw	5^4	; case 5
	skipnz
	goto	i1l369
	xorlw	6^5	; case 6
	skipnz
	goto	i1l370
	xorlw	7^6	; case 7
	skipnz
	goto	i1l371
	xorlw	8^7	; case 8
	skipnz
	goto	i1l372
	xorlw	9^8	; case 9
	skipnz
	goto	i1l373
	xorlw	10^9	; case 10
	skipnz
	goto	i1l374
	xorlw	11^10	; case 11
	skipnz
	goto	i1l375
	goto	i1l376
	opt asmopt_pop

	
i1l376:	
	line	202
;main.c: 202: g_doAdcSample = 1;
	bsf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	i1l357
	line	208
	
i1l8898:	
;main.c: 208: Update_LED_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_Update_LED_Slot
	line	210
	
i1l8900:	
;main.c: 210: g_scanPhase = 2;
	movlw	low(02h)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_scanPhase)	;volatile
	line	211
;main.c: 211: break;
	goto	i1l357
	line	214
	
i1l8902:	
;main.c: 214: if(g_scanIndex == 0)
	movf	((_g_scanIndex)),w	;volatile
	btfss	status,2
	goto	u1442_21
	goto	u1442_20
u1442_21:
	goto	i1l8948
u1442_20:
	line	217
	
i1l8904:	
;main.c: 215: {
;main.c: 217: if(!g_adcBusy)
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u1443_21
	goto	u1443_20
u1443_21:
	goto	i1l8918
u1443_20:
	line	219
	
i1l8906:	
;main.c: 218: {
;main.c: 219: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	220
	
i1l8908:	
;main.c: 220: test_adc = ADC_Sample(31, 0);
	clrf	(i1ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	i1_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	221
	
i1l8910:	
;main.c: 221: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u1444_21
	goto	u1444_20
u1444_21:
	goto	i1l8916
u1444_20:
	line	223
	
i1l8912:	
;main.c: 222: {
;main.c: 223: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult),w	;volatile
	movwf	(i1___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((i1___lldiv@divisor))+1
	clrf	2+((i1___lldiv@divisor))
	clrf	3+((i1___lldiv@divisor))
	movlw	0
	movwf	(i1___lldiv@dividend+3)
	movlw	04Bh
	movwf	(i1___lldiv@dividend+2)
	movlw	0
	movwf	(i1___lldiv@dividend+1)
	movlw	0
	movwf	(i1___lldiv@dividend)

	fcall	i1___lldiv
	movf	(3+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+3)
	movf	(2+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+2)
	movf	(1+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+1)
	movf	(0+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt)

	line	224
	
i1l8914:	
;main.c: 224: g_vcc_mv = (unsigned int)pt;
	movf	(Isr_Timer@pt+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv+1)^080h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(Isr_Timer@pt),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv)^080h	;volatile
	line	226
	
i1l8916:	
;main.c: 225: }
;main.c: 226: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	229
	
i1l8918:	
;main.c: 227: }
;main.c: 229: Charging_Control();
	fcall	_Charging_Control
	line	230
	
i1l8920:	
;main.c: 230: CCCV_Control();
	fcall	_CCCV_Control
	line	234
	
i1l8922:	
;main.c: 233: {
;main.c: 234: if(g_tempPhase == 0)
	movf	((_g_tempPhase)),w	;volatile
	btfss	status,2
	goto	u1445_21
	goto	u1445_20
u1445_21:
	goto	i1l8934
u1445_20:
	line	236
	
i1l8924:	
;main.c: 235: {
;main.c: 236: g_tempReadRoundCnt++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_tempReadRoundCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1)^080h,f	;volatile
	line	237
	
i1l8926:	
;main.c: 237: if(g_tempReadRoundCnt >= 200)
	movlw	0
	subwf	(_g_tempReadRoundCnt+1)^080h,w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt)^080h,w	;volatile
	skipc
	goto	u1446_21
	goto	u1446_20
u1446_21:
	goto	i1l8942
u1446_20:
	line	239
	
i1l8928:	
;main.c: 238: {
;main.c: 239: g_tempReadRoundCnt = 0;
	clrf	(_g_tempReadRoundCnt)^080h	;volatile
	clrf	(_g_tempReadRoundCnt+1)^080h	;volatile
	line	240
	
i1l8930:	
;main.c: 240: g_tempPhase = 1;
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_tempPhase)	;volatile
	line	241
	
i1l8932:	
;main.c: 241: g_tempSettleCnt = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	goto	i1l8942
	line	246
	
i1l8934:	
;main.c: 244: else
;main.c: 245: {
;main.c: 246: g_tempSettleCnt++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_tempSettleCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1)^080h,f	;volatile
	line	247
	
i1l8936:	
;main.c: 247: if(g_tempSettleCnt >= 60)
	movlw	0
	subwf	(_g_tempSettleCnt+1)^080h,w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt)^080h,w	;volatile
	skipc
	goto	u1447_21
	goto	u1447_20
u1447_21:
	goto	i1l8942
u1447_20:
	line	249
	
i1l8938:	
;main.c: 248: {
;main.c: 249: g_doNtcRead = 1;
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	250
	
i1l8940:	
;main.c: 250: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	line	251
;main.c: 251: g_tempPhase = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_tempPhase)	;volatile
	line	258
	
i1l8942:	
;main.c: 252: }
;main.c: 253: }
;main.c: 254: }
;main.c: 258: if(++g_printTick >= 100)
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_printTick)^080h,f	;volatile
	skipnz
	incf	(_g_printTick+1)^080h,f	;volatile
	movlw	0
	subwf	((_g_printTick+1)^080h),w	;volatile
	movlw	064h
	skipnz
	subwf	((_g_printTick)^080h),w	;volatile
	skipc
	goto	u1448_21
	goto	u1448_20
u1448_21:
	goto	i1l8948
u1448_20:
	line	260
	
i1l8944:	
;main.c: 259: {
;main.c: 260: g_printTick = 0;
	clrf	(_g_printTick)^080h	;volatile
	clrf	(_g_printTick+1)^080h	;volatile
	line	261
	
i1l8946:	
;main.c: 261: g_printFlag = 1;
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	267
	
i1l8948:	
;main.c: 262: }
;main.c: 264: }
;main.c: 267: if(++g_scanIndex >= 12)
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	incf	(_g_scanIndex),f	;volatile
	subwf	((_g_scanIndex)),w	;volatile
	skipc
	goto	u1449_21
	goto	u1449_20
u1449_21:
	goto	i1l388
u1449_20:
	line	268
	
i1l8950:	
;main.c: 268: g_scanIndex = 0;
	clrf	(_g_scanIndex)	;volatile
	
i1l388:	
	line	269
;main.c: 269: g_scanPhase = 0;
	clrf	(_g_scanPhase)	;volatile
	line	270
;main.c: 270: break;
	goto	i1l357
	line	195
	
i1l8956:	
	movf	(_g_scanPhase),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 2
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           17     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l359
	xorlw	1^0	; case 1
	skipnz
	goto	i1l8898
	xorlw	2^1	; case 2
	skipnz
	goto	i1l8902
	goto	i1l388
	opt asmopt_pop

	line	277
	
i1l357:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(??_Isr_Timer+3),w
	movwf	btemp+1
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^00h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	i1___lldiv

;; *************** function i1___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    0[COMMON] unsigned long 
;;  dividend        4    4[COMMON] unsigned long 
;; Auto vars:     Size  Location     Type
;;  __lldiv         4    1[BANK0 ] unsigned long 
;;  __lldiv         1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    0[COMMON] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         8       0       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       5       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext22
__ptext22:	;psect for function i1___lldiv
psect	text22
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_ofi1___lldiv
	__size_ofi1___lldiv	equ	__end_ofi1___lldiv-i1___lldiv
	
i1___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in i1___lldiv: [wreg+status,2+status,0]
	line	14
	
i1l8842:	
	clrf	(i1___lldiv@quotient)
	clrf	(i1___lldiv@quotient+1)
	clrf	(i1___lldiv@quotient+2)
	clrf	(i1___lldiv@quotient+3)
	line	15
	
i1l8844:	
	movf	(i1___lldiv@divisor+3),w
	iorwf	(i1___lldiv@divisor+2),w
	iorwf	(i1___lldiv@divisor+1),w
	iorwf	(i1___lldiv@divisor),w
	skipnz
	goto	u1431_21
	goto	u1431_20
u1431_21:
	goto	i1l8864
u1431_20:
	line	16
	
i1l8846:	
	clrf	(i1___lldiv@counter)
	incf	(i1___lldiv@counter),f
	line	17
	goto	i1l8850
	line	18
	
i1l8848:	
	clrc
	rlf	(i1___lldiv@divisor),f
	rlf	(i1___lldiv@divisor+1),f
	rlf	(i1___lldiv@divisor+2),f
	rlf	(i1___lldiv@divisor+3),f
	line	19
	incf	(i1___lldiv@counter),f
	line	17
	
i1l8850:	
	btfss	(i1___lldiv@divisor+3),(31)&7
	goto	u1432_21
	goto	u1432_20
u1432_21:
	goto	i1l8848
u1432_20:
	line	22
	
i1l8852:	
	clrc
	rlf	(i1___lldiv@quotient),f
	rlf	(i1___lldiv@quotient+1),f
	rlf	(i1___lldiv@quotient+2),f
	rlf	(i1___lldiv@quotient+3),f
	line	23
	
i1l8854:	
	movf	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),w
	skipz
	goto	u1433_25
	movf	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),w
	skipz
	goto	u1433_25
	movf	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),w
	skipz
	goto	u1433_25
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),w
u1433_25:
	skipc
	goto	u1433_21
	goto	u1433_20
u1433_21:
	goto	i1l8860
u1433_20:
	line	24
	
i1l8856:	
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),f
	movf	(i1___lldiv@divisor+1),w
	skipc
	incfsz	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),f
	movf	(i1___lldiv@divisor+2),w
	skipc
	incfsz	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),f
	movf	(i1___lldiv@divisor+3),w
	skipc
	incfsz	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),f
	line	25
	
i1l8858:	
	bsf	(i1___lldiv@quotient)+(0/8),(0)&7
	line	27
	
i1l8860:	
	clrc
	rrf	(i1___lldiv@divisor+3),f
	rrf	(i1___lldiv@divisor+2),f
	rrf	(i1___lldiv@divisor+1),f
	rrf	(i1___lldiv@divisor),f
	line	28
	
i1l8862:	
	decfsz	(i1___lldiv@counter),f
	goto	u1434_21
	goto	u1434_20
u1434_21:
	goto	i1l8852
u1434_20:
	line	30
	
i1l8864:	
	movf	(i1___lldiv@quotient+3),w
	movwf	(?i1___lldiv+3)
	movf	(i1___lldiv@quotient+2),w
	movwf	(?i1___lldiv+2)
	movf	(i1___lldiv@quotient+1),w
	movwf	(?i1___lldiv+1)
	movf	(i1___lldiv@quotient),w
	movwf	(?i1___lldiv)

	line	31
	
i1l1210:	
	return
	opt stack 0
GLOBAL	__end_ofi1___lldiv
	__end_ofi1___lldiv:
	signat	i1___lldiv,92
	global	i1_ADC_Sample

;; *************** function i1_ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    0[BANK0 ] unsigned char 
;;  ADC_Sample      4    3[BANK0 ] volatile unsigned long 
;;  ADC_Sample      2   11[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    9[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    7[BANK0 ] volatile unsigned int 
;;  ADC_Sample      1    2[BANK0 ] unsigned char 
;;  ADC_Sample      1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      13       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext23
__ptext23:	;psect for function i1_ADC_Sample
psect	text23
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_ofi1_ADC_Sample
	__size_ofi1_ADC_Sample	equ	__end_ofi1_ADC_Sample-i1_ADC_Sample
	
i1_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in i1_ADC_Sample: [wreg+status,2+status,0]
;i1ADC_Sample@adch stored from wreg
	movwf	(i1ADC_Sample@adch)
	line	51
	
i1l5104:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	52
	
i1l5106:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(i1ADC_Sample@admin)	;volatile
	clrf	(i1ADC_Sample@admin+1)	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(i1ADC_Sample@admax)	;volatile
	clrf	(i1ADC_Sample@admax+1)	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	line	58
	
i1l5108:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u711_21
	goto	u711_20
u711_21:
	goto	i1l5114
u711_20:
	
i1l5110:	
	btfss	(i1ADC_Sample@adldo),(2)&7
	goto	u712_21
	goto	u712_20
u712_21:
	goto	i1l5114
u712_20:
	line	60
	
i1l5112:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??i1_ADC_Sample+0)+0),f
	u1461_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u1461_27
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	i1l5116
	line	64
	
i1l5114:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	67
	
i1l5116:	
;adc_drv.c: 67: if(adch & 0x10)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(i1ADC_Sample@adch),(4)&7
	goto	u713_21
	goto	u713_20
u713_21:
	goto	i1l484
u713_20:
	line	69
	
i1l5118:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
i1l5120:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(i1ADC_Sample@adch),f
	line	71
;adc_drv.c: 71: }
	goto	i1l5122
	line	72
	
i1l484:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
i1l5122:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@i)
	
i1l5124:	
	movlw	low(022h)
	subwf	(i1ADC_Sample@i),w
	skipc
	goto	u714_21
	goto	u714_20
u714_21:
	goto	i1l5128
u714_20:
	goto	i1l5160
	line	79
	
i1l5128:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(i1ADC_Sample@adch),w
	movwf	(??i1_ADC_Sample+0)+0
	movlw	(02h)-1
u715_25:
	clrc
	rlf	(??i1_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u715_25
	clrc
	rlf	(??i1_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
i1l5130:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	6
movwf	((??i1_ADC_Sample+0)+0),f
	u1462_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u1462_27
	nop
opt asmopt_pop

	line	81
	
i1l5132:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
i1l5134:	
;adc_drv.c: 84: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@j)
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	i1l488
	
i1l489:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(i1ADC_Sample@j),f
	goto	u716_21
	goto	u716_20
u716_21:
	goto	i1l488
u716_20:
	line	89
	
i1l5136:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	i1l491
	line	90
	
i1l488:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u717_21
	goto	u717_20
u717_21:
	goto	i1l489
u717_20:
	line	93
	
i1l5140:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	swapf	(i1ADC_Sample@ad_temp),f	;volatile
	swapf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp),f	;volatile
	
i1l5142:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(i1ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(i1ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
i1l5144:	
;adc_drv.c: 96: if(0 == admax)
	movf	((i1ADC_Sample@admax)),w	;volatile
iorwf	((i1ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u718_21
	goto	u718_20
u718_21:
	goto	i1l5148
u718_20:
	line	98
	
i1l5146:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	100
;adc_drv.c: 100: }
	goto	i1l494
	line	102
	
i1l5148:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	subwf	(i1ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u719_25
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	subwf	(i1ADC_Sample@admax),w	;volatile
u719_25:
	skipnc
	goto	u719_21
	goto	u719_20
u719_21:
	goto	i1l5152
u719_20:
	line	103
	
i1l5150:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	goto	i1l494
	line	105
	
i1l5152:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	subwf	(i1ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u720_25
	movf	(i1ADC_Sample@admin),w	;volatile
	subwf	(i1ADC_Sample@ad_temp),w	;volatile
u720_25:
	skipnc
	goto	u720_21
	goto	u720_20
u720_21:
	goto	i1l494
u720_20:
	line	106
	
i1l5154:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	108
	
i1l494:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	addwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u721_21
	addwf	(i1ADC_Sample@adsum+1),f	;volatile
u721_21:
	movf	2+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u721_22
	addwf	(i1ADC_Sample@adsum+2),f	;volatile
u721_22:
	movf	3+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u721_23
	addwf	(i1ADC_Sample@adsum+3),f	;volatile
u721_23:

	line	76
	
i1l5156:	
	incf	(i1ADC_Sample@i),f
	goto	i1l5124
	line	112
	
i1l5160:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(i1ADC_Sample@admax),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admax+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u722_25
	goto	u722_26
u722_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u722_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u722_27
	goto	u722_28
u722_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u722_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u722_29
	goto	u722_20
u722_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u722_20:

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	3+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u723_25
	movf	2+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u723_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u723_25
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),w	;volatile
u723_25:
	skipc
	goto	u723_21
	goto	u723_20
u723_21:
	goto	i1l498
u723_20:
	line	114
	
i1l5162:	
;adc_drv.c: 114: adsum -= admin;
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u724_25
	goto	u724_26
u724_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u724_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u724_27
	goto	u724_28
u724_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u724_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u724_29
	goto	u724_20
u724_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u724_20:

	goto	i1l5164
	line	115
	
i1l498:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	118
	
i1l5164:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(i1ADC_Sample@adsum),w	;volatile
	movwf	(??i1_ADC_Sample+0)+0
	movf	(i1ADC_Sample@adsum+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	movf	(i1ADC_Sample@adsum+2),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+2)
	movf	(i1ADC_Sample@adsum+3),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+3)
	movlw	05h
u725_25:
	clrc
	rrf	(??i1_ADC_Sample+0)+3,f
	rrf	(??i1_ADC_Sample+0)+2,f
	rrf	(??i1_ADC_Sample+0)+1,f
	rrf	(??i1_ADC_Sample+0)+0,f
u725_20:
	addlw	-1
	skipz
	goto	u725_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
i1l5166:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
i1l491:	
	return
	opt stack 0
GLOBAL	__end_ofi1_ADC_Sample
	__end_ofi1_ADC_Sample:
	signat	i1_ADC_Sample,89
	global	_Update_LED_Slot

;; *************** function _Update_LED_Slot *****************
;; Defined at:
;;		line 28 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    3[COMMON] unsigned char 
;;  s               1    8[COMMON] unsigned char 
;;  i               1    7[COMMON] unsigned char 
;;  hasFull         1    6[COMMON] unsigned char 
;;  hasChg          1    5[COMMON] unsigned char 
;;  hasErr          1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         6       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         6       0       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	28
global __ptext24
__ptext24:	;psect for function _Update_LED_Slot
psect	text24
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	28
	global	__size_of_Update_LED_Slot
	__size_of_Update_LED_Slot	equ	__end_of_Update_LED_Slot-_Update_LED_Slot
	
_Update_LED_Slot:	
;incstack = 0
	opt	stack 2
; Regs used in _Update_LED_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Update_LED_Slot@idx stored from wreg
	movwf	(Update_LED_Slot@idx)
	line	31
	
i1l7482:	
;led.c: 30: unsigned char i;
;led.c: 31: unsigned char hasErr = 0;
	clrf	(Update_LED_Slot@hasErr)
	line	32
;led.c: 32: unsigned char hasChg = 0;
	clrf	(Update_LED_Slot@hasChg)
	line	33
;led.c: 33: unsigned char hasFull = 0;
	clrf	(Update_LED_Slot@hasFull)
	line	35
;led.c: 35: for(i = 0; i < 12; i++)
	clrf	(Update_LED_Slot@i)
	line	37
	
i1l7488:	
;led.c: 36: {
;led.c: 37: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Update_LED_Slot@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Slot@s)
	line	38
	
i1l7490:	
;led.c: 38: if(s == 7)
		movlw	7
	xorwf	((Update_LED_Slot@s)),w
	btfss	status,2
	goto	u1147_21
	goto	u1147_20
u1147_21:
	goto	i1l7494
u1147_20:
	line	39
	
i1l7492:	
;led.c: 39: hasErr = 1;
	clrf	(Update_LED_Slot@hasErr)
	incf	(Update_LED_Slot@hasErr),f
	goto	i1l7504
	line	40
	
i1l7494:	
;led.c: 40: else if(s != 0 && s != 6)
	movf	((Update_LED_Slot@s)),w
	btfsc	status,2
	goto	u1148_21
	goto	u1148_20
u1148_21:
	goto	i1l7500
u1148_20:
	
i1l7496:	
		movlw	6
	xorwf	((Update_LED_Slot@s)),w
	btfsc	status,2
	goto	u1149_21
	goto	u1149_20
u1149_21:
	goto	i1l7500
u1149_20:
	line	41
	
i1l7498:	
;led.c: 41: hasChg = 1;
	clrf	(Update_LED_Slot@hasChg)
	incf	(Update_LED_Slot@hasChg),f
	goto	i1l7504
	line	42
	
i1l7500:	
;led.c: 42: else if(s == 6)
		movlw	6
	xorwf	((Update_LED_Slot@s)),w
	btfss	status,2
	goto	u1150_21
	goto	u1150_20
u1150_21:
	goto	i1l7504
u1150_20:
	line	43
	
i1l7502:	
;led.c: 43: hasFull = 1;
	clrf	(Update_LED_Slot@hasFull)
	incf	(Update_LED_Slot@hasFull),f
	line	35
	
i1l7504:	
	incf	(Update_LED_Slot@i),f
	
i1l7506:	
	movlw	low(0Ch)
	subwf	(Update_LED_Slot@i),w
	skipc
	goto	u1151_21
	goto	u1151_20
u1151_21:
	goto	i1l7488
u1151_20:
	line	46
	
i1l7508:	
;led.c: 44: }
;led.c: 46: if(hasErr)
	movf	((Update_LED_Slot@hasErr)),w
	btfsc	status,2
	goto	u1152_21
	goto	u1152_20
u1152_21:
	goto	i1l7520
u1152_20:
	line	49
	
i1l7510:	
;led.c: 47: {
;led.c: 49: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	50
	
i1l7512:	
;led.c: 50: if(idx == 0)
	movf	((Update_LED_Slot@idx)),w
	btfss	status,2
	goto	u1153_21
	goto	u1153_20
u1153_21:
	goto	i1l912
u1153_20:
	line	52
	
i1l7514:	
;led.c: 51: {
;led.c: 52: if(++s_ledBlinkCnt >= (100 / 2))
	movlw	low(032h)
	incf	(_s_ledBlinkCnt),f	;volatile
	subwf	((_s_ledBlinkCnt)),w	;volatile
	skipc
	goto	u1154_21
	goto	u1154_20
u1154_21:
	goto	i1l7518
u1154_20:
	line	53
	
i1l7516:	
;led.c: 53: s_ledBlinkCnt = 0;
	clrf	(_s_ledBlinkCnt)	;volatile
	line	54
	
i1l7518:	
;led.c: 54: RC5 = (s_ledBlinkCnt < ((100 / 2) / 2)) ? 0 : 1;
	movlw	low(019h)
	subwf	(_s_ledBlinkCnt),w	;volatile
	skipnc
	goto	u1155_21
	goto	u1155_20
	
u1155_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u1156_24
u1155_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u1156_24:
	goto	i1l912
	line	57
	
i1l7520:	
;led.c: 57: else if(hasChg)
	movf	((Update_LED_Slot@hasChg)),w
	btfsc	status,2
	goto	u1157_21
	goto	u1157_20
u1157_21:
	goto	i1l7524
u1157_20:
	line	60
	
i1l7522:	
;led.c: 58: {
;led.c: 60: RC5 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	61
;led.c: 61: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	62
;led.c: 62: }
	goto	i1l912
	line	63
	
i1l7524:	
;led.c: 63: else if(hasFull)
	movf	((Update_LED_Slot@hasFull)),w
	btfsc	status,2
	goto	u1158_21
	goto	u1158_20
u1158_21:
	goto	i1l910
u1158_20:
	line	66
	
i1l7526:	
;led.c: 64: {
;led.c: 66: RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	67
;led.c: 67: RC4 = 0;
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	68
;led.c: 68: }
	goto	i1l912
	line	69
	
i1l910:	
	line	72
;led.c: 69: else
;led.c: 70: {
;led.c: 72: RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	73
;led.c: 73: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	75
	
i1l912:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Slot
	__end_of_Update_LED_Slot:
	signat	_Update_LED_Slot,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 84 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	line	84
global __ptext25
__ptext25:	;psect for function _PowerOnLedSequence
psect	text25
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	84
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	86
	
i1l3696:	
;led.c: 86: g_powerOnTimer++;
	incf	(_g_powerOnTimer),f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1),f	;volatile
	line	88
	
i1l3698:	
;led.c: 88: if(g_powerOnPhase == 0)
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u419_21
	goto	u419_20
u419_21:
	goto	i1l3708
u419_20:
	line	91
	
i1l3700:	
;led.c: 89: {
;led.c: 91: RC5 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	92
;led.c: 92: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	93
	
i1l3702:	
;led.c: 93: if(g_powerOnTimer >= 100)
	movlw	0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u420_21
	goto	u420_20
u420_21:
	goto	i1l920
u420_20:
	line	95
	
i1l3704:	
;led.c: 94: {
;led.c: 95: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	96
	
i1l3706:	
;led.c: 96: g_powerOnPhase = 1;
	movlw	low(01h)
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l920
	line	99
	
i1l3708:	
;led.c: 99: else if(g_powerOnPhase == 1)
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u421_21
	goto	u421_20
u421_21:
	goto	i1l920
u421_20:
	line	102
	
i1l3710:	
;led.c: 100: {
;led.c: 102: RC5 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	103
;led.c: 103: RC4 = 0;
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	104
	
i1l3712:	
;led.c: 104: if(g_powerOnTimer >= 100)
	movlw	0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u422_21
	goto	u422_20
u422_21:
	goto	i1l920
u422_20:
	line	106
	
i1l3714:	
;led.c: 105: {
;led.c: 106: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	107
	
i1l3716:	
;led.c: 107: g_powerOnPhase = 2;
	movlw	low(02h)
	movwf	(_g_powerOnPhase)	;volatile
	line	111
	
i1l920:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
	global	_Charging_Control

;; *************** function _Charging_Control *****************
;; Defined at:
;;		line 1146 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    3[COMMON] unsigned char 
;;  i               1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         2       0       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1146
global __ptext26
__ptext26:	;psect for function _Charging_Control
psect	text26
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1146
	global	__size_of_Charging_Control
	__size_of_Charging_Control	equ	__end_of_Charging_Control-_Charging_Control
	
_Charging_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _Charging_Control: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1151
	
i1l7528:	
;charge_mgr.c: 1148: unsigned char i;
;charge_mgr.c: 1151: if(g_tempProtect)
	movf	((_g_tempProtect)),w
	btfsc	status,2
	goto	u1159_21
	goto	u1159_20
u1159_21:
	goto	i1l7534
u1159_20:
	line	1153
;charge_mgr.c: 1152: {
;charge_mgr.c: 1153: do { RA0=1; RA1=1; RB3=1; RB2=1; RA3=1; RA2=1; RD1=1; RD3=1; RB0=1; RB1=1; RD2=1; RD0=1; } while(0);
	
i1l796:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	bsf	(1073/8)^080h,(1073)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	bsf	(50/8),(50)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	bsf	(1074/8)^080h,(1074)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	bsf	(49/8),(49)&7	;volatile
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	line	1154
	
i1l7530:	
;charge_mgr.c: 1154: g_pwmDuty = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	goto	i1l798
	line	1161
	
i1l7534:	
;charge_mgr.c: 1156: }
;charge_mgr.c: 1161: if(g_vccProtect)
	bcf	status, 5	;RP0=0, select bank0
	movf	((_g_vccProtect)),w
	btfsc	status,2
	goto	u1160_21
	goto	u1160_20
u1160_21:
	goto	i1l7544
u1160_20:
	line	1163
	
i1l7536:	
;charge_mgr.c: 1162: {
;charge_mgr.c: 1163: if(g_vcc_mv < 4600)
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u1161_21
	goto	u1161_20
u1161_21:
	goto	i1l7542
u1161_20:
	goto	i1l796
	line	1169
	
i1l7542:	
;charge_mgr.c: 1168: }
;charge_mgr.c: 1169: g_vccProtect = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	line	1170
;charge_mgr.c: 1170: }
	goto	i1l7552
	line	1173
	
i1l7544:	
;charge_mgr.c: 1171: else
;charge_mgr.c: 1172: {
;charge_mgr.c: 1173: if(g_vcc_mv < 4400)
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u1162_21
	goto	u1162_20
u1162_21:
	goto	i1l7552
u1162_20:
	line	1175
	
i1l7546:	
;charge_mgr.c: 1174: {
;charge_mgr.c: 1175: g_vccProtect = 1;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	incf	(_g_vccProtect),f
	goto	i1l796
	line	1183
	
i1l7552:	
;charge_mgr.c: 1179: }
;charge_mgr.c: 1180: }
;charge_mgr.c: 1183: for(i = 0; i < 12; i++)
	clrf	(Charging_Control@i)
	line	1185
	
i1l7558:	
;charge_mgr.c: 1184: {
;charge_mgr.c: 1185: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Charging_Control@s)
	line	1190
	
i1l7560:	
;charge_mgr.c: 1188: if(s == 2 || s == 3 ||
;charge_mgr.c: 1189: s == 4 || s == 5 ||
;charge_mgr.c: 1190: s == 8)
		movlw	2
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1163_21
	goto	u1163_20
u1163_21:
	goto	i1l7572
u1163_20:
	
i1l7562:	
		movlw	3
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1164_21
	goto	u1164_20
u1164_21:
	goto	i1l7572
u1164_20:
	
i1l7564:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1165_21
	goto	u1165_20
u1165_21:
	goto	i1l7572
u1165_20:
	
i1l7566:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u1166_21
	goto	u1166_20
u1166_21:
	goto	i1l7572
u1166_20:
	
i1l7568:	
		movlw	8
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u1167_21
	goto	u1167_20
u1167_21:
	goto	i1l7574
u1167_20:
	goto	i1l7572
	line	1192
	
i1l814:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l7584
	
i1l816:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l7584
	
i1l817:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l7584
	
i1l818:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l7584
	
i1l819:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l7584
	
i1l820:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l7584
	
i1l821:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l7584
	
i1l822:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l7584
	
i1l823:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l7584
	
i1l824:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l7584
	
i1l825:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l7584
	
i1l826:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l7584
	
i1l7572:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l814
	xorlw	1^0	; case 1
	skipnz
	goto	i1l816
	xorlw	2^1	; case 2
	skipnz
	goto	i1l817
	xorlw	3^2	; case 3
	skipnz
	goto	i1l818
	xorlw	4^3	; case 4
	skipnz
	goto	i1l819
	xorlw	5^4	; case 5
	skipnz
	goto	i1l820
	xorlw	6^5	; case 6
	skipnz
	goto	i1l821
	xorlw	7^6	; case 7
	skipnz
	goto	i1l822
	xorlw	8^7	; case 8
	skipnz
	goto	i1l823
	xorlw	9^8	; case 9
	skipnz
	goto	i1l824
	xorlw	10^9	; case 10
	skipnz
	goto	i1l825
	xorlw	11^10	; case 11
	skipnz
	goto	i1l826
	goto	i1l7584
	opt asmopt_pop

	line	1195
	
i1l7574:	
;charge_mgr.c: 1195: else if(s == 1)
		decf	((Charging_Control@s)),w
	btfss	status,2
	goto	u1168_21
	goto	u1168_20
u1168_21:
	goto	i1l7582
u1168_20:
	line	1197
	
i1l7578:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l814
	xorlw	1^0	; case 1
	skipnz
	goto	i1l816
	xorlw	2^1	; case 2
	skipnz
	goto	i1l817
	xorlw	3^2	; case 3
	skipnz
	goto	i1l818
	xorlw	4^3	; case 4
	skipnz
	goto	i1l819
	xorlw	5^4	; case 5
	skipnz
	goto	i1l820
	xorlw	6^5	; case 6
	skipnz
	goto	i1l821
	xorlw	7^6	; case 7
	skipnz
	goto	i1l822
	xorlw	8^7	; case 8
	skipnz
	goto	i1l823
	xorlw	9^8	; case 9
	skipnz
	goto	i1l824
	xorlw	10^9	; case 10
	skipnz
	goto	i1l825
	xorlw	11^10	; case 11
	skipnz
	goto	i1l826
	goto	i1l7584
	opt asmopt_pop

	line	1201
	
i1l849:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l7584
	
i1l851:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l7584
	
i1l852:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	i1l7584
	
i1l853:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	i1l7584
	
i1l854:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l7584
	
i1l855:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l7584
	
i1l856:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l7584
	
i1l857:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l7584
	
i1l858:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	i1l7584
	
i1l859:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	i1l7584
	
i1l860:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l7584
	
i1l861:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l7584
	
i1l7582:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l849
	xorlw	1^0	; case 1
	skipnz
	goto	i1l851
	xorlw	2^1	; case 2
	skipnz
	goto	i1l852
	xorlw	3^2	; case 3
	skipnz
	goto	i1l853
	xorlw	4^3	; case 4
	skipnz
	goto	i1l854
	xorlw	5^4	; case 5
	skipnz
	goto	i1l855
	xorlw	6^5	; case 6
	skipnz
	goto	i1l856
	xorlw	7^6	; case 7
	skipnz
	goto	i1l857
	xorlw	8^7	; case 8
	skipnz
	goto	i1l858
	xorlw	9^8	; case 9
	skipnz
	goto	i1l859
	xorlw	10^9	; case 10
	skipnz
	goto	i1l860
	xorlw	11^10	; case 11
	skipnz
	goto	i1l861
	goto	i1l7584
	opt asmopt_pop

	line	1183
	
i1l7584:	
	incf	(Charging_Control@i),f
	
i1l7586:	
	movlw	low(0Ch)
	subwf	(Charging_Control@i),w
	skipc
	goto	u1169_21
	goto	u1169_20
u1169_21:
	goto	i1l7558
u1169_20:
	line	1206
	
i1l798:	
	return
	opt stack 0
GLOBAL	__end_of_Charging_Control
	__end_of_Charging_Control:
	signat	_Charging_Control,89
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 1224 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    6[BANK0 ] unsigned int 
;;  s               1   17[BANK0 ] unsigned char 
;;  duty            2   14[BANK0 ] int 
;;  error           2   10[BANK0 ] int 
;;  adjust          2    0[BANK0 ] int 
;;  duty_initial    1   13[BANK0 ] unsigned char 
;;  duty_target     1   12[BANK0 ] unsigned char 
;;  maxV            2    8[BANK0 ] unsigned int 
;;  i               1   16[BANK0 ] unsigned char 
;;  preCount        1    5[BANK0 ] unsigned char 
;;  ccCount         1    4[BANK0 ] unsigned char 
;;  cvCount         1    3[BANK0 ] unsigned char 
;;  hasCharging     1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2      18       0       0       0
;;Total ram usage:       20 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___awdiv
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=0
	line	1224
global __ptext27
__ptext27:	;psect for function _CCCV_Control
psect	text27
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1224
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1227
	
i1l7588:	
;charge_mgr.c: 1226: unsigned char i;
;charge_mgr.c: 1227: unsigned char hasCharging = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	1228
;charge_mgr.c: 1228: unsigned int maxV = 0;
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	1229
;charge_mgr.c: 1229: unsigned char cvCount = 0;
	clrf	(CCCV_Control@cvCount)
	line	1230
;charge_mgr.c: 1230: unsigned char ccCount = 0;
	clrf	(CCCV_Control@ccCount)
	line	1231
;charge_mgr.c: 1231: unsigned char preCount = 0;
	clrf	(CCCV_Control@preCount)
	line	1234
;charge_mgr.c: 1234: for(i = 0; i < 12; i++)
	clrf	(CCCV_Control@i)
	line	1236
	
i1l7594:	
;charge_mgr.c: 1235: {
;charge_mgr.c: 1236: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	1240
	
i1l7596:	
;charge_mgr.c: 1238: if(s == 2 || s == 3 ||
;charge_mgr.c: 1239: s == 4 || s == 5 ||
;charge_mgr.c: 1240: s == 8)
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1170_21
	goto	u1170_20
u1170_21:
	goto	i1l869
u1170_20:
	
i1l7598:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1171_21
	goto	u1171_20
u1171_21:
	goto	i1l869
u1171_20:
	
i1l7600:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1172_21
	goto	u1172_20
u1172_21:
	goto	i1l869
u1172_20:
	
i1l7602:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1173_21
	goto	u1173_20
u1173_21:
	goto	i1l869
u1173_20:
	
i1l7604:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1174_21
	goto	u1174_20
u1174_21:
	goto	i1l867
u1174_20:
	
i1l869:	
	line	1242
;charge_mgr.c: 1241: {
;charge_mgr.c: 1242: hasCharging = 1;
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	1244
	
i1l7606:	
;charge_mgr.c: 1243: {
;charge_mgr.c: 1244: unsigned int vt = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	1245
	
i1l7608:	
;charge_mgr.c: 1245: if(vt > maxV) maxV = vt;
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u1175_25
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u1175_25:
	skipnc
	goto	u1175_21
	goto	u1175_20
u1175_21:
	goto	i1l7612
u1175_20:
	
i1l7610:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	1247
	
i1l7612:	
;charge_mgr.c: 1246: }
;charge_mgr.c: 1247: if(s == 5)
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1176_21
	goto	u1176_20
u1176_21:
	goto	i1l7616
u1176_20:
	line	1248
	
i1l7614:	
;charge_mgr.c: 1248: cvCount++;
	incf	(CCCV_Control@cvCount),f
	line	1249
	
i1l7616:	
;charge_mgr.c: 1249: if(s == 4)
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1177_21
	goto	u1177_20
u1177_21:
	goto	i1l7620
u1177_20:
	line	1250
	
i1l7618:	
;charge_mgr.c: 1250: ccCount++;
	incf	(CCCV_Control@ccCount),f
	line	1251
	
i1l7620:	
;charge_mgr.c: 1251: if(s == 3 || s == 2)
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1178_21
	goto	u1178_20
u1178_21:
	goto	i1l7624
u1178_20:
	
i1l7622:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1179_21
	goto	u1179_20
u1179_21:
	goto	i1l867
u1179_20:
	line	1252
	
i1l7624:	
;charge_mgr.c: 1252: preCount++;
	incf	(CCCV_Control@preCount),f
	line	1253
	
i1l867:	
	line	1234
	incf	(CCCV_Control@i),f
	
i1l7626:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u1180_21
	goto	u1180_20
u1180_21:
	goto	i1l7594
u1180_20:
	line	1257
	
i1l7628:	
;charge_mgr.c: 1253: }
;charge_mgr.c: 1254: }
;charge_mgr.c: 1257: if(!hasCharging)
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u1181_21
	goto	u1181_20
u1181_21:
	goto	i1l7634
u1181_20:
	line	1259
	
i1l7630:	
;charge_mgr.c: 1258: {
;charge_mgr.c: 1259: g_pwmDuty = 0;
	clrf	(_g_pwmDuty)	;volatile
	line	1260
;charge_mgr.c: 1260: g_cvIntegral = 0;
	clrf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l877
	line	1268
	
i1l7634:	
;charge_mgr.c: 1262: }
;charge_mgr.c: 1268: if(cvCount == 0)
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u1182_21
	goto	u1182_20
u1182_21:
	goto	i1l7664
u1182_20:
	line	1272
	
i1l7636:	
;charge_mgr.c: 1269: {
;charge_mgr.c: 1270: unsigned char duty_target, duty_initial;
;charge_mgr.c: 1272: if(ccCount > 0)
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u1183_21
	goto	u1183_20
u1183_21:
	goto	i1l7640
u1183_20:
	line	1275
	
i1l7638:	
;charge_mgr.c: 1273: {
;charge_mgr.c: 1275: duty_target = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	1276
;charge_mgr.c: 1276: duty_initial = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	1277
;charge_mgr.c: 1277: }
	goto	i1l7648
	line	1278
	
i1l7640:	
;charge_mgr.c: 1278: else if(preCount > 0)
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u1184_21
	goto	u1184_20
u1184_21:
	goto	i1l7644
u1184_20:
	line	1281
	
i1l7642:	
;charge_mgr.c: 1279: {
;charge_mgr.c: 1281: duty_target = 8;
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	1282
;charge_mgr.c: 1282: duty_initial = 5;
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	1283
;charge_mgr.c: 1283: }
	goto	i1l7648
	line	1288
	
i1l7644:	
;charge_mgr.c: 1284: else
;charge_mgr.c: 1285: {
;charge_mgr.c: 1288: g_pwmDuty = 25;
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l877
	line	1292
	
i1l7648:	
;charge_mgr.c: 1290: }
;charge_mgr.c: 1292: if(g_pwmDuty < duty_initial)
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u1185_21
	goto	u1185_20
u1185_21:
	goto	i1l7656
u1185_20:
	line	1295
	
i1l7650:	
;charge_mgr.c: 1293: {
;charge_mgr.c: 1295: g_pwmDuty += 3;
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	1296
	
i1l7652:	
;charge_mgr.c: 1296: if(g_pwmDuty > duty_initial)
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u1186_21
	goto	u1186_20
u1186_21:
	goto	i1l877
u1186_20:
	line	1297
	
i1l7654:	
;charge_mgr.c: 1297: g_pwmDuty = duty_initial;
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l877
	line	1299
	
i1l7656:	
	line	1302
	
i1l7658:	
;charge_mgr.c: 1300: {
;charge_mgr.c: 1302: g_pwmDuty = duty_target;
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	1303
;charge_mgr.c: 1303: }
	goto	i1l877
	line	1318
	
i1l7664:	
;charge_mgr.c: 1310: }
;charge_mgr.c: 1317: {
;charge_mgr.c: 1318: int error = (int)(3100) - (int)(maxV);
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	1321
;charge_mgr.c: 1321: g_cvIntegral += error * 1;
	movf	(CCCV_Control@error),w
	addwf	(_g_cvIntegral),f
	skipnc
	incf	(_g_cvIntegral+1),f
	movf	(CCCV_Control@error+1),w
	addwf	(_g_cvIntegral+1),f
	line	1322
	
i1l7666:	
;charge_mgr.c: 1322: if(g_cvIntegral > 200)
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u1187_25
	movlw	0C9h
	subwf	(_g_cvIntegral),w
u1187_25:

	skipc
	goto	u1187_21
	goto	u1187_20
u1187_21:
	goto	i1l7670
u1187_20:
	line	1323
	
i1l7668:	
;charge_mgr.c: 1323: g_cvIntegral = 200;
	movlw	0C8h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	clrf	(_g_cvIntegral+1)
	goto	i1l7674
	line	1324
	
i1l7670:	
;charge_mgr.c: 1324: else if(g_cvIntegral < -200)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_cvIntegral+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u1188_25
	movlw	038h
	subwf	(_g_cvIntegral),w
u1188_25:

	skipnc
	goto	u1188_21
	goto	u1188_20
u1188_21:
	goto	i1l7674
u1188_20:
	line	1325
	
i1l7672:	
;charge_mgr.c: 1325: g_cvIntegral = -200;
	movlw	038h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_cvIntegral)
	movlw	0FFh
	movwf	((_g_cvIntegral))+1
	line	1328
	
i1l7674:	
;charge_mgr.c: 1328: int adjust = (error * 4 + g_cvIntegral) / 8;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	movf	(_g_cvIntegral),w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1),w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	1329
	
i1l7676:	
;charge_mgr.c: 1329: int duty = (int)g_pwmDuty + adjust;
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
i1l7678:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	1332
	
i1l7680:	
;charge_mgr.c: 1332: if(duty > 32) duty = 32;
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u1189_25
	movlw	021h
	subwf	(CCCV_Control@duty),w
u1189_25:

	skipc
	goto	u1189_21
	goto	u1189_20
u1189_21:
	goto	i1l7684
u1189_20:
	
i1l7682:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1333
	
i1l7684:	
;charge_mgr.c: 1333: if(duty < 0) duty = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u1190_21
	goto	u1190_20
u1190_21:
	goto	i1l7688
u1190_20:
	
i1l7686:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1335
	
i1l7688:	
;charge_mgr.c: 1335: g_pwmDuty = (unsigned char)duty;
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	1337
	
i1l877:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	i1___bmul

;; *************** function i1___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[COMMON] unsigned char 
;;  __bmul          1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext28
__ptext28:	;psect for function i1___bmul
psect	text28
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_ofi1___bmul
	__size_ofi1___bmul	equ	__end_ofi1___bmul-i1___bmul
	
i1___bmul:	
;incstack = 0
	opt	stack 2
; Regs used in i1___bmul: [wreg+status,2+status,0]
;i1___bmul@multiplier stored from wreg
	movwf	(i1___bmul@multiplier)
	line	6
	
i1l3612:	
	clrf	(i1___bmul@product)
	line	43
	
i1l3614:	
	btfss	(i1___bmul@multiplier),(0)&7
	goto	u416_21
	goto	u416_20
u416_21:
	goto	i1l3618
u416_20:
	line	44
	
i1l3616:	
	movf	(i1___bmul@multiplicand),w
	addwf	(i1___bmul@product),f
	line	45
	
i1l3618:	
	clrc
	rlf	(i1___bmul@multiplicand),f
	line	46
	
i1l3620:	
	clrc
	rrf	(i1___bmul@multiplier),f
	line	47
	movf	((i1___bmul@multiplier)),w
	btfss	status,2
	goto	u417_21
	goto	u417_20
u417_21:
	goto	i1l3614
u417_20:
	line	50
	
i1l3622:	
	movf	(i1___bmul@product),w
	line	51
	
i1l944:	
	return
	opt stack 0
GLOBAL	__end_ofi1___bmul
	__end_ofi1___bmul:
	signat	i1___bmul,89
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] int 
;;  dividend        2    2[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] int 
;;  sign            1    5[COMMON] unsigned char 
;;  counter         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext29
__ptext29:	;psect for function ___awdiv
psect	text29
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
i1l3568:	
	clrf	(___awdiv@sign)
	line	15
	
i1l3570:	
	btfss	(___awdiv@divisor+1),7
	goto	u409_21
	goto	u409_20
u409_21:
	goto	i1l3576
u409_20:
	line	16
	
i1l3572:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
i1l3574:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
i1l3576:	
	btfss	(___awdiv@dividend+1),7
	goto	u410_21
	goto	u410_20
u410_21:
	goto	i1l3582
u410_20:
	line	20
	
i1l3578:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
i1l3580:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
i1l3582:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
i1l3584:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u411_21
	goto	u411_20
u411_21:
	goto	i1l3604
u411_20:
	line	25
	
i1l3586:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	i1l3590
	line	27
	
i1l3588:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
i1l3590:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u412_21
	goto	u412_20
u412_21:
	goto	i1l3588
u412_20:
	line	31
	
i1l3592:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
i1l3594:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u413_25
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u413_25:
	skipc
	goto	u413_21
	goto	u413_20
u413_21:
	goto	i1l3600
u413_20:
	line	33
	
i1l3596:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
i1l3598:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
i1l3600:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
i1l3602:	
	decfsz	(___awdiv@counter),f
	goto	u414_21
	goto	u414_20
u414_21:
	goto	i1l3592
u414_20:
	line	39
	
i1l3604:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u415_21
	goto	u415_20
u415_21:
	goto	i1l3608
u415_20:
	line	40
	
i1l3606:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
i1l3608:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
i1l1056:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
