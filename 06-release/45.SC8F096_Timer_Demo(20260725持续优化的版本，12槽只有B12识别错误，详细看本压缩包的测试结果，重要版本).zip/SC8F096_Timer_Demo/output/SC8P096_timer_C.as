opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ChargeProcess_Slot
	FNCALL	_main,_Do_AdcSample
	FNCALL	_main,_Do_NtcRead
	FNCALL	_main,_Print_DetectLog
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_System_Init
	FNCALL	_main,_uart_send_number
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_Print_DetectLog,_uart_send_char
	FNCALL	_Print_DetectLog,_uart_send_number
	FNCALL	_Print_DetectLog,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_Do_NtcRead,_Read_Temperature
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Do_AdcSample,_ADC_Sample
	FNCALL	_Do_AdcSample,___bmul
	FNCALL	_ChargeProcess_Slot,_ADC_Sample
	FNCALL	_ChargeProcess_Slot,_Detect_BatteryType
	FNCALL	_ChargeProcess_Slot,___bmul
	FNCALL	_ChargeProcess_Slot,___lldiv
	FNCALL	_ChargeProcess_Slot,___lmul
	FNCALL	_ChargeProcess_Slot,___lwdiv
	FNCALL	_ChargeProcess_Slot,___wmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_CCCV_Control
	FNCALL	_Isr_Timer,_Charging_Control
	FNCALL	_Isr_Timer,_Led_BlinkProcess
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Update_LED_Slot
	FNCALL	_Isr_Timer,i1_ADC_Sample
	FNCALL	_Isr_Timer,i1___lldiv
	FNCALL	_Charging_Control,i1___bmul
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,i1___bmul
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_temperature
	global	_g_vcc_mv
	global	_g_impCheckSlot
psect	idataBANK0,class=CODE,space=0,delta=2,noexec
global __pidataBANK0
__pidataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	12

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	15

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	19

;initializer for _g_impCheckSlot
	retlw	0FFh
	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	47
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_powerOnTimer
	global	_g_vccProtect
	global	_g_tempProtect
	global	_g_dbgNewType
	global	_g_dbgNewState
	global	_g_dbgOldState
	global	_g_dbgSlot
	global	_g_tempPhase
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_scanPhase
	global	_g_scanIndex
	global	_g_detectLogType
	global	_g_detectLogSlot
	global	_test_adc
	global	_g_blinkTick
	global	_adresult
	global	_g_dbgDetectFlag
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_adcBusy
	global	_g_doAdcSample
	global	_g_detectLogFlag
	global	_g_detectLowCnt
	global	_g_highVFlag
	global	_g_impData
	global	_g_capFlag
	global	_g_dbgVoltage
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_cvIntegral
	global	_g_slot
	global	_g_slotRefV
	global	_g_stableCnt
	global	_g_ovCnt
	global	_g_ccBlocks
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_GIE
_GIE	set	0x5F
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RC4
_RC4	set	0x834
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC5
_RC5	set	0x835
	global	_RC3
_RC3	set	0x833
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_32:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_33:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_31:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_34:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	45	;'-'
	retlw	105	;'i'
	retlw	111	;'o'
	retlw	110	;'n'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_8:	
	retlw	67	;'C'
	retlw	32	;' '
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	95	;'_'
	retlw	76	;'L'
	retlw	79	;'O'
	retlw	67	;'C'
	retlw	75	;'K'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_36:	
	retlw	68	;'D'
	retlw	66	;'B'
	retlw	71	;'G'
	retlw	58	;':'
	retlw	32	;' '
	retlw	115	;'s'
	retlw	108	;'l'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_35:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_11:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_37:	
	retlw	32	;' '
	retlw	111	;'o'
	retlw	108	;'l'
	retlw	100	;'d'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_38:	
	retlw	32	;' '
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	119	;'w'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_25:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	73	;'I'
	retlw	79	;'O'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_23:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_27:	
	retlw	32	;' '
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_40:	
	retlw	32	;' '
	retlw	86	;'V'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
STR_39	equ	STR_28+0
STR_7	equ	STR_2+0
STR_9	equ	STR_35+7
STR_29	equ	STR_35+7
STR_30	equ	STR_35+7
STR_41	equ	STR_35+7
; #config settings
	file	"SC8P096_timer_C.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssBANK0,class=BANK0,bit,space=1,noexec
global __pbitbssBANK0
__pbitbssBANK0:
_g_dbgDetectFlag:
       ds      1

_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

_g_adcBusy:
       ds      1

_g_doAdcSample:
       ds      1

_g_detectLogFlag:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_powerOnTimer:
       ds      2

_g_vccProtect:
       ds      1

_g_tempProtect:
       ds      1

_g_dbgNewType:
       ds      1

_g_dbgNewState:
       ds      1

_g_dbgOldState:
       ds      1

_g_dbgSlot:
       ds      1

_g_tempPhase:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_scanPhase:
       ds      1

_g_scanIndex:
       ds      1

_g_detectLogType:
       ds      1

_g_detectLogSlot:
       ds      1

_test_adc:
       ds      1

_g_blinkTick:
       ds      1

_adresult:
       ds      2

psect	dataBANK0,class=BANK0,space=1,noexec
global __pdataBANK0
__pdataBANK0:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	12
_g_temperature:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_detectLowCnt:
       ds      12

_g_highVFlag:
       ds      2

_g_impData:
       ds      2

_g_capFlag:
       ds      2

_g_dbgVoltage:
       ds      2

_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_cvIntegral:
       ds      2

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	15
_g_vcc_mv:
       ds      2

psect	dataBANK1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	19
_g_impCheckSlot:
       ds      1

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slotRefV:
       ds      24

_g_stableCnt:
       ds      12

_g_ovCnt:
       ds      12

_g_ccBlocks:
       ds      12

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"SC8P096_timer_C.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
	fcall	__pidataBANK1+2		;fetch initializer
	movwf	__pdataBANK1+2&07fh		
; Initialize objects allocated to BANK0
	global __pidataBANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	fcall	__pidataBANK0+0		;fetch initializer
	movwf	__pdataBANK0+0&07fh		
	fcall	__pidataBANK0+1		;fetch initializer
	movwf	__pdataBANK0+1&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+03Ch)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+01Ch)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+014h)
	fcall	clear_ram0
; Clear objects allocated to BITBANK0
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssBANK0/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK3,class=BANK3,space=1,noexec
global __pcstackBANK3
__pcstackBANK3:
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0x0
	global	ChargeProcess_Slot@bat_mv_long_400
ChargeProcess_Slot@bat_mv_long_400:	; 4 bytes @ 0x0
	ds	4
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x4
	global	_ChargeProcess_Slot$402
_ChargeProcess_Slot$402:	; 2 bytes @ 0x4
	ds	2
	global	ChargeProcess_Slot@v_ref
ChargeProcess_Slot@v_ref:	; 2 bytes @ 0x6
	ds	2
	global	ChargeProcess_Slot@bat_mv
ChargeProcess_Slot@bat_mv:	; 2 bytes @ 0x8
	ds	2
	global	ChargeProcess_Slot@bat_mv_398
ChargeProcess_Slot@bat_mv_398:	; 2 bytes @ 0xA
	ds	2
	global	ChargeProcess_Slot@bat_mv_401
ChargeProcess_Slot@bat_mv_401:	; 2 bytes @ 0xC
	ds	4
	global	ChargeProcess_Slot@st
ChargeProcess_Slot@st:	; 1 bytes @ 0x10
	ds	1
	global	ChargeProcess_Slot@ct
ChargeProcess_Slot@ct:	; 2 bytes @ 0x11
	ds	2
	global	ChargeProcess_Slot@ty
ChargeProcess_Slot@ty:	; 1 bytes @ 0x13
	ds	1
psect	cstackBANK2,class=BANK2,space=1,noexec
global __pcstackBANK2
__pcstackBANK2:
	global	ChargeProcess_Slot@v
ChargeProcess_Slot@v:	; 2 bytes @ 0x0
	ds	2
	global	ChargeProcess_Slot@idx
ChargeProcess_Slot@idx:	; 1 bytes @ 0x2
	ds	1
??_main:	; 1 bytes @ 0x3
	ds	2
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
	global	?___lmul
?___lmul:	; 4 bytes @ 0x0
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x0
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x0
	global	___wmul@product
___wmul@product:	; 2 bytes @ 0x0
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x0
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x1
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x1
	ds	1
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x2
	ds	1
?_uart_send_number:	; 1 bytes @ 0x3
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x3
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x4
	ds	1
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x5
	ds	2
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x8
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x8
	ds	1
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	2
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0xB
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0xC
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0xC
	ds	1
??_Do_AdcSample:	; 1 bytes @ 0xD
	global	_Print_NtcTemp$753
_Print_NtcTemp$753:	; 2 bytes @ 0xD
	ds	1
	global	Do_AdcSample@ch
Do_AdcSample@ch:	; 1 bytes @ 0xE
	ds	1
	global	Do_AdcSample@ty
Do_AdcSample@ty:	; 1 bytes @ 0xF
	global	_Print_NtcTemp$754
_Print_NtcTemp$754:	; 2 bytes @ 0xF
	ds	1
	global	Do_AdcSample@dly
Do_AdcSample@dly:	; 1 bytes @ 0x10
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x10
	ds	1
	global	Do_AdcSample@st
Do_AdcSample@st:	; 1 bytes @ 0x11
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x11
	ds	4
??_Read_Temperature:	; 1 bytes @ 0x15
??_ChargeProcess_Slot:	; 1 bytes @ 0x15
??_Print_SystemStatus:	; 1 bytes @ 0x15
	ds	4
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x19
	ds	1
	global	ChargeProcess_Slot@v_init
ChargeProcess_Slot@v_init:	; 2 bytes @ 0x1A
	ds	2
	global	ChargeProcess_Slot@vx_mv
ChargeProcess_Slot@vx_mv:	; 4 bytes @ 0x1C
	ds	1
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x1D
	global	_Print_SystemStatus$755
_Print_SystemStatus$755:	; 2 bytes @ 0x1D
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x1F
	global	_Print_SystemStatus$756
_Print_SystemStatus$756:	; 2 bytes @ 0x1F
	ds	1
	global	ChargeProcess_Slot@bat_mv_long
ChargeProcess_Slot@bat_mv_long:	; 4 bytes @ 0x20
	ds	1
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x21
	ds	3
	global	ChargeProcess_Slot@vx_mv_396
ChargeProcess_Slot@vx_mv_396:	; 4 bytes @ 0x24
	ds	1
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x25
	ds	1
	global	_Print_SystemStatus$285
_Print_SystemStatus$285:	; 2 bytes @ 0x26
	ds	2
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x28
	global	ChargeProcess_Slot@bat_mv_long_397
ChargeProcess_Slot@bat_mv_long_397:	; 4 bytes @ 0x28
	ds	2
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0x2A
	ds	2
	global	ChargeProcess_Slot@vx_mv_399
ChargeProcess_Slot@vx_mv_399:	; 4 bytes @ 0x2C
	ds	2
	global	Print_SystemStatus@t
Print_SystemStatus@t:	; 1 bytes @ 0x2E
	ds	1
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x2F
	ds	1
	global	ChargeProcess_Slot@old_st
ChargeProcess_Slot@old_st:	; 1 bytes @ 0x30
	ds	1
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Update_LED_Slot:	; 1 bytes @ 0x0
??_Update_LED_Slot:	; 1 bytes @ 0x0
?_Charging_Control:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Led_BlinkProcess:	; 1 bytes @ 0x0
??_Led_BlinkProcess:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_ChargeProcess_Slot:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Do_AdcSample:	; 1 bytes @ 0x0
?_Do_NtcRead:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_Print_DetectLog:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?i1_ADC_Sample:	; 1 bytes @ 0x0
?i1___bmul:	; 1 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	?i1___lldiv
?i1___lldiv:	; 4 bytes @ 0x0
Update_LED_Slot@idx:	; 1 bytes @ 0x0
	global	i1ADC_Sample@adldo
i1ADC_Sample@adldo:	; 1 bytes @ 0x0
	global	i1___bmul@multiplicand
i1___bmul@multiplicand:	; 1 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	global	i1___lldiv@divisor
i1___lldiv@divisor:	; 4 bytes @ 0x0
	ds	1
??i1_ADC_Sample:	; 1 bytes @ 0x1
??i1___bmul:	; 1 bytes @ 0x1
	global	i1___bmul@multiplier
i1___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
	global	i1___bmul@product
i1___bmul@product:	; 1 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_Charging_Control:	; 1 bytes @ 0x3
	global	Charging_Control@chargeB1_6
Charging_Control@chargeB1_6:	; 1 bytes @ 0x3
	ds	1
??___awdiv:	; 1 bytes @ 0x4
	global	Charging_Control@chargeB7_12
Charging_Control@chargeB7_12:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	global	i1___lldiv@dividend
i1___lldiv@dividend:	; 4 bytes @ 0x4
	ds	1
	global	Charging_Control@s
Charging_Control@s:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	ds	1
	global	Charging_Control@i
Charging_Control@i:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	2
??_CCCV_Control:	; 1 bytes @ 0x8
??i1___lldiv:	; 1 bytes @ 0x8
	global	i1___lldiv@counter
i1___lldiv@counter:	; 1 bytes @ 0x8
	ds	1
	global	i1___lldiv@quotient
i1___lldiv@quotient:	; 4 bytes @ 0x9
	ds	4
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	i1ADC_Sample@adch
i1ADC_Sample@adch:	; 1 bytes @ 0x0
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x0
	ds	1
	global	i1ADC_Sample@j
i1ADC_Sample@j:	; 1 bytes @ 0x1
	ds	1
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x2
	global	i1ADC_Sample@i
i1ADC_Sample@i:	; 1 bytes @ 0x2
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x3
	global	i1ADC_Sample@adsum
i1ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0x4
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0x5
	ds	1
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x6
	ds	1
	global	i1ADC_Sample@admin
i1ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x8
	ds	1
	global	i1ADC_Sample@admax
i1ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	1
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xA
	ds	1
	global	i1ADC_Sample@ad_temp
i1ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0xC
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0xD
	ds	1
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0xE
	ds	2
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x10
	ds	1
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x11
	ds	1
??_Isr_Timer:	; 1 bytes @ 0x12
	ds	4
	global	Isr_Timer@pt
Isr_Timer@pt:	; 4 bytes @ 0x16
	ds	4
??_AD_Init:	; 1 bytes @ 0x1A
??_uart_init:	; 1 bytes @ 0x1A
?_ADC_Sample:	; 1 bytes @ 0x1A
??_uart_send_char:	; 1 bytes @ 0x1A
?_Detect_BatteryType:	; 1 bytes @ 0x1A
??___lmul:	; 1 bytes @ 0x1A
?___bmul:	; 1 bytes @ 0x1A
	global	?___wmul
?___wmul:	; 2 bytes @ 0x1A
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x1A
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x1A
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x1A
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x1A
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x1A
	global	___wmul@multiplier
___wmul@multiplier:	; 2 bytes @ 0x1A
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x1A
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x1A
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x1A
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x1B
??___bmul:	; 1 bytes @ 0x1B
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x1B
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x1B
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x1C
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x1C
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x1C
	global	___wmul@multiplicand
___wmul@multiplicand:	; 2 bytes @ 0x1C
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x1C
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x1C
	ds	1
?_uart_send_string:	; 1 bytes @ 0x1D
??_System_Init:	; 1 bytes @ 0x1D
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x1D
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x1D
	ds	1
??___wmul:	; 1 bytes @ 0x1E
??___lldiv:	; 1 bytes @ 0x1E
??___lwdiv:	; 1 bytes @ 0x1E
??___lwmod:	; 1 bytes @ 0x1E
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x1E
	ds	1
??_uart_send_string:	; 1 bytes @ 0x1F
??_uart_send_number:	; 1 bytes @ 0x1F
??_Do_NtcRead:	; 1 bytes @ 0x1F
??_Print_NtcTemp:	; 1 bytes @ 0x1F
??_Print_DetectLog:	; 1 bytes @ 0x1F
;!
;!Data Sizes:
;!    Strings     361
;!    Constant    12
;!    Data        5
;!    BSS         180
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     13      13
;!    BANK0            80     31      54
;!    BANK1            80     49      80
;!    BANK3            80     20      80
;!    BANK2            80      5      77

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 37
;!		 -> STR_41(CODE[3]), STR_40(CODE[4]), STR_39(CODE[5]), STR_38(CODE[6]), 
;!		 -> STR_37(CODE[6]), STR_36(CODE[11]), STR_35(CODE[10]), STR_34(CODE[21]), 
;!		 -> STR_33(CODE[34]), STR_32(CODE[37]), STR_31(CODE[33]), STR_30(CODE[3]), 
;!		 -> STR_29(CODE[3]), STR_28(CODE[5]), STR_27(CODE[5]), STR_26(CODE[6]), 
;!		 -> STR_25(CODE[6]), STR_24(CODE[6]), STR_23(CODE[6]), STR_22(CODE[16]), 
;!		 -> STR_21(CODE[13]), STR_20(CODE[15]), STR_19(CODE[7]), STR_18(CODE[5]), 
;!		 -> STR_17(CODE[5]), STR_16(CODE[6]), STR_15(CODE[6]), STR_14(CODE[6]), 
;!		 -> STR_13(CODE[7]), STR_12(CODE[4]), STR_11(CODE[6]), STR_10(CODE[6]), 
;!		 -> STR_9(CODE[3]), STR_8(CODE[12]), STR_7(CODE[2]), STR_6(CODE[6]), 
;!		 -> STR_5(CODE[5]), STR_4(CODE[29]), STR_3(CODE[4]), STR_2(CODE[2]), 
;!		 -> STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->i1___lldiv
;!    _Charging_Control->i1___bmul
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_uart_send_string
;!    _System_Init->___bmul
;!    _Print_SystemStatus->_ADC_Sample
;!    _Print_SystemStatus->___lwmod
;!    _Print_SystemStatus->_uart_send_string
;!    _Print_NtcTemp->___lwmod
;!    _Print_NtcTemp->_uart_send_string
;!    _Print_DetectLog->_uart_send_string
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwmod
;!    _Read_Temperature->_ADC_Sample
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->_ADC_Sample
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    _Isr_Timer->_CCCV_Control
;!
;!Critical Paths under _main in BANK1
;!
;!    _main->_ChargeProcess_Slot
;!    _main->_Print_SystemStatus
;!    _Print_SystemStatus->___lldiv
;!    _Print_NtcTemp->_uart_send_number
;!    _Print_DetectLog->_uart_send_number
;!    _uart_send_number->___lwdiv
;!    _Do_NtcRead->_Read_Temperature
;!    _Read_Temperature->___lldiv
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->___lldiv
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    _main->_ChargeProcess_Slot
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    _main->_ChargeProcess_Slot
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 2     2      0   74315
;!                                              3 BANK2      2     2      0
;!                 _ChargeProcess_Slot
;!                       _Do_AdcSample
;!                         _Do_NtcRead
;!                    _Print_DetectLog
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                        _System_Init
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1533
;!                                             29 BANK0      1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  33    33      0   17047
;!                                             21 BANK1     28    28      0
;!                                              0 BANK3      5     5      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    8634
;!                                             13 BANK1      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_DetectLog                                      0     0      0    7226
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    3473
;!                                             29 BANK0      2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_number                                    10     8      2    3609
;!                                              3 BANK1     10     8      2
;!                             ___bmul (ARG)
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     144
;!                                             26 BANK0      3     3      0
;! ---------------------------------------------------------------------------------
;! (2) ___lwmod                                              5     1      4     518
;!                                             26 BANK0      5     1      4
;! ---------------------------------------------------------------------------------
;! (1) _Do_NtcRead                                           0     0      0    7394
;!                   _Read_Temperature
;! ---------------------------------------------------------------------------------
;! (2) _Read_Temperature                                    12    12      0    7394
;!                                             21 BANK1     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (1) _Do_AdcSample                                         5     5      0    3353
;!                                             13 BANK1      5     5      0
;!                         _ADC_Sample
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _ChargeProcess_Slot                                  51    51      0   22046
;!                                             21 BANK1     28    28      0
;!                                              0 BANK3     20    20      0
;!                                              0 BANK2      3     3      0
;!                         _ADC_Sample
;!                 _Detect_BatteryType
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (2) ___wmul                                               6     2      4    2260
;!                                             26 BANK0      4     0      4
;!                                              0 BANK1      2     2      0
;! ---------------------------------------------------------------------------------
;! (2) ___lwdiv                                              7     3      4    1010
;!                                             26 BANK0      4     0      4
;!                                              0 BANK1      3     3      0
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8    2762
;!                                             26 BANK0      4     4      0
;!                                              0 BANK1      8     0      8
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1554
;!                                              8 BANK1     13     5      8
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1    1185
;!                                             26 BANK0      3     2      1
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     331
;!                                             26 BANK0      2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _ADC_Sample                                          18    17      1    1508
;!                                             26 BANK0      5     4      1
;!                                              0 BANK1     13    13      0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 2
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            8     8      0    3961
;!                                             18 BANK0      8     8      0
;!                       _CCCV_Control
;!                   _Charging_Control
;!                   _Led_BlinkProcess
;!                 _PowerOnLedSequence
;!                    _Update_LED_Slot
;!                       i1_ADC_Sample
;!                          i1___lldiv
;! ---------------------------------------------------------------------------------
;! (5) i1___lldiv                                           13     5      8      44
;!                                              0 COMMON    13     5      8
;! ---------------------------------------------------------------------------------
;! (5) i1_ADC_Sample                                        18    17      1     805
;!                                              0 COMMON     5     4      1
;!                                              0 BANK0     13    13      0
;! ---------------------------------------------------------------------------------
;! (5) _Update_LED_Slot                                      1     1      0       0
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Led_BlinkProcess                                     0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Charging_Control                                     4     4      0     797
;!                                              3 COMMON     4     4      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _CCCV_Control                                        20    20      0    2267
;!                                              8 COMMON     2     2      0
;!                                              0 BANK0     18    18      0
;!                            ___awdiv
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (6) i1___bmul                                             3     2      1     125
;!                                              0 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (6) ___awdiv                                              8     4      4     606
;!                                              0 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ChargeProcess_Slot
;!     _ADC_Sample
;!     _Detect_BatteryType
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___wmul
;!   _Do_AdcSample
;!     _ADC_Sample
;!     ___bmul
;!   _Do_NtcRead
;!     _Read_Temperature
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!       ___lwdiv
;!   _Print_DetectLog
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _uart_send_number
;!     ___bmul (ARG)
;!     ___lwdiv (ARG)
;!     ___lwmod (ARG)
;!     _uart_send_char (ARG)
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     i1___bmul
;!   _Charging_Control
;!     i1___bmul
;!   _Led_BlinkProcess
;!   _PowerOnLedSequence
;!   _Update_LED_Slot
;!   i1_ADC_Sample
;!   i1___lldiv
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50     14      50       8      100.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      5      4D      10       96.3%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50     31      50       6      100.0%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     1F      36       4       67.5%
;!BITBANK0            50      0       1       3        1.3%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      D       D       1       92.9%
;!BITCOMMON            E      0       0       0        0.0%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     130      12        0.0%
;!ABS                  0      0     130      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 514 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       2
;;      Totals:         0       0       0       0       2
;;Total ram usage:        2 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ChargeProcess_Slot
;;		_Do_AdcSample
;;		_Do_NtcRead
;;		_Print_DetectLog
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_System_Init
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	514
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	514
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	517
	
l7930:	
;main.c: 517: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
movwf	((??_main+0)^0100h+0+1),f
	movlw	241
movwf	((??_main+0)^0100h+0),f
	u12087:
decfsz	((??_main+0)^0100h+0),f
	goto	u12087
	decfsz	((??_main+0)^0100h+0+1),f
	goto	u12087
opt asmopt_pop

	line	518
# 518 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	521
	
l7932:	
;main.c: 521: System_Init();
	fcall	_System_Init
	line	524
	
l7934:	
;main.c: 524: uart_send_string("L1211 Charger V2.1\r\n");
	movlw	low(((STR_34)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_34)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	525
	
l7936:	
;main.c: 525: uart_send_string("Init...\r\n");
	movlw	low(((STR_35)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_35)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	528
;main.c: 528: while(1)
	
l478:	
	line	530
# 530 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	533
	
l7938:	
;main.c: 533: if(g_doAdcSample)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u12031
	goto	u12030
u12031:
	goto	l7968
u12030:
	line	535
	
l7940:	
;main.c: 534: {
;main.c: 535: g_doAdcSample = 0;
	bcf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	line	536
;main.c: 536: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	537
	
l7942:	
;main.c: 537: Do_AdcSample();
	fcall	_Do_AdcSample
	line	538
	
l7944:	
;main.c: 538: ChargeProcess_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_ChargeProcess_Slot
	line	541
	
l7946:	
;main.c: 541: if(g_dbgDetectFlag)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	goto	u12041
	goto	u12040
u12041:
	goto	l7966
u12040:
	line	543
	
l7948:	
;main.c: 542: {
;main.c: 543: g_dbgDetectFlag = 0;
	bcf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	544
	
l7950:	
;main.c: 544: uart_send_string("DBG: slot=");
	movlw	low(((STR_36)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_36)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	545
	
l7952:	
;main.c: 545: uart_send_number(g_dbgSlot);
	movf	(_g_dbgSlot),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	546
	
l7954:	
;main.c: 546: uart_send_string(" old=");
	movlw	low(((STR_37)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_37)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	547
;main.c: 547: uart_send_number(g_dbgOldState);
	movf	(_g_dbgOldState),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	548
	
l7956:	
;main.c: 548: uart_send_string(" new=");
	movlw	low(((STR_38)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_38)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	549
	
l7958:	
;main.c: 549: uart_send_number(g_dbgNewState);
	movf	(_g_dbgNewState),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	550
;main.c: 550: uart_send_string(" ty=");
	movlw	low(((STR_39)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_39)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	551
	
l7960:	
;main.c: 551: uart_send_number(g_dbgNewType);
	movf	(_g_dbgNewType),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	552
	
l7962:	
;main.c: 552: uart_send_string(" V=");
	movlw	low(((STR_40)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_40)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	553
;main.c: 553: uart_send_number(g_dbgVoltage);
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_dbgVoltage+1)^080h,w	;volatile
	movwf	(uart_send_number@num+1)^080h
	movf	(_g_dbgVoltage)^080h,w	;volatile
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	554
	
l7964:	
;main.c: 554: uart_send_string("\r\n");
	movlw	low(((STR_41)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_41)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	557
	
l7966:	
;main.c: 555: }
;main.c: 557: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	561
	
l7968:	
;main.c: 558: }
;main.c: 561: if(g_doNtcRead)
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u12051
	goto	u12050
u12051:
	goto	l7976
u12050:
	line	563
	
l7970:	
;main.c: 562: {
;main.c: 563: g_doNtcRead = 0;
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	564
;main.c: 564: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	565
	
l7972:	
;main.c: 565: Do_NtcRead();
	fcall	_Do_NtcRead
	line	566
	
l7974:	
;main.c: 566: g_adcBusy = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	570
	
l7976:	
;main.c: 567: }
;main.c: 570: if(g_printFlag)
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u12061
	goto	u12060
u12061:
	goto	l7982
u12060:
	line	572
	
l7978:	
;main.c: 571: {
;main.c: 572: g_printFlag = 0;
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	573
	
l7980:	
;main.c: 573: Print_SystemStatus();
	fcall	_Print_SystemStatus
	line	574
;main.c: 574: Print_NtcTemp();
	fcall	_Print_NtcTemp
	line	578
	
l7982:	
;main.c: 575: }
;main.c: 578: if(g_detectLogFlag)
	btfss	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	goto	u12071
	goto	u12070
u12071:
	goto	l478
u12070:
	line	580
	
l7984:	
;main.c: 579: {
;main.c: 580: g_detectLogFlag = 0;
	bcf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	line	581
	
l7986:	
;main.c: 581: Print_DetectLog();
	fcall	_Print_DetectLog
	goto	l478
	global	start
	ljmp	start
	opt stack 0
	line	584
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 68 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   29[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	68
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	68
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	73
	
l6704:	
# 73 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	74
# 74 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text1
	line	75
	
l6706:	
;main.c: 75: OSCCON = 0x72;
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	79
;main.c: 79: TRISA = 0xF0; PORTA = 0x0F;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	80
;main.c: 80: TRISB = 0x30; PORTB = 0x4F;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	81
;main.c: 81: TRISC = 0x07; PORTC = 0x00;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l6708:	
	clrf	(262)^0100h	;volatile
	line	82
	
l6710:	
;main.c: 82: TRISD = 0xF0; PORTD = 0x0F;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l6712:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	85
	
l6714:	
;main.c: 85: WPUA = 0x00; WPDA = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l6716:	
	clrf	(135)^080h	;volatile
	line	86
	
l6718:	
;main.c: 86: WPUB = 0x00; WPDB = 0x00;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l6720:	
	clrf	(7)	;volatile
	line	87
	
l6722:	
;main.c: 87: WPUC = 0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	88
	
l6724:	
;main.c: 88: WPUD = 0x00;
	clrf	(277)^0100h	;volatile
	line	91
	
l6726:	
;main.c: 91: IOCA = 0x00; IOCB = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l6728:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	94
	
l6730:	
;main.c: 94: CC0CON = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	95
	
l6732:	
;main.c: 95: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	102
	
l6734:	
;main.c: 102: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	103
	
l6736:	
;main.c: 103: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	104
	
l6738:	
;main.c: 104: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	105
	
l6740:	
;main.c: 105: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	108
	
l6742:	
;main.c: 108: AD_Init();
	fcall	_AD_Init
	line	111
	
l6744:	
;main.c: 111: uart_init();
	fcall	_uart_init
	line	118
;main.c: 118: OPTION_REG = 0x00;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	119
	
l6746:	
;main.c: 119: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	120
	
l6748:	
;main.c: 120: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	121
	
l6750:	
;main.c: 121: INTCON = 0xE0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	124
;main.c: 124: g_pwmDuty = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	125
;main.c: 125: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	126
	
l6752:	
;main.c: 126: RC3 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	127
	
l6754:	
;main.c: 127: RC5 = 0;
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	128
	
l6756:	
;main.c: 128: RB6 = 1;
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	129
	
l6758:	
;main.c: 129: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	132
;main.c: 132: for(i = 0; i < 12; i++)
	clrf	(System_Init@i)
	line	134
	
l6764:	
;main.c: 133: {
;main.c: 134: g_slot[i].state = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	135
;main.c: 135: g_slot[i].type = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	136
;main.c: 136: g_slot[i].voltage = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	137
;main.c: 137: g_slot[i].chargeTimer = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	138
	
l6766:	
;main.c: 138: g_ccBlocks[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	139
	
l6768:	
;main.c: 139: g_ovCnt[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	132
	
l6770:	
	incf	(System_Init@i),f
	
l6772:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u9791
	goto	u9790
u9791:
	goto	l6764
u9790:
	line	141
	
l6774:	
;main.c: 140: }
;main.c: 141: g_blinkTick = 0;
	clrf	(_g_blinkTick)
	line	144
	
l361:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
global __ptext2
__ptext2:	;psect for function _uart_init
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_init: []
	line	23
	
l3096:	
;uart_dbg.c: 23: TRISC &= (unsigned char)~0x10;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
;uart_dbg.c: 24: ANSEL2 &= (unsigned char)~0x10;
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
;uart_dbg.c: 25: RC4 = 1;
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l516:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
global __ptext3
__ptext3:	;psect for function _AD_Init
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l3090:	
;adc_drv.c: 25: CC0CON = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
;adc_drv.c: 26: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	27
	
l3092:	
;adc_drv.c: 27: ADCON0 = 0X81;
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l3094:	
;adc_drv.c: 28: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	29
	
l493:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 373 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  t               1   46[BANK1 ] unsigned char 
;;  bat_mv_long     4    0[BANK3 ] unsigned long 
;;  vx_mv           4   42[BANK1 ] unsigned long 
;;  v               2   40[BANK1 ] unsigned int 
;;  s               1   37[BANK1 ] unsigned char 
;;  pt              4   33[BANK1 ] unsigned long 
;;  vcc_mv          2   47[BANK1 ] unsigned int 
;;  i               1    4[BANK3 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      20       5       0
;;      Temps:          0       0       8       0       0
;;      Totals:         0       0      28       5       0
;;Total ram usage:       33 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	373
global __ptext4
__ptext4:	;psect for function _Print_SystemStatus
psect	text4
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	373
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	378
	
l7018:	
;main.c: 375: unsigned char i;
;main.c: 376: unsigned int vcc_mv;
;main.c: 378: uart_send_string("\r\n== L1211 12CH CHARGER ==\r\n");
	movlw	low(((STR_4)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	381
	
l7020:	
;main.c: 381: test_adc = ADC_Sample(31, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	382
	
l7022:	
;main.c: 382: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u10321
	goto	u10320
u10321:
	goto	l7028
u10320:
	line	384
	
l7024:	
;main.c: 383: {
;main.c: 384: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt)^080h

	line	385
	
l7026:	
;main.c: 385: vcc_mv = (unsigned int)pt;
	movf	(Print_SystemStatus@pt+1)^080h,w
	movwf	(Print_SystemStatus@vcc_mv+1)^080h
	movf	(Print_SystemStatus@pt)^080h,w
	movwf	(Print_SystemStatus@vcc_mv)^080h
	line	386
;main.c: 386: }
	goto	l434
	line	388
	
l7028:	
;main.c: 387: else
;main.c: 388: vcc_mv = 5000;
	movlw	088h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vcc_mv)^080h
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv)^080h)+1
	
l434:	
	line	390
;main.c: 390: g_vcc_mv = vcc_mv;
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	line	392
	
l7030:	
;main.c: 392: uart_send_string("VCC=");
	movlw	low(((STR_5)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	393
	
l7032:	
;main.c: 393: uart_send_number(vcc_mv);
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	394
	
l7034:	
;main.c: 394: uart_send_string("mV T=");
	movlw	low(((STR_6)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	395
	
l7036:	
;main.c: 395: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$755+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$755)^080h
	
l7038:	
;main.c: 395: uart_send_number(g_temperature / 10U);
	movf	(_Print_SystemStatus$755+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$755)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	396
	
l7040:	
;main.c: 396: uart_send_string(".");
	movlw	low(((STR_7)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	397
	
l7042:	
;main.c: 397: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$756+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$756)^080h
	
l7044:	
;main.c: 397: uart_send_number(g_temperature % 10U);
	movf	(_Print_SystemStatus$756+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$756)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	398
	
l7046:	
;main.c: 398: uart_send_string("C IMP_LOCK=");
	movlw	low(((STR_8)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	399
	
l7048:	
;main.c: 399: uart_send_number(g_impCheckSlot == 0xFF ? 0xFFU : (unsigned int)g_impCheckSlot);
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u10331
	goto	u10330
u10331:
	goto	l7052
u10330:
	
l7050:	
	movf	(_g_impCheckSlot)^080h,w
	movwf	(_Print_SystemStatus$285)^080h
	clrf	(_Print_SystemStatus$285+1)^080h
	goto	l7054
	
l7052:	
	movlw	0FFh
	movwf	(_Print_SystemStatus$285)^080h
	clrf	(_Print_SystemStatus$285+1)^080h
	
l7054:	
	movf	(_Print_SystemStatus$285+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$285)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	400
	
l7056:	
;main.c: 400: uart_send_string("\r\n");
	movlw	low(((STR_9)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	407
	
l7058:	
;main.c: 407: for(i = 0; i < 12; i++)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(Print_SystemStatus@i)^0180h
	line	413
	
l7064:	
;main.c: 412: {
;main.c: 413: unsigned int v = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@v)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)^080h
	line	414
;main.c: 414: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@s)^080h
	line	416
	
l7066:	
;main.c: 416: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	417
	
l7068:	
;main.c: 417: uart_send_number((unsigned int)i + 1U);
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	incf	(uart_send_number@num)^080h,f
	skipnz
	incf	(uart_send_number@num+1)^080h,f
	fcall	_uart_send_number
	line	418
;main.c: 418: uart_send_char('=');
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	419
	
l7070:	
;main.c: 419: uart_send_number(v);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(Print_SystemStatus@v)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	425
	
l7072:	
;main.c: 424: {
;main.c: 425: unsigned long vx_mv = (unsigned long)v * (unsigned long)vcc_mv / 4096UL;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Print_SystemStatus@v+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(___lmul@multiplicand)^080h
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv)^080h

	
l7074:	
	movlw	0Ch
u10345:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3)^080h,f
	rrf	(Print_SystemStatus@vx_mv+2)^080h,f
	rrf	(Print_SystemStatus@vx_mv+1)^080h,f
	rrf	(Print_SystemStatus@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u10345

	line	426
	
l7076:	
;main.c: 426: if(vx_mv + 200U >= (unsigned long)vcc_mv)
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	clrf	((??_Print_SystemStatus+0)^080h+0+2)
	clrf	((??_Print_SystemStatus+0)^080h+0+3)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+4)^080h+0)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	(Print_SystemStatus@vx_mv)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+0,f
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1)^080h,w
	goto	u10350
	goto	u10351
u10350:
	addwf	(??_Print_SystemStatus+4)^080h+1,f
u10351:
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2)^080h,w
	goto	u10352
	goto	u10353
u10352:
	addwf	(??_Print_SystemStatus+4)^080h+2,f
u10353:
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	subwf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u10365
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	subwf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u10365
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	subwf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u10365
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	subwf	0+(??_Print_SystemStatus+4)^080h+0,w
u10365:
	skipc
	goto	u10361
	goto	u10360
u10361:
	goto	l7080
u10360:
	line	428
	
l7078:	
;main.c: 427: {
;main.c: 428: uart_send_string(" OPEN");
	movlw	low(((STR_10)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	429
;main.c: 429: }
	goto	l7090
	line	432
	
l7080:	
;main.c: 430: else
;main.c: 431: {
;main.c: 432: unsigned long bat_mv_long = 124UL * vx_mv;
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(Print_SystemStatus@vx_mv)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long)^0180h

	line	433
;main.c: 433: if(bat_mv_long > (206UL * (unsigned long)vcc_mv))
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	(3+(?___lmul))^080h,w
	skipz
	goto	u10375
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long+2)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	(2+(?___lmul))^080h,w
	skipz
	goto	u10375
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	(1+(?___lmul))^080h,w
	skipz
	goto	u10375
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	(0+(?___lmul))^080h,w
u10375:
	skipnc
	goto	u10371
	goto	u10370
u10371:
	goto	l7090
u10370:
	line	435
	
l7082:	
;main.c: 434: {
;main.c: 435: bat_mv_long = (bat_mv_long - 206UL * (unsigned long)vcc_mv + 1000UL/2UL) / 1000UL;
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+3)
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+1)^080h
	movlw	032h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	addwf	(Print_SystemStatus@bat_mv_long)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+4)^080h+0+0)
	movlw	0
	skipnc
	movlw	1
	addwf	(1+(?___lmul))^080h,w
	clrf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	bsf	status, 6	;RP1=1, select bank3
	addwf	(Print_SystemStatus@bat_mv_long+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	movf	(2+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+2),w
	clrf	((??_Print_SystemStatus+4)^080h+0+3)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	bsf	status, 6	;RP1=1, select bank3
	addwf	(Print_SystemStatus@bat_mv_long+2)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	movf	(3+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+3),w
	bsf	status, 6	;RP1=1, select bank3
	addwf	(Print_SystemStatus@bat_mv_long+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	0+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+0,f
	movf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	1+(??_Print_SystemStatus+4)^080h+0,w
	goto	u10380
	goto	u10381
u10380:
	addwf	(??_Print_SystemStatus+0)^080h+1,f
u10381:
	movf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	2+(??_Print_SystemStatus+4)^080h+0,w
	goto	u10382
	goto	u10383
u10382:
	addwf	(??_Print_SystemStatus+0)^080h+2,f
u10383:
	movf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incf	3+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long)^0180h

	line	436
	
l7084:	
;main.c: 436: uart_send_string(" BAT(");
	movlw	low(((STR_11)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	437
	
l7086:	
;main.c: 437: uart_send_number((unsigned int)bat_mv_long);
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	438
	
l7088:	
;main.c: 438: uart_send_string("mV)");
	movlw	low(((STR_12)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	445
	
l7090:	
;main.c: 439: }
;main.c: 441: }
;main.c: 442: }
;main.c: 445: uart_send_char(' ');
	movlw	low(020h)
	fcall	_uart_send_char
	line	446
;main.c: 446: switch(s)
	goto	l7132
	line	448
	
l7092:	
	movlw	low(((STR_13)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7134
	line	449
	
l7094:	
	movlw	low(((STR_14)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7134
	line	450
	
l7096:	
	movlw	low(((STR_15)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7134
	line	451
	
l7098:	
	movlw	low(((STR_16)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7134
	line	452
	
l7100:	
	movlw	low(((STR_17)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7134
	line	453
	
l7102:	
	movlw	low(((STR_18)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7134
	line	454
	
l7104:	
	movlw	low(((STR_19)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7134
	line	457
	
l7106:	
;main.c: 456: {
;main.c: 457: unsigned char t = g_slot[(unsigned char)(i)].type;
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@t)^080h
	line	458
	
l7108:	
;main.c: 458: if(t == 2 || t == 3)
		movlw	2
	xorwf	((Print_SystemStatus@t)^080h),w
	btfsc	status,2
	goto	u10391
	goto	u10390
u10391:
	goto	l7112
u10390:
	
l7110:	
		movlw	3
	xorwf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u10401
	goto	u10400
u10401:
	goto	l7114
u10400:
	line	459
	
l7112:	
;main.c: 459: uart_send_string("[Dry/NiMH ERR]");
	movlw	low(((STR_20)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7134
	line	460
	
l7114:	
;main.c: 460: else if(t == 1)
		decf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u10411
	goto	u10410
u10411:
	goto	l7118
u10410:
	line	461
	
l7116:	
;main.c: 461: uart_send_string("[Li-ion ERR]");
	movlw	low(((STR_21)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7134
	line	462
	
l7118:	
;main.c: 462: else if(t == 6)
		movlw	6
	xorwf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u10421
	goto	u10420
u10421:
	goto	l7122
u10420:
	line	463
	
l7120:	
;main.c: 463: uart_send_string("[Linear Li ERR]");
	movlw	low(((STR_22)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7134
	line	465
	
l7122:	
;main.c: 464: else
;main.c: 465: uart_send_string("[ERR]");
	movlw	low(((STR_23)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7134
	line	468
	
l7124:	
	movlw	low(((STR_24)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7134
	line	469
	
l7126:	
	movlw	low(((STR_25)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7134
	line	470
	
l7128:	
	movlw	low(((STR_26)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7134
	line	446
	
l7132:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@s)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l7092
	xorlw	1^0	; case 1
	skipnz
	goto	l7094
	xorlw	2^1	; case 2
	skipnz
	goto	l7096
	xorlw	3^2	; case 3
	skipnz
	goto	l7098
	xorlw	4^3	; case 4
	skipnz
	goto	l7100
	xorlw	5^4	; case 5
	skipnz
	goto	l7102
	xorlw	6^5	; case 6
	skipnz
	goto	l7104
	xorlw	7^6	; case 7
	skipnz
	goto	l7106
	xorlw	8^7	; case 8
	skipnz
	goto	l7124
	xorlw	9^8	; case 9
	skipnz
	goto	l7126
	goto	l7128
	opt asmopt_pop

	line	474
	
l7134:	
;main.c: 474: uart_send_string(" ct=");
	movlw	low(((STR_27)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	475
	
l7136:	
;main.c: 475: uart_send_number(g_slot[(unsigned char)(i)].chargeTimer);
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	476
	
l7138:	
;main.c: 476: uart_send_string(" ty=");
	movlw	low(((STR_28)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	477
;main.c: 477: uart_send_number(g_slot[(unsigned char)(i)].type);
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	480
	
l7140:	
;main.c: 480: uart_send_string("\r\n");
	movlw	low(((STR_29)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	407
	
l7142:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	incf	(Print_SystemStatus@i)^0180h,f
	
l7144:	
	movlw	low(0Ch)
	subwf	(Print_SystemStatus@i)^0180h,w
	skipc
	goto	u10431
	goto	u10430
u10431:
	goto	l7064
u10430:
	line	483
	
l7146:	
;main.c: 482: }
;main.c: 483: uart_send_string("\r\n");
	movlw	low(((STR_30)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	484
	
l465:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 353 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	353
global __ptext5
__ptext5:	;psect for function _Print_NtcTemp
psect	text5
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	353
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	355
	
l7006:	
;main.c: 355: uart_send_string("NTC=");
	movlw	low(((STR_1)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	356
	
l7008:	
;main.c: 356: uart_send_number(g_temperature / 10U);
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_NtcTemp$753+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_NtcTemp$753)^080h
	
l7010:	
;main.c: 356: uart_send_number(g_temperature / 10U);
	movf	(_Print_NtcTemp$753+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$753)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	357
	
l7012:	
;main.c: 357: uart_send_string(".");
	movlw	low(((STR_2)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	358
	
l7014:	
;main.c: 358: uart_send_number(g_temperature % 10U);
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_NtcTemp$754+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_NtcTemp$754)^080h
;main.c: 358: uart_send_number(g_temperature % 10U);
	movf	(_Print_NtcTemp$754+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$754)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	359
	
l7016:	
;main.c: 359: uart_send_string("C\r\n");
	movlw	low(((STR_3)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	360
	
l430:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_Print_DetectLog

;; *************** function _Print_DetectLog *****************
;; Defined at:
;;		line 490 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	line	490
global __ptext6
__ptext6:	;psect for function _Print_DetectLog
psect	text6
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	490
	global	__size_of_Print_DetectLog
	__size_of_Print_DetectLog	equ	__end_of_Print_DetectLog-_Print_DetectLog
	
_Print_DetectLog:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_DetectLog: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	492
	
l7148:	
;main.c: 492: uart_send_char('B');
	movlw	low(042h)
	fcall	_uart_send_char
	line	493
	
l7150:	
;main.c: 493: uart_send_number((unsigned int)g_detectLogSlot + 1U);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_detectLogSlot),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	incf	(uart_send_number@num)^080h,f
	skipnz
	incf	(uart_send_number@num+1)^080h,f
	fcall	_uart_send_number
	line	495
	
l7152:	
;main.c: 495: if(g_detectLogType == 2)
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u10441
	goto	u10440
u10441:
	goto	l7156
u10440:
	line	496
	
l7154:	
;main.c: 496: uart_send_string(": NiMH detected! Not charging.\r\n");
	movlw	low(((STR_31)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l473
	line	497
	
l7156:	
;main.c: 497: else if(g_detectLogType == 3)
		movlw	3
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u10451
	goto	u10450
u10451:
	goto	l7160
u10450:
	line	498
	
l7158:	
;main.c: 498: uart_send_string(": Dry/NiMH detected! Not charging.\r\n");
	movlw	low(((STR_32)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l473
	line	499
	
l7160:	
;main.c: 499: else if(g_detectLogType == 6)
		movlw	6
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u10461
	goto	u10460
u10461:
	goto	l473
u10460:
	line	500
	
l7162:	
;main.c: 500: uart_send_string(": Linear Li detected! Charging.\r\n");
	movlw	low(((STR_33)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	501
	
l473:	
	return
	opt stack 0
GLOBAL	__end_of_Print_DetectLog
	__end_of_Print_DetectLog:
	signat	_Print_DetectLog,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2   29[BANK0 ] PTR const unsigned char 
;;		 -> STR_41(3), STR_40(4), STR_39(5), STR_38(6), 
;;		 -> STR_37(6), STR_36(11), STR_35(10), STR_34(21), 
;;		 -> STR_33(34), STR_32(37), STR_31(33), STR_30(3), 
;;		 -> STR_29(3), STR_28(5), STR_27(5), STR_26(6), 
;;		 -> STR_25(6), STR_24(6), STR_23(6), STR_22(16), 
;;		 -> STR_21(13), STR_20(15), STR_19(7), STR_18(5), 
;;		 -> STR_17(5), STR_16(6), STR_15(6), STR_14(6), 
;;		 -> STR_13(7), STR_12(4), STR_11(6), STR_10(6), 
;;		 -> STR_9(3), STR_8(12), STR_7(2), STR_6(6), 
;;		 -> STR_5(5), STR_4(29), STR_3(4), STR_2(2), 
;;		 -> STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
global __ptext7
__ptext7:	;psect for function _uart_send_string
psect	text7
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l6606:	
;uart_dbg.c: 63: while(*str != '\0')
	goto	l6612
	line	65
	
l6608:	
;uart_dbg.c: 64: {
;uart_dbg.c: 65: uart_send_char(*str++);
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	fcall	_uart_send_char
	
l6610:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(uart_send_string@str),f
	skipnz
	incf	(uart_send_string@str+1),f
	line	66
# 66 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
clrwdt ;# 
psect	text7
	line	63
	
l6612:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u9651
	goto	u9650
u9651:
	goto	l6608
u9650:
	line	68
	
l529:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2    3[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    5[BANK1 ] unsigned char [6]
;;  j               1   12[BANK1 ] unsigned char 
;;  i               1   11[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      10       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext8
__ptext8:	;psect for function _uart_send_number
psect	text8
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l6614:	
;uart_dbg.c: 79: unsigned char buf[6];
;uart_dbg.c: 80: unsigned char i = 0;
	clrf	(uart_send_number@i)^080h
	line	84
	
l6616:	
;uart_dbg.c: 81: unsigned char j;
;uart_dbg.c: 84: if(num == 0)
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u9661
	goto	u9660
u9661:
	goto	l6628
u9660:
	line	86
	
l6618:	
;uart_dbg.c: 85: {
;uart_dbg.c: 86: uart_send_char('0');
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l533
	line	93
	
l6622:	
;uart_dbg.c: 92: {
;uart_dbg.c: 93: buf[i++] = '0' + (num % 10);
	movf	(uart_send_number@i)^080h,w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@num+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@num)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank1
	movwf	indf
	
l6624:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(uart_send_number@i)^080h,f
	line	94
	
l6626:	
;uart_dbg.c: 94: num /= 10;
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@num+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@num)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	line	91
	
l6628:	
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u9671
	goto	u9670
u9671:
	goto	l6622
u9670:
	line	98
	
l6630:	
;uart_dbg.c: 95: }
;uart_dbg.c: 98: for(j = i; j > 0; j--)
	movf	(uart_send_number@i)^080h,w
	movwf	(uart_send_number@j)^080h
	
l6632:	
	movf	((uart_send_number@j)^080h),w
	btfss	status,2
	goto	u9681
	goto	u9680
u9681:
	goto	l6636
u9680:
	goto	l533
	line	99
	
l6636:	
;uart_dbg.c: 99: uart_send_char(buf[(unsigned char)(j - 1)]);
	movf	(uart_send_number@j)^080h,w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l6638:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decf	(uart_send_number@j)^080h,f
	goto	l6632
	line	100
	
l533:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1   27[BANK0 ] unsigned char 
;;  i               1   28[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext9
__ptext9:	;psect for function _uart_send_char
psect	text9
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_char: [wreg+status,2+status,0]
;uart_send_char@c stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_char@c)
	line	38
	
l6460:	
;uart_dbg.c: 37: unsigned char i;
;uart_dbg.c: 38: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	39
;uart_dbg.c: 39: RC4 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l6462:	
;uart_dbg.c: 40: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u12097:
decfsz	(??_uart_send_char+0)+0,f
	goto	u12097
	nop2
opt asmopt_pop

	line	41
	
l6464:	
;uart_dbg.c: 41: for(i = 0; i < 8; i++)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(uart_send_char@i)
	line	42
	
l519:	
	line	43
;uart_dbg.c: 42: {
;uart_dbg.c: 43: if(c & 0x01)
	btfss	(uart_send_char@c),(0)&7
	goto	u9381
	goto	u9380
u9381:
	goto	l521
u9380:
	line	44
	
l6470:	
;uart_dbg.c: 44: RC4 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l6472
	line	45
	
l521:	
	line	46
;uart_dbg.c: 45: else
;uart_dbg.c: 46: RC4 = 0;
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l6472:	
;uart_dbg.c: 47: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u12107:
decfsz	(??_uart_send_char+0)+0,f
	goto	u12107
	nop2
opt asmopt_pop

	line	48
	
l6474:	
;uart_dbg.c: 48: c >>= 1;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rrf	(uart_send_char@c),f
	line	41
	
l6476:	
	incf	(uart_send_char@i),f
	
l6478:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u9391
	goto	u9390
u9391:
	goto	l519
u9390:
	
l520:	
	line	50
;uart_dbg.c: 49: }
;uart_dbg.c: 50: RC4 = 1;
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l6480:	
;uart_dbg.c: 51: _delay((unsigned long)((104)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u12117:
decfsz	(??_uart_send_char+0)+0,f
	goto	u12117
	nop2
opt asmopt_pop

	line	52
	
l6482:	
;uart_dbg.c: 52: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l523:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   26[BANK0 ] unsigned int 
;;  dividend        2   28[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1   30[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   26[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       5       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext10
__ptext10:	;psect for function ___lwmod
psect	text10
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l6548:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u9511
	goto	u9510
u9511:
	goto	l6564
u9510:
	line	14
	
l6550:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l6554
	line	16
	
l6552:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l6554:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u9521
	goto	u9520
u9521:
	goto	l6552
u9520:
	line	20
	
l6556:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u9535
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u9535:
	skipc
	goto	u9531
	goto	u9530
u9531:
	goto	l6560
u9530:
	line	21
	
l6558:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l6560:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l6562:	
	decfsz	(___lwmod@counter),f
	goto	u9541
	goto	u9540
u9541:
	goto	l6556
u9540:
	line	25
	
l6564:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1221:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	_Do_NtcRead

;; *************** function _Do_NtcRead *****************
;; Defined at:
;;		line 344 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Read_Temperature
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	344
global __ptext11
__ptext11:	;psect for function _Do_NtcRead
psect	text11
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	344
	global	__size_of_Do_NtcRead
	__size_of_Do_NtcRead	equ	__end_of_Do_NtcRead-_Do_NtcRead
	
_Do_NtcRead:	
;incstack = 0
	opt	stack 2
; Regs used in _Do_NtcRead: [wreg+status,2+status,0+pclath+cstack]
	line	346
	
l7004:	
;main.c: 346: Read_Temperature();
	fcall	_Read_Temperature
	line	347
	
l427:	
	return
	opt stack 0
GLOBAL	__end_of_Do_NtcRead
	__end_of_Do_NtcRead:
	signat	_Do_NtcRead,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 37 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   25[BANK1 ] unsigned long 
;;  temp_x10        2   31[BANK1 ] unsigned int 
;;  ntcVal          2   29[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   66[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Do_NtcRead
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	37
global __ptext12
__ptext12:	;psect for function _Read_Temperature
psect	text12
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	37
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 2
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	42
	
l6568:	
;charge_mgr.c: 39: unsigned int ntcVal;
;charge_mgr.c: 40: unsigned int temp_x10;
;charge_mgr.c: 42: test_adc = ADC_Sample(18, 0);
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	43
	
l6570:	
;charge_mgr.c: 43: if(0xA5 != test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u9551
	goto	u9550
u9551:
	goto	l6574
u9550:
	goto	l574
	line	46
	
l6574:	
;charge_mgr.c: 46: ntcVal = adresult;
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal)^080h
	line	47
;charge_mgr.c: 47: if(ntcVal < 100 || ntcVal > 3996)
	movlw	0
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u9561
	goto	u9560
u9561:
	goto	l574
u9560:
	
l6576:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u9571
	goto	u9570
u9571:
	goto	l6578
u9570:
	goto	l574
	line	52
	
l6578:	
;charge_mgr.c: 50: {
;charge_mgr.c: 51: unsigned long rt;
;charge_mgr.c: 52: rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	010h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0
	movwf	(___lldiv@divisor)^080h

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0)
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0+1)
	clrf	((??_Read_Temperature+0)^080h+0+2)
	clrf	((??_Read_Temperature+0)^080h+0+3)
	movf	0+(??_Read_Temperature+0)^080h+0,w
	subwf	(___lldiv@divisor)^080h,f
	movf	1+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)^080h+0,w
	goto	u9585
	goto	u9586
u9585:
	subwf	(___lldiv@divisor+1)^080h,f
u9586:
	movf	2+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)^080h+0,w
	goto	u9587
	goto	u9588
u9587:
	subwf	(___lldiv@divisor+2)^080h,f
u9588:
	movf	3+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)^080h+0,w
	goto	u9589
	goto	u9580
u9589:
	subwf	(___lldiv@divisor+3)^080h,f
u9580:

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0
	movwf	(___lmul@multiplicand+2)^080h
	movlw	027h
	movwf	(___lmul@multiplicand+1)^080h
	movlw	010h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt)^080h

	line	53
	
l6580:	
;charge_mgr.c: 53: if(rt >= 10000UL)
		movf	(Read_Temperature@rt+3)^080h,w
	btfss	status,2
	goto	u9590
	movf	(Read_Temperature@rt+2)^080h,w
	btfss	status,2
	goto	u9590
	movlw	39
	subwf	(Read_Temperature@rt+1)^080h,w
	skipz
	goto	u9593
	movlw	16
	subwf	(Read_Temperature@rt)^080h,w
	skipz
	goto	u9593
u9593:
	btfss	status,0
	goto	u9591
	goto	u9590

u9591:
	goto	l6586
u9590:
	line	54
	
l6582:	
;charge_mgr.c: 54: temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l6584:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0F0h
	movwf	((??_Read_Temperature+0)^080h+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)^080h+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+3)
	movf	(Read_Temperature@rt)^080h,w
	addwf	(??_Read_Temperature+0)^080h+0,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+1)^080h,w
	goto	u9600
	goto	u9601
u9600:
	addwf	(??_Read_Temperature+0)^080h+1,f
u9601:
	movf	(Read_Temperature@rt+2)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+2)^080h,w
	goto	u9602
	goto	u9603
u9602:
	addwf	(??_Read_Temperature+0)^080h+2,f
u9603:
	movf	(Read_Temperature@rt+3)^080h,w
	skipnc
	incf	(Read_Temperature@rt+3)^080h,w
	addwf	(??_Read_Temperature+0)^080h+3,f
	movf	3+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+3)^080h
	movf	2+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+2)^080h
	movf	1+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+1)^080h
	movf	0+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier)^080h

	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(0+(?___lldiv))^080h,w
	subwf	(Read_Temperature@temp_x10)^080h,f
	movf	(1+(?___lldiv))^080h,w
	skipc
	decf	(Read_Temperature@temp_x10+1)^080h,f
	subwf	(Read_Temperature@temp_x10+1)^080h,f
	goto	l6590
	line	56
	
l6586:	
;charge_mgr.c: 55: else
;charge_mgr.c: 56: temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0
	movwf	(___lmul@multiplier+3)^080h
	movlw	0
	movwf	(___lmul@multiplier+2)^080h
	movlw	027h
	movwf	(___lmul@multiplier+1)^080h
	movlw	010h
	movwf	(___lmul@multiplier)^080h

	movf	(Read_Temperature@rt)^080h,w
	subwf	(___lmul@multiplier)^080h,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+1)^080h,w
	subwf	(___lmul@multiplier+1)^080h,f
	movf	(Read_Temperature@rt+2)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+2)^080h,w
	subwf	(___lmul@multiplier+2)^080h,f
	movf	(Read_Temperature@rt+3)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+3)^080h,w
	subwf	(___lmul@multiplier+3)^080h,f
	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10)^080h
	
l6588:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10)^080h,f
	skipnc
	incf	(Read_Temperature@temp_x10+1)^080h,f
	line	57
	
l6590:	
;charge_mgr.c: 57: if(temp_x10 < 100U) temp_x10 = 100U;
	movlw	0
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipnc
	goto	u9611
	goto	u9610
u9611:
	goto	l580
u9610:
	
l6592:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l580:	
	line	58
;charge_mgr.c: 58: if(temp_x10 > 750U) temp_x10 = 750U;
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipc
	goto	u9621
	goto	u9620
u9621:
	goto	l581
u9620:
	
l6594:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)^080h
	movlw	02h
	movwf	((Read_Temperature@temp_x10)^080h)+1
	
l581:	
	line	61
;charge_mgr.c: 59: }
;charge_mgr.c: 61: g_temperature = temp_x10;
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature)
	line	62
	
l6596:	
;charge_mgr.c: 62: if((temp_x10 / 10U) >= 60)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u9631
	goto	u9630
u9631:
	goto	l6600
u9630:
	line	63
	
l6598:	
;charge_mgr.c: 63: g_tempProtect = 1;
	clrf	(_g_tempProtect)
	incf	(_g_tempProtect),f
	goto	l574
	line	64
	
l6600:	
;charge_mgr.c: 64: else if((temp_x10 / 10U) <= 50)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u9641
	goto	u9640
u9641:
	goto	l574
u9640:
	line	65
	
l6602:	
;charge_mgr.c: 65: g_tempProtect = 0;
	clrf	(_g_tempProtect)
	line	68
	
l574:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	_Do_AdcSample

;; *************** function _Do_AdcSample *****************
;; Defined at:
;;		line 273 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  st              1   17[BANK1 ] unsigned char 
;;  dly             1   16[BANK1 ] unsigned char 
;;  ty              1   15[BANK1 ] unsigned char 
;;  ch              1   14[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       0       1       0       0
;;      Totals:         0       0       5       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	273
global __ptext13
__ptext13:	;psect for function _Do_AdcSample
psect	text13
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	273
	global	__size_of_Do_AdcSample
	__size_of_Do_AdcSample	equ	__end_of_Do_AdcSample-_Do_AdcSample
	
_Do_AdcSample:	
;incstack = 0
	opt	stack 3
; Regs used in _Do_AdcSample: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	275
	
l6944:	
;main.c: 275: unsigned char ch = s_adcChannels[g_scanIndex];
	movf	(_g_scanIndex),w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@ch)^080h
	line	276
	
l6946:	
;main.c: 276: unsigned char ty = g_slot[(unsigned char)(g_scanIndex)].type;
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@ty)^080h
	line	277
	
l6948:	
;main.c: 277: unsigned char st = g_slot[(unsigned char)(g_scanIndex)].state;
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@st)^080h
	line	297
	
l6950:	
;main.c: 278: unsigned char dly;
;main.c: 293: if((ty == 6 &&
;main.c: 294: (st == 2 || st == 3 ||
;main.c: 295: st == 4 || st == 5)) ||
;main.c: 296: st == 1 ||
;main.c: 297: st == 8)
		movlw	6
	xorwf	((Do_AdcSample@ty)^080h),w
	btfss	status,2
	goto	u10171
	goto	u10170
u10171:
	goto	l6960
u10170:
	
l6952:	
		movlw	2
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10181
	goto	u10180
u10181:
	goto	l6964
u10180:
	
l6954:	
		movlw	3
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10191
	goto	u10190
u10191:
	goto	l6964
u10190:
	
l6956:	
		movlw	4
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10201
	goto	u10200
u10201:
	goto	l6964
u10200:
	
l6958:	
		movlw	5
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10211
	goto	u10210
u10211:
	goto	l6964
u10210:
	
l6960:	
		decf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10221
	goto	u10220
u10221:
	goto	l6964
u10220:
	
l6962:	
		movlw	8
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u10231
	goto	u10230
u10231:
	goto	l6980
u10230:
	line	301
	
l6964:	
;main.c: 298: {
;main.c: 301: if(st == 1 || st == 8)
		decf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10241
	goto	u10240
u10241:
	goto	l6968
u10240:
	
l6966:	
		movlw	8
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u10251
	goto	u10250
u10251:
	goto	l6980
u10250:
	line	303
	
l6968:	
;main.c: 302: {
;main.c: 303: for(dly = 0; dly < 20; dly++)
	clrf	(Do_AdcSample@dly)^080h
	line	304
	
l6974:	
;main.c: 304: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_Do_AdcSample+0)^080h+0),f
	u12127:
decfsz	(??_Do_AdcSample+0)^080h+0,f
	goto	u12127
	nop
opt asmopt_pop

	line	303
	
l6976:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(Do_AdcSample@dly)^080h,f
	
l6978:	
	movlw	low(014h)
	subwf	(Do_AdcSample@dly)^080h,w
	skipc
	goto	u10261
	goto	u10260
u10261:
	goto	l6974
u10260:
	goto	l6984
	line	308
	
l6980:	
;main.c: 306: else
;main.c: 307: {
;main.c: 308: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_Do_AdcSample+0)^080h+0),f
	u12137:
decfsz	(??_Do_AdcSample+0)^080h+0,f
	goto	u12137
	nop
opt asmopt_pop

	line	316
	
l6984:	
;main.c: 314: }
;main.c: 316: test_adc = ADC_Sample(ch, 0);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@adldo)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Do_AdcSample@ch)^080h,w
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	318
	
l6986:	
;main.c: 318: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u10271
	goto	u10270
u10271:
	goto	l7000
u10270:
	line	323
	
l6988:	
;main.c: 319: {
;main.c: 322: if(ty == 6 && (st == 4 || st == 5)
;main.c: 323: && adresult >= 3990)
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	((Do_AdcSample@ty)^080h),w
	btfss	status,2
	goto	u10281
	goto	u10280
u10281:
	goto	l6998
u10280:
	
l6990:	
		movlw	4
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10291
	goto	u10290
u10291:
	goto	l6994
u10290:
	
l6992:	
		movlw	5
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u10301
	goto	u10300
u10301:
	goto	l6998
u10300:
	
l6994:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_adresult+1),w	;volatile
	movlw	096h
	skipnz
	subwf	(_adresult),w	;volatile
	skipc
	goto	u10311
	goto	u10310
u10311:
	goto	l6998
u10310:
	goto	l7002
	line	329
	
l6998:	
;main.c: 327: else
;main.c: 328: {
;main.c: 329: g_slot[g_scanIndex].voltage = adresult;
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	movf	(_adresult),w	;volatile
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_adresult+1),w	;volatile
	movwf	indf
	goto	l7002
	line	333
	
l7000:	
;main.c: 332: else
;main.c: 333: g_slot[g_scanIndex].voltage = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	335
	
l7002:	
;main.c: 335: g_scanPhase = 1;
	movlw	low(01h)
	movwf	(_g_scanPhase)	;volatile
	line	336
	
l424:	
	return
	opt stack 0
GLOBAL	__end_of_Do_AdcSample
	__end_of_Do_AdcSample:
	signat	_Do_AdcSample,89
	global	_ChargeProcess_Slot

;; *************** function _ChargeProcess_Slot *****************
;; Defined at:
;;		line 135 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    2[BANK2 ] unsigned char 
;;  bat_mv_long     4   32[BANK1 ] unsigned long 
;;  vx_mv           4   28[BANK1 ] unsigned long 
;;  bat_mv          2    8[BANK3 ] unsigned int 
;;  bat_mv_long     4    0[BANK3 ] unsigned long 
;;  vx_mv           4   44[BANK1 ] unsigned long 
;;  bat_mv          2   12[BANK3 ] unsigned int 
;;  bat_mv_long     4   40[BANK1 ] unsigned long 
;;  vx_mv           4   36[BANK1 ] unsigned long 
;;  bat_mv          2   10[BANK3 ] unsigned int 
;;  v_ref           2    6[BANK3 ] unsigned int 
;;  v_init          2   26[BANK1 ] unsigned int 
;;  v               2    0[BANK2 ] unsigned int 
;;  ct              2   17[BANK3 ] unsigned int 
;;  tick            2    0        unsigned int 
;;  ty              1   19[BANK3 ] unsigned char 
;;  st              1   16[BANK3 ] unsigned char 
;;  old_st          1   48[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      23      20       3
;;      Temps:          0       0       5       0       0
;;      Totals:         0       0      28      20       3
;;Total ram usage:       51 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		_Detect_BatteryType
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___wmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	135
global __ptext14
__ptext14:	;psect for function _ChargeProcess_Slot
psect	text14
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	135
	global	__size_of_ChargeProcess_Slot
	__size_of_ChargeProcess_Slot	equ	__end_of_ChargeProcess_Slot-_ChargeProcess_Slot
	
_ChargeProcess_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _ChargeProcess_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;ChargeProcess_Slot@idx stored from wreg
	bsf	status, 6	;RP1=1, select bank2
	movwf	(ChargeProcess_Slot@idx)^0100h
	line	139
	
l7164:	
	line	142
	
l7166:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	
l7168:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	
l7170:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(ChargeProcess_Slot@v)^0100h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v+1)^0100h
	
l7172:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ct)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@ct+1)^0180h
	line	143
	
l7174:	
;charge_mgr.c: 143: old_st = st;
	movf	(ChargeProcess_Slot@st)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@old_st)^080h
	line	145
;charge_mgr.c: 145: switch(st)
	goto	l7800
	line	148
	
l7176:	
;charge_mgr.c: 148: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	149
	
l7178:	
;charge_mgr.c: 149: st = 1;
	clrf	(ChargeProcess_Slot@st)^0180h
	incf	(ChargeProcess_Slot@st)^0180h,f
	line	150
	
l7180:	
;charge_mgr.c: 150: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10474
u10475:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10474:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10475
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	151
;charge_mgr.c: 151: break;
	goto	l7802
	line	154
	
l7182:	
;charge_mgr.c: 154: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	157
	
l7184:	
;charge_mgr.c: 157: if(ct == 1)
		decf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u10481
	goto	u10480
u10481:
	goto	l7190
u10480:
	line	159
	
l7186:	
;charge_mgr.c: 158: {
;charge_mgr.c: 159: g_stableCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	160
	
l7188:	
;charge_mgr.c: 160: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10494
u10495:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10494:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10495
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	163
	
l7190:	
;charge_mgr.c: 161: }
;charge_mgr.c: 163: if(ct < (2 * 100))
	movlw	0
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0C8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u10501
	goto	u10500
u10501:
	goto	l7194
u10500:
	goto	l7802
	line	172
	
l7194:	
;charge_mgr.c: 172: if(ct == (2 * 100))
		movlw	200
	xorwf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u10511
	goto	u10510
u10511:
	goto	l7202
u10510:
	line	174
	
l7196:	
;charge_mgr.c: 173: {
;charge_mgr.c: 174: g_slotRefV[idx] = v;
	bcf	status, 5	;RP0=0, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	175
	
l7198:	
;charge_mgr.c: 175: if(v > 2900)
	movlw	0Bh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u10521
	goto	u10520
u10521:
	goto	l7802
u10520:
	line	176
	
l7200:	
;charge_mgr.c: 176: g_capFlag |= (unsigned int)1 << idx;
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10534
u10535:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10534:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10535
	
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_capFlag+1)^080h,f
	goto	l7802
	line	179
	
l7202:	
;charge_mgr.c: 178: }
;charge_mgr.c: 179: if(v > 2900 && v < 3990)
	movlw	0Bh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u10541
	goto	u10540
u10541:
	goto	l7262
u10540:
	
l7204:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u10551
	goto	u10550
u10551:
	goto	l7262
u10550:
	line	188
	
l7206:	
;charge_mgr.c: 180: {
;charge_mgr.c: 188: if(!(g_capFlag & ((unsigned int)1 << idx)) && ty != 5)
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10564
u10565:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10564:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10565
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfss	status,2
	goto	u10571
	goto	u10570
u10571:
	goto	l7218
u10570:
	
l7208:	
		movlw	5
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u10581
	goto	u10580
u10581:
	goto	l7218
u10580:
	line	190
	
l7210:	
;charge_mgr.c: 189: {
;charge_mgr.c: 190: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	191
	
l7212:	
;charge_mgr.c: 191: g_slotRefV[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	192
	
l7214:	
;charge_mgr.c: 192: g_stableCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	193
	
l7216:	
;charge_mgr.c: 193: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	194
;charge_mgr.c: 194: break;
	goto	l7802
	line	204
	
l7218:	
;charge_mgr.c: 195: }
;charge_mgr.c: 204: unsigned int v_init = g_slotRefV[idx];
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@v_init)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_init+1)^080h
	line	206
;charge_mgr.c: 206: if(g_stableCnt[idx] >= 20)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipc
	goto	u10591
	goto	u10590
u10591:
	goto	l7248
u10590:
	line	211
	
l7220:	
;charge_mgr.c: 207: {
;charge_mgr.c: 211: g_highVFlag |= (unsigned int)1 << idx;
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10604
u10605:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10604:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10605
	
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_highVFlag+1)^080h,f
	line	213
	
l7222:	
;charge_mgr.c: 213: if(v <= 2900)
	movlw	0Bh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u10611
	goto	u10610
u10611:
	goto	l7230
u10610:
	line	216
	
l7224:	
;charge_mgr.c: 214: {
;charge_mgr.c: 216: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10624
u10625:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10624:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10625
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	217
	
l7226:	
;charge_mgr.c: 217: g_stableCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	218
	
l7228:	
;charge_mgr.c: 218: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10634
u10635:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10634:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10635
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	219
;charge_mgr.c: 219: }
	goto	l7274
	line	220
	
l7230:	
;charge_mgr.c: 220: else if(ct < (2 * 100) + (8 * 100))
	movlw	03h
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0E8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u10641
	goto	u10640
u10641:
	goto	l7242
u10640:
	line	226
	
l7232:	
;charge_mgr.c: 221: {
;charge_mgr.c: 225: if((g_highVFlag & ((unsigned int)1 << idx)) &&
;charge_mgr.c: 226: ct >= (2 * 100) + 200U)
	bcf	status, 5	;RP0=0, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10654
u10655:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10654:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10655
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u10661
	goto	u10660
u10661:
	goto	l7238
u10660:
	
l7234:	
	movlw	01h
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	090h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u10671
	goto	u10670
u10671:
	goto	l7238
u10670:
	goto	l7242
	line	229
	
l7238:	
;charge_mgr.c: 229: g_slotRefV[idx] = v;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	230
;charge_mgr.c: 230: break;
	goto	l7802
	line	239
	
l7242:	
;charge_mgr.c: 239: g_capFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10684
u10685:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10684:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10685
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	240
	
l7244:	
;charge_mgr.c: 240: g_stableCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	241
	
l7246:	
;charge_mgr.c: 241: ty = 5;
	movlw	low(05h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	242
;charge_mgr.c: 242: goto amb_check;
	goto	l7298
	line	248
	
l7248:	
;charge_mgr.c: 245: else
;charge_mgr.c: 246: {
;charge_mgr.c: 248: if(v + 50 < v_init)
	movf	(ChargeProcess_Slot@v)^0100h,w
	addlw	low(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(ChargeProcess_Slot@v_init+1)^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u10695
	movf	(ChargeProcess_Slot@v_init)^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u10695:
	skipnc
	goto	u10691
	goto	u10690
u10691:
	goto	l7252
u10690:
	line	251
	
l7250:	
;charge_mgr.c: 249: {
;charge_mgr.c: 251: g_slotRefV[idx] = v;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	252
;charge_mgr.c: 252: g_stableCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	253
;charge_mgr.c: 253: }
	goto	l618
	line	257
	
l7252:	
;charge_mgr.c: 254: else
;charge_mgr.c: 255: {
;charge_mgr.c: 257: g_slotRefV[idx] = v;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	258
;charge_mgr.c: 258: g_stableCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	259
	
l618:	
	line	260
;charge_mgr.c: 259: }
;charge_mgr.c: 260: if(g_stableCnt[idx] < 20)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u10701
	goto	u10700
u10701:
	goto	l7256
u10700:
	goto	l7802
	line	263
	
l7256:	
;charge_mgr.c: 263: if(g_capFlag & ((unsigned int)1 << idx))
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10714
u10715:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10714:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10715
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u10721
	goto	u10720
u10721:
	goto	l7260
u10720:
	goto	l7802
	line	265
	
l7260:	
;charge_mgr.c: 265: g_stableCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7274
	line	268
	
l7262:	
;charge_mgr.c: 268: else if(ct < (2 * 100) + (8 * 100) && v < 3990)
	movlw	03h
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0E8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u10731
	goto	u10730
u10731:
	goto	l7274
u10730:
	
l7264:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u10741
	goto	u10740
u10741:
	goto	l7274
u10740:
	line	270
	
l7266:	
;charge_mgr.c: 269: {
;charge_mgr.c: 270: unsigned int v_ref = g_slotRefV[idx];
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@v_ref)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_ref+1)^0180h
	line	271
	
l7268:	
;charge_mgr.c: 271: if(v_ref < 3990 && v + 50 < v_ref)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v_ref+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v_ref)^0180h,w
	skipnc
	goto	u10751
	goto	u10750
u10751:
	goto	l7274
u10750:
	
l7270:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	addlw	low(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_ref+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u10765
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_ref)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u10765:
	skipnc
	goto	u10761
	goto	u10760
u10761:
	goto	l7274
u10760:
	goto	l7238
	line	281
	
l7274:	
;charge_mgr.c: 275: }
;charge_mgr.c: 276: }
;charge_mgr.c: 281: if(g_capFlag & ((unsigned int)1 << idx))
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10774
u10775:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10774:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10775
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u10781
	goto	u10780
u10781:
	goto	l7282
u10780:
	line	283
	
l7276:	
;charge_mgr.c: 282: {
;charge_mgr.c: 283: g_capFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10794
u10795:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10794:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10795
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	284
	
l7278:	
;charge_mgr.c: 284: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	285
	
l7280:	
;charge_mgr.c: 285: ty = 5;
	movlw	low(05h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	286
;charge_mgr.c: 286: }
	goto	l7284
	line	289
	
l7282:	
;charge_mgr.c: 287: else
;charge_mgr.c: 288: {
;charge_mgr.c: 289: ty = Detect_BatteryType(v);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Detect_BatteryType@voltage+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	294
	
l7284:	
;charge_mgr.c: 290: }
;charge_mgr.c: 294: if(v < 500)
	movlw	01h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0F4h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u10801
	goto	u10800
u10801:
	goto	l7290
u10800:
	line	296
	
l7286:	
;charge_mgr.c: 295: {
;charge_mgr.c: 296: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	297
;charge_mgr.c: 297: if(g_detectLowCnt[idx] < 5)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u10811
	goto	u10810
u10811:
	goto	l7298
u10810:
	goto	l7802
	line	301
	
l7290:	
;charge_mgr.c: 301: else if(ty != 5 && ty != 1 && ty != 6)
		movlw	5
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u10821
	goto	u10820
u10821:
	goto	l7298
u10820:
	
l7292:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u10831
	goto	u10830
u10831:
	goto	l7298
u10830:
	
l7294:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u10841
	goto	u10840
u10841:
	goto	l7298
u10840:
	line	303
	
l7296:	
;charge_mgr.c: 302: {
;charge_mgr.c: 303: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	307
	
l7298:	
;charge_mgr.c: 307: if(ty == 5)
		movlw	5
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u10851
	goto	u10850
u10851:
	goto	l7328
u10850:
	line	314
	
l7300:	
;charge_mgr.c: 308: {
;charge_mgr.c: 314: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	315
;charge_mgr.c: 315: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u10861
	goto	u10860
u10861:
	goto	l7304
u10860:
	goto	l7802
	line	319
	
l7304:	
;charge_mgr.c: 319: if(g_impCheckSlot != 0xFF && g_impCheckSlot != idx)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u10871
	goto	u10870
u10871:
	goto	l7310
u10870:
	
l7306:	
	movf	(_g_impCheckSlot)^080h,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	xorwf	(ChargeProcess_Slot@idx)^0100h,w
	skipnz
	goto	u10881
	goto	u10880
u10881:
	goto	l7310
u10880:
	goto	l7802
	line	321
	
l7310:	
;charge_mgr.c: 321: g_impCheckSlot = idx;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	325
	
l7312:	
;charge_mgr.c: 325: if(0xA5 == ADC_Sample(31, 0))
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u10891
	goto	u10890
u10891:
	goto	l633
u10890:
	line	326
	
l7314:	
;charge_mgr.c: 326: g_vcc_mv = (unsigned int)((4096UL * 1200UL) / adresult);
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(0+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	
l633:	
	line	330
;charge_mgr.c: 330: g_impData = v | ((unsigned int)(((g_vcc_mv + 50U) / 100U) - 38U) << 12);
	movlw	064h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_impData+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_impData)^080h
	
l7316:	
	movlw	0Ch
	
u10905:
	clrc
	rlf	(_g_impData)^080h,f
	rlf	(_g_impData+1)^080h,f
	addlw	-1
	skipz
	goto	u10905
	
l7318:	
	movlw	(0A000h >> 8)
	addwf	(_g_impData+1)^080h,f
	
l7320:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	iorwf	(_g_impData)^080h,f
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	iorwf	(_g_impData+1)^080h,f
	line	331
	
l7322:	
;charge_mgr.c: 331: st = 8;
	movlw	low(08h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	332
	
l7324:	
;charge_mgr.c: 332: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	333
	
l7326:	
;charge_mgr.c: 333: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	335
	
l7328:	
;charge_mgr.c: 334: }
;charge_mgr.c: 335: if(ty == 1 || ty == 6)
	bsf	status, 5	;RP0=1, select bank3
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u10911
	goto	u10910
u10911:
	goto	l7332
u10910:
	
l7330:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u10921
	goto	u10920
u10921:
	goto	l7372
u10920:
	line	338
	
l7332:	
;charge_mgr.c: 336: {
;charge_mgr.c: 338: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	339
;charge_mgr.c: 339: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u10931
	goto	u10930
u10931:
	goto	l7336
u10930:
	goto	l7802
	line	341
	
l7336:	
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv)^080h

	
l7338:	
	movlw	0Ch
u10945:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u10945

	
l7340:	
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long)^080h

	
l7342:	
	movf	(ChargeProcess_Slot@vx_mv+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10951
	addwf	(ChargeProcess_Slot@bat_mv_long+1)^080h,f
u10951:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10952
	addwf	(ChargeProcess_Slot@bat_mv_long+2)^080h,f
u10952:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u10953
	addwf	(ChargeProcess_Slot@bat_mv_long+3)^080h,f
u10953:

	
l7344:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	goto	u10960
	goto	u10961
u10960:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u10961:
	movf	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	goto	u10962
	goto	u10963
u10962:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u10963:
	movf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv)^0180h
	
l7346:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u10971
	goto	u10970
u10971:
	goto	l7350
u10970:
	
l7348:	
	movlw	low(02h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l7366
	
l7350:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u10981
	goto	u10980
u10981:
	goto	l7354
u10980:
	
l7352:	
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l7366
	
l7354:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipc
	goto	u10991
	goto	u10990
u10991:
	goto	l7360
u10990:
	
l7356:	
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l7358:	
	bcf	status, 5	;RP0=0, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	goto	l7366
	
l7360:	
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l7362:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l7358
	
l7366:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	
l7368:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l7216
	line	343
	
l7372:	
;charge_mgr.c: 343: else if(ty == 0)
	movf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11001
	goto	u11000
u11001:
	goto	l7388
u11000:
	line	346
	
l7374:	
;charge_mgr.c: 344: {
;charge_mgr.c: 346: if(v >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11011
	goto	u11010
u11011:
	goto	l7384
u11010:
	line	350
	
l7376:	
;charge_mgr.c: 347: {
;charge_mgr.c: 350: if(ct < (2 * 100) + (8 * 100))
	movlw	03h
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0E8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u11021
	goto	u11020
u11021:
	goto	l7246
u11020:
	goto	l7802
	line	360
	
l7384:	
;charge_mgr.c: 358: else
;charge_mgr.c: 359: {
;charge_mgr.c: 360: st = 7;
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l7216
	line	364
	
l7388:	
;charge_mgr.c: 364: else if(ty == 2 || ty == 3)
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11031
	goto	u11030
u11031:
	goto	l7392
u11030:
	
l7390:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11041
	goto	u11040
u11041:
	goto	l7802
u11040:
	line	366
	
l7392:	
;charge_mgr.c: 365: {
;charge_mgr.c: 366: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	367
	
l7394:	
;charge_mgr.c: 367: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	368
	
l7396:	
;charge_mgr.c: 368: g_detectLogSlot = idx;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	369
	
l7398:	
;charge_mgr.c: 369: g_detectLogType = ty;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ty)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogType)	;volatile
	line	370
	
l7400:	
;charge_mgr.c: 370: g_detectLogFlag = 1;
	bsf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	goto	l7802
	line	375
	
l7402:	
;charge_mgr.c: 375: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	376
	
l7404:	
;charge_mgr.c: 376: if(ct < 1)
	movf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u11051
	goto	u11050
u11051:
	goto	l7408
u11050:
	goto	l7802
	line	383
	
l7408:	
;charge_mgr.c: 379: {
;charge_mgr.c: 383: if(0xA5 == ADC_Sample(31, 0))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u11061
	goto	u11060
u11061:
	goto	l657
u11060:
	line	384
	
l7410:	
;charge_mgr.c: 384: g_vcc_mv = (unsigned int)((4096UL * 1200UL) / adresult);
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(0+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	
l657:	
	line	391
;charge_mgr.c: 391: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 300U)
	bsf	status, 5	;RP0=1, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(012Ch)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(012Ch)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11075
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11075:
	skipnc
	goto	u11071
	goto	u11070
u11071:
	goto	l7422
u11070:
	line	393
	
l7412:	
;charge_mgr.c: 392: {
;charge_mgr.c: 393: ty = 2;
	movlw	low(02h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	394
;charge_mgr.c: 394: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	395
;charge_mgr.c: 395: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	396
	
l7414:	
;charge_mgr.c: 396: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11084
u11085:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11084:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11085
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	397
	
l7416:	
;charge_mgr.c: 397: g_detectLogSlot = idx;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	398
	
l7418:	
;charge_mgr.c: 398: g_detectLogType = 2;
	movlw	low(02h)
	movwf	(_g_detectLogType)	;volatile
	goto	l7400
	line	409
	
l7422:	
;charge_mgr.c: 401: }
;charge_mgr.c: 409: if(v >= 3990 && (g_impData & 0x0FFFU) >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11091
	goto	u11090
u11091:
	goto	l7432
u11090:
	
l7424:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	096h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u11101
	goto	u11100
u11101:
	goto	l7432
u11100:
	line	411
	
l7426:	
;charge_mgr.c: 410: {
;charge_mgr.c: 411: ty = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	412
;charge_mgr.c: 412: st = 0;
	clrf	(ChargeProcess_Slot@st)^0180h
	line	413
	
l7428:	
;charge_mgr.c: 413: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	goto	l7180
	line	423
	
l7432:	
;charge_mgr.c: 416: }
;charge_mgr.c: 423: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 200U)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(0C8h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11115
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11115:
	skipnc
	goto	u11111
	goto	u11110
u11111:
	goto	l7436
u11110:
	goto	l7450
	line	431
	
l7436:	
;charge_mgr.c: 431: if((g_impData & 0x0FFFU) > 2300U)
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	08h
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u11121
	goto	u11120
u11121:
	goto	l7440
u11120:
	goto	l7490
	line	433
	
l7440:	
;charge_mgr.c: 433: if(v >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11131
	goto	u11130
u11131:
	goto	l7444
u11130:
	goto	l7490
	line	443
	
l7444:	
;charge_mgr.c: 443: st = 9;
	movlw	low(09h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	444
	
l7446:	
;charge_mgr.c: 444: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	goto	l7180
	line	451
	
l7450:	
;charge_mgr.c: 451: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	line	452
	
l7452:	
;charge_mgr.c: 452: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11144
u11145:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11144:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11145
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	453
	
l7454:	
;charge_mgr.c: 453: ty = 1;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	incf	(ChargeProcess_Slot@ty)^0180h,f
	line	454
	
l7456:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_396+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_396+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_396+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_396)^080h

	
l7458:	
	movlw	0Ch
u11155:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_396+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_396+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_396+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_396)^080h,f
	addlw	-1
	skipz
	goto	u11155

	
l7460:	
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_397+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_397+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_397+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_397)^080h

	
l7462:	
	movf	(ChargeProcess_Slot@vx_mv_396+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv_396+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv_396+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv_396)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long_397)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11161
	addwf	(ChargeProcess_Slot@bat_mv_long_397+1)^080h,f
u11161:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11162
	addwf	(ChargeProcess_Slot@bat_mv_long_397+2)^080h,f
u11162:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11163
	addwf	(ChargeProcess_Slot@bat_mv_long_397+3)^080h,f
u11163:

	
l7464:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long_397)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long_397+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_397+1)^080h,w
	goto	u11170
	goto	u11171
u11170:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u11171:
	movf	(ChargeProcess_Slot@bat_mv_long_397+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_397+2)^080h,w
	goto	u11172
	goto	u11173
u11172:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u11173:
	movf	(ChargeProcess_Slot@bat_mv_long_397+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_397+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_398+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_398)^0180h
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_398+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_398)^0180h,w
	skipnc
	goto	u11181
	goto	u11180
u11181:
	goto	l7468
u11180:
	goto	l7348
	
l7468:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_398+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_398)^0180h,w
	skipnc
	goto	u11191
	goto	u11190
u11191:
	goto	l7472
u11190:
	goto	l7352
	
l7472:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_398+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_398)^0180h,w
	skipc
	goto	u11201
	goto	u11200
u11201:
	goto	l7360
u11200:
	goto	l7356
	line	466
	
l7490:	
;charge_mgr.c: 466: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	467
	
l7492:	
;charge_mgr.c: 467: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11214
u11215:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11214:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11215
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	468
	
l7494:	
;charge_mgr.c: 468: ty = 6;
	movlw	low(06h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	469
	
l7496:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(___lmul@multiplier)^080h
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(___lmul@multiplier)^080h
	clrf	2+(___lmul@multiplier)^080h
	clrf	3+(___lmul@multiplier)^080h
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_399+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_399+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_399+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_399)^080h

	
l7498:	
	movlw	0Ch
u11225:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_399+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_399+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_399+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_399)^080h,f
	addlw	-1
	skipz
	goto	u11225

	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long_400+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long_400+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long_400+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long_400)^0180h

	bcf	status, 6	;RP1=0, select bank1
	movf	(ChargeProcess_Slot@vx_mv_399+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv_399+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv_399+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv_399)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long_400)^0180h,f
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11231
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long_400+1)^0180h,f
u11231:
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11232
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long_400+2)^0180h,f
u11232:
	bcf	status, 6	;RP1=0, select bank1
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11233
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long_400+3)^0180h,f
u11233:
	bcf	status, 6	;RP1=0, select bank1
	bsf	status, 6	;RP1=1, select bank3

	movlw	0
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long_400)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long_400+1)^0180h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_400+1)^0180h,w
	goto	u11240
	goto	u11241
u11240:
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u11241:
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long_400+2)^0180h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_400+2)^0180h,w
	goto	u11242
	goto	u11243
u11242:
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u11243:
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long_400+3)^0180h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_400+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_401+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_401)^0180h
	
l7500:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_401+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_401)^0180h,w
	skipnc
	goto	u11251
	goto	u11250
u11251:
	goto	l7504
u11250:
	goto	l7348
	
l7504:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_401+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_401)^0180h,w
	skipnc
	goto	u11261
	goto	u11260
u11261:
	goto	l7508
u11260:
	goto	l7352
	
l7508:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_401+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_401)^0180h,w
	skipc
	goto	u11271
	goto	u11270
u11271:
	goto	l7514
u11270:
	
l7510:	
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l7512:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	goto	l7366
	
l7514:	
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l7516:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l7512
	line	483
	
l7526:	
;charge_mgr.c: 484: {
;charge_mgr.c: 486: if(v >= 3990 && (g_impData & 0x0FFFU) < 3990)
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	493
	
l7530:	
;charge_mgr.c: 490: }
;charge_mgr.c: 493: if(v > (g_impData & 0x0FFFU) + 100)
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(064h)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(064h)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	skipz
	goto	u11285
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
u11285:
	skipnc
	goto	u11281
	goto	u11280
u11281:
	goto	l7534
u11280:
	goto	l7490
	line	497
	
l7534:	
;charge_mgr.c: 497: if(ct >= 100)
	movlw	0
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	064h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11291
	goto	u11290
u11291:
	goto	l7802
u11290:
	line	499
	
l7536:	
;charge_mgr.c: 498: {
;charge_mgr.c: 499: ty = 3;
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	500
;charge_mgr.c: 500: st = 7;
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	501
;charge_mgr.c: 501: g_impCheckSlot = 0xFF;
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	502
	
l7538:	
;charge_mgr.c: 502: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11304
u11305:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11304:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11305
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	503
	
l7540:	
;charge_mgr.c: 503: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	504
	
l7542:	
;charge_mgr.c: 504: g_detectLogSlot = idx;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	505
	
l7544:	
;charge_mgr.c: 505: g_detectLogType = 3;
	movlw	low(03h)
	movwf	(_g_detectLogType)	;volatile
	goto	l7400
	line	514
	
l7548:	
;charge_mgr.c: 514: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	515
;charge_mgr.c: 515: if(ct > (60 * 100))
	movlw	017h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	071h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11311
	goto	u11310
u11311:
	goto	l7552
u11310:
	line	517
	
l7550:	
;charge_mgr.c: 516: {
;charge_mgr.c: 517: st = 7;
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	518
;charge_mgr.c: 518: break;
	goto	l7802
	line	520
	
l7552:	
;charge_mgr.c: 519: }
;charge_mgr.c: 520: if(v > 750)
	movlw	02h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11321
	goto	u11320
u11321:
	goto	l7558
u11320:
	line	522
	
l7554:	
;charge_mgr.c: 521: {
;charge_mgr.c: 522: st = 3;
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	523
	
l7556:	
;charge_mgr.c: 523: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	524
;charge_mgr.c: 524: break;
	goto	l7802
	line	526
	
l7558:	
;charge_mgr.c: 525: }
;charge_mgr.c: 526: if(v >= 3850)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11331
	goto	u11330
u11331:
	goto	l7802
u11330:
	goto	l7550
	line	534
	
l7562:	
;charge_mgr.c: 534: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	535
;charge_mgr.c: 535: if(ct > (300 * 100))
	movlw	075h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	031h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11341
	goto	u11340
u11341:
	goto	l7566
u11340:
	goto	l7550
	line	540
	
l7566:	
;charge_mgr.c: 539: }
;charge_mgr.c: 540: if(v >= 3850)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11351
	goto	u11350
u11351:
	goto	l7572
u11350:
	line	542
	
l7568:	
;charge_mgr.c: 541: {
;charge_mgr.c: 542: g_ovCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	543
;charge_mgr.c: 543: if(g_ovCnt[idx] >= 5)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u11361
	goto	u11360
u11361:
	goto	l7574
u11360:
	goto	l7550
	line	551
	
l7572:	
;charge_mgr.c: 549: else
;charge_mgr.c: 550: {
;charge_mgr.c: 551: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	553
	
l7574:	
;charge_mgr.c: 552: }
;charge_mgr.c: 553: if(v >= 2700)
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	08Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11371
	goto	u11370
u11371:
	goto	l7802
u11370:
	line	555
	
l7576:	
;charge_mgr.c: 554: {
;charge_mgr.c: 555: st = 4;
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	556
	
l7578:	
;charge_mgr.c: 556: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	557
	
l7580:	
;charge_mgr.c: 557: g_ccBlocks[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	558
	
l7582:	
;charge_mgr.c: 558: g_ovCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l7238
	line	564
	
l7586:	
;charge_mgr.c: 564: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	565
;charge_mgr.c: 565: if(ct >= (600 * 100))
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	060h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11381
	goto	u11380
u11381:
	goto	l7592
u11380:
	line	567
	
l7588:	
;charge_mgr.c: 566: {
;charge_mgr.c: 567: ct -= (600 * 100);
	movlw	060h
	subwf	(ChargeProcess_Slot@ct)^0180h,f
	movlw	0EAh
	skipc
	decf	(ChargeProcess_Slot@ct+1)^0180h,f
	subwf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	568
	
l7590:	
;charge_mgr.c: 568: g_ccBlocks[idx]++;
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	570
	
l7592:	
;charge_mgr.c: 569: }
;charge_mgr.c: 570: if(g_ccBlocks[idx] >= 18)
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(012h)
	subwf	indf,w
	skipc
	goto	u11391
	goto	u11390
u11391:
	goto	l7596
u11390:
	goto	l7550
	line	579
	
l7596:	
;charge_mgr.c: 574: }
;charge_mgr.c: 579: if(v >= 3990 && ty == 6)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11401
	goto	u11400
u11401:
	goto	l7602
u11400:
	
l7598:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11411
	goto	u11410
u11411:
	goto	l7602
u11410:
	goto	l699
	line	585
	
l7602:	
;charge_mgr.c: 583: else
;charge_mgr.c: 584: {
;charge_mgr.c: 585: if(v > g_slotRefV[idx]) g_slotRefV[idx] = v;
	bcf	status, 5	;RP0=0, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11425
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11425:
	skipnc
	goto	u11421
	goto	u11420
u11421:
	goto	l699
u11420:
	
l7604:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	586
	
l699:	
	line	592
;charge_mgr.c: 586: }
;charge_mgr.c: 592: if(g_slotRefV[idx] - v > 500 && ty != 6)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u11431
	goto	u11430
u11431:
	goto	l7620
u11430:
	
l7606:	
		movlw	6
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11441
	goto	u11440
u11441:
	goto	l7620
u11440:
	line	595
	
l7608:	
;charge_mgr.c: 593: {
;charge_mgr.c: 595: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	596
;charge_mgr.c: 596: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11451
	goto	u11450
u11451:
	goto	l7612
u11450:
	goto	l7802
	line	598
	
l7612:	
;charge_mgr.c: 598: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	599
	
l7614:	
;charge_mgr.c: 599: st = 1;
	bsf	status, 5	;RP0=1, select bank3
	clrf	(ChargeProcess_Slot@st)^0180h
	incf	(ChargeProcess_Slot@st)^0180h,f
	goto	l7556
	line	605
	
l7620:	
;charge_mgr.c: 603: else
;charge_mgr.c: 604: {
;charge_mgr.c: 605: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	614
	
l7622:	
;charge_mgr.c: 606: }
;charge_mgr.c: 614: if(v >= 3990 && ty == 1)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11461
	goto	u11460
u11461:
	goto	l7630
u11460:
	
l7624:	
	bsf	status, 5	;RP0=1, select bank3
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11471
	goto	u11470
u11471:
	goto	l7630
u11470:
	line	616
	
l7626:	
;charge_mgr.c: 615: {
;charge_mgr.c: 616: st = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l7556
	line	624
	
l7630:	
;charge_mgr.c: 619: }
;charge_mgr.c: 624: if(v >= 3850 && ty != 6)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11481
	goto	u11480
u11481:
	goto	l7638
u11480:
	
l7632:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11491
	goto	u11490
u11491:
	goto	l7638
u11490:
	line	626
	
l7634:	
;charge_mgr.c: 625: {
;charge_mgr.c: 626: g_ovCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	627
;charge_mgr.c: 627: if(g_ovCnt[idx] >= 5)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u11501
	goto	u11500
u11501:
	goto	l600
u11500:
	goto	l7550
	line	635
	
l7638:	
;charge_mgr.c: 633: else
;charge_mgr.c: 634: {
;charge_mgr.c: 635: g_ovCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	637
	
l7640:	
;charge_mgr.c: 637: if(v >= 3100 && !(v >= 3990 && ty == 6))
	movlw	0Ch
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	01Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11511
	goto	u11510
u11511:
	goto	l600
u11510:
	
l7642:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11521
	goto	u11520
u11521:
	goto	l7646
u11520:
	
l7644:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11531
	goto	u11530
u11531:
	goto	l600
u11530:
	line	639
	
l7646:	
;charge_mgr.c: 638: {
;charge_mgr.c: 639: st = 5;
	movlw	low(05h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l7556
	line	646
	
l7650:	
;charge_mgr.c: 646: ct += tick;
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	647
;charge_mgr.c: 647: if(ct > (600 * 100))
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	061h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11541
	goto	u11540
u11541:
	goto	l712
u11540:
	line	648
	
l7652:	
;charge_mgr.c: 648: st = 6;
	movlw	low(06h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l712:	
	line	656
;charge_mgr.c: 656: if(v >= 3990 && ty == 6)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11551
	goto	u11550
u11551:
	goto	l7658
u11550:
	
l7654:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11561
	goto	u11560
u11561:
	goto	l7658
u11560:
	goto	l7802
	line	660
	
l7658:	
;charge_mgr.c: 660: if(v > g_slotRefV[idx]) g_slotRefV[idx] = v;
	bcf	status, 5	;RP0=0, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11575
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11575:
	skipnc
	goto	u11571
	goto	u11570
u11571:
	goto	l7662
u11570:
	
l7660:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	665
	
l7662:	
;charge_mgr.c: 665: if(v >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11581
	goto	u11580
u11581:
	goto	l7688
u11580:
	line	667
	
l7664:	
;charge_mgr.c: 666: {
;charge_mgr.c: 667: if(ty == 1)
	bsf	status, 5	;RP0=1, select bank3
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11591
	goto	u11590
u11591:
	goto	l7676
u11590:
	line	669
	
l7666:	
;charge_mgr.c: 668: {
;charge_mgr.c: 669: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	670
;charge_mgr.c: 670: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11601
	goto	u11600
u11601:
	goto	l7670
u11600:
	goto	l7802
	line	672
	
l7670:	
;charge_mgr.c: 672: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7626
	line	677
	
l7676:	
;charge_mgr.c: 676: }
;charge_mgr.c: 677: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	678
;charge_mgr.c: 678: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11611
	goto	u11610
u11611:
	goto	l7680
u11610:
	goto	l7802
	line	680
	
l7680:	
;charge_mgr.c: 680: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	681
	
l7682:	
;charge_mgr.c: 681: ty = 0;
	bsf	status, 5	;RP0=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	682
	
l7684:	
;charge_mgr.c: 682: st = 0;
	bsf	status, 5	;RP0=1, select bank3
	clrf	(ChargeProcess_Slot@st)^0180h
	goto	l7556
	line	692
	
l7688:	
;charge_mgr.c: 685: }
;charge_mgr.c: 692: if(g_slotRefV[idx] - v > 500 && ty != 6)
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u11621
	goto	u11620
u11621:
	goto	l7702
u11620:
	
l7690:	
		movlw	6
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11631
	goto	u11630
u11631:
	goto	l7702
u11630:
	line	694
	
l7692:	
;charge_mgr.c: 693: {
;charge_mgr.c: 694: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	695
;charge_mgr.c: 695: if(g_detectLowCnt[idx] >= 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipc
	goto	u11641
	goto	u11640
u11641:
	goto	l7704
u11640:
	line	697
	
l7694:	
;charge_mgr.c: 696: {
;charge_mgr.c: 697: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	698
	
l7696:	
;charge_mgr.c: 698: ty = 0;
	bsf	status, 5	;RP0=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	goto	l7614
	line	706
	
l7702:	
;charge_mgr.c: 704: else
;charge_mgr.c: 705: {
;charge_mgr.c: 706: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	710
	
l7704:	
;charge_mgr.c: 707: }
;charge_mgr.c: 710: if(v >= 3850)
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11651
	goto	u11650
u11651:
	goto	l7710
u11650:
	line	712
	
l7706:	
;charge_mgr.c: 711: {
;charge_mgr.c: 712: g_ovCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	713
;charge_mgr.c: 713: if(g_ovCnt[idx] >= 5)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u11661
	goto	u11660
u11661:
	goto	l600
u11660:
	goto	l7550
	line	721
	
l7710:	
;charge_mgr.c: 719: else
;charge_mgr.c: 720: {
;charge_mgr.c: 721: g_ovCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l7802
	line	732
	
l7712:	
;charge_mgr.c: 732: if(v >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11671
	goto	u11670
u11671:
	goto	l7730
u11670:
	line	734
	
l7714:	
;charge_mgr.c: 733: {
;charge_mgr.c: 734: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	735
	
l7716:	
;charge_mgr.c: 735: if(g_detectLowCnt[idx] >= (ty == 6 ? 50 : 2))
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11681
	goto	u11680
u11681:
	goto	l7720
u11680:
	
l7718:	
	movlw	02h
	movwf	(_ChargeProcess_Slot$402)^0180h
	clrf	(_ChargeProcess_Slot$402+1)^0180h
	goto	l7722
	
l7720:	
	movlw	032h
	movwf	(_ChargeProcess_Slot$402)^0180h
	clrf	(_ChargeProcess_Slot$402+1)^0180h
	
l7722:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	movf	(_ChargeProcess_Slot$402+1)^0180h,w
	xorlw	80h
	sublw	080h
	skipz
	goto	u11695
	movf	(_ChargeProcess_Slot$402)^0180h,w
	subwf	indf,w
u11695:

	skipc
	goto	u11691
	goto	u11690
u11691:
	goto	l7802
u11690:
	line	737
	
l7724:	
;charge_mgr.c: 736: {
;charge_mgr.c: 737: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l7684
	line	746
	
l7730:	
;charge_mgr.c: 742: }
;charge_mgr.c: 746: if(v < 2800U)
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u11701
	goto	u11700
u11701:
	goto	l7216
u11700:
	line	748
	
l7732:	
;charge_mgr.c: 747: {
;charge_mgr.c: 748: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	749
;charge_mgr.c: 749: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11711
	goto	u11710
u11711:
	goto	l7736
u11710:
	goto	l7802
	line	751
	
l7736:	
;charge_mgr.c: 751: g_detectLowCnt[idx] = 0;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	752
	
l7738:	
;charge_mgr.c: 752: st = 4;
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	753
	
l7740:	
;charge_mgr.c: 753: ct = 0;
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	goto	l7582
	line	765
	
l7748:	
;charge_mgr.c: 765: if(v >= 3990)
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11721
	goto	u11720
u11721:
	goto	l7762
u11720:
	line	767
	
l7750:	
;charge_mgr.c: 766: {
;charge_mgr.c: 767: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	768
;charge_mgr.c: 768: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11731
	goto	u11730
u11731:
	goto	l7680
u11730:
	goto	l7802
	line	784
	
l7762:	
;charge_mgr.c: 775: }
;charge_mgr.c: 784: if(ty == 2 || ty == 3)
		movlw	2
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11741
	goto	u11740
u11741:
	goto	l7766
u11740:
	
l7764:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11751
	goto	u11750
u11751:
	goto	l7782
u11750:
	line	786
	
l7766:	
;charge_mgr.c: 785: {
;charge_mgr.c: 786: if(v > 2700U && (g_highVFlag & ((unsigned int)1 << idx)))
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	08Dh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11761
	goto	u11760
u11761:
	goto	l7216
u11760:
	
l7768:	
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11774
u11775:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11774:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11775
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u11781
	goto	u11780
u11781:
	goto	l7216
u11780:
	line	788
	
l7770:	
;charge_mgr.c: 787: {
;charge_mgr.c: 788: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	789
;charge_mgr.c: 789: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11791
	goto	u11790
u11791:
	goto	l7612
u11790:
	goto	l7802
	line	802
	
l7782:	
;charge_mgr.c: 800: }
;charge_mgr.c: 802: if(v > 750)
	movlw	02h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11801
	goto	u11800
u11801:
	goto	l7216
u11800:
	line	804
	
l7784:	
;charge_mgr.c: 803: {
;charge_mgr.c: 804: g_detectLowCnt[idx]++;
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	805
;charge_mgr.c: 805: if(g_detectLowCnt[idx] < 2)
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11811
	goto	u11810
u11811:
	goto	l7612
u11810:
	goto	l7802
	line	818
	
l7796:	
;charge_mgr.c: 818: st = 0;
	clrf	(ChargeProcess_Slot@st)^0180h
	line	819
;charge_mgr.c: 819: break;
	goto	l7802
	line	145
	
l7800:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@st)^0180h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l7176
	xorlw	1^0	; case 1
	skipnz
	goto	l7182
	xorlw	2^1	; case 2
	skipnz
	goto	l7548
	xorlw	3^2	; case 3
	skipnz
	goto	l7562
	xorlw	4^3	; case 4
	skipnz
	goto	l7586
	xorlw	5^4	; case 5
	skipnz
	goto	l7650
	xorlw	6^5	; case 6
	skipnz
	goto	l7712
	xorlw	7^6	; case 7
	skipnz
	goto	l7748
	xorlw	8^7	; case 8
	skipnz
	goto	l7402
	xorlw	9^8	; case 9
	skipnz
	goto	l7526
	goto	l7796
	opt asmopt_pop

	line	820
	
l600:	
	line	822
	
l7802:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@st)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ty)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ct)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@ct+1)^0180h,w
	movwf	indf
	line	825
	
l7804:	
;charge_mgr.c: 825: if(idx <= 5 && st != old_st)
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@idx)^0100h,w
	skipnc
	goto	u11821
	goto	u11820
u11821:
	goto	l751
u11820:
	
l7806:	
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@st)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	xorwf	(ChargeProcess_Slot@old_st)^080h,w
	skipnz
	goto	u11831
	goto	u11830
u11831:
	goto	l751
u11830:
	line	827
	
l7808:	
;charge_mgr.c: 826: {
;charge_mgr.c: 827: g_dbgSlot = idx;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_dbgSlot)	;volatile
	line	828
;charge_mgr.c: 828: g_dbgOldState = old_st;
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@old_st)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_dbgOldState)	;volatile
	line	829
;charge_mgr.c: 829: g_dbgNewState = st;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@st)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_dbgNewState)	;volatile
	line	830
;charge_mgr.c: 830: g_dbgNewType = ty;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ty)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_dbgNewType)	;volatile
	line	831
;charge_mgr.c: 831: g_dbgVoltage = v;
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_dbgVoltage+1)^080h	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_dbgVoltage)^080h	;volatile
	line	832
	
l7810:	
;charge_mgr.c: 832: g_dbgDetectFlag = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	834
	
l751:	
	return
	opt stack 0
GLOBAL	__end_of_ChargeProcess_Slot
	__end_of_ChargeProcess_Slot:
	signat	_ChargeProcess_Slot,4217
	global	___wmul

;; *************** function ___wmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
;; Parameters:    Size  Location     Type
;;  multiplier      2   26[BANK0 ] unsigned int 
;;  multiplicand    2   28[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  product         2    0[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   26[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       0       2       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       2       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
global __ptext15
__ptext15:	;psect for function ___wmul
psect	text15
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
	global	__size_of___wmul
	__size_of___wmul	equ	__end_of___wmul-___wmul
	
___wmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___wmul: [wreg+status,2+status,0]
	line	43
	
l6674:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___wmul@product)^080h
	clrf	(___wmul@product+1)^080h
	line	45
	
l6676:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(___wmul@multiplier),(0)&7
	goto	u9751
	goto	u9750
u9751:
	goto	l6680
u9750:
	line	46
	
l6678:	
	movf	(___wmul@multiplicand),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(___wmul@product)^080h,f
	skipnc
	incf	(___wmul@product+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(___wmul@multiplicand+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(___wmul@product+1)^080h,f
	line	47
	
l6680:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(___wmul@multiplicand),f
	rlf	(___wmul@multiplicand+1),f
	line	48
	
l6682:	
	clrc
	rrf	(___wmul@multiplier+1),f
	rrf	(___wmul@multiplier),f
	line	49
	
l6684:	
	movf	((___wmul@multiplier)),w
iorwf	((___wmul@multiplier+1)),w
	btfss	status,2
	goto	u9761
	goto	u9760
u9761:
	goto	l6676
u9760:
	line	52
	
l6686:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___wmul@product+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___wmul+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(___wmul@product)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___wmul)
	line	53
	
l874:	
	return
	opt stack 0
GLOBAL	__end_of___wmul
	__end_of___wmul:
	signat	___wmul,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   26[BANK0 ] unsigned int 
;;  dividend        2   28[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    1[BANK1 ] unsigned int 
;;  counter         1    0[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   26[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       0       3       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       3       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext16
__ptext16:	;psect for function ___lwdiv
psect	text16
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l6522:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___lwdiv@quotient)^080h
	clrf	(___lwdiv@quotient+1)^080h
	line	15
	
l6524:	
	bcf	status, 5	;RP0=0, select bank0
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u9471
	goto	u9470
u9471:
	goto	l6544
u9470:
	line	16
	
l6526:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___lwdiv@counter)^080h
	incf	(___lwdiv@counter)^080h,f
	line	17
	goto	l6530
	line	18
	
l6528:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	bsf	status, 5	;RP0=1, select bank1
	incf	(___lwdiv@counter)^080h,f
	line	17
	
l6530:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u9481
	goto	u9480
u9481:
	goto	l6528
u9480:
	line	22
	
l6532:	
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(___lwdiv@quotient)^080h,f
	rlf	(___lwdiv@quotient+1)^080h,f
	line	23
	
l6534:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u9495
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u9495:
	skipc
	goto	u9491
	goto	u9490
u9491:
	goto	l6540
u9490:
	line	24
	
l6536:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l6538:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(___lwdiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l6540:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l6542:	
	bsf	status, 5	;RP0=1, select bank1
	decfsz	(___lwdiv@counter)^080h,f
	goto	u9501
	goto	u9500
u9501:
	goto	l6532
u9500:
	line	30
	
l6544:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lwdiv@quotient+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lwdiv+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lwdiv@quotient)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lwdiv)
	line	31
	
l1211:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    0[BANK1 ] unsigned long 
;;  multiplicand    4    4[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4   26[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    0[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       8       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext17
__ptext17:	;psect for function ___lmul
psect	text17
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l6484:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l883:	
	line	121
	bsf	status, 5	;RP0=1, select bank1
	btfss	(___lmul@multiplier)^080h,(0)&7
	goto	u9401
	goto	u9400
u9401:
	goto	l6488
u9400:
	line	122
	
l6486:	
	movf	(___lmul@multiplicand)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product),f
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lmul@multiplicand+1)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9411
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product+1),f
u9411:
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lmul@multiplicand+2)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9412
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product+2),f
u9412:
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lmul@multiplicand+3)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9413
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product+3),f
u9413:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 5	;RP0=0, select bank0

	line	123
	
l6488:	
	clrc
	bsf	status, 5	;RP0=1, select bank1
	rlf	(___lmul@multiplicand)^080h,f
	rlf	(___lmul@multiplicand+1)^080h,f
	rlf	(___lmul@multiplicand+2)^080h,f
	rlf	(___lmul@multiplicand+3)^080h,f
	line	124
	
l6490:	
	clrc
	rrf	(___lmul@multiplier+3)^080h,f
	rrf	(___lmul@multiplier+2)^080h,f
	rrf	(___lmul@multiplier+1)^080h,f
	rrf	(___lmul@multiplier)^080h,f
	line	125
	movf	(___lmul@multiplier+3)^080h,w
	iorwf	(___lmul@multiplier+2)^080h,w
	iorwf	(___lmul@multiplier+1)^080h,w
	iorwf	(___lmul@multiplier)^080h,w
	skipz
	goto	u9421
	goto	u9420
u9421:
	goto	l883
u9420:
	line	128
	
l6492:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+3),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+2),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul)^080h

	line	129
	
l886:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    8[BANK1 ] unsigned long 
;;  dividend        4   12[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   17[BANK1 ] unsigned long 
;;  counter         1   16[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    8[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       0       5       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext18
__ptext18:	;psect for function ___lldiv
psect	text18
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l6496:	
	clrf	(___lldiv@quotient)^080h
	clrf	(___lldiv@quotient+1)^080h
	clrf	(___lldiv@quotient+2)^080h
	clrf	(___lldiv@quotient+3)^080h
	line	15
	
l6498:	
	movf	(___lldiv@divisor+3)^080h,w
	iorwf	(___lldiv@divisor+2)^080h,w
	iorwf	(___lldiv@divisor+1)^080h,w
	iorwf	(___lldiv@divisor)^080h,w
	skipnz
	goto	u9431
	goto	u9430
u9431:
	goto	l6518
u9430:
	line	16
	
l6500:	
	clrf	(___lldiv@counter)^080h
	incf	(___lldiv@counter)^080h,f
	line	17
	goto	l6504
	line	18
	
l6502:	
	clrc
	rlf	(___lldiv@divisor)^080h,f
	rlf	(___lldiv@divisor+1)^080h,f
	rlf	(___lldiv@divisor+2)^080h,f
	rlf	(___lldiv@divisor+3)^080h,f
	line	19
	incf	(___lldiv@counter)^080h,f
	line	17
	
l6504:	
	btfss	(___lldiv@divisor+3)^080h,(31)&7
	goto	u9441
	goto	u9440
u9441:
	goto	l6502
u9440:
	line	22
	
l6506:	
	clrc
	rlf	(___lldiv@quotient)^080h,f
	rlf	(___lldiv@quotient+1)^080h,f
	rlf	(___lldiv@quotient+2)^080h,f
	rlf	(___lldiv@quotient+3)^080h,f
	line	23
	
l6508:	
	movf	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,w
	skipz
	goto	u9455
	movf	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,w
	skipz
	goto	u9455
	movf	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,w
	skipz
	goto	u9455
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,w
u9455:
	skipc
	goto	u9451
	goto	u9450
u9451:
	goto	l6514
u9450:
	line	24
	
l6510:	
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,f
	movf	(___lldiv@divisor+1)^080h,w
	skipc
	incfsz	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,f
	movf	(___lldiv@divisor+2)^080h,w
	skipc
	incfsz	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,f
	movf	(___lldiv@divisor+3)^080h,w
	skipc
	incfsz	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,f
	line	25
	
l6512:	
	bsf	(___lldiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l6514:	
	clrc
	rrf	(___lldiv@divisor+3)^080h,f
	rrf	(___lldiv@divisor+2)^080h,f
	rrf	(___lldiv@divisor+1)^080h,f
	rrf	(___lldiv@divisor)^080h,f
	line	28
	
l6516:	
	decfsz	(___lldiv@counter)^080h,f
	goto	u9461
	goto	u9460
u9461:
	goto	l6506
u9460:
	line	30
	
l6518:	
	movf	(___lldiv@quotient+3)^080h,w
	movwf	(?___lldiv+3)^080h
	movf	(___lldiv@quotient+2)^080h,w
	movwf	(?___lldiv+2)^080h
	movf	(___lldiv@quotient+1)^080h,w
	movwf	(?___lldiv+1)^080h
	movf	(___lldiv@quotient)^080h,w
	movwf	(?___lldiv)^080h

	line	31
	
l1158:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1   26[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1   28[BANK0 ] unsigned char 
;;  product         1   27[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext19
__ptext19:	;psect for function ___bmul
psect	text19
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplier)
	line	6
	
l6690:	
	clrf	(___bmul@product)
	line	43
	
l6692:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u9771
	goto	u9770
u9771:
	goto	l6696
u9770:
	line	44
	
l6694:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l6696:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l6698:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u9781
	goto	u9780
u9781:
	goto	l6692
u9780:
	line	50
	
l6700:	
	movf	(___bmul@product),w
	line	51
	
l892:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 70 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2   26[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	70
global __ptext20
__ptext20:	;psect for function _Detect_BatteryType
psect	text20
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	70
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	72
	
l6642:	
;charge_mgr.c: 72: if(voltage >= 3990)
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u9691
	goto	u9690
u9691:
	goto	l6648
u9690:
	line	73
	
l6644:	
;charge_mgr.c: 73: return 0;
	movlw	low(0)
	goto	l588
	line	74
	
l6648:	
;charge_mgr.c: 74: if(voltage < 500)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u9701
	goto	u9700
u9701:
	goto	l6654
u9700:
	goto	l6644
	line	85
	
l6654:	
;charge_mgr.c: 85: if(voltage >= 1015 && voltage < 3990)
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u9711
	goto	u9710
u9711:
	goto	l6662
u9710:
	
l6656:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u9721
	goto	u9720
u9721:
	goto	l6662
u9720:
	line	86
	
l6658:	
;charge_mgr.c: 86: return 5;
	movlw	low(05h)
	goto	l588
	line	91
	
l6662:	
;charge_mgr.c: 91: if(voltage >= 500 && voltage < 3990)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u9731
	goto	u9730
u9731:
	goto	l6644
u9730:
	
l6664:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u9741
	goto	u9740
u9741:
	goto	l6644
u9740:
	line	92
	
l6666:	
;charge_mgr.c: 92: return 1;
	movlw	low(01h)
	line	95
	
l588:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1   26[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    1[BANK1 ] unsigned char 
;;  j               1    0[BANK1 ] unsigned char 
;;  adsum           4    3[BANK1 ] volatile unsigned long 
;;  ad_temp         2   11[BANK1 ] volatile unsigned int 
;;  admax           2    9[BANK1 ] volatile unsigned int 
;;  admin           2    7[BANK1 ] volatile unsigned int 
;;  i               1    2[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       0      13       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0       5      13       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext21
__ptext21:	;psect for function _ADC_Sample
psect	text21
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ADC_Sample@adch)^080h
	line	51
	
l6394:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	52
	
l6396:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(ADC_Sample@admin)^080h	;volatile
	clrf	(ADC_Sample@admin+1)^080h	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(ADC_Sample@admax)^080h	;volatile
	clrf	(ADC_Sample@admax+1)^080h	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	line	58
	
l6398:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u9231
	goto	u9230
u9231:
	goto	l6404
u9230:
	
l6400:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u9241
	goto	u9240
u9241:
	goto	l6404
u9240:
	line	60
	
l6402:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u12147:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u12147
	nop
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	l6406
	line	64
	
l6404:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	bcf	status, 5	;RP0=0, select bank0
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	67
	
l6406:	
;adc_drv.c: 67: if(adch & 0x10)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	btfss	(ADC_Sample@adch)^080h,(4)&7
	goto	u9251
	goto	u9250
u9251:
	goto	l498
u9250:
	line	69
	
l6408:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l6410:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	andwf	(ADC_Sample@adch)^080h,f
	line	71
;adc_drv.c: 71: }
	goto	l6412
	line	72
	
l498:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l6412:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	clrf	(ADC_Sample@i)^080h
	line	79
	
l6418:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(ADC_Sample@adch)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u9265:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u9265
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l6420:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	5
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u12157:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u12157
	nop2
opt asmopt_pop

	line	81
	
l6422:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l6424:	
;adc_drv.c: 84: unsigned char j = 0;
	clrf	(ADC_Sample@j)^080h
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	l502
	
l503:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decfsz	(ADC_Sample@j)^080h,f
	goto	u9271
	goto	u9270
u9271:
	goto	l502
u9270:
	line	89
	
l6426:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	l505
	line	90
	
l502:	
	line	85
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u9281
	goto	u9280
u9281:
	goto	l503
u9280:
	line	93
	
l6430:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	movwf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	swapf	(ADC_Sample@ad_temp)^080h,f	;volatile
	swapf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	
l6432:	
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	addwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	line	96
	
l6434:	
;adc_drv.c: 96: if(0 == admax)
	movf	((ADC_Sample@admax)^080h),w	;volatile
iorwf	((ADC_Sample@admax+1)^080h),w	;volatile
	btfss	status,2
	goto	u9291
	goto	u9290
u9291:
	goto	l6438
u9290:
	line	98
	
l6436:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	100
;adc_drv.c: 100: }
	goto	l508
	line	102
	
l6438:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	subwf	(ADC_Sample@admax+1)^080h,w	;volatile
	skipz
	goto	u9305
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	subwf	(ADC_Sample@admax)^080h,w	;volatile
u9305:
	skipnc
	goto	u9301
	goto	u9300
u9301:
	goto	l6442
u9300:
	line	103
	
l6440:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	goto	l508
	line	105
	
l6442:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	skipz
	goto	u9315
	movf	(ADC_Sample@admin)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp)^080h,w	;volatile
u9315:
	skipnc
	goto	u9311
	goto	u9310
u9311:
	goto	l508
u9310:
	line	106
	
l6444:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	108
	
l508:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ADC_Sample@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9321
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u9321:
	bcf	status, 5	;RP0=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9322
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u9322:
	bcf	status, 5	;RP0=0, select bank0
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9323
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u9323:
	bcf	status, 5	;RP0=0, select bank0
	bsf	status, 5	;RP0=1, select bank1

	line	76
	
l6446:	
	incf	(ADC_Sample@i)^080h,f
	
l6448:	
	movlw	low(022h)
	subwf	(ADC_Sample@i)^080h,w
	skipc
	goto	u9331
	goto	u9330
u9331:
	goto	l6418
u9330:
	line	112
	
l6450:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(ADC_Sample@admax)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@admax+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u9345
	goto	u9346
u9345:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u9346:
	bcf	status, 5	;RP0=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u9347
	goto	u9348
u9347:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u9348:
	bcf	status, 5	;RP0=0, select bank0
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u9349
	goto	u9340
u9349:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u9340:
	bcf	status, 5	;RP0=0, select bank0
	bsf	status, 5	;RP0=1, select bank1

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(ADC_Sample@admin)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+3)^080h,w	;volatile
	skipz
	goto	u9355
	bcf	status, 5	;RP0=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+2)^080h,w	;volatile
	skipz
	goto	u9355
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+1)^080h,w	;volatile
	skipz
	goto	u9355
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum)^080h,w	;volatile
u9355:
	skipc
	goto	u9351
	goto	u9350
u9351:
	goto	l512
u9350:
	line	114
	
l6452:	
;adc_drv.c: 114: adsum -= admin;
	movf	(ADC_Sample@admin)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u9365
	goto	u9366
u9365:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u9366:
	bcf	status, 5	;RP0=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u9367
	goto	u9368
u9367:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u9368:
	bcf	status, 5	;RP0=0, select bank0
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u9369
	goto	u9360
u9369:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u9360:
	bcf	status, 5	;RP0=0, select bank0
	bsf	status, 5	;RP0=1, select bank1

	goto	l6454
	line	115
	
l512:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	118
	
l6454:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(ADC_Sample@adsum)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_ADC_Sample+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@adsum+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@adsum+2)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@adsum+3)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u9375:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u9370:
	addlw	-1
	skipz
	goto	u9375
	movf	1+(??_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
l6456:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
l505:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 156 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   22[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0       8       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_CCCV_Control
;;		_Charging_Control
;;		_Led_BlinkProcess
;;		_PowerOnLedSequence
;;		_Update_LED_Slot
;;		i1_ADC_Sample
;;		i1___lldiv
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	156
global __ptext22
__ptext22:	;psect for function _Isr_Timer
psect	text22
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	156
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 2
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	movf	btemp+1,w
	movwf	(??_Isr_Timer+3)
	ljmp	_Isr_Timer
psect	text22
	line	159
	
i1l7838:	
;main.c: 159: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u1188_21
	goto	u1188_20
u1188_21:
	goto	i1l371
u1188_20:
	line	161
	
i1l7840:	
;main.c: 160: {
;main.c: 161: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	162
	
i1l7842:	
;main.c: 162: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	163
# 163 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text22
	line	166
	
i1l7844:	
;main.c: 166: g_pwmCounter++;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	167
	
i1l7846:	
;main.c: 167: if(g_pwmCounter >= 32)
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u1189_21
	goto	u1189_20
u1189_21:
	goto	i1l7850
u1189_20:
	line	168
	
i1l7848:	
;main.c: 168: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)	;volatile
	line	171
	
i1l7850:	
;main.c: 171: if(g_pwmDuty > 0 && g_pwmCounter < g_pwmDuty)
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u1190_21
	goto	u1190_20
u1190_21:
	goto	i1l368
u1190_20:
	
i1l7852:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u1191_21
	goto	u1191_20
u1191_21:
	goto	i1l368
u1191_20:
	line	172
	
i1l7854:	
;main.c: 172: RB7 = 1;
	bsf	(55/8),(55)&7	;volatile
	goto	i1l7856
	line	173
	
i1l368:	
	line	174
;main.c: 173: else
;main.c: 174: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	177
	
i1l7856:	
;main.c: 177: if(g_powerOnPhase < 2)
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u1192_21
	goto	u1192_20
u1192_21:
	goto	i1l7928
u1192_20:
	line	179
	
i1l7858:	
;main.c: 178: {
;main.c: 179: PowerOnLedSequence();
	fcall	_PowerOnLedSequence
	goto	i1l371
	line	186
;main.c: 185: {
;main.c: 186: case 0:
	
i1l373:	
	line	188
;main.c: 188: if(!g_adcBusy && !g_doAdcSample)
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u1193_21
	goto	u1193_20
u1193_21:
	goto	i1l371
u1193_20:
	
i1l7862:	
	btfsc	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u1194_21
	goto	u1194_20
u1194_21:
	goto	i1l371
u1194_20:
	goto	i1l7866
	line	190
	
i1l377:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l390
	
i1l379:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l390
	
i1l380:	
	bsf	(51/8),(51)&7	;volatile
	goto	i1l390
	
i1l381:	
	bsf	(50/8),(50)&7	;volatile
	goto	i1l390
	
i1l382:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l390
	
i1l383:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l390
	
i1l384:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l390
	
i1l385:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l390
	
i1l386:	
	bsf	(48/8),(48)&7	;volatile
	goto	i1l390
	
i1l387:	
	bsf	(49/8),(49)&7	;volatile
	goto	i1l390
	
i1l388:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l390
	
i1l389:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l390
	
i1l7866:	
	movf	(_g_scanIndex),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l377
	xorlw	1^0	; case 1
	skipnz
	goto	i1l379
	xorlw	2^1	; case 2
	skipnz
	goto	i1l380
	xorlw	3^2	; case 3
	skipnz
	goto	i1l381
	xorlw	4^3	; case 4
	skipnz
	goto	i1l382
	xorlw	5^4	; case 5
	skipnz
	goto	i1l383
	xorlw	6^5	; case 6
	skipnz
	goto	i1l384
	xorlw	7^6	; case 7
	skipnz
	goto	i1l385
	xorlw	8^7	; case 8
	skipnz
	goto	i1l386
	xorlw	9^8	; case 9
	skipnz
	goto	i1l387
	xorlw	10^9	; case 10
	skipnz
	goto	i1l388
	xorlw	11^10	; case 11
	skipnz
	goto	i1l389
	goto	i1l390
	opt asmopt_pop

	
i1l390:	
	line	191
;main.c: 191: g_doAdcSample = 1;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	i1l371
	line	197
	
i1l7868:	
;main.c: 197: Update_LED_Slot(g_scanIndex);
	movf	(_g_scanIndex),w	;volatile
	fcall	_Update_LED_Slot
	line	199
	
i1l7870:	
;main.c: 199: g_scanPhase = 2;
	movlw	low(02h)
	movwf	(_g_scanPhase)	;volatile
	line	200
;main.c: 200: break;
	goto	i1l371
	line	203
	
i1l7872:	
;main.c: 203: if(g_scanIndex == 0)
	movf	((_g_scanIndex)),w	;volatile
	btfss	status,2
	goto	u1195_21
	goto	u1195_20
u1195_21:
	goto	i1l7920
u1195_20:
	line	206
	
i1l7874:	
;main.c: 204: {
;main.c: 206: if(!g_adcBusy)
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u1196_21
	goto	u1196_20
u1196_21:
	goto	i1l7888
u1196_20:
	line	208
	
i1l7876:	
;main.c: 207: {
;main.c: 208: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	209
	
i1l7878:	
;main.c: 209: test_adc = ADC_Sample(31, 0);
	clrf	(i1ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	i1_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	210
	
i1l7880:	
;main.c: 210: if(0xA5 == test_adc)
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u1197_21
	goto	u1197_20
u1197_21:
	goto	i1l7886
u1197_20:
	line	212
	
i1l7882:	
;main.c: 211: {
;main.c: 212: unsigned long pt = (4096UL * 1200UL) / adresult;
	movf	(_adresult),w	;volatile
	movwf	(i1___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((i1___lldiv@divisor))+1
	clrf	2+((i1___lldiv@divisor))
	clrf	3+((i1___lldiv@divisor))
	movlw	0
	movwf	(i1___lldiv@dividend+3)
	movlw	04Bh
	movwf	(i1___lldiv@dividend+2)
	movlw	0
	movwf	(i1___lldiv@dividend+1)
	movlw	0
	movwf	(i1___lldiv@dividend)

	fcall	i1___lldiv
	movf	(3+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+3)
	movf	(2+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+2)
	movf	(1+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+1)
	movf	(0+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt)

	line	213
	
i1l7884:	
;main.c: 213: g_vcc_mv = (unsigned int)pt;
	movf	(Isr_Timer@pt+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv+1)^080h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(Isr_Timer@pt),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv)^080h	;volatile
	line	215
	
i1l7886:	
;main.c: 214: }
;main.c: 215: g_adcBusy = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	218
	
i1l7888:	
;main.c: 216: }
;main.c: 218: Charging_Control();
	fcall	_Charging_Control
	line	219
	
i1l7890:	
;main.c: 219: CCCV_Control();
	fcall	_CCCV_Control
	line	220
	
i1l7892:	
;main.c: 220: Led_BlinkProcess();
	fcall	_Led_BlinkProcess
	line	224
	
i1l7894:	
;main.c: 223: {
;main.c: 224: if(g_tempPhase == 0)
	movf	((_g_tempPhase)),w	;volatile
	btfss	status,2
	goto	u1198_21
	goto	u1198_20
u1198_21:
	goto	i1l7906
u1198_20:
	line	226
	
i1l7896:	
;main.c: 225: {
;main.c: 226: g_tempReadRoundCnt++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_tempReadRoundCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1)^080h,f	;volatile
	line	227
	
i1l7898:	
;main.c: 227: if(g_tempReadRoundCnt >= 200)
	movlw	0
	subwf	(_g_tempReadRoundCnt+1)^080h,w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt)^080h,w	;volatile
	skipc
	goto	u1199_21
	goto	u1199_20
u1199_21:
	goto	i1l7914
u1199_20:
	line	229
	
i1l7900:	
;main.c: 228: {
;main.c: 229: g_tempReadRoundCnt = 0;
	clrf	(_g_tempReadRoundCnt)^080h	;volatile
	clrf	(_g_tempReadRoundCnt+1)^080h	;volatile
	line	230
	
i1l7902:	
;main.c: 230: g_tempPhase = 1;
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_tempPhase)	;volatile
	line	231
	
i1l7904:	
;main.c: 231: g_tempSettleCnt = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	goto	i1l7914
	line	236
	
i1l7906:	
;main.c: 234: else
;main.c: 235: {
;main.c: 236: g_tempSettleCnt++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_tempSettleCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1)^080h,f	;volatile
	line	237
	
i1l7908:	
;main.c: 237: if(g_tempSettleCnt >= 60)
	movlw	0
	subwf	(_g_tempSettleCnt+1)^080h,w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt)^080h,w	;volatile
	skipc
	goto	u1200_21
	goto	u1200_20
u1200_21:
	goto	i1l7914
u1200_20:
	line	239
	
i1l7910:	
;main.c: 238: {
;main.c: 239: g_doNtcRead = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	240
	
i1l7912:	
;main.c: 240: g_tempSettleCnt = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	line	241
;main.c: 241: g_tempPhase = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_tempPhase)	;volatile
	line	247
	
i1l7914:	
;main.c: 242: }
;main.c: 243: }
;main.c: 244: }
;main.c: 247: if(++g_printTick >= 100)
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_printTick)^080h,f	;volatile
	skipnz
	incf	(_g_printTick+1)^080h,f	;volatile
	movlw	0
	subwf	((_g_printTick+1)^080h),w	;volatile
	movlw	064h
	skipnz
	subwf	((_g_printTick)^080h),w	;volatile
	skipc
	goto	u1201_21
	goto	u1201_20
u1201_21:
	goto	i1l7920
u1201_20:
	line	249
	
i1l7916:	
;main.c: 248: {
;main.c: 249: g_printTick = 0;
	clrf	(_g_printTick)^080h	;volatile
	clrf	(_g_printTick+1)^080h	;volatile
	line	250
	
i1l7918:	
;main.c: 250: g_printFlag = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	255
	
i1l7920:	
;main.c: 251: }
;main.c: 252: }
;main.c: 255: if(++g_scanIndex >= 12)
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	incf	(_g_scanIndex),f	;volatile
	subwf	((_g_scanIndex)),w	;volatile
	skipc
	goto	u1202_21
	goto	u1202_20
u1202_21:
	goto	i1l402
u1202_20:
	line	256
	
i1l7922:	
;main.c: 256: g_scanIndex = 0;
	clrf	(_g_scanIndex)	;volatile
	
i1l402:	
	line	257
;main.c: 257: g_scanPhase = 0;
	clrf	(_g_scanPhase)	;volatile
	line	258
;main.c: 258: break;
	goto	i1l371
	line	184
	
i1l7928:	
	movf	(_g_scanPhase),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 2
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           17     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l373
	xorlw	1^0	; case 1
	skipnz
	goto	i1l7868
	xorlw	2^1	; case 2
	skipnz
	goto	i1l7872
	goto	i1l402
	opt asmopt_pop

	line	265
	
i1l371:	
	movf	(??_Isr_Timer+3),w
	movwf	btemp+1
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^00h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	i1___lldiv

;; *************** function i1___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    0[COMMON] unsigned long 
;;  dividend        4    4[COMMON] unsigned long 
;; Auto vars:     Size  Location     Type
;;  __lldiv         4    9[COMMON] unsigned long 
;;  __lldiv         1    8[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    0[COMMON] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         8       0       0       0       0
;;      Locals:         5       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:        13       0       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext23
__ptext23:	;psect for function i1___lldiv
psect	text23
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_ofi1___lldiv
	__size_ofi1___lldiv	equ	__end_ofi1___lldiv-i1___lldiv
	
i1___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in i1___lldiv: [wreg+status,2+status,0]
	line	14
	
i1l7812:	
	clrf	(i1___lldiv@quotient)
	clrf	(i1___lldiv@quotient+1)
	clrf	(i1___lldiv@quotient+2)
	clrf	(i1___lldiv@quotient+3)
	line	15
	
i1l7814:	
	movf	(i1___lldiv@divisor+3),w
	iorwf	(i1___lldiv@divisor+2),w
	iorwf	(i1___lldiv@divisor+1),w
	iorwf	(i1___lldiv@divisor),w
	skipnz
	goto	u1184_21
	goto	u1184_20
u1184_21:
	goto	i1l7834
u1184_20:
	line	16
	
i1l7816:	
	clrf	(i1___lldiv@counter)
	incf	(i1___lldiv@counter),f
	line	17
	goto	i1l7820
	line	18
	
i1l7818:	
	clrc
	rlf	(i1___lldiv@divisor),f
	rlf	(i1___lldiv@divisor+1),f
	rlf	(i1___lldiv@divisor+2),f
	rlf	(i1___lldiv@divisor+3),f
	line	19
	incf	(i1___lldiv@counter),f
	line	17
	
i1l7820:	
	btfss	(i1___lldiv@divisor+3),(31)&7
	goto	u1185_21
	goto	u1185_20
u1185_21:
	goto	i1l7818
u1185_20:
	line	22
	
i1l7822:	
	clrc
	rlf	(i1___lldiv@quotient),f
	rlf	(i1___lldiv@quotient+1),f
	rlf	(i1___lldiv@quotient+2),f
	rlf	(i1___lldiv@quotient+3),f
	line	23
	
i1l7824:	
	movf	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),w
	skipz
	goto	u1186_25
	movf	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),w
	skipz
	goto	u1186_25
	movf	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),w
	skipz
	goto	u1186_25
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),w
u1186_25:
	skipc
	goto	u1186_21
	goto	u1186_20
u1186_21:
	goto	i1l7830
u1186_20:
	line	24
	
i1l7826:	
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),f
	movf	(i1___lldiv@divisor+1),w
	skipc
	incfsz	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),f
	movf	(i1___lldiv@divisor+2),w
	skipc
	incfsz	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),f
	movf	(i1___lldiv@divisor+3),w
	skipc
	incfsz	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),f
	line	25
	
i1l7828:	
	bsf	(i1___lldiv@quotient)+(0/8),(0)&7
	line	27
	
i1l7830:	
	clrc
	rrf	(i1___lldiv@divisor+3),f
	rrf	(i1___lldiv@divisor+2),f
	rrf	(i1___lldiv@divisor+1),f
	rrf	(i1___lldiv@divisor),f
	line	28
	
i1l7832:	
	decfsz	(i1___lldiv@counter),f
	goto	u1187_21
	goto	u1187_20
u1187_21:
	goto	i1l7822
u1187_20:
	line	30
	
i1l7834:	
	movf	(i1___lldiv@quotient+3),w
	movwf	(?i1___lldiv+3)
	movf	(i1___lldiv@quotient+2),w
	movwf	(?i1___lldiv+2)
	movf	(i1___lldiv@quotient+1),w
	movwf	(?i1___lldiv+1)
	movf	(i1___lldiv@quotient),w
	movwf	(?i1___lldiv)

	line	31
	
i1l1158:	
	return
	opt stack 0
GLOBAL	__end_ofi1___lldiv
	__end_ofi1___lldiv:
	signat	i1___lldiv,92
	global	i1_ADC_Sample

;; *************** function i1_ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    0[BANK0 ] unsigned char 
;;  ADC_Sample      4    3[BANK0 ] volatile unsigned long 
;;  ADC_Sample      2   11[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    9[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    7[BANK0 ] volatile unsigned int 
;;  ADC_Sample      1    2[BANK0 ] unsigned char 
;;  ADC_Sample      1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      13       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext24
__ptext24:	;psect for function i1_ADC_Sample
psect	text24
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_ofi1_ADC_Sample
	__size_ofi1_ADC_Sample	equ	__end_ofi1_ADC_Sample-i1_ADC_Sample
	
i1_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in i1_ADC_Sample: [wreg+status,2+status,0]
;i1ADC_Sample@adch stored from wreg
	movwf	(i1ADC_Sample@adch)
	line	51
	
i1l6152:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	52
	
i1l6154:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(i1ADC_Sample@admin)	;volatile
	clrf	(i1ADC_Sample@admin+1)	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(i1ADC_Sample@admax)	;volatile
	clrf	(i1ADC_Sample@admax+1)	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	line	58
	
i1l6156:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u884_21
	goto	u884_20
u884_21:
	goto	i1l6162
u884_20:
	
i1l6158:	
	btfss	(i1ADC_Sample@adldo),(2)&7
	goto	u885_21
	goto	u885_20
u885_21:
	goto	i1l6162
u885_20:
	line	60
	
i1l6160:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??i1_ADC_Sample+0)+0),f
	u1216_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u1216_27
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	i1l6164
	line	64
	
i1l6162:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	67
	
i1l6164:	
;adc_drv.c: 67: if(adch & 0x10)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(i1ADC_Sample@adch),(4)&7
	goto	u886_21
	goto	u886_20
u886_21:
	goto	i1l498
u886_20:
	line	69
	
i1l6166:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
i1l6168:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(i1ADC_Sample@adch),f
	line	71
;adc_drv.c: 71: }
	goto	i1l6170
	line	72
	
i1l498:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
i1l6170:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@i)
	
i1l6172:	
	movlw	low(022h)
	subwf	(i1ADC_Sample@i),w
	skipc
	goto	u887_21
	goto	u887_20
u887_21:
	goto	i1l6176
u887_20:
	goto	i1l6208
	line	79
	
i1l6176:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(i1ADC_Sample@adch),w
	movwf	(??i1_ADC_Sample+0)+0
	movlw	(02h)-1
u888_25:
	clrc
	rlf	(??i1_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u888_25
	clrc
	rlf	(??i1_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
i1l6178:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	6
movwf	((??i1_ADC_Sample+0)+0),f
	u1217_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u1217_27
	nop
opt asmopt_pop

	line	81
	
i1l6180:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
i1l6182:	
;adc_drv.c: 84: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@j)
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	i1l502
	
i1l503:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(i1ADC_Sample@j),f
	goto	u889_21
	goto	u889_20
u889_21:
	goto	i1l502
u889_20:
	line	89
	
i1l6184:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	i1l505
	line	90
	
i1l502:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u890_21
	goto	u890_20
u890_21:
	goto	i1l503
u890_20:
	line	93
	
i1l6188:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	swapf	(i1ADC_Sample@ad_temp),f	;volatile
	swapf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp),f	;volatile
	
i1l6190:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(i1ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(i1ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
i1l6192:	
;adc_drv.c: 96: if(0 == admax)
	movf	((i1ADC_Sample@admax)),w	;volatile
iorwf	((i1ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u891_21
	goto	u891_20
u891_21:
	goto	i1l6196
u891_20:
	line	98
	
i1l6194:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	100
;adc_drv.c: 100: }
	goto	i1l508
	line	102
	
i1l6196:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	subwf	(i1ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u892_25
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	subwf	(i1ADC_Sample@admax),w	;volatile
u892_25:
	skipnc
	goto	u892_21
	goto	u892_20
u892_21:
	goto	i1l6200
u892_20:
	line	103
	
i1l6198:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	goto	i1l508
	line	105
	
i1l6200:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	subwf	(i1ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u893_25
	movf	(i1ADC_Sample@admin),w	;volatile
	subwf	(i1ADC_Sample@ad_temp),w	;volatile
u893_25:
	skipnc
	goto	u893_21
	goto	u893_20
u893_21:
	goto	i1l508
u893_20:
	line	106
	
i1l6202:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	108
	
i1l508:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	addwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u894_21
	addwf	(i1ADC_Sample@adsum+1),f	;volatile
u894_21:
	movf	2+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u894_22
	addwf	(i1ADC_Sample@adsum+2),f	;volatile
u894_22:
	movf	3+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u894_23
	addwf	(i1ADC_Sample@adsum+3),f	;volatile
u894_23:

	line	76
	
i1l6204:	
	incf	(i1ADC_Sample@i),f
	goto	i1l6172
	line	112
	
i1l6208:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(i1ADC_Sample@admax),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admax+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u895_25
	goto	u895_26
u895_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u895_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u895_27
	goto	u895_28
u895_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u895_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u895_29
	goto	u895_20
u895_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u895_20:

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	3+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u896_25
	movf	2+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u896_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u896_25
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),w	;volatile
u896_25:
	skipc
	goto	u896_21
	goto	u896_20
u896_21:
	goto	i1l512
u896_20:
	line	114
	
i1l6210:	
;adc_drv.c: 114: adsum -= admin;
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u897_25
	goto	u897_26
u897_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u897_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u897_27
	goto	u897_28
u897_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u897_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u897_29
	goto	u897_20
u897_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u897_20:

	goto	i1l6212
	line	115
	
i1l512:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	118
	
i1l6212:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(i1ADC_Sample@adsum),w	;volatile
	movwf	(??i1_ADC_Sample+0)+0
	movf	(i1ADC_Sample@adsum+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	movf	(i1ADC_Sample@adsum+2),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+2)
	movf	(i1ADC_Sample@adsum+3),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+3)
	movlw	05h
u898_25:
	clrc
	rrf	(??i1_ADC_Sample+0)+3,f
	rrf	(??i1_ADC_Sample+0)+2,f
	rrf	(??i1_ADC_Sample+0)+1,f
	rrf	(??i1_ADC_Sample+0)+0,f
u898_20:
	addlw	-1
	skipz
	goto	u898_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
i1l6214:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
i1l505:	
	return
	opt stack 0
GLOBAL	__end_ofi1_ADC_Sample
	__end_ofi1_ADC_Sample:
	signat	i1_ADC_Sample,89
	global	_Update_LED_Slot

;; *************** function _Update_LED_Slot *****************
;; Defined at:
;;		line 31 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    0[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	31
global __ptext25
__ptext25:	;psect for function _Update_LED_Slot
psect	text25
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	31
	global	__size_of_Update_LED_Slot
	__size_of_Update_LED_Slot	equ	__end_of_Update_LED_Slot-_Update_LED_Slot
	
_Update_LED_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _Update_LED_Slot: [wreg]
	line	36
	
i1l856:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Slot
	__end_of_Update_LED_Slot:
	signat	_Update_LED_Slot,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 63 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=0
	line	63
global __ptext26
__ptext26:	;psect for function _PowerOnLedSequence
psect	text26
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	63
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	65
	
i1l5092:	
;led.c: 65: g_powerOnTimer++;
	incf	(_g_powerOnTimer),f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1),f	;volatile
	line	67
	
i1l5094:	
;led.c: 67: if(g_powerOnPhase == 0)
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u675_21
	goto	u675_20
u675_21:
	goto	i1l5102
u675_20:
	line	70
	
i1l5096:	
;led.c: 68: {
;led.c: 70: if(g_powerOnTimer >= 100)
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u676_21
	goto	u676_20
u676_21:
	goto	i1l868
u676_20:
	line	72
	
i1l5098:	
;led.c: 71: {
;led.c: 72: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	73
	
i1l5100:	
;led.c: 73: g_powerOnPhase = 1;
	movlw	low(01h)
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l868
	line	76
	
i1l5102:	
;led.c: 76: else if(g_powerOnPhase == 1)
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u677_21
	goto	u677_20
u677_21:
	goto	i1l868
u677_20:
	line	79
	
i1l5104:	
;led.c: 77: {
;led.c: 79: if(g_powerOnTimer >= 100)
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u678_21
	goto	u678_20
u678_21:
	goto	i1l868
u678_20:
	line	81
	
i1l5106:	
;led.c: 80: {
;led.c: 81: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	82
	
i1l5108:	
;led.c: 82: g_powerOnPhase = 2;
	movlw	low(02h)
	movwf	(_g_powerOnPhase)	;volatile
	line	86
	
i1l868:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
	global	_Led_BlinkProcess

;; *************** function _Led_BlinkProcess *****************
;; Defined at:
;;		line 48 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=0
	line	48
global __ptext27
__ptext27:	;psect for function _Led_BlinkProcess
psect	text27
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	48
	global	__size_of_Led_BlinkProcess
	__size_of_Led_BlinkProcess	equ	__end_of_Led_BlinkProcess-_Led_BlinkProcess
	
_Led_BlinkProcess:	
;incstack = 0
	opt	stack 3
; Regs used in _Led_BlinkProcess: [wreg+status,2+status,0]
	line	50
	
i1l5278:	
;led.c: 50: g_blinkTick++;
	bcf	status, 5	;RP0=0, select bank0
	incf	(_g_blinkTick),f
	line	51
	
i1l5280:	
;led.c: 51: if(g_blinkTick >= 100)
	movlw	low(064h)
	subwf	(_g_blinkTick),w
	skipc
	goto	u716_21
	goto	u716_20
u716_21:
	goto	i1l860
u716_20:
	line	52
	
i1l5282:	
;led.c: 52: g_blinkTick = 0;
	clrf	(_g_blinkTick)
	line	53
	
i1l860:	
	return
	opt stack 0
GLOBAL	__end_of_Led_BlinkProcess
	__end_of_Led_BlinkProcess:
	signat	_Led_BlinkProcess,89
	global	_Charging_Control

;; *************** function _Charging_Control *****************
;; Defined at:
;;		line 848 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    5[COMMON] unsigned char 
;;  i               1    6[COMMON] unsigned char 
;;  chargeB7_12     1    4[COMMON] unsigned char 
;;  chargeB1_6      1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 100/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	848
global __ptext28
__ptext28:	;psect for function _Charging_Control
psect	text28
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	848
	global	__size_of_Charging_Control
	__size_of_Charging_Control	equ	__end_of_Charging_Control-_Charging_Control
	
_Charging_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _Charging_Control: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	851
	
i1l6776:	
;charge_mgr.c: 850: unsigned char i;
;charge_mgr.c: 851: unsigned char chargeB1_6 = 0;
	clrf	(Charging_Control@chargeB1_6)
	line	852
;charge_mgr.c: 852: unsigned char chargeB7_12 = 0;
	clrf	(Charging_Control@chargeB7_12)
	line	855
	
i1l6778:	
;charge_mgr.c: 855: if(g_tempProtect)
	movf	((_g_tempProtect)),w
	btfsc	status,2
	goto	u980_21
	goto	u980_20
u980_21:
	goto	i1l6784
u980_20:
	line	857
;charge_mgr.c: 856: {
;charge_mgr.c: 857: do { RA0=1; RA1=1; RB3=1; RB2=1; RA3=1; RA2=1; RD1=1; RD3=1; RB0=1; RB1=1; RD2=1; RD0=1; } while(0);
	
i1l755:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	bsf	(1073/8)^080h,(1073)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	bsf	(50/8),(50)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	bsf	(1074/8)^080h,(1074)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	bsf	(49/8),(49)&7	;volatile
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	
i1l756:	
	line	858
;charge_mgr.c: 858: RC3 = 0;
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	859
;charge_mgr.c: 859: RC5 = 0;
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	860
	
i1l6780:	
;charge_mgr.c: 860: g_pwmDuty = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	goto	i1l757
	line	867
	
i1l6784:	
;charge_mgr.c: 862: }
;charge_mgr.c: 867: if(g_vccProtect)
	movf	((_g_vccProtect)),w
	btfsc	status,2
	goto	u981_21
	goto	u981_20
u981_21:
	goto	i1l6794
u981_20:
	line	869
	
i1l6786:	
;charge_mgr.c: 868: {
;charge_mgr.c: 869: if(g_vcc_mv < 4600)
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u982_21
	goto	u982_20
u982_21:
	goto	i1l6792
u982_20:
	goto	i1l755
	line	877
	
i1l6792:	
;charge_mgr.c: 876: }
;charge_mgr.c: 877: g_vccProtect = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	line	878
;charge_mgr.c: 878: }
	goto	i1l6802
	line	881
	
i1l6794:	
;charge_mgr.c: 879: else
;charge_mgr.c: 880: {
;charge_mgr.c: 881: if(g_vcc_mv < 4400)
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u983_21
	goto	u983_20
u983_21:
	goto	i1l6802
u983_20:
	line	883
	
i1l6796:	
;charge_mgr.c: 882: {
;charge_mgr.c: 883: g_vccProtect = 1;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	incf	(_g_vccProtect),f
	goto	i1l755
	line	893
	
i1l6802:	
;charge_mgr.c: 889: }
;charge_mgr.c: 890: }
;charge_mgr.c: 893: for(i = 0; i < 12; i++)
	clrf	(Charging_Control@i)
	line	895
	
i1l6808:	
;charge_mgr.c: 894: {
;charge_mgr.c: 895: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Charging_Control@s)
	line	900
	
i1l6810:	
;charge_mgr.c: 898: if(s == 2 || s == 3 ||
;charge_mgr.c: 899: s == 4 || s == 5 ||
;charge_mgr.c: 900: s == 8)
		movlw	2
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u984_21
	goto	u984_20
u984_21:
	goto	i1l6822
u984_20:
	
i1l6812:	
		movlw	3
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u985_21
	goto	u985_20
u985_21:
	goto	i1l6822
u985_20:
	
i1l6814:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u986_21
	goto	u986_20
u986_21:
	goto	i1l6822
u986_20:
	
i1l6816:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u987_21
	goto	u987_20
u987_21:
	goto	i1l6822
u987_20:
	
i1l6818:	
		movlw	8
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u988_21
	goto	u988_20
u988_21:
	goto	i1l6828
u988_20:
	goto	i1l6822
	line	902
	
i1l773:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l6824
	
i1l775:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l6824
	
i1l776:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l6824
	
i1l777:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l6824
	
i1l778:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l6824
	
i1l779:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l6824
	
i1l780:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l6824
	
i1l781:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l6824
	
i1l782:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l6824
	
i1l783:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l6824
	
i1l784:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l6824
	
i1l785:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l6824
	
i1l6822:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l773
	xorlw	1^0	; case 1
	skipnz
	goto	i1l775
	xorlw	2^1	; case 2
	skipnz
	goto	i1l776
	xorlw	3^2	; case 3
	skipnz
	goto	i1l777
	xorlw	4^3	; case 4
	skipnz
	goto	i1l778
	xorlw	5^4	; case 5
	skipnz
	goto	i1l779
	xorlw	6^5	; case 6
	skipnz
	goto	i1l780
	xorlw	7^6	; case 7
	skipnz
	goto	i1l781
	xorlw	8^7	; case 8
	skipnz
	goto	i1l782
	xorlw	9^8	; case 9
	skipnz
	goto	i1l783
	xorlw	10^9	; case 10
	skipnz
	goto	i1l784
	xorlw	11^10	; case 11
	skipnz
	goto	i1l785
	goto	i1l6824
	opt asmopt_pop

	line	905
	
i1l6824:	
;charge_mgr.c: 905: if(i < 6)
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipnc
	goto	u989_21
	goto	u989_20
u989_21:
	goto	i1l787
u989_20:
	line	906
	
i1l6826:	
;charge_mgr.c: 906: chargeB1_6 = 1;
	clrf	(Charging_Control@chargeB1_6)
	incf	(Charging_Control@chargeB1_6),f
	goto	i1l6838
	line	907
	
i1l787:	
	line	908
;charge_mgr.c: 907: else
;charge_mgr.c: 908: chargeB7_12 = 1;
	clrf	(Charging_Control@chargeB7_12)
	incf	(Charging_Control@chargeB7_12),f
	goto	i1l6838
	line	912
	
i1l6828:	
;charge_mgr.c: 912: else if(s == 1)
		decf	((Charging_Control@s)),w
	btfss	status,2
	goto	u990_21
	goto	u990_20
u990_21:
	goto	i1l6836
u990_20:
	goto	i1l6832
	line	914
	
i1l793:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l6838
	
i1l795:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l6838
	
i1l796:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l6838
	
i1l797:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l6838
	
i1l798:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l6838
	
i1l799:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l6838
	
i1l800:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l6838
	
i1l801:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l6838
	
i1l802:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l6838
	
i1l803:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l6838
	
i1l804:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l6838
	
i1l805:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l6838
	
i1l6832:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l793
	xorlw	1^0	; case 1
	skipnz
	goto	i1l795
	xorlw	2^1	; case 2
	skipnz
	goto	i1l796
	xorlw	3^2	; case 3
	skipnz
	goto	i1l797
	xorlw	4^3	; case 4
	skipnz
	goto	i1l798
	xorlw	5^4	; case 5
	skipnz
	goto	i1l799
	xorlw	6^5	; case 6
	skipnz
	goto	i1l800
	xorlw	7^6	; case 7
	skipnz
	goto	i1l801
	xorlw	8^7	; case 8
	skipnz
	goto	i1l802
	xorlw	9^8	; case 9
	skipnz
	goto	i1l803
	xorlw	10^9	; case 10
	skipnz
	goto	i1l804
	xorlw	11^10	; case 11
	skipnz
	goto	i1l805
	goto	i1l6838
	opt asmopt_pop

	line	918
	
i1l810:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l6838
	
i1l812:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l6838
	
i1l813:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	i1l6838
	
i1l814:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	i1l6838
	
i1l815:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l6838
	
i1l816:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l6838
	
i1l817:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l6838
	
i1l818:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l6838
	
i1l819:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	i1l6838
	
i1l820:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	i1l6838
	
i1l821:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l6838
	
i1l822:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l6838
	
i1l6836:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l810
	xorlw	1^0	; case 1
	skipnz
	goto	i1l812
	xorlw	2^1	; case 2
	skipnz
	goto	i1l813
	xorlw	3^2	; case 3
	skipnz
	goto	i1l814
	xorlw	4^3	; case 4
	skipnz
	goto	i1l815
	xorlw	5^4	; case 5
	skipnz
	goto	i1l816
	xorlw	6^5	; case 6
	skipnz
	goto	i1l817
	xorlw	7^6	; case 7
	skipnz
	goto	i1l818
	xorlw	8^7	; case 8
	skipnz
	goto	i1l819
	xorlw	9^8	; case 9
	skipnz
	goto	i1l820
	xorlw	10^9	; case 10
	skipnz
	goto	i1l821
	xorlw	11^10	; case 11
	skipnz
	goto	i1l822
	goto	i1l6838
	opt asmopt_pop

	line	893
	
i1l6838:	
	incf	(Charging_Control@i),f
	
i1l6840:	
	movlw	low(0Ch)
	subwf	(Charging_Control@i),w
	skipc
	goto	u991_21
	goto	u991_20
u991_21:
	goto	i1l6808
u991_20:
	
i1l767:	
	line	923
;charge_mgr.c: 919: }
;charge_mgr.c: 920: }
;charge_mgr.c: 923: RC3 = chargeB1_6;
	btfsc	(Charging_Control@chargeB1_6),0
	goto	u992_21
	goto	u992_20
	
u992_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2099/8)^0100h,(2099)&7	;volatile
	goto	u993_24
u992_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
u993_24:
	line	924
;charge_mgr.c: 924: RC5 = chargeB7_12;
	btfsc	(Charging_Control@chargeB7_12),0
	goto	u994_21
	goto	u994_20
	
u994_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u995_24
u994_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u995_24:
	line	927
	
i1l757:	
	return
	opt stack 0
GLOBAL	__end_of_Charging_Control
	__end_of_Charging_Control:
	signat	_Charging_Control,89
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 945 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    6[BANK0 ] unsigned int 
;;  s               1   17[BANK0 ] unsigned char 
;;  duty            2   14[BANK0 ] int 
;;  error           2   10[BANK0 ] int 
;;  adjust          2    0[BANK0 ] int 
;;  duty_initial    1   13[BANK0 ] unsigned char 
;;  duty_target     1   12[BANK0 ] unsigned char 
;;  maxV            2    8[BANK0 ] unsigned int 
;;  i               1   16[BANK0 ] unsigned char 
;;  preCount        1    5[BANK0 ] unsigned char 
;;  ccCount         1    4[BANK0 ] unsigned char 
;;  cvCount         1    3[BANK0 ] unsigned char 
;;  hasCharging     1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 100/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2      18       0       0       0
;;Total ram usage:       20 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___awdiv
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=0
	line	945
global __ptext29
__ptext29:	;psect for function _CCCV_Control
psect	text29
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	945
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	948
	
i1l6842:	
;charge_mgr.c: 947: unsigned char i;
;charge_mgr.c: 948: unsigned char hasCharging = 0;
	bcf	status, 6	;RP1=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	949
;charge_mgr.c: 949: unsigned int maxV = 0;
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	950
;charge_mgr.c: 950: unsigned char cvCount = 0;
	clrf	(CCCV_Control@cvCount)
	line	951
;charge_mgr.c: 951: unsigned char ccCount = 0;
	clrf	(CCCV_Control@ccCount)
	line	952
;charge_mgr.c: 952: unsigned char preCount = 0;
	clrf	(CCCV_Control@preCount)
	line	955
;charge_mgr.c: 955: for(i = 0; i < 12; i++)
	clrf	(CCCV_Control@i)
	line	957
	
i1l6848:	
;charge_mgr.c: 956: {
;charge_mgr.c: 957: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	961
	
i1l6850:	
;charge_mgr.c: 959: if(s == 2 || s == 3 ||
;charge_mgr.c: 960: s == 4 || s == 5 ||
;charge_mgr.c: 961: s == 8)
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u996_21
	goto	u996_20
u996_21:
	goto	i1l830
u996_20:
	
i1l6852:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u997_21
	goto	u997_20
u997_21:
	goto	i1l830
u997_20:
	
i1l6854:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u998_21
	goto	u998_20
u998_21:
	goto	i1l830
u998_20:
	
i1l6856:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u999_21
	goto	u999_20
u999_21:
	goto	i1l830
u999_20:
	
i1l6858:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1000_21
	goto	u1000_20
u1000_21:
	goto	i1l828
u1000_20:
	
i1l830:	
	line	963
;charge_mgr.c: 962: {
;charge_mgr.c: 963: hasCharging = 1;
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	965
	
i1l6860:	
;charge_mgr.c: 964: {
;charge_mgr.c: 965: unsigned int vt = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	966
	
i1l6862:	
;charge_mgr.c: 966: if(vt > maxV) maxV = vt;
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u1001_25
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u1001_25:
	skipnc
	goto	u1001_21
	goto	u1001_20
u1001_21:
	goto	i1l6866
u1001_20:
	
i1l6864:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	968
	
i1l6866:	
;charge_mgr.c: 967: }
;charge_mgr.c: 968: if(s == 5)
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1002_21
	goto	u1002_20
u1002_21:
	goto	i1l6870
u1002_20:
	line	969
	
i1l6868:	
;charge_mgr.c: 969: cvCount++;
	incf	(CCCV_Control@cvCount),f
	line	970
	
i1l6870:	
;charge_mgr.c: 970: if(s == 4)
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1003_21
	goto	u1003_20
u1003_21:
	goto	i1l6874
u1003_20:
	line	971
	
i1l6872:	
;charge_mgr.c: 971: ccCount++;
	incf	(CCCV_Control@ccCount),f
	line	972
	
i1l6874:	
;charge_mgr.c: 972: if(s == 3 || s == 2)
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1004_21
	goto	u1004_20
u1004_21:
	goto	i1l6878
u1004_20:
	
i1l6876:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1005_21
	goto	u1005_20
u1005_21:
	goto	i1l828
u1005_20:
	line	973
	
i1l6878:	
;charge_mgr.c: 973: preCount++;
	incf	(CCCV_Control@preCount),f
	line	974
	
i1l828:	
	line	955
	incf	(CCCV_Control@i),f
	
i1l6880:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u1006_21
	goto	u1006_20
u1006_21:
	goto	i1l6848
u1006_20:
	line	978
	
i1l6882:	
;charge_mgr.c: 974: }
;charge_mgr.c: 975: }
;charge_mgr.c: 978: if(!hasCharging)
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u1007_21
	goto	u1007_20
u1007_21:
	goto	i1l6888
u1007_20:
	line	980
	
i1l6884:	
;charge_mgr.c: 979: {
;charge_mgr.c: 980: g_pwmDuty = 0;
	clrf	(_g_pwmDuty)	;volatile
	line	981
;charge_mgr.c: 981: g_cvIntegral = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	i1l838
	line	989
	
i1l6888:	
;charge_mgr.c: 983: }
;charge_mgr.c: 989: if(cvCount == 0)
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u1008_21
	goto	u1008_20
u1008_21:
	goto	i1l6918
u1008_20:
	line	993
	
i1l6890:	
;charge_mgr.c: 990: {
;charge_mgr.c: 991: unsigned char duty_target, duty_initial;
;charge_mgr.c: 993: if(ccCount > 0)
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u1009_21
	goto	u1009_20
u1009_21:
	goto	i1l6894
u1009_20:
	line	996
	
i1l6892:	
;charge_mgr.c: 994: {
;charge_mgr.c: 996: duty_target = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	997
;charge_mgr.c: 997: duty_initial = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	998
;charge_mgr.c: 998: }
	goto	i1l6902
	line	999
	
i1l6894:	
;charge_mgr.c: 999: else if(preCount > 0)
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u1010_21
	goto	u1010_20
u1010_21:
	goto	i1l6898
u1010_20:
	line	1002
	
i1l6896:	
;charge_mgr.c: 1000: {
;charge_mgr.c: 1002: duty_target = 8;
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	1003
;charge_mgr.c: 1003: duty_initial = 5;
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	1004
;charge_mgr.c: 1004: }
	goto	i1l6902
	line	1009
	
i1l6898:	
;charge_mgr.c: 1005: else
;charge_mgr.c: 1006: {
;charge_mgr.c: 1009: g_pwmDuty = 25;
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l838
	line	1013
	
i1l6902:	
;charge_mgr.c: 1011: }
;charge_mgr.c: 1013: if(g_pwmDuty < duty_initial)
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u1011_21
	goto	u1011_20
u1011_21:
	goto	i1l6910
u1011_20:
	line	1016
	
i1l6904:	
;charge_mgr.c: 1014: {
;charge_mgr.c: 1016: g_pwmDuty += 3;
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	1017
	
i1l6906:	
;charge_mgr.c: 1017: if(g_pwmDuty > duty_initial)
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u1012_21
	goto	u1012_20
u1012_21:
	goto	i1l838
u1012_20:
	line	1018
	
i1l6908:	
;charge_mgr.c: 1018: g_pwmDuty = duty_initial;
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l838
	line	1020
	
i1l6910:	
	line	1023
	
i1l6912:	
;charge_mgr.c: 1021: {
;charge_mgr.c: 1023: g_pwmDuty = duty_target;
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	1024
;charge_mgr.c: 1024: }
	goto	i1l838
	line	1039
	
i1l6918:	
;charge_mgr.c: 1031: }
;charge_mgr.c: 1038: {
;charge_mgr.c: 1039: int error = (int)(3100) - (int)(maxV);
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	1042
;charge_mgr.c: 1042: g_cvIntegral += error * 1;
	movf	(CCCV_Control@error),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral)^080h,f
	skipnc
	incf	(_g_cvIntegral+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(CCCV_Control@error+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral+1)^080h,f
	line	1043
	
i1l6920:	
;charge_mgr.c: 1043: if(g_cvIntegral > 200)
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u1013_25
	movlw	0C9h
	subwf	(_g_cvIntegral)^080h,w
u1013_25:

	skipc
	goto	u1013_21
	goto	u1013_20
u1013_21:
	goto	i1l6924
u1013_20:
	line	1044
	
i1l6922:	
;charge_mgr.c: 1044: g_cvIntegral = 200;
	movlw	0C8h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	i1l6928
	line	1045
	
i1l6924:	
;charge_mgr.c: 1045: else if(g_cvIntegral < -200)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u1014_25
	movlw	038h
	subwf	(_g_cvIntegral)^080h,w
u1014_25:

	skipnc
	goto	u1014_21
	goto	u1014_20
u1014_21:
	goto	i1l6928
u1014_20:
	line	1046
	
i1l6926:	
;charge_mgr.c: 1046: g_cvIntegral = -200;
	movlw	038h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	movlw	0FFh
	movwf	((_g_cvIntegral)^080h)+1
	line	1049
	
i1l6928:	
;charge_mgr.c: 1049: int adjust = (error * 4 + g_cvIntegral) / 8;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_cvIntegral)^080h,w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1)^080h,w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	1050
	
i1l6930:	
;charge_mgr.c: 1050: int duty = (int)g_pwmDuty + adjust;
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
i1l6932:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	1053
	
i1l6934:	
;charge_mgr.c: 1053: if(duty > 32) duty = 32;
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u1015_25
	movlw	021h
	subwf	(CCCV_Control@duty),w
u1015_25:

	skipc
	goto	u1015_21
	goto	u1015_20
u1015_21:
	goto	i1l6938
u1015_20:
	
i1l6936:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1054
	
i1l6938:	
;charge_mgr.c: 1054: if(duty < 0) duty = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u1016_21
	goto	u1016_20
u1016_21:
	goto	i1l6942
u1016_20:
	
i1l6940:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1056
	
i1l6942:	
;charge_mgr.c: 1056: g_pwmDuty = (unsigned char)duty;
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	1058
	
i1l838:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	i1___bmul

;; *************** function i1___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[COMMON] unsigned char 
;;  __bmul          1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Charging_Control
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text30,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext30
__ptext30:	;psect for function i1___bmul
psect	text30
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_ofi1___bmul
	__size_ofi1___bmul	equ	__end_ofi1___bmul-i1___bmul
	
i1___bmul:	
;incstack = 0
	opt	stack 2
; Regs used in i1___bmul: [wreg+status,2+status,0]
;i1___bmul@multiplier stored from wreg
	movwf	(i1___bmul@multiplier)
	line	6
	
i1l3278:	
	clrf	(i1___bmul@product)
	line	43
	
i1l3280:	
	btfss	(i1___bmul@multiplier),(0)&7
	goto	u359_21
	goto	u359_20
u359_21:
	goto	i1l3284
u359_20:
	line	44
	
i1l3282:	
	movf	(i1___bmul@multiplicand),w
	addwf	(i1___bmul@product),f
	line	45
	
i1l3284:	
	clrc
	rlf	(i1___bmul@multiplicand),f
	line	46
	
i1l3286:	
	clrc
	rrf	(i1___bmul@multiplier),f
	line	47
	movf	((i1___bmul@multiplier)),w
	btfss	status,2
	goto	u360_21
	goto	u360_20
u360_21:
	goto	i1l3280
u360_20:
	line	50
	
i1l3288:	
	movf	(i1___bmul@product),w
	line	51
	
i1l892:	
	return
	opt stack 0
GLOBAL	__end_ofi1___bmul
	__end_ofi1___bmul:
	signat	i1___bmul,89
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] int 
;;  dividend        2    2[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] int 
;;  sign            1    5[COMMON] unsigned char 
;;  counter         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text31,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext31
__ptext31:	;psect for function ___awdiv
psect	text31
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
i1l4976:	
	clrf	(___awdiv@sign)
	line	15
	
i1l4978:	
	btfss	(___awdiv@divisor+1),7
	goto	u667_21
	goto	u667_20
u667_21:
	goto	i1l4984
u667_20:
	line	16
	
i1l4980:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
i1l4982:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
i1l4984:	
	btfss	(___awdiv@dividend+1),7
	goto	u668_21
	goto	u668_20
u668_21:
	goto	i1l4990
u668_20:
	line	20
	
i1l4986:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
i1l4988:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
i1l4990:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
i1l4992:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u669_21
	goto	u669_20
u669_21:
	goto	i1l5012
u669_20:
	line	25
	
i1l4994:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	i1l4998
	line	27
	
i1l4996:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
i1l4998:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u670_21
	goto	u670_20
u670_21:
	goto	i1l4996
u670_20:
	line	31
	
i1l5000:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
i1l5002:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u671_25
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u671_25:
	skipc
	goto	u671_21
	goto	u671_20
u671_21:
	goto	i1l5008
u671_20:
	line	33
	
i1l5004:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
i1l5006:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
i1l5008:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
i1l5010:	
	decfsz	(___awdiv@counter),f
	goto	u672_21
	goto	u672_20
u672_21:
	goto	i1l5000
u672_20:
	line	39
	
i1l5012:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u673_21
	goto	u673_20
u673_21:
	goto	i1l5016
u673_20:
	line	40
	
i1l5014:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
i1l5016:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
i1l1004:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
