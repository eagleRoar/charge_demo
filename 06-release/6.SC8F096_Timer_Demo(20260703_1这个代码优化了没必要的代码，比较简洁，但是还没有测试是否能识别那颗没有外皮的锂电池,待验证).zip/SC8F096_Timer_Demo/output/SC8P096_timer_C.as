opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ChargeProcess_Slot
	FNCALL	_main,_Do_AdcSample
	FNCALL	_main,_Do_NtcRead
	FNCALL	_main,_Print_DetectLog
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_System_Init
	FNCALL	_main,___bmul
	FNCALL	_main,_uart_send_number
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_Print_DetectLog,_uart_send_char
	FNCALL	_Print_DetectLog,_uart_send_number
	FNCALL	_Print_DetectLog,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_Do_NtcRead,_Read_Temperature
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Do_AdcSample,_ADC_Sample
	FNCALL	_Do_AdcSample,___bmul
	FNCALL	_ChargeProcess_Slot,_Detect_BatteryType
	FNCALL	_ChargeProcess_Slot,___bmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_CCCV_Control
	FNCALL	_Isr_Timer,_Charging_Control
	FNCALL	_Isr_Timer,_Led_BlinkProcess
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Update_LED_Slot
	FNCALL	_Update_LED_Slot,i1___bmul
	FNCALL	_Charging_Control,i1___bmul
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,i1___bmul
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_temperature
psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	9

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	45
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_dbgNewState
	global	_g_dbgSlot
	global	_g_tempPhase
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_scanPhase
	global	_g_scanIndex
	global	_g_detectLogType
	global	_g_detectLogSlot
	global	_test_adc
	global	_adresult
	global	_g_dbgDetectFlag
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_adcBusy
	global	_g_doAdcSample
	global	_g_detectLogFlag
	global	_g_blinkTimer
	global	_g_blinkPhase
	global	_g_ledState
	global	_g_ccBlocks
	global	_g_dbgVoltage
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_powerOnTimer
	global	_g_cvIntegral
	global	_g_tempProtect
	global	_g_dbgNewType
	global	_g_impRefV
	global	_g_slot
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_GIE
_GIE	set	0x5F
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RC4
_RC4	set	0x834
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC5
_RC5	set	0x835
	global	_RC3
_RC3	set	0x833
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_25:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	101	;'e'
	retlw	108	;'l'
	retlw	108	;'l'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	68	;'D'
	retlw	66	;'B'
	retlw	71	;'G'
	retlw	58	;':'
	retlw	32	;' '
	retlw	115	;'s'
	retlw	108	;'l'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_27:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	87	;'W'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_32:	
	retlw	32	;' '
	retlw	118	;'v'
	retlw	114	;'r'
	retlw	102	;'f'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_9:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_29:	
	retlw	32	;' '
	retlw	115	;'s'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_30:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_11:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_31:	
	retlw	32	;' '
	retlw	86	;'V'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
STR_7	equ	STR_2+0
STR_8	equ	STR_3+0
STR_23	equ	STR_27+7
STR_33	equ	STR_27+7
; #config settings
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\output\SC8P096_timer_C.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssBANK0,class=BANK0,bit,space=1,noexec
global __pbitbssBANK0
__pbitbssBANK0:
_g_dbgDetectFlag:
       ds      1

_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

_g_adcBusy:
       ds      1

_g_doAdcSample:
       ds      1

_g_detectLogFlag:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_dbgNewState:
       ds      1

_g_dbgSlot:
       ds      1

_g_tempPhase:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_scanPhase:
       ds      1

_g_scanIndex:
       ds      1

_g_detectLogType:
       ds      1

_g_detectLogSlot:
       ds      1

_test_adc:
       ds      1

_adresult:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_blinkTimer:
       ds      24

_g_blinkPhase:
       ds      12

_g_ledState:
       ds      12

_g_ccBlocks:
       ds      12

_g_dbgVoltage:
       ds      2

_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_powerOnTimer:
       ds      2

_g_cvIntegral:
       ds      2

_g_tempProtect:
       ds      1

_g_dbgNewType:
       ds      1

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	9
_g_temperature:
       ds      2

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slot:
       ds      72

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_impRefV:
       ds      24

	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\output\SC8P096_timer_C.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+018h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+04Ah)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+0Dh)
	fcall	clear_ram0
; Clear objects allocated to BITBANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	clrf	((__pbitbssBANK0/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK2,class=BANK2,space=1,noexec
global __pcstackBANK2
__pcstackBANK2:
	global	_Print_SystemStatus$712
_Print_SystemStatus$712:	; 2 bytes @ 0x0
	ds	2
	global	_Print_SystemStatus$713
_Print_SystemStatus$713:	; 2 bytes @ 0x2
	ds	2
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x4
	ds	4
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x8
	ds	1
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x9
	ds	2
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0xB
	ds	4
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0xF
	ds	4
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x13
	ds	2
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x15
	ds	1
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
??_main:	; 1 bytes @ 0x0
	ds	2
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Update_LED_Slot:	; 1 bytes @ 0x0
?_Charging_Control:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Led_BlinkProcess:	; 1 bytes @ 0x0
??_Led_BlinkProcess:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_ChargeProcess_Slot:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Do_AdcSample:	; 1 bytes @ 0x0
?_Do_NtcRead:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_Print_DetectLog:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?i1___bmul:	; 1 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	i1___bmul@multiplicand
i1___bmul@multiplicand:	; 1 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	ds	1
??i1___bmul:	; 1 bytes @ 0x1
	global	i1___bmul@multiplier
i1___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
	global	Led_BlinkProcess@i
Led_BlinkProcess@i:	; 1 bytes @ 0x2
	global	i1___bmul@product
i1___bmul@product:	; 1 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_Update_LED_Slot:	; 1 bytes @ 0x3
??_Charging_Control:	; 1 bytes @ 0x3
	global	Charging_Control@chargeB1_6
Charging_Control@chargeB1_6:	; 1 bytes @ 0x3
	global	Update_LED_Slot@s
Update_LED_Slot@s:	; 1 bytes @ 0x3
	ds	1
??___awdiv:	; 1 bytes @ 0x4
	global	Charging_Control@chargeB7_12
Charging_Control@chargeB7_12:	; 1 bytes @ 0x4
	global	Update_LED_Slot@idx
Update_LED_Slot@idx:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	ds	1
	global	Charging_Control@s
Charging_Control@s:	; 1 bytes @ 0x5
	global	Update_LED_Slot@led
Update_LED_Slot@led:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	ds	1
	global	Charging_Control@i
Charging_Control@i:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	2
??_CCCV_Control:	; 1 bytes @ 0x8
	ds	2
??_Isr_Timer:	; 1 bytes @ 0xA
	ds	4
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x0
	ds	2
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x2
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x3
	ds	1
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x4
	ds	2
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x6
	ds	2
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0x8
	ds	2
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0xA
	ds	2
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0xC
	ds	1
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0xD
	ds	1
??_AD_Init:	; 1 bytes @ 0xE
??_uart_init:	; 1 bytes @ 0xE
?_ADC_Sample:	; 1 bytes @ 0xE
??_uart_send_char:	; 1 bytes @ 0xE
?_Detect_BatteryType:	; 1 bytes @ 0xE
?___bmul:	; 1 bytes @ 0xE
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0xE
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0xE
	global	?___lmul
?___lmul:	; 4 bytes @ 0xE
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0xE
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0xE
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0xE
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0xE
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0xE
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0xE
	ds	1
??_ADC_Sample:	; 1 bytes @ 0xF
??___bmul:	; 1 bytes @ 0xF
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0xF
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0xF
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x10
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x10
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x10
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x10
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x10
	ds	1
?_uart_send_string:	; 1 bytes @ 0x11
??_ChargeProcess_Slot:	; 1 bytes @ 0x11
??_System_Init:	; 1 bytes @ 0x11
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x11
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x11
	global	ChargeProcess_Slot@delta
ChargeProcess_Slot@delta:	; 2 bytes @ 0x11
	ds	1
??___lwdiv:	; 1 bytes @ 0x12
??___lwmod:	; 1 bytes @ 0x12
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x12
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x12
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x12
	ds	1
??_uart_send_string:	; 1 bytes @ 0x13
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x13
	global	ChargeProcess_Slot@rise
ChargeProcess_Slot@rise:	; 2 bytes @ 0x13
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x13
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x14
	ds	1
?_uart_send_number:	; 1 bytes @ 0x15
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x15
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x15
	global	ChargeProcess_Slot@v_before
ChargeProcess_Slot@v_before:	; 2 bytes @ 0x15
	ds	1
??___lmul:	; 1 bytes @ 0x16
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x16
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x16
	ds	1
??_uart_send_number:	; 1 bytes @ 0x17
	global	ChargeProcess_Slot@v_start
ChargeProcess_Slot@v_start:	; 2 bytes @ 0x17
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x17
	ds	3
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x1A
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x1A
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x1A
	ds	1
	global	ChargeProcess_Slot@st
ChargeProcess_Slot@st:	; 1 bytes @ 0x1B
	ds	1
	global	ChargeProcess_Slot@ty
ChargeProcess_Slot@ty:	; 1 bytes @ 0x1C
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x1C
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0x1D
	global	ChargeProcess_Slot@ct
ChargeProcess_Slot@ct:	; 2 bytes @ 0x1D
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x1E
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0x1E
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x1E
	ds	1
??_Print_NtcTemp:	; 1 bytes @ 0x1F
??_Print_DetectLog:	; 1 bytes @ 0x1F
	global	ChargeProcess_Slot@idx
ChargeProcess_Slot@idx:	; 1 bytes @ 0x1F
	global	_Print_NtcTemp$710
_Print_NtcTemp$710:	; 2 bytes @ 0x1F
	ds	1
??_Do_AdcSample:	; 1 bytes @ 0x20
	global	Do_AdcSample@ch
Do_AdcSample@ch:	; 1 bytes @ 0x20
	global	ChargeProcess_Slot@v
ChargeProcess_Slot@v:	; 2 bytes @ 0x20
	ds	1
	global	_Print_NtcTemp$711
_Print_NtcTemp$711:	; 2 bytes @ 0x21
	ds	1
??___lldiv:	; 1 bytes @ 0x22
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x22
	ds	4
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x26
	ds	1
??_Read_Temperature:	; 1 bytes @ 0x27
??_Print_SystemStatus:	; 1 bytes @ 0x27
	ds	4
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x2B
	ds	4
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x2F
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x31
	ds	2
??_Do_NtcRead:	; 1 bytes @ 0x33
	global	main@slot
main@slot:	; 1 bytes @ 0x33
	ds	1
;!
;!Data Sizes:
;!    Strings     268
;!    Constant    12
;!    Data        2
;!    BSS         183
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     14      14
;!    BANK0            80     52      66
;!    BANK1            80      2      78
;!    BANK3            80      0      72
;!    BANK2            80     22      46

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 37
;!		 -> STR_33(CODE[3]), STR_32(CODE[7]), STR_31(CODE[4]), STR_30(CODE[5]), 
;!		 -> STR_29(CODE[5]), STR_28(CODE[11]), STR_27(CODE[10]), STR_26(CODE[21]), 
;!		 -> STR_25(CODE[37]), STR_24(CODE[33]), STR_23(CODE[3]), STR_22(CODE[6]), 
;!		 -> STR_21(CODE[8]), STR_20(CODE[6]), STR_19(CODE[6]), STR_18(CODE[7]), 
;!		 -> STR_17(CODE[5]), STR_16(CODE[5]), STR_15(CODE[6]), STR_14(CODE[6]), 
;!		 -> STR_13(CODE[6]), STR_12(CODE[7]), STR_11(CODE[4]), STR_10(CODE[6]), 
;!		 -> STR_9(CODE[6]), STR_8(CODE[4]), STR_7(CODE[2]), STR_6(CODE[6]), 
;!		 -> STR_5(CODE[5]), STR_4(CODE[29]), STR_3(CODE[4]), STR_2(CODE[2]), 
;!		 -> STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->_CCCV_Control
;!    _Update_LED_Slot->i1___bmul
;!    _Charging_Control->i1___bmul
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _main in BANK0
;!
;!    _System_Init->___bmul
;!    _Print_SystemStatus->___lldiv
;!    _Print_NtcTemp->_uart_send_number
;!    _Print_DetectLog->_uart_send_number
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _Do_NtcRead->_Read_Temperature
;!    _Read_Temperature->___lldiv
;!    ___lldiv->___lmul
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->___bmul
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    _Isr_Timer->_CCCV_Control
;!
;!Critical Paths under _main in BANK1
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    _main->_Print_SystemStatus
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 3     3      0   37103
;!                                             51 BANK0      1     1      0
;!                                              0 BANK1      2     2      0
;!                 _ChargeProcess_Slot
;!                       _Do_AdcSample
;!                         _Do_NtcRead
;!                    _Print_DetectLog
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                        _System_Init
;!                             ___bmul
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1147
;!                                             17 BANK0      1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  30    30      0   10140
;!                                             39 BANK0      8     8      0
;!                                              0 BANK2     22    22      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    5811
;!                                             31 BANK0      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_DetectLog                                      0     0      0    4878
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    2312
;!                                             17 BANK0      2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_number                                    10     8      2    2464
;!                                             21 BANK0     10     8      2
;!                             ___bmul (ARG)
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     102
;!                                             14 BANK0      3     3      0
;! ---------------------------------------------------------------------------------
;! (2) ___lwmod                                              5     1      4     378
;!                                             14 BANK0      5     1      4
;! ---------------------------------------------------------------------------------
;! (1) _Do_NtcRead                                           0     0      0    3892
;!                   _Read_Temperature
;! ---------------------------------------------------------------------------------
;! (2) _Read_Temperature                                    12    12      0    3892
;!                                             39 BANK0     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (2) ___lwdiv                                              7     3      4     647
;!                                             14 BANK0      7     3      4
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8    1077
;!                                             14 BANK0     12     4      8
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8     800
;!                                             26 BANK0     13     5      8
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (1) _Do_AdcSample                                         1     1      0    1762
;!                                             32 BANK0      1     1      0
;!                         _ADC_Sample
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) _ADC_Sample                                          18    17      1     965
;!                                             14 BANK0     18    17      1
;! ---------------------------------------------------------------------------------
;! (1) _ChargeProcess_Slot                                  17    17      0    3869
;!                                             17 BANK0     17    17      0
;!                 _Detect_BatteryType
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) ___bmul                                               3     2      1     763
;!                                             14 BANK0      3     2      1
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     317
;!                                             14 BANK0      2     0      2
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 2
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            4     4      0    2377
;!                                             10 COMMON     4     4      0
;!                       _CCCV_Control
;!                   _Charging_Control
;!                   _Led_BlinkProcess
;!                 _PowerOnLedSequence
;!                    _Update_LED_Slot
;! ---------------------------------------------------------------------------------
;! (5) _Update_LED_Slot                                      3     3      0     286
;!                                              3 COMMON     3     3      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Led_BlinkProcess                                     3     3      0     156
;!                                              0 COMMON     3     3      0
;! ---------------------------------------------------------------------------------
;! (5) _Charging_Control                                     4     4      0     599
;!                                              3 COMMON     4     4      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _CCCV_Control                                        16    16      0    1336
;!                                              8 COMMON     2     2      0
;!                                              0 BANK0     14    14      0
;!                            ___awdiv
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (6) i1___bmul                                             3     2      1     144
;!                                              0 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (6) ___awdiv                                              8     4      4     428
;!                                              0 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ChargeProcess_Slot
;!     _Detect_BatteryType
;!     ___bmul
;!   _Do_AdcSample
;!     _ADC_Sample
;!     ___bmul
;!   _Do_NtcRead
;!     _Read_Temperature
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!       ___lwdiv
;!   _Print_DetectLog
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   ___bmul
;!   _uart_send_number
;!     ___bmul (ARG)
;!     ___lwdiv (ARG)
;!     ___lwmod (ARG)
;!     _uart_send_char (ARG)
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     i1___bmul
;!   _Charging_Control
;!     i1___bmul
;!   _Led_BlinkProcess
;!   _PowerOnLedSequence
;!   _Update_LED_Slot
;!     i1___bmul
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50      0      48       8       90.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50     16      2E      10       57.5%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50      2      4E       6       97.5%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     34      42       4       82.5%
;!BITBANK0            50      0       1       3        1.3%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      E       E       1      100.0%
;!BITCOMMON            E      0       0       0        0.0%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     114      12        0.0%
;!ABS                  0      0     114      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 423 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  slot            1   51[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       2       0       0
;;      Totals:         0       1       2       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ChargeProcess_Slot
;;		_Do_AdcSample
;;		_Do_NtcRead
;;		_Print_DetectLog
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_System_Init
;;		___bmul
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	423
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	423
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	426
	
l4307:	
	opt asmopt_push
opt asmopt_off
movlw	52
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_main+0)^080h+0+1),f
	movlw	241
movwf	((??_main+0)^080h+0),f
	u4877:
decfsz	((??_main+0)^080h+0),f
	goto	u4877
	decfsz	((??_main+0)^080h+0+1),f
	goto	u4877
opt asmopt_pop

	line	427
# 427 "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	430
	
l4309:	
	fcall	_System_Init
	line	433
	
l4311:	
	movlw	low(((STR_26)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	434
	
l4313:	
	movlw	low(((STR_27)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	437
	
l444:	
	line	439
# 439 "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	442
	
l4315:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u4821
	goto	u4820
u4821:
	goto	l4353
u4820:
	line	444
	
l4317:	
	bcf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	line	445
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	446
	
l4319:	
	fcall	_Do_AdcSample
	line	450
	
l4321:	
	movf	(_g_scanIndex),w	;volatile
	fcall	_ChargeProcess_Slot
	line	453
	
l4323:	
	btfss	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	goto	u4831
	goto	u4830
u4831:
	goto	l4351
u4830:
	line	455
	
l4325:	
	movf	(_g_dbgSlot),w	;volatile
	movwf	(main@slot)
	line	456
	
l4327:	
	bcf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	459
	
l4329:	
	movlw	low(((STR_28)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	460
	
l4331:	
	movf	(main@slot),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	461
	
l4333:	
	movlw	low(((STR_29)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	462
	
l4335:	
	movf	(_g_dbgNewState),w	;volatile
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	463
	
l4337:	
	movlw	low(((STR_30)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	464
	
l4339:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_dbgNewType)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	465
	
l4341:	
	movlw	low(((STR_31)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	466
	
l4343:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_dbgVoltage+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_dbgVoltage)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	467
	
l4345:	
	movlw	low(((STR_32)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	468
	
l4347:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(main@slot),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	469
	
l4349:	
	movlw	low(((STR_33)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	472
	
l4351:	
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	476
	
l4353:	
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u4841
	goto	u4840
u4841:
	goto	l4361
u4840:
	line	478
	
l4355:	
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	479
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	480
	
l4357:	
	fcall	_Do_NtcRead
	line	481
	
l4359:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	485
	
l4361:	
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u4851
	goto	u4850
u4851:
	goto	l4367
u4850:
	line	487
	
l4363:	
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	488
	
l4365:	
	fcall	_Print_SystemStatus
	line	489
	fcall	_Print_NtcTemp
	line	493
	
l4367:	
	btfss	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	goto	u4861
	goto	u4860
u4861:
	goto	l444
u4860:
	line	495
	
l4369:	
	bcf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	line	496
	
l4371:	
	fcall	_Print_DetectLog
	goto	l444
	global	start
	ljmp	start
	opt stack 0
	line	499
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 66 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   17[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	66
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	66
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	71
	
l3643:	
# 71 "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	72
# 72 "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text1
	line	73
	
l3645:	
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	77
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	78
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	79
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l3647:	
	clrf	(262)^0100h	;volatile
	line	80
	
l3649:	
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l3651:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	83
	
l3653:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l3655:	
	clrf	(135)^080h	;volatile
	line	84
	
l3657:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l3659:	
	clrf	(7)	;volatile
	line	85
	
l3661:	
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	86
	
l3663:	
	clrf	(277)^0100h	;volatile
	line	89
	
l3665:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l3667:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	92
	
l3669:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	93
	
l3671:	
	clrf	(406)^0180h	;volatile
	line	100
	
l3673:	
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	101
	
l3675:	
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	102
	
l3677:	
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	103
	
l3679:	
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	106
	
l3681:	
	fcall	_AD_Init
	line	109
	
l3683:	
	fcall	_uart_init
	line	116
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	117
	
l3685:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	118
	
l3687:	
	bcf	(90/8),(90)&7	;volatile
	line	119
	
l3689:	
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	122
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	123
	clrf	(_g_pwmCounter)	;volatile
	line	124
	
l3691:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	125
	
l3693:	
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	126
	
l3695:	
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	127
	
l3697:	
	bcf	(55/8),(55)&7	;volatile
	line	130
	clrf	(System_Init@i)
	line	132
	
l3703:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	133
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	134
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	135
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	136
	
l3705:	
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	130
	
l3707:	
	incf	(System_Init@i),f
	
l3709:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u3901
	goto	u3900
u3901:
	goto	l3703
u3900:
	line	138
	
l3711:	
	clrf	(System_Init@i)
	line	140
	
l3717:	
	movf	(System_Init@i),w
	addlw	low(_g_ledState|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	141
	movf	(System_Init@i),w
	addlw	low(_g_blinkPhase|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	142
	clrc
	rlf	(System_Init@i),w
	addlw	low(_g_blinkTimer|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	138
	
l3719:	
	incf	(System_Init@i),f
	
l3721:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u3911
	goto	u3910
u3911:
	goto	l3717
u3910:
	line	146
	
l359:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
global __ptext2
__ptext2:	;psect for function _uart_init
psect	text2
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_init: []
	line	23
	
l2413:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l482:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
global __ptext3
__ptext3:	;psect for function _AD_Init
psect	text3
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l2407:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
	clrf	(406)^0180h	;volatile
	line	27
	
l2409:	
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l2411:	
	clrf	(150)^080h	;volatile
	line	29
	
l459:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 308 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  bat_mv_long     4   15[BANK2 ] unsigned long 
;;  vx_mv           4   11[BANK2 ] unsigned long 
;;  v               2    9[BANK2 ] unsigned int 
;;  s               1    8[BANK2 ] unsigned char 
;;  pt              4    4[BANK2 ] unsigned long 
;;  vcc_mv          2   19[BANK2 ] unsigned int 
;;  i               1   21[BANK2 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0      22
;;      Temps:          0       8       0       0       0
;;      Totals:         0       8       0       0      22
;;Total ram usage:       30 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	308
global __ptext4
__ptext4:	;psect for function _Print_SystemStatus
psect	text4
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	308
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	313
	
l3891:	
	movlw	low(((STR_4)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	316
	
l3893:	
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	317
	
l3895:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u4231
	goto	u4230
u4231:
	goto	l3901
u4230:
	line	319
	
l3897:	
	movf	(_adresult),w	;volatile
	movwf	(___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@pt+3)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(2+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@pt+2)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@pt+1)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@pt)^0100h

	line	320
	
l3899:	
	movf	(Print_SystemStatus@pt+1)^0100h,w
	movwf	(Print_SystemStatus@vcc_mv+1)^0100h
	movf	(Print_SystemStatus@pt)^0100h,w
	movwf	(Print_SystemStatus@vcc_mv)^0100h
	line	321
	goto	l3903
	line	323
	
l3901:	
	movlw	088h
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@vcc_mv)^0100h
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv)^0100h)+1
	line	325
	
l3903:	
	movlw	low(((STR_5)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	326
	
l3905:	
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	327
	
l3907:	
	movlw	low(((STR_6)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	328
	
l3909:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(_Print_SystemStatus$712+1)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(_Print_SystemStatus$712)^0100h
	
l3911:	
	movf	(_Print_SystemStatus$712+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	(_Print_SystemStatus$712)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	329
	
l3913:	
	movlw	low(((STR_7)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	330
	
l3915:	
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(_Print_SystemStatus$713+1)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(0+(?___lwmod)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(_Print_SystemStatus$713)^0100h
	
l3917:	
	movf	(_Print_SystemStatus$713+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	(_Print_SystemStatus$713)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	331
	
l3919:	
	movlw	low(((STR_8)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	338
	
l3921:	
	bsf	status, 6	;RP1=1, select bank2
	clrf	(Print_SystemStatus@i)^0100h
	line	341
	
l3927:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@i)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@v)^0100h
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)^0100h
	line	342
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@i)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@s)^0100h
	line	349
	
l3929:	
	movlw	low(042h)
	fcall	_uart_send_char
	line	350
	
l3931:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@i)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	351
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	352
	
l3933:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@v+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@v)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	358
	
l3935:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@v)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@v+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___lmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@vx_mv+3)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@vx_mv+2)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(1+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@vx_mv+1)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(0+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@vx_mv)^0100h

	
l3937:	
	movlw	0Ch
u4245:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3)^0100h,f
	rrf	(Print_SystemStatus@vx_mv+2)^0100h,f
	rrf	(Print_SystemStatus@vx_mv+1)^0100h,f
	rrf	(Print_SystemStatus@vx_mv)^0100h,f
	addlw	-1
	skipz
	goto	u4245

	line	359
	
l3939:	
	movf	(Print_SystemStatus@vcc_mv)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_Print_SystemStatus+0)+0)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_Print_SystemStatus+0)+0+1)
	clrf	((??_Print_SystemStatus+0)+0+2)
	clrf	((??_Print_SystemStatus+0)+0+3)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+4)+0)
	movlw	0
	movwf	((??_Print_SystemStatus+4)+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+4)+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+4)+0+3)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vx_mv)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	addwf	(??_Print_SystemStatus+4)+0,f
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vx_mv+1)^0100h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1)^0100h,w
	goto	u4250
	goto	u4251
u4250:
	bcf	status, 6	;RP1=0, select bank0
	addwf	(??_Print_SystemStatus+4)+1,f
u4251:
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vx_mv+2)^0100h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2)^0100h,w
	goto	u4252
	goto	u4253
u4252:
	bcf	status, 6	;RP1=0, select bank0
	addwf	(??_Print_SystemStatus+4)+2,f
u4253:
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vx_mv+3)^0100h,w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	addwf	(??_Print_SystemStatus+4)+3,f
	movf	3+(??_Print_SystemStatus+0)+0,w
	subwf	3+(??_Print_SystemStatus+4)+0,w
	skipz
	goto	u4265
	movf	2+(??_Print_SystemStatus+0)+0,w
	subwf	2+(??_Print_SystemStatus+4)+0,w
	skipz
	goto	u4265
	movf	1+(??_Print_SystemStatus+0)+0,w
	subwf	1+(??_Print_SystemStatus+4)+0,w
	skipz
	goto	u4265
	movf	0+(??_Print_SystemStatus+0)+0,w
	subwf	0+(??_Print_SystemStatus+4)+0,w
u4265:
	skipc
	goto	u4261
	goto	u4260
u4261:
	goto	l3943
u4260:
	line	361
	
l3941:	
	movlw	low(((STR_9)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	362
	goto	l3953
	line	365
	
l3943:	
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vx_mv+3)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___lmul@multiplier+3)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vx_mv+2)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___lmul@multiplier+2)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vx_mv+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___lmul@multiplier+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vx_mv)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___lmul@multiplier)

	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	04h
	movwf	(___lmul@multiplicand+1)
	movlw	087h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@bat_mv_long+3)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@bat_mv_long+2)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(1+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@bat_mv_long+1)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(0+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@bat_mv_long)^0100h

	line	366
	movf	(Print_SystemStatus@vcc_mv)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	02h
	movwf	(___lmul@multiplicand+1)
	movlw	087h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@bat_mv_long+3)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	subwf	(3+(?___lmul)),w
	skipz
	goto	u4275
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@bat_mv_long+2)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	subwf	(2+(?___lmul)),w
	skipz
	goto	u4275
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@bat_mv_long+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	subwf	(1+(?___lmul)),w
	skipz
	goto	u4275
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@bat_mv_long)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	subwf	(0+(?___lmul)),w
u4275:
	skipnc
	goto	u4271
	goto	u4270
u4271:
	goto	l3953
u4270:
	line	368
	
l3945:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Print_SystemStatus+0)+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+3)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___lmul@multiplier)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@vcc_mv+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)
	movlw	0FDh
	movwf	(___lmul@multiplicand+1)
	movlw	079h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(0+(?___lmul)),w
	bsf	status, 6	;RP1=1, select bank2
	addwf	(Print_SystemStatus@bat_mv_long)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_Print_SystemStatus+4)+0+0)
	movlw	0
	skipnc
	movlw	1
	addwf	(1+(?___lmul)),w
	clrf	((??_Print_SystemStatus+4)+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)+0+2),f
	bsf	status, 6	;RP1=1, select bank2
	addwf	(Print_SystemStatus@bat_mv_long+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_Print_SystemStatus+4)+0+1)
	skipnc
	incf	((??_Print_SystemStatus+4)+0+2),f
	movf	(2+(?___lmul)),w
	addwf	((??_Print_SystemStatus+4)+0+2),w
	clrf	((??_Print_SystemStatus+4)+0+3)
	skipnc
	incf	((??_Print_SystemStatus+4)+0+3),f
	bsf	status, 6	;RP1=1, select bank2
	addwf	(Print_SystemStatus@bat_mv_long+2)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_Print_SystemStatus+4)+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)+0+3),f
	movf	(3+(?___lmul)),w
	addwf	((??_Print_SystemStatus+4)+0+3),w
	bsf	status, 6	;RP1=1, select bank2
	addwf	(Print_SystemStatus@bat_mv_long+3)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	((??_Print_SystemStatus+4)+0+3)
	movf	0+(??_Print_SystemStatus+4)+0,w
	addwf	(??_Print_SystemStatus+0)+0,f
	movf	1+(??_Print_SystemStatus+4)+0,w
	skipnc
	incfsz	1+(??_Print_SystemStatus+4)+0,w
	goto	u4280
	goto	u4281
u4280:
	addwf	(??_Print_SystemStatus+0)+1,f
u4281:
	movf	2+(??_Print_SystemStatus+4)+0,w
	skipnc
	incfsz	2+(??_Print_SystemStatus+4)+0,w
	goto	u4282
	goto	u4283
u4282:
	addwf	(??_Print_SystemStatus+0)+2,f
u4283:
	movf	3+(??_Print_SystemStatus+4)+0,w
	skipnc
	incf	3+(??_Print_SystemStatus+4)+0,w
	addwf	(??_Print_SystemStatus+0)+3,f
	movf	3+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@bat_mv_long+3)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(2+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@bat_mv_long+2)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@bat_mv_long+1)^0100h
	bcf	status, 6	;RP1=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(Print_SystemStatus@bat_mv_long)^0100h

	line	369
	
l3947:	
	movlw	low(((STR_10)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	370
	
l3949:	
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@bat_mv_long+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@bat_mv_long)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	371
	
l3951:	
	movlw	low(((STR_11)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	378
	
l3953:	
	movlw	low(020h)
	fcall	_uart_send_char
	line	379
	goto	l3979
	line	381
	
l3955:	
	movlw	low(((STR_12)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3981
	line	382
	
l3957:	
	movlw	low(((STR_13)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3981
	line	383
	
l3959:	
	movlw	low(((STR_14)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3981
	line	384
	
l3961:	
	movlw	low(((STR_15)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3981
	line	385
	
l3963:	
	movlw	low(((STR_16)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3981
	line	386
	
l3965:	
	movlw	low(((STR_17)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3981
	line	387
	
l3967:	
	movlw	low(((STR_18)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3981
	line	388
	
l3969:	
	movlw	low(((STR_19)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3981
	line	389
	
l3971:	
	movlw	low(((STR_20)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3981
	line	390
	
l3973:	
	movlw	low(((STR_21)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3981
	line	391
	
l3975:	
	movlw	low(((STR_22)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l3981
	line	379
	
l3979:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(Print_SystemStatus@s)^0100h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l3955
	xorlw	1^0	; case 1
	skipnz
	goto	l3957
	xorlw	2^1	; case 2
	skipnz
	goto	l3959
	xorlw	3^2	; case 3
	skipnz
	goto	l3961
	xorlw	4^3	; case 4
	skipnz
	goto	l3963
	xorlw	5^4	; case 5
	skipnz
	goto	l3965
	xorlw	6^5	; case 6
	skipnz
	goto	l3967
	xorlw	7^6	; case 7
	skipnz
	goto	l3969
	xorlw	8^7	; case 8
	skipnz
	goto	l3971
	xorlw	9^8	; case 9
	skipnz
	goto	l3973
	goto	l3975
	opt asmopt_pop

	line	338
	
l3981:	
	bsf	status, 6	;RP1=1, select bank2
	incf	(Print_SystemStatus@i)^0100h,f
	
l3983:	
	movf	((Print_SystemStatus@i)^0100h),w
	btfsc	status,2
	goto	u4291
	goto	u4290
u4291:
	goto	l3927
u4290:
	line	394
	
l3985:	
	movlw	low(((STR_23)|8000h))
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	395
	
l433:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 290 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	290
global __ptext5
__ptext5:	;psect for function _Print_NtcTemp
psect	text5
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	290
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	292
	
l3879:	
	movlw	low(((STR_1)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	293
	
l3881:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$710+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$710)
	
l3883:	
	movf	(_Print_NtcTemp$710+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$710),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	294
	
l3885:	
	movlw	low(((STR_2)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	295
	
l3887:	
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	movwf	(_Print_NtcTemp$711+1)
	movf	(0+(?___lwmod)),w
	movwf	(_Print_NtcTemp$711)
	movf	(_Print_NtcTemp$711+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$711),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	296
	
l3889:	
	movlw	low(((STR_3)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	297
	
l410:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_Print_DetectLog

;; *************** function _Print_DetectLog *****************
;; Defined at:
;;		line 401 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	line	401
global __ptext6
__ptext6:	;psect for function _Print_DetectLog
psect	text6
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	401
	global	__size_of_Print_DetectLog
	__size_of_Print_DetectLog	equ	__end_of_Print_DetectLog-_Print_DetectLog
	
_Print_DetectLog:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_DetectLog: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	403
	
l3987:	
	movlw	low(042h)
	fcall	_uart_send_char
	line	404
	
l3989:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_detectLogSlot),w	;volatile
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	406
	
l3991:	
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u4301
	goto	u4300
u4301:
	goto	l3995
u4300:
	line	407
	
l3993:	
	movlw	low(((STR_24)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l439
	line	408
	
l3995:	
		movlw	3
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u4311
	goto	u4310
u4311:
	goto	l439
u4310:
	line	409
	
l3997:	
	movlw	low(((STR_25)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	410
	
l439:	
	return
	opt stack 0
GLOBAL	__end_of_Print_DetectLog
	__end_of_Print_DetectLog:
	signat	_Print_DetectLog,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2   17[BANK0 ] PTR const unsigned char 
;;		 -> STR_33(3), STR_32(7), STR_31(4), STR_30(5), 
;;		 -> STR_29(5), STR_28(11), STR_27(10), STR_26(21), 
;;		 -> STR_25(37), STR_24(33), STR_23(3), STR_22(6), 
;;		 -> STR_21(8), STR_20(6), STR_19(6), STR_18(7), 
;;		 -> STR_17(5), STR_16(5), STR_15(6), STR_14(6), 
;;		 -> STR_13(6), STR_12(7), STR_11(4), STR_10(6), 
;;		 -> STR_9(6), STR_8(4), STR_7(2), STR_6(6), 
;;		 -> STR_5(5), STR_4(29), STR_3(4), STR_2(2), 
;;		 -> STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
global __ptext7
__ptext7:	;psect for function _uart_send_string
psect	text7
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l3593:	
	goto	l3599
	line	65
	
l3595:	
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	fcall	_uart_send_char
	
l3597:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(uart_send_string@str),f
	skipnz
	incf	(uart_send_string@str+1),f
	line	66
# 66 "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
clrwdt ;# 
psect	text7
	line	63
	
l3599:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u3841
	goto	u3840
u3841:
	goto	l3595
u3840:
	line	68
	
l495:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2   21[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6   23[BANK0 ] unsigned char [6]
;;  j               1   30[BANK0 ] unsigned char 
;;  i               1   29[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      10       0       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext8
__ptext8:	;psect for function _uart_send_number
psect	text8
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l3601:	
	clrf	(uart_send_number@i)
	line	84
	
l3603:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u3851
	goto	u3850
u3851:
	goto	l3615
u3850:
	line	86
	
l3605:	
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l499
	line	93
	
l3609:	
	movf	(uart_send_number@i),w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwmod@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank0
	movwf	indf
	
l3611:	
	incf	(uart_send_number@i),f
	line	94
	
l3613:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(uart_send_number@num+1)
	movf	(0+(?___lwdiv)),w
	movwf	(uart_send_number@num)
	line	91
	
l3615:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u3861
	goto	u3860
u3861:
	goto	l3609
u3860:
	line	98
	
l3617:	
	movf	(uart_send_number@i),w
	movwf	(uart_send_number@j)
	
l3619:	
	movf	((uart_send_number@j)),w
	btfss	status,2
	goto	u3871
	goto	u3870
u3871:
	goto	l3623
u3870:
	goto	l499
	line	99
	
l3623:	
	movf	(uart_send_number@j),w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l3625:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decf	(uart_send_number@j),f
	goto	l3619
	line	100
	
l499:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1   15[BANK0 ] unsigned char 
;;  i               1   16[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/A00
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext9
__ptext9:	;psect for function _uart_send_char
psect	text9
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_char: [wreg+status,2+status,0]
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_char@c)
	line	38
	
l3447:	
	bcf	(95/8),(95)&7	;volatile
	line	39
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l3449:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u4887:
decfsz	(??_uart_send_char+0)+0,f
	goto	u4887
	nop2
opt asmopt_pop

	line	41
	
l3451:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(uart_send_char@i)
	line	42
	
l485:	
	line	43
	btfss	(uart_send_char@c),(0)&7
	goto	u3571
	goto	u3570
u3571:
	goto	l487
u3570:
	line	44
	
l3457:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l3459
	line	45
	
l487:	
	line	46
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l3459:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u4897:
decfsz	(??_uart_send_char+0)+0,f
	goto	u4897
	nop2
opt asmopt_pop

	line	48
	
l3461:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rrf	(uart_send_char@c),f
	line	41
	
l3463:	
	incf	(uart_send_char@i),f
	
l3465:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u3581
	goto	u3580
u3581:
	goto	l485
u3580:
	
l486:	
	line	50
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l3467:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u4907:
decfsz	(??_uart_send_char+0)+0,f
	goto	u4907
	nop2
opt asmopt_pop

	line	52
	
l3469:	
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l489:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   14[BANK0 ] unsigned int 
;;  dividend        2   16[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1   18[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   14[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       5       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext10
__ptext10:	;psect for function ___lwmod
psect	text10
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l3535:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u3701
	goto	u3700
u3701:
	goto	l3551
u3700:
	line	14
	
l3537:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l3541
	line	16
	
l3539:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l3541:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u3711
	goto	u3710
u3711:
	goto	l3539
u3710:
	line	20
	
l3543:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u3725
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u3725:
	skipc
	goto	u3721
	goto	u3720
u3721:
	goto	l3547
u3720:
	line	21
	
l3545:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l3547:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l3549:	
	decfsz	(___lwmod@counter),f
	goto	u3731
	goto	u3730
u3731:
	goto	l3543
u3730:
	line	25
	
l3551:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1068:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	_Do_NtcRead

;; *************** function _Do_NtcRead *****************
;; Defined at:
;;		line 281 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Read_Temperature
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	281
global __ptext11
__ptext11:	;psect for function _Do_NtcRead
psect	text11
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	281
	global	__size_of_Do_NtcRead
	__size_of_Do_NtcRead	equ	__end_of_Do_NtcRead-_Do_NtcRead
	
_Do_NtcRead:	
;incstack = 0
	opt	stack 2
; Regs used in _Do_NtcRead: [wreg+status,2+status,0+pclath+cstack]
	line	283
	
l3877:	
	fcall	_Read_Temperature
	line	284
	
l407:	
	return
	opt stack 0
GLOBAL	__end_of_Do_NtcRead
	__end_of_Do_NtcRead:
	signat	_Do_NtcRead,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 23 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   43[BANK0 ] unsigned long 
;;  temp_x10        2   49[BANK0 ] unsigned int 
;;  ntcVal          2   47[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   66[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Do_NtcRead
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	23
global __ptext12
__ptext12:	;psect for function _Read_Temperature
psect	text12
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	23
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 2
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	28
	
l3555:	
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	29
	
l3557:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u3741
	goto	u3740
u3741:
	goto	l3561
u3740:
	goto	l528
	line	32
	
l3561:	
	movf	(_adresult+1),w	;volatile
	movwf	(Read_Temperature@ntcVal+1)
	movf	(_adresult),w	;volatile
	movwf	(Read_Temperature@ntcVal)
	line	33
	movlw	0
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u3751
	goto	u3750
u3751:
	goto	l528
u3750:
	
l3563:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u3761
	goto	u3760
u3761:
	goto	l3565
u3760:
	goto	l528
	line	38
	
l3565:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	010h
	movwf	(___lldiv@divisor+1)
	movlw	0
	movwf	(___lldiv@divisor)

	movf	(Read_Temperature@ntcVal),w
	movwf	((??_Read_Temperature+0)+0)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((??_Read_Temperature+0)+0+1)
	clrf	((??_Read_Temperature+0)+0+2)
	clrf	((??_Read_Temperature+0)+0+3)
	movf	0+(??_Read_Temperature+0)+0,w
	subwf	(___lldiv@divisor),f
	movf	1+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)+0,w
	goto	u3775
	goto	u3776
u3775:
	subwf	(___lldiv@divisor+1),f
u3776:
	movf	2+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)+0,w
	goto	u3777
	goto	u3778
u3777:
	subwf	(___lldiv@divisor+2),f
u3778:
	movf	3+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)+0,w
	goto	u3779
	goto	u3770
u3779:
	subwf	(___lldiv@divisor+3),f
u3770:

	movf	(Read_Temperature@ntcVal),w
	movwf	(___lmul@multiplier)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	027h
	movwf	(___lmul@multiplicand+1)
	movlw	010h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Read_Temperature@rt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Read_Temperature@rt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@rt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@rt)

	line	39
	
l3567:	
		movf	(Read_Temperature@rt+3),w
	btfss	status,2
	goto	u3780
	movf	(Read_Temperature@rt+2),w
	btfss	status,2
	goto	u3780
	movlw	39
	subwf	(Read_Temperature@rt+1),w
	skipz
	goto	u3783
	movlw	16
	subwf	(Read_Temperature@rt),w
	skipz
	goto	u3783
u3783:
	btfss	status,0
	goto	u3781
	goto	u3780

u3781:
	goto	l3573
u3780:
	line	40
	
l3569:	
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l3571:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0F0h
	movwf	((??_Read_Temperature+0)+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+3)
	movf	(Read_Temperature@rt),w
	addwf	(??_Read_Temperature+0)+0,f
	movf	(Read_Temperature@rt+1),w
	skipnc
	incfsz	(Read_Temperature@rt+1),w
	goto	u3790
	goto	u3791
u3790:
	addwf	(??_Read_Temperature+0)+1,f
u3791:
	movf	(Read_Temperature@rt+2),w
	skipnc
	incfsz	(Read_Temperature@rt+2),w
	goto	u3792
	goto	u3793
u3792:
	addwf	(??_Read_Temperature+0)+2,f
u3793:
	movf	(Read_Temperature@rt+3),w
	skipnc
	incf	(Read_Temperature@rt+3),w
	addwf	(??_Read_Temperature+0)+3,f
	movf	3+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+3)
	movf	2+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+2)
	movf	1+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+1)
	movf	0+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier)

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(0+(?___lldiv)),w
	subwf	(Read_Temperature@temp_x10),f
	movf	(1+(?___lldiv)),w
	skipc
	decf	(Read_Temperature@temp_x10+1),f
	subwf	(Read_Temperature@temp_x10+1),f
	goto	l3577
	line	42
	
l3573:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0
	movwf	(___lmul@multiplier+3)
	movlw	0
	movwf	(___lmul@multiplier+2)
	movlw	027h
	movwf	(___lmul@multiplier+1)
	movlw	010h
	movwf	(___lmul@multiplier)

	movf	(Read_Temperature@rt),w
	subwf	(___lmul@multiplier),f
	movf	(Read_Temperature@rt+1),w
	skipc
	incfsz	(Read_Temperature@rt+1),w
	subwf	(___lmul@multiplier+1),f
	movf	(Read_Temperature@rt+2),w
	skipc
	incfsz	(Read_Temperature@rt+2),w
	subwf	(___lmul@multiplier+2),f
	movf	(Read_Temperature@rt+3),w
	skipc
	incfsz	(Read_Temperature@rt+3),w
	subwf	(___lmul@multiplier+3),f
	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10)
	
l3575:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10),f
	skipnc
	incf	(Read_Temperature@temp_x10+1),f
	line	43
	
l3577:	
	movlw	0
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipnc
	goto	u3801
	goto	u3800
u3801:
	goto	l534
u3800:
	
l3579:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l534:	
	line	44
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipc
	goto	u3811
	goto	u3810
u3811:
	goto	l535
u3810:
	
l3581:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)
	movlw	02h
	movwf	((Read_Temperature@temp_x10))+1
	
l535:	
	line	47
	movf	(Read_Temperature@temp_x10+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_temperature+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(Read_Temperature@temp_x10),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_temperature)^080h
	line	48
	
l3583:	
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u3821
	goto	u3820
u3821:
	goto	l3587
u3820:
	line	49
	
l3585:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	incf	(_g_tempProtect)^080h,f
	goto	l528
	line	50
	
l3587:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u3831
	goto	u3830
u3831:
	goto	l528
u3830:
	line	51
	
l3589:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	line	54
	
l528:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   14[BANK0 ] unsigned int 
;;  dividend        2   16[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2   19[BANK0 ] unsigned int 
;;  counter         1   18[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   14[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       7       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext13
__ptext13:	;psect for function ___lwdiv
psect	text13
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l3509:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l3511:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u3661
	goto	u3660
u3661:
	goto	l3531
u3660:
	line	16
	
l3513:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l3517
	line	18
	
l3515:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l3517:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u3671
	goto	u3670
u3671:
	goto	l3515
u3670:
	line	22
	
l3519:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l3521:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u3685
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u3685:
	skipc
	goto	u3681
	goto	u3680
u3681:
	goto	l3527
u3680:
	line	24
	
l3523:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l3525:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l3527:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l3529:	
	decfsz	(___lwdiv@counter),f
	goto	u3691
	goto	u3690
u3691:
	goto	l3519
u3690:
	line	30
	
l3531:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l1058:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4   14[BANK0 ] unsigned long 
;;  multiplicand    4   18[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4   22[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4   14[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext14
__ptext14:	;psect for function ___lmul
psect	text14
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l3471:	
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l730:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u3591
	goto	u3590
u3591:
	goto	l3475
u3590:
	line	122
	
l3473:	
	movf	(___lmul@multiplicand),w
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3601
	addwf	(___lmul@product+1),f
u3601:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3602
	addwf	(___lmul@product+2),f
u3602:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3603
	addwf	(___lmul@product+3),f
u3603:

	line	123
	
l3475:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l3477:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u3611
	goto	u3610
u3611:
	goto	l730
u3610:
	line	128
	
l3479:	
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l733:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4   26[BANK0 ] unsigned long 
;;  dividend        4   30[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   34[BANK0 ] unsigned long 
;;  counter         1   38[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4   26[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      13       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext15
__ptext15:	;psect for function ___lldiv
psect	text15
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l3483:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l3485:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u3621
	goto	u3620
u3621:
	goto	l3505
u3620:
	line	16
	
l3487:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l3491
	line	18
	
l3489:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l3491:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u3631
	goto	u3630
u3631:
	goto	l3489
u3630:
	line	22
	
l3493:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l3495:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u3645
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u3645
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u3645
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u3645:
	skipc
	goto	u3641
	goto	u3640
u3641:
	goto	l3501
u3640:
	line	24
	
l3497:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l3499:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l3501:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l3503:	
	decfsz	(___lldiv@counter),f
	goto	u3651
	goto	u3650
u3651:
	goto	l3493
u3650:
	line	30
	
l3505:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l1005:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_Do_AdcSample

;; *************** function _Do_AdcSample *****************
;; Defined at:
;;		line 262 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  ch              1   32[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=0
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	262
global __ptext16
__ptext16:	;psect for function _Do_AdcSample
psect	text16
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	262
	global	__size_of_Do_AdcSample
	__size_of_Do_AdcSample	equ	__end_of_Do_AdcSample-_Do_AdcSample
	
_Do_AdcSample:	
;incstack = 0
	opt	stack 3
; Regs used in _Do_AdcSample: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	264
	
l3865:	
	movf	(_g_scanIndex),w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(Do_AdcSample@ch)
	line	265
	
l3867:	
	clrf	(ADC_Sample@adldo)
	movf	(Do_AdcSample@ch),w
	fcall	_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	267
	
l3869:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u4221
	goto	u4220
u4221:
	goto	l3873
u4220:
	line	268
	
l3871:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	movf	(_adresult),w	;volatile
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(_adresult+1),w	;volatile
	movwf	indf
	goto	l3875
	line	270
	
l3873:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	272
	
l3875:	
	movlw	low(01h)
	movwf	(_g_scanPhase)	;volatile
	line	273
	
l404:	
	return
	opt stack 0
GLOBAL	__end_of_Do_AdcSample
	__end_of_Do_AdcSample:
	signat	_Do_AdcSample,89
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1   14[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1   20[BANK0 ] unsigned char 
;;  j               1   19[BANK0 ] unsigned char 
;;  adsum           4   22[BANK0 ] volatile unsigned long 
;;  ad_temp         2   30[BANK0 ] volatile unsigned int 
;;  admax           2   28[BANK0 ] volatile unsigned int 
;;  admin           2   26[BANK0 ] volatile unsigned int 
;;  i               1   21[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      18       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=0
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext17
__ptext17:	;psect for function _ADC_Sample
psect	text17
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
	movwf	(ADC_Sample@adch)
	line	51
	
l3381:	
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	52
	
l3383:	
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	53
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	54
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	58
	
l3385:	
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u3421
	goto	u3420
u3421:
	goto	l3391
u3420:
	
l3387:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u3431
	goto	u3430
u3431:
	goto	l3391
u3430:
	line	60
	
l3389:	
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	61
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u4917:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u4917
	nop
opt asmopt_pop

	line	62
	goto	l3393
	line	64
	
l3391:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	67
	
l3393:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(ADC_Sample@adch),(4)&7
	goto	u3441
	goto	u3440
u3441:
	goto	l464
u3440:
	line	69
	
l3395:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l3397:	
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(ADC_Sample@adch),f
	line	71
	goto	l3399
	line	72
	
l464:	
	line	73
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l3399:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@i)
	line	79
	
l3405:	
	movf	(ADC_Sample@adch),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u3455:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u3455
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l3407:	
	opt asmopt_push
opt asmopt_off
	movlw	5
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u4927:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u4927
	nop2
opt asmopt_pop

	line	81
	
l3409:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l3411:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	85
	goto	l468
	
l469:	
	line	87
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u3461
	goto	u3460
u3461:
	goto	l468
u3460:
	line	89
	
l3413:	
	movlw	low(0)
	goto	l471
	line	90
	
l468:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u3471
	goto	u3470
u3471:
	goto	l469
u3470:
	line	93
	
l3417:	
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
l3419:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
l3421:	
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u3481
	goto	u3480
u3481:
	goto	l3425
u3480:
	line	98
	
l3423:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	99
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	100
	goto	l474
	line	102
	
l3425:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u3495
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u3495:
	skipnc
	goto	u3491
	goto	u3490
u3491:
	goto	l3429
u3490:
	line	103
	
l3427:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	l474
	line	105
	
l3429:	
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u3505
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u3505:
	skipnc
	goto	u3501
	goto	u3500
u3501:
	goto	l474
u3500:
	line	106
	
l3431:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	108
	
l474:	
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3511
	addwf	(ADC_Sample@adsum+1),f	;volatile
u3511:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3512
	addwf	(ADC_Sample@adsum+2),f	;volatile
u3512:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3513
	addwf	(ADC_Sample@adsum+3),f	;volatile
u3513:

	line	76
	
l3433:	
	incf	(ADC_Sample@i),f
	
l3435:	
	movlw	low(022h)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u3521
	goto	u3520
u3521:
	goto	l3405
u3520:
	line	112
	
l3437:	
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u3535
	goto	u3536
u3535:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u3536:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u3537
	goto	u3538
u3537:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u3538:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u3539
	goto	u3530
u3539:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u3530:

	line	113
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u3545
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u3545
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u3545
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u3545:
	skipc
	goto	u3541
	goto	u3540
u3541:
	goto	l478
u3540:
	line	114
	
l3439:	
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u3555
	goto	u3556
u3555:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u3556:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u3557
	goto	u3558
u3557:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u3558:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u3559
	goto	u3550
u3559:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u3550:

	goto	l3441
	line	115
	
l478:	
	line	116
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	118
	
l3441:	
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u3565:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u3560:
	addlw	-1
	skipz
	goto	u3565
	movf	1+(??_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
l3443:	
	movlw	low(0A5h)
	line	120
	
l471:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_ChargeProcess_Slot

;; *************** function _ChargeProcess_Slot *****************
;; Defined at:
;;		line 93 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   31[BANK0 ] unsigned char 
;;  v_start         2   23[BANK0 ] unsigned int 
;;  rise            2   19[BANK0 ] unsigned int 
;;  v_before        2   21[BANK0 ] unsigned int 
;;  delta           2   17[BANK0 ] unsigned int 
;;  v               2   32[BANK0 ] unsigned int 
;;  ct              2   29[BANK0 ] unsigned int 
;;  tick            2    0        unsigned int 
;;  ty              1   28[BANK0 ] unsigned char 
;;  st              1   27[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      17       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      17       0       0       0
;;Total ram usage:       17 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Detect_BatteryType
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=0
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	93
global __ptext18
__ptext18:	;psect for function _ChargeProcess_Slot
psect	text18
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	93
	global	__size_of_ChargeProcess_Slot
	__size_of_ChargeProcess_Slot	equ	__end_of_ChargeProcess_Slot-_ChargeProcess_Slot
	
_ChargeProcess_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _ChargeProcess_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	movwf	(ChargeProcess_Slot@idx)
	line	97
	
l3999:	
	line	99
	
l4001:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(ChargeProcess_Slot@st)
	
l4003:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(ChargeProcess_Slot@ty)
	
l4005:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(ChargeProcess_Slot@v)
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v+1)
	
l4007:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(ChargeProcess_Slot@ct)
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@ct+1)
	goto	l4225
	line	104
	
l4009:	
	clrf	(ChargeProcess_Slot@ct)
	clrf	(ChargeProcess_Slot@ct+1)
	line	105
	
l4011:	
	clrf	(ChargeProcess_Slot@st)
	incf	(ChargeProcess_Slot@st),f
	line	106
	goto	l4227
	line	109
	
l4013:	
	incf	(ChargeProcess_Slot@ct),f
	skipnz
	incf	(ChargeProcess_Slot@ct+1),f
	line	110
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1),w
	movlw	0C8h
	skipnz
	subwf	(ChargeProcess_Slot@ct),w
	skipnc
	goto	u4321
	goto	u4320
u4321:
	goto	l4017
u4320:
	goto	l4227
	line	113
	
l4017:	
	movf	(ChargeProcess_Slot@v+1),w
	movwf	(Detect_BatteryType@voltage+1)
	movf	(ChargeProcess_Slot@v),w
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	movwf	(ChargeProcess_Slot@ty)
	line	115
	
l4019:	
		movlw	5
	xorwf	((ChargeProcess_Slot@ty)),w
	btfss	status,2
	goto	u4331
	goto	u4330
u4331:
	goto	l4027
u4330:
	line	117
	
l4021:	
	clrc
	rlf	(ChargeProcess_Slot@idx),w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v),w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1),w
	movwf	indf
	line	118
	
l4023:	
	movlw	low(08h)
	movwf	(ChargeProcess_Slot@st)
	line	119
	
l4025:	
	clrf	(ChargeProcess_Slot@ct)
	clrf	(ChargeProcess_Slot@ct+1)
	line	120
	goto	l4067
	line	121
	
l4027:	
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)),w
	btfsc	status,2
	goto	u4341
	goto	u4340
u4341:
	goto	l4033
u4340:
	
l4029:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)),w
	btfsc	status,2
	goto	u4351
	goto	u4350
u4351:
	goto	l4033
u4350:
	
l4031:	
	movf	((ChargeProcess_Slot@ty)),w
	btfss	status,2
	goto	u4361
	goto	u4360
u4361:
	goto	l4043
u4360:
	line	123
	
l4033:	
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)
	line	124
	
l4035:	
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)),w
	btfsc	status,2
	goto	u4371
	goto	u4370
u4371:
	goto	l4039
u4370:
	
l4037:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)),w
	btfss	status,2
	goto	u4381
	goto	u4380
u4381:
	goto	l4067
u4380:
	line	126
	
l4039:	
	movf	(ChargeProcess_Slot@idx),w
	movwf	(_g_detectLogSlot)	;volatile
	line	127
	movf	(ChargeProcess_Slot@ty),w
	movwf	(_g_detectLogType)	;volatile
	line	128
	
l4041:	
	bsf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	goto	l4067
	line	133
	
l4043:	
	movlw	09h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	036h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u4391
	goto	u4390
u4391:
	goto	l4049
u4390:
	line	135
	
l4045:	
	movlw	low(02h)
	movwf	(ChargeProcess_Slot@st)
	goto	l4025
	line	138
	
l4049:	
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	050h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u4401
	goto	u4400
u4401:
	goto	l4055
u4400:
	line	140
	
l4051:	
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@st)
	goto	l4025
	line	143
	
l4055:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	021h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4411
	goto	u4410
u4411:
	goto	l4061
u4410:
	line	145
	
l4057:	
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)
	goto	l4025
	line	150
	
l4061:	
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)
	line	151
	
l4063:	
	clrf	(ChargeProcess_Slot@ct)
	clrf	(ChargeProcess_Slot@ct+1)
	line	152
	
l4065:	
	movf	(ChargeProcess_Slot@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	156
	
l4067:	
	movf	(ChargeProcess_Slot@idx),w
	movwf	(_g_dbgSlot)	;volatile
	line	157
	
l4069:	
	movf	(ChargeProcess_Slot@st),w
	movwf	(_g_dbgNewState)	;volatile
	line	158
	
l4071:	
	movf	(ChargeProcess_Slot@ty),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_dbgNewType)^080h	;volatile
	line	159
	
l4073:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(ChargeProcess_Slot@v+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_dbgVoltage+1)^080h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(ChargeProcess_Slot@v),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_dbgVoltage)^080h	;volatile
	line	160
	
l4075:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	161
	goto	l4227
	line	164
	
l4077:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4421
	goto	u4420
u4421:
	goto	l4081
u4420:
	line	166
	
l4079:	
	clrf	(ChargeProcess_Slot@ty)
	line	167
	clrf	(ChargeProcess_Slot@st)
	line	168
	goto	l4227
	line	170
	
l4081:	
	incf	(ChargeProcess_Slot@ct),f
	skipnz
	incf	(ChargeProcess_Slot@ct+1),f
	line	171
	movlw	0
	subwf	(ChargeProcess_Slot@ct+1),w
	movlw	03h
	skipnz
	subwf	(ChargeProcess_Slot@ct),w
	skipnc
	goto	u4431
	goto	u4430
u4431:
	goto	l4085
u4430:
	goto	l4227
	line	175
	
l4085:	
	clrc
	rlf	(ChargeProcess_Slot@idx),w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_before)
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_before+1)
	line	177
	
l4087:	
	movf	(ChargeProcess_Slot@v_before+1),w
	subwf	(ChargeProcess_Slot@v+1),w
	skipz
	goto	u4445
	movf	(ChargeProcess_Slot@v_before),w
	subwf	(ChargeProcess_Slot@v),w
u4445:
	skipnc
	goto	u4441
	goto	u4440
u4441:
	goto	l4091
u4440:
	
l4089:	
	movf	(ChargeProcess_Slot@v_before+1),w
	movwf	(ChargeProcess_Slot@delta+1)
	movf	(ChargeProcess_Slot@v_before),w
	movwf	(ChargeProcess_Slot@delta)
	movf	(ChargeProcess_Slot@v),w
	subwf	(ChargeProcess_Slot@delta),f
	movf	(ChargeProcess_Slot@v+1),w
	skipc
	decf	(ChargeProcess_Slot@delta+1),f
	subwf	(ChargeProcess_Slot@delta+1),f
	goto	l4093
	line	178
	
l4091:	
	clrf	(ChargeProcess_Slot@delta)
	clrf	(ChargeProcess_Slot@delta+1)
	line	180
	
l4093:	
	movlw	0
	subwf	(ChargeProcess_Slot@delta+1),w
	movlw	051h
	skipnz
	subwf	(ChargeProcess_Slot@delta),w
	skipc
	goto	u4451
	goto	u4450
u4451:
	goto	l4099
u4450:
	line	182
	
l4095:	
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@ty)
	line	183
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)
	line	184
	movf	(ChargeProcess_Slot@idx),w
	movwf	(_g_detectLogSlot)	;volatile
	line	185
	movlw	low(03h)
	movwf	(_g_detectLogType)	;volatile
	line	186
	
l4097:	
	bsf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	line	187
	goto	l4227
	line	190
	
l4099:	
	clrc
	rlf	(ChargeProcess_Slot@idx),w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v),w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1),w
	movwf	indf
	line	191
	
l4101:	
	movlw	low(09h)
	movwf	(ChargeProcess_Slot@st)
	line	192
	
l4103:	
	clrf	(ChargeProcess_Slot@ct)
	clrf	(ChargeProcess_Slot@ct+1)
	goto	l4227
	line	198
	
l4105:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4461
	goto	u4460
u4461:
	goto	l4109
u4460:
	goto	l4079
	line	204
	
l4109:	
	incf	(ChargeProcess_Slot@ct),f
	skipnz
	incf	(ChargeProcess_Slot@ct+1),f
	line	205
	movlw	0Bh
	subwf	(ChargeProcess_Slot@ct+1),w
	movlw	0B8h
	skipnz
	subwf	(ChargeProcess_Slot@ct),w
	skipnc
	goto	u4471
	goto	u4470
u4471:
	goto	l4121
u4470:
	line	207
	
l4111:	
	movlw	0Ch
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	085h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4481
	goto	u4480
u4481:
	goto	l4227
u4480:
	line	209
	
l4113:	
	clrf	(ChargeProcess_Slot@ty)
	incf	(ChargeProcess_Slot@ty),f
	line	210
	
l4115:	
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)
	line	211
	
l4117:	
	clrf	(ChargeProcess_Slot@ct)
	clrf	(ChargeProcess_Slot@ct+1)
	line	212
	
l4119:	
	movf	(ChargeProcess_Slot@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l4227
	line	218
	
l4121:	
	clrc
	rlf	(ChargeProcess_Slot@idx),w
	addlw	low(_g_impRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_start)
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_start+1)
	line	220
	
l4123:	
	movf	(ChargeProcess_Slot@v+1),w
	subwf	(ChargeProcess_Slot@v_start+1),w
	skipz
	goto	u4495
	movf	(ChargeProcess_Slot@v),w
	subwf	(ChargeProcess_Slot@v_start),w
u4495:
	skipnc
	goto	u4491
	goto	u4490
u4491:
	goto	l4127
u4490:
	
l4125:	
	movf	(ChargeProcess_Slot@v+1),w
	movwf	(ChargeProcess_Slot@rise+1)
	movf	(ChargeProcess_Slot@v),w
	movwf	(ChargeProcess_Slot@rise)
	movf	(ChargeProcess_Slot@v_start),w
	subwf	(ChargeProcess_Slot@rise),f
	movf	(ChargeProcess_Slot@v_start+1),w
	skipc
	decf	(ChargeProcess_Slot@rise+1),f
	subwf	(ChargeProcess_Slot@rise+1),f
	goto	l4129
	line	221
	
l4127:	
	clrf	(ChargeProcess_Slot@rise)
	clrf	(ChargeProcess_Slot@rise+1)
	line	223
	
l4129:	
	movlw	0
	subwf	(ChargeProcess_Slot@rise+1),w
	movlw	014h
	skipnz
	subwf	(ChargeProcess_Slot@rise),w
	skipc
	goto	u4501
	goto	u4500
u4501:
	goto	l4141
u4500:
	
l4131:	
	movlw	0Ch
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	085h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4511
	goto	u4510
u4511:
	goto	l4141
u4510:
	goto	l4113
	line	232
	
l4141:	
	movlw	low(02h)
	movwf	(ChargeProcess_Slot@ty)
	line	233
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)
	line	234
	movf	(ChargeProcess_Slot@idx),w
	movwf	(_g_detectLogSlot)	;volatile
	line	235
	movlw	low(02h)
	movwf	(_g_detectLogType)	;volatile
	goto	l4097
	line	242
	
l4145:	
	incf	(ChargeProcess_Slot@ct),f
	skipnz
	incf	(ChargeProcess_Slot@ct+1),f
	line	243
	movlw	017h
	subwf	(ChargeProcess_Slot@ct+1),w
	movlw	071h
	skipnz
	subwf	(ChargeProcess_Slot@ct),w
	skipc
	goto	u4521
	goto	u4520
u4521:
	goto	l4149
u4520:
	line	245
	
l4147:	
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)
	line	246
	goto	l4227
	line	248
	
l4149:	
	movlw	09h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	036h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4531
	goto	u4530
u4531:
	goto	l4155
u4530:
	line	250
	
l4151:	
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@st)
	goto	l4103
	line	254
	
l4155:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	05Ah
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4541
	goto	u4540
u4541:
	goto	l4227
u4540:
	goto	l4147
	line	262
	
l4159:	
	incf	(ChargeProcess_Slot@ct),f
	skipnz
	incf	(ChargeProcess_Slot@ct+1),f
	line	263
	movlw	075h
	subwf	(ChargeProcess_Slot@ct+1),w
	movlw	031h
	skipnz
	subwf	(ChargeProcess_Slot@ct),w
	skipc
	goto	u4551
	goto	u4550
u4551:
	goto	l4163
u4550:
	goto	l4147
	line	268
	
l4163:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	05Ah
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4561
	goto	u4560
u4561:
	goto	l4167
u4560:
	goto	l4147
	line	273
	
l4167:	
	movlw	0Bh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	0B1h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4571
	goto	u4570
u4571:
	goto	l4227
u4570:
	goto	l4115
	line	282
	
l4175:	
	incf	(ChargeProcess_Slot@ct),f
	skipnz
	incf	(ChargeProcess_Slot@ct+1),f
	line	283
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1),w
	movlw	060h
	skipnz
	subwf	(ChargeProcess_Slot@ct),w
	skipc
	goto	u4581
	goto	u4580
u4581:
	goto	l4181
u4580:
	line	285
	
l4177:	
	movlw	060h
	subwf	(ChargeProcess_Slot@ct),f
	movlw	0EAh
	skipc
	decf	(ChargeProcess_Slot@ct+1),f
	subwf	(ChargeProcess_Slot@ct+1),f
	line	286
	
l4179:	
	movf	(ChargeProcess_Slot@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	288
	
l4181:	
	movf	(ChargeProcess_Slot@idx),w
	addlw	low(_g_ccBlocks|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(012h)
	bcf	status, 7	;select IRP bank1
	subwf	indf,w
	skipc
	goto	u4591
	goto	u4590
u4591:
	goto	l4185
u4590:
	goto	l4147
	line	293
	
l4185:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	05Ah
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4601
	goto	u4600
u4601:
	goto	l4189
u4600:
	goto	l4147
	line	298
	
l4189:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	021h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4611
	goto	u4610
u4611:
	goto	l4227
u4610:
	line	300
	
l4191:	
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)
	goto	l4103
	line	306
	
l4195:	
	incf	(ChargeProcess_Slot@ct),f
	skipnz
	incf	(ChargeProcess_Slot@ct+1),f
	line	307
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1),w
	movlw	061h
	skipnz
	subwf	(ChargeProcess_Slot@ct),w
	skipc
	goto	u4621
	goto	u4620
u4621:
	goto	l4227
u4620:
	line	308
	
l4197:	
	movlw	low(06h)
	movwf	(ChargeProcess_Slot@st)
	goto	l4227
	line	312
	
l4199:	
	movlw	0Dh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	017h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u4631
	goto	u4630
u4631:
	goto	l4227
u4630:
	line	314
	
l4201:	
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)
	goto	l4103
	line	320
	
l4205:	
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)),w
	btfsc	status,2
	goto	u4641
	goto	u4640
u4641:
	goto	l4209
u4640:
	
l4207:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)),w
	btfss	status,2
	goto	u4651
	goto	u4650
u4651:
	goto	l4213
u4650:
	line	322
	
l4209:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4661
	goto	u4660
u4661:
	goto	l4227
u4660:
	line	324
	
l4211:	
	clrf	(ChargeProcess_Slot@ty)
	line	325
	clrf	(ChargeProcess_Slot@st)
	line	326
	clrf	(ChargeProcess_Slot@ct)
	clrf	(ChargeProcess_Slot@ct+1)
	goto	l4227
	line	330
	
l4213:	
	movlw	09h
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	036h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipc
	goto	u4671
	goto	u4670
u4671:
	goto	l4227
u4670:
	
l4215:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1),w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v),w
	skipnc
	goto	u4681
	goto	u4680
u4681:
	goto	l4227
u4680:
	line	332
	
l4217:	
	clrf	(ChargeProcess_Slot@st)
	incf	(ChargeProcess_Slot@st),f
	goto	l4103
	line	338
	
l4221:	
	clrf	(ChargeProcess_Slot@st)
	line	339
	goto	l4227
	line	101
	
l4225:	
	movf	(ChargeProcess_Slot@st),w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l4009
	xorlw	1^0	; case 1
	skipnz
	goto	l4013
	xorlw	2^1	; case 2
	skipnz
	goto	l4145
	xorlw	3^2	; case 3
	skipnz
	goto	l4159
	xorlw	4^3	; case 4
	skipnz
	goto	l4175
	xorlw	5^4	; case 5
	skipnz
	goto	l4195
	xorlw	6^5	; case 6
	skipnz
	goto	l4199
	xorlw	7^6	; case 7
	skipnz
	goto	l4205
	xorlw	8^7	; case 8
	skipnz
	goto	l4077
	xorlw	9^8	; case 9
	skipnz
	goto	l4105
	goto	l4221
	opt asmopt_pop

	line	342
	
l4227:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@st),w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@ty),w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v),w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1),w
	movwf	indf
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(ChargeProcess_Slot@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@ct),w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@ct+1),w
	movwf	indf
	line	343
	
l616:	
	return
	opt stack 0
GLOBAL	__end_of_ChargeProcess_Slot
	__end_of_ChargeProcess_Slot:
	signat	_ChargeProcess_Slot,4217
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1   14[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1   16[BANK0 ] unsigned char 
;;  product         1   15[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 100/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_main
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext19
__ptext19:	;psect for function ___bmul
psect	text19
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___bmul: [wreg+status,2+status,0]
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplier)
	line	6
	
l3629:	
	clrf	(___bmul@product)
	line	43
	
l3631:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u3881
	goto	u3880
u3881:
	goto	l3635
u3880:
	line	44
	
l3633:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l3635:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l3637:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u3891
	goto	u3890
u3891:
	goto	l3631
u3890:
	line	50
	
l3639:	
	movf	(___bmul@product),w
	line	51
	
l739:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 56 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2   14[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	56
global __ptext20
__ptext20:	;psect for function _Detect_BatteryType
psect	text20
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	56
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	58
	
l2489:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2151
	goto	u2150
u2151:
	goto	l2495
u2150:
	line	59
	
l2491:	
	movlw	low(0)
	goto	l542
	line	60
	
l2495:	
	movlw	09h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0Ah
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2161
	goto	u2160
u2161:
	goto	l2501
u2160:
	goto	l2491
	line	64
	
l2501:	
	movlw	0Bh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2171
	goto	u2170
u2171:
	goto	l2509
u2170:
	
l2503:	
	movlw	0Ch
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	085h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2181
	goto	u2180
u2181:
	goto	l2509
u2180:
	line	65
	
l2505:	
	movlw	low(05h)
	goto	l542
	line	68
	
l2509:	
	movlw	0Ah
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	050h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2191
	goto	u2190
u2191:
	goto	l2517
u2190:
	
l2511:	
	movlw	0Dh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	022h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2201
	goto	u2200
u2201:
	goto	l2517
u2200:
	line	69
	
l2513:	
	movlw	low(01h)
	goto	l542
	line	70
	
l2517:	
	movlw	0Dh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	022h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2211
	goto	u2210
u2211:
	goto	l2525
u2210:
	
l2519:	
	movlw	0Dh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	05Ah
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2221
	goto	u2220
u2221:
	goto	l2525
u2220:
	goto	l2513
	line	72
	
l2525:	
	movlw	0Dh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	05Ah
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2231
	goto	u2230
u2231:
	goto	l2533
u2230:
	
l2527:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2241
	goto	u2240
u2241:
	goto	l2533
u2240:
	goto	l2513
	line	74
	
l2533:	
	movlw	09h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0Ah
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u2251
	goto	u2250
u2251:
	goto	l2491
u2250:
	
l2535:	
	movlw	0Ah
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	050h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u2261
	goto	u2260
u2261:
	goto	l2491
u2260:
	goto	l2513
	line	78
	
l542:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 158 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_CCCV_Control
;;		_Charging_Control
;;		_Led_BlinkProcess
;;		_PowerOnLedSequence
;;		_Update_LED_Slot
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	158
global __ptext21
__ptext21:	;psect for function _Isr_Timer
psect	text21
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	158
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 2
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	btemp+1,w
	movwf	(??_Isr_Timer+3)
	ljmp	_Isr_Timer
psect	text21
	line	161
	
i1l4229:	
	btfss	(90/8),(90)&7	;volatile
	goto	u469_21
	goto	u469_20
u469_21:
	goto	i1l369
u469_20:
	line	163
	
i1l4231:	
	bcf	(90/8),(90)&7	;volatile
	line	164
	
i1l4233:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	165
# 165 "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text21
	line	168
	
i1l4235:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	169
	
i1l4237:	
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u470_21
	goto	u470_20
u470_21:
	goto	i1l4241
u470_20:
	line	170
	
i1l4239:	
	clrf	(_g_pwmCounter)	;volatile
	line	173
	
i1l4241:	
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u471_21
	goto	u471_20
u471_21:
	goto	i1l366
u471_20:
	
i1l4243:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u472_21
	goto	u472_20
u472_21:
	goto	i1l366
u472_20:
	line	174
	
i1l4245:	
	bsf	(55/8),(55)&7	;volatile
	goto	i1l4247
	line	175
	
i1l366:	
	line	176
	bcf	(55/8),(55)&7	;volatile
	line	179
	
i1l4247:	
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u473_21
	goto	u473_20
u473_21:
	goto	i1l4305
u473_20:
	line	181
	
i1l4249:	
	fcall	_PowerOnLedSequence
	goto	i1l369
	line	188
	
i1l371:	
	line	190
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u474_21
	goto	u474_20
u474_21:
	goto	i1l369
u474_20:
	
i1l4253:	
	btfsc	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u475_21
	goto	u475_20
u475_21:
	goto	i1l369
u475_20:
	goto	i1l4257
	line	192
	
i1l375:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l388
	
i1l377:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l388
	
i1l378:	
	bsf	(51/8),(51)&7	;volatile
	goto	i1l388
	
i1l379:	
	bsf	(50/8),(50)&7	;volatile
	goto	i1l388
	
i1l380:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l388
	
i1l381:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l388
	
i1l382:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l388
	
i1l383:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l388
	
i1l384:	
	bsf	(48/8),(48)&7	;volatile
	goto	i1l388
	
i1l385:	
	bsf	(49/8),(49)&7	;volatile
	goto	i1l388
	
i1l386:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l388
	
i1l387:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l388
	
i1l4257:	
	movf	(_g_scanIndex),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l375
	xorlw	1^0	; case 1
	skipnz
	goto	i1l377
	xorlw	2^1	; case 2
	skipnz
	goto	i1l378
	xorlw	3^2	; case 3
	skipnz
	goto	i1l379
	xorlw	4^3	; case 4
	skipnz
	goto	i1l380
	xorlw	5^4	; case 5
	skipnz
	goto	i1l381
	xorlw	6^5	; case 6
	skipnz
	goto	i1l382
	xorlw	7^6	; case 7
	skipnz
	goto	i1l383
	xorlw	8^7	; case 8
	skipnz
	goto	i1l384
	xorlw	9^8	; case 9
	skipnz
	goto	i1l385
	xorlw	10^9	; case 10
	skipnz
	goto	i1l386
	xorlw	11^10	; case 11
	skipnz
	goto	i1l387
	goto	i1l388
	opt asmopt_pop

	
i1l388:	
	line	193
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	i1l369
	line	199
	
i1l4259:	
	movf	(_g_scanIndex),w	;volatile
	fcall	_Update_LED_Slot
	line	201
	
i1l4261:	
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_scanPhase)	;volatile
	line	202
	goto	i1l369
	line	205
	
i1l4263:	
	movf	((_g_scanIndex)),w	;volatile
	btfss	status,2
	goto	u476_21
	goto	u476_20
u476_21:
	goto	i1l4297
u476_20:
	line	207
	
i1l4265:	
	fcall	_Charging_Control
	line	208
	
i1l4267:	
	fcall	_CCCV_Control
	line	209
	
i1l4269:	
	fcall	_Led_BlinkProcess
	line	213
	
i1l4271:	
	bcf	status, 5	;RP0=0, select bank0
	movf	((_g_tempPhase)),w	;volatile
	btfss	status,2
	goto	u477_21
	goto	u477_20
u477_21:
	goto	i1l4283
u477_20:
	line	215
	
i1l4273:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_tempReadRoundCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1)^080h,f	;volatile
	line	216
	
i1l4275:	
	movlw	0
	subwf	(_g_tempReadRoundCnt+1)^080h,w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt)^080h,w	;volatile
	skipc
	goto	u478_21
	goto	u478_20
u478_21:
	goto	i1l4291
u478_20:
	line	218
	
i1l4277:	
	clrf	(_g_tempReadRoundCnt)^080h	;volatile
	clrf	(_g_tempReadRoundCnt+1)^080h	;volatile
	line	219
	
i1l4279:	
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_tempPhase)	;volatile
	line	220
	
i1l4281:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	goto	i1l4291
	line	225
	
i1l4283:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_tempSettleCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1)^080h,f	;volatile
	line	226
	
i1l4285:	
	movlw	0
	subwf	(_g_tempSettleCnt+1)^080h,w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt)^080h,w	;volatile
	skipc
	goto	u479_21
	goto	u479_20
u479_21:
	goto	i1l4291
u479_20:
	line	228
	
i1l4287:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	229
	
i1l4289:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	line	230
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_tempPhase)	;volatile
	line	236
	
i1l4291:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_printTick)^080h,f	;volatile
	skipnz
	incf	(_g_printTick+1)^080h,f	;volatile
	movlw	0
	subwf	((_g_printTick+1)^080h),w	;volatile
	movlw	064h
	skipnz
	subwf	((_g_printTick)^080h),w	;volatile
	skipc
	goto	u480_21
	goto	u480_20
u480_21:
	goto	i1l4297
u480_20:
	line	238
	
i1l4293:	
	clrf	(_g_printTick)^080h	;volatile
	clrf	(_g_printTick+1)^080h	;volatile
	line	239
	
i1l4295:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	244
	
i1l4297:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	incf	(_g_scanIndex),f	;volatile
	subwf	((_g_scanIndex)),w	;volatile
	skipc
	goto	u481_21
	goto	u481_20
u481_21:
	goto	i1l398
u481_20:
	line	245
	
i1l4299:	
	clrf	(_g_scanIndex)	;volatile
	
i1l398:	
	line	246
	clrf	(_g_scanPhase)	;volatile
	line	247
	goto	i1l369
	line	186
	
i1l4305:	
	movf	(_g_scanPhase),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 2
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           17     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l371
	xorlw	1^0	; case 1
	skipnz
	goto	i1l4259
	xorlw	2^1	; case 2
	skipnz
	goto	i1l4263
	goto	i1l398
	opt asmopt_pop

	line	254
	
i1l369:	
	movf	(??_Isr_Timer+3),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	btemp+1
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	_Update_LED_Slot

;; *************** function _Update_LED_Slot *****************
;; Defined at:
;;		line 30 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    4[COMMON] unsigned char 
;;  led             1    5[COMMON] unsigned char 
;;  s               1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 800/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         3       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	30
global __ptext22
__ptext22:	;psect for function _Update_LED_Slot
psect	text22
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	30
	global	__size_of_Update_LED_Slot
	__size_of_Update_LED_Slot	equ	__end_of_Update_LED_Slot-_Update_LED_Slot
	
_Update_LED_Slot:	
;incstack = 0
	opt	stack 2
; Regs used in _Update_LED_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	movwf	(Update_LED_Slot@idx)
	line	32
	
i1l3723:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Update_LED_Slot@idx),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(Update_LED_Slot@s)
	line	35
	goto	i1l3735
	line	38
	
i1l3725:	
	clrf	(Update_LED_Slot@led)
	line	39
	goto	i1l3737
	line	43
	
i1l693:	
	line	46
	
i1l696:	
	line	47
	clrf	(Update_LED_Slot@led)
	incf	(Update_LED_Slot@led),f
	line	48
	goto	i1l3737
	line	50
	
i1l3727:	
	movlw	low(02h)
	movwf	(Update_LED_Slot@led)
	line	51
	goto	i1l3737
	line	53
	
i1l3729:	
	movlw	low(03h)
	movwf	(Update_LED_Slot@led)
	line	54
	goto	i1l3737
	line	35
	
i1l3735:	
	movf	(Update_LED_Slot@s),w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l3725
	xorlw	1^0	; case 1
	skipnz
	goto	i1l693
	xorlw	2^1	; case 2
	skipnz
	goto	i1l696
	xorlw	3^2	; case 3
	skipnz
	goto	i1l696
	xorlw	4^3	; case 4
	skipnz
	goto	i1l696
	xorlw	5^4	; case 5
	skipnz
	goto	i1l696
	xorlw	6^5	; case 6
	skipnz
	goto	i1l3727
	xorlw	7^6	; case 7
	skipnz
	goto	i1l3729
	xorlw	8^7	; case 8
	skipnz
	goto	i1l696
	xorlw	9^8	; case 9
	skipnz
	goto	i1l696
	goto	i1l3725
	opt asmopt_pop

	line	60
	
i1l3737:	
	movf	(Update_LED_Slot@idx),w
	addlw	low(_g_ledState|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Update_LED_Slot@led),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	line	61
	
i1l700:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Slot
	__end_of_Update_LED_Slot:
	signat	_Update_LED_Slot,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 97 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	line	97
global __ptext23
__ptext23:	;psect for function _PowerOnLedSequence
psect	text23
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	97
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	99
	
i1l2697:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_powerOnTimer)^080h,f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1)^080h,f	;volatile
	line	101
	
i1l2699:	
	bcf	status, 5	;RP0=0, select bank0
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u240_21
	goto	u240_20
u240_21:
	goto	i1l2707
u240_20:
	line	104
	
i1l2701:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u241_21
	goto	u241_20
u241_21:
	goto	i1l715
u241_20:
	line	106
	
i1l2703:	
	clrf	(_g_powerOnTimer)^080h	;volatile
	clrf	(_g_powerOnTimer+1)^080h	;volatile
	line	107
	
i1l2705:	
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l715
	line	110
	
i1l2707:	
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u242_21
	goto	u242_20
u242_21:
	goto	i1l715
u242_20:
	line	113
	
i1l2709:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u243_21
	goto	u243_20
u243_21:
	goto	i1l715
u243_20:
	line	115
	
i1l2711:	
	clrf	(_g_powerOnTimer)^080h	;volatile
	clrf	(_g_powerOnTimer+1)^080h	;volatile
	line	116
	
i1l2713:	
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_powerOnPhase)	;volatile
	line	120
	
i1l715:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
	global	_Led_BlinkProcess

;; *************** function _Led_BlinkProcess *****************
;; Defined at:
;;		line 71 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : A00/0
;;		Unchanged: 200/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	line	71
global __ptext24
__ptext24:	;psect for function _Led_BlinkProcess
psect	text24
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	71
	global	__size_of_Led_BlinkProcess
	__size_of_Led_BlinkProcess	equ	__end_of_Led_BlinkProcess-_Led_BlinkProcess
	
_Led_BlinkProcess:	
;incstack = 0
	opt	stack 3
; Regs used in _Led_BlinkProcess: [wreg-fsr0h+status,2+status,0]
	line	75
	
i1l2857:	
	clrf	(Led_BlinkProcess@i)
	line	77
	
i1l2863:	
	movf	(Led_BlinkProcess@i),w
	addlw	low(_g_ledState|((0x0)<<8))&0ffh
	movwf	fsr0
		movlw	3
	bcf	status, 7	;select IRP bank1
	xorwf	(indf),w
	btfss	status,2
	goto	u274_21
	goto	u274_20
u274_21:
	goto	i1l2869
u274_20:
	line	79
	
i1l2865:	
	clrc
	rlf	(Led_BlinkProcess@i),w
	addlw	low(_g_blinkTimer|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	80
	clrc
	rlf	(Led_BlinkProcess@i),w
	addlw	low(_g_blinkTimer|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Led_BlinkProcess+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_BlinkProcess+0)+0+1
	movlw	0
	subwf	1+(??_Led_BlinkProcess+0)+0,w
	movlw	032h
	skipnz
	subwf	0+(??_Led_BlinkProcess+0)+0,w
	skipc
	goto	u275_21
	goto	u275_20
u275_21:
	goto	i1l2869
u275_20:
	line	82
	
i1l2867:	
	clrc
	rlf	(Led_BlinkProcess@i),w
	addlw	low(_g_blinkTimer|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	83
	movf	(Led_BlinkProcess@i),w
	addlw	low(_g_blinkPhase|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(01h)
	xorwf	indf,f
	line	75
	
i1l2869:	
	incf	(Led_BlinkProcess@i),f
	
i1l2871:	
	movlw	low(0Ch)
	subwf	(Led_BlinkProcess@i),w
	skipc
	goto	u276_21
	goto	u276_20
u276_21:
	goto	i1l2863
u276_20:
	line	87
	
i1l707:	
	return
	opt stack 0
GLOBAL	__end_of_Led_BlinkProcess
	__end_of_Led_BlinkProcess:
	signat	_Led_BlinkProcess,89
	global	_Charging_Control

;; *************** function _Charging_Control *****************
;; Defined at:
;;		line 357 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    5[COMMON] unsigned char 
;;  i               1    6[COMMON] unsigned char 
;;  chargeB7_12     1    4[COMMON] unsigned char 
;;  chargeB1_6      1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 100/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	357
global __ptext25
__ptext25:	;psect for function _Charging_Control
psect	text25
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	357
	global	__size_of_Charging_Control
	__size_of_Charging_Control	equ	__end_of_Charging_Control-_Charging_Control
	
_Charging_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _Charging_Control: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	360
	
i1l3739:	
	clrf	(Charging_Control@chargeB1_6)
	line	361
	clrf	(Charging_Control@chargeB7_12)
	line	364
	
i1l3741:	
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_tempProtect)^080h),w
	btfsc	status,2
	goto	u392_21
	goto	u392_20
u392_21:
	goto	i1l3747
u392_20:
	line	366
	
i1l620:	
	bsf	(1072/8)^080h,(1072)&7	;volatile
	bsf	(1073/8)^080h,(1073)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	bsf	(50/8),(50)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	bsf	(1074/8)^080h,(1074)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	bsf	(49/8),(49)&7	;volatile
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	
i1l621:	
	line	367
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	368
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	369
	
i1l3743:	
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	goto	i1l622
	line	374
	
i1l3747:	
	clrf	(Charging_Control@i)
	line	376
	
i1l3753:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(Charging_Control@s)
	line	381
	
i1l3755:	
		movlw	2
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u393_21
	goto	u393_20
u393_21:
	goto	i1l3769
u393_20:
	
i1l3757:	
		movlw	3
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u394_21
	goto	u394_20
u394_21:
	goto	i1l3769
u394_20:
	
i1l3759:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u395_21
	goto	u395_20
u395_21:
	goto	i1l3769
u395_20:
	
i1l3761:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u396_21
	goto	u396_20
u396_21:
	goto	i1l3769
u396_20:
	
i1l3763:	
		movlw	8
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u397_21
	goto	u397_20
u397_21:
	goto	i1l3769
u397_20:
	
i1l3765:	
		movlw	9
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u398_21
	goto	u398_20
u398_21:
	goto	i1l3777
u398_20:
	goto	i1l3769
	line	383
	
i1l630:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l3771
	
i1l632:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l3771
	
i1l633:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l3771
	
i1l634:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l3771
	
i1l635:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l3771
	
i1l636:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l3771
	
i1l637:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l3771
	
i1l638:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l3771
	
i1l639:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l3771
	
i1l640:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l3771
	
i1l641:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l3771
	
i1l642:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l3771
	
i1l3769:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l630
	xorlw	1^0	; case 1
	skipnz
	goto	i1l632
	xorlw	2^1	; case 2
	skipnz
	goto	i1l633
	xorlw	3^2	; case 3
	skipnz
	goto	i1l634
	xorlw	4^3	; case 4
	skipnz
	goto	i1l635
	xorlw	5^4	; case 5
	skipnz
	goto	i1l636
	xorlw	6^5	; case 6
	skipnz
	goto	i1l637
	xorlw	7^6	; case 7
	skipnz
	goto	i1l638
	xorlw	8^7	; case 8
	skipnz
	goto	i1l639
	xorlw	9^8	; case 9
	skipnz
	goto	i1l640
	xorlw	10^9	; case 10
	skipnz
	goto	i1l641
	xorlw	11^10	; case 11
	skipnz
	goto	i1l642
	goto	i1l3771
	opt asmopt_pop

	line	386
	
i1l3771:	
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipnc
	goto	u399_21
	goto	u399_20
u399_21:
	goto	i1l644
u399_20:
	line	387
	
i1l3773:	
	clrf	(Charging_Control@chargeB1_6)
	incf	(Charging_Control@chargeB1_6),f
	goto	i1l3779
	line	388
	
i1l644:	
	line	389
	clrf	(Charging_Control@chargeB7_12)
	incf	(Charging_Control@chargeB7_12),f
	goto	i1l3779
	line	393
	
i1l649:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l3779
	
i1l651:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l3779
	
i1l652:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	i1l3779
	
i1l653:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	i1l3779
	
i1l654:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l3779
	
i1l655:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l3779
	
i1l656:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l3779
	
i1l657:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l3779
	
i1l658:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	i1l3779
	
i1l659:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	i1l3779
	
i1l660:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l3779
	
i1l661:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l3779
	
i1l3777:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l649
	xorlw	1^0	; case 1
	skipnz
	goto	i1l651
	xorlw	2^1	; case 2
	skipnz
	goto	i1l652
	xorlw	3^2	; case 3
	skipnz
	goto	i1l653
	xorlw	4^3	; case 4
	skipnz
	goto	i1l654
	xorlw	5^4	; case 5
	skipnz
	goto	i1l655
	xorlw	6^5	; case 6
	skipnz
	goto	i1l656
	xorlw	7^6	; case 7
	skipnz
	goto	i1l657
	xorlw	8^7	; case 8
	skipnz
	goto	i1l658
	xorlw	9^8	; case 9
	skipnz
	goto	i1l659
	xorlw	10^9	; case 10
	skipnz
	goto	i1l660
	xorlw	11^10	; case 11
	skipnz
	goto	i1l661
	goto	i1l3779
	opt asmopt_pop

	line	374
	
i1l3779:	
	incf	(Charging_Control@i),f
	
i1l3781:	
	movlw	low(0Ch)
	subwf	(Charging_Control@i),w
	skipc
	goto	u400_21
	goto	u400_20
u400_21:
	goto	i1l3753
u400_20:
	
i1l624:	
	line	398
	btfsc	(Charging_Control@chargeB1_6),0
	goto	u401_21
	goto	u401_20
	
u401_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2099/8)^0100h,(2099)&7	;volatile
	goto	u402_24
u401_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
u402_24:
	line	399
	btfsc	(Charging_Control@chargeB7_12),0
	goto	u403_21
	goto	u403_20
	
u403_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u404_24
u403_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u404_24:
	line	402
	
i1l622:	
	return
	opt stack 0
GLOBAL	__end_of_Charging_Control
	__end_of_Charging_Control:
	signat	_Charging_Control,89
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 420 in file "e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    4[BANK0 ] unsigned int 
;;  s               1   13[BANK0 ] unsigned char 
;;  duty            2   10[BANK0 ] int 
;;  error           2    8[BANK0 ] int 
;;  adjust          2    0[BANK0 ] int 
;;  maxV            2    6[BANK0 ] unsigned int 
;;  i               1   12[BANK0 ] unsigned char 
;;  cvCount         1    3[BANK0 ] unsigned char 
;;  hasCharging     1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 100/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      14       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2      14       0       0       0
;;Total ram usage:       16 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___awdiv
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=0
	line	420
global __ptext26
__ptext26:	;psect for function _CCCV_Control
psect	text26
	file	"e:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	420
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	423
	
i1l3783:	
	bcf	status, 6	;RP1=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	424
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	425
	clrf	(CCCV_Control@cvCount)
	line	428
	clrf	(CCCV_Control@i)
	line	430
	
i1l3789:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	434
	
i1l3791:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u405_21
	goto	u405_20
u405_21:
	goto	i1l669
u405_20:
	
i1l3793:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u406_21
	goto	u406_20
u406_21:
	goto	i1l669
u406_20:
	
i1l3795:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u407_21
	goto	u407_20
u407_21:
	goto	i1l669
u407_20:
	
i1l3797:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u408_21
	goto	u408_20
u408_21:
	goto	i1l669
u408_20:
	
i1l3799:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u409_21
	goto	u409_20
u409_21:
	goto	i1l669
u409_20:
	
i1l3801:	
		movlw	9
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u410_21
	goto	u410_20
u410_21:
	goto	i1l667
u410_20:
	
i1l669:	
	line	436
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	438
	
i1l3803:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	439
	
i1l3805:	
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u411_25
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u411_25:
	skipnc
	goto	u411_21
	goto	u411_20
u411_21:
	goto	i1l3809
u411_20:
	
i1l3807:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	441
	
i1l3809:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u412_21
	goto	u412_20
u412_21:
	goto	i1l667
u412_20:
	line	442
	
i1l3811:	
	incf	(CCCV_Control@cvCount),f
	line	443
	
i1l667:	
	line	428
	incf	(CCCV_Control@i),f
	
i1l3813:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u413_21
	goto	u413_20
u413_21:
	goto	i1l3789
u413_20:
	line	447
	
i1l3815:	
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u414_21
	goto	u414_20
u414_21:
	goto	i1l3821
u414_20:
	line	449
	
i1l3817:	
	clrf	(_g_pwmDuty)	;volatile
	line	450
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	i1l673
	line	457
	
i1l3821:	
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u415_21
	goto	u415_20
u415_21:
	goto	i1l3839
u415_20:
	line	459
	
i1l3823:	
	movlw	low(019h)
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u416_21
	goto	u416_20
u416_21:
	goto	i1l3831
u416_20:
	line	462
	
i1l3825:	
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	463
	
i1l3827:	
	movlw	low(01Ah)
	subwf	(_g_pwmDuty),w	;volatile
	skipc
	goto	u417_21
	goto	u417_20
u417_21:
	goto	i1l673
u417_20:
	line	464
	
i1l3829:	
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l673
	line	466
	
i1l3831:	
	goto	i1l3829
	line	485
	
i1l3839:	
	movlw	021h
	movwf	(CCCV_Control@error)
	movlw	0Dh
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	488
	movf	(CCCV_Control@error),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral)^080h,f
	skipnc
	incf	(_g_cvIntegral+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(CCCV_Control@error+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral+1)^080h,f
	line	489
	
i1l3841:	
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u418_25
	movlw	0C9h
	subwf	(_g_cvIntegral)^080h,w
u418_25:

	skipc
	goto	u418_21
	goto	u418_20
u418_21:
	goto	i1l3845
u418_20:
	line	490
	
i1l3843:	
	movlw	0C8h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	i1l3849
	line	491
	
i1l3845:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u419_25
	movlw	038h
	subwf	(_g_cvIntegral)^080h,w
u419_25:

	skipnc
	goto	u419_21
	goto	u419_20
u419_21:
	goto	i1l3849
u419_20:
	line	492
	
i1l3847:	
	movlw	038h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	movlw	0FFh
	movwf	((_g_cvIntegral)^080h)+1
	line	495
	
i1l3849:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_cvIntegral)^080h,w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1)^080h,w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	496
	
i1l3851:	
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
i1l3853:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	499
	
i1l3855:	
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u420_25
	movlw	021h
	subwf	(CCCV_Control@duty),w
u420_25:

	skipc
	goto	u420_21
	goto	u420_20
u420_21:
	goto	i1l3859
u420_20:
	
i1l3857:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	500
	
i1l3859:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u421_21
	goto	u421_20
u421_21:
	goto	i1l3863
u421_20:
	
i1l3861:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	502
	
i1l3863:	
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	504
	
i1l673:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	i1___bmul

;; *************** function i1___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[COMMON] unsigned char 
;;  __bmul          1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Charging_Control
;;		_CCCV_Control
;;		_Update_LED_Slot
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext27
__ptext27:	;psect for function i1___bmul
psect	text27
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_ofi1___bmul
	__size_ofi1___bmul	equ	__end_ofi1___bmul-i1___bmul
	
i1___bmul:	
;incstack = 0
	opt	stack 2
; Regs used in i1___bmul: [wreg+status,2+status,0]
	movwf	(i1___bmul@multiplier)
	line	6
	
i1l2603:	
	clrf	(i1___bmul@product)
	line	43
	
i1l2605:	
	btfss	(i1___bmul@multiplier),(0)&7
	goto	u236_21
	goto	u236_20
u236_21:
	goto	i1l2609
u236_20:
	line	44
	
i1l2607:	
	movf	(i1___bmul@multiplicand),w
	addwf	(i1___bmul@product),f
	line	45
	
i1l2609:	
	clrc
	rlf	(i1___bmul@multiplicand),f
	line	46
	
i1l2611:	
	clrc
	rrf	(i1___bmul@multiplier),f
	line	47
	movf	((i1___bmul@multiplier)),w
	btfss	status,2
	goto	u237_21
	goto	u237_20
u237_21:
	goto	i1l2605
u237_20:
	line	50
	
i1l2613:	
	movf	(i1___bmul@product),w
	line	51
	
i1l739:	
	return
	opt stack 0
GLOBAL	__end_ofi1___bmul
	__end_ofi1___bmul:
	signat	i1___bmul,89
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] int 
;;  dividend        2    2[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] int 
;;  sign            1    5[COMMON] unsigned char 
;;  counter         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext28
__ptext28:	;psect for function ___awdiv
psect	text28
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
i1l2559:	
	clrf	(___awdiv@sign)
	line	15
	
i1l2561:	
	btfss	(___awdiv@divisor+1),7
	goto	u229_21
	goto	u229_20
u229_21:
	goto	i1l2567
u229_20:
	line	16
	
i1l2563:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
i1l2565:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
i1l2567:	
	btfss	(___awdiv@dividend+1),7
	goto	u230_21
	goto	u230_20
u230_21:
	goto	i1l2573
u230_20:
	line	20
	
i1l2569:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
i1l2571:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
i1l2573:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
i1l2575:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u231_21
	goto	u231_20
u231_21:
	goto	i1l2595
u231_20:
	line	25
	
i1l2577:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	i1l2581
	line	27
	
i1l2579:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
i1l2581:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u232_21
	goto	u232_20
u232_21:
	goto	i1l2579
u232_20:
	line	31
	
i1l2583:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
i1l2585:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u233_25
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u233_25:
	skipc
	goto	u233_21
	goto	u233_20
u233_21:
	goto	i1l2591
u233_20:
	line	33
	
i1l2587:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
i1l2589:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
i1l2591:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
i1l2593:	
	decfsz	(___awdiv@counter),f
	goto	u234_21
	goto	u234_20
u234_21:
	goto	i1l2583
u234_20:
	line	39
	
i1l2595:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u235_21
	goto	u235_20
u235_21:
	goto	i1l2599
u235_20:
	line	40
	
i1l2597:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
i1l2599:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
i1l851:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
