opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_CCCV_Control
	FNCALL	_main,_Display_Service
	FNCALL	_main,_Get_Vcc
	FNCALL	_main,_Read_Temperature
	FNCALL	_main,_Sense_Pins_AsSink
	FNCALL	_main,_Sense_Pins_Restore
	FNCALL	_main,_Slot_Charge_Ctrl
	FNCALL	_main,_System_Init
	FNCALL	_main,_Update_LED_Global
	FNCALL	_main,_Wait_Display_Idle
	FNCALL	_main,___bmul
	FNCALL	_Update_LED_Global,___bmul
	FNCALL	_Update_LED_Global,___lwmod
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_Slot_Charge_Ctrl,_Adc_Norm
	FNCALL	_Slot_Charge_Ctrl,_Detect_BatteryType
	FNCALL	_Slot_Charge_Ctrl,_Detect_Classify
	FNCALL	_Slot_Charge_Ctrl,_Enter_DiodeTest
	FNCALL	_Slot_Charge_Ctrl,_Get_Vcc
	FNCALL	_Slot_Charge_Ctrl,_Route_LiIon
	FNCALL	_Slot_Charge_Ctrl,_Route_LinearLi
	FNCALL	_Slot_Charge_Ctrl,___bmul
	FNCALL	_Slot_Charge_Ctrl,___lldiv
	FNCALL	_Slot_Charge_Ctrl,___wmul
	FNCALL	_Route_LinearLi,_Route_DetectLi
	FNCALL	_Route_LiIon,_Route_DetectLi
	FNCALL	_Detect_Classify,_Get_Vcc
	FNCALL	_Detect_Classify,_Route_DetectLi
	FNCALL	_Detect_Classify,___lwdiv
	FNCALL	_Route_DetectLi,___lldiv
	FNCALL	_Route_DetectLi,___lmul
	FNCALL	_Get_Vcc,_ADC_Sample
	FNCALL	_Get_Vcc,___lldiv
	FNCALL	_Adc_Norm,_ADC_Sample
	FNCALL	_Adc_Norm,___lldiv
	FNCALL	_Adc_Norm,___lmul
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,___bmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Sink_Set
	FNCALL	_Sink_Set,_Sink_Slot_Off
	FNCALL	_Sink_Set,_Sink_Slot_On
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_vcc_mv
	global	_g_elapsedTicks
	global	_g_detectWaiter
	global	_g_detectOwner
psect	idataCOMMON,class=CODE,space=0,delta=2,noexec
global __pidataCOMMON
__pidataCOMMON:
	file	"main.c"
	line	15

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	line	29

;initializer for _g_elapsedTicks
	retlw	01h
	retlw	0

	file	"charge_mgr.c"
	line	35

;initializer for _g_detectWaiter
	retlw	0FFh
	line	29

;initializer for _g_detectOwner
	retlw	0FFh
	global	_s_adcChannels
psect	strings,class=STRING,delta=2,noexec
global __pstrings
__pstrings:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 1 byte each
stringcode:stringdir:
movlw high(stringdir)
movwf pclath
movf fsr,w
incf fsr
	addwf pc
	global __stringbase
__stringbase:
	retlw	0
psect	strings
	global    __end_of__stringtab
__end_of__stringtab:
	file	"main.c"
	line	55
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_impData
	global	_g_pwmDuty
	global	_s_senseRestored
	global	_g_doNtcRead
	global	_g_fullSample
	global	_g_fullDark
	global	_g_adcBusy
	global	_g_dispWin
	global	_g_stableCnt
	global	_g_detectLowCnt
	global	_s_work
	global	_g_diodeTrace
	global	_s_fullTick
	global	_g_highVFlag
	global	_g_capFlag
	global	main@s_slowLastTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_sinkMask
	global	_g_lastHwTick
	global	_g_hwTick
	global	_g_powerOnTimer
	global	_g_cvIntegral
	global	_s_ledBlinkCnt
	global	_g_diodeTraceCnt
	global	_g_vccProtect
	global	_g_tempProtect
	global	_test_adc
	global	_g_tempPhase
	global	_g_hwTickDiv
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_adresult
	global	_g_slot
	global	_g_slotRefV
	global	_g_ovCnt
	global	_g_ccBlocks
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB5
_RB5	set	0x35
	global	_RB4
_RB4	set	0x34
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA6
_RA6	set	0x436
	global	_RA7
_RA7	set	0x437
	global	_RA4
_RA4	set	0x434
	global	_RA5
_RA5	set	0x435
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RD0
_RD0	set	0x838
	global	_RD1
_RD1	set	0x839
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD5
_RD5	set	0x83D
	global	_RD4
_RD4	set	0x83C
	global	_RC0
_RC0	set	0x830
	global	_RC1
_RC1	set	0x831
	global	_RC5
_RC5	set	0x835
	global	_RC4
_RC4	set	0x834
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
; #config settings
	file	"main.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_s_senseRestored:
       ds      1

_g_doNtcRead:
       ds      1

_g_fullSample:
       ds      1

_g_fullDark:
       ds      1

_g_adcBusy:
       ds      1

_g_dispWin:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_g_impData:
       ds      2

_g_pwmDuty:
       ds      1

psect	dataCOMMON,class=COMMON,space=1,noexec
global __pdataCOMMON
__pdataCOMMON:
	file	"main.c"
	line	15
_g_vcc_mv:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_stableCnt:
       ds      12

_g_detectLowCnt:
       ds      12

_s_work:
       ds      6

_g_diodeTrace:
       ds      4

_s_fullTick:
       ds      2

_g_highVFlag:
       ds      2

_g_capFlag:
       ds      2

main@s_slowLastTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_sinkMask:
       ds      2

_g_lastHwTick:
       ds      2

_g_hwTick:
       ds      2

_g_powerOnTimer:
       ds      2

_g_cvIntegral:
       ds      2

_s_ledBlinkCnt:
       ds      1

_g_diodeTraceCnt:
       ds      1

_g_vccProtect:
       ds      1

_g_tempProtect:
       ds      1

_test_adc:
       ds      1

_g_tempPhase:
       ds      1

_g_hwTickDiv:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_adresult:
       ds      2

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"main.c"
	line	29
_g_elapsedTicks:
       ds      2

psect	dataBANK1
	file	"charge_mgr.c"
	line	35
_g_detectWaiter:
       ds      1

psect	dataBANK1
	file	"charge_mgr.c"
	line	29
_g_detectOwner:
       ds      1

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slotRefV:
       ds      24

_g_ovCnt:
       ds      12

_g_ccBlocks:
       ds      12

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"main.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
	fcall	__pidataBANK1+2		;fetch initializer
	movwf	__pdataBANK1+2&07fh		
	fcall	__pidataBANK1+3		;fetch initializer
	movwf	__pdataBANK1+3&07fh		
; Initialize objects allocated to COMMON
	global __pidataCOMMON
psect cinit,class=CODE,delta=2,merge=1
	fcall	__pidataCOMMON+0		;fetch initializer
	movwf	__pdataCOMMON+0&07fh		
	fcall	__pidataCOMMON+1		;fetch initializer
	movwf	__pdataCOMMON+1&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+030h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+043h)
	fcall	clear_ram0
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
	clrf	((__pbssCOMMON)+1)&07Fh
	clrf	((__pbssCOMMON)+2)&07Fh
; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
??_main:	; 1 bytes @ 0x0
	ds	3
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Slot_Charge_Ctrl:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Update_LED_Global:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Sink_Slot_On:	; 1 bytes @ 0x0
??_Sink_Slot_On:	; 1 bytes @ 0x0
?_Sink_Slot_Off:	; 1 bytes @ 0x0
??_Sink_Slot_Off:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Sense_Pins_AsSink:	; 1 bytes @ 0x0
?_Sense_Pins_Restore:	; 1 bytes @ 0x0
?_Wait_Display_Idle:	; 1 bytes @ 0x0
?_Display_Service:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?_Route_LiIon:	; 1 bytes @ 0x0
?_Enter_DiodeTest:	; 1 bytes @ 0x0
?_Get_Vcc:	; 2 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	global	Sink_Slot_On@idx
Sink_Slot_On@idx:	; 1 bytes @ 0x0
	global	Sink_Slot_Off@idx
Sink_Slot_Off@idx:	; 1 bytes @ 0x0
	ds	1
?_Sink_Set:	; 1 bytes @ 0x1
	global	Sink_Set@mask
Sink_Set@mask:	; 2 bytes @ 0x1
	ds	2
	global	Sink_Set@on
Sink_Set@on:	; 1 bytes @ 0x3
	ds	1
??_Sink_Set:	; 1 bytes @ 0x4
	global	Sink_Set@i
Sink_Set@i:	; 1 bytes @ 0x4
	ds	1
??_Isr_Timer:	; 1 bytes @ 0x5
	ds	3
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
??_AD_Init:	; 1 bytes @ 0x0
??_Sense_Pins_AsSink:	; 1 bytes @ 0x0
??_Sense_Pins_Restore:	; 1 bytes @ 0x0
??_Wait_Display_Idle:	; 1 bytes @ 0x0
??_Display_Service:	; 1 bytes @ 0x0
?_ADC_Sample:	; 1 bytes @ 0x0
?_Detect_BatteryType:	; 1 bytes @ 0x0
??_Enter_DiodeTest:	; 1 bytes @ 0x0
?___bmul:	; 1 bytes @ 0x0
	global	?___wmul
?___wmul:	; 2 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x0
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x0
	global	?___lmul
?___lmul:	; 4 bytes @ 0x0
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x0
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x0
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x0
	global	___wmul@multiplier
___wmul@multiplier:	; 2 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x0
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x0
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x0
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x1
??___bmul:	; 1 bytes @ 0x1
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x1
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x2
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x2
	global	___wmul@multiplicand
___wmul@multiplicand:	; 2 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x2
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x2
	ds	1
??_System_Init:	; 1 bytes @ 0x3
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x3
	global	Enter_DiodeTest@idx
Enter_DiodeTest@idx:	; 1 bytes @ 0x3
	ds	1
??___wmul:	; 1 bytes @ 0x4
??___awdiv:	; 1 bytes @ 0x4
??___lwdiv:	; 1 bytes @ 0x4
??___lwmod:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x4
	global	___wmul@product
___wmul@product:	; 2 bytes @ 0x4
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x4
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x4
	ds	1
??_Update_LED_Global:	; 1 bytes @ 0x5
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x6
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	1
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x7
	ds	1
??_CCCV_Control:	; 1 bytes @ 0x8
??___lmul:	; 1 bytes @ 0x8
	global	Update_LED_Global@fullBits
Update_LED_Global@fullBits:	; 2 bytes @ 0x8
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x8
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x8
	ds	2
	global	Update_LED_Global@hasDet
Update_LED_Global@hasDet:	; 1 bytes @ 0xA
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0xA
	ds	1
	global	Update_LED_Global@sT0IE
Update_LED_Global@sT0IE:	; 1 bytes @ 0xB
	ds	1
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0xC
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0xC
	global	Update_LED_Global@s_371
Update_LED_Global@s_371:	; 1 bytes @ 0xC
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0xC
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0xC
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0xD
	global	Update_LED_Global@hasErr
Update_LED_Global@hasErr:	; 1 bytes @ 0xD
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0xE
	global	Update_LED_Global@hasChg
Update_LED_Global@hasChg:	; 1 bytes @ 0xE
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0xE
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0xF
	global	Update_LED_Global@s_370
Update_LED_Global@s_370:	; 1 bytes @ 0xF
	ds	1
	global	Update_LED_Global@hasFull
Update_LED_Global@hasFull:	; 1 bytes @ 0x10
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0x10
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x10
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x10
	ds	1
	global	Update_LED_Global@mask
Update_LED_Global@mask:	; 2 bytes @ 0x11
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x12
	ds	1
	global	Update_LED_Global@s
Update_LED_Global@s:	; 1 bytes @ 0x13
	ds	1
??___lldiv:	; 1 bytes @ 0x14
	global	Update_LED_Global@i
Update_LED_Global@i:	; 1 bytes @ 0x14
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0x14
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x14
	ds	2
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0x16
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0x17
	ds	1
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x18
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0x18
	ds	1
??_Get_Vcc:	; 1 bytes @ 0x19
??_Read_Temperature:	; 1 bytes @ 0x19
?_Route_DetectLi:	; 1 bytes @ 0x19
	global	?_Adc_Norm
?_Adc_Norm:	; 2 bytes @ 0x19
	global	Route_DetectLi@slot_v
Route_DetectLi@slot_v:	; 2 bytes @ 0x19
	global	Get_Vcc@pt
Get_Vcc@pt:	; 4 bytes @ 0x19
	ds	1
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x1A
	ds	1
??_Route_DetectLi:	; 1 bytes @ 0x1B
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x1B
	ds	1
??_Adc_Norm:	; 1 bytes @ 0x1C
	global	Adc_Norm@ch
Adc_Norm@ch:	; 1 bytes @ 0x1C
	ds	1
	global	Adc_Norm@raw
Adc_Norm@raw:	; 2 bytes @ 0x1D
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x1D
	ds	2
	global	Route_DetectLi@bat_mv
Route_DetectLi@bat_mv:	; 2 bytes @ 0x1F
	ds	2
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x21
	global	Route_DetectLi@vx_mv
Route_DetectLi@vx_mv:	; 4 bytes @ 0x21
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x23
	ds	2
	global	Route_DetectLi@bat_mv_long
Route_DetectLi@bat_mv_long:	; 4 bytes @ 0x25
	ds	4
	global	Route_DetectLi@st
Route_DetectLi@st:	; 1 bytes @ 0x29
	ds	1
	global	Route_DetectLi@idx
Route_DetectLi@idx:	; 1 bytes @ 0x2A
	ds	1
??_Route_LiIon:	; 1 bytes @ 0x2B
?_Route_LinearLi:	; 1 bytes @ 0x2B
?_Detect_Classify:	; 1 bytes @ 0x2B
	global	Detect_Classify@fromHighV
Detect_Classify@fromHighV:	; 1 bytes @ 0x2B
	global	Route_LinearLi@pre
Route_LinearLi@pre:	; 2 bytes @ 0x2B
	ds	1
??_Detect_Classify:	; 1 bytes @ 0x2C
	ds	1
??_Route_LinearLi:	; 1 bytes @ 0x2D
	ds	1
	global	Route_LiIon@idx
Route_LiIon@idx:	; 1 bytes @ 0x2E
	ds	1
	global	Detect_Classify@idx
Detect_Classify@idx:	; 1 bytes @ 0x2F
	ds	1
	global	Route_LinearLi@idx
Route_LinearLi@idx:	; 1 bytes @ 0x30
	ds	1
??_Slot_Charge_Ctrl:	; 1 bytes @ 0x31
	ds	5
	global	Slot_Charge_Ctrl@v_init
Slot_Charge_Ctrl@v_init:	; 2 bytes @ 0x36
	ds	2
	global	Slot_Charge_Ctrl@vcc_norm_pre
Slot_Charge_Ctrl@vcc_norm_pre:	; 2 bytes @ 0x38
	ds	2
	global	Slot_Charge_Ctrl@vcc_norm_now
Slot_Charge_Ctrl@vcc_norm_now:	; 2 bytes @ 0x3A
	ds	2
	global	Slot_Charge_Ctrl@ptTick
Slot_Charge_Ctrl@ptTick:	; 2 bytes @ 0x3C
	ds	2
	global	Slot_Charge_Ctrl@vcc_norm
Slot_Charge_Ctrl@vcc_norm:	; 2 bytes @ 0x3E
	ds	2
	global	_Slot_Charge_Ctrl$344
_Slot_Charge_Ctrl$344:	; 2 bytes @ 0x40
	ds	2
	global	Slot_Charge_Ctrl@pt
Slot_Charge_Ctrl@pt:	; 1 bytes @ 0x42
	ds	1
	global	Slot_Charge_Ctrl@charge_ticks_prev
Slot_Charge_Ctrl@charge_ticks_prev:	; 2 bytes @ 0x43
	ds	2
	global	Slot_Charge_Ctrl@newv
Slot_Charge_Ctrl@newv:	; 2 bytes @ 0x45
	ds	2
	global	Slot_Charge_Ctrl@v_ref
Slot_Charge_Ctrl@v_ref:	; 2 bytes @ 0x47
	ds	2
	global	Slot_Charge_Ctrl@dly
Slot_Charge_Ctrl@dly:	; 1 bytes @ 0x49
	ds	1
	global	Slot_Charge_Ctrl@diff
Slot_Charge_Ctrl@diff:	; 2 bytes @ 0x4A
	ds	2
	global	Slot_Charge_Ctrl@pre
Slot_Charge_Ctrl@pre:	; 2 bytes @ 0x4C
	ds	2
	global	Slot_Charge_Ctrl@idx
Slot_Charge_Ctrl@idx:	; 1 bytes @ 0x4E
	ds	1
	global	main@i
main@i:	; 1 bytes @ 0x4F
	ds	1
;!
;!Data Sizes:
;!    Strings     0
;!    Constant    12
;!    Data        6
;!    BSS         190
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14      8      14
;!    BANK0            80     80      80
;!    BANK1            80      3      74
;!    BANK3            80      0      48
;!    BANK2            80      0      72

;!
;!Pointer List with Targets:
;!
;!    None.


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->_Sink_Set
;!    _Sink_Set->_Sink_Slot_Off
;!    _Sink_Set->_Sink_Slot_On
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Slot_Charge_Ctrl
;!    _Update_LED_Global->___lwmod
;!    _System_Init->___bmul
;!    _Slot_Charge_Ctrl->_Route_LinearLi
;!    _Route_LinearLi->_Route_DetectLi
;!    _Route_LiIon->_Route_DetectLi
;!    _Detect_Classify->_Route_DetectLi
;!    _Route_DetectLi->___lldiv
;!    _Get_Vcc->___lldiv
;!    _Adc_Norm->___lldiv
;!    _Read_Temperature->___lldiv
;!    ___lldiv->___lmul
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    None.
;!
;!Critical Paths under _main in BANK1
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 3, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 4     4      0   33585
;!                                             79 BANK0      1     1      0
;!                                              0 BANK1      3     3      0
;!                       _CCCV_Control
;!                    _Display_Service
;!                            _Get_Vcc
;!                   _Read_Temperature
;!                  _Sense_Pins_AsSink
;!                 _Sense_Pins_Restore
;!                   _Slot_Charge_Ctrl
;!                        _System_Init
;!                  _Update_LED_Global
;!                  _Wait_Display_Idle
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _Wait_Display_Idle                                    1     1      0       0
;!                                              0 BANK0      1     1      0
;! ---------------------------------------------------------------------------------
;! (1) _Update_LED_Global                                   16    16      0    1720
;!                                              5 BANK0     16    16      0
;!                             ___bmul
;!                            ___lwmod
;! ---------------------------------------------------------------------------------
;! (2) ___lwmod                                              5     1      4     265
;!                                              0 BANK0      5     1      4
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0     660
;!                                              3 BANK0      1     1      0
;!                            _AD_Init
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Slot_Charge_Ctrl                                    30    30      0   23720
;!                                             49 BANK0     30    30      0
;!                           _Adc_Norm
;!                 _Detect_BatteryType
;!                    _Detect_Classify
;!                    _Enter_DiodeTest
;!                            _Get_Vcc
;!                        _Route_LiIon
;!                     _Route_LinearLi
;!                             ___bmul
;!                            ___lldiv
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (2) ___wmul                                               6     2      4    2058
;!                                              0 BANK0      6     2      4
;! ---------------------------------------------------------------------------------
;! (2) _Route_LinearLi                                       6     4      2    2932
;!                                             43 BANK0      6     4      2
;!                     _Route_DetectLi
;! ---------------------------------------------------------------------------------
;! (2) _Route_LiIon                                          4     4      0    2517
;!                                             43 BANK0      4     4      0
;!                     _Route_DetectLi
;! ---------------------------------------------------------------------------------
;! (2) _Enter_DiodeTest                                      4     4      0      33
;!                                              0 BANK0      4     4      0
;! ---------------------------------------------------------------------------------
;! (2) _Detect_Classify                                      5     4      1    5318
;!                                             43 BANK0      5     4      1
;!                            _Get_Vcc
;!                     _Route_DetectLi
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (3) _Route_DetectLi                                      18    16      2    2473
;!                                             25 BANK0     18    16      2
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (2) _Get_Vcc                                              4     4      0    1889
;!                                             25 BANK0      4     4      0
;!                         _ADC_Sample
;!                            ___lldiv
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     185
;!                                              0 BANK0      2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _Adc_Norm                                             6     3      3    2683
;!                                             25 BANK0      6     3      3
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (1) _Sense_Pins_Restore                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Sense_Pins_AsSink                                    0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Read_Temperature                                    12    12      0    3363
;!                                             25 BANK0     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4     480
;!                                              0 BANK0      7     3      4
;! ---------------------------------------------------------------------------------
;! (4) ___lmul                                              12     4      8     750
;!                                              0 BANK0     12     4      8
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1182
;!                                             12 BANK0     13     5      8
;!                             ___lmul (ARG)
;!                             ___wmul (ARG)
;! ---------------------------------------------------------------------------------
;! (3) _ADC_Sample                                          18    17      1     684
;!                                              0 BANK0     18    17      1
;! ---------------------------------------------------------------------------------
;! (1) _Display_Service                                      0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _CCCV_Control                                        20    20      0    1661
;!                                              8 BANK0     20    20      0
;!                            ___awdiv
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) ___bmul                                               3     2      1     482
;!                                              0 BANK0      3     2      1
;! ---------------------------------------------------------------------------------
;! (2) ___awdiv                                              8     4      4     428
;!                                              0 BANK0      8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 4
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (5) _Isr_Timer                                            3     3      0     391
;!                                              5 COMMON     3     3      0
;!                 _PowerOnLedSequence
;!                           _Sink_Set
;! ---------------------------------------------------------------------------------
;! (6) _Sink_Set                                             4     1      3     391
;!                                              1 COMMON     4     1      3
;!                      _Sink_Slot_Off
;!                       _Sink_Slot_On
;! ---------------------------------------------------------------------------------
;! (7) _Sink_Slot_On                                         1     1      0      22
;!                                              0 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (7) _Sink_Slot_Off                                        1     1      0      22
;!                                              0 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (6) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 7
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     ___bmul
;!   _Display_Service
;!   _Get_Vcc
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!       ___wmul (ARG)
;!   _Read_Temperature
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!       ___wmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!   _Sense_Pins_AsSink
;!   _Sense_Pins_Restore
;!   _Slot_Charge_Ctrl
;!     _Adc_Norm
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!         ___wmul (ARG)
;!       ___lmul
;!     _Detect_BatteryType
;!     _Detect_Classify
;!       _Get_Vcc
;!         _ADC_Sample
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!       _Route_DetectLi
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!         ___lmul
;!       ___lwdiv
;!     _Enter_DiodeTest
;!     _Get_Vcc
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!         ___wmul (ARG)
;!     _Route_LiIon
;!       _Route_DetectLi
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!         ___lmul
;!     _Route_LinearLi
;!       _Route_DetectLi
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!         ___lmul
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!       ___wmul (ARG)
;!     ___wmul
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!   _Update_LED_Global
;!     ___bmul
;!     ___lwmod
;!   _Wait_Display_Idle
;!   ___bmul
;!
;! _Isr_Timer (ROOT)
;!   _PowerOnLedSequence
;!   _Sink_Set
;!     _Sink_Slot_Off
;!     _Sink_Slot_On
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50      0      30       8       60.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      0      48      10       90.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50      3      4A       6       92.5%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     50      50       4      100.0%
;!BITBANK0            50      0       0       3        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      8       E       1      100.0%
;!BITCOMMON            E      0       1       0        7.1%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     120      12        0.0%
;!ABS                  0      0     120      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 599 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   79[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       3       0       0
;;      Totals:         0       1       3       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels required when called:    7
;; This function calls:
;;		_CCCV_Control
;;		_Display_Service
;;		_Get_Vcc
;;		_Read_Temperature
;;		_Sense_Pins_AsSink
;;		_Sense_Pins_Restore
;;		_Slot_Charge_Ctrl
;;		_System_Init
;;		_Update_LED_Global
;;		_Wait_Display_Idle
;;		___bmul
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"main.c"
	line	599
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"main.c"
	line	599
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 1
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	604
	
l5102:	
	opt asmopt_push
opt asmopt_off
movlw	52
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_main+0)^080h+0+1),f
	movlw	241
movwf	((??_main+0)^080h+0),f
	u7977:
decfsz	((??_main+0)^080h+0),f
	goto	u7977
	decfsz	((??_main+0)^080h+0+1),f
	goto	u7977
opt asmopt_pop

	line	605
# 605 "main.c"
clrwdt ;# 
psect	maintext
	line	608
	
l5104:	
	fcall	_System_Init
	line	616
	
l438:	
	line	618
# 618 "main.c"
clrwdt ;# 
psect	maintext
	line	624
	
l5106:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_hwTick+1)^080h,w	;volatile
	movwf	(_g_elapsedTicks+1)^080h
	movf	(_g_hwTick)^080h,w	;volatile
	movwf	(_g_elapsedTicks)^080h
	
l5108:	
	movf	(_g_lastHwTick)^080h,w
	subwf	(_g_elapsedTicks)^080h,f
	movf	(_g_lastHwTick+1)^080h,w
	skipc
	decf	(_g_elapsedTicks+1)^080h,f
	subwf	(_g_elapsedTicks+1)^080h,f
	line	625
	
l5110:	
	movf	((_g_elapsedTicks)^080h),w
iorwf	((_g_elapsedTicks+1)^080h),w
	btfss	status,2
	goto	u7881
	goto	u7880
u7881:
	goto	l5114
u7880:
	line	626
	
l5112:	
	clrf	(_g_elapsedTicks)^080h
	incf	(_g_elapsedTicks)^080h,f
	clrf	(_g_elapsedTicks+1)^080h
	line	627
	
l5114:	
	movf	(_g_hwTick+1)^080h,w	;volatile
	movwf	(_g_lastHwTick+1)^080h
	movf	(_g_hwTick)^080h,w	;volatile
	movwf	(_g_lastHwTick)^080h
	line	630
	
l5116:	
	fcall	_Get_Vcc
	line	643
	
l5118:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_powerOnPhase)^080h,w
	skipc
	goto	u7891
	goto	u7890
u7891:
	goto	l5156
u7890:
	line	647
	
l5120:	
	btfsc	(_s_senseRestored/8),(_s_senseRestored)&7
	goto	u7901
	goto	u7900
u7901:
	goto	l5126
u7900:
	line	649
	
l5122:	
	fcall	_Sense_Pins_Restore
	line	650
	
l5124:	
	bsf	(_s_senseRestored/8),(_s_senseRestored)&7
	line	656
	
l5126:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(main@i)
	line	662
	
l5132:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(main@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
		movlw	6
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u7911
	goto	u7910
u7911:
	goto	l5138
u7910:
	
l5134:	
	btfsc	(_g_fullSample/8),(_g_fullSample)&7	;volatile
	goto	u7921
	goto	u7920
u7921:
	goto	l5138
u7920:
	goto	l5144
	line	664
	
l5138:	
	fcall	_Wait_Display_Idle
	line	665
	
l5140:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@i),w
	fcall	_Slot_Charge_Ctrl
	line	666
	
l5142:	
	fcall	_Display_Service
	line	656
	
l5144:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(main@i),f
	
l5146:	
	movlw	low(0Ch)
	subwf	(main@i),w
	skipc
	goto	u7931
	goto	u7930
u7931:
	goto	l5132
u7930:
	line	670
	
l5148:	
	fcall	_CCCV_Control
	line	673
	
l5150:	
	movlw	low(01Dh)
	subwf	(_g_pwmDuty),w	;volatile
	skipc
	goto	u7941
	goto	u7940
u7941:
	goto	l5154
u7940:
	line	674
	
l5152:	
	movlw	low(01Ch)
	movwf	(_g_pwmDuty)	;volatile
	line	677
	
l5154:	
	fcall	_Update_LED_Global
	line	678
	goto	l5158
	line	682
	
l5156:	
	fcall	_Sense_Pins_AsSink
	line	686
	
l5158:	
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u7951
	goto	u7950
u7951:
	goto	l5164
u7950:
	line	688
	
l5160:	
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	689
	
l5162:	
	fcall	_Read_Temperature
	line	709
	
l5164:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(main@s_slowLastTick)^080h,w
	subwf	(_g_hwTick)^080h,w	;volatile
	movwf	(??_main+0)^080h+0
	movf	(main@s_slowLastTick+1)^080h,w
	skipc
	incf	(main@s_slowLastTick+1)^080h,w
	subwf	(_g_hwTick+1)^080h,w	;volatile
	movwf	1+(??_main+0)^080h+0
	movlw	0
	subwf	1+(??_main+0)^080h+0,w
	movlw	0C8h
	skipnz
	subwf	0+(??_main+0)^080h+0,w
	skipc
	goto	u7961
	goto	u7960
u7961:
	goto	l438
u7960:
	line	711
	
l5166:	
	movf	(_g_hwTick+1)^080h,w	;volatile
	movwf	(main@s_slowLastTick+1)^080h
	movf	(_g_hwTick)^080h,w	;volatile
	movwf	(main@s_slowLastTick)^080h
	line	712
	opt asmopt_push
opt asmopt_off
movlw  14
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_main+0)^080h+0+2),f
movlw	49
movwf	((??_main+0)^080h+0+1),f
	movlw	147
movwf	((??_main+0)^080h+0),f
	u7987:
decfsz	((??_main+0)^080h+0),f
	goto	u7987
	decfsz	((??_main+0)^080h+0+1),f
	goto	u7987
	decfsz	((??_main+0)^080h+0+2),f
	goto	u7987
	nop2
opt asmopt_pop

	goto	l438
	global	start
	ljmp	start
	opt stack 0
	line	716
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_Wait_Display_Idle

;; *************** function _Wait_Display_Idle *****************
;; Defined at:
;;		line 571 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	571
global __ptext1
__ptext1:	;psect for function _Wait_Display_Idle
psect	text1
	file	"main.c"
	line	571
	global	__size_of_Wait_Display_Idle
	__size_of_Wait_Display_Idle	equ	__end_of_Wait_Display_Idle-_Wait_Display_Idle
	
_Wait_Display_Idle:	
;incstack = 0
	opt	stack 4
; Regs used in _Wait_Display_Idle: [wreg+status,2+status,0]
	line	573
	
l3850:	
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	574
	goto	l417
	
l418:	
	line	575
# 575 "main.c"
clrwdt ;# 
psect	text1
	
l417:	
	line	574
	btfsc	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	goto	u4771
	goto	u4770
u4771:
	goto	l418
u4770:
	line	578
	
l3852:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	((_g_sinkMask)^080h),w	;volatile
iorwf	((_g_sinkMask+1)^080h),w	;volatile
	btfsc	status,2
	goto	u4781
	goto	u4780
u4781:
	goto	l421
u4780:
	line	579
	
l3854:	
	opt asmopt_push
opt asmopt_off
	movlw	65
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Wait_Display_Idle+0)+0),f
	u7997:
decfsz	(??_Wait_Display_Idle+0)+0,f
	goto	u7997
	nop2
opt asmopt_pop

	line	580
	
l421:	
	return
	opt stack 0
GLOBAL	__end_of_Wait_Display_Idle
	__end_of_Wait_Display_Idle:
	signat	_Wait_Display_Idle,89
	global	_Update_LED_Global

;; *************** function _Update_LED_Global *****************
;; Defined at:
;;		line 74 in file "led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1   12[BANK0 ] unsigned char 
;;  s               1   15[BANK0 ] unsigned char 
;;  s               1   19[BANK0 ] unsigned char 
;;  sT0IE           1   11[BANK0 ] unsigned char 
;;  mask            2   17[BANK0 ] unsigned int 
;;  fullBits        2    8[BANK0 ] unsigned int 
;;  i               1   20[BANK0 ] unsigned char 
;;  hasFull         1   16[BANK0 ] unsigned char 
;;  hasChg          1   14[BANK0 ] unsigned char 
;;  hasErr          1   13[BANK0 ] unsigned char 
;;  hasDet          1   10[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0      16       0       0       0
;;Total ram usage:       16 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___bmul
;;		___lwmod
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"led.c"
	line	74
global __ptext2
__ptext2:	;psect for function _Update_LED_Global
psect	text2
	file	"led.c"
	line	74
	global	__size_of_Update_LED_Global
	__size_of_Update_LED_Global	equ	__end_of_Update_LED_Global-_Update_LED_Global
	
_Update_LED_Global:	
;incstack = 0
	opt	stack 3
; Regs used in _Update_LED_Global: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	77
	
l4822:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Update_LED_Global@hasErr)
	line	78
	clrf	(Update_LED_Global@hasChg)
	line	79
	clrf	(Update_LED_Global@hasDet)
	line	80
	clrf	(Update_LED_Global@hasFull)
	line	81
	clrf	(Update_LED_Global@mask)
	clrf	(Update_LED_Global@mask+1)
	line	82
	clrf	(Update_LED_Global@fullBits)
	clrf	(Update_LED_Global@fullBits+1)
	line	85
	clrf	(Update_LED_Global@i)
	line	87
	
l4828:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Global@s)
	line	88
	
l4830:	
		movlw	7
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u7261
	goto	u7260
u7261:
	goto	l4834
u7260:
	line	90
	
l4832:	
	clrf	(Update_LED_Global@hasErr)
	incf	(Update_LED_Global@hasErr),f
	line	91
	goto	l4856
	line	93
	
l4834:	
		movlw	2
	xorwf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u7271
	goto	u7270
u7271:
	goto	l919
u7270:
	
l4836:	
		movlw	3
	xorwf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u7281
	goto	u7280
u7281:
	goto	l919
u7280:
	
l4838:	
		movlw	4
	xorwf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u7291
	goto	u7290
u7291:
	goto	l919
u7290:
	
l4840:	
		movlw	5
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u7301
	goto	u7300
u7301:
	goto	l4842
u7300:
	
l919:	
	line	101
	clrf	(Update_LED_Global@hasChg)
	incf	(Update_LED_Global@hasChg),f
	line	102
	goto	l4856
	line	103
	
l4842:	
		decf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u7311
	goto	u7310
u7311:
	goto	l4848
u7310:
	
l4844:	
		movlw	8
	xorwf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u7321
	goto	u7320
u7321:
	goto	l4848
u7320:
	
l4846:	
		movlw	9
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u7331
	goto	u7330
u7331:
	goto	l4852
u7330:
	line	105
	
l4848:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Update_LED_Global+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Update_LED_Global+0)+0+1
	movlw	0Fh
	subwf	1+(??_Update_LED_Global+0)+0,w
	movlw	096h
	skipnz
	subwf	0+(??_Update_LED_Global+0)+0,w
	skipnc
	goto	u7341
	goto	u7340
u7341:
	goto	l920
u7340:
	line	106
	
l4850:	
	clrf	(Update_LED_Global@hasDet)
	incf	(Update_LED_Global@hasDet),f
	goto	l4856
	line	108
	
l4852:	
		movlw	6
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u7351
	goto	u7350
u7351:
	goto	l920
u7350:
	line	110
	
l4854:	
	clrf	(Update_LED_Global@hasFull)
	incf	(Update_LED_Global@hasFull),f
	goto	l4856
	line	112
	
l920:	
	line	85
	
l4856:	
	incf	(Update_LED_Global@i),f
	
l4858:	
	movlw	low(0Ch)
	subwf	(Update_LED_Global@i),w
	skipc
	goto	u7361
	goto	u7360
u7361:
	goto	l4828
u7360:
	line	120
	
l4860:	
	movf	((Update_LED_Global@hasFull)),w
	btfsc	status,2
	goto	u7371
	goto	u7370
u7371:
	goto	l4886
u7370:
	line	122
	
l4862:	
	clrf	(Update_LED_Global@i)
	line	124
	
l4868:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
		movlw	6
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u7381
	goto	u7380
u7381:
	goto	l4872
u7380:
	line	125
	
l4870:	
	incf	(Update_LED_Global@i),w
	movwf	(??_Update_LED_Global+0)+0
	movlw	01h
	movwf	(??_Update_LED_Global+1)+0
	movlw	0
	movwf	(??_Update_LED_Global+1)+0+1
	goto	u7394
u7395:
	clrc
	rlf	(??_Update_LED_Global+1)+0,f
	rlf	(??_Update_LED_Global+1)+1,f
u7394:
	decfsz	(??_Update_LED_Global+0)+0,f
	goto	u7395
	
	movf	0+(??_Update_LED_Global+1)+0,w
	iorwf	(Update_LED_Global@fullBits),f
	movf	1+(??_Update_LED_Global+1)+0,w
	iorwf	(Update_LED_Global@fullBits+1),f
	line	122
	
l4872:	
	incf	(Update_LED_Global@i),f
	movlw	low(0Ch)
	subwf	(Update_LED_Global@i),w
	skipc
	goto	u7401
	goto	u7400
u7401:
	goto	l4868
u7400:
	line	127
	
l4874:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_elapsedTicks)^080h,w
	addwf	(_s_fullTick)^080h,f
	skipnc
	incf	(_s_fullTick+1)^080h,f
	movf	(_g_elapsedTicks+1)^080h,w
	addwf	(_s_fullTick+1)^080h,f
	line	128
	movlw	02h
	subwf	(_s_fullTick+1)^080h,w
	movlw	0Dh
	skipnz
	subwf	(_s_fullTick)^080h,w
	skipc
	goto	u7411
	goto	u7410
u7411:
	goto	l4878
u7410:
	line	129
	
l4876:	
	movlw	0Dh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@divisor)
	movlw	02h
	movwf	((___lwmod@divisor))+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(_s_fullTick+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_s_fullTick)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_fullTick+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_fullTick)^080h
	line	130
	
l4878:	
	movlw	01h
	subwf	(_s_fullTick+1)^080h,w
	movlw	0F4h
	skipnz
	subwf	(_s_fullTick)^080h,w
	skipnc
	goto	u7421
	goto	u7420
u7421:
	goto	l4882
u7420:
	line	132
	
l4880:	
	bcf	(_g_fullDark/8),(_g_fullDark)&7	;volatile
	bcf	(_g_fullSample/8),(_g_fullSample)&7	;volatile
	line	133
	goto	l4892
	line	134
	
l4882:	
	movlw	02h
	subwf	(_s_fullTick+1)^080h,w
	movlw	08h
	skipnz
	subwf	(_s_fullTick)^080h,w
	skipnc
	goto	u7431
	goto	u7430
u7431:
	goto	l934
u7430:
	line	136
	
l4884:	
	bsf	(_g_fullDark/8),(_g_fullDark)&7	;volatile
	bcf	(_g_fullSample/8),(_g_fullSample)&7	;volatile
	line	137
	goto	l4892
	line	138
	
l934:	
	line	140
	bsf	(_g_fullDark/8),(_g_fullDark)&7	;volatile
	bsf	(_g_fullSample/8),(_g_fullSample)&7	;volatile
	goto	l4892
	line	145
	
l4886:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_fullTick)^080h
	clrf	(_s_fullTick+1)^080h
	line	146
	
l4888:	
	bcf	(_g_fullDark/8),(_g_fullDark)&7	;volatile
	
l4890:	
	bsf	(_g_fullSample/8),(_g_fullSample)&7	;volatile
	line	152
	
l4892:	
	bcf	status, 5	;RP0=0, select bank0
	movf	((Update_LED_Global@hasErr)),w
	btfsc	status,2
	goto	u7441
	goto	u7440
u7441:
	goto	l4912
u7440:
	line	154
	
l4894:	
	clrf	(Update_LED_Global@i)
	line	156
	
l4900:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Global@s_370)
	line	157
	
l4902:	
		movlw	7
	xorwf	((Update_LED_Global@s_370)),w
	btfsc	status,2
	goto	u7451
	goto	u7450
u7451:
	goto	l4908
u7450:
	
l4904:	
		movlw	4
	xorwf	((Update_LED_Global@s_370)),w
	btfsc	status,2
	goto	u7461
	goto	u7460
u7461:
	goto	l4908
u7460:
	
l4906:	
		movlw	5
	xorwf	((Update_LED_Global@s_370)),w
	btfss	status,2
	goto	u7471
	goto	u7470
u7471:
	goto	l4910
u7470:
	line	158
	
l4908:	
	incf	(Update_LED_Global@i),w
	movwf	(??_Update_LED_Global+0)+0
	movlw	01h
	movwf	(??_Update_LED_Global+1)+0
	movlw	0
	movwf	(??_Update_LED_Global+1)+0+1
	goto	u7484
u7485:
	clrc
	rlf	(??_Update_LED_Global+1)+0,f
	rlf	(??_Update_LED_Global+1)+1,f
u7484:
	decfsz	(??_Update_LED_Global+0)+0,f
	goto	u7485
	
	movf	0+(??_Update_LED_Global+1)+0,w
	iorwf	(Update_LED_Global@mask),f
	movf	1+(??_Update_LED_Global+1)+0,w
	iorwf	(Update_LED_Global@mask+1),f
	line	154
	
l4910:	
	incf	(Update_LED_Global@i),f
	movlw	low(0Ch)
	subwf	(Update_LED_Global@i),w
	skipc
	goto	u7491
	goto	u7490
u7491:
	goto	l4900
u7490:
	goto	l943
	line	161
	
l4912:	
	movf	((Update_LED_Global@hasChg)),w
	btfsc	status,2
	goto	u7501
	goto	u7500
u7501:
	goto	l4930
u7500:
	line	163
	
l4914:	
	clrf	(Update_LED_Global@i)
	line	165
	
l4920:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Global@s_371)
	line	166
	
l4922:	
		movlw	4
	xorwf	((Update_LED_Global@s_371)),w
	btfsc	status,2
	goto	u7511
	goto	u7510
u7511:
	goto	l4926
u7510:
	
l4924:	
		movlw	5
	xorwf	((Update_LED_Global@s_371)),w
	btfss	status,2
	goto	u7521
	goto	u7520
u7521:
	goto	l4928
u7520:
	line	167
	
l4926:	
	incf	(Update_LED_Global@i),w
	movwf	(??_Update_LED_Global+0)+0
	movlw	01h
	movwf	(??_Update_LED_Global+1)+0
	movlw	0
	movwf	(??_Update_LED_Global+1)+0+1
	goto	u7534
u7535:
	clrc
	rlf	(??_Update_LED_Global+1)+0,f
	rlf	(??_Update_LED_Global+1)+1,f
u7534:
	decfsz	(??_Update_LED_Global+0)+0,f
	goto	u7535
	
	movf	0+(??_Update_LED_Global+1)+0,w
	iorwf	(Update_LED_Global@mask),f
	movf	1+(??_Update_LED_Global+1)+0,w
	iorwf	(Update_LED_Global@mask+1),f
	line	163
	
l4928:	
	incf	(Update_LED_Global@i),f
	movlw	low(0Ch)
	subwf	(Update_LED_Global@i),w
	skipc
	goto	u7541
	goto	u7540
u7541:
	goto	l4920
u7540:
	goto	l943
	line	170
	
l4930:	
	movf	((Update_LED_Global@hasFull)),w
	btfsc	status,2
	goto	u7551
	goto	u7550
u7551:
	goto	l943
u7550:
	line	174
	
l4932:	
	btfsc	(_g_fullDark/8),(_g_fullDark)&7	;volatile
	goto	u7561
	goto	u7560
u7561:
	goto	l943
u7560:
	line	175
	
l4934:	
	movf	(Update_LED_Global@fullBits+1),w
	movwf	(Update_LED_Global@mask+1)
	movf	(Update_LED_Global@fullBits),w
	movwf	(Update_LED_Global@mask)
	line	183
	
l943:	
	line	184
	movf	(11),w	;volatile
	movwf	(Update_LED_Global@sT0IE)
	
l4936:	
	movlw	low(020h)
	andwf	(Update_LED_Global@sT0IE),f
	line	185
	
l4938:	
	bcf	(11)+(5/8),(5)&7	;volatile
	line	186
	
l4940:	
	movf	((Update_LED_Global@hasErr)),w
	btfsc	status,2
	goto	u7571
	goto	u7570
u7571:
	goto	l4956
u7570:
	line	189
	
l4942:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_elapsedTicks)^080h,w
	addwf	(_s_ledBlinkCnt)^080h,f
	line	190
	
l4944:	
	movlw	low(019h)
	subwf	(_s_ledBlinkCnt)^080h,w
	skipc
	goto	u7581
	goto	u7580
u7581:
	goto	l4948
u7580:
	line	191
	
l4946:	
	clrf	(_s_ledBlinkCnt)^080h
	line	192
	
l4948:	
	movlw	low(0Ch)
	subwf	(_s_ledBlinkCnt)^080h,w
	skipnc
	goto	u7591
	goto	u7590
u7591:
	goto	l955
u7590:
	line	194
	
l4950:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	195
	
l4952:	
	bcf	status, 6	;RP1=0, select bank0
	movf	(Update_LED_Global@mask+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_sinkMask+1)^080h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(Update_LED_Global@mask),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_sinkMask)^080h	;volatile
	line	196
	goto	l4990
	line	197
	
l955:	
	line	199
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	200
	
l4954:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(_g_sinkMask)^080h	;volatile
	clrf	(_g_sinkMask+1)^080h	;volatile
	goto	l4990
	line	203
	
l4956:	
	movf	((Update_LED_Global@hasChg)),w
	btfsc	status,2
	goto	u7601
	goto	u7600
u7601:
	goto	l4966
u7600:
	line	206
	
l4958:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_ledBlinkCnt)^080h
	line	207
	
l4960:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	
l4962:	
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	l4952
	line	210
	
l4966:	
	movf	((Update_LED_Global@hasDet)),w
	btfsc	status,2
	goto	u7611
	goto	u7610
u7611:
	goto	l4974
u7610:
	line	214
	
l4968:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_ledBlinkCnt)^080h
	line	215
	
l4970:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	
l4972:	
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	216
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(_g_sinkMask)^080h	;volatile
	clrf	(_g_sinkMask+1)^080h	;volatile
	line	217
	goto	l4990
	line	218
	
l4974:	
	movf	((Update_LED_Global@hasFull)),w
	btfsc	status,2
	goto	u7621
	goto	u7620
u7621:
	goto	l4984
u7620:
	line	222
	
l4976:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_ledBlinkCnt)^080h
	line	223
	
l4978:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	
l4980:	
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	goto	l4952
	line	229
	
l4984:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_ledBlinkCnt)^080h
	line	230
	
l4986:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	
l4988:	
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	231
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(_g_sinkMask)^080h	;volatile
	clrf	(_g_sinkMask+1)^080h	;volatile
	line	233
	
l4990:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Update_LED_Global@sT0IE),w
	iorwf	(11),f	;volatile
	line	235
	
l964:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Global
	__end_of_Update_LED_Global:
	signat	_Update_LED_Global,89
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK0 ] unsigned int 
;;  dividend        2    2[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       5       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Update_LED_Global
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext3
__ptext3:	;psect for function ___lwmod
psect	text3
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l3680:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u4651
	goto	u4650
u4651:
	goto	l3696
u4650:
	line	14
	
l3682:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l3686
	line	16
	
l3684:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l3686:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u4661
	goto	u4660
u4661:
	goto	l3684
u4660:
	line	20
	
l3688:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u4675
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u4675:
	skipc
	goto	u4671
	goto	u4670
u4671:
	goto	l3692
u4670:
	line	21
	
l3690:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l3692:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l3694:	
	decfsz	(___lwmod@counter),f
	goto	u4681
	goto	u4680
u4681:
	goto	l3688
u4680:
	line	25
	
l3696:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1325:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 76 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1    3[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	76
global __ptext4
__ptext4:	;psect for function _System_Init
psect	text4
	file	"main.c"
	line	76
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	81
	
l3700:	
# 81 "main.c"
nop ;# 
	line	82
# 82 "main.c"
clrwdt ;# 
psect	text4
	line	83
	
l3702:	
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	87
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	88
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	89
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l3704:	
	clrf	(262)^0100h	;volatile
	line	91
	
l3706:	
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l3708:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	94
	
l3710:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l3712:	
	clrf	(135)^080h	;volatile
	line	95
	
l3714:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l3716:	
	clrf	(7)	;volatile
	line	96
	
l3718:	
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	97
	
l3720:	
	clrf	(277)^0100h	;volatile
	line	100
	
l3722:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l3724:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	103
	
l3726:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	104
	
l3728:	
	clrf	(406)^0180h	;volatile
	line	111
	
l3730:	
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	112
	
l3732:	
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	113
	
l3734:	
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	114
	
l3736:	
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	117
	
l3738:	
	fcall	_AD_Init
	line	128
	
l3740:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(1)	;volatile
	line	129
	
l3742:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	130
	
l3744:	
	bcf	(90/8),(90)&7	;volatile
	line	131
	
l3746:	
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	135
	
l3748:	
	clrf	(_g_pwmDuty)	;volatile
	line	136
	
l3750:	
	clrf	(_g_pwmCounter)^080h	;volatile
	line	137
	
l3752:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	138
	
l3754:	
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	139
	
l3756:	
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	140
	
l3758:	
	bcf	(55/8),(55)&7	;volatile
	line	143
	
l3760:	
	clrf	(System_Init@i)
	line	145
	
l3766:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	146
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	147
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	148
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	149
	
l3768:	
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	150
	
l3770:	
	movf	(System_Init@i),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	143
	
l3772:	
	incf	(System_Init@i),f
	
l3774:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u4691
	goto	u4690
u4691:
	goto	l3766
u4690:
	line	154
	
l343:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	23
global __ptext5
__ptext5:	;psect for function _AD_Init
psect	text5
	file	"adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l3440:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
	clrf	(406)^0180h	;volatile
	line	27
	
l3442:	
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l3444:	
	clrf	(150)^080h	;volatile
	line	29
	
l461:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Slot_Charge_Ctrl

;; *************** function _Slot_Charge_Ctrl *****************
;; Defined at:
;;		line 427 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   78[BANK0 ] unsigned char 
;;  vcc_norm        2   62[BANK0 ] unsigned int 
;;  pre             2   76[BANK0 ] unsigned int 
;;  diff            2   74[BANK0 ] int 
;;  vcc_norm_now    2   58[BANK0 ] unsigned int 
;;  vcc_norm_pre    2   56[BANK0 ] unsigned int 
;;  ptTick          2   60[BANK0 ] unsigned int 
;;  pt              1   66[BANK0 ] unsigned char 
;;  v_ref           2   71[BANK0 ] unsigned int 
;;  v_init          2   54[BANK0 ] unsigned int 
;;  newv            2   69[BANK0 ] unsigned int 
;;  charge_ticks    2   67[BANK0 ] unsigned int 
;;  dly             1   73[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      25       0       0       0
;;      Temps:          0       5       0       0       0
;;      Totals:         0      30       0       0       0
;;Total ram usage:       30 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_Adc_Norm
;;		_Detect_BatteryType
;;		_Detect_Classify
;;		_Enter_DiodeTest
;;		_Get_Vcc
;;		_Route_LiIon
;;		_Route_LinearLi
;;		___bmul
;;		___lldiv
;;		___wmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	427
global __ptext6
__ptext6:	;psect for function _Slot_Charge_Ctrl
psect	text6
	file	"charge_mgr.c"
	line	427
	global	__size_of_Slot_Charge_Ctrl
	__size_of_Slot_Charge_Ctrl	equ	__end_of_Slot_Charge_Ctrl-_Slot_Charge_Ctrl
	
_Slot_Charge_Ctrl:	
;incstack = 0
	opt	stack 1
; Regs used in _Slot_Charge_Ctrl: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	movwf	(Slot_Charge_Ctrl@idx)
	line	433
	
l3862:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(_s_work)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	6
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
u4820:
	
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	((??_Slot_Charge_Ctrl+0)+0+2)
	incf	fsr,w
	movwf	((??_Slot_Charge_Ctrl+0)+0+3)
	movf	(??_Slot_Charge_Ctrl+0)+0,w
	movwf	fsr
	bcf	status, 7	;select IRP bank1
	
	movf	((??_Slot_Charge_Ctrl+0)+0+2),w
	movwf	indf
	incf	fsr,w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	((??_Slot_Charge_Ctrl+0)+0+3),w
	movwf	fsr
	decfsz	((??_Slot_Charge_Ctrl+0)+0+1),f
	goto	u4820
	
	line	438
	
l3864:	
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+04h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@charge_ticks_prev+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+04h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@charge_ticks_prev)
	line	439
	
l3866:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_elapsedTicks)^080h,w
	addwf	0+(_s_work)^080h+04h,f
	skipnc
	incf	1+(_s_work)^080h+04h,f
	movf	(_g_elapsedTicks+1)^080h,w
	addwf	1+(_s_work)^080h+04h,f
	line	447
	
l3868:	
		decf	((_s_work)^080h),w
	btfsc	status,2
	goto	u4831
	goto	u4830
u4831:
	goto	l3874
u4830:
	
l3870:	
		movlw	8
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u4841
	goto	u4840
u4841:
	goto	l3874
u4840:
	
l3872:	
		movlw	9
	xorwf	((_s_work)^080h),w
	btfss	status,2
	goto	u4851
	goto	u4850
u4851:
	goto	l3892
u4850:
	
l3874:	
		incf	((_g_detectOwner)^080h),w
	btfsc	status,2
	goto	u4861
	goto	u4860
u4861:
	goto	l3892
u4860:
	
l3876:	
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipnz
	goto	u4871
	goto	u4870
u4871:
	goto	l3892
u4870:
	line	451
	
l3878:	
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectWaiter)^080h),w
	btfss	status,2
	goto	u4881
	goto	u4880
u4881:
	goto	l3884
u4880:
	line	452
	
l3880:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectWaiter)^080h
	goto	l3884
	line	453
	
l591:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l3886
	
l593:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l3886
	
l594:	
	bsf	(51/8),(51)&7	;volatile
	goto	l3886
	
l595:	
	bsf	(50/8),(50)&7	;volatile
	goto	l3886
	
l596:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l3886
	
l597:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l3886
	
l598:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l3886
	
l599:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l3886
	
l600:	
	bsf	(48/8),(48)&7	;volatile
	goto	l3886
	
l601:	
	bsf	(49/8),(49)&7	;volatile
	goto	l3886
	
l602:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l3886
	
l603:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l3886
	
l3884:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l591
	xorlw	1^0	; case 1
	skipnz
	goto	l593
	xorlw	2^1	; case 2
	skipnz
	goto	l594
	xorlw	3^2	; case 3
	skipnz
	goto	l595
	xorlw	4^3	; case 4
	skipnz
	goto	l596
	xorlw	5^4	; case 5
	skipnz
	goto	l597
	xorlw	6^5	; case 6
	skipnz
	goto	l598
	xorlw	7^6	; case 7
	skipnz
	goto	l599
	xorlw	8^7	; case 8
	skipnz
	goto	l600
	xorlw	9^8	; case 9
	skipnz
	goto	l601
	xorlw	10^9	; case 10
	skipnz
	goto	l602
	xorlw	11^10	; case 11
	skipnz
	goto	l603
	goto	l3886
	opt asmopt_pop

	line	454
	
l3886:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_s_work)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+4,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+5,w
	movwf	indf
	goto	l605
	line	459
	
l608:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l3894
	
l610:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l3894
	
l611:	
	bsf	(51/8),(51)&7	;volatile
	goto	l3894
	
l612:	
	bsf	(50/8),(50)&7	;volatile
	goto	l3894
	
l613:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l3894
	
l614:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l3894
	
l615:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l3894
	
l616:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l3894
	
l617:	
	bsf	(48/8),(48)&7	;volatile
	goto	l3894
	
l618:	
	bsf	(49/8),(49)&7	;volatile
	goto	l3894
	
l619:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l3894
	
l620:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l3894
	
l3892:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l608
	xorlw	1^0	; case 1
	skipnz
	goto	l610
	xorlw	2^1	; case 2
	skipnz
	goto	l611
	xorlw	3^2	; case 3
	skipnz
	goto	l612
	xorlw	4^3	; case 4
	skipnz
	goto	l613
	xorlw	5^4	; case 5
	skipnz
	goto	l614
	xorlw	6^5	; case 6
	skipnz
	goto	l615
	xorlw	7^6	; case 7
	skipnz
	goto	l616
	xorlw	8^7	; case 8
	skipnz
	goto	l617
	xorlw	9^8	; case 9
	skipnz
	goto	l618
	xorlw	10^9	; case 10
	skipnz
	goto	l619
	xorlw	11^10	; case 11
	skipnz
	goto	l620
	goto	l3894
	opt asmopt_pop

	line	460
	
l3894:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
		decf	((_s_work)^080h),w
	btfsc	status,2
	goto	u4891
	goto	u4890
u4891:
	goto	l3900
u4890:
	
l3896:	
		movlw	8
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u4901
	goto	u4900
u4901:
	goto	l3900
u4900:
	
l3898:	
		movlw	9
	xorwf	((_s_work)^080h),w
	btfss	status,2
	goto	u4911
	goto	u4910
u4911:
	goto	l3912
u4910:
	line	463
	
l3900:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Slot_Charge_Ctrl@dly)
	
l3902:	
	movlw	low(014h)
	subwf	(Slot_Charge_Ctrl@dly),w
	skipc
	goto	u4921
	goto	u4920
u4921:
	goto	l3906
u4920:
	goto	l3914
	line	464
	
l3906:	
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u8007:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8007
	nop
opt asmopt_pop

	line	463
	
l3908:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Slot_Charge_Ctrl@dly),f
	goto	l3902
	line	468
	
l3912:	
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u8017:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u8017
	nop
opt asmopt_pop

	line	472
	
l3914:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low((((_s_adcChannels)-__stringbase)|8000h))
	movwf	fsr0
	fcall	stringdir
	fcall	_Adc_Norm
	movf	(1+(?_Adc_Norm)),w
	movwf	(Slot_Charge_Ctrl@newv+1)
	movf	(0+(?_Adc_Norm)),w
	movwf	(Slot_Charge_Ctrl@newv)
	line	476
	
l3916:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u4931
	goto	u4930
u4931:
	goto	l3924
u4930:
	
l3918:	
		movlw	4
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u4941
	goto	u4940
u4941:
	goto	l3922
u4940:
	
l3920:	
		movlw	5
	xorwf	((_s_work)^080h),w
	btfss	status,2
	goto	u4951
	goto	u4950
u4951:
	goto	l3924
u4950:
	
l3922:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Slot_Charge_Ctrl@newv+1),w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@newv),w
	skipnc
	goto	u4961
	goto	u4960
u4961:
	goto	l4634
u4960:
	line	478
	
l3924:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@newv+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	1+(_s_work)^080h+02h
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@newv),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+02h
	goto	l4634
	line	487
	
l3926:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u4971
	goto	u4970
u4971:
	goto	l3932
u4970:
	line	489
	
l3928:	
	movlw	09h
	subwf	1+(_s_work)^080h+04h,w
	movlw	060h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u4981
	goto	u4980
u4981:
	goto	l3932
u4980:
	goto	l4636
	line	497
	
l3932:	
		incf	((_g_detectOwner)^080h),w
	btfsc	status,2
	goto	u4991
	goto	u4990
u4991:
	goto	l3936
u4990:
	
l3934:	
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u5001
	goto	u5000
u5001:
	goto	l4636
u5000:
	
l3936:	
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectWaiter)^080h),w
	btfsc	status,2
	goto	u5011
	goto	u5010
u5011:
	goto	l3940
u5010:
	
l3938:	
	movf	(_g_detectWaiter)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipnz
	goto	u5021
	goto	u5020
u5021:
	goto	l3940
u5020:
	goto	l4636
	line	500
	
l3940:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	501
	
l3942:	
	clrf	(_s_work)^080h
	incf	(_s_work)^080h,f
	line	502
	
l3944:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	503
	
l3946:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5034
u5035:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5034:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5035
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	506
	
l3948:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u5041
	goto	u5040
u5041:
	goto	l3952
u5040:
	line	507
	
l3950:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	goto	l4636
	line	509
	
l3952:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l4636
	line	516
	
l3954:	
	bcf	status, 5	;RP0=0, select bank0
	movf	((Slot_Charge_Ctrl@charge_ticks_prev)),w
iorwf	((Slot_Charge_Ctrl@charge_ticks_prev+1)),w
	btfss	status,2
	goto	u5051
	goto	u5050
u5051:
	goto	l3962
u5050:
	
l3956:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(0+(_s_work)^080h+04h),w
iorwf	(1+(_s_work)^080h+04h),w
	btfsc	status,2
	goto	u5061
	goto	u5060
u5061:
	goto	l3962
u5060:
	line	518
	
l3958:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	519
	
l3960:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5074
u5075:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5074:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5075
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	522
	
l3962:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u5081
	goto	u5080
u5081:
	goto	l3966
u5080:
	goto	l4636
	line	537
	
l3966:	
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Slot_Charge_Ctrl@charge_ticks_prev+1),w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@charge_ticks_prev),w
	skipnc
	goto	u5091
	goto	u5090
u5091:
	goto	l3976
u5090:
	
l3968:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u5101
	goto	u5100
u5101:
	goto	l3976
u5100:
	line	539
	
l3970:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	540
	
l3972:	
	movlw	0Bh
	subwf	1+(_s_work)^080h+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5111
	goto	u5110
u5111:
	goto	l4636
u5110:
	line	541
	
l3974:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5124
u5125:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5124:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5125
	
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag+1)^080h,f
	goto	l4636
	line	544
	
l3976:	
	movlw	0Bh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5131
	goto	u5130
u5131:
	goto	l4038
u5130:
	
l3978:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u5141
	goto	u5140
u5141:
	goto	l4038
u5140:
	line	556
	
l3980:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5154
u5155:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5154:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5155
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfss	status,2
	goto	u5161
	goto	u5160
u5161:
	goto	l3994
u5160:
	
l3982:	
		movlw	5
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u5171
	goto	u5170
u5171:
	goto	l3994
u5170:
	
l3984:	
	movlw	0Dh
	subwf	1+(_s_work)^080h+02h,w
	movlw	0ADh
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u5181
	goto	u5180
u5181:
	goto	l3994
u5180:
	line	558
	
l3986:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	559
	
l3988:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	560
	
l3990:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	561
	
l3992:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	562
	goto	l4636
	line	572
	
l3994:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_init)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_init+1)
	line	574
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	bcf	status, 7	;select IRP bank1
	subwf	indf,w
	skipc
	goto	u5191
	goto	u5190
u5191:
	goto	l4018
u5190:
	line	579
	
l3996:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5204
u5205:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5204:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5205
	
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag+1)^080h,f
	line	581
	
l3998:	
	movlw	0Bh
	subwf	1+(_s_work)^080h+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u5211
	goto	u5210
u5211:
	goto	l4006
u5210:
	line	584
	
l4000:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5224
u5225:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5224:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5225
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	585
	
l4002:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	586
	
l4004:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5234
u5235:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5234:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5235
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	587
	goto	l4050
	line	588
	
l4006:	
	movlw	04h
	subwf	1+(_s_work)^080h+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u5241
	goto	u5240
u5241:
	goto	l4016
u5240:
	line	595
	
l4008:	
	movlw	01h
	subwf	1+(_s_work)^080h+04h,w
	movlw	09h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u5251
	goto	u5250
u5251:
	goto	l3950
u5250:
	line	597
	
l4010:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Detect_Classify@fromHighV)
	incf	(Detect_Classify@fromHighV),f
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	598
	goto	l4636
	line	607
	
l4016:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Detect_Classify@fromHighV)
	incf	(Detect_Classify@fromHighV),f
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	608
	goto	l4636
	line	616
	
l4018:	
	movlw	04h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u5261
	goto	u5260
u5261:
	goto	l4022
u5260:
	line	618
	
l4020:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Detect_Classify@fromHighV)
	incf	(Detect_Classify@fromHighV),f
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	619
	goto	l4636
	line	624
	
l4022:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	625
	
l4024:	
	movf	0+(_s_work)^080h+02h,w
	addlw	low(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v_init+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5275
	movf	(Slot_Charge_Ctrl@v_init),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5275:
	skipnc
	goto	u5271
	goto	u5270
u5271:
	goto	l4028
u5270:
	line	626
	
l4026:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l661
	line	628
	
l4028:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	
l661:	
	line	629
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u5281
	goto	u5280
u5281:
	goto	l4032
u5280:
	goto	l4636
	line	632
	
l4032:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5294
u5295:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5294:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5295
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u5301
	goto	u5300
u5301:
	goto	l4036
u5300:
	goto	l4636
	line	634
	
l4036:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l4050
	line	637
	
l4038:	
	movlw	04h
	subwf	1+(_s_work)^080h+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u5311
	goto	u5310
u5311:
	goto	l4050
u5310:
	
l4040:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u5321
	goto	u5320
u5321:
	goto	l4050
u5320:
	line	639
	
l4042:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_ref)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_ref+1)
	line	640
	
l4044:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v_ref+1),w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v_ref),w
	skipnc
	goto	u5331
	goto	u5330
u5331:
	goto	l4050
u5330:
	
l4046:	
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	addlw	low(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v_ref+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5345
	movf	(Slot_Charge_Ctrl@v_ref),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5345:
	skipnc
	goto	u5341
	goto	u5340
u5341:
	goto	l4050
u5340:
	goto	l3950
	line	650
	
l4050:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5354
u5355:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5354:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5355
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u5361
	goto	u5360
u5361:
	goto	l4058
u5360:
	line	652
	
l4052:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5374
u5375:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5374:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5375
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	653
	
l4054:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	654
	
l4056:	
	movlw	low(05h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	655
	goto	l668
	line	658
	
l4058:	
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Detect_BatteryType@voltage+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	664
	
l4060:	
	movf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u5381
	goto	u5380
u5381:
	goto	l668
u5380:
	
l4062:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5391
	goto	u5390
u5391:
	goto	l668
u5390:
	
l4064:	
	movlw	04h
	subwf	1+(_s_work)^080h+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u5401
	goto	u5400
u5401:
	goto	l668
u5400:
	goto	l4056
	line	666
	
l668:	
	line	670
	movlw	01h
	subwf	1+(_s_work)^080h+02h,w
	movlw	0F4h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u5411
	goto	u5410
u5411:
	goto	l4072
u5410:
	line	672
	
l4068:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	673
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u5421
	goto	u5420
u5421:
	goto	l4080
u5420:
	goto	l4636
	line	677
	
l4072:	
		movlw	5
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u5431
	goto	u5430
u5431:
	goto	l4080
u5430:
	
l4074:	
		decf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u5441
	goto	u5440
u5441:
	goto	l4080
u5440:
	
l4076:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u5451
	goto	u5450
u5451:
	goto	l4080
u5450:
	line	679
	
l4078:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	686
	
l4080:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Detect_Classify@fromHighV)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	687
	goto	l4636
	line	692
	
l4082:	
	movlw	0
	subwf	1+(_s_work)^080h+04h,w
	movlw	05h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u5461
	goto	u5460
u5461:
	goto	l4086
u5460:
	goto	l4636
	line	697
	
l4086:	
	fcall	_Get_Vcc
	line	703
	
l4088:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	0D2h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5471
	goto	u5470
u5471:
	goto	l4098
u5470:
	
l4090:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0D2h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u5481
	goto	u5480
u5481:
	goto	l4098
u5480:
	line	705
	
l4092:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_s_work)^080h+01h
	line	706
	clrf	(_s_work)^080h
	line	707
	
l4094:	
	movlw	low(0FFh)
	movwf	(_g_detectOwner)^080h
	line	708
	
l4096:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5494
u5495:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5494:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5495
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	709
	goto	l4636
	line	719
	
l4098:	
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(0+(?___wmul)),w
	movwf	((??_Slot_Charge_Ctrl+0)+0)
	movf	(1+(?___wmul)),w
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
	clrf	((??_Slot_Charge_Ctrl+0)+0+2)
	clrf	((??_Slot_Charge_Ctrl+0)+0+3)
	movlw	0Ch
u5505:
	clrc
	rlf	(??_Slot_Charge_Ctrl+0)+0,f
	rlf	(??_Slot_Charge_Ctrl+0)+1,f
	rlf	(??_Slot_Charge_Ctrl+0)+2,f
	rlf	(??_Slot_Charge_Ctrl+0)+3,f
u5500:
	addlw	-1
	skipz
	goto	u5505
	movf	3+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_pre+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_pre)
	line	720
	movf	(_g_vcc_mv),w
	movwf	(___lldiv@dividend)
	movf	(_g_vcc_mv+1),w
	movwf	((___lldiv@dividend))+1
	clrf	2+((___lldiv@dividend))
	clrf	3+((___lldiv@dividend))
	movlw	0Ch
	movwf	(??_Slot_Charge_Ctrl+0)+0
u5515:
	clrc
	rlf	(___lldiv@dividend),f
	rlf	(___lldiv@dividend+1),f
	rlf	(___lldiv@dividend+2),f
	rlf	(___lldiv@dividend+3),f
	decfsz	(??_Slot_Charge_Ctrl+0)+0
	goto	u5515
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_now+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_now)
	line	722
	
l4100:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	(Slot_Charge_Ctrl@vcc_norm_pre+1),w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u5525
	movf	(Slot_Charge_Ctrl@vcc_norm_pre),w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u5525:
	skipc
	goto	u5521
	goto	u5520
u5521:
	goto	l4110
u5520:
	
l4102:	
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@vcc_norm_now+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5535
	movf	(Slot_Charge_Ctrl@vcc_norm_now),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5535:
	skipc
	goto	u5531
	goto	u5530
u5531:
	goto	l4110
u5530:
	goto	l4092
	line	735
	
l4110:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(012Ch)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(012Ch)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5545
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5545:
	skipnc
	goto	u5541
	goto	u5540
u5541:
	goto	l4118
u5540:
	
l4112:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5551
	goto	u5550
u5551:
	goto	l4118
u5550:
	line	737
	
l4114:	
	movlw	low(02h)
	movwf	0+(_s_work)^080h+01h
	line	738
	movlw	low(07h)
	movwf	(_s_work)^080h
	line	739
	movlw	low(0FFh)
	movwf	(_g_detectOwner)^080h
	goto	l4096
	line	749
	
l4118:	
	swapf	(_g_impData+1),w
	andlw	15
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(0C8h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5565
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5565:
	skipnc
	goto	u5561
	goto	u5560
u5561:
	goto	l4124
u5560:
	
l4120:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Ch
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	01Ch
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u5571
	goto	u5570
u5571:
	goto	l4124
u5570:
	line	751
	
l4122:	
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	752
	goto	l4636
	line	761
	
l4124:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5584
u5585:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5584:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5585
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfss	status,2
	goto	u5591
	goto	u5590
u5591:
	goto	l4136
u5590:
	
l4126:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u5605
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u5605:
	skipnc
	goto	u5601
	goto	u5600
u5601:
	goto	l4136
u5600:
	
l4128:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipc
	incf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	03h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0E9h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipc
	goto	u5611
	goto	u5610
u5611:
	goto	l4136
u5610:
	line	763
	
l4130:	
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	764
	movlw	low(07h)
	movwf	(_s_work)^080h
	line	765
	movlw	low(0FFh)
	movwf	(_g_detectOwner)^080h
	line	766
	
l4132:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5624
u5625:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5624:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5625
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	goto	l3992
	line	775
	
l4136:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Dh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0ADh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u5631
	goto	u5630
u5631:
	goto	l4142
u5630:
	
l4138:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(0C8h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5645
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5645:
	skipc
	goto	u5641
	goto	u5640
u5641:
	goto	l4142
u5640:
	line	777
	
l4140:	
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Enter_DiodeTest
	line	778
	goto	l4636
	line	786
	
l4142:	
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Enter_DiodeTest
	line	788
	goto	l4636
	line	804
	
l4144:	
	movf	(_g_diodeTraceCnt)^080h,w
	addlw	01h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@pt)
	line	805
	
l4146:	
	movf	(Slot_Charge_Ctrl@pt),w
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	07h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(1+(?___wmul)),w
	movwf	(Slot_Charge_Ctrl@ptTick+1)
	movf	(0+(?___wmul)),w
	movwf	(Slot_Charge_Ctrl@ptTick)
	line	806
	
l4148:	
	movf	(Slot_Charge_Ctrl@ptTick+1),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	skipz
	goto	u5655
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@ptTick),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+04h,w
u5655:
	skipnc
	goto	u5651
	goto	u5650
u5651:
	goto	l4152
u5650:
	goto	l4168
	line	809
	
l4152:	
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff)
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	(Slot_Charge_Ctrl@diff),f
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	decf	(Slot_Charge_Ctrl@diff+1),f
	subwf	(Slot_Charge_Ctrl@diff+1),f
	line	810
	rlf	(Slot_Charge_Ctrl@diff+1),w
	rrf	(Slot_Charge_Ctrl@diff+1),f
	rrf	(Slot_Charge_Ctrl@diff),f
	rlf	(Slot_Charge_Ctrl@diff+1),w
	rrf	(Slot_Charge_Ctrl@diff+1),f
	rrf	(Slot_Charge_Ctrl@diff),f
	line	811
	
l4154:	
	movf	(Slot_Charge_Ctrl@diff+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u5665
	movlw	080h
	subwf	(Slot_Charge_Ctrl@diff),w
u5665:

	skipc
	goto	u5661
	goto	u5660
u5661:
	goto	l4158
u5660:
	
l4156:	
	movlw	07Fh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff)
	clrf	(Slot_Charge_Ctrl@diff+1)
	line	812
	
l4158:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@diff+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u5675
	movlw	080h
	subwf	(Slot_Charge_Ctrl@diff),w
u5675:

	skipnc
	goto	u5671
	goto	u5670
u5671:
	goto	l4162
u5670:
	
l4160:	
	movlw	080h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff)
	movlw	0FFh
	movwf	((Slot_Charge_Ctrl@diff))+1
	line	813
	
l4162:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_diodeTraceCnt)^080h,w
	addlw	low(_g_diodeTrace|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@diff),w
	addlw	080h
	bcf	status, 7	;select IRP bank1
	movwf	indf
	
l4164:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_diodeTraceCnt)^080h,f
	line	802
	
l4166:	
	movlw	low(04h)
	subwf	(_g_diodeTraceCnt)^080h,w
	skipc
	goto	u5681
	goto	u5680
u5681:
	goto	l4144
u5680:
	line	826
	
l4168:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	034h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u5691
	goto	u5690
u5691:
	goto	l4178
u5690:
	
l4170:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(0384h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(0384h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u5705
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u5705:
	skipnc
	goto	u5701
	goto	u5700
u5701:
	goto	l4178
u5700:
	line	830
	
l4172:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5715
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5715:
	skipnc
	goto	u5711
	goto	u5710
u5711:
	goto	l4176
u5710:
	line	831
	
l4174:	
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l4636
	line	833
	
l4176:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(Route_LinearLi@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l4636
	line	845
	
l4178:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Bh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0B9h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u5721
	goto	u5720
u5721:
	goto	l4186
u5720:
	
l4180:	
	movlw	0Bh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5731
	goto	u5730
u5731:
	goto	l4186
u5730:
	
l4182:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u5745
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u5745:
	skipnc
	goto	u5741
	goto	u5740
u5741:
	goto	l4186
u5740:
	line	847
	
l4184:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_LinearLi@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	848
	goto	l4636
	line	858
	
l4186:	
	movlw	0Bh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5751
	goto	u5750
u5751:
	goto	l4196
u5750:
	
l4188:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	034h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u5761
	goto	u5760
u5761:
	goto	l4196
u5760:
	goto	l4130
	line	879
	
l4196:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	014h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u5771
	goto	u5770
u5771:
	goto	l4208
u5770:
	
l4198:	
	movlw	08h
	subwf	1+(_s_work)^080h+02h,w
	movlw	035h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5781
	goto	u5780
u5781:
	goto	l4208
u5780:
	
l4200:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u5791
	goto	u5790
u5791:
	goto	l4208
u5790:
	
l4202:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	addlw	low(0A0h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(0A0h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u5805
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u5805:
	skipc
	goto	u5801
	goto	u5800
u5801:
	goto	l4208
u5800:
	
l4204:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u5815
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u5815:
	skipc
	goto	u5811
	goto	u5810
u5811:
	goto	l4208
u5810:
	line	881
	
l4206:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(Route_LinearLi@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	882
	goto	l4636
	line	890
	
l4208:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u5821
	goto	u5820
u5821:
	goto	l4636
u5820:
	line	892
	
l4210:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Slot_Charge_Ctrl@pre)
	line	901
	
l4212:	
	movf	(_g_vcc_mv),w
	movwf	(___lldiv@dividend)
	movf	(_g_vcc_mv+1),w
	movwf	((___lldiv@dividend))+1
	clrf	2+((___lldiv@dividend))
	clrf	3+((___lldiv@dividend))
	movlw	0Ch
	movwf	(??_Slot_Charge_Ctrl+0)+0
u5835:
	clrc
	rlf	(___lldiv@dividend),f
	rlf	(___lldiv@dividend+1),f
	rlf	(___lldiv@dividend+2),f
	rlf	(___lldiv@dividend+3),f
	decfsz	(??_Slot_Charge_Ctrl+0)+0
	goto	u5835
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm)
	line	902
	
l4214:	
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@vcc_norm+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5845
	movf	(Slot_Charge_Ctrl@vcc_norm),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5845:
	skipc
	goto	u5841
	goto	u5840
u5841:
	goto	l4222
u5840:
	line	904
	
l4216:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5855
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5855:
	skipnc
	goto	u5851
	goto	u5850
u5851:
	goto	l4220
u5850:
	line	905
	
l4218:	
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l4636
	line	907
	
l4220:	
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l4636
	line	918
	
l4222:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0ADh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipc
	goto	u5861
	goto	u5860
u5861:
	goto	l4234
u5860:
	
l4224:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u5871
	goto	u5870
u5871:
	goto	l4234
u5870:
	
l4226:	
	movf	(Slot_Charge_Ctrl@pre),w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u5885
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u5885:
	skipc
	goto	u5881
	goto	u5880
u5881:
	goto	l4234
u5880:
	line	920
	
l4228:	
	swapf	(_g_impData+1),w
	andlw	15
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5895
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5895:
	skipnc
	goto	u5891
	goto	u5890
u5891:
	goto	l4232
u5890:
	line	921
	
l4230:	
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l4636
	line	923
	
l4232:	
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l4636
	line	944
	
l4234:	
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	029h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5901
	goto	u5900
u5901:
	goto	l4250
u5900:
	
l4236:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u5911
	goto	u5910
u5911:
	goto	l4250
u5910:
	
l4238:	
	movlw	08h
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	034h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipc
	goto	u5921
	goto	u5920
u5921:
	goto	l4250
u5920:
	
l4240:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0ACh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u5931
	goto	u5930
u5931:
	goto	l4250
u5930:
	
l4242:	
	movlw	0Bh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0B8h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u5941
	goto	u5940
u5941:
	goto	l4246
u5940:
	
l4244:	
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5955
	movf	(Slot_Charge_Ctrl@pre),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5955:
	skipnc
	goto	u5951
	goto	u5950
u5951:
	goto	l4248
u5950:
	
l4246:	
	movf	(Slot_Charge_Ctrl@pre),w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u5965
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u5965:
	skipc
	goto	u5961
	goto	u5960
u5961:
	goto	l4250
u5960:
	line	946
	
l4248:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	947
	goto	l4636
	line	955
	
l4250:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@pre),w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5975
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5975:
	skipnc
	goto	u5971
	goto	u5970
u5971:
	goto	l4130
u5970:
	
l4252:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u5981
	goto	u5980
u5981:
	goto	l4130
u5980:
	
l4254:	
	movlw	07h
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	091h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipc
	goto	u5991
	goto	u5990
u5991:
	goto	l4130
u5990:
	
l4256:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0ACh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u6001
	goto	u6000
u6001:
	goto	l4130
u6000:
	line	957
	
l4258:	
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	958
	goto	l4636
	line	971
	
l4266:	
	movlw	017h
	subwf	1+(_s_work)^080h+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u6011
	goto	u6010
u6011:
	goto	l4270
u6010:
	line	973
	
l4268:	
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	974
	goto	l4636
	line	976
	
l4270:	
	movlw	02h
	subwf	1+(_s_work)^080h+02h,w
	movlw	0EFh
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6021
	goto	u6020
u6021:
	goto	l4276
u6020:
	line	978
	
l4272:	
	movlw	low(03h)
	movwf	(_s_work)^080h
	line	979
	
l4274:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	980
	goto	l4636
	line	982
	
l4276:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6031
	goto	u6030
u6031:
	goto	l4636
u6030:
	goto	l4268
	line	991
	
l4280:	
	movlw	075h
	subwf	1+(_s_work)^080h+04h,w
	movlw	031h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u6041
	goto	u6040
u6041:
	goto	l4284
u6040:
	goto	l4268
	line	996
	
l4284:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6051
	goto	u6050
u6051:
	goto	l4290
u6050:
	line	998
	
l4286:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	999
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u6061
	goto	u6060
u6061:
	goto	l4292
u6060:
	goto	l4268
	line	1007
	
l4290:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	1009
	
l4292:	
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	08Ch
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6071
	goto	u6070
u6071:
	goto	l4636
u6070:
	line	1011
	
l4294:	
	movlw	low(04h)
	movwf	(_s_work)^080h
	line	1012
	
l4296:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	1013
	
l4298:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1014
	
l4300:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1015
	
l4302:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	1016
	
l4304:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l4636
	line	1022
	
l4306:	
	movlw	0EAh
	subwf	1+(_s_work)^080h+04h,w
	movlw	060h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u6081
	goto	u6080
u6081:
	goto	l4312
u6080:
	line	1024
	
l4308:	
	movlw	060h
	subwf	0+(_s_work)^080h+04h,f
	movlw	0EAh
	skipc
	decf	1+(_s_work)^080h+04h,f
	subwf	1+(_s_work)^080h+04h,f
	line	1025
	
l4310:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1030
	
l4312:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(07Fh)
	bsf	status, 7	;select IRP bank3
	andwf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	low(012h)
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u6091
	goto	u6090
u6091:
	goto	l4316
u6090:
	goto	l4268
	line	1039
	
l4316:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6101
	goto	u6100
u6101:
	goto	l4322
u6100:
	
l4318:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6111
	goto	u6110
u6111:
	goto	l4322
u6110:
	goto	l4330
	line	1043
	
l4322:	
	movlw	017h
	subwf	1+(_s_work)^080h+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u6121
	goto	u6120
u6121:
	goto	l4326
u6120:
	goto	l4330
	line	1051
	
l4326:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u6135
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u6135:
	skipnc
	goto	u6131
	goto	u6130
u6131:
	goto	l4330
u6130:
	
l4328:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	1058
	
l4330:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6141
	goto	u6140
u6141:
	goto	l4376
u6140:
	line	1060
	
l4332:	
	movlw	07h
	subwf	1+(_s_work)^080h+02h,w
	movlw	0D0h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u6151
	goto	u6150
u6151:
	goto	l4342
u6150:
	line	1062
	
l4334:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1063
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u6161
	goto	u6160
u6161:
	goto	l4344
u6160:
	line	1065
	
l4336:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1066
	
l4338:	
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l4274
	line	1073
	
l4342:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	1083
	
l4344:	
	movlw	06h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	040h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u6171
	goto	u6170
u6171:
	goto	l4410
u6170:
	line	1085
	
l4346:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	1086
	
l4348:	
	movlw	0Ah
	subwf	1+(_s_work)^080h+02h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6181
	goto	u6180
u6181:
	goto	l4360
u6180:
	
l4350:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u6191
	goto	u6190
u6191:
	goto	l4360
u6190:
	line	1088
	
l4352:	
	movlw	low(05h)
	movwf	(_s_work)^080h
	line	1089
	
l4354:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l4302
	line	1093
	
l4360:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u6205
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u6205:
	skipc
	goto	u6201
	goto	u6200
u6201:
	goto	l4364
u6200:
	line	1095
	
l4362:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	indf,f
	line	1096
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	1097
	goto	l4636
	line	1098
	
l4364:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	(indf),w
	btfsc	status,2
	goto	u6211
	goto	u6210
u6211:
	goto	l4368
u6210:
	goto	l3950
	line	1102
	
l4368:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	btfss	indf,(7)&7
	goto	u6221
	goto	u6220
u6221:
	goto	l4372
u6220:
	goto	l4268
	line	1108
	
l4372:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(7/8),(7)&7
	line	1109
	
l4374:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_work)^080h
	incf	(_s_work)^080h,f
	line	1110
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	1111
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l4636
	line	1120
	
l4376:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u6235
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u6235:
	skipnc
	goto	u6231
	goto	u6230
u6231:
	goto	l4380
u6230:
	
l4378:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipc
	incf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	01h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipnc
	goto	u6241
	goto	u6240
u6241:
	goto	l4382
u6240:
	
l4380:	
	movlw	07h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	0D0h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u6251
	goto	u6250
u6251:
	goto	l4394
u6250:
	line	1122
	
l4382:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1123
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u6261
	goto	u6260
u6261:
	goto	l4386
u6260:
	goto	l4636
	line	1125
	
l4386:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1126
	
l4388:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_work)^080h
	incf	(_s_work)^080h,f
	goto	l4274
	line	1132
	
l4394:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	1140
	
l4396:	
	movlw	017h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u6271
	goto	u6270
u6271:
	goto	l4402
u6270:
	line	1142
	
l4398:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u6285
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u6285:
	skipc
	goto	u6281
	goto	u6280
u6281:
	goto	l4402
u6280:
	line	1143
	
l4400:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	indf,f
	line	1145
	
l4402:	
	movlw	017h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u6291
	goto	u6290
u6291:
	goto	l4410
u6290:
	
l4404:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	(indf),w
	btfss	status,2
	goto	u6301
	goto	u6300
u6301:
	goto	l4410
u6300:
	goto	l4338
	line	1159
	
l4410:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6311
	goto	u6310
u6311:
	goto	l4418
u6310:
	
l4412:	
		decf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6321
	goto	u6320
u6321:
	goto	l4418
u6320:
	line	1161
	
l4414:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l4274
	line	1169
	
l4418:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6331
	goto	u6330
u6331:
	goto	l4426
u6330:
	
l4420:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u6341
	goto	u6340
u6341:
	goto	l4426
u6340:
	line	1171
	
l4422:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1172
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u6351
	goto	u6350
u6351:
	goto	l4636
u6350:
	goto	l4268
	line	1180
	
l4426:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	1182
	
l4428:	
	movlw	0Ch
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	01Ch
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6361
	goto	u6360
u6361:
	goto	l4636
u6360:
	
l4430:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6371
	goto	u6370
u6371:
	goto	l4434
u6370:
	
l4432:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u6381
	goto	u6380
u6381:
	goto	l4636
u6380:
	line	1184
	
l4434:	
	movlw	low(05h)
	movwf	(_s_work)^080h
	line	1185
	
l4436:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	1186
	
l4438:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l4636
	line	1193
	
l4440:	
	movlw	0EAh
	subwf	1+(_s_work)^080h+04h,w
	movlw	061h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u6391
	goto	u6390
u6391:
	goto	l758
u6390:
	line	1194
	
l4442:	
	movlw	low(06h)
	movwf	(_s_work)^080h
	
l758:	
	line	1202
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6401
	goto	u6400
u6401:
	goto	l4448
u6400:
	
l4444:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6411
	goto	u6410
u6411:
	goto	l4448
u6410:
	goto	l4636
	line	1212
	
l4448:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u6421
	goto	u6420
u6421:
	goto	l4470
u6420:
	
l4450:	
	movlw	017h
	subwf	1+(_s_work)^080h+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u6431
	goto	u6430
u6431:
	goto	l4470
u6430:
	
l4452:	
		decf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6441
	goto	u6440
u6441:
	goto	l4470
u6440:
	line	1214
	
l4454:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfss	status,2
	goto	u6451
	goto	u6450
u6451:
	goto	l4458
u6450:
	line	1216
	
l4456:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	1217
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	1218
	goto	l4470
	line	1219
	
l4458:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u6465
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u6465:
	skipc
	goto	u6461
	goto	u6460
u6461:
	goto	l4468
u6460:
	line	1221
	
l4460:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	movlw	low(03h)
	subwf	(indf),w
	skipc
	goto	u6471
	goto	u6470
u6471:
	goto	l762
u6470:
	line	1223
	
l4462:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l4338
	line	1231
	
l4468:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l4470
	line	1232
	
l762:	
	line	1240
	
l4470:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6481
	goto	u6480
u6481:
	goto	l4500
u6480:
	line	1242
	
l4472:	
		decf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6491
	goto	u6490
u6491:
	goto	l4484
u6490:
	line	1244
	
l4474:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1245
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u6501
	goto	u6500
u6501:
	goto	l4478
u6500:
	goto	l4636
	line	1247
	
l4478:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l4414
	line	1252
	
l4484:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6511
	goto	u6510
u6511:
	goto	l4488
u6510:
	goto	l4636
	line	1257
	
l4488:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1258
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u6521
	goto	u6520
u6521:
	goto	l4492
u6520:
	goto	l4636
	line	1260
	
l4492:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1261
	
l4494:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_s_work)^080h+01h
	line	1262
	
l4496:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_work)^080h
	goto	l4274
	line	1272
	
l4500:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6531
	goto	u6530
u6531:
	goto	l4514
u6530:
	line	1274
	
l4502:	
	movlw	07h
	subwf	1+(_s_work)^080h+02h,w
	movlw	0D0h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u6541
	goto	u6540
u6541:
	goto	l4512
u6540:
	line	1276
	
l4504:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1277
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u6551
	goto	u6550
u6551:
	goto	l4530
u6550:
	goto	l4336
	line	1287
	
l4512:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l4530
	line	1292
	
l4514:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u6565
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u6565:
	skipnc
	goto	u6561
	goto	u6560
u6561:
	goto	l4512
u6560:
	
l4516:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipc
	incf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	01h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipc
	goto	u6571
	goto	u6570
u6571:
	goto	l4512
u6570:
	line	1294
	
l4518:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1295
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipc
	goto	u6581
	goto	u6580
u6581:
	goto	l4530
u6580:
	line	1297
	
l4520:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1298
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1300
	
l4522:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_s_work)^080h+01h
	goto	l4388
	line	1316
	
l4530:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6591
	goto	u6590
u6591:
	goto	l4538
u6590:
	
l4532:	
		decf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6601
	goto	u6600
u6601:
	goto	l4538
u6600:
	line	1318
	
l4534:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1319
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u6611
	goto	u6610
u6611:
	goto	l4636
u6610:
	goto	l4268
	line	1327
	
l4538:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l4636
	line	1338
	
l4540:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6621
	goto	u6620
u6621:
	goto	l4558
u6620:
	line	1340
	
l4542:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1341
	
l4544:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u6631
	goto	u6630
u6631:
	goto	l4548
u6630:
	
l4546:	
	movlw	02h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Slot_Charge_Ctrl$344)
	clrf	(_Slot_Charge_Ctrl$344+1)
	goto	l4550
	
l4548:	
	movlw	032h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Slot_Charge_Ctrl$344)
	clrf	(_Slot_Charge_Ctrl$344+1)
	
l4550:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(_Slot_Charge_Ctrl$344+1),w
	xorlw	80h
	sublw	080h
	skipz
	goto	u6645
	movf	(_Slot_Charge_Ctrl$344),w
	subwf	indf,w
u6645:

	skipc
	goto	u6641
	goto	u6640
u6641:
	goto	l4636
u6640:
	line	1343
	
l4552:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l4496
	line	1352
	
l4558:	
	movlw	0Ah
	subwf	1+(_s_work)^080h+02h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u6651
	goto	u6650
u6651:
	goto	l3992
u6650:
	line	1354
	
l4560:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1355
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u6661
	goto	u6660
u6661:
	goto	l4564
u6660:
	goto	l4636
	line	1357
	
l4564:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1358
	
l4566:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	1359
	
l4568:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	1360
	
l4570:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l4354
	line	1373
	
l4580:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6671
	goto	u6670
u6671:
	goto	l4596
u6670:
	line	1375
	
l4582:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1376
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u6681
	goto	u6680
u6681:
	goto	l4586
u6680:
	goto	l4636
	line	1378
	
l4586:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1379
	
l4588:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_s_work)^080h+01h
	line	1380
	
l4590:	
	clrf	(_s_work)^080h
	goto	l4436
	line	1393
	
l4596:	
		movlw	2
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u6691
	goto	u6690
u6691:
	goto	l4600
u6690:
	
l4598:	
		movlw	3
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6701
	goto	u6700
u6701:
	goto	l4616
u6700:
	line	1395
	
l4600:	
	movlw	0Ah
	subwf	1+(_s_work)^080h+02h,w
	movlw	08Dh
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6711
	goto	u6710
u6711:
	goto	l3992
u6710:
	
l4602:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u6724
u6725:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u6724:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u6725
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u6731
	goto	u6730
u6731:
	goto	l3992
u6730:
	line	1397
	
l4604:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1398
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u6741
	goto	u6740
u6741:
	goto	l4386
u6740:
	goto	l4636
	line	1411
	
l4616:	
	movlw	02h
	subwf	1+(_s_work)^080h+02h,w
	movlw	0EFh
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6751
	goto	u6750
u6751:
	goto	l3992
u6750:
	line	1413
	
l4618:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1414
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u6761
	goto	u6760
u6761:
	goto	l4386
u6760:
	goto	l4636
	line	1427
	
l4630:	
	clrf	(_s_work)^080h
	line	1428
	goto	l4636
	line	482
	
l4634:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_s_work)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l3926
	xorlw	1^0	; case 1
	skipnz
	goto	l3954
	xorlw	2^1	; case 2
	skipnz
	goto	l4266
	xorlw	3^2	; case 3
	skipnz
	goto	l4280
	xorlw	4^3	; case 4
	skipnz
	goto	l4306
	xorlw	5^4	; case 5
	skipnz
	goto	l4440
	xorlw	6^5	; case 6
	skipnz
	goto	l4540
	xorlw	7^6	; case 7
	skipnz
	goto	l4580
	xorlw	8^7	; case 8
	skipnz
	goto	l4082
	xorlw	9^8	; case 9
	skipnz
	goto	l4166
	goto	l4630
	opt asmopt_pop

	line	1440
	
l4636:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
		decf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6771
	goto	u6770
u6771:
	goto	l4642
u6770:
	
l4638:	
		movlw	8
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6781
	goto	u6780
u6781:
	goto	l4642
u6780:
	
l4640:	
		movlw	9
	xorwf	((_s_work)^080h),w
	btfss	status,2
	goto	u6791
	goto	u6790
u6791:
	goto	l4646
u6790:
	line	1442
	
l4642:	
		incf	((_g_detectOwner)^080h),w
	btfss	status,2
	goto	u6801
	goto	u6800
u6801:
	goto	l809
u6800:
	line	1443
	
l4644:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	goto	l809
	line	1447
	
l4646:	
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u6811
	goto	u6810
u6811:
	goto	l809
u6810:
	line	1448
	
l4648:	
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	1449
	
l809:	
	line	1455
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_detectWaiter)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u6821
	goto	u6820
u6821:
	goto	l4658
u6820:
	
l4650:	
	bsf	status, 5	;RP0=1, select bank1
		decf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6831
	goto	u6830
u6831:
	goto	l4658
u6830:
	
l4652:	
		movlw	8
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6841
	goto	u6840
u6841:
	goto	l4658
u6840:
	
l4654:	
		movlw	9
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6851
	goto	u6850
u6851:
	goto	l4658
u6850:
	line	1456
	
l4656:	
	movlw	low(0FFh)
	movwf	(_g_detectWaiter)^080h
	line	1458
	
l4658:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_s_work)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+4,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+5,w
	movwf	indf
	line	1467
	
l4660:	
		movlw	2
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6861
	goto	u6860
u6861:
	goto	l4668
u6860:
	
l4662:	
		movlw	3
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6871
	goto	u6870
u6871:
	goto	l4668
u6870:
	
l4664:	
		movlw	4
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6881
	goto	u6880
u6881:
	goto	l4668
u6880:
	
l4666:	
		movlw	5
	xorwf	((_s_work)^080h),w
	btfss	status,2
	goto	u6891
	goto	u6890
u6891:
	goto	l4674
u6890:
	
l4668:	
		incf	((_g_detectOwner)^080h),w
	btfsc	status,2
	goto	u6901
	goto	u6900
u6901:
	goto	l4674
u6900:
	goto	l4672
	line	1469
	
l817:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l605
	
l819:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l605
	
l820:	
	bsf	(51/8),(51)&7	;volatile
	goto	l605
	
l821:	
	bsf	(50/8),(50)&7	;volatile
	goto	l605
	
l822:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l605
	
l823:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l605
	
l824:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l605
	
l825:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l605
	
l826:	
	bsf	(48/8),(48)&7	;volatile
	goto	l605
	
l827:	
	bsf	(49/8),(49)&7	;volatile
	goto	l605
	
l828:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l605
	
l829:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l605
	
l4672:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l817
	xorlw	1^0	; case 1
	skipnz
	goto	l819
	xorlw	2^1	; case 2
	skipnz
	goto	l820
	xorlw	3^2	; case 3
	skipnz
	goto	l821
	xorlw	4^3	; case 4
	skipnz
	goto	l822
	xorlw	5^4	; case 5
	skipnz
	goto	l823
	xorlw	6^5	; case 6
	skipnz
	goto	l824
	xorlw	7^6	; case 7
	skipnz
	goto	l825
	xorlw	8^7	; case 8
	skipnz
	goto	l826
	xorlw	9^8	; case 9
	skipnz
	goto	l827
	xorlw	10^9	; case 10
	skipnz
	goto	l828
	xorlw	11^10	; case 11
	skipnz
	goto	l829
	goto	l605
	opt asmopt_pop

	line	1474
	
l4674:	
		movlw	2
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6911
	goto	u6910
u6911:
	goto	l4688
u6910:
	
l4676:	
		movlw	3
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6921
	goto	u6920
u6921:
	goto	l4688
u6920:
	
l4678:	
		movlw	4
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6931
	goto	u6930
u6931:
	goto	l4688
u6930:
	
l4680:	
		movlw	5
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6941
	goto	u6940
u6941:
	goto	l4688
u6940:
	
l4682:	
		movlw	8
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6951
	goto	u6950
u6951:
	goto	l4686
u6950:
	
l4684:	
		decf	((_s_work)^080h),w
	btfss	status,2
	goto	u6961
	goto	u6960
u6961:
	goto	l4698
u6960:
	
l4686:	
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u6971
	goto	u6970
u6971:
	goto	l4698
u6970:
	
l4688:	
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u6981
	goto	u6980
u6981:
	goto	l4698
u6980:
	
l4690:	
	movf	((_g_vccProtect)^080h),w
	btfss	status,2
	goto	u6991
	goto	u6990
u6991:
	goto	l4698
u6990:
	goto	l4694
	line	1476
	
l839:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	l605
	
l841:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	l605
	
l842:	
	bcf	(51/8),(51)&7	;volatile
	goto	l605
	
l843:	
	bcf	(50/8),(50)&7	;volatile
	goto	l605
	
l844:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	l605
	
l845:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	l605
	
l846:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l605
	
l847:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l605
	
l848:	
	bcf	(48/8),(48)&7	;volatile
	goto	l605
	
l849:	
	bcf	(49/8),(49)&7	;volatile
	goto	l605
	
l850:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l605
	
l851:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l605
	
l4694:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l839
	xorlw	1^0	; case 1
	skipnz
	goto	l841
	xorlw	2^1	; case 2
	skipnz
	goto	l842
	xorlw	3^2	; case 3
	skipnz
	goto	l843
	xorlw	4^3	; case 4
	skipnz
	goto	l844
	xorlw	5^4	; case 5
	skipnz
	goto	l845
	xorlw	6^5	; case 6
	skipnz
	goto	l846
	xorlw	7^6	; case 7
	skipnz
	goto	l847
	xorlw	8^7	; case 8
	skipnz
	goto	l848
	xorlw	9^8	; case 9
	skipnz
	goto	l849
	xorlw	10^9	; case 10
	skipnz
	goto	l850
	xorlw	11^10	; case 11
	skipnz
	goto	l851
	goto	l605
	opt asmopt_pop

	line	1480
	
l4698:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l817
	xorlw	1^0	; case 1
	skipnz
	goto	l819
	xorlw	2^1	; case 2
	skipnz
	goto	l820
	xorlw	3^2	; case 3
	skipnz
	goto	l821
	xorlw	4^3	; case 4
	skipnz
	goto	l822
	xorlw	5^4	; case 5
	skipnz
	goto	l823
	xorlw	6^5	; case 6
	skipnz
	goto	l824
	xorlw	7^6	; case 7
	skipnz
	goto	l825
	xorlw	8^7	; case 8
	skipnz
	goto	l826
	xorlw	9^8	; case 9
	skipnz
	goto	l827
	xorlw	10^9	; case 10
	skipnz
	goto	l828
	xorlw	11^10	; case 11
	skipnz
	goto	l829
	goto	l605
	opt asmopt_pop

	line	1482
	
l605:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_Charge_Ctrl
	__end_of_Slot_Charge_Ctrl:
	signat	_Slot_Charge_Ctrl,4217
	global	___wmul

;; *************** function ___wmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
;; Parameters:    Size  Location     Type
;;  multiplier      2    0[BANK0 ] unsigned int 
;;  multiplicand    2    2[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  product         2    4[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       6       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
global __ptext7
__ptext7:	;psect for function ___wmul
psect	text7
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
	global	__size_of___wmul
	__size_of___wmul	equ	__end_of___wmul-___wmul
	
___wmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___wmul: [wreg+status,2+status,0]
	line	43
	
l3606:	
	clrf	(___wmul@product)
	clrf	(___wmul@product+1)
	line	45
	
l3608:	
	btfss	(___wmul@multiplier),(0)&7
	goto	u4541
	goto	u4540
u4541:
	goto	l3612
u4540:
	line	46
	
l3610:	
	movf	(___wmul@multiplicand),w
	addwf	(___wmul@product),f
	skipnc
	incf	(___wmul@product+1),f
	movf	(___wmul@multiplicand+1),w
	addwf	(___wmul@product+1),f
	line	47
	
l3612:	
	clrc
	rlf	(___wmul@multiplicand),f
	rlf	(___wmul@multiplicand+1),f
	line	48
	
l3614:	
	clrc
	rrf	(___wmul@multiplier+1),f
	rrf	(___wmul@multiplier),f
	line	49
	
l3616:	
	movf	((___wmul@multiplier)),w
iorwf	((___wmul@multiplier+1)),w
	btfss	status,2
	goto	u4551
	goto	u4550
u4551:
	goto	l3608
u4550:
	line	52
	
l3618:	
	movf	(___wmul@product+1),w
	movwf	(?___wmul+1)
	movf	(___wmul@product),w
	movwf	(?___wmul)
	line	53
	
l978:	
	return
	opt stack 0
GLOBAL	__end_of___wmul
	__end_of___wmul:
	signat	___wmul,8314
	global	_Route_LinearLi

;; *************** function _Route_LinearLi *****************
;; Defined at:
;;		line 315 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  pre             2   43[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1   48[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       6       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Route_DetectLi
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	315
global __ptext8
__ptext8:	;psect for function _Route_LinearLi
psect	text8
	file	"charge_mgr.c"
	line	315
	global	__size_of_Route_LinearLi
	__size_of_Route_LinearLi	equ	__end_of_Route_LinearLi-_Route_LinearLi
	
_Route_LinearLi:	
;incstack = 0
	opt	stack 1
; Regs used in _Route_LinearLi: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	movwf	(Route_LinearLi@idx)
	line	317
	
l3520:	
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	318
	
l3522:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Route_LinearLi@idx),w
	movwf	(??_Route_LinearLi+0)+0
	movlw	01h
	movwf	(??_Route_LinearLi+1)+0
	movlw	0
	movwf	(??_Route_LinearLi+1)+0+1
	goto	u4404
u4405:
	clrc
	rlf	(??_Route_LinearLi+1)+0,f
	rlf	(??_Route_LinearLi+1)+1,f
u4404:
	decfsz	(??_Route_LinearLi+0)+0,f
	goto	u4405
	
	comf	(??_Route_LinearLi+1)+0,f
	comf	(??_Route_LinearLi+1)+1,f
	movf	0+(??_Route_LinearLi+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Route_LinearLi+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	319
	
l3524:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Route_LinearLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	btfss	indf,(7)&7
	goto	u4411
	goto	u4410
u4411:
	goto	l3530
u4410:
	line	321
	
l3526:	
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	322
	movlw	low(07h)
	goto	l563
	line	324
	
l3530:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	325
	
l3532:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	326
	
l3534:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Route_LinearLi@pre+1),w
	movwf	(Route_DetectLi@slot_v+1)
	movf	(Route_LinearLi@pre),w
	movwf	(Route_DetectLi@slot_v)
	movf	(Route_LinearLi@idx),w
	fcall	_Route_DetectLi
	line	327
	
l563:	
	return
	opt stack 0
GLOBAL	__end_of_Route_LinearLi
	__end_of_Route_LinearLi:
	signat	_Route_LinearLi,8313
	global	_Route_LiIon

;; *************** function _Route_LiIon *****************
;; Defined at:
;;		line 290 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   46[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Route_DetectLi
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	290
global __ptext9
__ptext9:	;psect for function _Route_LiIon
psect	text9
	file	"charge_mgr.c"
	line	290
	global	__size_of_Route_LiIon
	__size_of_Route_LiIon	equ	__end_of_Route_LiIon-_Route_LiIon
	
_Route_LiIon:	
;incstack = 0
	opt	stack 1
; Regs used in _Route_LiIon: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	movwf	(Route_LiIon@idx)
	line	292
	
l3508:	
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	293
	
l3510:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Route_LiIon@idx),w
	movwf	(??_Route_LiIon+0)+0
	movlw	01h
	movwf	(??_Route_LiIon+1)+0
	movlw	0
	movwf	(??_Route_LiIon+1)+0+1
	goto	u4394
u4395:
	clrc
	rlf	(??_Route_LiIon+1)+0,f
	rlf	(??_Route_LiIon+1)+1,f
u4394:
	decfsz	(??_Route_LiIon+0)+0,f
	goto	u4395
	
	comf	(??_Route_LiIon+1)+0,f
	comf	(??_Route_LiIon+1)+1,f
	movf	0+(??_Route_LiIon+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Route_LiIon+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	294
	
l3512:	
	clrf	0+(_s_work)^080h+01h
	incf	0+(_s_work)^080h+01h,f
	line	295
	
l3514:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	296
	
l3516:	
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_DetectLi@slot_v+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_DetectLi@slot_v)
	movf	(Route_LiIon@idx),w
	fcall	_Route_DetectLi
	line	297
	
l559:	
	return
	opt stack 0
GLOBAL	__end_of_Route_LiIon
	__end_of_Route_LiIon:
	signat	_Route_LiIon,4217
	global	_Enter_DiodeTest

;; *************** function _Enter_DiodeTest *****************
;; Defined at:
;;		line 406 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    3[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=0
	line	406
global __ptext10
__ptext10:	;psect for function _Enter_DiodeTest
psect	text10
	file	"charge_mgr.c"
	line	406
	global	__size_of_Enter_DiodeTest
	__size_of_Enter_DiodeTest	equ	__end_of_Enter_DiodeTest-_Enter_DiodeTest
	
_Enter_DiodeTest:	
;incstack = 0
	opt	stack 3
; Regs used in _Enter_DiodeTest: [wreg+status,2+status,0]
	movwf	(Enter_DiodeTest@idx)
	line	408
	
l3598:	
	movlw	low(09h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	409
	
l3600:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	410
	
l3602:	
	clrf	(_g_diodeTraceCnt)^080h
	line	412
	
l3604:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Enter_DiodeTest@idx),w
	movwf	(??_Enter_DiodeTest+0)+0
	movlw	01h
	movwf	(??_Enter_DiodeTest+1)+0
	movlw	0
	movwf	(??_Enter_DiodeTest+1)+0+1
	goto	u4534
u4535:
	clrc
	rlf	(??_Enter_DiodeTest+1)+0,f
	rlf	(??_Enter_DiodeTest+1)+1,f
u4534:
	decfsz	(??_Enter_DiodeTest+0)+0,f
	goto	u4535
	
	comf	(??_Enter_DiodeTest+1)+0,f
	comf	(??_Enter_DiodeTest+1)+1,f
	movf	0+(??_Enter_DiodeTest+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Enter_DiodeTest+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	413
	
l582:	
	return
	opt stack 0
GLOBAL	__end_of_Enter_DiodeTest
	__end_of_Enter_DiodeTest:
	signat	_Enter_DiodeTest,4217
	global	_Detect_Classify

;; *************** function _Detect_Classify *****************
;; Defined at:
;;		line 342 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  fromHighV       1   43[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   47[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       5       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Get_Vcc
;;		_Route_DetectLi
;;		___lwdiv
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	line	342
global __ptext11
__ptext11:	;psect for function _Detect_Classify
psect	text11
	file	"charge_mgr.c"
	line	342
	global	__size_of_Detect_Classify
	__size_of_Detect_Classify	equ	__end_of_Detect_Classify-_Detect_Classify
	
_Detect_Classify:	
;incstack = 0
	opt	stack 1
; Regs used in _Detect_Classify: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	movwf	(Detect_Classify@idx)
	line	344
	
l3538:	
	movf	((Detect_Classify@fromHighV)),w
	btfsc	status,2
	goto	u4421
	goto	u4420
u4421:
	goto	l3546
u4420:
	line	352
	
l3540:	
	incf	(Detect_Classify@idx),w
	movwf	(??_Detect_Classify+0)+0
	movlw	01h
	movwf	(??_Detect_Classify+1)+0
	movlw	0
	movwf	(??_Detect_Classify+1)+0+1
	goto	u4434
u4435:
	clrc
	rlf	(??_Detect_Classify+1)+0,f
	rlf	(??_Detect_Classify+1)+1,f
u4434:
	decfsz	(??_Detect_Classify+0)+0,f
	goto	u4435
	
	comf	(??_Detect_Classify+1)+0,f
	comf	(??_Detect_Classify+1)+1,f
	movf	0+(??_Detect_Classify+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Detect_Classify+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	353
	
l3542:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Detect_Classify@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	354
	
l3544:	
	movlw	low(05h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	356
	
l3546:	
		movlw	5
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u4441
	goto	u4440
u4441:
	goto	l3568
u4440:
	line	360
	
l3548:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	361
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u4451
	goto	u4450
u4451:
	goto	l3552
u4450:
	goto	l569
	line	365
	
l3552:	
	movf	(Detect_Classify@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	366
	
l3554:	
	fcall	_Get_Vcc
	line	368
	
l3556:	
	movlw	064h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_vcc_mv),w
	addlw	low(032h)
	movwf	(___lwdiv@dividend)
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(_g_impData+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_g_impData)
	movlw	0Ch
	
u4465:
	clrc
	rlf	(_g_impData),f
	rlf	(_g_impData+1),f
	addlw	-1
	skipz
	goto	u4465
	movlw	(0A000h >> 8)
	addwf	(_g_impData+1),f
	movlw	010h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	0
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u4471
	goto	u4470
u4471:
	goto	l3560
u4470:
	
l3558:	
	movf	0+(_s_work)^080h+02h,w
	iorwf	(_g_impData),f
	movf	1+(_s_work)^080h+02h,w
	iorwf	(_g_impData+1),f
	goto	l573
	
l3560:	
	movlw	0FFh
	iorwf	(_g_impData),f
	movlw	0Fh
	iorwf	(_g_impData+1),f
	
l573:	
	line	369
	movlw	low(08h)
	movwf	(_s_work)^080h
	line	370
	
l3562:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	371
	
l3564:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l569
	line	374
	
l3568:	
		decf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u4481
	goto	u4480
u4481:
	goto	l3572
u4480:
	
l3570:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u4491
	goto	u4490
u4491:
	goto	l3582
u4490:
	line	377
	
l3572:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	378
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u4501
	goto	u4500
u4501:
	goto	l3576
u4500:
	goto	l569
	line	380
	
l3576:	
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_DetectLi@slot_v+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_DetectLi@slot_v)
	movf	(Detect_Classify@idx),w
	fcall	_Route_DetectLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	381
	
l3578:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	goto	l569
	line	384
	
l3582:	
	movf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u4511
	goto	u4510
u4511:
	goto	l3588
u4510:
	line	387
	
l3584:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u4521
	goto	u4520
u4521:
	goto	l3588
u4520:
	goto	l569
	line	389
	
l3588:	
	movlw	low(07h)
	movwf	(_s_work)^080h
	goto	l3564
	line	396
	
l569:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_Classify
	__end_of_Detect_Classify:
	signat	_Detect_Classify,8313
	global	_Route_DetectLi

;; *************** function _Route_DetectLi *****************
;; Defined at:
;;		line 218 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  slot_v          2   25[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1   42[BANK0 ] unsigned char 
;;  bat_mv_long     4   37[BANK0 ] unsigned long 
;;  vx_mv           4   33[BANK0 ] unsigned long 
;;  bat_mv          2   31[BANK0 ] unsigned int 
;;  st              1   41[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0      12       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      18       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_Route_LiIon
;;		_Route_LinearLi
;;		_Detect_Classify
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	line	218
global __ptext12
__ptext12:	;psect for function _Route_DetectLi
psect	text12
	file	"charge_mgr.c"
	line	218
	global	__size_of_Route_DetectLi
	__size_of_Route_DetectLi	equ	__end_of_Route_DetectLi-_Route_DetectLi
	
_Route_DetectLi:	
;incstack = 0
	opt	stack 1
; Regs used in _Route_DetectLi: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	movwf	(Route_DetectLi@idx)
	line	231
	
l3372:	
	movf	(Route_DetectLi@slot_v),w
	movwf	(___lmul@multiplier)
	movf	(Route_DetectLi@slot_v+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv)

	
l3374:	
	movlw	0Ch
u4225:
	clrc
	rrf	(Route_DetectLi@vx_mv+3),f
	rrf	(Route_DetectLi@vx_mv+2),f
	rrf	(Route_DetectLi@vx_mv+1),f
	rrf	(Route_DetectLi@vx_mv),f
	addlw	-1
	skipz
	goto	u4225

	line	232
	
l3376:	
	movf	(Route_DetectLi@vx_mv+3),w
	movwf	(___lmul@multiplier+3)
	movf	(Route_DetectLi@vx_mv+2),w
	movwf	(___lmul@multiplier+2)
	movf	(Route_DetectLi@vx_mv+1),w
	movwf	(___lmul@multiplier+1)
	movf	(Route_DetectLi@vx_mv),w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long+3)
	movf	(2+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long+2)
	movf	(1+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long+1)
	movf	(0+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long)

	
l3378:	
	movlw	070h
	addwf	(Route_DetectLi@bat_mv_long),f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Route_DetectLi@bat_mv_long+1),f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Route_DetectLi@bat_mv_long+2),f
	movlw	0
	skipnc
movlw 1
	addwf	(Route_DetectLi@bat_mv_long+3),f
	line	233
	
l3380:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Route_DetectLi+0)+0)
	movlw	01h
	movwf	((??_Route_DetectLi+0)+0+1)
	movlw	0
	movwf	((??_Route_DetectLi+0)+0+2)
	movlw	0
	movwf	((??_Route_DetectLi+0)+0+3)
	movf	(Route_DetectLi@bat_mv_long),w
	addwf	(??_Route_DetectLi+0)+0,f
	movf	(Route_DetectLi@bat_mv_long+1),w
	skipnc
	incfsz	(Route_DetectLi@bat_mv_long+1),w
	goto	u4230
	goto	u4231
u4230:
	addwf	(??_Route_DetectLi+0)+1,f
u4231:
	movf	(Route_DetectLi@bat_mv_long+2),w
	skipnc
	incfsz	(Route_DetectLi@bat_mv_long+2),w
	goto	u4232
	goto	u4233
u4232:
	addwf	(??_Route_DetectLi+0)+2,f
u4233:
	movf	(Route_DetectLi@bat_mv_long+3),w
	skipnc
	incf	(Route_DetectLi@bat_mv_long+3),w
	addwf	(??_Route_DetectLi+0)+3,f
	movf	3+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Route_DetectLi@bat_mv+1)
	movf	(0+(?___lldiv)),w
	movwf	(Route_DetectLi@bat_mv)
	line	236
	
l3382:	
	movlw	0Ch
	subwf	(Route_DetectLi@slot_v+1),w
	movlw	0A3h
	skipnz
	subwf	(Route_DetectLi@slot_v),w
	skipnc
	goto	u4241
	goto	u4240
u4241:
	goto	l3386
u4240:
	
l3384:	
	movlw	0EAh
	subwf	(Route_DetectLi@bat_mv+1),w
	movlw	061h
	skipnz
	subwf	(Route_DetectLi@bat_mv),w
	skipc
	goto	u4251
	goto	u4250
u4251:
	goto	l3398
u4250:
	line	238
	
l3386:	
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u4261
	goto	u4260
u4261:
	goto	l3390
u4260:
	line	240
	
l3388:	
	movlw	low(07h)
	movwf	(Route_DetectLi@st)
	line	241
	goto	l3406
	line	244
	
l3390:	
	movlw	low(05h)
	movwf	(Route_DetectLi@st)
	line	245
	
l3392:	
	clrc
	rlf	(Route_DetectLi@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Route_DetectLi@slot_v),w
	movwf	indf
	incf	fsr0,f
	movf	(Route_DetectLi@slot_v+1),w
	movwf	indf
	line	246
	
l3394:	
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	247
	
l3396:	
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l3406
	line	252
	
l3398:	
	movlw	low(04h)
	movwf	(Route_DetectLi@st)
	line	253
	
l3400:	
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(080h)
	bsf	status, 7	;select IRP bank3
	andwf	indf,f
	line	255
	
l3402:	
	clrc
	rlf	(Route_DetectLi@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Route_DetectLi@slot_v),w
	movwf	indf
	incf	fsr0,f
	movf	(Route_DetectLi@slot_v+1),w
	movwf	indf
	goto	l3396
	line	258
	
l3406:	
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	259
	
l3408:	
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	260
	
l3410:	
	movf	(Route_DetectLi@st),w
	line	261
	
l556:	
	return
	opt stack 0
GLOBAL	__end_of_Route_DetectLi
	__end_of_Route_DetectLi:
	signat	_Route_DetectLi,8313
	global	_Get_Vcc

;; *************** function _Get_Vcc *****************
;; Defined at:
;;		line 81 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   25[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  2   48[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;; This function is called by:
;;		_main
;;		_Detect_Classify
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=0
	line	81
global __ptext13
__ptext13:	;psect for function _Get_Vcc
psect	text13
	file	"charge_mgr.c"
	line	81
	global	__size_of_Get_Vcc
	__size_of_Get_Vcc	equ	__end_of_Get_Vcc-_Get_Vcc
	
_Get_Vcc:	
;incstack = 0
	opt	stack 2
; Regs used in _Get_Vcc: [wreg+status,2+status,0+pclath+cstack]
	line	83
	
l3364:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u4211
	goto	u4210
u4211:
	goto	l517
u4210:
	line	85
	
l3366:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Get_Vcc@pt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Get_Vcc@pt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Get_Vcc@pt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Get_Vcc@pt)

	line	86
	
l3368:	
	movf	(Get_Vcc@pt+1),w
	movwf	(_g_vcc_mv+1)
	movf	(Get_Vcc@pt),w
	movwf	(_g_vcc_mv)
	line	89
	
l517:	
	return
	opt stack 0
GLOBAL	__end_of_Get_Vcc
	__end_of_Get_Vcc:
	signat	_Get_Vcc,90
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 142 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2    0[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	line	142
global __ptext14
__ptext14:	;psect for function _Detect_BatteryType
psect	text14
	file	"charge_mgr.c"
	line	142
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	144
	
l3476:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u4331
	goto	u4330
u4331:
	goto	l3482
u4330:
	line	145
	
l3478:	
	movlw	low(0)
	goto	l540
	line	146
	
l3482:	
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u4341
	goto	u4340
u4341:
	goto	l3488
u4340:
	goto	l3478
	line	161
	
l3488:	
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u4351
	goto	u4350
u4351:
	goto	l3496
u4350:
	
l3490:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u4361
	goto	u4360
u4361:
	goto	l3496
u4360:
	line	162
	
l3492:	
	movlw	low(05h)
	goto	l540
	line	167
	
l3496:	
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u4371
	goto	u4370
u4371:
	goto	l3478
u4370:
	
l3498:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u4381
	goto	u4380
u4381:
	goto	l3478
u4380:
	line	168
	
l3500:	
	movlw	low(01h)
	line	171
	
l540:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_Adc_Norm

;; *************** function _Adc_Norm *****************
;; Defined at:
;;		line 98 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  ch              1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  ch              1   28[BANK0 ] unsigned char 
;;  raw             2   29[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   25[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       3       0       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       6       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=0
	line	98
global __ptext15
__ptext15:	;psect for function _Adc_Norm
psect	text15
	file	"charge_mgr.c"
	line	98
	global	__size_of_Adc_Norm
	__size_of_Adc_Norm	equ	__end_of_Adc_Norm-_Adc_Norm
	
_Adc_Norm:	
;incstack = 0
	opt	stack 2
; Regs used in _Adc_Norm: [wreg+status,2+status,0+pclath+cstack]
	movwf	(Adc_Norm@ch)
	line	101
	
l3458:	
	clrf	(ADC_Sample@adldo)
	movf	(Adc_Norm@ch),w
	fcall	_ADC_Sample
	xorlw	0A5h
	skipnz
	goto	u4311
	goto	u4310
u4311:
	goto	l3464
u4310:
	line	102
	
l3460:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(?_Adc_Norm)
	clrf	(?_Adc_Norm+1)
	goto	l521
	line	103
	
l3464:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Adc_Norm@raw+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Adc_Norm@raw)
	line	104
	
l3466:	
	movf	((_g_vcc_mv)),w
iorwf	((_g_vcc_mv+1)),w
	btfss	status,2
	goto	u4321
	goto	u4320
u4321:
	goto	l3472
u4320:
	line	105
	
l3468:	
	movf	(Adc_Norm@raw+1),w
	movwf	(?_Adc_Norm+1)
	movf	(Adc_Norm@raw),w
	movwf	(?_Adc_Norm)
	goto	l521
	line	106
	
l3472:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	movf	(Adc_Norm@raw),w
	movwf	(___lmul@multiplier)
	movf	(Adc_Norm@raw+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movf	(_g_vcc_mv),w
	movwf	(___lmul@multiplicand)
	movf	(_g_vcc_mv+1),w
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(?_Adc_Norm+1)
	movf	(0+(?___lldiv)),w
	movwf	(?_Adc_Norm)
	line	107
	
l521:	
	return
	opt stack 0
GLOBAL	__end_of_Adc_Norm
	__end_of_Adc_Norm:
	signat	_Adc_Norm,4218
	global	_Sense_Pins_Restore

;; *************** function _Sense_Pins_Restore *****************
;; Defined at:
;;		line 550 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	550
global __ptext16
__ptext16:	;psect for function _Sense_Pins_Restore
psect	text16
	file	"main.c"
	line	550
	global	__size_of_Sense_Pins_Restore
	__size_of_Sense_Pins_Restore	equ	__end_of_Sense_Pins_Restore-_Sense_Pins_Restore
	
_Sense_Pins_Restore:	
;incstack = 0
	opt	stack 4
; Regs used in _Sense_Pins_Restore: [wreg+status,2+status,0]
	line	552
	
l3840:	
	movlw	low(0F0h)
	iorwf	(133)^080h,f	;volatile
	line	553
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(5),f	;volatile
	line	554
	movlw	low(0F0h)
	bsf	status, 6	;RP1=1, select bank2
	iorwf	(276)^0100h,f	;volatile
	line	555
	movlw	low(07h)
	iorwf	(261)^0100h,f	;volatile
	line	556
	
l3842:	
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	557
	
l3844:	
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	558
	
l3846:	
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	559
	
l3848:	
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	560
	
l414:	
	return
	opt stack 0
GLOBAL	__end_of_Sense_Pins_Restore
	__end_of_Sense_Pins_Restore:
	signat	_Sense_Pins_Restore,89
	global	_Sense_Pins_AsSink

;; *************** function _Sense_Pins_AsSink *****************
;; Defined at:
;;		line 538 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=0
	line	538
global __ptext17
__ptext17:	;psect for function _Sense_Pins_AsSink
psect	text17
	file	"main.c"
	line	538
	global	__size_of_Sense_Pins_AsSink
	__size_of_Sense_Pins_AsSink	equ	__end_of_Sense_Pins_AsSink-_Sense_Pins_AsSink
	
_Sense_Pins_AsSink:	
;incstack = 0
	opt	stack 4
; Regs used in _Sense_Pins_AsSink: [wreg+status,2+status,0]
	line	541
	
l3814:	
	movlw	low(0Fh)
	andwf	(147)^080h,f	;volatile
	movlw	low(0Fh)
	andwf	(133)^080h,f	;volatile
	
l3816:	
	bcf	(1076/8)^080h,(1076)&7	;volatile
	
l3818:	
	bcf	(1077/8)^080h,(1077)&7	;volatile
	
l3820:	
	bcf	(1078/8)^080h,(1078)&7	;volatile
	
l3822:	
	bcf	(1079/8)^080h,(1079)&7	;volatile
	line	543
	movlw	low(0CFh)
	andwf	(148)^080h,f	;volatile
	movlw	low(0CFh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(5),f	;volatile
	
l3824:	
	bcf	(52/8),(52)&7	;volatile
	
l3826:	
	bcf	(53/8),(53)&7	;volatile
	line	545
	movlw	low(0C3h)
	bsf	status, 5	;RP0=1, select bank1
	andwf	(140)^080h,f	;volatile
	movlw	low(0C3h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	andwf	(276)^0100h,f	;volatile
	
l3828:	
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	
l3830:	
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	
l3832:	
	bcf	(2108/8)^0100h,(2108)&7	;volatile
	
l3834:	
	bcf	(2109/8)^0100h,(2109)&7	;volatile
	line	547
	movlw	low(0FCh)
	andwf	(265)^0100h,f	;volatile
	movlw	low(0FCh)
	andwf	(261)^0100h,f	;volatile
	
l3836:	
	bcf	(2096/8)^0100h,(2096)&7	;volatile
	
l3838:	
	bcf	(2097/8)^0100h,(2097)&7	;volatile
	line	548
	
l411:	
	return
	opt stack 0
GLOBAL	__end_of_Sense_Pins_AsSink
	__end_of_Sense_Pins_AsSink:
	signat	_Sense_Pins_AsSink,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 109 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   29[BANK0 ] unsigned long 
;;  temp_x10        2   35[BANK0 ] unsigned int 
;;  ntcVal          2   33[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   56[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 100/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	109
global __ptext18
__ptext18:	;psect for function _Read_Temperature
psect	text18
	file	"charge_mgr.c"
	line	109
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 3
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	114
	
l4992:	
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_test_adc)^080h
	line	115
	
l4994:	
		movlw	165
	xorwf	((_test_adc)^080h),w
	btfsc	status,2
	goto	u7631
	goto	u7630
u7631:
	goto	l4998
u7630:
	goto	l526
	line	118
	
l4998:	
	movf	(_adresult+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Read_Temperature@ntcVal+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Read_Temperature@ntcVal)
	line	119
	movlw	0
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u7641
	goto	u7640
u7641:
	goto	l526
u7640:
	
l5000:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u7651
	goto	u7650
u7651:
	goto	l5002
u7650:
	goto	l526
	line	124
	
l5002:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	010h
	movwf	(___lldiv@divisor+1)
	movlw	0
	movwf	(___lldiv@divisor)

	movf	(Read_Temperature@ntcVal),w
	movwf	((??_Read_Temperature+0)+0)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((??_Read_Temperature+0)+0+1)
	clrf	((??_Read_Temperature+0)+0+2)
	clrf	((??_Read_Temperature+0)+0+3)
	movf	0+(??_Read_Temperature+0)+0,w
	subwf	(___lldiv@divisor),f
	movf	1+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)+0,w
	goto	u7665
	goto	u7666
u7665:
	subwf	(___lldiv@divisor+1),f
u7666:
	movf	2+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)+0,w
	goto	u7667
	goto	u7668
u7667:
	subwf	(___lldiv@divisor+2),f
u7668:
	movf	3+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)+0,w
	goto	u7669
	goto	u7660
u7669:
	subwf	(___lldiv@divisor+3),f
u7660:

	movf	(Read_Temperature@ntcVal),w
	movwf	(___lmul@multiplier)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	027h
	movwf	(___lmul@multiplicand+1)
	movlw	010h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Read_Temperature@rt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Read_Temperature@rt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@rt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@rt)

	line	125
	
l5004:	
		movf	(Read_Temperature@rt+3),w
	btfss	status,2
	goto	u7670
	movf	(Read_Temperature@rt+2),w
	btfss	status,2
	goto	u7670
	movlw	39
	subwf	(Read_Temperature@rt+1),w
	skipz
	goto	u7673
	movlw	16
	subwf	(Read_Temperature@rt),w
	skipz
	goto	u7673
u7673:
	btfss	status,0
	goto	u7671
	goto	u7670

u7671:
	goto	l5010
u7670:
	line	126
	
l5006:	
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l5008:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0F0h
	movwf	((??_Read_Temperature+0)+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+3)
	movf	(Read_Temperature@rt),w
	addwf	(??_Read_Temperature+0)+0,f
	movf	(Read_Temperature@rt+1),w
	skipnc
	incfsz	(Read_Temperature@rt+1),w
	goto	u7680
	goto	u7681
u7680:
	addwf	(??_Read_Temperature+0)+1,f
u7681:
	movf	(Read_Temperature@rt+2),w
	skipnc
	incfsz	(Read_Temperature@rt+2),w
	goto	u7682
	goto	u7683
u7682:
	addwf	(??_Read_Temperature+0)+2,f
u7683:
	movf	(Read_Temperature@rt+3),w
	skipnc
	incf	(Read_Temperature@rt+3),w
	addwf	(??_Read_Temperature+0)+3,f
	movf	3+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+3)
	movf	2+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+2)
	movf	1+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+1)
	movf	0+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier)

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(0+(?___lldiv)),w
	subwf	(Read_Temperature@temp_x10),f
	movf	(1+(?___lldiv)),w
	skipc
	decf	(Read_Temperature@temp_x10+1),f
	subwf	(Read_Temperature@temp_x10+1),f
	goto	l5014
	line	128
	
l5010:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0
	movwf	(___lmul@multiplier+3)
	movlw	0
	movwf	(___lmul@multiplier+2)
	movlw	027h
	movwf	(___lmul@multiplier+1)
	movlw	010h
	movwf	(___lmul@multiplier)

	movf	(Read_Temperature@rt),w
	subwf	(___lmul@multiplier),f
	movf	(Read_Temperature@rt+1),w
	skipc
	incfsz	(Read_Temperature@rt+1),w
	subwf	(___lmul@multiplier+1),f
	movf	(Read_Temperature@rt+2),w
	skipc
	incfsz	(Read_Temperature@rt+2),w
	subwf	(___lmul@multiplier+2),f
	movf	(Read_Temperature@rt+3),w
	skipc
	incfsz	(Read_Temperature@rt+3),w
	subwf	(___lmul@multiplier+3),f
	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10)
	
l5012:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10),f
	skipnc
	incf	(Read_Temperature@temp_x10+1),f
	line	129
	
l5014:	
	movlw	0
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipnc
	goto	u7691
	goto	u7690
u7691:
	goto	l532
u7690:
	
l5016:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l532:	
	line	130
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipc
	goto	u7701
	goto	u7700
u7701:
	goto	l5020
u7700:
	
l5018:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)
	movlw	02h
	movwf	((Read_Temperature@temp_x10))+1
	line	134
	
l5020:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u7711
	goto	u7710
u7711:
	goto	l5024
u7710:
	line	135
	
l5022:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	incf	(_g_tempProtect)^080h,f
	goto	l526
	line	136
	
l5024:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u7721
	goto	u7720
u7721:
	goto	l526
u7720:
	line	137
	
l5026:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	line	140
	
l526:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK0 ] unsigned int 
;;  dividend        2    2[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    4[BANK0 ] unsigned int 
;;  counter         1    6[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       7       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Read_Temperature
;;		_Detect_Classify
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext19
__ptext19:	;psect for function ___lwdiv
psect	text19
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l3414:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l3416:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u4271
	goto	u4270
u4271:
	goto	l3436
u4270:
	line	16
	
l3418:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l3422
	line	18
	
l3420:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l3422:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u4281
	goto	u4280
u4281:
	goto	l3420
u4280:
	line	22
	
l3424:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l3426:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u4295
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u4295:
	skipc
	goto	u4291
	goto	u4290
u4291:
	goto	l3432
u4290:
	line	24
	
l3428:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l3430:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l3432:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l3434:	
	decfsz	(___lwdiv@counter),f
	goto	u4301
	goto	u4300
u4301:
	goto	l3424
u4300:
	line	30
	
l3436:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l1315:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    0[BANK0 ] unsigned long 
;;  multiplicand    4    4[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    8[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    0[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Route_DetectLi
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext20
__ptext20:	;psect for function ___lmul
psect	text20
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 1
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l3326:	
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l987:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u4141
	goto	u4140
u4141:
	goto	l3330
u4140:
	line	122
	
l3328:	
	movf	(___lmul@multiplicand),w
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u4151
	addwf	(___lmul@product+1),f
u4151:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u4152
	addwf	(___lmul@product+2),f
u4152:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u4153
	addwf	(___lmul@product+3),f
u4153:

	line	123
	
l3330:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l3332:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u4161
	goto	u4160
u4161:
	goto	l987
u4160:
	line	128
	
l3334:	
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l990:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4   12[BANK0 ] unsigned long 
;;  dividend        4   16[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   20[BANK0 ] unsigned long 
;;  counter         1   24[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4   12[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      13       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Get_Vcc
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Route_DetectLi
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext21
__ptext21:	;psect for function ___lldiv
psect	text21
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l3338:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l3340:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u4171
	goto	u4170
u4171:
	goto	l3360
u4170:
	line	16
	
l3342:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l3346
	line	18
	
l3344:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l3346:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u4181
	goto	u4180
u4181:
	goto	l3344
u4180:
	line	22
	
l3348:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l3350:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u4195
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u4195
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u4195
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u4195:
	skipc
	goto	u4191
	goto	u4190
u4191:
	goto	l3356
u4190:
	line	24
	
l3352:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l3354:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l3356:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l3358:	
	decfsz	(___lldiv@counter),f
	goto	u4201
	goto	u4200
u4201:
	goto	l3348
u4200:
	line	30
	
l3360:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l1262:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    0[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    6[BANK0 ] unsigned char 
;;  j               1    5[BANK0 ] unsigned char 
;;  adsum           4    8[BANK0 ] volatile unsigned long 
;;  ad_temp         2   16[BANK0 ] volatile unsigned int 
;;  admax           2   14[BANK0 ] volatile unsigned int 
;;  admin           2   12[BANK0 ] volatile unsigned int 
;;  i               1    7[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      18       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Get_Vcc
;;		_Adc_Norm
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	49
global __ptext22
__ptext22:	;psect for function _ADC_Sample
psect	text22
	file	"adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 2
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
	movwf	(ADC_Sample@adch)
	line	51
	
l3260:	
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	52
	
l3262:	
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	53
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	54
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	58
	
l3264:	
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u3991
	goto	u3990
u3991:
	goto	l3270
u3990:
	
l3266:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u4001
	goto	u4000
u4001:
	goto	l3270
u4000:
	line	60
	
l3268:	
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	61
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u8027:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u8027
	nop
opt asmopt_pop

	line	62
	goto	l3272
	line	64
	
l3270:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	67
	
l3272:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(ADC_Sample@adch),(4)&7
	goto	u4011
	goto	u4010
u4011:
	goto	l466
u4010:
	line	69
	
l3274:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l3276:	
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(ADC_Sample@adch),f
	line	71
	goto	l3278
	line	72
	
l466:	
	line	73
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l3278:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@i)
	line	79
	
l3284:	
	movf	(ADC_Sample@adch),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u4025:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u4025
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l3286:	
	opt asmopt_push
opt asmopt_off
	movlw	5
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u8037:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u8037
	nop2
opt asmopt_pop

	line	81
	
l3288:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l3290:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	85
	goto	l470
	
l471:	
	line	87
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u4031
	goto	u4030
u4031:
	goto	l470
u4030:
	line	89
	
l3292:	
	movlw	low(0)
	goto	l473
	line	90
	
l470:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u4041
	goto	u4040
u4041:
	goto	l471
u4040:
	line	93
	
l3296:	
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
l3298:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
l3300:	
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u4051
	goto	u4050
u4051:
	goto	l3304
u4050:
	line	98
	
l3302:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	99
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	100
	goto	l476
	line	102
	
l3304:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u4065
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u4065:
	skipnc
	goto	u4061
	goto	u4060
u4061:
	goto	l3308
u4060:
	line	103
	
l3306:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	l476
	line	105
	
l3308:	
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u4075
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u4075:
	skipnc
	goto	u4071
	goto	u4070
u4071:
	goto	l476
u4070:
	line	106
	
l3310:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	108
	
l476:	
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u4081
	addwf	(ADC_Sample@adsum+1),f	;volatile
u4081:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u4082
	addwf	(ADC_Sample@adsum+2),f	;volatile
u4082:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u4083
	addwf	(ADC_Sample@adsum+3),f	;volatile
u4083:

	line	76
	
l3312:	
	incf	(ADC_Sample@i),f
	
l3314:	
	movlw	low(022h)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u4091
	goto	u4090
u4091:
	goto	l3284
u4090:
	line	112
	
l3316:	
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u4105
	goto	u4106
u4105:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u4106:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u4107
	goto	u4108
u4107:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u4108:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u4109
	goto	u4100
u4109:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u4100:

	line	113
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u4115
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u4115
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u4115
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u4115:
	skipc
	goto	u4111
	goto	u4110
u4111:
	goto	l480
u4110:
	line	114
	
l3318:	
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u4125
	goto	u4126
u4125:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u4126:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u4127
	goto	u4128
u4127:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u4128:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u4129
	goto	u4120
u4129:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u4120:

	goto	l3320
	line	115
	
l480:	
	line	116
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	118
	
l3320:	
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u4135:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u4130:
	addlw	-1
	skipz
	goto	u4135
	movf	1+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_adresult+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_adresult)^080h
	line	119
	
l3322:	
	movlw	low(0A5h)
	line	120
	
l473:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Display_Service

;; *************** function _Display_Service *****************
;; Defined at:
;;		line 582 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 800/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	582
global __ptext23
__ptext23:	;psect for function _Display_Service
psect	text23
	file	"main.c"
	line	582
	global	__size_of_Display_Service
	__size_of_Display_Service	equ	__end_of_Display_Service-_Display_Service
	
_Display_Service:	
;incstack = 0
	opt	stack 4
; Regs used in _Display_Service: [wreg+status,2+status,0]
	line	586
	
l3856:	
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	587
	
l3858:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	((_g_sinkMask)^080h),w	;volatile
iorwf	((_g_sinkMask+1)^080h),w	;volatile
	btfss	status,2
	goto	u4791
	goto	u4790
u4791:
	goto	l426
u4790:
	goto	l425
	line	589
	
l427:	
	line	590
# 590 "main.c"
clrwdt ;# 
psect	text23
	
l426:	
	line	589
	btfss	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	goto	u4801
	goto	u4800
u4801:
	goto	l427
u4800:
	goto	l429
	line	591
	
l430:	
	line	592
# 592 "main.c"
clrwdt ;# 
psect	text23
	
l429:	
	line	591
	btfsc	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	goto	u4811
	goto	u4810
u4811:
	goto	l430
u4810:
	line	593
	
l425:	
	return
	opt stack 0
GLOBAL	__end_of_Display_Service
	__end_of_Display_Service:
	signat	_Display_Service,89
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 1500 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2   16[BANK0 ] unsigned int 
;;  s               1   27[BANK0 ] unsigned char 
;;  duty            2   24[BANK0 ] int 
;;  error           2   20[BANK0 ] int 
;;  adjust          2   10[BANK0 ] int 
;;  duty_initial    1   23[BANK0 ] unsigned char 
;;  duty_target     1   22[BANK0 ] unsigned char 
;;  maxV            2   18[BANK0 ] unsigned int 
;;  i               1   26[BANK0 ] unsigned char 
;;  preCount        1   15[BANK0 ] unsigned char 
;;  ccCount         1   14[BANK0 ] unsigned char 
;;  cvCount         1   13[BANK0 ] unsigned char 
;;  hasCharging     1   12[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          0       2       0       0       0
;;      Totals:         0      20       0       0       0
;;Total ram usage:       20 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___awdiv
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	1500
global __ptext24
__ptext24:	;psect for function _CCCV_Control
psect	text24
	file	"charge_mgr.c"
	line	1500
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 3
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1503
	
l4700:	
	clrf	(CCCV_Control@hasCharging)
	line	1504
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	1505
	clrf	(CCCV_Control@cvCount)
	line	1506
	clrf	(CCCV_Control@ccCount)
	line	1507
	clrf	(CCCV_Control@preCount)
	line	1510
	
l4702:	
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u7001
	goto	u7000
u7001:
	goto	l4708
u7000:
	line	1512
	
l4704:	
	movlw	011h
	subwf	(_g_vcc_mv+1),w
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv),w
	skipc
	goto	u7011
	goto	u7010
u7011:
	goto	l4712
u7010:
	line	1513
	
l4706:	
	clrf	(_g_vccProtect)^080h
	goto	l4712
	line	1517
	
l4708:	
	movlw	011h
	subwf	(_g_vcc_mv+1),w
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv),w
	skipnc
	goto	u7021
	goto	u7020
u7021:
	goto	l4712
u7020:
	line	1518
	
l4710:	
	clrf	(_g_vccProtect)^080h
	incf	(_g_vccProtect)^080h,f
	line	1522
	
l4712:	
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u7031
	goto	u7030
u7031:
	goto	l4716
u7030:
	
l4714:	
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u7041
	goto	u7040
u7041:
	goto	l4720
u7040:
	line	1524
	
l4716:	
	clrf	(_g_pwmDuty)	;volatile
	line	1525
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	l879
	line	1530
	
l4720:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(CCCV_Control@i)
	line	1532
	
l4726:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(CCCV_Control@s)
	line	1536
	
l4728:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u7051
	goto	u7050
u7051:
	goto	l884
u7050:
	
l4730:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u7061
	goto	u7060
u7061:
	goto	l884
u7060:
	
l4732:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u7071
	goto	u7070
u7071:
	goto	l884
u7070:
	
l4734:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u7081
	goto	u7080
u7081:
	goto	l884
u7080:
	
l4736:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u7091
	goto	u7090
u7091:
	goto	l882
u7090:
	
l884:	
	line	1538
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	1540
	
l4738:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	1541
	
l4740:	
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u7105
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u7105:
	skipnc
	goto	u7101
	goto	u7100
u7101:
	goto	l4744
u7100:
	
l4742:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	1543
	
l4744:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u7111
	goto	u7110
u7111:
	goto	l4748
u7110:
	line	1544
	
l4746:	
	incf	(CCCV_Control@cvCount),f
	line	1545
	
l4748:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u7121
	goto	u7120
u7121:
	goto	l4752
u7120:
	line	1546
	
l4750:	
	incf	(CCCV_Control@ccCount),f
	line	1547
	
l4752:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u7131
	goto	u7130
u7131:
	goto	l4756
u7130:
	
l4754:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u7141
	goto	u7140
u7141:
	goto	l882
u7140:
	line	1548
	
l4756:	
	incf	(CCCV_Control@preCount),f
	line	1549
	
l882:	
	line	1530
	incf	(CCCV_Control@i),f
	
l4758:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u7151
	goto	u7150
u7151:
	goto	l4726
u7150:
	line	1553
	
l4760:	
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u7161
	goto	u7160
u7161:
	goto	l4766
u7160:
	goto	l4716
	line	1564
	
l4766:	
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u7171
	goto	u7170
u7171:
	goto	l4796
u7170:
	line	1568
	
l4768:	
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u7181
	goto	u7180
u7181:
	goto	l4772
u7180:
	line	1571
	
l4770:	
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	1572
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	1573
	goto	l4780
	line	1574
	
l4772:	
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u7191
	goto	u7190
u7191:
	goto	l4776
u7190:
	line	1577
	
l4774:	
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	1578
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	1579
	goto	l4780
	line	1584
	
l4776:	
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	l879
	line	1588
	
l4780:	
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u7201
	goto	u7200
u7201:
	goto	l4788
u7200:
	line	1591
	
l4782:	
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	1592
	
l4784:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u7211
	goto	u7210
u7211:
	goto	l879
u7210:
	line	1593
	
l4786:	
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	l879
	line	1595
	
l4788:	
	line	1598
	
l4790:	
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	1599
	goto	l879
	line	1614
	
l4796:	
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	1617
	movf	(CCCV_Control@error),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral)^080h,f
	skipnc
	incf	(_g_cvIntegral+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(CCCV_Control@error+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral+1)^080h,f
	line	1618
	
l4798:	
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u7225
	movlw	0C9h
	subwf	(_g_cvIntegral)^080h,w
u7225:

	skipc
	goto	u7221
	goto	u7220
u7221:
	goto	l4802
u7220:
	line	1619
	
l4800:	
	movlw	0C8h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	l4806
	line	1620
	
l4802:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u7235
	movlw	038h
	subwf	(_g_cvIntegral)^080h,w
u7235:

	skipnc
	goto	u7231
	goto	u7230
u7231:
	goto	l4806
u7230:
	line	1621
	
l4804:	
	movlw	038h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	movlw	0FFh
	movwf	((_g_cvIntegral)^080h)+1
	line	1624
	
l4806:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_cvIntegral)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_cvIntegral+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	1625
	
l4808:	
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
l4810:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	1628
	
l4812:	
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u7245
	movlw	021h
	subwf	(CCCV_Control@duty),w
u7245:

	skipc
	goto	u7241
	goto	u7240
u7241:
	goto	l4816
u7240:
	
l4814:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1629
	
l4816:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u7251
	goto	u7250
u7251:
	goto	l4820
u7250:
	
l4818:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1631
	
l4820:	
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	1633
	
l879:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    2[BANK0 ] unsigned char 
;;  product         1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_main
;;		_Slot_Charge_Ctrl
;;		_CCCV_Control
;;		_Update_LED_Global
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext25
__ptext25:	;psect for function ___bmul
psect	text25
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 4
; Regs used in ___bmul: [wreg+status,2+status,0]
	movwf	(___bmul@multiplier)
	line	6
	
l3622:	
	clrf	(___bmul@product)
	line	43
	
l3624:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u4561
	goto	u4560
u4561:
	goto	l3628
u4560:
	line	44
	
l3626:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l3628:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l3630:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u4571
	goto	u4570
u4571:
	goto	l3624
u4570:
	line	50
	
l3632:	
	movf	(___bmul@product),w
	line	51
	
l996:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK0 ] int 
;;  dividend        2    2[BANK0 ] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[BANK0 ] int 
;;  sign            1    5[BANK0 ] unsigned char 
;;  counter         1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       8       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext26
__ptext26:	;psect for function ___awdiv
psect	text26
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
l3636:	
	clrf	(___awdiv@sign)
	line	15
	
l3638:	
	btfss	(___awdiv@divisor+1),7
	goto	u4581
	goto	u4580
u4581:
	goto	l3644
u4580:
	line	16
	
l3640:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
l3642:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
l3644:	
	btfss	(___awdiv@dividend+1),7
	goto	u4591
	goto	u4590
u4591:
	goto	l3650
u4590:
	line	20
	
l3646:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
l3648:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
l3650:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
l3652:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u4601
	goto	u4600
u4601:
	goto	l3672
u4600:
	line	25
	
l3654:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	l3658
	line	27
	
l3656:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
l3658:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u4611
	goto	u4610
u4611:
	goto	l3656
u4610:
	line	31
	
l3660:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
l3662:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u4625
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u4625:
	skipc
	goto	u4621
	goto	u4620
u4621:
	goto	l3668
u4620:
	line	33
	
l3664:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
l3666:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
l3668:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
l3670:	
	decfsz	(___awdiv@counter),f
	goto	u4631
	goto	u4630
u4631:
	goto	l3660
u4630:
	line	39
	
l3672:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u4641
	goto	u4640
u4641:
	goto	l3676
u4640:
	line	40
	
l3674:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
l3676:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
l1108:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 233 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          3       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_PowerOnLedSequence
;;		_Sink_Set
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	233
global __ptext27
__ptext27:	;psect for function _Isr_Timer
psect	text27
	file	"main.c"
	line	233
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 1
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	ljmp	_Isr_Timer
psect	text27
	line	236
	
i1l5030:	
	btfss	(90/8),(90)&7	;volatile
	goto	u773_21
	goto	u773_20
u773_21:
	goto	i1l399
u773_20:
	line	238
	
i1l5032:	
	bcf	(90/8),(90)&7	;volatile
	line	239
	
i1l5034:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(129)^080h	;volatile
	line	240
# 240 "main.c"
clrwdt ;# 
psect	text27
	line	243
	
i1l5036:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(_g_pwmCounter)^080h,f	;volatile
	line	244
	
i1l5038:	
	movlw	low(020h)
	subwf	(_g_pwmCounter)^080h,w	;volatile
	skipc
	goto	u774_21
	goto	u774_20
u774_21:
	goto	i1l5042
u774_20:
	line	245
	
i1l5040:	
	clrf	(_g_pwmCounter)^080h	;volatile
	line	247
	
i1l5042:	
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u775_21
	goto	u775_20
u775_21:
	goto	i1l394
u775_20:
	
i1l5044:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter)^080h,w	;volatile
	skipnc
	goto	u776_21
	goto	u776_20
u776_21:
	goto	i1l394
u776_20:
	line	248
	
i1l5046:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(55/8),(55)&7	;volatile
	goto	i1l5048
	line	249
	
i1l394:	
	line	250
	bcf	status, 5	;RP0=0, select bank0
	bcf	(55/8),(55)&7	;volatile
	line	256
	
i1l5048:	
	movlw	low(050h)
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_hwTickDiv)^080h,f	;volatile
	subwf	((_g_hwTickDiv)^080h),w	;volatile
	skipc
	goto	u777_21
	goto	u777_20
u777_21:
	goto	i1l5058
u777_20:
	line	258
	
i1l5050:	
	clrf	(_g_hwTickDiv)^080h	;volatile
	line	259
	
i1l5052:	
	incf	(_g_hwTick)^080h,f	;volatile
	skipnz
	incf	(_g_hwTick+1)^080h,f	;volatile
	line	260
	
i1l5054:	
	movlw	low(02h)
	subwf	(_g_powerOnPhase)^080h,w
	skipnc
	goto	u778_21
	goto	u778_20
u778_21:
	goto	i1l5058
u778_20:
	line	261
	
i1l5056:	
	incf	(_g_powerOnTimer)^080h,f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1)^080h,f	;volatile
	line	275
	
i1l5058:	
	movlw	low(02h)
	subwf	(_g_powerOnPhase)^080h,w	;volatile
	skipnc
	goto	u779_21
	goto	u779_20
u779_21:
	goto	i1l5064
u779_20:
	line	277
	
i1l5060:	
	fcall	_PowerOnLedSequence
	goto	i1l399
	line	278
	
i1l5062:	
	goto	i1l399
	line	282
	
i1l5064:	
	movf	((_g_tempPhase)^080h),w	;volatile
	btfss	status,2
	goto	u780_21
	goto	u780_20
u780_21:
	goto	i1l5076
u780_20:
	line	284
	
i1l5066:	
	incf	(_g_tempReadRoundCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1)^080h,f	;volatile
	line	285
	
i1l5068:	
	movlw	0
	subwf	(_g_tempReadRoundCnt+1)^080h,w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt)^080h,w	;volatile
	skipc
	goto	u781_21
	goto	u781_20
u781_21:
	goto	i1l5084
u781_20:
	line	287
	
i1l5070:	
	clrf	(_g_tempReadRoundCnt)^080h	;volatile
	clrf	(_g_tempReadRoundCnt+1)^080h	;volatile
	line	288
	
i1l5072:	
	movlw	low(01h)
	movwf	(_g_tempPhase)^080h	;volatile
	line	289
	
i1l5074:	
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	goto	i1l5084
	line	294
	
i1l5076:	
	incf	(_g_tempSettleCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1)^080h,f	;volatile
	line	295
	
i1l5078:	
	movlw	0
	subwf	(_g_tempSettleCnt+1)^080h,w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt)^080h,w	;volatile
	skipc
	goto	u782_21
	goto	u782_20
u782_21:
	goto	i1l5084
u782_20:
	line	297
	
i1l5080:	
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	298
	
i1l5082:	
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	line	299
	clrf	(_g_tempPhase)^080h	;volatile
	line	313
	
i1l5084:	
		movlw	28
	xorwf	((_g_pwmCounter)^080h),w	;volatile
	btfss	status,2
	goto	u783_21
	goto	u783_20
u783_21:
	goto	i1l5094
u783_20:
	line	315
	
i1l5086:	
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u784_21
	goto	u784_20
u784_21:
	goto	i1l399
u784_20:
	
i1l5088:	
	movf	((_g_sinkMask)^080h),w	;volatile
iorwf	((_g_sinkMask+1)^080h),w	;volatile
	btfsc	status,2
	goto	u785_21
	goto	u785_20
u785_21:
	goto	i1l399
u785_20:
	line	317
	
i1l5090:	
	movf	(_g_sinkMask+1)^080h,w	;volatile
	movwf	(Sink_Set@mask+1)
	movf	(_g_sinkMask)^080h,w	;volatile
	movwf	(Sink_Set@mask)
	clrf	(Sink_Set@on)
	incf	(Sink_Set@on),f
	fcall	_Sink_Set
	line	318
	
i1l5092:	
	bsf	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	goto	i1l399
	line	321
	
i1l5094:	
	movf	((_g_pwmCounter)^080h),w
	btfss	status,2
	goto	u786_21
	goto	u786_20
u786_21:
	goto	i1l399
u786_20:
	line	323
	
i1l5096:	
	btfss	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	goto	u787_21
	goto	u787_20
u787_21:
	goto	i1l5062
u787_20:
	line	327
	
i1l5098:	
	movlw	0FFh
	movwf	(Sink_Set@mask)
	movlw	0Fh
	movwf	((Sink_Set@mask))+1
	clrf	(Sink_Set@on)
	fcall	_Sink_Set
	line	328
	
i1l5100:	
	bcf	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	line	332
	
i1l399:	
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	_Sink_Set

;; *************** function _Sink_Set *****************
;; Defined at:
;;		line 207 in file "main.c"
;; Parameters:    Size  Location     Type
;;  mask            2    1[COMMON] unsigned int 
;;  on              1    3[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  i               1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         3       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		_Sink_Slot_Off
;;		_Sink_Slot_On
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=0
	line	207
global __ptext28
__ptext28:	;psect for function _Sink_Set
psect	text28
	file	"main.c"
	line	207
	global	__size_of_Sink_Set
	__size_of_Sink_Set	equ	__end_of_Sink_Set-_Sink_Set
	
_Sink_Set:	
;incstack = 0
	opt	stack 1
; Regs used in _Sink_Set: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	210
	
i1l3776:	
	clrf	(Sink_Set@i)
	line	211
	
i1l382:	
	line	212
	btfss	(Sink_Set@mask),(0)&7
	goto	u470_21
	goto	u470_20
u470_21:
	goto	i1l3788
u470_20:
	line	214
	
i1l3782:	
	movf	((Sink_Set@on)),w
	btfsc	status,2
	goto	u471_21
	goto	u471_20
u471_21:
	goto	i1l3786
u471_20:
	line	215
	
i1l3784:	
	movf	(Sink_Set@i),w
	fcall	_Sink_Slot_On
	goto	i1l3788
	line	217
	
i1l3786:	
	movf	(Sink_Set@i),w
	fcall	_Sink_Slot_Off
	line	219
	
i1l3788:	
	clrc
	rrf	(Sink_Set@mask+1),f
	rrf	(Sink_Set@mask),f
	line	210
	
i1l3790:	
	incf	(Sink_Set@i),f
	
i1l3792:	
	movlw	low(0Ch)
	subwf	(Sink_Set@i),w
	skipc
	goto	u472_21
	goto	u472_20
u472_21:
	goto	i1l382
u472_20:
	line	221
	
i1l387:	
	return
	opt stack 0
GLOBAL	__end_of_Sink_Set
	__end_of_Sink_Set:
	signat	_Sink_Set,8313
	global	_Sink_Slot_On

;; *************** function _Sink_Slot_On *****************
;; Defined at:
;;		line 166 in file "main.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    0[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 0/100
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         1       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Sink_Set
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=0
	line	166
global __ptext29
__ptext29:	;psect for function _Sink_Slot_On
psect	text29
	file	"main.c"
	line	166
	global	__size_of_Sink_Slot_On
	__size_of_Sink_Slot_On	equ	__end_of_Sink_Slot_On-_Sink_Slot_On
	
_Sink_Slot_On:	
;incstack = 0
	opt	stack 1
; Regs used in _Sink_Slot_On: [wreg-fsr0h+status,2+status,0]
	movwf	(Sink_Slot_On@idx)
	line	168
	
i1l3446:	
	goto	i1l3450
	line	170
	
i1l347:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(265)^0100h+(1/8),(1)&7	;volatile
	bcf	(261)^0100h+(1/8),(1)&7	;volatile
	bcf	(2097/8)^0100h,(2097)&7	;volatile
	goto	i1l361
	line	171
	
i1l349:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(265)^0100h+(0/8),(0)&7	;volatile
	bcf	(261)^0100h+(0/8),(0)&7	;volatile
	bcf	(2096/8)^0100h,(2096)&7	;volatile
	goto	i1l361
	line	172
	
i1l350:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(148)^080h+(4/8),(4)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	(5)+(4/8),(4)&7	;volatile
	bcf	(52/8),(52)&7	;volatile
	goto	i1l361
	line	173
	
i1l351:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(148)^080h+(5/8),(5)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	(5)+(5/8),(5)&7	;volatile
	bcf	(53/8),(53)&7	;volatile
	goto	i1l361
	line	174
	
i1l352:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(147)^080h+(5/8),(5)&7	;volatile
	bcf	(133)^080h+(5/8),(5)&7	;volatile
	bcf	(1077/8)^080h,(1077)&7	;volatile
	goto	i1l361
	line	175
	
i1l353:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(147)^080h+(4/8),(4)&7	;volatile
	bcf	(133)^080h+(4/8),(4)&7	;volatile
	bcf	(1076/8)^080h,(1076)&7	;volatile
	goto	i1l361
	line	176
	
i1l354:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(140)^080h+(4/8),(4)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(276)^0100h+(4/8),(4)&7	;volatile
	bcf	(2108/8)^0100h,(2108)&7	;volatile
	goto	i1l361
	line	177
	
i1l355:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(140)^080h+(5/8),(5)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(276)^0100h+(5/8),(5)&7	;volatile
	bcf	(2109/8)^0100h,(2109)&7	;volatile
	goto	i1l361
	line	178
	
i1l356:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(140)^080h+(3/8),(3)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(276)^0100h+(3/8),(3)&7	;volatile
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l361
	line	179
	
i1l357:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(140)^080h+(2/8),(2)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(276)^0100h+(2/8),(2)&7	;volatile
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l361
	line	180
	
i1l358:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(147)^080h+(7/8),(7)&7	;volatile
	bcf	(133)^080h+(7/8),(7)&7	;volatile
	bcf	(1079/8)^080h,(1079)&7	;volatile
	goto	i1l361
	line	181
	
i1l359:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(147)^080h+(6/8),(6)&7	;volatile
	bcf	(133)^080h+(6/8),(6)&7	;volatile
	bcf	(1078/8)^080h,(1078)&7	;volatile
	goto	i1l361
	line	168
	
i1l3450:	
	movf	(Sink_Slot_On@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l347
	xorlw	1^0	; case 1
	skipnz
	goto	i1l349
	xorlw	2^1	; case 2
	skipnz
	goto	i1l350
	xorlw	3^2	; case 3
	skipnz
	goto	i1l351
	xorlw	4^3	; case 4
	skipnz
	goto	i1l352
	xorlw	5^4	; case 5
	skipnz
	goto	i1l353
	xorlw	6^5	; case 6
	skipnz
	goto	i1l354
	xorlw	7^6	; case 7
	skipnz
	goto	i1l355
	xorlw	8^7	; case 8
	skipnz
	goto	i1l356
	xorlw	9^8	; case 9
	skipnz
	goto	i1l357
	xorlw	10^9	; case 10
	skipnz
	goto	i1l358
	xorlw	11^10	; case 11
	skipnz
	goto	i1l359
	goto	i1l361
	opt asmopt_pop

	line	184
	
i1l361:	
	return
	opt stack 0
GLOBAL	__end_of_Sink_Slot_On
	__end_of_Sink_Slot_On:
	signat	_Sink_Slot_On,4217
	global	_Sink_Slot_Off

;; *************** function _Sink_Slot_Off *****************
;; Defined at:
;;		line 186 in file "main.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    0[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 0/100
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         1       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Sink_Set
;; This function uses a non-reentrant model
;;
psect	text30,local,class=CODE,delta=2,merge=1,group=0
	line	186
global __ptext30
__ptext30:	;psect for function _Sink_Slot_Off
psect	text30
	file	"main.c"
	line	186
	global	__size_of_Sink_Slot_Off
	__size_of_Sink_Slot_Off	equ	__end_of_Sink_Slot_Off-_Sink_Slot_Off
	
_Sink_Slot_Off:	
;incstack = 0
	opt	stack 1
; Regs used in _Sink_Slot_Off: [wreg-fsr0h+status,2+status,0]
	movwf	(Sink_Slot_Off@idx)
	line	188
	
i1l3452:	
	goto	i1l3456
	line	190
	
i1l365:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(261)^0100h+(1/8),(1)&7	;volatile
	bsf	(265)^0100h+(1/8),(1)&7	;volatile
	goto	i1l379
	line	191
	
i1l367:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(261)^0100h+(0/8),(0)&7	;volatile
	bsf	(265)^0100h+(0/8),(0)&7	;volatile
	goto	i1l379
	line	192
	
i1l368:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(5)+(4/8),(4)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(148)^080h+(4/8),(4)&7	;volatile
	goto	i1l379
	line	193
	
i1l369:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(5)+(5/8),(5)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(148)^080h+(5/8),(5)&7	;volatile
	goto	i1l379
	line	194
	
i1l370:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(133)^080h+(5/8),(5)&7	;volatile
	bsf	(147)^080h+(5/8),(5)&7	;volatile
	goto	i1l379
	line	195
	
i1l371:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(133)^080h+(4/8),(4)&7	;volatile
	bsf	(147)^080h+(4/8),(4)&7	;volatile
	goto	i1l379
	line	196
	
i1l372:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(276)^0100h+(4/8),(4)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(140)^080h+(4/8),(4)&7	;volatile
	goto	i1l379
	line	197
	
i1l373:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(276)^0100h+(5/8),(5)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(140)^080h+(5/8),(5)&7	;volatile
	goto	i1l379
	line	198
	
i1l374:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(276)^0100h+(3/8),(3)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(140)^080h+(3/8),(3)&7	;volatile
	goto	i1l379
	line	199
	
i1l375:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(276)^0100h+(2/8),(2)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(140)^080h+(2/8),(2)&7	;volatile
	goto	i1l379
	line	200
	
i1l376:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(133)^080h+(7/8),(7)&7	;volatile
	bsf	(147)^080h+(7/8),(7)&7	;volatile
	goto	i1l379
	line	201
	
i1l377:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(133)^080h+(6/8),(6)&7	;volatile
	bsf	(147)^080h+(6/8),(6)&7	;volatile
	goto	i1l379
	line	188
	
i1l3456:	
	movf	(Sink_Slot_Off@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l365
	xorlw	1^0	; case 1
	skipnz
	goto	i1l367
	xorlw	2^1	; case 2
	skipnz
	goto	i1l368
	xorlw	3^2	; case 3
	skipnz
	goto	i1l369
	xorlw	4^3	; case 4
	skipnz
	goto	i1l370
	xorlw	5^4	; case 5
	skipnz
	goto	i1l371
	xorlw	6^5	; case 6
	skipnz
	goto	i1l372
	xorlw	7^6	; case 7
	skipnz
	goto	i1l373
	xorlw	8^7	; case 8
	skipnz
	goto	i1l374
	xorlw	9^8	; case 9
	skipnz
	goto	i1l375
	xorlw	10^9	; case 10
	skipnz
	goto	i1l376
	xorlw	11^10	; case 11
	skipnz
	goto	i1l377
	goto	i1l379
	opt asmopt_pop

	line	204
	
i1l379:	
	return
	opt stack 0
GLOBAL	__end_of_Sink_Slot_Off
	__end_of_Sink_Slot_Off:
	signat	_Sink_Slot_Off,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 255 in file "led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text31,local,class=CODE,delta=2,merge=1,group=0
	file	"led.c"
	line	255
global __ptext31
__ptext31:	;psect for function _PowerOnLedSequence
psect	text31
	file	"led.c"
	line	255
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 2
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	259
	
i1l3794:	
	movf	((_g_powerOnPhase)^080h),w	;volatile
	btfss	status,2
	goto	u473_21
	goto	u473_20
u473_21:
	goto	i1l3804
u473_20:
	line	262
	
i1l3796:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	263
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	264
	
i1l3798:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u474_21
	goto	u474_20
u474_21:
	goto	i1l972
u474_20:
	line	266
	
i1l3800:	
	clrf	(_g_powerOnTimer)^080h	;volatile
	clrf	(_g_powerOnTimer+1)^080h	;volatile
	line	267
	
i1l3802:	
	movlw	low(01h)
	movwf	(_g_powerOnPhase)^080h	;volatile
	goto	i1l972
	line	270
	
i1l3804:	
		decf	((_g_powerOnPhase)^080h),w	;volatile
	btfss	status,2
	goto	u475_21
	goto	u475_20
u475_21:
	goto	i1l972
u475_20:
	line	273
	
i1l3806:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	274
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	275
	
i1l3808:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u476_21
	goto	u476_20
u476_21:
	goto	i1l972
u476_20:
	line	277
	
i1l3810:	
	clrf	(_g_powerOnTimer)^080h	;volatile
	clrf	(_g_powerOnTimer+1)^080h	;volatile
	line	278
	
i1l3812:	
	movlw	low(02h)
	movwf	(_g_powerOnPhase)^080h	;volatile
	line	282
	
i1l972:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
