opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_ChargeProcess_Slot
	FNCALL	_main,_Do_AdcSample
	FNCALL	_main,_Do_NtcRead
	FNCALL	_main,_Print_DetectLog
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_System_Init
	FNCALL	_main,_uart_send_number
	FNCALL	_main,_uart_send_string
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_Print_DetectLog,_uart_send_char
	FNCALL	_Print_DetectLog,_uart_send_number
	FNCALL	_Print_DetectLog,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_Do_NtcRead,_Read_Temperature
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Do_AdcSample,_ADC_Sample
	FNCALL	_Do_AdcSample,___bmul
	FNCALL	_ChargeProcess_Slot,_ADC_Sample
	FNCALL	_ChargeProcess_Slot,_Detect_BatteryType
	FNCALL	_ChargeProcess_Slot,___bmul
	FNCALL	_ChargeProcess_Slot,___lldiv
	FNCALL	_ChargeProcess_Slot,___lmul
	FNCALL	_ChargeProcess_Slot,___lwdiv
	FNCALL	_ChargeProcess_Slot,___wmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_CCCV_Control
	FNCALL	_Isr_Timer,_Charging_Control
	FNCALL	_Isr_Timer,_Led_BlinkProcess
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Update_LED_Slot
	FNCALL	_Isr_Timer,i1_ADC_Sample
	FNCALL	_Isr_Timer,i1___lldiv
	FNCALL	_Charging_Control,i1___bmul
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,i1___bmul
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_temperature
	global	_g_vcc_mv
	global	_g_impCheckSlot
psect	idataBANK0,class=CODE,space=0,delta=2,noexec
global __pidataBANK0
__pidataBANK0:
	file	"charge_mgr.c"
	line	12

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	file	"main.c"
	line	15

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

	file	"charge_mgr.c"
	line	19

;initializer for _g_impCheckSlot
	retlw	0FFh
	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"main.c"
	line	47
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_powerOnTimer
	global	_g_vccProtect
	global	_g_tempProtect
	global	_g_dbgNewType
	global	_g_dbgNewState
	global	_g_dbgOldState
	global	_g_dbgSlot
	global	_g_tempPhase
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_g_pwmDuty
	global	_g_scanPhase
	global	_g_scanIndex
	global	_g_detectLogType
	global	_g_detectLogSlot
	global	_test_adc
	global	_g_blinkTick
	global	_adresult
	global	_g_dbgDetectFlag
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_adcBusy
	global	_g_doAdcSample
	global	_g_detectLogFlag
	global	_g_detectLowCnt
	global	_g_highVFlag
	global	_g_impData
	global	_g_capFlag
	global	_g_dbgVoltage
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_cvIntegral
	global	_g_slot
	global	_g_slotRefV
	global	_g_stableCnt
	global	_g_ovCnt
	global	_g_ccBlocks
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_GIE
_GIE	set	0x5F
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RC4
_RC4	set	0x834
	global	_RD0
_RD0	set	0x838
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD1
_RD1	set	0x839
	global	_RC5
_RC5	set	0x835
	global	_RC3
_RC3	set	0x833
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_32:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_33:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_31:	
	retlw	58	;':'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	100	;'d'
	retlw	101	;'e'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	101	;'e'
	retlw	100	;'d'
	retlw	33	;'!'
	retlw	32	;' '
	retlw	78	;'N'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	32	;' '
	retlw	99	;'c'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	103	;'g'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_34:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	45	;'-'
	retlw	105	;'i'
	retlw	111	;'o'
	retlw	110	;'n'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_8:	
	retlw	67	;'C'
	retlw	32	;' '
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	95	;'_'
	retlw	76	;'L'
	retlw	79	;'O'
	retlw	67	;'C'
	retlw	75	;'K'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_36:	
	retlw	68	;'D'
	retlw	66	;'B'
	retlw	71	;'G'
	retlw	58	;':'
	retlw	32	;' '
	retlw	115	;'s'
	retlw	108	;'l'
	retlw	111	;'o'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_35:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_11:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_37:	
	retlw	32	;' '
	retlw	111	;'o'
	retlw	108	;'l'
	retlw	100	;'d'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_38:	
	retlw	32	;' '
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	119	;'w'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_25:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	73	;'I'
	retlw	79	;'O'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_23:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_27:	
	retlw	32	;' '
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_40:	
	retlw	32	;' '
	retlw	86	;'V'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
STR_39	equ	STR_28+0
STR_7	equ	STR_2+0
STR_9	equ	STR_35+7
STR_29	equ	STR_35+7
STR_30	equ	STR_35+7
STR_41	equ	STR_35+7
; #config settings
	file	"main.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssBANK0,class=BANK0,bit,space=1,noexec
global __pbitbssBANK0
__pbitbssBANK0:
_g_dbgDetectFlag:
       ds      1

_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

_g_adcBusy:
       ds      1

_g_doAdcSample:
       ds      1

_g_detectLogFlag:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_g_powerOnTimer:
       ds      2

_g_vccProtect:
       ds      1

_g_tempProtect:
       ds      1

_g_dbgNewType:
       ds      1

_g_dbgNewState:
       ds      1

_g_dbgOldState:
       ds      1

_g_dbgSlot:
       ds      1

_g_tempPhase:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_pwmDuty:
       ds      1

_g_scanPhase:
       ds      1

_g_scanIndex:
       ds      1

_g_detectLogType:
       ds      1

_g_detectLogSlot:
       ds      1

_test_adc:
       ds      1

_g_blinkTick:
       ds      1

_adresult:
       ds      2

psect	dataBANK0,class=BANK0,space=1,noexec
global __pdataBANK0
__pdataBANK0:
	file	"charge_mgr.c"
	line	12
_g_temperature:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_detectLowCnt:
       ds      12

_g_highVFlag:
       ds      2

_g_impData:
       ds      2

_g_capFlag:
       ds      2

_g_dbgVoltage:
       ds      2

_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_cvIntegral:
       ds      2

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"main.c"
	line	15
_g_vcc_mv:
       ds      2

psect	dataBANK1
	file	"charge_mgr.c"
	line	19
_g_impCheckSlot:
       ds      1

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slotRefV:
       ds      24

_g_stableCnt:
       ds      12

_g_ovCnt:
       ds      12

_g_ccBlocks:
       ds      12

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"main.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
	fcall	__pidataBANK1+2		;fetch initializer
	movwf	__pdataBANK1+2&07fh		
; Initialize objects allocated to BANK0
	global __pidataBANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 5	;RP0=0, select bank0
	fcall	__pidataBANK0+0		;fetch initializer
	movwf	__pdataBANK0+0&07fh		
	fcall	__pidataBANK0+1		;fetch initializer
	movwf	__pdataBANK0+1&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+03Ch)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+01Ch)
	fcall	clear_ram0
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+014h)
	fcall	clear_ram0
; Clear objects allocated to BITBANK0
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssBANK0/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK3,class=BANK3,space=1,noexec
global __pcstackBANK3
__pcstackBANK3:
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0x0
	global	ChargeProcess_Slot@bat_mv_long_400
ChargeProcess_Slot@bat_mv_long_400:	; 4 bytes @ 0x0
	ds	4
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x4
	global	_ChargeProcess_Slot$402
_ChargeProcess_Slot$402:	; 2 bytes @ 0x4
	ds	2
	global	ChargeProcess_Slot@v_ref
ChargeProcess_Slot@v_ref:	; 2 bytes @ 0x6
	ds	2
	global	ChargeProcess_Slot@bat_mv
ChargeProcess_Slot@bat_mv:	; 2 bytes @ 0x8
	ds	2
	global	ChargeProcess_Slot@bat_mv_398
ChargeProcess_Slot@bat_mv_398:	; 2 bytes @ 0xA
	ds	2
	global	ChargeProcess_Slot@bat_mv_401
ChargeProcess_Slot@bat_mv_401:	; 2 bytes @ 0xC
	ds	4
	global	ChargeProcess_Slot@st
ChargeProcess_Slot@st:	; 1 bytes @ 0x10
	ds	1
	global	ChargeProcess_Slot@ct
ChargeProcess_Slot@ct:	; 2 bytes @ 0x11
	ds	2
	global	ChargeProcess_Slot@ty
ChargeProcess_Slot@ty:	; 1 bytes @ 0x13
	ds	1
psect	cstackBANK2,class=BANK2,space=1,noexec
global __pcstackBANK2
__pcstackBANK2:
	global	ChargeProcess_Slot@v
ChargeProcess_Slot@v:	; 2 bytes @ 0x0
	ds	2
	global	ChargeProcess_Slot@idx
ChargeProcess_Slot@idx:	; 1 bytes @ 0x2
	ds	1
??_main:	; 1 bytes @ 0x3
	ds	2
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
	global	?___lmul
?___lmul:	; 4 bytes @ 0x0
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x0
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x0
	global	___wmul@product
___wmul@product:	; 2 bytes @ 0x0
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x0
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x1
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x1
	ds	1
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x2
	ds	1
?_uart_send_number:	; 1 bytes @ 0x3
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x3
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x4
	ds	1
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x5
	ds	2
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x8
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x8
	ds	1
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	2
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0xB
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0xC
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0xC
	ds	1
??_Do_AdcSample:	; 1 bytes @ 0xD
	global	_Print_NtcTemp$753
_Print_NtcTemp$753:	; 2 bytes @ 0xD
	ds	1
	global	Do_AdcSample@ch
Do_AdcSample@ch:	; 1 bytes @ 0xE
	ds	1
	global	Do_AdcSample@ty
Do_AdcSample@ty:	; 1 bytes @ 0xF
	global	_Print_NtcTemp$754
_Print_NtcTemp$754:	; 2 bytes @ 0xF
	ds	1
	global	Do_AdcSample@dly
Do_AdcSample@dly:	; 1 bytes @ 0x10
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x10
	ds	1
	global	Do_AdcSample@st
Do_AdcSample@st:	; 1 bytes @ 0x11
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x11
	ds	4
??_Read_Temperature:	; 1 bytes @ 0x15
??_ChargeProcess_Slot:	; 1 bytes @ 0x15
??_Print_SystemStatus:	; 1 bytes @ 0x15
	ds	4
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x19
	ds	1
	global	ChargeProcess_Slot@v_init
ChargeProcess_Slot@v_init:	; 2 bytes @ 0x1A
	ds	2
	global	ChargeProcess_Slot@vx_mv
ChargeProcess_Slot@vx_mv:	; 4 bytes @ 0x1C
	ds	1
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x1D
	global	_Print_SystemStatus$755
_Print_SystemStatus$755:	; 2 bytes @ 0x1D
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x1F
	global	_Print_SystemStatus$756
_Print_SystemStatus$756:	; 2 bytes @ 0x1F
	ds	1
	global	ChargeProcess_Slot@bat_mv_long
ChargeProcess_Slot@bat_mv_long:	; 4 bytes @ 0x20
	ds	1
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x21
	ds	3
	global	ChargeProcess_Slot@vx_mv_396
ChargeProcess_Slot@vx_mv_396:	; 4 bytes @ 0x24
	ds	1
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x25
	ds	1
	global	_Print_SystemStatus$285
_Print_SystemStatus$285:	; 2 bytes @ 0x26
	ds	2
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x28
	global	ChargeProcess_Slot@bat_mv_long_397
ChargeProcess_Slot@bat_mv_long_397:	; 4 bytes @ 0x28
	ds	2
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0x2A
	ds	2
	global	ChargeProcess_Slot@vx_mv_399
ChargeProcess_Slot@vx_mv_399:	; 4 bytes @ 0x2C
	ds	2
	global	Print_SystemStatus@t
Print_SystemStatus@t:	; 1 bytes @ 0x2E
	ds	1
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x2F
	ds	1
	global	ChargeProcess_Slot@old_st
ChargeProcess_Slot@old_st:	; 1 bytes @ 0x30
	ds	1
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Update_LED_Slot:	; 1 bytes @ 0x0
??_Update_LED_Slot:	; 1 bytes @ 0x0
?_Charging_Control:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Led_BlinkProcess:	; 1 bytes @ 0x0
??_Led_BlinkProcess:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_ChargeProcess_Slot:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Do_AdcSample:	; 1 bytes @ 0x0
?_Do_NtcRead:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_Print_DetectLog:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?i1_ADC_Sample:	; 1 bytes @ 0x0
?i1___bmul:	; 1 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	?i1___lldiv
?i1___lldiv:	; 4 bytes @ 0x0
Update_LED_Slot@idx:	; 1 bytes @ 0x0
	global	i1ADC_Sample@adldo
i1ADC_Sample@adldo:	; 1 bytes @ 0x0
	global	i1___bmul@multiplicand
i1___bmul@multiplicand:	; 1 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	global	i1___lldiv@divisor
i1___lldiv@divisor:	; 4 bytes @ 0x0
	ds	1
??i1_ADC_Sample:	; 1 bytes @ 0x1
??i1___bmul:	; 1 bytes @ 0x1
	global	i1___bmul@multiplier
i1___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
	global	i1___bmul@product
i1___bmul@product:	; 1 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_Charging_Control:	; 1 bytes @ 0x3
	global	Charging_Control@chargeB1_6
Charging_Control@chargeB1_6:	; 1 bytes @ 0x3
	ds	1
??___awdiv:	; 1 bytes @ 0x4
	global	Charging_Control@chargeB7_12
Charging_Control@chargeB7_12:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	global	i1___lldiv@dividend
i1___lldiv@dividend:	; 4 bytes @ 0x4
	ds	1
	global	Charging_Control@s
Charging_Control@s:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	ds	1
	global	Charging_Control@i
Charging_Control@i:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	2
??_CCCV_Control:	; 1 bytes @ 0x8
??i1___lldiv:	; 1 bytes @ 0x8
	global	i1___lldiv@counter
i1___lldiv@counter:	; 1 bytes @ 0x8
	ds	1
	global	i1___lldiv@quotient
i1___lldiv@quotient:	; 4 bytes @ 0x9
	ds	4
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
	global	i1ADC_Sample@adch
i1ADC_Sample@adch:	; 1 bytes @ 0x0
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0x0
	ds	1
	global	i1ADC_Sample@j
i1ADC_Sample@j:	; 1 bytes @ 0x1
	ds	1
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0x2
	global	i1ADC_Sample@i
i1ADC_Sample@i:	; 1 bytes @ 0x2
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0x3
	global	i1ADC_Sample@adsum
i1ADC_Sample@adsum:	; 4 bytes @ 0x3
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0x4
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0x5
	ds	1
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x6
	ds	1
	global	i1ADC_Sample@admin
i1ADC_Sample@admin:	; 2 bytes @ 0x7
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x8
	ds	1
	global	i1ADC_Sample@admax
i1ADC_Sample@admax:	; 2 bytes @ 0x9
	ds	1
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0xA
	ds	1
	global	i1ADC_Sample@ad_temp
i1ADC_Sample@ad_temp:	; 2 bytes @ 0xB
	ds	1
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0xC
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0xD
	ds	1
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0xE
	ds	2
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x10
	ds	1
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x11
	ds	1
??_Isr_Timer:	; 1 bytes @ 0x12
	ds	4
	global	Isr_Timer@pt
Isr_Timer@pt:	; 4 bytes @ 0x16
	ds	4
??_AD_Init:	; 1 bytes @ 0x1A
??_uart_init:	; 1 bytes @ 0x1A
?_ADC_Sample:	; 1 bytes @ 0x1A
??_uart_send_char:	; 1 bytes @ 0x1A
?_Detect_BatteryType:	; 1 bytes @ 0x1A
??___lmul:	; 1 bytes @ 0x1A
?___bmul:	; 1 bytes @ 0x1A
	global	?___wmul
?___wmul:	; 2 bytes @ 0x1A
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x1A
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x1A
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x1A
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x1A
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x1A
	global	___wmul@multiplier
___wmul@multiplier:	; 2 bytes @ 0x1A
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x1A
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x1A
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x1A
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x1B
??___bmul:	; 1 bytes @ 0x1B
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x1B
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x1B
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x1C
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x1C
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x1C
	global	___wmul@multiplicand
___wmul@multiplicand:	; 2 bytes @ 0x1C
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x1C
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x1C
	ds	1
?_uart_send_string:	; 1 bytes @ 0x1D
??_System_Init:	; 1 bytes @ 0x1D
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x1D
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x1D
	ds	1
??___wmul:	; 1 bytes @ 0x1E
??___lldiv:	; 1 bytes @ 0x1E
??___lwdiv:	; 1 bytes @ 0x1E
??___lwmod:	; 1 bytes @ 0x1E
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x1E
	ds	1
??_uart_send_string:	; 1 bytes @ 0x1F
??_uart_send_number:	; 1 bytes @ 0x1F
??_Do_NtcRead:	; 1 bytes @ 0x1F
??_Print_NtcTemp:	; 1 bytes @ 0x1F
??_Print_DetectLog:	; 1 bytes @ 0x1F
;!
;!Data Sizes:
;!    Strings     361
;!    Constant    12
;!    Data        5
;!    BSS         180
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14     13      13
;!    BANK0            80     31      54
;!    BANK1            80     49      80
;!    BANK3            80     20      80
;!    BANK2            80      5      77

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 37
;!		 -> STR_41(CODE[3]), STR_40(CODE[4]), STR_39(CODE[5]), STR_38(CODE[6]), 
;!		 -> STR_37(CODE[6]), STR_36(CODE[11]), STR_35(CODE[10]), STR_34(CODE[21]), 
;!		 -> STR_33(CODE[34]), STR_32(CODE[37]), STR_31(CODE[33]), STR_30(CODE[3]), 
;!		 -> STR_29(CODE[3]), STR_28(CODE[5]), STR_27(CODE[5]), STR_26(CODE[6]), 
;!		 -> STR_25(CODE[6]), STR_24(CODE[6]), STR_23(CODE[6]), STR_22(CODE[16]), 
;!		 -> STR_21(CODE[13]), STR_20(CODE[15]), STR_19(CODE[7]), STR_18(CODE[5]), 
;!		 -> STR_17(CODE[5]), STR_16(CODE[6]), STR_15(CODE[6]), STR_14(CODE[6]), 
;!		 -> STR_13(CODE[7]), STR_12(CODE[4]), STR_11(CODE[6]), STR_10(CODE[6]), 
;!		 -> STR_9(CODE[3]), STR_8(CODE[12]), STR_7(CODE[2]), STR_6(CODE[6]), 
;!		 -> STR_5(CODE[5]), STR_4(CODE[29]), STR_3(CODE[4]), STR_2(CODE[2]), 
;!		 -> STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->i1___lldiv
;!    _Charging_Control->i1___bmul
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_uart_send_string
;!    _System_Init->___bmul
;!    _Print_SystemStatus->_ADC_Sample
;!    _Print_SystemStatus->___lwmod
;!    _Print_SystemStatus->_uart_send_string
;!    _Print_NtcTemp->___lwmod
;!    _Print_NtcTemp->_uart_send_string
;!    _Print_DetectLog->_uart_send_string
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwmod
;!    _Read_Temperature->_ADC_Sample
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->_ADC_Sample
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    _Isr_Timer->_CCCV_Control
;!
;!Critical Paths under _main in BANK1
;!
;!    _main->_ChargeProcess_Slot
;!    _main->_Print_SystemStatus
;!    _Print_SystemStatus->___lldiv
;!    _Print_NtcTemp->_uart_send_number
;!    _Print_DetectLog->_uart_send_number
;!    _uart_send_number->___lwdiv
;!    _Do_NtcRead->_Read_Temperature
;!    _Read_Temperature->___lldiv
;!    _Do_AdcSample->_ADC_Sample
;!    _ChargeProcess_Slot->___lldiv
;!    ___lldiv->___lmul
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    _main->_ChargeProcess_Slot
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    _main->_ChargeProcess_Slot
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 2     2      0   74795
;!                                              3 BANK2      2     2      0
;!                 _ChargeProcess_Slot
;!                       _Do_AdcSample
;!                         _Do_NtcRead
;!                    _Print_DetectLog
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                        _System_Init
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1533
;!                                             29 BANK0      1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  33    33      0   17047
;!                                             21 BANK1     28    28      0
;!                                              0 BANK3      5     5      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    8634
;!                                             13 BANK1      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Print_DetectLog                                      0     0      0    7226
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    3473
;!                                             29 BANK0      2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_number                                    10     8      2    3609
;!                                              3 BANK1     10     8      2
;!                             ___bmul (ARG)
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     144
;!                                             26 BANK0      3     3      0
;! ---------------------------------------------------------------------------------
;! (2) ___lwmod                                              5     1      4     518
;!                                             26 BANK0      5     1      4
;! ---------------------------------------------------------------------------------
;! (1) _Do_NtcRead                                           0     0      0    7394
;!                   _Read_Temperature
;! ---------------------------------------------------------------------------------
;! (2) _Read_Temperature                                    12    12      0    7394
;!                                             21 BANK1     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (1) _Do_AdcSample                                         5     5      0    3143
;!                                             13 BANK1      5     5      0
;!                         _ADC_Sample
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _ChargeProcess_Slot                                  51    51      0   22736
;!                                             21 BANK1     28    28      0
;!                                              0 BANK3     20    20      0
;!                                              0 BANK2      3     3      0
;!                         _ADC_Sample
;!                 _Detect_BatteryType
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (2) ___wmul                                               6     2      4    2260
;!                                             26 BANK0      4     0      4
;!                                              0 BANK1      2     2      0
;! ---------------------------------------------------------------------------------
;! (2) ___lwdiv                                              7     3      4    1010
;!                                             26 BANK0      4     0      4
;!                                              0 BANK1      3     3      0
;! ---------------------------------------------------------------------------------
;! (2) ___lmul                                              12     4      8    2762
;!                                             26 BANK0      4     4      0
;!                                              0 BANK1      8     0      8
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1554
;!                                              8 BANK1     13     5      8
;!                             ___lmul (ARG)
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1    1185
;!                                             26 BANK0      3     2      1
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     331
;!                                             26 BANK0      2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _ADC_Sample                                          18    17      1    1508
;!                                             26 BANK0      5     4      1
;!                                              0 BANK1     13    13      0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 2
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (4) _Isr_Timer                                            8     8      0    3961
;!                                             18 BANK0      8     8      0
;!                       _CCCV_Control
;!                   _Charging_Control
;!                   _Led_BlinkProcess
;!                 _PowerOnLedSequence
;!                    _Update_LED_Slot
;!                       i1_ADC_Sample
;!                          i1___lldiv
;! ---------------------------------------------------------------------------------
;! (5) i1___lldiv                                           13     5      8      44
;!                                              0 COMMON    13     5      8
;! ---------------------------------------------------------------------------------
;! (5) i1_ADC_Sample                                        18    17      1     805
;!                                              0 COMMON     5     4      1
;!                                              0 BANK0     13    13      0
;! ---------------------------------------------------------------------------------
;! (5) _Update_LED_Slot                                      1     1      0       0
;! ---------------------------------------------------------------------------------
;! (5) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Led_BlinkProcess                                     0     0      0       0
;! ---------------------------------------------------------------------------------
;! (5) _Charging_Control                                     4     4      0     797
;!                                              3 COMMON     4     4      0
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (5) _CCCV_Control                                        20    20      0    2267
;!                                              8 COMMON     2     2      0
;!                                              0 BANK0     18    18      0
;!                            ___awdiv
;!                           i1___bmul
;! ---------------------------------------------------------------------------------
;! (6) i1___bmul                                             3     2      1     125
;!                                              0 COMMON     3     2      1
;! ---------------------------------------------------------------------------------
;! (6) ___awdiv                                              8     4      4     606
;!                                              0 COMMON     8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 6
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _ChargeProcess_Slot
;!     _ADC_Sample
;!     _Detect_BatteryType
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___wmul
;!   _Do_AdcSample
;!     _ADC_Sample
;!     ___bmul
;!   _Do_NtcRead
;!     _Read_Temperature
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!       ___lmul
;!       ___lwdiv
;!   _Print_DetectLog
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _uart_send_number
;!     ___bmul (ARG)
;!     ___lwdiv (ARG)
;!     ___lwmod (ARG)
;!     _uart_send_char (ARG)
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     i1___bmul
;!   _Charging_Control
;!     i1___bmul
;!   _Led_BlinkProcess
;!   _PowerOnLedSequence
;!   _Update_LED_Slot
;!   i1_ADC_Sample
;!   i1___lldiv
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50     14      50       8      100.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      5      4D      10       96.3%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50     31      50       6      100.0%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     1F      36       4       67.5%
;!BITBANK0            50      0       1       3        1.3%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      D       D       1       92.9%
;!BITCOMMON            E      0       0       0        0.0%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     130      12        0.0%
;!ABS                  0      0     130      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 498 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       2
;;      Totals:         0       0       0       0       2
;;Total ram usage:        2 bytes
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ChargeProcess_Slot
;;		_Do_AdcSample
;;		_Do_NtcRead
;;		_Print_DetectLog
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_System_Init
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"main.c"
	line	498
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"main.c"
	line	498
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	501
	
l7985:	
	opt asmopt_push
opt asmopt_off
movlw	52
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
movwf	((??_main+0)^0100h+0+1),f
	movlw	241
movwf	((??_main+0)^0100h+0),f
	u12217:
decfsz	((??_main+0)^0100h+0),f
	goto	u12217
	decfsz	((??_main+0)^0100h+0+1),f
	goto	u12217
opt asmopt_pop

	line	502
# 502 "main.c"
clrwdt ;# 
psect	maintext
	line	505
	
l7987:	
	fcall	_System_Init
	line	508
	
l7989:	
	movlw	low(((STR_34)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_34)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	509
	
l7991:	
	movlw	low(((STR_35)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_35)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	512
	
l470:	
	line	514
# 514 "main.c"
clrwdt ;# 
psect	maintext
	line	517
	
l7993:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u12161
	goto	u12160
u12161:
	goto	l8023
u12160:
	line	519
	
l7995:	
	bcf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	line	520
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	521
	
l7997:	
	fcall	_Do_AdcSample
	line	522
	
l7999:	
	movf	(_g_scanIndex),w	;volatile
	fcall	_ChargeProcess_Slot
	line	525
	
l8001:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	goto	u12171
	goto	u12170
u12171:
	goto	l8021
u12170:
	line	527
	
l8003:	
	bcf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	528
	
l8005:	
	movlw	low(((STR_36)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_36)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	529
	
l8007:	
	movf	(_g_dbgSlot),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	530
	
l8009:	
	movlw	low(((STR_37)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_37)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	531
	movf	(_g_dbgOldState),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	532
	
l8011:	
	movlw	low(((STR_38)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_38)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	533
	
l8013:	
	movf	(_g_dbgNewState),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	534
	movlw	low(((STR_39)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_39)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	535
	
l8015:	
	movf	(_g_dbgNewType),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	536
	
l8017:	
	movlw	low(((STR_40)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_40)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	537
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_dbgVoltage+1)^080h,w	;volatile
	movwf	(uart_send_number@num+1)^080h
	movf	(_g_dbgVoltage)^080h,w	;volatile
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	538
	
l8019:	
	movlw	low(((STR_41)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_41)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	541
	
l8021:	
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	545
	
l8023:	
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u12181
	goto	u12180
u12181:
	goto	l8031
u12180:
	line	547
	
l8025:	
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	548
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	549
	
l8027:	
	fcall	_Do_NtcRead
	line	550
	
l8029:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	554
	
l8031:	
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u12191
	goto	u12190
u12191:
	goto	l8037
u12190:
	line	556
	
l8033:	
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	557
	
l8035:	
	fcall	_Print_SystemStatus
	line	558
	fcall	_Print_NtcTemp
	line	562
	
l8037:	
	btfss	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	goto	u12201
	goto	u12200
u12201:
	goto	l470
u12200:
	line	564
	
l8039:	
	bcf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	line	565
	
l8041:	
	fcall	_Print_DetectLog
	goto	l470
	global	start
	ljmp	start
	opt stack 0
	line	568
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 68 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   29[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	68
global __ptext1
__ptext1:	;psect for function _System_Init
psect	text1
	file	"main.c"
	line	68
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	73
	
l6745:	
# 73 "main.c"
nop ;# 
	line	74
# 74 "main.c"
clrwdt ;# 
psect	text1
	line	75
	
l6747:	
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	79
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	80
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	81
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l6749:	
	clrf	(262)^0100h	;volatile
	line	82
	
l6751:	
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l6753:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	85
	
l6755:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l6757:	
	clrf	(135)^080h	;volatile
	line	86
	
l6759:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l6761:	
	clrf	(7)	;volatile
	line	87
	
l6763:	
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	88
	
l6765:	
	clrf	(277)^0100h	;volatile
	line	91
	
l6767:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l6769:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	94
	
l6771:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	95
	
l6773:	
	clrf	(406)^0180h	;volatile
	line	102
	
l6775:	
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	103
	
l6777:	
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	104
	
l6779:	
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	105
	
l6781:	
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	108
	
l6783:	
	fcall	_AD_Init
	line	111
	
l6785:	
	fcall	_uart_init
	line	118
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	119
	
l6787:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	120
	
l6789:	
	bcf	(90/8),(90)&7	;volatile
	line	121
	
l6791:	
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	124
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	line	125
	clrf	(_g_pwmCounter)	;volatile
	line	126
	
l6793:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	127
	
l6795:	
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	128
	
l6797:	
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	129
	
l6799:	
	bcf	(55/8),(55)&7	;volatile
	line	132
	clrf	(System_Init@i)
	line	134
	
l6805:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	135
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	136
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	137
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	138
	
l6807:	
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	139
	
l6809:	
	movf	(System_Init@i),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	132
	
l6811:	
	incf	(System_Init@i),f
	
l6813:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u9891
	goto	u9890
u9891:
	goto	l6805
u9890:
	line	141
	
l6815:	
	clrf	(_g_blinkTick)
	line	144
	
l361:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"uart_dbg.c"
	line	21
global __ptext2
__ptext2:	;psect for function _uart_init
psect	text2
	file	"uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_init: []
	line	23
	
l3109:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l508:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	23
global __ptext3
__ptext3:	;psect for function _AD_Init
psect	text3
	file	"adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l3103:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
	clrf	(406)^0180h	;volatile
	line	27
	
l3105:	
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l3107:	
	clrf	(150)^080h	;volatile
	line	29
	
l485:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 352 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  t               1   46[BANK1 ] unsigned char 
;;  bat_mv_long     4    0[BANK3 ] unsigned long 
;;  vx_mv           4   42[BANK1 ] unsigned long 
;;  v               2   40[BANK1 ] unsigned int 
;;  s               1   37[BANK1 ] unsigned char 
;;  pt              4   33[BANK1 ] unsigned long 
;;  vcc_mv          2   47[BANK1 ] unsigned int 
;;  i               1    4[BANK3 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      20       5       0
;;      Temps:          0       0       8       0       0
;;      Totals:         0       0      28       5       0
;;Total ram usage:       33 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	352
global __ptext4
__ptext4:	;psect for function _Print_SystemStatus
psect	text4
	file	"main.c"
	line	352
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	357
	
l7043:	
	movlw	low(((STR_4)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	360
	
l7045:	
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	361
	
l7047:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u10361
	goto	u10360
u10361:
	goto	l7053
u10360:
	line	363
	
l7049:	
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Print_SystemStatus@pt)^080h

	line	364
	
l7051:	
	movf	(Print_SystemStatus@pt+1)^080h,w
	movwf	(Print_SystemStatus@vcc_mv+1)^080h
	movf	(Print_SystemStatus@pt)^080h,w
	movwf	(Print_SystemStatus@vcc_mv)^080h
	line	365
	goto	l426
	line	367
	
l7053:	
	movlw	088h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@vcc_mv)^080h
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv)^080h)+1
	
l426:	
	line	369
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	line	371
	
l7055:	
	movlw	low(((STR_5)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	372
	
l7057:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	373
	
l7059:	
	movlw	low(((STR_6)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	374
	
l7061:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$755+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$755)^080h
	
l7063:	
	movf	(_Print_SystemStatus$755+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$755)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	375
	
l7065:	
	movlw	low(((STR_7)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	376
	
l7067:	
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$756+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_SystemStatus$756)^080h
	
l7069:	
	movf	(_Print_SystemStatus$756+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$756)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	377
	
l7071:	
	movlw	low(((STR_8)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	378
	
l7073:	
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u10371
	goto	u10370
u10371:
	goto	l7077
u10370:
	
l7075:	
	movf	(_g_impCheckSlot)^080h,w
	movwf	(_Print_SystemStatus$285)^080h
	clrf	(_Print_SystemStatus$285+1)^080h
	goto	l7079
	
l7077:	
	movlw	0FFh
	movwf	(_Print_SystemStatus$285)^080h
	clrf	(_Print_SystemStatus$285+1)^080h
	
l7079:	
	movf	(_Print_SystemStatus$285+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_SystemStatus$285)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	379
	
l7081:	
	movlw	low(((STR_9)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	383
	
l7083:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(Print_SystemStatus@i)^0180h
	line	392
	
l7089:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@v)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)^080h
	line	393
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@s)^080h
	line	400
	
l7091:	
	movlw	low(042h)
	fcall	_uart_send_char
	line	401
	
l7093:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	incf	(uart_send_number@num)^080h,f
	skipnz
	incf	(uart_send_number@num+1)^080h,f
	fcall	_uart_send_number
	line	402
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	403
	
l7095:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(Print_SystemStatus@v)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	409
	
l7097:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@v)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Print_SystemStatus@v+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(___lmul@multiplicand)^080h
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(Print_SystemStatus@vx_mv)^080h

	
l7099:	
	movlw	0Ch
u10385:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3)^080h,f
	rrf	(Print_SystemStatus@vx_mv+2)^080h,f
	rrf	(Print_SystemStatus@vx_mv+1)^080h,f
	rrf	(Print_SystemStatus@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u10385

	line	410
	
l7101:	
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	clrf	((??_Print_SystemStatus+0)^080h+0+2)
	clrf	((??_Print_SystemStatus+0)^080h+0+3)
	movlw	0C8h
	movwf	((??_Print_SystemStatus+4)^080h+0)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	(Print_SystemStatus@vx_mv)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+0,f
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1)^080h,w
	goto	u10390
	goto	u10391
u10390:
	addwf	(??_Print_SystemStatus+4)^080h+1,f
u10391:
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2)^080h,w
	goto	u10392
	goto	u10393
u10392:
	addwf	(??_Print_SystemStatus+4)^080h+2,f
u10393:
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3)^080h,w
	addwf	(??_Print_SystemStatus+4)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	subwf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u10405
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	subwf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u10405
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	subwf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipz
	goto	u10405
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	subwf	0+(??_Print_SystemStatus+4)^080h+0,w
u10405:
	skipc
	goto	u10401
	goto	u10400
u10401:
	goto	l7105
u10400:
	line	412
	
l7103:	
	movlw	low(((STR_10)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	413
	goto	l7115
	line	416
	
l7105:	
	movf	(Print_SystemStatus@vx_mv+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(Print_SystemStatus@vx_mv+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(Print_SystemStatus@vx_mv+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(Print_SystemStatus@vx_mv)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long)^0180h

	line	417
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	(3+(?___lmul))^080h,w
	skipz
	goto	u10415
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long+2)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	(2+(?___lmul))^080h,w
	skipz
	goto	u10415
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	(1+(?___lmul))^080h,w
	skipz
	goto	u10415
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	(0+(?___lmul))^080h,w
u10415:
	skipnc
	goto	u10411
	goto	u10410
u10411:
	goto	l7115
u10410:
	line	419
	
l7107:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_Print_SystemStatus+0)^080h+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)^080h+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)^080h+0+3)
	movf	(Print_SystemStatus@vcc_mv)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Print_SystemStatus@vcc_mv+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0FFh
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+2)^080h
	movlw	0FFh
	movwf	(___lmul@multiplicand+1)^080h
	movlw	032h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	addwf	(Print_SystemStatus@bat_mv_long)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+4)^080h+0+0)
	movlw	0
	skipnc
	movlw	1
	addwf	(1+(?___lmul))^080h,w
	clrf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	bsf	status, 6	;RP1=1, select bank3
	addwf	(Print_SystemStatus@bat_mv_long+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+4)^080h+0+1)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+2),f
	movf	(2+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+2),w
	clrf	((??_Print_SystemStatus+4)^080h+0+3)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	bsf	status, 6	;RP1=1, select bank3
	addwf	(Print_SystemStatus@bat_mv_long+2)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+4)^080h+0+2)
	skipnc
	incf	((??_Print_SystemStatus+4)^080h+0+3),f
	movf	(3+(?___lmul))^080h,w
	addwf	((??_Print_SystemStatus+4)^080h+0+3),w
	bsf	status, 6	;RP1=1, select bank3
	addwf	(Print_SystemStatus@bat_mv_long+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	((??_Print_SystemStatus+4)^080h+0+3)
	movf	0+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+0,f
	movf	1+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	1+(??_Print_SystemStatus+4)^080h+0,w
	goto	u10420
	goto	u10421
u10420:
	addwf	(??_Print_SystemStatus+0)^080h+1,f
u10421:
	movf	2+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incfsz	2+(??_Print_SystemStatus+4)^080h+0,w
	goto	u10422
	goto	u10423
u10422:
	addwf	(??_Print_SystemStatus+0)^080h+2,f
u10423:
	movf	3+(??_Print_SystemStatus+4)^080h+0,w
	skipnc
	incf	3+(??_Print_SystemStatus+4)^080h+0,w
	addwf	(??_Print_SystemStatus+0)^080h+3,f
	movf	3+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_Print_SystemStatus+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(Print_SystemStatus@bat_mv_long)^0180h

	line	420
	
l7109:	
	movlw	low(((STR_11)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	421
	
l7111:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num+1)^080h
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@bat_mv_long)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	422
	
l7113:	
	movlw	low(((STR_12)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	429
	
l7115:	
	movlw	low(020h)
	fcall	_uart_send_char
	line	430
	goto	l7157
	line	432
	
l7117:	
	movlw	low(((STR_13)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7159
	line	433
	
l7119:	
	movlw	low(((STR_14)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7159
	line	434
	
l7121:	
	movlw	low(((STR_15)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7159
	line	435
	
l7123:	
	movlw	low(((STR_16)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7159
	line	436
	
l7125:	
	movlw	low(((STR_17)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7159
	line	437
	
l7127:	
	movlw	low(((STR_18)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7159
	line	438
	
l7129:	
	movlw	low(((STR_19)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7159
	line	441
	
l7131:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Print_SystemStatus@t)^080h
	line	442
	
l7133:	
		movlw	2
	xorwf	((Print_SystemStatus@t)^080h),w
	btfsc	status,2
	goto	u10431
	goto	u10430
u10431:
	goto	l7137
u10430:
	
l7135:	
		movlw	3
	xorwf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u10441
	goto	u10440
u10441:
	goto	l7139
u10440:
	line	443
	
l7137:	
	movlw	low(((STR_20)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7159
	line	444
	
l7139:	
		decf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u10451
	goto	u10450
u10451:
	goto	l7143
u10450:
	line	445
	
l7141:	
	movlw	low(((STR_21)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7159
	line	446
	
l7143:	
		movlw	6
	xorwf	((Print_SystemStatus@t)^080h),w
	btfss	status,2
	goto	u10461
	goto	u10460
u10461:
	goto	l7147
u10460:
	line	447
	
l7145:	
	movlw	low(((STR_22)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7159
	line	449
	
l7147:	
	movlw	low(((STR_23)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7159
	line	452
	
l7149:	
	movlw	low(((STR_24)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7159
	line	453
	
l7151:	
	movlw	low(((STR_25)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7159
	line	454
	
l7153:	
	movlw	low(((STR_26)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l7159
	line	430
	
l7157:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(Print_SystemStatus@s)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l7117
	xorlw	1^0	; case 1
	skipnz
	goto	l7119
	xorlw	2^1	; case 2
	skipnz
	goto	l7121
	xorlw	3^2	; case 3
	skipnz
	goto	l7123
	xorlw	4^3	; case 4
	skipnz
	goto	l7125
	xorlw	5^4	; case 5
	skipnz
	goto	l7127
	xorlw	6^5	; case 6
	skipnz
	goto	l7129
	xorlw	7^6	; case 7
	skipnz
	goto	l7131
	xorlw	8^7	; case 8
	skipnz
	goto	l7149
	xorlw	9^8	; case 9
	skipnz
	goto	l7151
	goto	l7153
	opt asmopt_pop

	line	458
	
l7159:	
	movlw	low(((STR_27)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	459
	
l7161:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	460
	
l7163:	
	movlw	low(((STR_28)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	461
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(Print_SystemStatus@i)^0180h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	fcall	_uart_send_number
	line	464
	
l7165:	
	movlw	low(((STR_29)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	383
	
l7167:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	incf	(Print_SystemStatus@i)^0180h,f
	
l7169:	
	movlw	low(06h)
	subwf	(Print_SystemStatus@i)^0180h,w
	skipc
	goto	u10471
	goto	u10470
u10471:
	goto	l7089
u10470:
	line	467
	
l7171:	
	movlw	low(((STR_30)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	468
	
l457:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 332 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	332
global __ptext5
__ptext5:	;psect for function _Print_NtcTemp
psect	text5
	file	"main.c"
	line	332
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	334
	
l7031:	
	movlw	low(((STR_1)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	335
	
l7033:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_NtcTemp$753+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_NtcTemp$753)^080h
	
l7035:	
	movf	(_Print_NtcTemp$753+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$753)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	336
	
l7037:	
	movlw	low(((STR_2)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	337
	
l7039:	
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(_g_temperature+1),w
	movwf	(___lwmod@dividend+1)
	movf	(_g_temperature),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_NtcTemp$754+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwmod)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Print_NtcTemp$754)^080h
	movf	(_Print_NtcTemp$754+1)^080h,w
	movwf	(uart_send_number@num+1)^080h
	movf	(_Print_NtcTemp$754)^080h,w
	movwf	(uart_send_number@num)^080h
	fcall	_uart_send_number
	line	338
	
l7041:	
	movlw	low(((STR_3)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	339
	
l422:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_Print_DetectLog

;; *************** function _Print_DetectLog *****************
;; Defined at:
;;		line 474 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	line	474
global __ptext6
__ptext6:	;psect for function _Print_DetectLog
psect	text6
	file	"main.c"
	line	474
	global	__size_of_Print_DetectLog
	__size_of_Print_DetectLog	equ	__end_of_Print_DetectLog-_Print_DetectLog
	
_Print_DetectLog:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_DetectLog: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	476
	
l7173:	
	movlw	low(042h)
	fcall	_uart_send_char
	line	477
	
l7175:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_g_detectLogSlot),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	clrf	(uart_send_number@num+1)^080h
	incf	(uart_send_number@num)^080h,f
	skipnz
	incf	(uart_send_number@num+1)^080h,f
	fcall	_uart_send_number
	line	479
	
l7177:	
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u10481
	goto	u10480
u10481:
	goto	l7181
u10480:
	line	480
	
l7179:	
	movlw	low(((STR_31)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l465
	line	481
	
l7181:	
		movlw	3
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u10491
	goto	u10490
u10491:
	goto	l7185
u10490:
	line	482
	
l7183:	
	movlw	low(((STR_32)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l465
	line	483
	
l7185:	
		movlw	6
	xorwf	((_g_detectLogType)),w	;volatile
	btfss	status,2
	goto	u10501
	goto	u10500
u10501:
	goto	l465
u10500:
	line	484
	
l7187:	
	movlw	low(((STR_33)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	485
	
l465:	
	return
	opt stack 0
GLOBAL	__end_of_Print_DetectLog
	__end_of_Print_DetectLog:
	signat	_Print_DetectLog,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2   29[BANK0 ] PTR const unsigned char 
;;		 -> STR_41(3), STR_40(4), STR_39(5), STR_38(6), 
;;		 -> STR_37(6), STR_36(11), STR_35(10), STR_34(21), 
;;		 -> STR_33(34), STR_32(37), STR_31(33), STR_30(3), 
;;		 -> STR_29(3), STR_28(5), STR_27(5), STR_26(6), 
;;		 -> STR_25(6), STR_24(6), STR_23(6), STR_22(16), 
;;		 -> STR_21(13), STR_20(15), STR_19(7), STR_18(5), 
;;		 -> STR_17(5), STR_16(6), STR_15(6), STR_14(6), 
;;		 -> STR_13(7), STR_12(4), STR_11(6), STR_10(6), 
;;		 -> STR_9(3), STR_8(12), STR_7(2), STR_6(6), 
;;		 -> STR_5(5), STR_4(29), STR_3(4), STR_2(2), 
;;		 -> STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	file	"uart_dbg.c"
	line	61
global __ptext7
__ptext7:	;psect for function _uart_send_string
psect	text7
	file	"uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l6647:	
	goto	l6653
	line	65
	
l6649:	
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	fcall	_uart_send_char
	
l6651:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(uart_send_string@str),f
	skipnz
	incf	(uart_send_string@str+1),f
	line	66
# 66 "uart_dbg.c"
clrwdt ;# 
psect	text7
	line	63
	
l6653:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u9751
	goto	u9750
u9751:
	goto	l6649
u9750:
	line	68
	
l521:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2    3[BANK1 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    5[BANK1 ] unsigned char [6]
;;  j               1   12[BANK1 ] unsigned char 
;;  i               1   11[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       2       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      10       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_main
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext8
__ptext8:	;psect for function _uart_send_number
psect	text8
	file	"uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l6655:	
	clrf	(uart_send_number@i)^080h
	line	84
	
l6657:	
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u9761
	goto	u9760
u9761:
	goto	l6669
u9760:
	line	86
	
l6659:	
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l525
	line	93
	
l6663:	
	movf	(uart_send_number@i)^080h,w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@num+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@num)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank1
	movwf	indf
	
l6665:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(uart_send_number@i)^080h,f
	line	94
	
l6667:	
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@num+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(uart_send_number@num)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(uart_send_number@num)^080h
	line	91
	
l6669:	
	movf	((uart_send_number@num)^080h),w
iorwf	((uart_send_number@num+1)^080h),w
	btfss	status,2
	goto	u9771
	goto	u9770
u9771:
	goto	l6663
u9770:
	line	98
	
l6671:	
	movf	(uart_send_number@i)^080h,w
	movwf	(uart_send_number@j)^080h
	
l6673:	
	movf	((uart_send_number@j)^080h),w
	btfss	status,2
	goto	u9781
	goto	u9780
u9781:
	goto	l6677
u9780:
	goto	l525
	line	99
	
l6677:	
	movf	(uart_send_number@j)^080h,w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l6679:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decf	(uart_send_number@j)^080h,f
	goto	l6673
	line	100
	
l525:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1   27[BANK0 ] unsigned char 
;;  i               1   28[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/900
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Print_DetectLog
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext9
__ptext9:	;psect for function _uart_send_char
psect	text9
	file	"uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_char: [wreg+status,2+status,0]
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_char@c)
	line	38
	
l6501:	
	bcf	(95/8),(95)&7	;volatile
	line	39
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l6503:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u12227:
decfsz	(??_uart_send_char+0)+0,f
	goto	u12227
	nop2
opt asmopt_pop

	line	41
	
l6505:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(uart_send_char@i)
	line	42
	
l511:	
	line	43
	btfss	(uart_send_char@c),(0)&7
	goto	u9481
	goto	u9480
u9481:
	goto	l513
u9480:
	line	44
	
l6511:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l6513
	line	45
	
l513:	
	line	46
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l6513:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u12237:
decfsz	(??_uart_send_char+0)+0,f
	goto	u12237
	nop2
opt asmopt_pop

	line	48
	
l6515:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rrf	(uart_send_char@c),f
	line	41
	
l6517:	
	incf	(uart_send_char@i),f
	
l6519:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u9491
	goto	u9490
u9491:
	goto	l511
u9490:
	
l512:	
	line	50
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l6521:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u12247:
decfsz	(??_uart_send_char+0)+0,f
	goto	u12247
	nop2
opt asmopt_pop

	line	52
	
l6523:	
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l515:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   26[BANK0 ] unsigned int 
;;  dividend        2   28[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1   30[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   26[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       5       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext10
__ptext10:	;psect for function ___lwmod
psect	text10
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l6589:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u9611
	goto	u9610
u9611:
	goto	l6605
u9610:
	line	14
	
l6591:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l6595
	line	16
	
l6593:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l6595:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u9621
	goto	u9620
u9621:
	goto	l6593
u9620:
	line	20
	
l6597:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u9635
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u9635:
	skipc
	goto	u9631
	goto	u9630
u9631:
	goto	l6601
u9630:
	line	21
	
l6599:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l6601:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l6603:	
	decfsz	(___lwmod@counter),f
	goto	u9641
	goto	u9640
u9641:
	goto	l6597
u9640:
	line	25
	
l6605:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1216:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	_Do_NtcRead

;; *************** function _Do_NtcRead *****************
;; Defined at:
;;		line 323 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Read_Temperature
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	323
global __ptext11
__ptext11:	;psect for function _Do_NtcRead
psect	text11
	file	"main.c"
	line	323
	global	__size_of_Do_NtcRead
	__size_of_Do_NtcRead	equ	__end_of_Do_NtcRead-_Do_NtcRead
	
_Do_NtcRead:	
;incstack = 0
	opt	stack 2
; Regs used in _Do_NtcRead: [wreg+status,2+status,0+pclath+cstack]
	line	325
	
l7029:	
	fcall	_Read_Temperature
	line	326
	
l419:	
	return
	opt stack 0
GLOBAL	__end_of_Do_NtcRead
	__end_of_Do_NtcRead:
	signat	_Do_NtcRead,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 37 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   25[BANK1 ] unsigned long 
;;  temp_x10        2   31[BANK1 ] unsigned int 
;;  ntcVal          2   29[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   66[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       8       0       0
;;      Temps:          0       0       4       0       0
;;      Totals:         0       0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Do_NtcRead
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	37
global __ptext12
__ptext12:	;psect for function _Read_Temperature
psect	text12
	file	"charge_mgr.c"
	line	37
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 2
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	42
	
l6609:	
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	43
	
l6611:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfsc	status,2
	goto	u9651
	goto	u9650
u9651:
	goto	l6615
u9650:
	goto	l566
	line	46
	
l6615:	
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Read_Temperature@ntcVal)^080h
	line	47
	movlw	0
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u9661
	goto	u9660
u9661:
	goto	l566
u9660:
	
l6617:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1)^080h,w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal)^080h,w
	skipc
	goto	u9671
	goto	u9670
u9671:
	goto	l6619
u9670:
	goto	l566
	line	52
	
l6619:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	010h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0
	movwf	(___lldiv@divisor)^080h

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0)
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((??_Read_Temperature+0)^080h+0+1)
	clrf	((??_Read_Temperature+0)^080h+0+2)
	clrf	((??_Read_Temperature+0)^080h+0+3)
	movf	0+(??_Read_Temperature+0)^080h+0,w
	subwf	(___lldiv@divisor)^080h,f
	movf	1+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)^080h+0,w
	goto	u9685
	goto	u9686
u9685:
	subwf	(___lldiv@divisor+1)^080h,f
u9686:
	movf	2+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)^080h+0,w
	goto	u9687
	goto	u9688
u9687:
	subwf	(___lldiv@divisor+2)^080h,f
u9688:
	movf	3+(??_Read_Temperature+0)^080h+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)^080h+0,w
	goto	u9689
	goto	u9680
u9689:
	subwf	(___lldiv@divisor+3)^080h,f
u9680:

	movf	(Read_Temperature@ntcVal)^080h,w
	movwf	(___lmul@multiplier)^080h
	movf	(Read_Temperature@ntcVal+1)^080h,w
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0
	movwf	(___lmul@multiplicand+3)^080h
	movlw	0
	movwf	(___lmul@multiplicand+2)^080h
	movlw	027h
	movwf	(___lmul@multiplicand+1)^080h
	movlw	010h
	movwf	(___lmul@multiplicand)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(3+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+3)^080h
	movf	(2+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+2)^080h
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@rt)^080h

	line	53
	
l6621:	
		movf	(Read_Temperature@rt+3)^080h,w
	btfss	status,2
	goto	u9690
	movf	(Read_Temperature@rt+2)^080h,w
	btfss	status,2
	goto	u9690
	movlw	39
	subwf	(Read_Temperature@rt+1)^080h,w
	skipz
	goto	u9693
	movlw	16
	subwf	(Read_Temperature@rt)^080h,w
	skipz
	goto	u9693
u9693:
	btfss	status,0
	goto	u9691
	goto	u9690

u9691:
	goto	l6627
u9690:
	line	54
	
l6623:	
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l6625:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0F0h
	movwf	((??_Read_Temperature+0)^080h+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)^080h+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)^080h+0+3)
	movf	(Read_Temperature@rt)^080h,w
	addwf	(??_Read_Temperature+0)^080h+0,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+1)^080h,w
	goto	u9700
	goto	u9701
u9700:
	addwf	(??_Read_Temperature+0)^080h+1,f
u9701:
	movf	(Read_Temperature@rt+2)^080h,w
	skipnc
	incfsz	(Read_Temperature@rt+2)^080h,w
	goto	u9702
	goto	u9703
u9702:
	addwf	(??_Read_Temperature+0)^080h+2,f
u9703:
	movf	(Read_Temperature@rt+3)^080h,w
	skipnc
	incf	(Read_Temperature@rt+3)^080h,w
	addwf	(??_Read_Temperature+0)^080h+3,f
	movf	3+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+3)^080h
	movf	2+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+2)^080h
	movf	1+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier+1)^080h
	movf	0+(??_Read_Temperature+0)^080h+0,w
	movwf	(___lmul@multiplier)^080h

	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(0+(?___lldiv))^080h,w
	subwf	(Read_Temperature@temp_x10)^080h,f
	movf	(1+(?___lldiv))^080h,w
	skipc
	decf	(Read_Temperature@temp_x10+1)^080h,f
	subwf	(Read_Temperature@temp_x10+1)^080h,f
	goto	l6631
	line	56
	
l6627:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	01h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0BDh
	movwf	(___lldiv@divisor)^080h

	movlw	0
	movwf	(___lmul@multiplier+3)^080h
	movlw	0
	movwf	(___lmul@multiplier+2)^080h
	movlw	027h
	movwf	(___lmul@multiplier+1)^080h
	movlw	010h
	movwf	(___lmul@multiplier)^080h

	movf	(Read_Temperature@rt)^080h,w
	subwf	(___lmul@multiplier)^080h,f
	movf	(Read_Temperature@rt+1)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+1)^080h,w
	subwf	(___lmul@multiplier+1)^080h,f
	movf	(Read_Temperature@rt+2)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+2)^080h,w
	subwf	(___lmul@multiplier+2)^080h,f
	movf	(Read_Temperature@rt+3)^080h,w
	skipc
	incfsz	(Read_Temperature@rt+3)^080h,w
	subwf	(___lmul@multiplier+3)^080h,f
	movlw	0Ah
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(___lldiv@dividend+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10+1)^080h
	movf	(0+(?___lldiv))^080h,w
	movwf	(Read_Temperature@temp_x10)^080h
	
l6629:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10)^080h,f
	skipnc
	incf	(Read_Temperature@temp_x10+1)^080h,f
	line	57
	
l6631:	
	movlw	0
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipnc
	goto	u9711
	goto	u9710
u9711:
	goto	l572
u9710:
	
l6633:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)^080h
	clrf	(Read_Temperature@temp_x10+1)^080h
	
l572:	
	line	58
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1)^080h,w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10)^080h,w
	skipc
	goto	u9721
	goto	u9720
u9721:
	goto	l573
u9720:
	
l6635:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)^080h
	movlw	02h
	movwf	((Read_Temperature@temp_x10)^080h)+1
	
l573:	
	line	61
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_temperature)
	line	62
	
l6637:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u9731
	goto	u9730
u9731:
	goto	l6641
u9730:
	line	63
	
l6639:	
	clrf	(_g_tempProtect)
	incf	(_g_tempProtect),f
	goto	l566
	line	64
	
l6641:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Read_Temperature@temp_x10)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u9741
	goto	u9740
u9741:
	goto	l566
u9740:
	line	65
	
l6643:	
	clrf	(_g_tempProtect)
	line	68
	
l566:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	_Do_AdcSample

;; *************** function _Do_AdcSample *****************
;; Defined at:
;;		line 273 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  st              1   17[BANK1 ] unsigned char 
;;  dly             1   16[BANK1 ] unsigned char 
;;  ty              1   15[BANK1 ] unsigned char 
;;  ch              1   14[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       4       0       0
;;      Temps:          0       0       1       0       0
;;      Totals:         0       0       5       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	273
global __ptext13
__ptext13:	;psect for function _Do_AdcSample
psect	text13
	file	"main.c"
	line	273
	global	__size_of_Do_AdcSample
	__size_of_Do_AdcSample	equ	__end_of_Do_AdcSample-_Do_AdcSample
	
_Do_AdcSample:	
;incstack = 0
	opt	stack 3
; Regs used in _Do_AdcSample: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	275
	
l6985:	
	movf	(_g_scanIndex),w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@ch)^080h
	line	276
	
l6987:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@ty)^080h
	line	277
	
l6989:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(Do_AdcSample@st)^080h
	line	297
	
l6991:	
		movlw	6
	xorwf	((Do_AdcSample@ty)^080h),w
	btfss	status,2
	goto	u10271
	goto	u10270
u10271:
	goto	l7001
u10270:
	
l6993:	
		movlw	2
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10281
	goto	u10280
u10281:
	goto	l7005
u10280:
	
l6995:	
		movlw	3
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10291
	goto	u10290
u10291:
	goto	l7005
u10290:
	
l6997:	
		movlw	4
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10301
	goto	u10300
u10301:
	goto	l7005
u10300:
	
l6999:	
		movlw	5
	xorwf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10311
	goto	u10310
u10311:
	goto	l7005
u10310:
	
l7001:	
		decf	((Do_AdcSample@st)^080h),w
	btfsc	status,2
	goto	u10321
	goto	u10320
u10321:
	goto	l7005
u10320:
	
l7003:	
		movlw	8
	xorwf	((Do_AdcSample@st)^080h),w
	btfss	status,2
	goto	u10331
	goto	u10330
u10331:
	goto	l7017
u10330:
	line	299
	
l7005:	
	clrf	(Do_AdcSample@dly)^080h
	line	300
	
l7011:	
	opt asmopt_push
opt asmopt_off
	movlw	132
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_Do_AdcSample+0)^080h+0),f
	u12257:
decfsz	(??_Do_AdcSample+0)^080h+0,f
	goto	u12257
	nop
opt asmopt_pop

	line	299
	
l7013:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(Do_AdcSample@dly)^080h,f
	
l7015:	
	movlw	low(014h)
	subwf	(Do_AdcSample@dly)^080h,w
	skipc
	goto	u10341
	goto	u10340
u10341:
	goto	l7011
u10340:
	goto	l7019
	line	304
	
l7017:	
	opt asmopt_push
opt asmopt_off
	movlw	132
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_Do_AdcSample+0)^080h+0),f
	u12267:
decfsz	(??_Do_AdcSample+0)^080h+0,f
	goto	u12267
	nop
opt asmopt_pop

	line	307
	
l7019:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@adldo)
	bsf	status, 5	;RP0=1, select bank1
	movf	(Do_AdcSample@ch)^080h,w
	fcall	_ADC_Sample
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_test_adc)	;volatile
	line	309
	
l7021:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u10351
	goto	u10350
u10351:
	goto	l7025
u10350:
	line	310
	
l7023:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	movf	(_adresult),w	;volatile
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_adresult+1),w	;volatile
	movwf	indf
	goto	l7027
	line	312
	
l7025:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(_g_scanIndex),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	314
	
l7027:	
	movlw	low(01h)
	movwf	(_g_scanPhase)	;volatile
	line	315
	
l416:	
	return
	opt stack 0
GLOBAL	__end_of_Do_AdcSample
	__end_of_Do_AdcSample:
	signat	_Do_AdcSample,89
	global	_ChargeProcess_Slot

;; *************** function _ChargeProcess_Slot *****************
;; Defined at:
;;		line 135 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    2[BANK2 ] unsigned char 
;;  bat_mv_long     4   32[BANK1 ] unsigned long 
;;  vx_mv           4   28[BANK1 ] unsigned long 
;;  bat_mv          2    8[BANK3 ] unsigned int 
;;  bat_mv_long     4    0[BANK3 ] unsigned long 
;;  vx_mv           4   44[BANK1 ] unsigned long 
;;  bat_mv          2   12[BANK3 ] unsigned int 
;;  bat_mv_long     4   40[BANK1 ] unsigned long 
;;  vx_mv           4   36[BANK1 ] unsigned long 
;;  bat_mv          2   10[BANK3 ] unsigned int 
;;  v_ref           2    6[BANK3 ] unsigned int 
;;  v_init          2   26[BANK1 ] unsigned int 
;;  v               2    0[BANK2 ] unsigned int 
;;  ct              2   17[BANK3 ] unsigned int 
;;  tick            2    0        unsigned int 
;;  ty              1   19[BANK3 ] unsigned char 
;;  st              1   16[BANK3 ] unsigned char 
;;  old_st          1   48[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0      23      20       3
;;      Temps:          0       0       5       0       0
;;      Totals:         0       0      28      20       3
;;Total ram usage:       51 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		_Detect_BatteryType
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___wmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	135
global __ptext14
__ptext14:	;psect for function _ChargeProcess_Slot
psect	text14
	file	"charge_mgr.c"
	line	135
	global	__size_of_ChargeProcess_Slot
	__size_of_ChargeProcess_Slot	equ	__end_of_ChargeProcess_Slot-_ChargeProcess_Slot
	
_ChargeProcess_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _ChargeProcess_Slot: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	bsf	status, 6	;RP1=1, select bank2
	movwf	(ChargeProcess_Slot@idx)^0100h
	line	139
	
l7189:	
	line	142
	
l7191:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	
l7193:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	
l7195:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(ChargeProcess_Slot@v)^0100h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v+1)^0100h
	
l7197:	
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ct)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@ct+1)^0180h
	line	143
	
l7199:	
	movf	(ChargeProcess_Slot@st)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@old_st)^080h
	line	145
	goto	l7855
	line	148
	
l7201:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	149
	
l7203:	
	clrf	(ChargeProcess_Slot@st)^0180h
	incf	(ChargeProcess_Slot@st)^0180h,f
	line	150
	
l7205:	
	bcf	status, 5	;RP0=0, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10514
u10515:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10514:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10515
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	155
	
l7207:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u10521
	goto	u10520
u10521:
	goto	l7857
u10520:
	line	156
	
l7209:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	goto	l7857
	line	160
	
l7211:	
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	165
	
l7213:	
		decf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u10531
	goto	u10530
u10531:
	goto	l7219
u10530:
	line	167
	
l7215:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	168
	
l7217:	
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10544
u10545:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10544:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10545
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	179
	
l7219:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u10551
	goto	u10550
u10551:
	goto	l7243
u10550:
	
l7221:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	((??_ChargeProcess_Slot+0)^080h+0),w
iorwf	((??_ChargeProcess_Slot+0)^080h+1),w
	btfsc	status,2
	goto	u10561
	goto	u10560
u10561:
	goto	l7243
u10560:
	
l7223:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movlw	0Fh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	096h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	goto	u10571
	goto	u10570
u10571:
	goto	l7243
u10570:
	
l7225:	
		movlw	6
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u10581
	goto	u10580
u10581:
	goto	l7243
u10580:
	
l7227:	
	bcf	status, 5	;RP0=0, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	incf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u10591
	goto	u10590
u10591:
	goto	l7243
u10590:
	line	181
	
l7229:	
	movlw	low(06h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	182
	
l7231:	
	bcf	status, 5	;RP0=0, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10604
u10605:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10604:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10605
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	187
	
l7233:	
	movlw	low(04h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	188
	
l7235:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	189
	
l7237:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	190
	
l7239:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	191
	
l7241:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	192
	goto	l7857
	line	195
	
l7243:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0C8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u10611
	goto	u10610
u10611:
	goto	l7249
u10610:
	line	199
	
l7245:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u10621
	goto	u10620
u10621:
	goto	l7857
u10620:
	goto	l7209
	line	210
	
l7249:	
		movlw	200
	xorwf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u10631
	goto	u10630
u10631:
	goto	l7257
u10630:
	line	212
	
l7251:	
	bcf	status, 5	;RP0=0, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	213
	
l7253:	
	movlw	0Bh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u10641
	goto	u10640
u10641:
	goto	l7857
u10640:
	line	214
	
l7255:	
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10654
u10655:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10654:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10655
	
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_capFlag+1)^080h,f
	goto	l7857
	line	217
	
l7257:	
	movlw	0Bh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u10661
	goto	u10660
u10661:
	goto	l7317
u10660:
	
l7259:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u10671
	goto	u10670
u10671:
	goto	l7317
u10670:
	line	226
	
l7261:	
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10684
u10685:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10684:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10685
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfss	status,2
	goto	u10691
	goto	u10690
u10691:
	goto	l7273
u10690:
	
l7263:	
		movlw	5
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u10701
	goto	u10700
u10701:
	goto	l7273
u10700:
	line	228
	
l7265:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	229
	
l7267:	
	bcf	status, 5	;RP0=0, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	230
	
l7269:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7241
	line	242
	
l7273:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(ChargeProcess_Slot@v_init)^080h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_init+1)^080h
	line	244
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipc
	goto	u10711
	goto	u10710
u10711:
	goto	l7303
u10710:
	line	249
	
l7275:	
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10724
u10725:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10724:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10725
	
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	iorwf	(_g_highVFlag+1)^080h,f
	line	251
	
l7277:	
	movlw	0Bh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	055h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u10731
	goto	u10730
u10731:
	goto	l7285
u10730:
	line	254
	
l7279:	
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10744
u10745:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10744:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10745
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	255
	
l7281:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	256
	
l7283:	
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10754
u10755:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10754:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10755
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	257
	goto	l7329
	line	258
	
l7285:	
	movlw	03h
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0E8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u10761
	goto	u10760
u10761:
	goto	l7297
u10760:
	line	264
	
l7287:	
	bcf	status, 5	;RP0=0, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10774
u10775:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10774:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10775
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u10781
	goto	u10780
u10781:
	goto	l7209
u10780:
	
l7289:	
	movlw	01h
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	090h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u10791
	goto	u10790
u10791:
	goto	l7209
u10790:
	line	277
	
l7297:	
	bcf	status, 5	;RP0=0, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10804
u10805:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10804:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10805
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	278
	
l7299:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	279
	
l7301:	
	movlw	low(05h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	280
	goto	l7353
	line	286
	
l7303:	
	movf	(ChargeProcess_Slot@v)^0100h,w
	addlw	low(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	(ChargeProcess_Slot@v_init+1)^080h,w
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u10815
	movf	(ChargeProcess_Slot@v_init)^080h,w
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u10815:
	skipnc
	goto	u10811
	goto	u10810
u10811:
	goto	l7307
u10810:
	line	289
	
l7305:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	290
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	291
	goto	l613
	line	295
	
l7307:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	296
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	297
	
l613:	
	line	298
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u10821
	goto	u10820
u10821:
	goto	l7311
u10820:
	goto	l7857
	line	301
	
l7311:	
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10834
u10835:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10834:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10835
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u10841
	goto	u10840
u10841:
	goto	l7315
u10840:
	goto	l7857
	line	303
	
l7315:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7329
	line	306
	
l7317:	
	movlw	03h
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0E8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u10851
	goto	u10850
u10851:
	goto	l7329
u10850:
	
l7319:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u10861
	goto	u10860
u10861:
	goto	l7329
u10860:
	line	308
	
l7321:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@v_ref)^0180h
	incf	fsr0,f
	movf	indf,w
	movwf	(ChargeProcess_Slot@v_ref+1)^0180h
	line	309
	
l7323:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v_ref+1)^0180h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v_ref)^0180h,w
	skipnc
	goto	u10871
	goto	u10870
u10871:
	goto	l7329
u10870:
	
l7325:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	addlw	low(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_ref+1)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u10885
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@v_ref)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u10885:
	skipnc
	goto	u10881
	goto	u10880
u10881:
	goto	l7329
u10880:
	goto	l7209
	line	319
	
l7329:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10894
u10895:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10894:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10895
	
	movf	(_g_capFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_capFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u10901
	goto	u10900
u10901:
	goto	l7337
u10900:
	line	321
	
l7331:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u10914
u10915:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u10914:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u10915
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_capFlag+1)^080h,f
	line	322
	
l7333:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	323
	
l7335:	
	movlw	low(05h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	324
	goto	l7339
	line	327
	
l7337:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Detect_BatteryType@voltage+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	332
	
l7339:	
	movlw	01h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0F4h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u10921
	goto	u10920
u10921:
	goto	l7345
u10920:
	line	334
	
l7341:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	335
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u10931
	goto	u10930
u10931:
	goto	l7353
u10930:
	goto	l7857
	line	339
	
l7345:	
		movlw	5
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u10941
	goto	u10940
u10941:
	goto	l7353
u10940:
	
l7347:	
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u10951
	goto	u10950
u10951:
	goto	l7353
u10950:
	
l7349:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u10961
	goto	u10960
u10961:
	goto	l7353
u10960:
	line	341
	
l7351:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	345
	
l7353:	
		movlw	5
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u10971
	goto	u10970
u10971:
	goto	l7383
u10970:
	line	352
	
l7355:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	353
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u10981
	goto	u10980
u10981:
	goto	l7359
u10980:
	goto	l7857
	line	357
	
l7359:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
		incf	((_g_impCheckSlot)^080h),w
	btfsc	status,2
	goto	u10991
	goto	u10990
u10991:
	goto	l7365
u10990:
	
l7361:	
	movf	(_g_impCheckSlot)^080h,w
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	xorwf	(ChargeProcess_Slot@idx)^0100h,w
	skipnz
	goto	u11001
	goto	u11000
u11001:
	goto	l7365
u11000:
	goto	l7857
	line	359
	
l7365:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	363
	
l7367:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u11011
	goto	u11010
u11011:
	goto	l628
u11010:
	line	364
	
l7369:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(0+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	
l628:	
	line	368
	movlw	064h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_impData+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lwdiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_impData)^080h
	
l7371:	
	movlw	0Ch
	
u11025:
	clrc
	rlf	(_g_impData)^080h,f
	rlf	(_g_impData+1)^080h,f
	addlw	-1
	skipz
	goto	u11025
	
l7373:	
	movlw	(0A000h >> 8)
	addwf	(_g_impData+1)^080h,f
	
l7375:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	iorwf	(_g_impData)^080h,f
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	iorwf	(_g_impData+1)^080h,f
	line	369
	
l7377:	
	movlw	low(08h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	370
	
l7379:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	371
	
l7381:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	373
	
l7383:	
	bsf	status, 5	;RP0=1, select bank3
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11031
	goto	u11030
u11031:
	goto	l7387
u11030:
	
l7385:	
		movlw	6
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11041
	goto	u11040
u11041:
	goto	l7427
u11040:
	line	376
	
l7387:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	377
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11051
	goto	u11050
u11051:
	goto	l7391
u11050:
	goto	l7857
	line	379
	
l7391:	
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv)^080h

	
l7393:	
	movlw	0Ch
u11065:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv)^080h,f
	addlw	-1
	skipz
	goto	u11065

	
l7395:	
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long)^080h

	
l7397:	
	movf	(ChargeProcess_Slot@vx_mv+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11071
	addwf	(ChargeProcess_Slot@bat_mv_long+1)^080h,f
u11071:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11072
	addwf	(ChargeProcess_Slot@bat_mv_long+2)^080h,f
u11072:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11073
	addwf	(ChargeProcess_Slot@bat_mv_long+3)^080h,f
u11073:

	
l7399:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+1)^080h,w
	goto	u11080
	goto	u11081
u11080:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u11081:
	movf	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long+2)^080h,w
	goto	u11082
	goto	u11083
u11082:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u11083:
	movf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv)^0180h
	
l7401:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u11091
	goto	u11090
u11091:
	goto	l7405
u11090:
	
l7403:	
	movlw	low(02h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l7237
	
l7405:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipnc
	goto	u11101
	goto	u11100
u11101:
	goto	l7409
u11100:
	
l7407:	
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l7237
	
l7409:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv)^0180h,w
	skipc
	goto	u11111
	goto	u11110
u11111:
	goto	l7415
u11110:
	
l7411:	
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l7413:	
	bcf	status, 5	;RP0=0, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	goto	l7237
	
l7415:	
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l7417:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l7413
	line	381
	
l7427:	
	movf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11121
	goto	u11120
u11121:
	goto	l7443
u11120:
	line	384
	
l7429:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11131
	goto	u11130
u11131:
	goto	l7439
u11130:
	line	388
	
l7431:	
	movlw	03h
	bsf	status, 5	;RP0=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	0E8h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipnc
	goto	u11141
	goto	u11140
u11141:
	goto	l7301
u11140:
	goto	l7857
	line	398
	
l7439:	
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l7241
	line	402
	
l7443:	
		movlw	2
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11151
	goto	u11150
u11151:
	goto	l7447
u11150:
	
l7445:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11161
	goto	u11160
u11161:
	goto	l7857
u11160:
	line	404
	
l7447:	
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	405
	
l7449:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	406
	
l7451:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	407
	
l7453:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ty)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogType)	;volatile
	line	408
	
l7455:	
	bsf	(_g_detectLogFlag/8),(_g_detectLogFlag)&7	;volatile
	goto	l7857
	line	413
	
l7457:	
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	414
	
l7459:	
	movf	((ChargeProcess_Slot@ct)^0180h),w
iorwf	((ChargeProcess_Slot@ct+1)^0180h),w
	btfss	status,2
	goto	u11171
	goto	u11170
u11171:
	goto	l7463
u11170:
	goto	l7857
	line	421
	
l7463:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u11181
	goto	u11180
u11181:
	goto	l652
u11180:
	line	422
	
l7465:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___lldiv@divisor)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_adresult+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	movwf	((___lldiv@divisor)^080h)+1
	clrf	2+((___lldiv@divisor)^080h)
	clrf	3+((___lldiv@divisor)^080h)
	movlw	0
	movwf	(___lldiv@dividend+3)^080h
	movlw	04Bh
	movwf	(___lldiv@dividend+2)^080h
	movlw	0
	movwf	(___lldiv@dividend+1)^080h
	movlw	0
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv+1)^080h	;volatile
	movf	(0+(?___lldiv))^080h,w
	movwf	(_g_vcc_mv)^080h	;volatile
	
l652:	
	line	429
	bsf	status, 5	;RP0=1, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(012Ch)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(012Ch)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11195
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11195:
	skipnc
	goto	u11191
	goto	u11190
u11191:
	goto	l7477
u11190:
	line	431
	
l7467:	
	movlw	low(02h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	432
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	433
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	434
	
l7469:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11204
u11205:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11204:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11205
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	435
	
l7471:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	436
	
l7473:	
	movlw	low(02h)
	movwf	(_g_detectLogType)	;volatile
	goto	l7455
	line	447
	
l7477:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11211
	goto	u11210
u11211:
	goto	l7487
u11210:
	
l7479:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	096h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u11221
	goto	u11220
u11221:
	goto	l7487
u11220:
	line	449
	
l7481:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	450
	clrf	(ChargeProcess_Slot@st)^0180h
	line	451
	
l7483:	
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	452
	
l7485:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11234
u11235:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11234:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11235
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	453
	goto	l7857
	line	461
	
l7487:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	swapf	(_g_impData+1)^080h,w
	andlw	15
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_vcc_mv)^080h,w	;volatile
	addlw	low(0C8h)
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11245
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___wmul)),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11245:
	skipnc
	goto	u11241
	goto	u11240
u11241:
	goto	l7491
u11240:
	goto	l7505
	line	469
	
l7491:	
	movlw	0FFh
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movlw	08h
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	skipc
	goto	u11251
	goto	u11250
u11251:
	goto	l7495
u11250:
	goto	l7545
	line	471
	
l7495:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11261
	goto	u11260
u11261:
	goto	l7499
u11260:
	goto	l7545
	line	481
	
l7499:	
	movlw	low(09h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	482
	
l7501:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	goto	l7485
	line	489
	
l7505:	
	movlw	low(0FFh)
	movwf	(_g_impCheckSlot)^080h
	line	490
	
l7507:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11274
u11275:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11274:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11275
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	491
	
l7509:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	incf	(ChargeProcess_Slot@ty)^0180h,f
	line	492
	
l7511:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lmul@multiplier)^080h
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_396+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_396+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_396+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_396)^080h

	
l7513:	
	movlw	0Ch
u11285:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_396+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_396+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_396+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_396)^080h,f
	addlw	-1
	skipz
	goto	u11285

	
l7515:	
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_397+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_397+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_397+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@bat_mv_long_397)^080h

	
l7517:	
	movf	(ChargeProcess_Slot@vx_mv_396+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv_396+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv_396+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv_396)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	addwf	(ChargeProcess_Slot@bat_mv_long_397)^080h,f
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11291
	addwf	(ChargeProcess_Slot@bat_mv_long_397+1)^080h,f
u11291:
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11292
	addwf	(ChargeProcess_Slot@bat_mv_long_397+2)^080h,f
u11292:
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11293
	addwf	(ChargeProcess_Slot@bat_mv_long_397+3)^080h,f
u11293:

	
l7519:	
	movlw	0
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	movf	(ChargeProcess_Slot@bat_mv_long_397)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	movf	(ChargeProcess_Slot@bat_mv_long_397+1)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_397+1)^080h,w
	goto	u11300
	goto	u11301
u11300:
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u11301:
	movf	(ChargeProcess_Slot@bat_mv_long_397+2)^080h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_397+2)^080h,w
	goto	u11302
	goto	u11303
u11302:
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u11303:
	movf	(ChargeProcess_Slot@bat_mv_long_397+3)^080h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_397+3)^080h,w
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_398+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_398)^0180h
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_398+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_398)^0180h,w
	skipnc
	goto	u11311
	goto	u11310
u11311:
	goto	l7523
u11310:
	goto	l7403
	
l7523:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_398+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_398)^0180h,w
	skipnc
	goto	u11321
	goto	u11320
u11321:
	goto	l7527
u11320:
	goto	l7407
	
l7527:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_398+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_398)^0180h,w
	skipc
	goto	u11331
	goto	u11330
u11331:
	goto	l7415
u11330:
	goto	l7411
	line	504
	
l7545:	
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	505
	
l7547:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11344
u11345:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11344:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11345
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	506
	
l7549:	
	movlw	low(06h)
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	507
	
l7551:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(___lmul@multiplier)^080h
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(___lmul@multiplier)^080h
	clrf	2+(___lmul@multiplier)^080h
	clrf	3+(___lmul@multiplier)^080h
	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplicand)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplicand)^080h)+1
	clrf	2+((___lmul@multiplicand)^080h)
	clrf	3+((___lmul@multiplicand)^080h)
	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_399+3)^080h
	movf	(2+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_399+2)^080h
	movf	(1+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_399+1)^080h
	movf	(0+(?___lmul))^080h,w
	movwf	(ChargeProcess_Slot@vx_mv_399)^080h

	
l7553:	
	movlw	0Ch
u11355:
	clrc
	rrf	(ChargeProcess_Slot@vx_mv_399+3)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_399+2)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_399+1)^080h,f
	rrf	(ChargeProcess_Slot@vx_mv_399)^080h,f
	addlw	-1
	skipz
	goto	u11355

	movf	(_g_vcc_mv)^080h,w	;volatile
	movwf	(___lmul@multiplier)^080h
	movf	(_g_vcc_mv+1)^080h,w	;volatile
	movwf	((___lmul@multiplier)^080h)+1
	clrf	2+((___lmul@multiplier)^080h)
	clrf	3+((___lmul@multiplier)^080h)
	movlw	0CEh
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(3+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long_400+3)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long_400+2)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long_400+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_long_400)^0180h

	bcf	status, 6	;RP1=0, select bank1
	movf	(ChargeProcess_Slot@vx_mv_399+3)^080h,w
	movwf	(___lmul@multiplier+3)^080h
	movf	(ChargeProcess_Slot@vx_mv_399+2)^080h,w
	movwf	(___lmul@multiplier+2)^080h
	movf	(ChargeProcess_Slot@vx_mv_399+1)^080h,w
	movwf	(___lmul@multiplier+1)^080h
	movf	(ChargeProcess_Slot@vx_mv_399)^080h,w
	movwf	(___lmul@multiplier)^080h

	movlw	07Ch
	movwf	(___lmul@multiplicand)^080h
	clrf	(___lmul@multiplicand+1)^080h
	clrf	(___lmul@multiplicand+2)^080h
	clrf	(___lmul@multiplicand+3)^080h

	fcall	___lmul
	movf	(0+(?___lmul))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long_400)^0180h,f
	bcf	status, 6	;RP1=0, select bank1
	movf	(1+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11361
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long_400+1)^0180h,f
u11361:
	bcf	status, 6	;RP1=0, select bank1
	movf	(2+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11362
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long_400+2)^0180h,f
u11362:
	bcf	status, 6	;RP1=0, select bank1
	movf	(3+(?___lmul))^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u11363
	bsf	status, 6	;RP1=1, select bank3
	addwf	(ChargeProcess_Slot@bat_mv_long_400+3)^0180h,f
u11363:
	bcf	status, 6	;RP1=0, select bank1
	bsf	status, 6	;RP1=1, select bank3

	movlw	0
	bcf	status, 6	;RP1=0, select bank1
	movwf	(___lldiv@divisor+3)^080h
	movlw	0
	movwf	(___lldiv@divisor+2)^080h
	movlw	03h
	movwf	(___lldiv@divisor+1)^080h
	movlw	0E8h
	movwf	(___lldiv@divisor)^080h

	movlw	0F4h
	movwf	((??_ChargeProcess_Slot+0)^080h+0)
	movlw	01h
	movwf	((??_ChargeProcess_Slot+0)^080h+0+1)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+2)
	movlw	0
	movwf	((??_ChargeProcess_Slot+0)^080h+0+3)
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long_400)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+0,f
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long_400+1)^0180h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_400+1)^0180h,w
	goto	u11370
	goto	u11371
u11370:
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+1,f
u11371:
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long_400+2)^0180h,w
	skipnc
	incfsz	(ChargeProcess_Slot@bat_mv_long_400+2)^0180h,w
	goto	u11372
	goto	u11373
u11372:
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+2,f
u11373:
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@bat_mv_long_400+3)^0180h,w
	skipnc
	incf	(ChargeProcess_Slot@bat_mv_long_400+3)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	addwf	(??_ChargeProcess_Slot+0)^080h+3,f
	movf	3+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+3)^080h
	movf	2+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+2)^080h
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend+1)^080h
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(___lldiv@dividend)^080h

	fcall	___lldiv
	movf	(1+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_401+1)^0180h
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(?___lldiv))^080h,w
	bsf	status, 6	;RP1=1, select bank3
	movwf	(ChargeProcess_Slot@bat_mv_401)^0180h
	
l7555:	
	movlw	0
	subwf	(ChargeProcess_Slot@bat_mv_401+1)^0180h,w
	movlw	065h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_401)^0180h,w
	skipnc
	goto	u11381
	goto	u11380
u11381:
	goto	l7559
u11380:
	goto	l7403
	
l7559:	
	movlw	03h
	subwf	(ChargeProcess_Slot@bat_mv_401+1)^0180h,w
	movlw	084h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_401)^0180h,w
	skipnc
	goto	u11391
	goto	u11390
u11391:
	goto	l7563
u11390:
	goto	l7407
	
l7563:	
	movlw	05h
	subwf	(ChargeProcess_Slot@bat_mv_401+1)^0180h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@bat_mv_401)^0180h,w
	skipc
	goto	u11401
	goto	u11400
u11401:
	goto	l7569
u11400:
	
l7565:	
	movlw	low(05h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l7567:	
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	indf
	goto	l7237
	
l7569:	
	movlw	low(04h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l7571:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l7567
	line	521
	
l7581:	
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	531
	
l7585:	
	movlw	0FFh
	bcf	status, 6	;RP1=0, select bank1
	andwf	(_g_impData)^080h,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	0Fh
	andwf	(_g_impData+1)^080h,w
	movwf	1+(??_ChargeProcess_Slot+0)^080h+0
	movf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	addlw	low(064h)
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	movf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipnc
	addlw	1
	addlw	high(064h)
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	skipz
	goto	u11415
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
u11415:
	skipnc
	goto	u11411
	goto	u11410
u11411:
	goto	l7589
u11410:
	goto	l7545
	line	535
	
l7589:	
	movlw	0
	bsf	status, 6	;RP1=1, select bank3
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	064h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11421
	goto	u11420
u11421:
	goto	l7857
u11420:
	line	537
	
l7591:	
	movlw	low(03h)
	movwf	(ChargeProcess_Slot@ty)^0180h
	line	538
	movlw	low(07h)
	movwf	(ChargeProcess_Slot@st)^0180h
	line	539
	movlw	low(0FFh)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_impCheckSlot)^080h
	line	540
	
l7593:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11434
u11435:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11434:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11435
	
	comf	(??_ChargeProcess_Slot+1)^080h+0,f
	comf	(??_ChargeProcess_Slot+1)^080h+1,f
	movf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag)^080h,f
	movf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	andwf	(_g_highVFlag+1)^080h,f
	line	541
	
l7595:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	542
	
l7597:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_detectLogSlot)	;volatile
	line	543
	
l7599:	
	movlw	low(03h)
	movwf	(_g_detectLogType)	;volatile
	goto	l7455
	line	552
	
l7603:	
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	553
	movlw	017h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	071h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11441
	goto	u11440
u11441:
	goto	l7607
u11440:
	line	555
	
l7605:	
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	556
	goto	l7857
	line	558
	
l7607:	
	movlw	02h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11451
	goto	u11450
u11451:
	goto	l7613
u11450:
	line	560
	
l7609:	
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	561
	
l7611:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	562
	goto	l7857
	line	564
	
l7613:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11461
	goto	u11460
u11461:
	goto	l7857
u11460:
	goto	l7605
	line	572
	
l7617:	
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	573
	movlw	075h
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	031h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11471
	goto	u11470
u11471:
	goto	l7621
u11470:
	goto	l7605
	line	578
	
l7621:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11481
	goto	u11480
u11481:
	goto	l7627
u11480:
	line	580
	
l7623:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	581
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u11491
	goto	u11490
u11491:
	goto	l7629
u11490:
	goto	l7605
	line	589
	
l7627:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	591
	
l7629:	
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	08Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11501
	goto	u11500
u11501:
	goto	l7857
u11500:
	line	593
	
l7631:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	594
	
l7633:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	line	595
	
l7635:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	596
	
l7637:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l7209
	line	602
	
l7641:	
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	603
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	060h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11511
	goto	u11510
u11511:
	goto	l7647
u11510:
	line	605
	
l7643:	
	movlw	060h
	subwf	(ChargeProcess_Slot@ct)^0180h,f
	movlw	0EAh
	skipc
	decf	(ChargeProcess_Slot@ct+1)^0180h,f
	subwf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	606
	
l7645:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	608
	
l7647:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(012h)
	subwf	indf,w
	skipc
	goto	u11521
	goto	u11520
u11521:
	goto	l7651
u11520:
	goto	l7605
	line	617
	
l7651:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11531
	goto	u11530
u11531:
	goto	l7657
u11530:
	
l7653:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11541
	goto	u11540
u11541:
	goto	l7657
u11540:
	goto	l694
	line	623
	
l7657:	
	bcf	status, 5	;RP0=0, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11555
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11555:
	skipnc
	goto	u11551
	goto	u11550
u11551:
	goto	l694
u11550:
	
l7659:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	624
	
l694:	
	line	630
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u11561
	goto	u11560
u11561:
	goto	l7675
u11560:
	
l7661:	
		movlw	6
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11571
	goto	u11570
u11571:
	goto	l7675
u11570:
	line	633
	
l7663:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	634
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11581
	goto	u11580
u11581:
	goto	l7667
u11580:
	goto	l7857
	line	636
	
l7667:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	637
	
l7669:	
	bsf	status, 5	;RP0=1, select bank3
	clrf	(ChargeProcess_Slot@st)^0180h
	incf	(ChargeProcess_Slot@st)^0180h,f
	goto	l7611
	line	643
	
l7675:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	652
	
l7677:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11591
	goto	u11590
u11591:
	goto	l7685
u11590:
	
l7679:	
	bsf	status, 5	;RP0=1, select bank3
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11601
	goto	u11600
u11601:
	goto	l7685
u11600:
	line	654
	
l7681:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l7611
	line	662
	
l7685:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11611
	goto	u11610
u11611:
	goto	l7693
u11610:
	
l7687:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11621
	goto	u11620
u11621:
	goto	l7693
u11620:
	line	664
	
l7689:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	665
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u11631
	goto	u11630
u11631:
	goto	l593
u11630:
	goto	l7605
	line	673
	
l7693:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	675
	
l7695:	
	movlw	0Ch
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	01Ch
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11641
	goto	u11640
u11641:
	goto	l593
u11640:
	
l7697:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11651
	goto	u11650
u11651:
	goto	l7701
u11650:
	
l7699:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11661
	goto	u11660
u11661:
	goto	l593
u11660:
	line	677
	
l7701:	
	movlw	low(05h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	goto	l7611
	line	684
	
l7705:	
	incf	(ChargeProcess_Slot@ct)^0180h,f
	skipnz
	incf	(ChargeProcess_Slot@ct+1)^0180h,f
	line	685
	movlw	0EAh
	subwf	(ChargeProcess_Slot@ct+1)^0180h,w
	movlw	061h
	skipnz
	subwf	(ChargeProcess_Slot@ct)^0180h,w
	skipc
	goto	u11671
	goto	u11670
u11671:
	goto	l707
u11670:
	line	686
	
l7707:	
	movlw	low(06h)
	movwf	(ChargeProcess_Slot@st)^0180h
	
l707:	
	line	694
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11681
	goto	u11680
u11681:
	goto	l7713
u11680:
	
l7709:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11691
	goto	u11690
u11691:
	goto	l7713
u11690:
	goto	l7857
	line	698
	
l7713:	
	bcf	status, 5	;RP0=0, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	skipz
	goto	u11705
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
u11705:
	skipnc
	goto	u11701
	goto	u11700
u11701:
	goto	l7717
u11700:
	
l7715:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(ChargeProcess_Slot@v)^0100h,w
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	line	703
	
l7717:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11711
	goto	u11710
u11711:
	goto	l7743
u11710:
	line	705
	
l7719:	
	bsf	status, 5	;RP0=1, select bank3
		decf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11721
	goto	u11720
u11721:
	goto	l7731
u11720:
	line	707
	
l7721:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	708
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11731
	goto	u11730
u11731:
	goto	l7725
u11730:
	goto	l7857
	line	710
	
l7725:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7681
	line	715
	
l7731:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	716
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11741
	goto	u11740
u11741:
	goto	l7735
u11740:
	goto	l7857
	line	718
	
l7735:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	719
	
l7737:	
	bsf	status, 5	;RP0=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	line	720
	
l7739:	
	bsf	status, 5	;RP0=1, select bank3
	clrf	(ChargeProcess_Slot@st)^0180h
	goto	l7611
	line	730
	
l7743:	
	clrc
	rlf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_ChargeProcess_Slot+0)^080h+0+1
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	0+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	(??_ChargeProcess_Slot+2)^080h+0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	skipc
	incf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	1+(??_ChargeProcess_Slot+0)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+2)^080h+0
	movlw	01h
	subwf	1+(??_ChargeProcess_Slot+2)^080h+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_ChargeProcess_Slot+2)^080h+0,w
	skipc
	goto	u11751
	goto	u11750
u11751:
	goto	l7757
u11750:
	
l7745:	
		movlw	6
	bsf	status, 6	;RP1=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11761
	goto	u11760
u11761:
	goto	l7757
u11760:
	line	732
	
l7747:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	733
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipc
	goto	u11771
	goto	u11770
u11771:
	goto	l7759
u11770:
	line	735
	
l7749:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	736
	
l7751:	
	bsf	status, 5	;RP0=1, select bank3
	clrf	(ChargeProcess_Slot@ty)^0180h
	goto	l7669
	line	744
	
l7757:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	748
	
l7759:	
	movlw	0Fh
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0Ah
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11781
	goto	u11780
u11781:
	goto	l7765
u11780:
	line	750
	
l7761:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	751
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u11791
	goto	u11790
u11791:
	goto	l593
u11790:
	goto	l7605
	line	759
	
l7765:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l7857
	line	770
	
l7767:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11801
	goto	u11800
u11801:
	goto	l7785
u11800:
	line	772
	
l7769:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	773
	
l7771:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11811
	goto	u11810
u11811:
	goto	l7775
u11810:
	
l7773:	
	movlw	02h
	movwf	(_ChargeProcess_Slot$402)^0180h
	clrf	(_ChargeProcess_Slot$402+1)^0180h
	goto	l7777
	
l7775:	
	movlw	032h
	movwf	(_ChargeProcess_Slot$402)^0180h
	clrf	(_ChargeProcess_Slot$402+1)^0180h
	
l7777:	
	bcf	status, 5	;RP0=0, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	movf	(_ChargeProcess_Slot$402+1)^0180h,w
	xorlw	80h
	sublw	080h
	skipz
	goto	u11825
	movf	(_ChargeProcess_Slot$402)^0180h,w
	subwf	indf,w
u11825:

	skipc
	goto	u11821
	goto	u11820
u11821:
	goto	l7857
u11820:
	line	775
	
l7779:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l7739
	line	784
	
l7785:	
	movlw	0Ah
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0F0h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipnc
	goto	u11831
	goto	u11830
u11831:
	goto	l7241
u11830:
	line	786
	
l7787:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	787
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11841
	goto	u11840
u11841:
	goto	l7791
u11840:
	goto	l7857
	line	789
	
l7791:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	790
	
l7793:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	movwf	(ChargeProcess_Slot@st)^0180h
	line	791
	
l7795:	
	clrf	(ChargeProcess_Slot@ct)^0180h
	clrf	(ChargeProcess_Slot@ct+1)^0180h
	goto	l7637
	line	803
	
l7803:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	096h
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11851
	goto	u11850
u11851:
	goto	l7817
u11850:
	line	805
	
l7805:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	806
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11861
	goto	u11860
u11861:
	goto	l7735
u11860:
	goto	l7857
	line	822
	
l7817:	
		movlw	2
	bsf	status, 5	;RP0=1, select bank3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfsc	status,2
	goto	u11871
	goto	u11870
u11871:
	goto	l7821
u11870:
	
l7819:	
		movlw	3
	xorwf	((ChargeProcess_Slot@ty)^0180h),w
	btfss	status,2
	goto	u11881
	goto	u11880
u11881:
	goto	l7837
u11880:
	line	824
	
l7821:	
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	08Dh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11891
	goto	u11890
u11891:
	goto	l7241
u11890:
	
l7823:	
	incf	(ChargeProcess_Slot@idx)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(??_ChargeProcess_Slot+0)^080h+0
	movlw	01h
	movwf	(??_ChargeProcess_Slot+1)^080h+0
	movlw	0
	movwf	(??_ChargeProcess_Slot+1)^080h+0+1
	goto	u11904
u11905:
	clrc
	rlf	(??_ChargeProcess_Slot+1)^080h+0,f
	rlf	(??_ChargeProcess_Slot+1)^080h+1,f
u11904:
	decfsz	(??_ChargeProcess_Slot+0)^080h+0,f
	goto	u11905
	
	movf	(_g_highVFlag)^080h,w
	andwf	0+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	(??_ChargeProcess_Slot+3)^080h+0
	movf	(_g_highVFlag+1)^080h,w
	andwf	1+(??_ChargeProcess_Slot+1)^080h+0,w
	movwf	1+(??_ChargeProcess_Slot+3)^080h+0
	movf	((??_ChargeProcess_Slot+3)^080h+0),w
iorwf	((??_ChargeProcess_Slot+3)^080h+1),w
	btfsc	status,2
	goto	u11911
	goto	u11910
u11911:
	goto	l7241
u11910:
	line	826
	
l7825:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	827
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11921
	goto	u11920
u11921:
	goto	l7667
u11920:
	goto	l7857
	line	840
	
l7837:	
	movlw	02h
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@v+1)^0100h,w
	movlw	0EFh
	skipnz
	subwf	(ChargeProcess_Slot@v)^0100h,w
	skipc
	goto	u11931
	goto	u11930
u11931:
	goto	l7241
u11930:
	line	842
	
l7839:	
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	843
	movf	(ChargeProcess_Slot@idx)^0100h,w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u11941
	goto	u11940
u11941:
	goto	l7667
u11940:
	goto	l7857
	line	856
	
l7851:	
	clrf	(ChargeProcess_Slot@st)^0180h
	line	857
	goto	l7857
	line	145
	
l7855:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@st)^0180h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l7201
	xorlw	1^0	; case 1
	skipnz
	goto	l7211
	xorlw	2^1	; case 2
	skipnz
	goto	l7603
	xorlw	3^2	; case 3
	skipnz
	goto	l7617
	xorlw	4^3	; case 4
	skipnz
	goto	l7641
	xorlw	5^4	; case 5
	skipnz
	goto	l7705
	xorlw	6^5	; case 6
	skipnz
	goto	l7767
	xorlw	7^6	; case 7
	skipnz
	goto	l7803
	xorlw	8^7	; case 8
	skipnz
	goto	l7457
	xorlw	9^8	; case 9
	skipnz
	goto	l7581
	goto	l7851
	opt asmopt_pop

	line	858
	
l593:	
	line	860
	
l7857:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@st)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ty)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	movwf	indf
	movlw	low(06h)
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ct)^0180h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(ChargeProcess_Slot@ct+1)^0180h,w
	movwf	indf
	line	863
	
l7859:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank2
	subwf	(ChargeProcess_Slot@idx)^0100h,w
	skipnc
	goto	u11951
	goto	u11950
u11951:
	goto	l746
u11950:
	
l7861:	
	bsf	status, 5	;RP0=1, select bank3
	movf	(ChargeProcess_Slot@st)^0180h,w
	bcf	status, 6	;RP1=0, select bank1
	xorwf	(ChargeProcess_Slot@old_st)^080h,w
	skipnz
	goto	u11961
	goto	u11960
u11961:
	goto	l746
u11960:
	line	865
	
l7863:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@idx)^0100h,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_dbgSlot)	;volatile
	line	866
	bsf	status, 5	;RP0=1, select bank1
	movf	(ChargeProcess_Slot@old_st)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_dbgOldState)	;volatile
	line	867
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@st)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_dbgNewState)	;volatile
	line	868
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(ChargeProcess_Slot@ty)^0180h,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_g_dbgNewType)	;volatile
	line	869
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v+1)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_dbgVoltage+1)^080h	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movf	(ChargeProcess_Slot@v)^0100h,w
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_dbgVoltage)^080h	;volatile
	line	870
	
l7865:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_dbgDetectFlag/8),(_g_dbgDetectFlag)&7	;volatile
	line	872
	
l746:	
	return
	opt stack 0
GLOBAL	__end_of_ChargeProcess_Slot
	__end_of_ChargeProcess_Slot:
	signat	_ChargeProcess_Slot,4217
	global	___wmul

;; *************** function ___wmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
;; Parameters:    Size  Location     Type
;;  multiplier      2   26[BANK0 ] unsigned int 
;;  multiplicand    2   28[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  product         2    0[BANK1 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   26[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       0       2       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       2       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
global __ptext15
__ptext15:	;psect for function ___wmul
psect	text15
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
	global	__size_of___wmul
	__size_of___wmul	equ	__end_of___wmul-___wmul
	
___wmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___wmul: [wreg+status,2+status,0]
	line	43
	
l6715:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___wmul@product)^080h
	clrf	(___wmul@product+1)^080h
	line	45
	
l6717:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(___wmul@multiplier),(0)&7
	goto	u9851
	goto	u9850
u9851:
	goto	l6721
u9850:
	line	46
	
l6719:	
	movf	(___wmul@multiplicand),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(___wmul@product)^080h,f
	skipnc
	incf	(___wmul@product+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(___wmul@multiplicand+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(___wmul@product+1)^080h,f
	line	47
	
l6721:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(___wmul@multiplicand),f
	rlf	(___wmul@multiplicand+1),f
	line	48
	
l6723:	
	clrc
	rrf	(___wmul@multiplier+1),f
	rrf	(___wmul@multiplier),f
	line	49
	
l6725:	
	movf	((___wmul@multiplier)),w
iorwf	((___wmul@multiplier+1)),w
	btfss	status,2
	goto	u9861
	goto	u9860
u9861:
	goto	l6717
u9860:
	line	52
	
l6727:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___wmul@product+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___wmul+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(___wmul@product)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___wmul)
	line	53
	
l869:	
	return
	opt stack 0
GLOBAL	__end_of___wmul
	__end_of___wmul:
	signat	___wmul,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2   26[BANK0 ] unsigned int 
;;  dividend        2   28[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    1[BANK1 ] unsigned int 
;;  counter         1    0[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2   26[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       0       3       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       3       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext16
__ptext16:	;psect for function ___lwdiv
psect	text16
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l6563:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___lwdiv@quotient)^080h
	clrf	(___lwdiv@quotient+1)^080h
	line	15
	
l6565:	
	bcf	status, 5	;RP0=0, select bank0
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u9571
	goto	u9570
u9571:
	goto	l6585
u9570:
	line	16
	
l6567:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___lwdiv@counter)^080h
	incf	(___lwdiv@counter)^080h,f
	line	17
	goto	l6571
	line	18
	
l6569:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	bsf	status, 5	;RP0=1, select bank1
	incf	(___lwdiv@counter)^080h,f
	line	17
	
l6571:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u9581
	goto	u9580
u9581:
	goto	l6569
u9580:
	line	22
	
l6573:	
	bsf	status, 5	;RP0=1, select bank1
	clrc
	rlf	(___lwdiv@quotient)^080h,f
	rlf	(___lwdiv@quotient+1)^080h,f
	line	23
	
l6575:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u9595
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u9595:
	skipc
	goto	u9591
	goto	u9590
u9591:
	goto	l6581
u9590:
	line	24
	
l6577:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l6579:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(___lwdiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l6581:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l6583:	
	bsf	status, 5	;RP0=1, select bank1
	decfsz	(___lwdiv@counter)^080h,f
	goto	u9601
	goto	u9600
u9601:
	goto	l6573
u9600:
	line	30
	
l6585:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lwdiv@quotient+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lwdiv+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lwdiv@quotient)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(?___lwdiv)
	line	31
	
l1206:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    0[BANK1 ] unsigned long 
;;  multiplicand    4    4[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4   26[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    0[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       8       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext17
__ptext17:	;psect for function ___lmul
psect	text17
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l6525:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l878:	
	line	121
	bsf	status, 5	;RP0=1, select bank1
	btfss	(___lmul@multiplier)^080h,(0)&7
	goto	u9501
	goto	u9500
u9501:
	goto	l6529
u9500:
	line	122
	
l6527:	
	movf	(___lmul@multiplicand)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product),f
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lmul@multiplicand+1)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9511
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product+1),f
u9511:
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lmul@multiplicand+2)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9512
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product+2),f
u9512:
	bsf	status, 5	;RP0=1, select bank1
	movf	(___lmul@multiplicand+3)^080h,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9513
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___lmul@product+3),f
u9513:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 5	;RP0=0, select bank0

	line	123
	
l6529:	
	clrc
	bsf	status, 5	;RP0=1, select bank1
	rlf	(___lmul@multiplicand)^080h,f
	rlf	(___lmul@multiplicand+1)^080h,f
	rlf	(___lmul@multiplicand+2)^080h,f
	rlf	(___lmul@multiplicand+3)^080h,f
	line	124
	
l6531:	
	clrc
	rrf	(___lmul@multiplier+3)^080h,f
	rrf	(___lmul@multiplier+2)^080h,f
	rrf	(___lmul@multiplier+1)^080h,f
	rrf	(___lmul@multiplier)^080h,f
	line	125
	movf	(___lmul@multiplier+3)^080h,w
	iorwf	(___lmul@multiplier+2)^080h,w
	iorwf	(___lmul@multiplier+1)^080h,w
	iorwf	(___lmul@multiplier)^080h,w
	skipz
	goto	u9521
	goto	u9520
u9521:
	goto	l878
u9520:
	line	128
	
l6533:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+3),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+2),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___lmul@product),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(?___lmul)^080h

	line	129
	
l881:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    8[BANK1 ] unsigned long 
;;  dividend        4   12[BANK1 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   17[BANK1 ] unsigned long 
;;  counter         1   16[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    8[BANK1 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       8       0       0
;;      Locals:         0       0       5       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0      13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext18
__ptext18:	;psect for function ___lldiv
psect	text18
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l6537:	
	clrf	(___lldiv@quotient)^080h
	clrf	(___lldiv@quotient+1)^080h
	clrf	(___lldiv@quotient+2)^080h
	clrf	(___lldiv@quotient+3)^080h
	line	15
	
l6539:	
	movf	(___lldiv@divisor+3)^080h,w
	iorwf	(___lldiv@divisor+2)^080h,w
	iorwf	(___lldiv@divisor+1)^080h,w
	iorwf	(___lldiv@divisor)^080h,w
	skipnz
	goto	u9531
	goto	u9530
u9531:
	goto	l6559
u9530:
	line	16
	
l6541:	
	clrf	(___lldiv@counter)^080h
	incf	(___lldiv@counter)^080h,f
	line	17
	goto	l6545
	line	18
	
l6543:	
	clrc
	rlf	(___lldiv@divisor)^080h,f
	rlf	(___lldiv@divisor+1)^080h,f
	rlf	(___lldiv@divisor+2)^080h,f
	rlf	(___lldiv@divisor+3)^080h,f
	line	19
	incf	(___lldiv@counter)^080h,f
	line	17
	
l6545:	
	btfss	(___lldiv@divisor+3)^080h,(31)&7
	goto	u9541
	goto	u9540
u9541:
	goto	l6543
u9540:
	line	22
	
l6547:	
	clrc
	rlf	(___lldiv@quotient)^080h,f
	rlf	(___lldiv@quotient+1)^080h,f
	rlf	(___lldiv@quotient+2)^080h,f
	rlf	(___lldiv@quotient+3)^080h,f
	line	23
	
l6549:	
	movf	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,w
	skipz
	goto	u9555
	movf	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,w
	skipz
	goto	u9555
	movf	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,w
	skipz
	goto	u9555
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,w
u9555:
	skipc
	goto	u9551
	goto	u9550
u9551:
	goto	l6555
u9550:
	line	24
	
l6551:	
	movf	(___lldiv@divisor)^080h,w
	subwf	(___lldiv@dividend)^080h,f
	movf	(___lldiv@divisor+1)^080h,w
	skipc
	incfsz	(___lldiv@divisor+1)^080h,w
	subwf	(___lldiv@dividend+1)^080h,f
	movf	(___lldiv@divisor+2)^080h,w
	skipc
	incfsz	(___lldiv@divisor+2)^080h,w
	subwf	(___lldiv@dividend+2)^080h,f
	movf	(___lldiv@divisor+3)^080h,w
	skipc
	incfsz	(___lldiv@divisor+3)^080h,w
	subwf	(___lldiv@dividend+3)^080h,f
	line	25
	
l6553:	
	bsf	(___lldiv@quotient)^080h+(0/8),(0)&7
	line	27
	
l6555:	
	clrc
	rrf	(___lldiv@divisor+3)^080h,f
	rrf	(___lldiv@divisor+2)^080h,f
	rrf	(___lldiv@divisor+1)^080h,f
	rrf	(___lldiv@divisor)^080h,f
	line	28
	
l6557:	
	decfsz	(___lldiv@counter)^080h,f
	goto	u9561
	goto	u9560
u9561:
	goto	l6547
u9560:
	line	30
	
l6559:	
	movf	(___lldiv@quotient+3)^080h,w
	movwf	(?___lldiv+3)^080h
	movf	(___lldiv@quotient+2)^080h,w
	movwf	(?___lldiv+2)^080h
	movf	(___lldiv@quotient+1)^080h,w
	movwf	(?___lldiv+1)^080h
	movf	(___lldiv@quotient)^080h,w
	movwf	(?___lldiv)^080h

	line	31
	
l1153:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1   26[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1   28[BANK0 ] unsigned char 
;;  product         1   27[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_ChargeProcess_Slot
;;		_Charging_Control
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext19
__ptext19:	;psect for function ___bmul
psect	text19
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___bmul: [wreg+status,2+status,0]
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplier)
	line	6
	
l6731:	
	clrf	(___bmul@product)
	line	43
	
l6733:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u9871
	goto	u9870
u9871:
	goto	l6737
u9870:
	line	44
	
l6735:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l6737:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l6739:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u9881
	goto	u9880
u9881:
	goto	l6733
u9880:
	line	50
	
l6741:	
	movf	(___bmul@product),w
	line	51
	
l887:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 70 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2   26[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	70
global __ptext20
__ptext20:	;psect for function _Detect_BatteryType
psect	text20
	file	"charge_mgr.c"
	line	70
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	72
	
l6683:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u9791
	goto	u9790
u9791:
	goto	l6689
u9790:
	line	73
	
l6685:	
	movlw	low(0)
	goto	l580
	line	74
	
l6689:	
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u9801
	goto	u9800
u9801:
	goto	l6695
u9800:
	goto	l6685
	line	85
	
l6695:	
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u9811
	goto	u9810
u9811:
	goto	l6703
u9810:
	
l6697:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u9821
	goto	u9820
u9821:
	goto	l6703
u9820:
	line	86
	
l6699:	
	movlw	low(05h)
	goto	l580
	line	91
	
l6703:	
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u9831
	goto	u9830
u9831:
	goto	l6685
u9830:
	
l6705:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u9841
	goto	u9840
u9841:
	goto	l6685
u9840:
	line	92
	
l6707:	
	movlw	low(01h)
	line	95
	
l580:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1   26[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    1[BANK1 ] unsigned char 
;;  j               1    0[BANK1 ] unsigned char 
;;  adsum           4    3[BANK1 ] volatile unsigned long 
;;  ad_temp         2   11[BANK1 ] volatile unsigned int 
;;  admax           2    9[BANK1 ] volatile unsigned int 
;;  admin           2    7[BANK1 ] volatile unsigned int 
;;  i               1    2[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       0      13       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0       5      13       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Do_AdcSample
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_ChargeProcess_Slot
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	49
global __ptext21
__ptext21:	;psect for function _ADC_Sample
psect	text21
	file	"adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
	bsf	status, 5	;RP0=1, select bank1
	movwf	(ADC_Sample@adch)^080h
	line	51
	
l6435:	
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	52
	
l6437:	
	clrf	(ADC_Sample@admin)^080h	;volatile
	clrf	(ADC_Sample@admin+1)^080h	;volatile
	line	53
	clrf	(ADC_Sample@admax)^080h	;volatile
	clrf	(ADC_Sample@admax+1)^080h	;volatile
	line	54
	clrf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	line	58
	
l6439:	
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u9331
	goto	u9330
u9331:
	goto	l6445
u9330:
	
l6441:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u9341
	goto	u9340
u9341:
	goto	l6445
u9340:
	line	60
	
l6443:	
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	61
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u12277:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u12277
	nop
opt asmopt_pop

	line	62
	goto	l6447
	line	64
	
l6445:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	67
	
l6447:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	btfss	(ADC_Sample@adch)^080h,(4)&7
	goto	u9351
	goto	u9350
u9351:
	goto	l490
u9350:
	line	69
	
l6449:	
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l6451:	
	movlw	low(0Fh)
	andwf	(ADC_Sample@adch)^080h,f
	line	71
	goto	l6453
	line	72
	
l490:	
	line	73
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l6453:	
	clrf	(ADC_Sample@i)^080h
	line	79
	
l6459:	
	movf	(ADC_Sample@adch)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u9365:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u9365
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l6461:	
	opt asmopt_push
opt asmopt_off
	movlw	5
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u12287:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u12287
	nop2
opt asmopt_pop

	line	81
	
l6463:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l6465:	
	clrf	(ADC_Sample@j)^080h
	line	85
	goto	l494
	
l495:	
	line	87
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	decfsz	(ADC_Sample@j)^080h,f
	goto	u9371
	goto	u9370
u9371:
	goto	l494
u9370:
	line	89
	
l6467:	
	movlw	low(0)
	goto	l497
	line	90
	
l494:	
	line	85
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u9381
	goto	u9380
u9381:
	goto	l495
u9380:
	line	93
	
l6471:	
	movf	(153)^080h,w	;volatile
	movwf	(ADC_Sample@ad_temp)^080h	;volatile
	clrf	(ADC_Sample@ad_temp+1)^080h	;volatile
	swapf	(ADC_Sample@ad_temp)^080h,f	;volatile
	swapf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	
l6473:	
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	addwf	(ADC_Sample@ad_temp)^080h,f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1)^080h,f	;volatile
	line	96
	
l6475:	
	movf	((ADC_Sample@admax)^080h),w	;volatile
iorwf	((ADC_Sample@admax+1)^080h),w	;volatile
	btfss	status,2
	goto	u9391
	goto	u9390
u9391:
	goto	l6479
u9390:
	line	98
	
l6477:	
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	line	99
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	100
	goto	l500
	line	102
	
l6479:	
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	subwf	(ADC_Sample@admax+1)^080h,w	;volatile
	skipz
	goto	u9405
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	subwf	(ADC_Sample@admax)^080h,w	;volatile
u9405:
	skipnc
	goto	u9401
	goto	u9400
u9401:
	goto	l6483
u9400:
	line	103
	
l6481:	
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admax+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admax)^080h	;volatile
	goto	l500
	line	105
	
l6483:	
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	skipz
	goto	u9415
	movf	(ADC_Sample@admin)^080h,w	;volatile
	subwf	(ADC_Sample@ad_temp)^080h,w	;volatile
u9415:
	skipnc
	goto	u9411
	goto	u9410
u9411:
	goto	l500
u9410:
	line	106
	
l6485:	
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	movwf	(ADC_Sample@admin+1)^080h	;volatile
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	movwf	(ADC_Sample@admin)^080h	;volatile
	line	108
	
l500:	
	movf	(ADC_Sample@ad_temp)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@ad_temp+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ADC_Sample@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9421
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u9421:
	bcf	status, 5	;RP0=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9422
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u9422:
	bcf	status, 5	;RP0=0, select bank0
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9423
	bsf	status, 5	;RP0=1, select bank1
	addwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u9423:
	bcf	status, 5	;RP0=0, select bank0
	bsf	status, 5	;RP0=1, select bank1

	line	76
	
l6487:	
	incf	(ADC_Sample@i)^080h,f
	
l6489:	
	movlw	low(022h)
	subwf	(ADC_Sample@i)^080h,w
	skipc
	goto	u9431
	goto	u9430
u9431:
	goto	l6459
u9430:
	line	112
	
l6491:	
	movf	(ADC_Sample@admax)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@admax+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u9445
	goto	u9446
u9445:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u9446:
	bcf	status, 5	;RP0=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u9447
	goto	u9448
u9447:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u9448:
	bcf	status, 5	;RP0=0, select bank0
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u9449
	goto	u9440
u9449:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u9440:
	bcf	status, 5	;RP0=0, select bank0
	bsf	status, 5	;RP0=1, select bank1

	line	113
	movf	(ADC_Sample@admin)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+3)^080h,w	;volatile
	skipz
	goto	u9455
	bcf	status, 5	;RP0=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+2)^080h,w	;volatile
	skipz
	goto	u9455
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+1)^080h,w	;volatile
	skipz
	goto	u9455
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum)^080h,w	;volatile
u9455:
	skipc
	goto	u9451
	goto	u9450
u9451:
	goto	l504
u9450:
	line	114
	
l6493:	
	movf	(ADC_Sample@admin)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@admin+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u9465
	goto	u9466
u9465:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+1)^080h,f	;volatile
u9466:
	bcf	status, 5	;RP0=0, select bank0
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u9467
	goto	u9468
u9467:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+2)^080h,f	;volatile
u9468:
	bcf	status, 5	;RP0=0, select bank0
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u9469
	goto	u9460
u9469:
	bsf	status, 5	;RP0=1, select bank1
	subwf	(ADC_Sample@adsum+3)^080h,f	;volatile
u9460:
	bcf	status, 5	;RP0=0, select bank0
	bsf	status, 5	;RP0=1, select bank1

	goto	l6495
	line	115
	
l504:	
	line	116
	clrf	(ADC_Sample@adsum)^080h	;volatile
	clrf	(ADC_Sample@adsum+1)^080h	;volatile
	clrf	(ADC_Sample@adsum+2)^080h	;volatile
	clrf	(ADC_Sample@adsum+3)^080h	;volatile
	line	118
	
l6495:	
	movf	(ADC_Sample@adsum)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_ADC_Sample+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@adsum+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@adsum+2)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	(ADC_Sample@adsum+3)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u9475:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u9470:
	addlw	-1
	skipz
	goto	u9475
	movf	1+(??_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
l6497:	
	movlw	low(0A5h)
	line	120
	
l497:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 156 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   22[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0       8       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_CCCV_Control
;;		_Charging_Control
;;		_Led_BlinkProcess
;;		_PowerOnLedSequence
;;		_Update_LED_Slot
;;		i1_ADC_Sample
;;		i1___lldiv
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	156
global __ptext22
__ptext22:	;psect for function _Isr_Timer
psect	text22
	file	"main.c"
	line	156
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 2
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	movf	btemp+1,w
	movwf	(??_Isr_Timer+3)
	ljmp	_Isr_Timer
psect	text22
	line	159
	
i1l7893:	
	btfss	(90/8),(90)&7	;volatile
	goto	u1201_21
	goto	u1201_20
u1201_21:
	goto	i1l371
u1201_20:
	line	161
	
i1l7895:	
	bcf	(90/8),(90)&7	;volatile
	line	162
	
i1l7897:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	163
# 163 "main.c"
clrwdt ;# 
psect	text22
	line	166
	
i1l7899:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_g_pwmCounter),f	;volatile
	line	167
	
i1l7901:	
	movlw	low(020h)
	subwf	(_g_pwmCounter),w	;volatile
	skipc
	goto	u1202_21
	goto	u1202_20
u1202_21:
	goto	i1l7905
u1202_20:
	line	168
	
i1l7903:	
	clrf	(_g_pwmCounter)	;volatile
	line	171
	
i1l7905:	
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u1203_21
	goto	u1203_20
u1203_21:
	goto	i1l368
u1203_20:
	
i1l7907:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter),w	;volatile
	skipnc
	goto	u1204_21
	goto	u1204_20
u1204_21:
	goto	i1l368
u1204_20:
	line	172
	
i1l7909:	
	bsf	(55/8),(55)&7	;volatile
	goto	i1l7911
	line	173
	
i1l368:	
	line	174
	bcf	(55/8),(55)&7	;volatile
	line	177
	
i1l7911:	
	movlw	low(02h)
	subwf	(_g_powerOnPhase),w	;volatile
	skipnc
	goto	u1205_21
	goto	u1205_20
u1205_21:
	goto	i1l7983
u1205_20:
	line	179
	
i1l7913:	
	fcall	_PowerOnLedSequence
	goto	i1l371
	line	186
	
i1l373:	
	line	188
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u1206_21
	goto	u1206_20
u1206_21:
	goto	i1l371
u1206_20:
	
i1l7917:	
	btfsc	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	u1207_21
	goto	u1207_20
u1207_21:
	goto	i1l371
u1207_20:
	goto	i1l7921
	line	190
	
i1l377:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l390
	
i1l379:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l390
	
i1l380:	
	bsf	(51/8),(51)&7	;volatile
	goto	i1l390
	
i1l381:	
	bsf	(50/8),(50)&7	;volatile
	goto	i1l390
	
i1l382:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l390
	
i1l383:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l390
	
i1l384:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l390
	
i1l385:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l390
	
i1l386:	
	bsf	(48/8),(48)&7	;volatile
	goto	i1l390
	
i1l387:	
	bsf	(49/8),(49)&7	;volatile
	goto	i1l390
	
i1l388:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l390
	
i1l389:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l390
	
i1l7921:	
	movf	(_g_scanIndex),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l377
	xorlw	1^0	; case 1
	skipnz
	goto	i1l379
	xorlw	2^1	; case 2
	skipnz
	goto	i1l380
	xorlw	3^2	; case 3
	skipnz
	goto	i1l381
	xorlw	4^3	; case 4
	skipnz
	goto	i1l382
	xorlw	5^4	; case 5
	skipnz
	goto	i1l383
	xorlw	6^5	; case 6
	skipnz
	goto	i1l384
	xorlw	7^6	; case 7
	skipnz
	goto	i1l385
	xorlw	8^7	; case 8
	skipnz
	goto	i1l386
	xorlw	9^8	; case 9
	skipnz
	goto	i1l387
	xorlw	10^9	; case 10
	skipnz
	goto	i1l388
	xorlw	11^10	; case 11
	skipnz
	goto	i1l389
	goto	i1l390
	opt asmopt_pop

	
i1l390:	
	line	191
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(_g_doAdcSample/8),(_g_doAdcSample)&7	;volatile
	goto	i1l371
	line	197
	
i1l7923:	
	movf	(_g_scanIndex),w	;volatile
	fcall	_Update_LED_Slot
	line	199
	
i1l7925:	
	movlw	low(02h)
	movwf	(_g_scanPhase)	;volatile
	line	200
	goto	i1l371
	line	203
	
i1l7927:	
	movf	((_g_scanIndex)),w	;volatile
	btfss	status,2
	goto	u1208_21
	goto	u1208_20
u1208_21:
	goto	i1l7975
u1208_20:
	line	206
	
i1l7929:	
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u1209_21
	goto	u1209_20
u1209_21:
	goto	i1l7943
u1209_20:
	line	208
	
i1l7931:	
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	209
	
i1l7933:	
	clrf	(i1ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	i1_ADC_Sample
	movwf	(_test_adc)	;volatile
	line	210
	
i1l7935:	
		movlw	165
	xorwf	((_test_adc)),w	;volatile
	btfss	status,2
	goto	u1210_21
	goto	u1210_20
u1210_21:
	goto	i1l7941
u1210_20:
	line	212
	
i1l7937:	
	movf	(_adresult),w	;volatile
	movwf	(i1___lldiv@divisor)
	movf	(_adresult+1),w	;volatile
	movwf	((i1___lldiv@divisor))+1
	clrf	2+((i1___lldiv@divisor))
	clrf	3+((i1___lldiv@divisor))
	movlw	0
	movwf	(i1___lldiv@dividend+3)
	movlw	04Bh
	movwf	(i1___lldiv@dividend+2)
	movlw	0
	movwf	(i1___lldiv@dividend+1)
	movlw	0
	movwf	(i1___lldiv@dividend)

	fcall	i1___lldiv
	movf	(3+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+3)
	movf	(2+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+2)
	movf	(1+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt+1)
	movf	(0+(?i1___lldiv)),w
	movwf	(Isr_Timer@pt)

	line	213
	
i1l7939:	
	movf	(Isr_Timer@pt+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv+1)^080h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(Isr_Timer@pt),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_vcc_mv)^080h	;volatile
	line	215
	
i1l7941:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	218
	
i1l7943:	
	fcall	_Charging_Control
	line	219
	
i1l7945:	
	fcall	_CCCV_Control
	line	220
	
i1l7947:	
	fcall	_Led_BlinkProcess
	line	224
	
i1l7949:	
	movf	((_g_tempPhase)),w	;volatile
	btfss	status,2
	goto	u1211_21
	goto	u1211_20
u1211_21:
	goto	i1l7961
u1211_20:
	line	226
	
i1l7951:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_tempReadRoundCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1)^080h,f	;volatile
	line	227
	
i1l7953:	
	movlw	0
	subwf	(_g_tempReadRoundCnt+1)^080h,w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt)^080h,w	;volatile
	skipc
	goto	u1212_21
	goto	u1212_20
u1212_21:
	goto	i1l7969
u1212_20:
	line	229
	
i1l7955:	
	clrf	(_g_tempReadRoundCnt)^080h	;volatile
	clrf	(_g_tempReadRoundCnt+1)^080h	;volatile
	line	230
	
i1l7957:	
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_g_tempPhase)	;volatile
	line	231
	
i1l7959:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	goto	i1l7969
	line	236
	
i1l7961:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_tempSettleCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1)^080h,f	;volatile
	line	237
	
i1l7963:	
	movlw	0
	subwf	(_g_tempSettleCnt+1)^080h,w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt)^080h,w	;volatile
	skipc
	goto	u1213_21
	goto	u1213_20
u1213_21:
	goto	i1l7969
u1213_20:
	line	239
	
i1l7965:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	240
	
i1l7967:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	line	241
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_tempPhase)	;volatile
	line	247
	
i1l7969:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_printTick)^080h,f	;volatile
	skipnz
	incf	(_g_printTick+1)^080h,f	;volatile
	movlw	0
	subwf	((_g_printTick+1)^080h),w	;volatile
	movlw	064h
	skipnz
	subwf	((_g_printTick)^080h),w	;volatile
	skipc
	goto	u1214_21
	goto	u1214_20
u1214_21:
	goto	i1l7975
u1214_20:
	line	249
	
i1l7971:	
	clrf	(_g_printTick)^080h	;volatile
	clrf	(_g_printTick+1)^080h	;volatile
	line	250
	
i1l7973:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	255
	
i1l7975:	
	movlw	low(0Ch)
	bcf	status, 5	;RP0=0, select bank0
	incf	(_g_scanIndex),f	;volatile
	subwf	((_g_scanIndex)),w	;volatile
	skipc
	goto	u1215_21
	goto	u1215_20
u1215_21:
	goto	i1l402
u1215_20:
	line	256
	
i1l7977:	
	clrf	(_g_scanIndex)	;volatile
	
i1l402:	
	line	257
	clrf	(_g_scanPhase)	;volatile
	line	258
	goto	i1l371
	line	184
	
i1l7983:	
	movf	(_g_scanPhase),w	;volatile
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 2
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           17     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l373
	xorlw	1^0	; case 1
	skipnz
	goto	i1l7923
	xorlw	2^1	; case 2
	skipnz
	goto	i1l7927
	goto	i1l402
	opt asmopt_pop

	line	265
	
i1l371:	
	movf	(??_Isr_Timer+3),w
	movwf	btemp+1
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^00h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	i1___lldiv

;; *************** function i1___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    0[COMMON] unsigned long 
;;  dividend        4    4[COMMON] unsigned long 
;; Auto vars:     Size  Location     Type
;;  __lldiv         4    9[COMMON] unsigned long 
;;  __lldiv         1    8[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    0[COMMON] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         8       0       0       0       0
;;      Locals:         5       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:        13       0       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext23
__ptext23:	;psect for function i1___lldiv
psect	text23
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_ofi1___lldiv
	__size_ofi1___lldiv	equ	__end_ofi1___lldiv-i1___lldiv
	
i1___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in i1___lldiv: [wreg+status,2+status,0]
	line	14
	
i1l7867:	
	clrf	(i1___lldiv@quotient)
	clrf	(i1___lldiv@quotient+1)
	clrf	(i1___lldiv@quotient+2)
	clrf	(i1___lldiv@quotient+3)
	line	15
	
i1l7869:	
	movf	(i1___lldiv@divisor+3),w
	iorwf	(i1___lldiv@divisor+2),w
	iorwf	(i1___lldiv@divisor+1),w
	iorwf	(i1___lldiv@divisor),w
	skipnz
	goto	u1197_21
	goto	u1197_20
u1197_21:
	goto	i1l7889
u1197_20:
	line	16
	
i1l7871:	
	clrf	(i1___lldiv@counter)
	incf	(i1___lldiv@counter),f
	line	17
	goto	i1l7875
	line	18
	
i1l7873:	
	clrc
	rlf	(i1___lldiv@divisor),f
	rlf	(i1___lldiv@divisor+1),f
	rlf	(i1___lldiv@divisor+2),f
	rlf	(i1___lldiv@divisor+3),f
	line	19
	incf	(i1___lldiv@counter),f
	line	17
	
i1l7875:	
	btfss	(i1___lldiv@divisor+3),(31)&7
	goto	u1198_21
	goto	u1198_20
u1198_21:
	goto	i1l7873
u1198_20:
	line	22
	
i1l7877:	
	clrc
	rlf	(i1___lldiv@quotient),f
	rlf	(i1___lldiv@quotient+1),f
	rlf	(i1___lldiv@quotient+2),f
	rlf	(i1___lldiv@quotient+3),f
	line	23
	
i1l7879:	
	movf	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),w
	skipz
	goto	u1199_25
	movf	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),w
	skipz
	goto	u1199_25
	movf	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),w
	skipz
	goto	u1199_25
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),w
u1199_25:
	skipc
	goto	u1199_21
	goto	u1199_20
u1199_21:
	goto	i1l7885
u1199_20:
	line	24
	
i1l7881:	
	movf	(i1___lldiv@divisor),w
	subwf	(i1___lldiv@dividend),f
	movf	(i1___lldiv@divisor+1),w
	skipc
	incfsz	(i1___lldiv@divisor+1),w
	subwf	(i1___lldiv@dividend+1),f
	movf	(i1___lldiv@divisor+2),w
	skipc
	incfsz	(i1___lldiv@divisor+2),w
	subwf	(i1___lldiv@dividend+2),f
	movf	(i1___lldiv@divisor+3),w
	skipc
	incfsz	(i1___lldiv@divisor+3),w
	subwf	(i1___lldiv@dividend+3),f
	line	25
	
i1l7883:	
	bsf	(i1___lldiv@quotient)+(0/8),(0)&7
	line	27
	
i1l7885:	
	clrc
	rrf	(i1___lldiv@divisor+3),f
	rrf	(i1___lldiv@divisor+2),f
	rrf	(i1___lldiv@divisor+1),f
	rrf	(i1___lldiv@divisor),f
	line	28
	
i1l7887:	
	decfsz	(i1___lldiv@counter),f
	goto	u1200_21
	goto	u1200_20
u1200_21:
	goto	i1l7877
u1200_20:
	line	30
	
i1l7889:	
	movf	(i1___lldiv@quotient+3),w
	movwf	(?i1___lldiv+3)
	movf	(i1___lldiv@quotient+2),w
	movwf	(?i1___lldiv+2)
	movf	(i1___lldiv@quotient+1),w
	movwf	(?i1___lldiv+1)
	movf	(i1___lldiv@quotient),w
	movwf	(?i1___lldiv)

	line	31
	
i1l1153:	
	return
	opt stack 0
GLOBAL	__end_ofi1___lldiv
	__end_ofi1___lldiv:
	signat	i1___lldiv,92
	global	i1_ADC_Sample

;; *************** function i1_ADC_Sample *****************
;; Defined at:
;;		line 49 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    0[BANK0 ] unsigned char 
;;  ADC_Sample      4    3[BANK0 ] volatile unsigned long 
;;  ADC_Sample      2   11[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    9[BANK0 ] volatile unsigned int 
;;  ADC_Sample      2    7[BANK0 ] volatile unsigned int 
;;  ADC_Sample      1    2[BANK0 ] unsigned char 
;;  ADC_Sample      1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          4       0       0       0       0
;;      Totals:         5      13       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	49
global __ptext24
__ptext24:	;psect for function i1_ADC_Sample
psect	text24
	file	"adc_drv.c"
	line	49
	global	__size_ofi1_ADC_Sample
	__size_ofi1_ADC_Sample	equ	__end_ofi1_ADC_Sample-i1_ADC_Sample
	
i1_ADC_Sample:	
;incstack = 0
	opt	stack 3
; Regs used in i1_ADC_Sample: [wreg+status,2+status,0]
	movwf	(i1ADC_Sample@adch)
	line	51
	
i1l6193:	
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	52
	
i1l6195:	
	clrf	(i1ADC_Sample@admin)	;volatile
	clrf	(i1ADC_Sample@admin+1)	;volatile
	line	53
	clrf	(i1ADC_Sample@admax)	;volatile
	clrf	(i1ADC_Sample@admax+1)	;volatile
	line	54
	clrf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	line	58
	
i1l6197:	
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u894_21
	goto	u894_20
u894_21:
	goto	i1l6203
u894_20:
	
i1l6199:	
	btfss	(i1ADC_Sample@adldo),(2)&7
	goto	u895_21
	goto	u895_20
u895_21:
	goto	i1l6203
u895_20:
	line	60
	
i1l6201:	
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	61
	opt asmopt_push
opt asmopt_off
	movlw	133
movwf	((??i1_ADC_Sample+0)+0),f
	u1229_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u1229_27
opt asmopt_pop

	line	62
	goto	i1l6205
	line	64
	
i1l6203:	
	movf	(i1ADC_Sample@adldo),w
	movwf	(150)^080h	;volatile
	line	67
	
i1l6205:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(i1ADC_Sample@adch),(4)&7
	goto	u896_21
	goto	u896_20
u896_21:
	goto	i1l490
u896_20:
	line	69
	
i1l6207:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
i1l6209:	
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(i1ADC_Sample@adch),f
	line	71
	goto	i1l6211
	line	72
	
i1l490:	
	line	73
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
i1l6211:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@i)
	
i1l6213:	
	movlw	low(022h)
	subwf	(i1ADC_Sample@i),w
	skipc
	goto	u897_21
	goto	u897_20
u897_21:
	goto	i1l6217
u897_20:
	goto	i1l6249
	line	79
	
i1l6217:	
	movf	(i1ADC_Sample@adch),w
	movwf	(??i1_ADC_Sample+0)+0
	movlw	(02h)-1
u898_25:
	clrc
	rlf	(??i1_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u898_25
	clrc
	rlf	(??i1_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
i1l6219:	
	opt asmopt_push
opt asmopt_off
	movlw	6
movwf	((??i1_ADC_Sample+0)+0),f
	u1230_27:
decfsz	(??i1_ADC_Sample+0)+0,f
	goto	u1230_27
	nop
opt asmopt_pop

	line	81
	
i1l6221:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
i1l6223:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(i1ADC_Sample@j)
	line	85
	goto	i1l494
	
i1l495:	
	line	87
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(i1ADC_Sample@j),f
	goto	u899_21
	goto	u899_20
u899_21:
	goto	i1l494
u899_20:
	line	89
	
i1l6225:	
	movlw	low(0)
	goto	i1l497
	line	90
	
i1l494:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u900_21
	goto	u900_20
u900_21:
	goto	i1l495
u900_20:
	line	93
	
i1l6229:	
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(i1ADC_Sample@ad_temp)	;volatile
	clrf	(i1ADC_Sample@ad_temp+1)	;volatile
	swapf	(i1ADC_Sample@ad_temp),f	;volatile
	swapf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(i1ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(i1ADC_Sample@ad_temp),f	;volatile
	
i1l6231:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(i1ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(i1ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
i1l6233:	
	movf	((i1ADC_Sample@admax)),w	;volatile
iorwf	((i1ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u901_21
	goto	u901_20
u901_21:
	goto	i1l6237
u901_20:
	line	98
	
i1l6235:	
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	line	99
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	100
	goto	i1l500
	line	102
	
i1l6237:	
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	subwf	(i1ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u902_25
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	subwf	(i1ADC_Sample@admax),w	;volatile
u902_25:
	skipnc
	goto	u902_21
	goto	u902_20
u902_21:
	goto	i1l6241
u902_20:
	line	103
	
i1l6239:	
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admax+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admax)	;volatile
	goto	i1l500
	line	105
	
i1l6241:	
	movf	(i1ADC_Sample@admin+1),w	;volatile
	subwf	(i1ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u903_25
	movf	(i1ADC_Sample@admin),w	;volatile
	subwf	(i1ADC_Sample@ad_temp),w	;volatile
u903_25:
	skipnc
	goto	u903_21
	goto	u903_20
u903_21:
	goto	i1l500
u903_20:
	line	106
	
i1l6243:	
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	(i1ADC_Sample@admin+1)	;volatile
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	(i1ADC_Sample@admin)	;volatile
	line	108
	
i1l500:	
	movf	(i1ADC_Sample@ad_temp),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	addwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u904_21
	addwf	(i1ADC_Sample@adsum+1),f	;volatile
u904_21:
	movf	2+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u904_22
	addwf	(i1ADC_Sample@adsum+2),f	;volatile
u904_22:
	movf	3+(??i1_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u904_23
	addwf	(i1ADC_Sample@adsum+3),f	;volatile
u904_23:

	line	76
	
i1l6245:	
	incf	(i1ADC_Sample@i),f
	goto	i1l6213
	line	112
	
i1l6249:	
	movf	(i1ADC_Sample@admax),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admax+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u905_25
	goto	u905_26
u905_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u905_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u905_27
	goto	u905_28
u905_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u905_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u905_29
	goto	u905_20
u905_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u905_20:

	line	113
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	3+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u906_25
	movf	2+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u906_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u906_25
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),w	;volatile
u906_25:
	skipc
	goto	u906_21
	goto	u906_20
u906_21:
	goto	i1l504
u906_20:
	line	114
	
i1l6251:	
	movf	(i1ADC_Sample@admin),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0)
	movf	(i1ADC_Sample@admin+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	clrf	((??i1_ADC_Sample+0)+0+2)
	clrf	((??i1_ADC_Sample+0)+0+3)
	movf	0+(??i1_ADC_Sample+0)+0,w
	subwf	(i1ADC_Sample@adsum),f	;volatile
	movf	1+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??i1_ADC_Sample+0)+0,w
	goto	u907_25
	goto	u907_26
u907_25:
	subwf	(i1ADC_Sample@adsum+1),f	;volatile
u907_26:
	movf	2+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??i1_ADC_Sample+0)+0,w
	goto	u907_27
	goto	u907_28
u907_27:
	subwf	(i1ADC_Sample@adsum+2),f	;volatile
u907_28:
	movf	3+(??i1_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??i1_ADC_Sample+0)+0,w
	goto	u907_29
	goto	u907_20
u907_29:
	subwf	(i1ADC_Sample@adsum+3),f	;volatile
u907_20:

	goto	i1l6253
	line	115
	
i1l504:	
	line	116
	clrf	(i1ADC_Sample@adsum)	;volatile
	clrf	(i1ADC_Sample@adsum+1)	;volatile
	clrf	(i1ADC_Sample@adsum+2)	;volatile
	clrf	(i1ADC_Sample@adsum+3)	;volatile
	line	118
	
i1l6253:	
	movf	(i1ADC_Sample@adsum),w	;volatile
	movwf	(??i1_ADC_Sample+0)+0
	movf	(i1ADC_Sample@adsum+1),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+1)
	movf	(i1ADC_Sample@adsum+2),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+2)
	movf	(i1ADC_Sample@adsum+3),w	;volatile
	movwf	((??i1_ADC_Sample+0)+0+3)
	movlw	05h
u908_25:
	clrc
	rrf	(??i1_ADC_Sample+0)+3,f
	rrf	(??i1_ADC_Sample+0)+2,f
	rrf	(??i1_ADC_Sample+0)+1,f
	rrf	(??i1_ADC_Sample+0)+0,f
u908_20:
	addlw	-1
	skipz
	goto	u908_25
	movf	1+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult+1)	;volatile
	movf	0+(??i1_ADC_Sample+0)+0,w
	movwf	(_adresult)	;volatile
	line	119
	
i1l6255:	
	movlw	low(0A5h)
	line	120
	
i1l497:	
	return
	opt stack 0
GLOBAL	__end_ofi1_ADC_Sample
	__end_ofi1_ADC_Sample:
	signat	i1_ADC_Sample,89
	global	_Update_LED_Slot

;; *************** function _Update_LED_Slot *****************
;; Defined at:
;;		line 31 in file "led.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    0[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	file	"led.c"
	line	31
global __ptext25
__ptext25:	;psect for function _Update_LED_Slot
psect	text25
	file	"led.c"
	line	31
	global	__size_of_Update_LED_Slot
	__size_of_Update_LED_Slot	equ	__end_of_Update_LED_Slot-_Update_LED_Slot
	
_Update_LED_Slot:	
;incstack = 0
	opt	stack 3
; Regs used in _Update_LED_Slot: [wreg]
	line	36
	
i1l851:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Slot
	__end_of_Update_LED_Slot:
	signat	_Update_LED_Slot,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 63 in file "led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=0
	line	63
global __ptext26
__ptext26:	;psect for function _PowerOnLedSequence
psect	text26
	file	"led.c"
	line	63
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 3
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	65
	
i1l5119:	
	incf	(_g_powerOnTimer),f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1),f	;volatile
	line	67
	
i1l5121:	
	movf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u682_21
	goto	u682_20
u682_21:
	goto	i1l5129
u682_20:
	line	70
	
i1l5123:	
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u683_21
	goto	u683_20
u683_21:
	goto	i1l863
u683_20:
	line	72
	
i1l5125:	
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	73
	
i1l5127:	
	movlw	low(01h)
	movwf	(_g_powerOnPhase)	;volatile
	goto	i1l863
	line	76
	
i1l5129:	
		decf	((_g_powerOnPhase)),w	;volatile
	btfss	status,2
	goto	u684_21
	goto	u684_20
u684_21:
	goto	i1l863
u684_20:
	line	79
	
i1l5131:	
	movlw	0
	subwf	(_g_powerOnTimer+1),w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer),w	;volatile
	skipc
	goto	u685_21
	goto	u685_20
u685_21:
	goto	i1l863
u685_20:
	line	81
	
i1l5133:	
	clrf	(_g_powerOnTimer)	;volatile
	clrf	(_g_powerOnTimer+1)	;volatile
	line	82
	
i1l5135:	
	movlw	low(02h)
	movwf	(_g_powerOnPhase)	;volatile
	line	86
	
i1l863:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
	global	_Led_BlinkProcess

;; *************** function _Led_BlinkProcess *****************
;; Defined at:
;;		line 48 in file "led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=0
	line	48
global __ptext27
__ptext27:	;psect for function _Led_BlinkProcess
psect	text27
	file	"led.c"
	line	48
	global	__size_of_Led_BlinkProcess
	__size_of_Led_BlinkProcess	equ	__end_of_Led_BlinkProcess-_Led_BlinkProcess
	
_Led_BlinkProcess:	
;incstack = 0
	opt	stack 3
; Regs used in _Led_BlinkProcess: [wreg+status,2+status,0]
	line	50
	
i1l5305:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(_g_blinkTick),f
	line	51
	
i1l5307:	
	movlw	low(064h)
	subwf	(_g_blinkTick),w
	skipc
	goto	u723_21
	goto	u723_20
u723_21:
	goto	i1l855
u723_20:
	line	52
	
i1l5309:	
	clrf	(_g_blinkTick)
	line	53
	
i1l855:	
	return
	opt stack 0
GLOBAL	__end_of_Led_BlinkProcess
	__end_of_Led_BlinkProcess:
	signat	_Led_BlinkProcess,89
	global	_Charging_Control

;; *************** function _Charging_Control *****************
;; Defined at:
;;		line 886 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    5[COMMON] unsigned char 
;;  i               1    6[COMMON] unsigned char 
;;  chargeB7_12     1    4[COMMON] unsigned char 
;;  chargeB1_6      1    3[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 100/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	886
global __ptext28
__ptext28:	;psect for function _Charging_Control
psect	text28
	file	"charge_mgr.c"
	line	886
	global	__size_of_Charging_Control
	__size_of_Charging_Control	equ	__end_of_Charging_Control-_Charging_Control
	
_Charging_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _Charging_Control: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	889
	
i1l6817:	
	clrf	(Charging_Control@chargeB1_6)
	line	890
	clrf	(Charging_Control@chargeB7_12)
	line	893
	
i1l6819:	
	movf	((_g_tempProtect)),w
	btfsc	status,2
	goto	u990_21
	goto	u990_20
u990_21:
	goto	i1l6825
u990_20:
	line	895
	
i1l750:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	bsf	(1073/8)^080h,(1073)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	bsf	(50/8),(50)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	bsf	(1074/8)^080h,(1074)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	bsf	(49/8),(49)&7	;volatile
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	
i1l751:	
	line	896
	bcf	(2099/8)^0100h,(2099)&7	;volatile
	line	897
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	898
	
i1l6821:	
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_pwmDuty)	;volatile
	goto	i1l752
	line	905
	
i1l6825:	
	movf	((_g_vccProtect)),w
	btfsc	status,2
	goto	u991_21
	goto	u991_20
u991_21:
	goto	i1l6835
u991_20:
	line	907
	
i1l6827:	
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u992_21
	goto	u992_20
u992_21:
	goto	i1l6833
u992_20:
	goto	i1l750
	line	915
	
i1l6833:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	line	916
	goto	i1l6843
	line	919
	
i1l6835:	
	movlw	011h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_vcc_mv+1)^080h,w	;volatile
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv)^080h,w	;volatile
	skipnc
	goto	u993_21
	goto	u993_20
u993_21:
	goto	i1l6843
u993_20:
	line	921
	
i1l6837:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_g_vccProtect)
	incf	(_g_vccProtect),f
	goto	i1l750
	line	931
	
i1l6843:	
	clrf	(Charging_Control@i)
	line	933
	
i1l6849:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(Charging_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Charging_Control@s)
	line	938
	
i1l6851:	
		movlw	2
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u994_21
	goto	u994_20
u994_21:
	goto	i1l6863
u994_20:
	
i1l6853:	
		movlw	3
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u995_21
	goto	u995_20
u995_21:
	goto	i1l6863
u995_20:
	
i1l6855:	
		movlw	4
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u996_21
	goto	u996_20
u996_21:
	goto	i1l6863
u996_20:
	
i1l6857:	
		movlw	5
	xorwf	((Charging_Control@s)),w
	btfsc	status,2
	goto	u997_21
	goto	u997_20
u997_21:
	goto	i1l6863
u997_20:
	
i1l6859:	
		movlw	8
	xorwf	((Charging_Control@s)),w
	btfss	status,2
	goto	u998_21
	goto	u998_20
u998_21:
	goto	i1l6869
u998_20:
	goto	i1l6863
	line	940
	
i1l768:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l6865
	
i1l770:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l6865
	
i1l771:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l6865
	
i1l772:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l6865
	
i1l773:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l6865
	
i1l774:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l6865
	
i1l775:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l6865
	
i1l776:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l6865
	
i1l777:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l6865
	
i1l778:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l6865
	
i1l779:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l6865
	
i1l780:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l6865
	
i1l6863:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l768
	xorlw	1^0	; case 1
	skipnz
	goto	i1l770
	xorlw	2^1	; case 2
	skipnz
	goto	i1l771
	xorlw	3^2	; case 3
	skipnz
	goto	i1l772
	xorlw	4^3	; case 4
	skipnz
	goto	i1l773
	xorlw	5^4	; case 5
	skipnz
	goto	i1l774
	xorlw	6^5	; case 6
	skipnz
	goto	i1l775
	xorlw	7^6	; case 7
	skipnz
	goto	i1l776
	xorlw	8^7	; case 8
	skipnz
	goto	i1l777
	xorlw	9^8	; case 9
	skipnz
	goto	i1l778
	xorlw	10^9	; case 10
	skipnz
	goto	i1l779
	xorlw	11^10	; case 11
	skipnz
	goto	i1l780
	goto	i1l6865
	opt asmopt_pop

	line	943
	
i1l6865:	
	movlw	low(06h)
	subwf	(Charging_Control@i),w
	skipnc
	goto	u999_21
	goto	u999_20
u999_21:
	goto	i1l782
u999_20:
	line	944
	
i1l6867:	
	clrf	(Charging_Control@chargeB1_6)
	incf	(Charging_Control@chargeB1_6),f
	goto	i1l6879
	line	945
	
i1l782:	
	line	946
	clrf	(Charging_Control@chargeB7_12)
	incf	(Charging_Control@chargeB7_12),f
	goto	i1l6879
	line	950
	
i1l6869:	
		decf	((Charging_Control@s)),w
	btfss	status,2
	goto	u1000_21
	goto	u1000_20
u1000_21:
	goto	i1l6877
u1000_20:
	goto	i1l6873
	line	952
	
i1l788:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l6879
	
i1l790:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l6879
	
i1l791:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(51/8),(51)&7	;volatile
	goto	i1l6879
	
i1l792:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(50/8),(50)&7	;volatile
	goto	i1l6879
	
i1l793:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l6879
	
i1l794:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l6879
	
i1l795:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l6879
	
i1l796:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l6879
	
i1l797:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(48/8),(48)&7	;volatile
	goto	i1l6879
	
i1l798:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bcf	(49/8),(49)&7	;volatile
	goto	i1l6879
	
i1l799:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l6879
	
i1l800:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l6879
	
i1l6873:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l788
	xorlw	1^0	; case 1
	skipnz
	goto	i1l790
	xorlw	2^1	; case 2
	skipnz
	goto	i1l791
	xorlw	3^2	; case 3
	skipnz
	goto	i1l792
	xorlw	4^3	; case 4
	skipnz
	goto	i1l793
	xorlw	5^4	; case 5
	skipnz
	goto	i1l794
	xorlw	6^5	; case 6
	skipnz
	goto	i1l795
	xorlw	7^6	; case 7
	skipnz
	goto	i1l796
	xorlw	8^7	; case 8
	skipnz
	goto	i1l797
	xorlw	9^8	; case 9
	skipnz
	goto	i1l798
	xorlw	10^9	; case 10
	skipnz
	goto	i1l799
	xorlw	11^10	; case 11
	skipnz
	goto	i1l800
	goto	i1l6879
	opt asmopt_pop

	line	956
	
i1l805:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	i1l6879
	
i1l807:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	i1l6879
	
i1l808:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(51/8),(51)&7	;volatile
	goto	i1l6879
	
i1l809:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(50/8),(50)&7	;volatile
	goto	i1l6879
	
i1l810:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	i1l6879
	
i1l811:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	i1l6879
	
i1l812:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	i1l6879
	
i1l813:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l6879
	
i1l814:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(48/8),(48)&7	;volatile
	goto	i1l6879
	
i1l815:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(49/8),(49)&7	;volatile
	goto	i1l6879
	
i1l816:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l6879
	
i1l817:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	i1l6879
	
i1l6877:	
	movf	(Charging_Control@i),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l805
	xorlw	1^0	; case 1
	skipnz
	goto	i1l807
	xorlw	2^1	; case 2
	skipnz
	goto	i1l808
	xorlw	3^2	; case 3
	skipnz
	goto	i1l809
	xorlw	4^3	; case 4
	skipnz
	goto	i1l810
	xorlw	5^4	; case 5
	skipnz
	goto	i1l811
	xorlw	6^5	; case 6
	skipnz
	goto	i1l812
	xorlw	7^6	; case 7
	skipnz
	goto	i1l813
	xorlw	8^7	; case 8
	skipnz
	goto	i1l814
	xorlw	9^8	; case 9
	skipnz
	goto	i1l815
	xorlw	10^9	; case 10
	skipnz
	goto	i1l816
	xorlw	11^10	; case 11
	skipnz
	goto	i1l817
	goto	i1l6879
	opt asmopt_pop

	line	931
	
i1l6879:	
	incf	(Charging_Control@i),f
	
i1l6881:	
	movlw	low(0Ch)
	subwf	(Charging_Control@i),w
	skipc
	goto	u1001_21
	goto	u1001_20
u1001_21:
	goto	i1l6849
u1001_20:
	
i1l762:	
	line	961
	btfsc	(Charging_Control@chargeB1_6),0
	goto	u1002_21
	goto	u1002_20
	
u1002_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2099/8)^0100h,(2099)&7	;volatile
	goto	u1003_24
u1002_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2099/8)^0100h,(2099)&7	;volatile
u1003_24:
	line	962
	btfsc	(Charging_Control@chargeB7_12),0
	goto	u1004_21
	goto	u1004_20
	
u1004_21:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	u1005_24
u1004_20:
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2101/8)^0100h,(2101)&7	;volatile
u1005_24:
	line	965
	
i1l752:	
	return
	opt stack 0
GLOBAL	__end_of_Charging_Control
	__end_of_Charging_Control:
	signat	_Charging_Control,89
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 983 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2    6[BANK0 ] unsigned int 
;;  s               1   17[BANK0 ] unsigned char 
;;  duty            2   14[BANK0 ] int 
;;  error           2   10[BANK0 ] int 
;;  adjust          2    0[BANK0 ] int 
;;  duty_initial    1   13[BANK0 ] unsigned char 
;;  duty_target     1   12[BANK0 ] unsigned char 
;;  maxV            2    8[BANK0 ] unsigned int 
;;  i               1   16[BANK0 ] unsigned char 
;;  preCount        1    5[BANK0 ] unsigned char 
;;  ccCount         1    4[BANK0 ] unsigned char 
;;  cvCount         1    3[BANK0 ] unsigned char 
;;  hasCharging     1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 100/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          2       0       0       0       0
;;      Totals:         2      18       0       0       0
;;Total ram usage:       20 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		___awdiv
;;		i1___bmul
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=0
	line	983
global __ptext29
__ptext29:	;psect for function _CCCV_Control
psect	text29
	file	"charge_mgr.c"
	line	983
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 2
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	986
	
i1l6883:	
	bcf	status, 6	;RP1=0, select bank0
	clrf	(CCCV_Control@hasCharging)
	line	987
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	988
	clrf	(CCCV_Control@cvCount)
	line	989
	clrf	(CCCV_Control@ccCount)
	line	990
	clrf	(CCCV_Control@preCount)
	line	993
	clrf	(CCCV_Control@i)
	line	995
	
i1l6889:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@s)
	line	999
	
i1l6891:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1006_21
	goto	u1006_20
u1006_21:
	goto	i1l825
u1006_20:
	
i1l6893:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1007_21
	goto	u1007_20
u1007_21:
	goto	i1l825
u1007_20:
	
i1l6895:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1008_21
	goto	u1008_20
u1008_21:
	goto	i1l825
u1008_20:
	
i1l6897:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1009_21
	goto	u1009_20
u1009_21:
	goto	i1l825
u1009_20:
	
i1l6899:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1010_21
	goto	u1010_20
u1010_21:
	goto	i1l823
u1010_20:
	
i1l825:	
	line	1001
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	1003
	
i1l6901:	
	movlw	low(06h)
	movwf	(i1___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	i1___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	1004
	
i1l6903:	
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u1011_25
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u1011_25:
	skipnc
	goto	u1011_21
	goto	u1011_20
u1011_21:
	goto	i1l6907
u1011_20:
	
i1l6905:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	1006
	
i1l6907:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1012_21
	goto	u1012_20
u1012_21:
	goto	i1l6911
u1012_20:
	line	1007
	
i1l6909:	
	incf	(CCCV_Control@cvCount),f
	line	1008
	
i1l6911:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1013_21
	goto	u1013_20
u1013_21:
	goto	i1l6915
u1013_20:
	line	1009
	
i1l6913:	
	incf	(CCCV_Control@ccCount),f
	line	1010
	
i1l6915:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u1014_21
	goto	u1014_20
u1014_21:
	goto	i1l6919
u1014_20:
	
i1l6917:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u1015_21
	goto	u1015_20
u1015_21:
	goto	i1l823
u1015_20:
	line	1011
	
i1l6919:	
	incf	(CCCV_Control@preCount),f
	line	1012
	
i1l823:	
	line	993
	incf	(CCCV_Control@i),f
	
i1l6921:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u1016_21
	goto	u1016_20
u1016_21:
	goto	i1l6889
u1016_20:
	line	1016
	
i1l6923:	
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u1017_21
	goto	u1017_20
u1017_21:
	goto	i1l6929
u1017_20:
	line	1018
	
i1l6925:	
	clrf	(_g_pwmDuty)	;volatile
	line	1019
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	i1l833
	line	1027
	
i1l6929:	
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u1018_21
	goto	u1018_20
u1018_21:
	goto	i1l6959
u1018_20:
	line	1031
	
i1l6931:	
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u1019_21
	goto	u1019_20
u1019_21:
	goto	i1l6935
u1019_20:
	line	1034
	
i1l6933:	
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	1035
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	1036
	goto	i1l6943
	line	1037
	
i1l6935:	
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u1020_21
	goto	u1020_20
u1020_21:
	goto	i1l6939
u1020_20:
	line	1040
	
i1l6937:	
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	1041
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	1042
	goto	i1l6943
	line	1047
	
i1l6939:	
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l833
	line	1051
	
i1l6943:	
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u1021_21
	goto	u1021_20
u1021_21:
	goto	i1l6951
u1021_20:
	line	1054
	
i1l6945:	
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	1055
	
i1l6947:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u1022_21
	goto	u1022_20
u1022_21:
	goto	i1l833
u1022_20:
	line	1056
	
i1l6949:	
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	i1l833
	line	1058
	
i1l6951:	
	line	1061
	
i1l6953:	
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	1062
	goto	i1l833
	line	1077
	
i1l6959:	
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	1080
	movf	(CCCV_Control@error),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral)^080h,f
	skipnc
	incf	(_g_cvIntegral+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(CCCV_Control@error+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral+1)^080h,f
	line	1081
	
i1l6961:	
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u1023_25
	movlw	0C9h
	subwf	(_g_cvIntegral)^080h,w
u1023_25:

	skipc
	goto	u1023_21
	goto	u1023_20
u1023_21:
	goto	i1l6965
u1023_20:
	line	1082
	
i1l6963:	
	movlw	0C8h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	i1l6969
	line	1083
	
i1l6965:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u1024_25
	movlw	038h
	subwf	(_g_cvIntegral)^080h,w
u1024_25:

	skipnc
	goto	u1024_21
	goto	u1024_20
u1024_21:
	goto	i1l6969
u1024_20:
	line	1084
	
i1l6967:	
	movlw	038h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	movlw	0FFh
	movwf	((_g_cvIntegral)^080h)+1
	line	1087
	
i1l6969:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_cvIntegral)^080h,w
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	movf	(_g_cvIntegral+1)^080h,w
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	1088
	
i1l6971:	
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
i1l6973:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	1091
	
i1l6975:	
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u1025_25
	movlw	021h
	subwf	(CCCV_Control@duty),w
u1025_25:

	skipc
	goto	u1025_21
	goto	u1025_20
u1025_21:
	goto	i1l6979
u1025_20:
	
i1l6977:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1092
	
i1l6979:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u1026_21
	goto	u1026_20
u1026_21:
	goto	i1l6983
u1026_20:
	
i1l6981:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1094
	
i1l6983:	
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	1096
	
i1l833:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	i1___bmul

;; *************** function i1___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[COMMON] unsigned char 
;;  __bmul          1    2[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         1       0       0       0       0
;;      Locals:         2       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Charging_Control
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text30,local,class=CODE,delta=2,merge=1,group=0
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext30
__ptext30:	;psect for function i1___bmul
psect	text30
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_ofi1___bmul
	__size_ofi1___bmul	equ	__end_ofi1___bmul-i1___bmul
	
i1___bmul:	
;incstack = 0
	opt	stack 2
; Regs used in i1___bmul: [wreg+status,2+status,0]
	movwf	(i1___bmul@multiplier)
	line	6
	
i1l3291:	
	clrf	(i1___bmul@product)
	line	43
	
i1l3293:	
	btfss	(i1___bmul@multiplier),(0)&7
	goto	u363_21
	goto	u363_20
u363_21:
	goto	i1l3297
u363_20:
	line	44
	
i1l3295:	
	movf	(i1___bmul@multiplicand),w
	addwf	(i1___bmul@product),f
	line	45
	
i1l3297:	
	clrc
	rlf	(i1___bmul@multiplicand),f
	line	46
	
i1l3299:	
	clrc
	rrf	(i1___bmul@multiplier),f
	line	47
	movf	((i1___bmul@multiplier)),w
	btfss	status,2
	goto	u364_21
	goto	u364_20
u364_21:
	goto	i1l3293
u364_20:
	line	50
	
i1l3301:	
	movf	(i1___bmul@product),w
	line	51
	
i1l887:	
	return
	opt stack 0
GLOBAL	__end_ofi1___bmul
	__end_ofi1___bmul:
	signat	i1___bmul,89
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[COMMON] int 
;;  dividend        2    2[COMMON] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[COMMON] int 
;;  sign            1    5[COMMON] unsigned char 
;;  counter         1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         4       0       0       0       0
;;      Locals:         4       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         8       0       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text31,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext31
__ptext31:	;psect for function ___awdiv
psect	text31
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
i1l5003:	
	clrf	(___awdiv@sign)
	line	15
	
i1l5005:	
	btfss	(___awdiv@divisor+1),7
	goto	u674_21
	goto	u674_20
u674_21:
	goto	i1l5011
u674_20:
	line	16
	
i1l5007:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
i1l5009:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
i1l5011:	
	btfss	(___awdiv@dividend+1),7
	goto	u675_21
	goto	u675_20
u675_21:
	goto	i1l5017
u675_20:
	line	20
	
i1l5013:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
i1l5015:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
i1l5017:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
i1l5019:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u676_21
	goto	u676_20
u676_21:
	goto	i1l5039
u676_20:
	line	25
	
i1l5021:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	i1l5025
	line	27
	
i1l5023:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
i1l5025:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u677_21
	goto	u677_20
u677_21:
	goto	i1l5023
u677_20:
	line	31
	
i1l5027:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
i1l5029:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u678_25
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u678_25:
	skipc
	goto	u678_21
	goto	u678_20
u678_21:
	goto	i1l5035
u678_20:
	line	33
	
i1l5031:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
i1l5033:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
i1l5035:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
i1l5037:	
	decfsz	(___awdiv@counter),f
	goto	u679_21
	goto	u679_20
u679_21:
	goto	i1l5027
u679_20:
	line	39
	
i1l5039:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u680_21
	goto	u680_20
u680_21:
	goto	i1l5043
u680_20:
	line	40
	
i1l5041:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
i1l5043:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
i1l999:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
