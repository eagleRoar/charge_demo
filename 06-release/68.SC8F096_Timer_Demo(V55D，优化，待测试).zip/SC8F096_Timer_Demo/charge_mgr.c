/*-------------------------------------------
  L1211 12槽充电器 - 充电管理模块
-------------------------------------------*/
#include "config.h"

/* --- 本地常量(不依赖config.h的微调参数) --- */
#define DETECT_STABLE_TICKS      20    /* 高压稳定确认tick数: 20tick=200ms无显著下跌→真锂电 */
#define DETECT_HIGHV_RELEASE_TICKS 25  /* 高压锂电提前放行: 稳定后额外等待tick数(≈2s) */
#define DIODE_CLAMP_MARGIN       150   /* DIODE_TEST钳位判据: 相对脉冲前电压的最大允许爬升(ADC).
                                          超过说明电容未被电池/体二极管钳位→干电池高内阻特征 */
#define CC_RETRY_FLAG            0x80  /* g_ccBlocks bit7 复用为LINEAR_LI CC超时循环标记:
                                          0=首次超时回DETECT重判, 1=再次超时直接ERROR锁死,
                                          进CV/新CC周期/电池拔出时清零. */

/* --- IMP_CHECK/DIODE_TEST 检测阈值(ADC归一化值, VCC=5000mV基准) --- */
#define IMP_VCC_DROP_NIMH        300   /* VCC跌>300mV → 镍氢(极低内阻拉垮VCC) */
#define IMP_VCC_DROP_ION         200   /* VCC跌>200mV → 锂离子(charger IC拉载) */
#define IMP_VCC_DROP_LI          150   /* VCC跌>150mV → 恒压锂(charger IC轻载) */
#define IMP_BAT_REMOVED_THRESH   4050  /* 脉冲前后电压均≥此值 → 空槽/已拔出 */
#define IMP_DRY_DROP_THRESH      1000  /* 脉冲后较脉冲前跌>1000ADC → 碳性/碱性干电池 */
#define IMP_LI_ION_PRE_MAX       3100  /* 恒压锂VCC跌落判据: 脉冲前电压上限(中压段走DIODE_TEST) */

#define DIODE_HIGHV_FALL_PRE     3000  /* 高压回落识别: 脉冲前电压>3000 */
#define DIODE_MIDV_LOW           2300  /* 中压段下限(2300~NEAR_OPEN) */
#define DIODE_LOWV_THRESH        2100  /* 低压兜底: 当前电压下限 */
#define DIODE_LOWV_CLAMP_DROP    160   /* 低压兜底: 相对脉冲前允许下跌差值 */
#define DIODE_MIDV_CLAMP         150   /* 中压钳位: 电压与脉冲前允许差值 */
#define DIODE_LOWV_MIN_TICKS     20    /* 低压兜底: 最小等待tick数 */
#define DIODE_RISE_TRACE_MIN     136   /* 轨迹爬升判定: (v-pre)/4>=8 即 +128 */

/* --- CC/CV 低压崩溃/超时/满电阈值 --- */
#define CC_LOWV_CRASH_THRESH     2000  /* CC/CV低压崩溃阈值: v低于此值判崩溃 */
#define CC_LOWV_CRASH_CNT        33    /* 低压崩溃消抖tick数 */
#define CC_TIMEOUT_TICKS         200   /* CC阶段超时tick数(~16s) */
#define CC_NEAR_FULL_THRESH      2800  /* 满电边缘阈值: CC超时直接进CV / FULL补电 */
#define ERROR_NIMH_HIGHV_THRESH  2700  /* ERROR重判: NiMH维持此高压说明非真NiMH */

/*========================================================================
  全局变量
========================================================================*/
unsigned int g_temperature = 250;
unsigned char g_tempProtect = 0;
unsigned char g_vccProtect  = 0;         /* VCC低压保护标志: 1=VCC过低, 关闭充电 */
unsigned int g_slotRefV[BATTERY_SLOTS];  /* 槽位参考电压: DETECT存初始值/稳定基准, CC/CV存峰值 */
unsigned char g_ccBlocks[12];           /* CC阶段10分钟块计数(解决16bit chargeTimer溢出);
                                           bit7复用为LINEAR_LI CC超时循环标记 */
unsigned char g_ovCnt[12];              /* 过压消抖计数器: 连续过压次数 */
unsigned char g_detectLowCnt[12];       /* 通用消抖计数器(短路消抖/AMBIGUOUS消抖/LI_ION消抖) */
unsigned char g_impCheckSlot = 0xFF;    /* IMP_CHECK串行锁: 0xFF=空闲, 其他=持有锁的槽号
                                           同一时间只允许一个槽做IMP_CHECK,
                                           避免NiMH拉垮VCC导致其他槽误判 */
unsigned char g_stableCnt[12];           /* DETECT高压稳定循环专用计数器 */
unsigned int g_capFlag;                  /* 电容虚高标记位掩码: bit[i]=1表示槽i需扩展等待电容放电 */
unsigned int g_impData;                  /* IMP_CHECK共享数据: 低12位脉冲前电压+高4位VCC编码(100mV步进)
                                           因IMP_CHECK串行化, 同一时间仅一个槽使用 */
unsigned char g_diodeTrace[4];         /* DIODE_TEST v轨迹: 4点(ct=7,14,21,28),
                                         每点1字节存相对pre偏移/4+128(±127*4 ADC, clamp),
                                         单槽共享缓冲(IMP_CHECK串行锁保证同时仅一槽在DIODE_TEST),
                                         仅ISR写数组供主循环打印, 不阻塞UART */
unsigned char g_diodeTraceCnt;         /* DIODE_TEST v轨迹采样点数, 主循环打印后清零 */
unsigned char g_diodeTraceSlot;        /* 轨迹归属槽号(打印时匹配) */
unsigned int g_highVFlag;                /* DETECT高压确认标记: bit[i]=1表示槽i在高压稳定循环中
                                           连续≥DETECT_STABLE_TICKS维持V>2900, 用于IMP_CHECK
                                           区分恒压锂电池charger IC断开(false low)和真干电池 */
unsigned int g_vccImp;                   /* IMP检测专用实时VCC(mV). 存脉冲期VCC,
                                           与归一化基准g_vcc_mv解耦: NiMH脉冲拉垮VCC时
                                           只改此变量用于塌陷判据, 不污染其他槽的Adc_Norm基准. */

/*========================================================================
  函数: Get_Vcc
  功能: 采样VREF(内部1.2V参考)反推实时VCC(mV), 写回g_vcc_mv并返回
========================================================================*/
unsigned int Get_Vcc(void)
{
	if(ADC_OK == ADC_Sample(ADC_CH_VREF, 0))
	{
		unsigned long pt = POWER_RATIO / adresult;
		g_vcc_mv = (unsigned int)pt;
	}
	return g_vcc_mv;
}

/* IMP检测专用VCC采样. 只返回不写g_vcc_mv,
   使IMP脉冲/塌陷判据不污染归一化基准(供其他槽Adc_Norm用). */
unsigned int Get_Vcc_Imp(void)
{
	if(ADC_OK == ADC_Sample(ADC_CH_VREF, 0))
	{
		unsigned long pt = POWER_RATIO / adresult;
		return (unsigned int)pt;
	}
	return g_vcc_mv;                     /* 失败回退上次归一化基准 */
}

/*========================================================================
  函数: Adc_Norm
  功能: 采样指定ADC通道并归一化到 VCC_REF_MV(5000mV) 基准
  说明: ADC参考为VDD(比例式), 对固定物理电压(Vbat)有 raw ∝ 1/VCC,
        即VCC越高原始ADC越低. 归一化 raw*vcc/5000 把读数折算成
        "VCC=5000mV时的等效ADC", 使同一电池在不同槽位/不同电源下读数一致,
        可直接套用 VCC≈5000 标定的全部阈值. 结果钳位到4095防止溢出
        (否则 >4095 会污染 g_impData 高4位的VCC编码).
========================================================================*/
unsigned int Adc_Norm(unsigned char ch)
{
	unsigned int raw;
	unsigned long norm;

	if(ADC_OK != ADC_Sample(ch, 0))
		return 0;
	raw = adresult;

	/* 空槽/近开路(raw≥OPEN): BxAD被100K上拉跟随VCC, 原始ADC已是满量程且与VCC无关,
	   不归一化(否则低压电源下会把空槽/伪OPEN拉到OPEN以下造成误判电池). */
	if(raw >= ADC_V_OPEN)
		return raw;

	if(g_vcc_mv == 0)
		return raw;                     /* 防除0 */

	norm = (unsigned long)raw * g_vcc_mv / VCC_REF_MV;
	if(norm > 4095UL)                   /* 钳位防超12位(避免污染 g_impData 高4位VCC编码) */
		norm = 4095UL;
	return (unsigned int)norm;
}

unsigned int Read_Temperature(void)
{
	unsigned int ntcVal;
	unsigned int temp_x10;

	test_adc = ADC_Sample(ADC_CH_NTC, 0);
	if(ADC_OK != test_adc)
		return g_temperature;

	ntcVal = adresult;
	if(ntcVal < 100 || ntcVal > 3996)
		return g_temperature;

	{
		unsigned long rt;
		rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
		if(rt >= 10000UL)
			temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
		else
			temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
		if(temp_x10 < 100U) temp_x10 = 100U;
		if(temp_x10 > 750U) temp_x10 = 750U;
	}

	g_temperature = temp_x10;
	if((temp_x10 / 10U) >= TEMP_STOP)
		g_tempProtect = 1;
	else if((temp_x10 / 10U) <= TEMP_RESUME)
		g_tempProtect = 0;

	return temp_x10;
}

unsigned char Detect_BatteryType(unsigned int voltage)
{
	if(voltage >= ADC_V_OPEN)
		return BAT_TYPE_UNKNOWN;
	if(voltage < ADC_V_SHORT)
		return BAT_TYPE_UNKNOWN;

#if NIMH_DETECT_ENABLE
	/* AMBIGUOUS区间[NIMH_LOW, OPEN): 覆盖低/中/高压电池, 全部进入IMP_CHECK
	   用VCC跌落脉冲+体二极管爬升区分:
	   - VCC跌>300mV → NiMH(极低内阻拉垮VCC)
	   - VCC跌>200mV → LI_ION(charger IC拉载)
	   - 电池自身跌>1000ADC → DRY(碳性/碱性高内阻)
	   - 脉冲前>NEAR_OPEN且VCC不塌 → DRY(高压碳性/碱性)
	   - 脉冲前>2300(≤NEAR_OPEN) → LINEAR_LI(中压锂电兜底)
	   - 脉冲后电压≥OPEN → LINEAR_LI(体二极管阻断)
	   - DIODE_TEST爬升>DIODE_RISE_THRESH → LINEAR_LI(无charger IC)
	   - 否则DIODE_TEST超时 → DRY(干电池拒充)
	   高位碳性/碱性若漏入CC, PEAK_DROP会在数秒内纠正 */
	if(voltage >= ADC_V_NIMH_LOW && voltage < ADC_V_OPEN)
		return BAT_TYPE_AMBIGUOUS;
#endif

	/* AMBIGUOUS区间以外: SHORT~NIMH_LOW(低压/过放锂) → LI_ION
	   或 OPEN以上 → UNKNOWN(已达L69返回) */
	if(voltage >= ADC_V_SHORT && voltage < ADC_V_OPEN)
		return BAT_TYPE_LI_ION;

	return BAT_TYPE_UNKNOWN;
}

volatile BatterySlot_t g_slot[12];

/* 槽位字段读写辅助宏 */
#define SLOT_RD_ALL(idx, st, ty, v, ct)  do { \
	st = g_slot[(idx)].state; ty = g_slot[(idx)].type; \
	v  = g_slot[(idx)].voltage; ct = g_slot[(idx)].chargeTimer; \
} while(0)

#define SLOT_WR_ALL(idx, st, ty, v, ct)  do { \
	g_slot[(idx)].state = st; g_slot[(idx)].type = ty; \
	g_slot[(idx)].voltage = v; g_slot[(idx)].chargeTimer = ct; \
} while(0)

/* 锂电池DETECT后统一充电路由: 计算bat_mv→按电压档位跳转ACTIVATE/PRECHARGE/CV/CC */
#define DETECT_LI_ROUTE(idx, v, st, ct)  do { \
	unsigned long vx_mv = (unsigned long)(v) * VCC_REF_MV / 4096UL; \
	unsigned long bat_mv_long = ALPHA_NUM * vx_mv + BETA_NUM * VCC_REF_MV; \
	unsigned int  bat_mv = (unsigned int)((bat_mv_long + CAL_DEN/2UL) / CAL_DEN); \
	if(bat_mv <= BAT_MV_ACTIVATE) { \
		st = CHG_ACTIVATE; \
	} else if(bat_mv < BAT_MV_PRECHARGE) { \
		st = CHG_PRECHARGE; \
	} else if(bat_mv >= BAT_MV_FULL) { \
		if(g_ccBlocks[idx] >= CV_DROP_LOOP_MAX) { \
			st = CHG_ERROR; \
		} else { \
			st = CHG_CV_CHARGE; \
			g_slotRefV[idx] = v; \
			g_ccBlocks[idx] = 0; \
			g_stableCnt[idx] = 0; \
		} \
	} else { \
		st = CHG_CC_CHARGE; \
		g_ccBlocks[idx] &= CC_RETRY_FLAG; /* 仅清块计数, 保留CC_RETRY_FLAG:
		                                     使CC超时重判循环能累计到再次超时ERROR. */ \
		g_slotRefV[idx] = v; \
		g_stableCnt[idx] = 0; \
	} \
	ct = 0; \
	g_ovCnt[idx] = 0; \
	g_detectLowCnt[idx] = 0; \
} while(0)

/* IMP_CHECK阶段VCC解码: 从g_impData高4位还原脉冲前VCC(mV), 误差≤50mV */
#define IMP_VCC_DECODE(data)  (((((data) >> 12) & 0x0FU) + 38U) * 100U)

void Slot_Charge_Ctrl(unsigned char idx)
{
	unsigned char st, ty;                   /* st: 充电状态, ty: 电池类型 */
	unsigned int  v, ct;                   /* v: ADC电压(归一化), ct: 充电计时器 */
	unsigned char dly;                     /* 稳定延时循环计数 */

	SLOT_RD_ALL(idx, st, ty, v, ct);

	/* --- 单槽同步采样: 关MOSFET → 稳定延时 → 采样并归一化 --- */
	SLOT_CHARGE_OFF(idx);
	if(st == CHG_DETECT || st == CHG_IMP_CHECK || st == CHG_IMP_DIODE_TEST)
	{
		/* 2000us: 让BxAD电容充电/放电到可区分电池类型的电平 */
		for(dly = 0; dly < 20; dly++)
			__delay_us(100);
	}
	else
	{
		__delay_us(100);
	}

	{
		unsigned int newv = Adc_Norm(s_adcChannels[idx]);
		/* LINEAR_LI CC/CV伪OPEN消噪: 读到OPEN不更新, 保留上次有效值 */
		if(!(ty == BAT_TYPE_LINEAR_LI &&
		     (st == CHG_CC_CHARGE || st == CHG_CV_CHARGE) &&
		     newv >= ADC_V_OPEN))
		{
			v = newv;
		}
	}

	switch(st)
	{
	case CHG_IDLE:
		/* 空槽(v≥OPEN)停留IDLE_POLL_TICKS后再转DETECT, 避免空槽在
		   DETECT→IMP_CHECK→IDLE 间循环导致红灯常亮. 插入电池(v<OPEN)立即转DETECT. */
		if(v >= ADC_V_OPEN)
		{
			if(ct < IDLE_POLL_TICKS)
			{
				ct++;
				break;
			}
		}
		ct = 0;
		st = CHG_DETECT;
		g_ccBlocks[idx] = 0;      /* 新检测周期复位CV崩溃计数与CC_RETRY_FLAG */
		g_highVFlag &= ~((unsigned int)1 << idx);
		/* 记录IDLE→DETECT初始电压, 供DETECT稳定检测基准使用 */
		if(v < ADC_V_OPEN)
			g_slotRefV[idx] = v;
		else
			g_slotRefV[idx] = 0;
		break;

	case CHG_DETECT:
		ct++;

		/* 首次进入DETECT(ct==1): 重置本槽专用计数器, 清除可能残留的电容标记 */
		if(ct == 1)
		{
			g_stableCnt[idx] = 0;
			g_capFlag &= ~((unsigned int)1 << idx); /* 通过idx清除可能残留的电容标记 */
		}

		if(ct < TIME_DETECT_WAIT)
		{
			/* 等待期内不判型: 干电池/碱性由后续 IMP_CHECK / DIODE_TEST
			   链路正常拒充, 此处仅让电压建立稳定. */
			break;
		}

		/* 高内阻电池(碳性/碱性)开槽放电稳定检测:
		   OPEN→DETECT时槽位电容充满近VCC电荷, 高内阻电池放电慢,
		   初始ADC读数偏高. 若稳定后降至≤ADC_V_NIMH_MAX→电容放电→清除cap标记;
		   高压区间持续稳定=真锂电池→放行, 否则超时判DRY. */
		if(ct == TIME_DETECT_WAIT)
		{
			g_slotRefV[idx] = v;
			if(v > ADC_V_NIMH_MAX)
				g_capFlag |= (unsigned int)1 << idx;  /* 标记: 初始电压>2900(可能是电容放电) */
			break;
		}
		if(v > ADC_V_NIMH_MAX && v < ADC_V_OPEN)
		{
			/* 门禁: 仅ct=TIME_DETECT_WAIT时电压已>2900(g_capFlag置位)
			   才进入高压稳定路径. 若初始电压≤2900(无cap标记)后电压
			   异常跳升>2900: 多槽IMP_CHECK排队等待期间其他槽充电噪声/
			   串扰导致ADC读值异常(碳性1960→3769), 重置DETECT重读.
			   但电压>NEAR_OPEN(3500)时已接近OPEN, 不可能是碳性噪声,
			   应继续高压稳定流程, 避免高压线性锂/恒压锂(B11等)卡死.
			   接触改善导致电压真上升会在重置后ct=TIME_DETECT_WAIT时正确置cap标记
			   ty=AMBIGUOUS跳过: amb_shortcut清除g_capFlag后ty已标记
			   为AMBIGUOUS(确认高压稳定), 门禁不应重置ct→丢失进度 */
			if(!(g_capFlag & ((unsigned int)1 << idx)) && ty != BAT_TYPE_AMBIGUOUS &&
			   v <= ADC_V_NEAR_OPEN)
			{
				ct = 0;
				g_slotRefV[idx] = 0;
				g_stableCnt[idx] = 0;
				g_detectLowCnt[idx] = 0;
				break;
			}

			/* 高压区间(>2900): 两阶段处理
			   [1]稳定循环: 连续DETECT_STABLE_TICKS无显著下跌→电压已稳定.
			       每周期更新g_slotRefV跟踪当前值, 防电压振荡被误判为累计下跌.
			   [2]扩展等待: cap标记电池稳定后延长等待电容放电至≤2900,
			       超时仍>2900→真实锂电池放行. */
			unsigned int v_init = g_slotRefV[idx];

			if(g_stableCnt[idx] >= DETECT_STABLE_TICKS)
			{
				/* 高压稳定确认: 记录此槽在DETECT中V>2900持续稳定,
				   IMP_CHECK时若判DRY但此标记存在→charger IC断开假象→走LI_ION
				   真干电池(碳性/碱性)无法在高压区间连续20tick保持稳定 */
				g_highVFlag |= (unsigned int)1 << idx;
				/* ── 阶段[2]: 扩展等待电容放电 ── */
				if(v <= ADC_V_NIMH_MAX)
				{
					/* 电压降至2900以下 → 电容放电确认, 清除所有高压标记 */
					g_capFlag &= ~((unsigned int)1 << idx);
					g_stableCnt[idx] = 0;
					g_highVFlag &= ~((unsigned int)1 << idx);
				}
				else if(ct < TIME_DETECT_WAIT + TIME_DETECT_SETTLE)
				{
					/* 高压锂电提前放行: g_highVFlag已确认V>2900稳定,
			   保守等25tick(≈2s)后仍>2900→真锂电, 直接IMP_CHECK.
			   异常环境误入由 DIODE_TEST 判据及 CC/CV 崩溃锁定兜底. */
				if((g_highVFlag & ((unsigned int)1 << idx)) &&
				   ct >= TIME_DETECT_WAIT + DETECT_HIGHV_RELEASE_TICKS)
					goto amb_shortcut;
					/* 继续等待, 更新基准跟踪当前值 */
					g_slotRefV[idx] = v;
					break;
				}
					else
				{
				amb_shortcut:
					/* 超时仍>2900: 走AMBIGUOUS→IMP_CHECK用VCC跌落做最后区分:
					有charger IC(VCC跌落>200mV)→LI_ION, 无→LINEAR_LI
					必须goto amb_check, 否则后续Detect_BatteryType(v)会
					将ty覆盖为LI_ION(>2900), 导致IMP_CHECK被跳过 */
					g_capFlag &= ~((unsigned int)1 << idx);
					g_stableCnt[idx] = 0;
					ty = BAT_TYPE_AMBIGUOUS;
					goto amb_check;
				}
			}
			else
			{
				/* ── 阶段[1]: 稳定循环 ── */
				if(v + DETECT_SETTLE_DROP < v_init)
				{
					/* 电压显著下跌: 仍在放电, 更新基准并重置稳定计数 */
					g_slotRefV[idx] = v;
					g_stableCnt[idx] = 0;
				}
				else
				{
					/* 电压稳定(或小幅上升): 更新基准跟踪当前值, 递增稳定计数 */
					g_slotRefV[idx] = v;
					g_stableCnt[idx]++;
				}
				if(g_stableCnt[idx] < DETECT_STABLE_TICKS)
					break;                       /* 尚未稳定: 继续等待 */
				/* 稳定确认: cap标记→保留计数器进入阶段[2]扩展等待 */
				if(g_capFlag & ((unsigned int)1 << idx))
					break;                       /* 下tick进入扩展等待 */
				g_stableCnt[idx] = 0;            /* 无cap标记: 直接放行 */
			}
		}
		else if(ct < TIME_DETECT_WAIT + TIME_DETECT_SETTLE && v < ADC_V_OPEN)
		{
			unsigned int v_ref = g_slotRefV[idx];
			if(v_ref < ADC_V_OPEN && v + DETECT_SETTLE_DROP < v_ref)
			{
				g_slotRefV[idx] = v;
				break;
			}
		}

		/* 电容放电标记路由: 电压已降至2900以下(经扩展等待或自然放电)
		   统一走AMBIGUOUS→IMP_CHECK: VCC跌落脉冲可靠区分NiMH(>300mV塌陷)
		   和锂电(>200mV跌落), 碳性无charger IC不拉载VCC→判DRY拒充 */
		if(g_capFlag & ((unsigned int)1 << idx))
		{
			g_capFlag &= ~((unsigned int)1 << idx);  /* 清除标记 */
			g_detectLowCnt[idx] = 0;                  /* 重置消抖计数器 */
			ty = BAT_TYPE_AMBIGUOUS;                  /* 强制AMBIGUOUS→IMP_CHECK */
		}
		else
		{
			ty = Detect_BatteryType(v);
			/* 空槽(v≥OPEN)超时后强制转AMBIGUOUS, 复用amb_check的消抖+串行锁
			   进入IMP_CHECK: 空槽脉冲前后v均≥OPEN→IDLE, 真电池负载下v跌至真实值→正常充电. */
			if(ty == BAT_TYPE_UNKNOWN && v >= ADC_V_OPEN &&
			   ct >= TIME_DETECT_WAIT + TIME_DETECT_SETTLE)
				ty = BAT_TYPE_AMBIGUOUS;
		}

		/* 消抖: 高内阻电池ADC读数可能跳动到极低值,
		   连续N次低值才判定为UNKNOWN, 避免单次噪点误触发ERROR */
		if(v < ADC_V_SHORT)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < DETECT_LOW_DEBOUNCE)
				break;
		}
		/* 仅对UNKNOWN/NIMH/DRY重置计数器, AMBIGUOUS和LI_ION各自维护消抖计数 */
		else if(ty != BAT_TYPE_AMBIGUOUS && ty != BAT_TYPE_LI_ION && ty != BAT_TYPE_LINEAR_LI)
		{
			g_detectLowCnt[idx] = 0;
		}

	amb_check:
		if(ty == BAT_TYPE_AMBIGUOUS)
		{
			/* AMBIGUOUS电压段(1.20V~1.45V): 短脉冲方向检测区分
			   恒压/线性锂电池: 接PWM后芯片切充电模式→电压上升
			   NiMH: 极低内阻等效短路→VCC塌陷(>300mV)
			   干电池: 高内阻限流→电压不升, VCC不塌
			   消抖: 单帧VCC污染可能让空槽(4093)误读为~2243, 需连续2帧确认 */
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			/* 串行化: 同一时间只允许一个槽做IMP_CHECK,
			   避免NiMH极低内阻拉垮整个VCC导致其他槽同时误判 */
			if(g_impCheckSlot != 0xFF && g_impCheckSlot != idx)
				break;                /* 等待其他槽完成IMP_CHECK */
			g_impCheckSlot = idx;
			/* 重新采样VCC: 防止g_vcc_mv滞后于其他槽充电导致的VCC跌落,
			   避免后续IMP_CHECK中误判(其他槽充电会拉低VCC). */
			g_vccImp = Get_Vcc_Imp();
			/* VCC打包至g_impData: 低12位=脉冲前电压v(0~4095), 高4位=脉冲前VCC编码
			   VCC编码 = (g_vccImp+50)/100 - 38, 四舍五入到100mV, 覆盖3800~5100mV范围
			   IMP_CHECK串行锁保证单槽访问, 无需数组 */
			g_impData = v | ((unsigned int)(((g_vccImp + 50U) / 100U) - 38U) << 12);
			st = CHG_IMP_CHECK;
			ct = 0;
			g_detectLowCnt[idx] = 0;
		}
		if(ty == BAT_TYPE_LI_ION || ty == BAT_TYPE_LINEAR_LI)
		{
			/* LI_ION/LINEAR_LI: 连续2帧确认, 防止碳性/碱性电池ADC尖峰越过NIMH_HIGH误判 */
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			DETECT_LI_ROUTE(idx, v, st, ct);
		}
		else if(ty == BAT_TYPE_UNKNOWN)
		{
			/* UNKNOWN: 分辨空槽(OPEN)和不可识别电池(SHORT/异常)
			   注: v≥OPEN且等待超时的空槽已由上方ty强制AMBIGUOUS接管,
			   此分支的OPEN等待仅在超时前短暂出现(电容放电中) */
			if(v >= ADC_V_OPEN)
				break;                /* 继续等待电压下降 */
			st = CHG_ERROR;           /* 电压异常或无法识别 → 报错 */
			g_detectLowCnt[idx] = 0;
		}
		else if(ty == BAT_TYPE_NIMH || ty == BAT_TYPE_DRY)
		{
			st = CHG_ERROR;
			g_detectLowCnt[idx] = 0;
		}
		break;

	case CHG_IMP_CHECK:
		ct++;
		if(ct < IMP_PULSE_TICKS)
			break;

		{
			/* 实时VCC采样: IMP_CHECK期间MOSFET已导通~80ms */
			g_vccImp = Get_Vcc_Imp();

			/* ── 电池拔出检测（最高优先级） ──
			   脉冲前后电压均≥IMP_BAT_REMOVED_THRESH → 确实空槽/已被拔出.
			   阈值高于OPEN, 避免满电高压碱性(接近OPEN)被误拔入IDLE死循环. */
			if(v >= IMP_BAT_REMOVED_THRESH && (g_impData & 0x0FFFU) >= IMP_BAT_REMOVED_THRESH)
			{
				ty = BAT_TYPE_UNKNOWN;
				st = CHG_IDLE;
				g_impCheckSlot = 0xFF;
				g_highVFlag &= ~((unsigned int)1 << idx);
				break;
			}

			/* ── NiMH VCC塌陷检测 ──
			   VCC跌落>300mV 且 脉冲后电池端被拉到OPEN
			   恒压锂电charger IC也会拉低VCC, 但电池端不会飙升到OPEN, 避免误判 */
			if(IMP_VCC_DECODE(g_impData) > g_vccImp + IMP_VCC_DROP_NIMH && v >= ADC_V_OPEN)
			{
				ty = BAT_TYPE_NIMH;
				st = CHG_ERROR;
				g_impCheckSlot = 0xFF;
				g_highVFlag &= ~((unsigned int)1 << idx);
				break;
			}

			/* ── 恒压锂电: VCC跌落>IMP_VCC_DROP_ION ──
			   仅对脉冲前电压<IMP_LI_ION_PRE_MAX的电池启用, 中高压段
			   易因VCC波动误判, 统一走DIODE_TEST用爬升区分. */
			if(IMP_VCC_DECODE(g_impData) > g_vccImp + IMP_VCC_DROP_ION &&
			   (g_impData & 0x0FFFU) < IMP_LI_ION_PRE_MAX)
				goto imp_li_ion;

			/* ── 碳性/碱性干电池: 脉冲后电压比脉冲前低>IMP_DRY_DROP_THRESH ──
			   g_highVFlag保护: DETECT已确认高压稳定的真锂电跳过此判据
			   (其脉冲前读数是电容虚高), 碳性/碱性内阻大无法稳定仍正常拒充. */
			if(!(g_highVFlag & ((unsigned int)1 << idx)) &&
			   ((g_impData & 0x0FFFU) > v) &&
			   ((g_impData & 0x0FFFU) - v) > IMP_DRY_DROP_THRESH)
			{
				ty = BAT_TYPE_DRY;
				st = CHG_ERROR;
				g_impCheckSlot = 0xFF;
				g_highVFlag &= ~((unsigned int)1 << idx);
				g_detectLowCnt[idx] = 0;
				break;
			}

			/* ── 高压锂电保护: pre>NEAR_OPEN 且 VCC不塌(<200mV)
			   不直接判DRY, 先进DIODE_TEST确认, 避免高压恒压锂/线性锂
			   (B10/B11/B12等)被误拒充 */
			if(((g_impData & 0x0FFFU) > ADC_V_NEAR_OPEN) &&
			   (IMP_VCC_DECODE(g_impData) <= g_vccImp + IMP_VCC_DROP_ION))
			{
				goto imp_diode_test_entry;
			}

			/* ── 脉冲后≥OPEN → 进DIODE_TEST进一步确认 ──
			   可能是线性锂/恒压锂/镍氢, DIODE_TEST用爬升区分Li与DRY/NiMH */
			if(v >= ADC_V_OPEN)
				goto imp_diode_test_entry;

		imp_diode_test_entry:
			/* ── 进入DIODE_TEST ──
			   保持IMP_CHECK串行锁不释放, 防止g_impData基准被其它槽改写 */
			st = CHG_IMP_DIODE_TEST;
			ct = 0;
			g_diodeTraceCnt = 0;        /* 新一轮检测开始, 清v轨迹(单槽共享缓冲) */
			g_diodeTraceSlot = (unsigned char)idx;
			g_highVFlag &= ~((unsigned int)1 << idx);
		}
		break;

	/* ── Li-ion路由(共用代码, goto跳转节省RAM) ── */
	imp_li_ion:
		g_impCheckSlot = 0xFF;
		g_highVFlag &= ~((unsigned int)1 << idx);
		ty = BAT_TYPE_LI_ION;
		DETECT_LI_ROUTE(idx, v, st, ct);
		break;

	/* ── 线性锂电池路由(无charger IC, VCC不塌) ──
	   检测: (1)脉冲后≥OPEN(体二极管阻断) (2)DIODE_TEST爬升>DIODE_RISE_THRESH
	   用脉冲前电压(g_impData低12位)做DETECT_LI_ROUTE:
	   线性锂无charger IC拉载, IMP_CHECK PWM脉冲后电容充电至VCC,
	   体二极管被阻断无法放电→v读伪OPEN(4091), 若用v做路由会误入CV
	   且g_slotRefV被设为4091, 后续PEAK_DROP必然触发
	   脉冲前电压来自DETECT(MOSFET导通→电容跟踪Vbat→读数准确) */
	imp_linear_li:
		g_impCheckSlot = 0xFF;
		g_highVFlag &= ~((unsigned int)1 << idx);
		ty = BAT_TYPE_LINEAR_LI;
		DETECT_LI_ROUTE(idx, (unsigned int)(g_impData & 0x0FFFU), st, ct);
		break;

	/*========================================================================
	  CHG_IMP_DIODE_TEST: 体二极管被动检测
	  MOSFET关断, BxAD电容通过100K上拉充电, 观察电压爬升
	  线性锂(体二极管阻断): 电容持续爬升>DIODE_RISE_THRESH
	  镍氢/干电池(体二极管导通或内阻大): 电压被钳位, 爬升不足
	========================================================================*/
	case CHG_IMP_DIODE_TEST:
		ct++;
		/* 记录v相对pre的偏移轨迹(ct=7,14,21,28共4点, 每点1字节:
		   (v-pre)/4+128, 覆盖±508ADC并clamp), 供主循环打印分析. */
		if((ct == 7U || ct == 14U || ct == 21U || ct == 28U) &&
		   g_diodeTraceCnt < 4U)
		{
			signed int diff = (signed int)v - (signed int)(g_impData & 0x0FFFU);
			diff >>= 2;                       /* /4 */
			if(diff > 127) diff = 127;
			if(diff < -128) diff = -128;
			g_diodeTrace[g_diodeTraceCnt++] = (unsigned char)(diff + 128);
		}
		{
			/* 电池拔出检查: 线性锂误插后拔出→电压回落至OPEN */
			if(v >= ADC_V_OPEN && (g_impData & 0x0FFFU) < ADC_V_OPEN)
			{
				/* 预脉冲非OPEN但当前OPEN: 电容正在充电中, 不是真拔出 */
			}

			/* 电压爬升检测: 当前电压-脉冲前电压 > DIODE_RISE_THRESH → Li */
			if(v > (g_impData & 0x0FFFU) + DIODE_RISE_THRESH)
			{
				/* 用IMP_CHECK期间记录的VCC跌落区分CV锂与线性锂:
				   跌落>150mV → 恒压锂, 否则 → 线性锂 */
				if(IMP_VCC_DECODE(g_impData) > g_vccImp + IMP_VCC_DROP_LI)
					goto imp_li_ion;
				else
					goto imp_linear_li;
			}

			/* 高压锂电回落识别:
			   IMP_CHECK时MOSFET导通使电容充到偏高电压, 关断后真实高压锂电
			   (低内阻)把电容迅速拉回本体电压 → v明显低于pre但仍>NIMH_MAX.
			   碱性/碳性内阻大, 电容被100K继续拉向VCC, 不会出现此回落. */
		if(((g_impData & 0x0FFFU) > DIODE_HIGHV_FALL_PRE) &&
		   (v > ADC_V_NIMH_MAX) &&
		   (v < (g_impData & 0x0FFFU)))
			goto imp_linear_li;

			/* NiMH上拉虚高保护:
			   脉冲前≤2300但DIODE_TEST期间电压>2900, 说明是100K上拉把电池/电容
			   充起来的虚假高电平, 判DRY拒充, 避免镍氢被误判为LINEAR_LI. */
			if((v > ADC_V_NIMH_MAX) &&
			   ((g_impData & 0x0FFFU) <= DIODE_MIDV_LOW))
			{
				ty = BAT_TYPE_DRY;
				st = CHG_ERROR;
				g_impCheckSlot = 0xFF;
				g_highVFlag &= ~((unsigned int)1 << idx);
				g_detectLowCnt[idx] = 0;
				break;
			}

			/* 低压锂电兜底: DIODE_TEST满DIODE_LOWV_MIN_TICKS后, 电压仍稳定
			   在>DIODE_LOWV_THRESH且与脉冲前基本持平(下跌<DIODE_LOWV_CLAMP_DROP,
			   爬升≤DIODE_CLAMP_MARGIN), 说明电容被钳位在电池电压附近 → 真锂电放行.
			   干电池高内阻被100K上拉推离电池电压, 不满足钳位判据 → 超时判DRY. */
			if(ct >= DIODE_LOWV_MIN_TICKS && v > DIODE_LOWV_THRESH &&
			   (g_impData & 0x0FFFU) <= DIODE_MIDV_LOW &&
			   v + DIODE_LOWV_CLAMP_DROP >= (g_impData & 0x0FFFU) &&
			   v <= (g_impData & 0x0FFFU) + DIODE_CLAMP_MARGIN)
				goto imp_linear_li;

			/* 超时: 无爬升 → 干电池. 但高压/中压锂电可能因电容/体二极管
			   特性爬升不足(<DIODE_RISE_THRESH), 需在下方用VCC跌落+稳定钳位
			   判据放行, 避免误杀; 碳性误放行由后续CC超时循环锁定ERROR兜底. */
			if(ct >= DIODE_TEST_TICKS)
			{
				unsigned int pre = (unsigned int)(g_impData & 0x0FFFU);
				/* 高压段(pre>NEAR_OPEN)用"VCC跌落+爬升"双判据:
				   VCC跌落>IMP_VCC_DROP_LI → 恒压锂; 有爬升 → 线性锂;
				   均不满足 → 碳性/碱性, 判DRY. */
				if(pre > ADC_V_NEAR_OPEN && pre < ADC_V_OPEN)
				{
					unsigned char tc;
					unsigned char hasRise = 0;
					for(tc = 0; tc < g_diodeTraceCnt; tc++)
					{
						if(g_diodeTrace[tc] >= DIODE_RISE_TRACE_MIN)   /* (v-pre)/4>=8 */
						{
							hasRise = 1;
							break;
						}
					}
					if(IMP_VCC_DECODE(g_impData) > g_vccImp + IMP_VCC_DROP_LI)
						goto imp_li_ion;              /* 恒压锂 */
					if(!hasRise)
					{
						ty = BAT_TYPE_DRY;
						st = CHG_ERROR;
						g_impCheckSlot = 0xFF;
						g_highVFlag &= ~((unsigned int)1 << idx);
						g_detectLowCnt[idx] = 0;
						break;
					}
					goto imp_linear_li;               /* 线性锂 */
				}
				if(v > ADC_V_NEAR_OPEN && v < ADC_V_OPEN)
				{
					goto imp_linear_li;
				}
				/* 中压钳位(DIODE_MIDV_LOW~NEAR_OPEN): 电压稳定钳位在电池电压
				   附近(v与pre差<DIODE_MIDV_CLAMP)即放行线性锂, 覆盖中压段盲区;
				   碳性误放行由CC超时循环锁定ERROR兜底. */
				if(v > DIODE_MIDV_LOW && v < ADC_V_NEAR_OPEN && pre < ADC_V_NEAR_OPEN &&
				   v + DIODE_MIDV_CLAMP >= pre && pre + DIODE_MIDV_CLAMP >= v)
				{
					goto imp_linear_li;
				}
				ty = BAT_TYPE_DRY;
				st = CHG_ERROR;
				g_impCheckSlot = 0xFF;
				g_highVFlag &= ~((unsigned int)1 << idx);
				g_detectLowCnt[idx] = 0;
			}
	}
	break;

	case CHG_ACTIVATE:
		ct++;
		if(ct > TIME_ACTIVATE_MAX)
		{
			st = CHG_ERROR;
			break;
		}
		if(v > ADC_V_ACTIVATE)
		{
			st = CHG_PRECHARGE;
			ct = 0;
			break;
		}
		if(v >= ADC_V_OVER)
		{
			st = CHG_ERROR;
			break;
		}
		break;

	case CHG_PRECHARGE:
		ct++;
		if(ct > TIME_PRECHARGE_MAX)
		{
			st = CHG_ERROR;
			break;
		}
		if(v >= ADC_V_OVER)
		{
			g_ovCnt[idx]++;
			if(g_ovCnt[idx] >= OV_DEBOUNCE_CNT)
			{
				st = CHG_ERROR;
				break;
			}
		}
		else
		{
			g_ovCnt[idx] = 0;
		}
		if(v >= ADC_V_PRE_MAX)
		{
			st = CHG_CC_CHARGE;
			ct = 0;
			g_ccBlocks[idx] = 0;       /* 复位块计数与CC_RETRY_FLAG */
			g_ovCnt[idx] = 0;
			g_slotRefV[idx] = v;
			g_stableCnt[idx] = 0;      /* 复位CC无进展检测闩锁 */
		}
		break;

	case CHG_CC_CHARGE:
		ct++;
		if(ct >= CC_BLOCK_TICKS)
		{
			ct -= CC_BLOCK_TICKS;
			g_ccBlocks[idx]++;
		}
		if(g_ccBlocks[idx] >= CC_MAX_BLOCKS)
		{
			st = CHG_ERROR;
			break;
		}

		/* 伪OPEN过滤: 线性锂电池无charger IC, BxAD电容充电至VCC后放电不足→伪OPEN(4091),
		   伪OPEN不更新g_slotRefV(防4091污染), 不触发CC→CV(等真实电压达标),
		   继续PEAK_DROP/OV/CC_MAX_BLOCKS等安全检查, CC→CV由真实电压触发 */
		if(v >= ADC_V_OPEN && ty == BAT_TYPE_LINEAR_LI)
		{
			/* g_slotRefV不更新(跳过4091污染), 继续后续检查 */
		}
		else if(ct <= CC_NO_PROGRESS_TICKS)
		{
			/* CC无进展检测窗口期内冻结g_slotRefV为CC起点基准v0,
			   不做峰值追踪, 供进展判断与PEAK_DROP跌落基准使用;
			   窗口结束后恢复峰值追踪. */
		}
		else
		{
			if(v > g_slotRefV[idx]) g_slotRefV[idx] = v;
		}

		/* 电压跌落/低压崩溃重判: 按类型分类处理, 避免共用消抖计数互相清零.
		   - LINEAR_LI: v<CC_LOWV_CRASH_THRESH持续CC_LOWV_CRASH_CNT tick→ERROR
		   - LI_ION: 峰值跌落>PEAK_DROP_THRESH或低压, 连续2帧→回DETECT重判 */
		if(ty == BAT_TYPE_LINEAR_LI)
		{
			if(v < CC_LOWV_CRASH_THRESH)
			{
				g_detectLowCnt[idx]++;
				if(g_detectLowCnt[idx] >= CC_LOWV_CRASH_CNT)
				{
					g_detectLowCnt[idx] = 0;
					st = CHG_ERROR;
					ct = 0;
					break;
				}
			}
			else
			{
				g_detectLowCnt[idx] = 0;
			}

			/* CC超时循环重判: 首次超时置CC_RETRY_FLAG并回DETECT重判,
			   再次超时直接ERROR锁死. 满电边缘(v≥CC_NEAR_FULL_THRESH)直接进CV;
			   用起点ref判断充电进展: 有进展则延长CC, 无进展(碳性)才走flag循环. */
		if(ct >= CC_TIMEOUT_TICKS)
		{
			ct = 0;
			if(v >= CC_NEAR_FULL_THRESH && v < ADC_V_OPEN)
			{
				st = CHG_CV_CHARGE;
				g_ccBlocks[idx] = 0;
				g_slotRefV[idx] = v;
				g_stableCnt[idx] = 0;
			}
			else if(v >= g_slotRefV[idx] + CC_NO_PROGRESS_RISE)
			{
				g_stableCnt[idx] = 1;    /* 真实锂电: CC中有充电进展, 标记后延长 */
				g_slotRefV[idx] = v;     /* 重置起点, 下一轮窗口冻结新基准 */
			}
			else if(g_stableCnt[idx] != 0)
			{
				g_slotRefV[idx] = v;     /* 已确认进展: 继续CC充电, 不循环不ERROR */
			}
			else if(g_ccBlocks[idx] & CC_RETRY_FLAG)
			{
				st = CHG_ERROR;          /* 碳性/异常: 无进展二次超时锁死 */
			}
			else
			{
				g_ccBlocks[idx] |= CC_RETRY_FLAG;
				st = CHG_DETECT;         /* 首次超时无进展: 回DETECT重判 */
				g_slotRefV[idx] = 0;
				g_stableCnt[idx] = 0;
			}
			break;
		}
		}
		else
		{
			/* 跌落检测加v<g_slotRefV守卫: 窗口期g_slotRefV冻结为起点v0,
			   电压上升时直接相减会unsigned回绕成巨大值→误判跌落死循环. */
			if((v < g_slotRefV[idx] && g_slotRefV[idx] - v > PEAK_DROP_THRESH) || v < CC_LOWV_CRASH_THRESH)
			{
				g_detectLowCnt[idx]++;
				if(g_detectLowCnt[idx] < 2)
					break;
				g_detectLowCnt[idx] = 0;
				st = CHG_DETECT;
				ct = 0;
				break;
			}
			else
			{
				g_detectLowCnt[idx] = 0;
			}

			/* CC无进展检测: 进CC后CC_NO_PROGRESS_TICKS内电压上升
			   <CC_NO_PROGRESS_RISE, 即维持中压不升不降 → 误判LI_ION的
			   碳性/异常电池 → ERROR. 窗口期g_slotRefV冻结为起点v0,
			   g_stableCnt做进展闩锁. */
			if(ct <= CC_NO_PROGRESS_TICKS)
			{
				if(v >= g_slotRefV[idx] + CC_NO_PROGRESS_RISE)
					g_stableCnt[idx] = 1;
			}
			if(ct > CC_NO_PROGRESS_TICKS && g_stableCnt[idx] == 0)
			{
				st = CHG_ERROR;
				ct = 0;
				break;
			}
		}

		/* 线性锂电池(LC9203DC): 内部电芯VBAT>充电器VOUT时,
		   芯片不激活充电模式→不拉电流→BxAD电容充电至VCC→伪OPEN
		   恒压锂电池(LC9203DB)有charger IC始终拉载, 不会出现此现象
		   LI_ION+OPEN在CC阶段出现 → 电芯已充满 → 跳转FULL
		   线性锂电池排除: 100μs放电不足导致伪OPEN与真实电压交替出现,
		   伪OPEN不代表充满, 走正常CC→CV→FULL路径 */
		if(v >= ADC_V_OPEN && ty == BAT_TYPE_LI_ION)
		{
			st = CHG_FULL;
			ct = 0;
			break;
		}

		/* 过压保护: 线性锂电池排除(无charger IC, ADC读数因电容残留不可靠,
		   伪OPEN(4091)不是真过压, 且已排除伪OPEN→FULL和PEAK_DROP,
		   真过压由电池自身保护板处理) */
		if(v >= ADC_V_OVER && ty != BAT_TYPE_LINEAR_LI)
		{
			g_ovCnt[idx]++;
			if(g_ovCnt[idx] >= OV_DEBOUNCE_CNT)
			{
				st = CHG_ERROR;
				break;
			}
		}
		else
		{
			g_ovCnt[idx] = 0;
			/* LINEAR_LI伪OPEN不触发CC→CV: 等真实电压≥FULL时转换 */
			if(v >= ADC_V_FULL && !(v >= ADC_V_OPEN && ty == BAT_TYPE_LINEAR_LI))
			{
				st = CHG_CV_CHARGE;
				ct = 0;
				g_ccBlocks[idx] = 0;    /* 复位CV上爬检测起点锁/闩锁与CC_RETRY_FLAG */
			}
		}
		break;

	case CHG_CV_CHARGE:
		ct++;
		if(ct > TIME_CV_HOLD)
			st = CHG_FULL;

		/* 伪OPEN过滤(必须在g_slotRefV更新之前):
		   线性锂电池(LC9203DC)无charger IC, MOSFET导通时BxAD电容充电至VCC,
		   100μs放电不足→伪OPEN(4091)≠真实电压, 跳过本次ADC读数,
		   保持当前充电状态(cvTimer已累加)继续下一周期, 防止:
		   (a) g_slotRefV被4091污染→后续PEAK_DROP假落差
		   (b) 拔出检测误判→IMP_CHECK↔CV↔IDLE死循环 */
		if(v >= ADC_V_OPEN && ty == BAT_TYPE_LINEAR_LI)
			break;

		/* CV上爬检测: 碳性/碱性/镍氢误判进CV时电压持续爬升→窗口内相对起点
		   上升>CV_NO_PROGRESS_RISE且连续CV_NO_PROGRESS_CNT帧→ERROR, 而非等
		   TIME_CV_HOLD后误判FULL. g_ccBlocks复用为起点锁定标志, g_stableCnt
		   复用为上爬消抖计数. 仅对恒压锂(LI_ION)启用(线性锂无charger IC会自然缓升). */
		if(v < ADC_V_OPEN && ct <= CV_NO_PROGRESS_TICKS && ty == BAT_TYPE_LI_ION)
		{
			if(g_ccBlocks[idx] == 0)
			{
				g_slotRefV[idx] = v;
				g_ccBlocks[idx] = 1;
			}
			else if(v >= g_slotRefV[idx] + CV_NO_PROGRESS_RISE)
			{
				if(++g_stableCnt[idx] >= CV_NO_PROGRESS_CNT)
				{
					g_stableCnt[idx] = 0;
					st = CHG_ERROR;
					ct = 0;
					break;
				}
			}
			else
			{
				g_stableCnt[idx] = 0;
			}
		}

		/* 电池拔出检测: 2帧消抖.
		   仅LI_ION的伪OPEN代表电芯已满→FULL; LINEAR_LI无charger IC,
		   ADC读数可能接近OPEN但仍在真实电压范围, 保持CV继续观察. */
		if(v >= ADC_V_OPEN)
		{
			if(ty == BAT_TYPE_LI_ION)
			{
				g_detectLowCnt[idx]++;
				if(g_detectLowCnt[idx] < 2)
					break;
				g_detectLowCnt[idx] = 0;
				st = CHG_FULL;
				ct = 0;
				break;
			}
			if(ty == BAT_TYPE_LINEAR_LI)
			{
				break;    /* 线性锂CV高压伪OPEN: 保持CV, 由CT超时进FULL. */
			}
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			g_detectLowCnt[idx] = 0;
			ty = BAT_TYPE_UNKNOWN;
			st = CHG_IDLE;
			ct = 0;
			break;
		}

		/* 低压崩溃/跌落重判:
		   - LINEAR_LI: v<CC_LOWV_CRASH_THRESH持续CC_LOWV_CRASH_CNT tick→ERROR
		   - LI_ION: 峰值跌落>PEAK_DROP_THRESH, 2帧→回DETECT重判
		   LINEAR_LI排除跌落判据: 100μs放电不足致v在真实值/伪OPEN间交替. */
		if(ty == BAT_TYPE_LINEAR_LI)
		{
			if(v < CC_LOWV_CRASH_THRESH)
			{
				g_detectLowCnt[idx]++;
				if(g_detectLowCnt[idx] >= CC_LOWV_CRASH_CNT)
				{
					g_detectLowCnt[idx] = 0;
					st = CHG_ERROR;
					ct = 0;
					break;
				}
			}
			else
			{
				g_detectLowCnt[idx] = 0;
			}
		}
		else
		{
			if(v < g_slotRefV[idx] && g_slotRefV[idx] - v > PEAK_DROP_THRESH)
			{
				g_detectLowCnt[idx]++;
				if(g_detectLowCnt[idx] >= 2)
				{
					g_detectLowCnt[idx] = 0;
					g_ccBlocks[idx]++;    /* CV崩溃计数, 累计≥CV_DROP_LOOP_MAX
					                        后DETECT_LI_ROUTE再进CV直接ERROR */
					ty = BAT_TYPE_UNKNOWN;
					st = CHG_DETECT;
					ct = 0;
					break;
				}
			}
			else
			{
				g_detectLowCnt[idx] = 0;
			}
		}

		/* 过压保护: 仅对恒压锂(LI_ION)启用. 线性锂无charger IC,
		   CV阶段电压自然爬升且读数因VCC波动偏高, 过压保护会误杀. */
		if(v >= ADC_V_OVER && ty == BAT_TYPE_LI_ION)
		{
			g_ovCnt[idx]++;
			if(g_ovCnt[idx] >= OV_DEBOUNCE_CNT)
			{
				st = CHG_ERROR;
				break;
			}
		}
		else
		{
			g_ovCnt[idx] = 0;
		}
		break;

	case CHG_FULL:
		/* 电池拔出检测: 连续N帧v≥OPEN退出FULL回IDLE
		   LINEAR_LI(无charger IC)100μs放电不足→伪OPEN(4091)与真实值
		   交替出现, 2帧消抖容易被伪OPEN连续命中→误判拔出→IDLE→DETECT
		   →FULL死循环. 改用50帧(0.5秒)消抖:
		   真拔出时V持续≈VCC, 50帧全部≥OPEN→可靠判定;
		   电池在位时真实V(<OPEN)出现在else→g_detectLowCnt复位→永不误判 */
		if(v >= ADC_V_OPEN)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] >= (ty == BAT_TYPE_LINEAR_LI ? 50 : 2))
			{
				g_detectLowCnt[idx] = 0;
				st = CHG_IDLE;
				ct = 0;
			}
			break;
		}
		/* 仅锂电池可补电: NIMH/DRY/AMBIGUOUS/UNKNOWN在DETECT阶段即被拦截,
		   只有LI_ION/LINEAR_LI能经CC→CV到达FULL
		   电压显著回落(v<2800≈1.45V)说明电池已放电, 满电电容稳定后v≈2900~3500不触发 */
		if(v < CC_NEAR_FULL_THRESH)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			g_detectLowCnt[idx] = 0;
			st = CHG_CC_CHARGE;
			ct = 0;
			g_ovCnt[idx] = 0;
			g_ccBlocks[idx] = 0;   /* 补电新CC周期复位块计数与CC_RETRY_FLAG */
			g_slotRefV[idx] = v;
			g_stableCnt[idx] = 0;      /* 复位CC无进展检测闩锁 */
		}
		else
		{
			g_detectLowCnt[idx] = 0;
		}
		break;

	case CHG_ERROR:
		/* 恢复路径: ADC回OPEN → 电池被拔出 → IDLE, 需连续2帧确认 */
		if(v >= ADC_V_OPEN)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			g_detectLowCnt[idx] = 0;
			ty = BAT_TYPE_UNKNOWN;
			st = CHG_IDLE;
			ct = 0;
			g_ccBlocks[idx] = 0;    /* 电池拔出, 复位CC_RETRY_FLAG */
			break;
		}
		/* NiMH/干电池 重判路径:
		   NiMH物理上无法维持ERROR_NIMH_HIGHV_THRESH以上高压 → 可能是恒压锂
		   charger IC待机误判 → 回DETECT重判. 仅DETECT确认过V>2900稳定
		   (真锂电池)才允许重判; 干电池的电容虚高电压无此标记则直接锁定ERROR. */
		if(ty == BAT_TYPE_NIMH || ty == BAT_TYPE_DRY)
		{
			if(v > ERROR_NIMH_HIGHV_THRESH && (g_highVFlag & ((unsigned int)1 << idx)))
			{
				g_detectLowCnt[idx]++;
				if(g_detectLowCnt[idx] < 2)
					break;
				g_detectLowCnt[idx] = 0;
				st = CHG_DETECT;
				ct = 0;
			}
			else
			{
				g_detectLowCnt[idx] = 0;
			}
			break;
		}
		/* LI_ION/LINEAR_LI/UNKNOWN: 有电压 → 回DETECT重判, 需连续2帧确认 */
		if(v > ADC_V_ACTIVATE)
		{
			g_detectLowCnt[idx]++;
			if(g_detectLowCnt[idx] < 2)
				break;
			g_detectLowCnt[idx] = 0;
			st = CHG_DETECT;
			ct = 0;
		}
		else
		{
			g_detectLowCnt[idx] = 0;
		}
		break;

	default:
		st = CHG_IDLE;
		break;
	}

	SLOT_WR_ALL(idx, st, ty, v, ct);

	/* --- 依据结果控制本槽 MOSFET(受温度/VCC保护门控) --- */
	if((st == CHG_ACTIVATE || st == CHG_PRECHARGE ||
	    st == CHG_CC_CHARGE || st == CHG_CV_CHARGE ||
	    st == CHG_IMP_CHECK || st == CHG_DETECT) &&
	   !g_tempProtect && !g_vccProtect)
	{
		SLOT_CHARGE_ON(idx);
	}
	else
	{
		SLOT_CHARGE_OFF(idx);
	}
}

/*========================================================================
  函数: CCCV_Control
  功能: CC-CV恒流恒压PWM占空比自动调节
  说明: 每轮槽位处理结束后调用一次, 含温度/VCC低压保护
  控制策略:
    CC恒流阶段(ACTIVATE/PRECHARGE/CC_CHARGE):
      - 使用固定占空比(CC_DUTY_TARGET=25/32≈78%)
      - 软启动: 每次+CC_DUTY_RAMP_STEP逐步增加到目标值
      - 无电流检测硬件, 通过固定占空比近似恒流效果
    CV恒压阶段(CV_CHARGE):
      - PI闭环控制, 以ADC_V_FULL为目标电压
      - 根据电压误差动态调节PWM占空比
      - 带积分限幅防饱和
  输出: 更新全局变量 g_pwmDuty (0~PWM_MAX),
        ISR中根据g_pwmDuty自动生成PWM波形
========================================================================*/
void CCCV_Control(void)
{
	unsigned char i;
	unsigned char hasCharging = 0;
	unsigned int  maxV = 0;
	unsigned char cvCount = 0;
	unsigned char ccCount = 0;
	unsigned char preCount = 0;

	/* VCC低压保护滞回: 电源过载VCC跌落→停止充电, 恢复后解除 */
	if(g_vccProtect)
	{
		if(g_vcc_mv >= VCC_UVLO_RESUME)
			g_vccProtect = 0;
	}
	else
	{
		if(g_vcc_mv < VCC_UVLO_STOP)
			g_vccProtect = 1;
	}

	/* 温度/VCC保护: 关闭PWM输出 */
	if(g_tempProtect || g_vccProtect)
	{
		g_pwmDuty = 0;
		g_cvIntegral = 0;
		return;
	}

	/* 遍历12槽位, 找出充电状态和最高电压 */
	for(i = 0; i < BATTERY_SLOTS; i++)
	{
		unsigned char s = S_STATE(i);

		if(s == CHG_ACTIVATE || s == CHG_PRECHARGE ||
		   s == CHG_CC_CHARGE || s == CHG_CV_CHARGE ||
		   s == CHG_IMP_CHECK)
		{
			hasCharging = 1;
			{
				unsigned int vt = S_VOLT(i);
				if(vt > maxV) maxV = vt;
			}
			if(s == CHG_CV_CHARGE)
				cvCount++;
			if(s == CHG_CC_CHARGE)
				ccCount++;
			if(s == CHG_PRECHARGE || s == CHG_ACTIVATE)
				preCount++;
		}
	}

	/* 无充电槽位: 关闭PWM, 复位积分 */
	if(!hasCharging)
	{
		g_pwmDuty = 0;
		g_cvIntegral = 0;
		return;
	}

	/* --- CC/PRECHARGE阶段: 固定占空比 + 软启动 ---
	   CC_CHARGE槽存在时: 使用CC_DUTY_TARGET(25/32=78%)
	   仅ACTIVATE/PRECHARGE时: 使用PRE_DUTY_TARGET(8/32=25%)小电流预充
	   避免78%PWM对高内阻深度过放电池造成充电异常 */
	if(cvCount == 0)
	{
		unsigned char duty_target, duty_initial;

		if(ccCount > 0)
		{
			/* 有CC槽位: 使用标准CC占空比 */
			duty_target  = CC_DUTY_TARGET;
			duty_initial = CC_DUTY_INITIAL;
		}
		else if(preCount > 0)
		{
			/* 仅预充/激活: 使用低占空比小电流激活 */
			duty_target  = PRE_DUTY_TARGET;
			duty_initial = PRE_DUTY_INITIAL;
		}
		else
		{
			/* 仅IMP_CHECK槽位: 78%占空比脉冲, 跳过硬启动
			   碳性电池可能短暂进入CC, PEAK_DROP会在数秒内纠正 */
			g_pwmDuty = CC_DUTY_TARGET;
			return;
		}

		if(g_pwmDuty < duty_initial)
		{
			/* 首次充电: 软启动 */
			g_pwmDuty += CC_DUTY_RAMP_STEP;
			if(g_pwmDuty > duty_initial)
				g_pwmDuty = duty_initial;
		}
		else if(g_pwmDuty > duty_target)
		{
			/* 从高占空比回退: 直接使用目标占空比 */
			g_pwmDuty = duty_target;
		}
		else
		{
			/* 维持目标占空比 */
			g_pwmDuty = duty_target;
		}
		return;
	}

	/* --- CV恒压阶段: PI闭环控制 ---
	   目标: 维持电池电压在ADC_V_FULL(1.52V)
	   error > 0: 电压偏低, 需加大占空比
	   error < 0: 电压偏高, 需减小占空比
	   积分项累加稳态误差, 消除静差 */
	{
		int error = (int)(ADC_V_FULL) - (int)(maxV);

		/* 积分累加(带限幅防积分饱和) */
		g_cvIntegral += error * CV_KI;
		if(g_cvIntegral > CV_KI_LIMIT)
			g_cvIntegral = CV_KI_LIMIT;
		else if(g_cvIntegral < -CV_KI_LIMIT)
			g_cvIntegral = -CV_KI_LIMIT;

		/* PI计算: duty = current_duty + (Kp*error + Ki*integral)/8 */
		int adjust = (error * CV_KP + g_cvIntegral) / 8;
		int duty = (int)g_pwmDuty + adjust;

		/* 占空比限幅 */
		if(duty > PWM_MAX) duty = PWM_MAX;
		if(duty < 0)      duty = 0;

		g_pwmDuty = (unsigned char)duty;
	}
}