/*-------------------------------------------
  L1211 12槽充电器 - LED控制模块 (V2.3原理图适配版)
  功能: 全局双色LED状态显示、红灯闪烁、上电自检序列
  硬件(V2.3原理图 + 实测确认): 12槽LED红/绿管芯各自共用全局网络, 由两个P沟道
  MOSFET总控(低有效: 0=亮):
    PIN_LED_IO2(RC5) → LED_VCC1轨 → 绿灯全局网络
    PIN_LED_IO1(RC4) → LED_VCC2轨 → 红灯全局网络
  显示规则(全局, 优先级从高到低):
    1. 任何槽ERROR        → 红灯闪烁, 绿灯灭
    2. 任何槽真正充电中    → 红灯常亮, 绿灯灭
    3. 仅有槽处于检测链    → 绿轨常亮(复现V58W检测采样环境, 见Update_LED_Global)
    4. 全部已满           → 绿灯常亮
    5. 全部空闲(无电池)    → 全灭
  上电自检: Phase0=全绿1s → Phase1=全红1s → Phase2=正常显示
  注: s_ledBlinkCnt作红灯闪烁节拍(1字节)

  V58O LED缺陷修复:
    ①闪烁时间基准: 原按"主循环轮数"计数, 而TICK_PER_SEC是10ms节拍数(=100),
      实测单轮仅3~6ms → 实际周期≈0.15~0.3s(3~7Hz快闪), 且随轮速漂移
      (UART打印阻塞的0.65s长轮会改变轮速, 关掉UART后频率又变) → 现改为按
      g_elapsedTicks(真实10ms节拍)累加, 与状态机计时同一基准, 与轮速解耦.
    ②空槽误点亮红灯: 空槽轮询也会进DETECT, 原判据把检测态一律算"充电中" →
      12个空槽时几乎总有一个在DETECT → 红灯常亮, 违反"全部空闲→全灭".
      现仅当该槽有电池(S_VOLT < ADC_V_OPEN)时才计为"忙".
    ③上电自检期间主循环不再驱动LED(main.c加 g_powerOnPhase>=2 门控),
      自检与正常显示不再争抢同一对引脚.
  -------------------------------------------*/
  #include "config.h"

  /* 红灯闪烁半周期(10ms节拍数): TICK_PER_SEC/4 = 25节拍 = 0.25s → 周期0.5s(2Hz),
    亮0.25s/灭0.25s. 若要1s周期(亮0.5s/灭0.5s)改为 (TICK_PER_SEC/2).
    ⚠ 单位必须是"10ms节拍", 不是"主循环轮数"(见上方缺陷①) */
  #define LED_BLINK_HALF      (TICK_PER_SEC / 4)

  static unsigned char s_ledBlinkCnt = 0;   /* 红灯闪烁累积节拍数(仅主循环访问) */

  /*========================================================================
   函数: Update_LED_Global
   功能: 全局LED状态显示(每轮调用一次, 统计12槽状态后驱动IO)
   说明: V2.3无单槽独立LED, 12颗绿管芯共LED_VCC1轨(RC5), 12颗红管芯共LED_VCC2轨
         (RC4); 颜色只能整轨开/关(全局色); "某槽亮不亮"由该槽AD脚是否下沉决定
         (ISR显示窗; 检测链与FULL槽不下沉, FULL绿灯靠电池回路点亮, 见pass2).
         本函数只负责: ①按优先级选全局配色并驱动红/绿轨; ②输出
         "该点亮的槽"掩码(g_sinkMask)供ISR在显示窗内按槽下沉点灯.
         该槽自身下沉供流, 不依赖其它槽回流, 故12槽全为恒压锂时也能整排亮.
         自检期间(前2秒)本函数不被调用, 引脚由ISR的PowerOnLedSequence独占

   ⚠ 检测链采样环境约束(这是本函数的硬性设计点, 勿擅改):
     检测判据(DETECT/IMP_CHECK/DIODE_TEST)是在V58W的电气环境下标定的 —— V58W检测
     期间点亮的正是 LED_VCC1 轨(绿轨, RC5): 该轨经LED→5.1k向检测槽AD节点注入电流,
     把镍氢节点抬到≈1991, 于是IMP_CHECK入口的pre≈1815, 落在DIODE_PRE_DRY_MAX(1936)
     之下 → 走完判别链终判DRY/NiMH.
       · 若检测期改点红轨(RC4): 红灯管芯压降更低、注入电流更大 → pre被抬到≈2070,
         越过1936命中"低压锂电预充放行" → 镍氢被误判LINEAR_LI进CC;
       · 若检测期两轨全关: 节点回落到真实电池电压≈956, 低于ADC_V_NIMH_LOW(1015)
         → 被Detect_BatteryType直接判LI_ION进CC.
     因此检测链期间必须与V58W完全一致地"只点绿轨(RC5)、红轨关断、该槽不下沉";
     充电/报错才切到红轨(RC4)显示正确颜色. 其余逻辑(采样/判据/阈值)一律不动.
  ========================================================================*/
  void Update_LED_Global(void)
  {
  unsigned char i;
  unsigned char hasErr = 0;
  unsigned char hasChg = 0;
  unsigned char hasDet = 0;
  unsigned char hasFull = 0;
  unsigned int  mask = 0;

  /* pass1: 优先级判定(错误 > 充电中 > 检测链 > 全满 > 空闲) */
  for(i = 0; i < BATTERY_SLOTS; i++)
  {
  unsigned char s = S_STATE(i);
  if(s == CHG_ERROR)
  {
  hasErr = 1;
  }
  else if(s == CHG_ACTIVATE || s == CHG_PRECHARGE ||
          s == CHG_CC_CHARGE || s == CHG_CV_CHARGE)
  {
  /* 只有"确实有电池且处于充电态"的槽才算忙: 空槽也会走 IDLE→DETECT→
  IMP_CHECK→IDLE 轮询(空槽读数≈VCC_norm≥OPEN), 若把空槽检测态也算"充电中",
  12个空槽时几乎总有一个在DETECT → 红灯常亮, 违反"全部空闲→全灭". */
  if(S_VOLT(i) < ADC_V_OPEN)
  hasChg = 1;      /* 真正充电态: ACTIVATE/PRECHARGE/CC/CV */
  }
  else if(s == CHG_DETECT || s == CHG_IMP_CHECK || s == CHG_IMP_DIODE_TEST)
  {
  if(S_VOLT(i) < ADC_V_OPEN)
  hasDet = 1;      /* 检测链(有电池): 采样电气环境须复现V58W, 见上方说明 */
  }
  else if(s == CHG_FULL)
  {
  hasFull = 1;
  }
  }

  /* pass2: 生成下沉掩码(仅"该显示"的槽才下沉点灯)
     ⚠ 检测链(DETECT/IMP_CHECK/DIODE_TEST)的槽一律不下沉: V58W检测期间无下沉,
     下沉会周期拉低检测槽AD脚、压低采样读数. 故 hasDet 路径下 mask 恒为0. */
  if(hasErr)
  {
  for(i = 0; i < BATTERY_SLOTS; i++)
  {
  unsigned char s = S_STATE(i);
  if(s == CHG_ERROR || s == CHG_CC_CHARGE || s == CHG_CV_CHARGE)
  mask |= (unsigned int)1 << i;   /* 错误态: 错误槽 + CC/CV槽一起显示 */
  }
  }
  else if(hasChg)
  {
  for(i = 0; i < BATTERY_SLOTS; i++)
  {
  unsigned char s = S_STATE(i);
  if((s == CHG_CC_CHARGE || s == CHG_CV_CHARGE) && S_VOLT(i) < ADC_V_OPEN)
  mask |= (unsigned int)1 << i;   /* 充电中: 仅有电池且处于CC/CV的槽 */
  }
  }
  /* hasDet / hasFull / 空闲: mask=0, 不开显示窗, 不下沉任何槽(与V58W一致).
     ⚠ FULL槽同样不下沉: 复现V58W的FULL采样环境. FULL时该槽MOSFET常关, 线性锂
     内部单向路径不回灌, 节点只剩弱上拉支撑; 若每帧下沉(每轮约12次窗口), 节点
     稳态被拉到~2732(<2800) → 误触发FULL→CC补电(红↔绿振荡; 实测1ms/10ms采样前
     延时均无效, 因该回稳时间常数达百ms量级). 不下沉则节点被电芯钳在~2937>2800,
     与V58W一致. 绿灯轨RC5仍由pass3常开, FULL槽绿灯走电池回路点亮. */

  /* pass3: 驱动全局色轨(低有效) + 原子输出掩码给ISR
     g_sinkMask 是 16bit, 非原子写; ISR 读它时若恰好在主循环写的中间会读到撕裂值.
     用 T0IE(INTCON bit5) 关 Timer0 中断(只有它会读 g_sinkMask)后再写, 避免竞态. */
  {
  unsigned char sT0IE = INTCON & 0x20U;   /* 保存 T0IE */
  INTCON &= ~0x20U;                        /* 关 Timer0 中断 */
  if(hasErr)
  {
  /* 优先级1: 错误 → 红灯闪烁(按真实10ms节拍g_elapsedTicks累加), 绿灯灭 */
  s_ledBlinkCnt = (unsigned char)(s_ledBlinkCnt + g_elapsedTicks);
  if(s_ledBlinkCnt >= LED_BLINK_HALF)
  s_ledBlinkCnt = 0;
  if(s_ledBlinkCnt < (LED_BLINK_HALF / 2))
  {
  PIN_LED_IO1 = 0;  PIN_LED_IO2 = 1;   /* 红轨亮: 错误+CC/CV槽一起闪红 */
  g_sinkMask = mask;
  }
  else
  {
  PIN_LED_IO1 = 1;  PIN_LED_IO2 = 1;   /* 全灭(闪烁的暗半周) */
  g_sinkMask = 0;
  }
  }
  else if(hasChg)
  {
  /* 优先级2: 有槽真正充电 → 红轨常亮, 仅CC/CV槽下沉点亮 */
  s_ledBlinkCnt = 0;
  PIN_LED_IO1 = 0;  PIN_LED_IO2 = 1;
  g_sinkMask = mask;
  }
  else if(hasDet)
  {
  /* 优先级3: 仅检测链 → 复现V58W检测采样环境: 只点绿轨(RC5), 红轨关断, 不下沉.
     详见函数头"检测链采样环境约束": 点亮绿轨才能使镍氢pre≈1815落在判别链窗口内. */
  s_ledBlinkCnt = 0;
  PIN_LED_IO1 = 1;  PIN_LED_IO2 = 0;
  g_sinkMask = 0;
  }
  else if(hasFull)
  {
  /* 优先级4: 全部已满(无错误/无充电中) → 绿轨常亮. FULL槽不下沉(mask=0,
     复现V58W采样环境, 见pass2说明), 绿灯靠电池回路点亮 */
  s_ledBlinkCnt = 0;
  PIN_LED_IO1 = 1;  PIN_LED_IO2 = 0;
  g_sinkMask = mask;
  }
  else
  {
  /* 优先级5: 全部空闲 → 全灭(两轨关断, 掩码清空, 无任何槽下沉) */
  s_ledBlinkCnt = 0;
  PIN_LED_IO1 = 1;  PIN_LED_IO2 = 1;
  g_sinkMask = 0;
  }
  INTCON |= sT0IE;                         /* 恢复 Timer0 中断 */
  }
  }

/*========================================================================
  函数: PowerOnLedSequence
  功能: 上电LED自检序列(ISR中g_powerOnPhase<2时每125us调用一次)
  流程: Phase0 = 仅绿1s → Phase1 = 仅红1s → Phase2 = 正常显示
  可见性(原理图+实测确认): 空板同样可见, 无需插电池.
    灯回路: LED_VCCx(Q11/Q8低有效导通, 源=VCC) → 管芯 → R11(5.1k) → 槽节点Bn
            → 该槽采样分压的下臂(≈10K) → GND
    · 空板: 回流走分压下臂 ⇒ I ≈ (5.1-1.9)/(5.1k+10k) ≈ 210µA ⇒ 可见
    · 有电池: 回流走"电池+0.2R"(阻抗低得多) ⇒ 更亮
    ⚠ 硬性约束: 该槽MOSFET(AO3401, P沟道, 源=VCC)一旦导通, 会把Bn抬到VCC,
      LED两端压差≈0 ⇒ 该槽灯立即熄灭. 因此自检相位0/1期间必须保持12槽MOSFET
      全关(System_Init已把12个栅极置High=关). 切勿为"增亮"而打开槽MOSFET.
    ⚠ 推论: 正在充电/检测(其MOSFET为导通态)的槽, 自身那颗灯不亮; 且12槽灯是
      "全局色"(12颗红管芯共LED_VCC1/2), 并非逐槽独立显示.
  注: 低有效, 0=亮
  ⚠ 相位总数必须与 main.c 三处门限(g_powerOnPhase < 2U / >= 2U)一致,
     否则 Update_LED_Global 会因相位到不了2而永不执行(LED被冻结).
========================================================================*/
void PowerOnLedSequence(void)
{
	/* g_powerOnTimer已由ISR按10ms显式节拍递增, 此处不再自增 */

	if(g_powerOnPhase == 0)
	{
		/* Phase 0: 仅绿1秒: 点亮 LED_VCC1轨(RC5=绿灯) */
		PIN_LED_IO1 = 1;    /* 红灯灭 */
		PIN_LED_IO2 = 0;    /* 绿灯亮 */
		if(g_powerOnTimer >= TICK_PER_SEC)   /* 1秒(规格) */
		{
			g_powerOnTimer = 0;
			g_powerOnPhase = 1;
		}
	}
	else if(g_powerOnPhase == 1)
	{
		/* Phase 1: 仅红1秒: 点亮 LED_VCC2轨(RC4=红灯) */
		PIN_LED_IO1 = 0;    /* 红灯亮 */
		PIN_LED_IO2 = 1;    /* 绿灯灭 */
		if(g_powerOnTimer >= TICK_PER_SEC)
		{
			g_powerOnTimer = 0;
			g_powerOnPhase = 2;         /* 自检完成, 进入正常显示(空盘→全灭) */
		}
	}
	/* Phase 2: 由Update_LED_Global按槽状态驱动 */
}
