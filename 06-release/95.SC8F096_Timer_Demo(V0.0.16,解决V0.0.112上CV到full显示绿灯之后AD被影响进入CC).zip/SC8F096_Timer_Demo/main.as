opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_CCCV_Control
	FNCALL	_main,_Display_Service
	FNCALL	_main,_Get_Vcc
	FNCALL	_main,_Print_NtcTemp
	FNCALL	_main,_Print_SystemStatus
	FNCALL	_main,_Read_Temperature
	FNCALL	_main,_Sense_Pins_AsSink
	FNCALL	_main,_Sense_Pins_Restore
	FNCALL	_main,_Slot_Charge_Ctrl
	FNCALL	_main,_System_Init
	FNCALL	_main,_Update_LED_Global
	FNCALL	_main,_Wait_Display_Idle
	FNCALL	_main,_uart_send_string
	FNCALL	_Update_LED_Global,___bmul
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_System_Init,_uart_init
	FNCALL	_Slot_Charge_Ctrl,_Adc_Norm
	FNCALL	_Slot_Charge_Ctrl,_Detect_BatteryType
	FNCALL	_Slot_Charge_Ctrl,_Detect_Classify
	FNCALL	_Slot_Charge_Ctrl,_Enter_DiodeTest
	FNCALL	_Slot_Charge_Ctrl,_Get_Vcc
	FNCALL	_Slot_Charge_Ctrl,_Route_LiIon
	FNCALL	_Slot_Charge_Ctrl,_Route_LinearLi
	FNCALL	_Slot_Charge_Ctrl,___bmul
	FNCALL	_Slot_Charge_Ctrl,___lldiv
	FNCALL	_Slot_Charge_Ctrl,___wmul
	FNCALL	_Route_LinearLi,_Route_DetectLi
	FNCALL	_Route_LiIon,_Route_DetectLi
	FNCALL	_Detect_Classify,_Get_Vcc
	FNCALL	_Detect_Classify,_Route_DetectLi
	FNCALL	_Detect_Classify,___lwdiv
	FNCALL	_Route_DetectLi,___lldiv
	FNCALL	_Route_DetectLi,___lmul
	FNCALL	_Get_Vcc,_ADC_Sample
	FNCALL	_Get_Vcc,___lldiv
	FNCALL	_Adc_Norm,_ADC_Sample
	FNCALL	_Adc_Norm,___lldiv
	FNCALL	_Adc_Norm,___lmul
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_Print_SystemStatus,_ADC_Sample
	FNCALL	_Print_SystemStatus,___bmul
	FNCALL	_Print_SystemStatus,___lldiv
	FNCALL	_Print_SystemStatus,___lmul
	FNCALL	_Print_SystemStatus,___lwdiv
	FNCALL	_Print_SystemStatus,___lwmod
	FNCALL	_Print_SystemStatus,_uart_send_char
	FNCALL	_Print_SystemStatus,_uart_send_number
	FNCALL	_Print_SystemStatus,_uart_send_string
	FNCALL	_Print_NtcTemp,___lwdiv
	FNCALL	_Print_NtcTemp,___lwmod
	FNCALL	_Print_NtcTemp,_uart_send_number
	FNCALL	_Print_NtcTemp,_uart_send_string
	FNCALL	_uart_send_string,_uart_send_char
	FNCALL	_uart_send_number,___lwdiv
	FNCALL	_uart_send_number,___lwmod
	FNCALL	_uart_send_number,_uart_send_char
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,___bmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Sink_Set
	FNCALL	_Sink_Set,_Sink_Slot_Off
	FNCALL	_Sink_Set,_Sink_Slot_On
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_vcc_mv
	global	_g_elapsedTicks
	global	_g_temperature
	global	_g_detectWaiter
	global	_g_detectOwner
psect	idataCOMMON,class=CODE,space=0,delta=2,noexec
global __pidataCOMMON
__pidataCOMMON:
	file	"main.c"
	line	15

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	line	29

;initializer for _g_elapsedTicks
	retlw	01h
	retlw	0

	file	"charge_mgr.c"
	line	21

;initializer for _g_temperature
	retlw	0FAh
	retlw	0

	line	35

;initializer for _g_detectWaiter
	retlw	0FFh
	line	29

;initializer for _g_detectOwner
	retlw	0FFh
	global	_s_adcChannels
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"main.c"
	line	50
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_impData
	global	_g_pwmDuty
	global	_s_senseRestored
	global	_g_printFlag
	global	_g_doNtcRead
	global	_g_adcBusy
	global	_g_dispWin
	global	_g_stableCnt
	global	_g_detectLowCnt
	global	_s_work
	global	_g_diodeTrace
	global	_g_highVFlag
	global	_g_capFlag
	global	_g_printTick
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_sinkMask
	global	_g_lastHwTick
	global	_g_hwTick
	global	_g_powerOnTimer
	global	_g_cvIntegral
	global	_s_ledBlinkCnt
	global	_g_vccProtect
	global	_g_tempProtect
	global	_g_tempPhase
	global	_g_hwTickDiv
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_g_diodeTraceSlot
	global	_g_diodeTraceCnt
	global	_test_adc
	global	_adresult
	global	_g_slot
	global	_g_slotRefV
	global	_g_ovCnt
	global	_g_ccBlocks
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_GIE
_GIE	set	0x5F
	global	_RB5
_RB5	set	0x35
	global	_RB4
_RB4	set	0x34
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA6
_RA6	set	0x436
	global	_RA7
_RA7	set	0x437
	global	_RA4
_RA4	set	0x434
	global	_RA5
_RA5	set	0x435
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RD0
_RD0	set	0x838
	global	_RD1
_RD1	set	0x839
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD5
_RD5	set	0x83D
	global	_RD4
_RD4	set	0x83C
	global	_RC0
_RC0	set	0x830
	global	_RC1
_RC1	set	0x831
	global	_RC5
_RC5	set	0x835
	global	_RC4
_RC4	set	0x834
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
	
STR_4:	
	retlw	13
	retlw	10
	retlw	61	;'='
	retlw	61	;'='
	retlw	32	;' '
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	72	;'H'
	retlw	65	;'A'
	retlw	82	;'R'
	retlw	71	;'G'
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	32	;' '
	retlw	0
psect	stringtext
	
STR_37:	
	retlw	76	;'L'
	retlw	49	;'1'
	retlw	50	;'2'
	retlw	49	;'1'
	retlw	49	;'1'
	retlw	32	;' '
	retlw	67	;'C'
	retlw	104	;'h'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	103	;'g'
	retlw	101	;'e'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	86	;'V'
	retlw	50	;'2'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_25:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	110	;'n'
	retlw	101	;'e'
	retlw	97	;'a'
	retlw	114	;'r'
	retlw	32	;' '
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_23:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	114	;'r'
	retlw	121	;'y'
	retlw	47	;'/'
	retlw	78	;'N'
	retlw	105	;'i'
	retlw	77	;'M'
	retlw	72	;'H'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_24:	
	retlw	91	;'['
	retlw	76	;'L'
	retlw	105	;'i'
	retlw	45	;'-'
	retlw	105	;'i'
	retlw	111	;'o'
	retlw	110	;'n'
	retlw	32	;' '
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_38:	
	retlw	73	;'I'
	retlw	110	;'n'
	retlw	105	;'i'
	retlw	116	;'t'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	46	;'.'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_10:	
	retlw	67	;'C'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	79	;'O'
	retlw	75	;'K'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_5:	
	retlw	86	;'V'
	retlw	48	;'0'
	retlw	46	;'.'
	retlw	48	;'0'
	retlw	46	;'.'
	retlw	49	;'1'
	retlw	54	;'6'
	retlw	0
psect	stringtext
	
STR_15:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	68	;'D'
	retlw	76	;'L'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_22:	
	retlw	91	;'['
	retlw	70	;'F'
	retlw	85	;'U'
	retlw	76	;'L'
	retlw	76	;'L'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_6:	
	retlw	32	;' '
	retlw	61	;'='
	retlw	61	;'='
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_13:	
	retlw	32	;' '
	retlw	66	;'B'
	retlw	65	;'A'
	retlw	84	;'T'
	retlw	40	;'('
	retlw	0
psect	stringtext
	
STR_8:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	32	;' '
	retlw	84	;'T'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_30:	
	retlw	32	;' '
	retlw	112	;'p'
	retlw	114	;'r'
	retlw	101	;'e'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_17:	
	retlw	32	;' '
	retlw	114	;'r'
	retlw	101	;'e'
	retlw	102	;'f'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_12:	
	retlw	32	;' '
	retlw	79	;'O'
	retlw	80	;'P'
	retlw	69	;'E'
	retlw	78	;'N'
	retlw	0
psect	stringtext
	
STR_31:	
	retlw	91	;'['
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	63	;'?'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_19:	
	retlw	91	;'['
	retlw	80	;'P'
	retlw	82	;'R'
	retlw	69	;'E'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_29:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	73	;'I'
	retlw	79	;'O'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_28:	
	retlw	91	;'['
	retlw	73	;'I'
	retlw	77	;'M'
	retlw	80	;'P'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_26:	
	retlw	91	;'['
	retlw	69	;'E'
	retlw	82	;'R'
	retlw	82	;'R'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_18:	
	retlw	91	;'['
	retlw	65	;'A'
	retlw	67	;'C'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_16:	
	retlw	91	;'['
	retlw	68	;'D'
	retlw	69	;'E'
	retlw	84	;'T'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_7:	
	retlw	86	;'V'
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_1:	
	retlw	78	;'N'
	retlw	84	;'T'
	retlw	67	;'C'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_34:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	114	;'r'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_32:	
	retlw	32	;' '
	retlw	99	;'c'
	retlw	116	;'t'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_33:	
	retlw	32	;' '
	retlw	116	;'t'
	retlw	121	;'y'
	retlw	61	;'='
	retlw	0
psect	stringtext
	
STR_20:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	67	;'C'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_21:	
	retlw	91	;'['
	retlw	67	;'C'
	retlw	86	;'V'
	retlw	93	;']'
	retlw	0
psect	stringtext
	
STR_3:	
	retlw	67	;'C'
	retlw	13
	retlw	10
	retlw	0
psect	stringtext
	
STR_14:	
	retlw	109	;'m'
	retlw	86	;'V'
	retlw	41	;')'
	retlw	0
psect	stringtext
	
STR_2:	
	retlw	46	;'.'
	retlw	0
psect	stringtext
STR_27	equ	STR_17+0
STR_9	equ	STR_2+0
STR_11	equ	STR_38+7
STR_35	equ	STR_38+7
STR_36	equ	STR_38+7
; #config settings
	file	"main.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_s_senseRestored:
       ds      1

_g_printFlag:
       ds      1

_g_doNtcRead:
       ds      1

_g_adcBusy:
       ds      1

_g_dispWin:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_g_impData:
       ds      2

_g_pwmDuty:
       ds      1

psect	dataCOMMON,class=COMMON,space=1,noexec
global __pdataCOMMON
__pdataCOMMON:
	file	"main.c"
	line	15
_g_vcc_mv:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_stableCnt:
       ds      12

_g_detectLowCnt:
       ds      12

_s_work:
       ds      6

_g_diodeTrace:
       ds      4

_g_highVFlag:
       ds      2

_g_capFlag:
       ds      2

_g_printTick:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_sinkMask:
       ds      2

_g_lastHwTick:
       ds      2

_g_hwTick:
       ds      2

_g_powerOnTimer:
       ds      2

_g_cvIntegral:
       ds      2

_s_ledBlinkCnt:
       ds      1

_g_vccProtect:
       ds      1

_g_tempProtect:
       ds      1

_g_tempPhase:
       ds      1

_g_hwTickDiv:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_g_diodeTraceSlot:
       ds      1

_g_diodeTraceCnt:
       ds      1

_test_adc:
       ds      1

_adresult:
       ds      2

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"main.c"
	line	29
_g_elapsedTicks:
       ds      2

psect	dataBANK1
	file	"charge_mgr.c"
	line	21
_g_temperature:
       ds      2

psect	dataBANK1
	file	"charge_mgr.c"
	line	35
_g_detectWaiter:
       ds      1

psect	dataBANK1
	file	"charge_mgr.c"
	line	29
_g_detectOwner:
       ds      1

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_slotRefV:
       ds      24

_g_ovCnt:
       ds      12

_g_ccBlocks:
       ds      12

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"main.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
	fcall	__pidataBANK1+2		;fetch initializer
	movwf	__pdataBANK1+2&07fh		
	fcall	__pidataBANK1+3		;fetch initializer
	movwf	__pdataBANK1+3&07fh		
	fcall	__pidataBANK1+4		;fetch initializer
	movwf	__pdataBANK1+4&07fh		
	fcall	__pidataBANK1+5		;fetch initializer
	movwf	__pdataBANK1+5&07fh		
; Initialize objects allocated to COMMON
	global __pidataCOMMON
psect cinit,class=CODE,delta=2,merge=1
	fcall	__pidataCOMMON+0		;fetch initializer
	movwf	__pdataCOMMON+0&07fh		
	fcall	__pidataCOMMON+1		;fetch initializer
	movwf	__pdataCOMMON+1&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+030h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+042h)
	fcall	clear_ram0
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
	clrf	((__pbssCOMMON)+1)&07Fh
	clrf	((__pbssCOMMON)+2)&07Fh
; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
??_main:	; 1 bytes @ 0x0
	ds	2
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_uart_init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_uart_send_char:	; 1 bytes @ 0x0
?_Slot_Charge_Ctrl:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Update_LED_Global:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Sink_Slot_On:	; 1 bytes @ 0x0
??_Sink_Slot_On:	; 1 bytes @ 0x0
?_Sink_Slot_Off:	; 1 bytes @ 0x0
??_Sink_Slot_Off:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Print_NtcTemp:	; 1 bytes @ 0x0
?_Print_SystemStatus:	; 1 bytes @ 0x0
?_Sense_Pins_AsSink:	; 1 bytes @ 0x0
?_Sense_Pins_Restore:	; 1 bytes @ 0x0
?_Wait_Display_Idle:	; 1 bytes @ 0x0
?_Display_Service:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?_Route_LiIon:	; 1 bytes @ 0x0
?_Enter_DiodeTest:	; 1 bytes @ 0x0
?_Get_Vcc:	; 2 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	global	Sink_Slot_On@idx
Sink_Slot_On@idx:	; 1 bytes @ 0x0
	global	Sink_Slot_Off@idx
Sink_Slot_Off@idx:	; 1 bytes @ 0x0
	ds	1
?_Sink_Set:	; 1 bytes @ 0x1
	global	Sink_Set@mask
Sink_Set@mask:	; 2 bytes @ 0x1
	ds	2
	global	Sink_Set@on
Sink_Set@on:	; 1 bytes @ 0x3
	ds	1
??_Sink_Set:	; 1 bytes @ 0x4
	global	Sink_Set@i
Sink_Set@i:	; 1 bytes @ 0x4
	ds	1
??_Isr_Timer:	; 1 bytes @ 0x5
	ds	3
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
??_AD_Init:	; 1 bytes @ 0x0
??_uart_init:	; 1 bytes @ 0x0
?_ADC_Sample:	; 1 bytes @ 0x0
??_uart_send_char:	; 1 bytes @ 0x0
??_Sense_Pins_AsSink:	; 1 bytes @ 0x0
??_Sense_Pins_Restore:	; 1 bytes @ 0x0
??_Wait_Display_Idle:	; 1 bytes @ 0x0
??_Display_Service:	; 1 bytes @ 0x0
?_Detect_BatteryType:	; 1 bytes @ 0x0
??_Enter_DiodeTest:	; 1 bytes @ 0x0
?___bmul:	; 1 bytes @ 0x0
	global	?___wmul
?___wmul:	; 2 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x0
	global	?___lwmod
?___lwmod:	; 2 bytes @ 0x0
	global	?___lmul
?___lmul:	; 4 bytes @ 0x0
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x0
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x0
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x0
	global	___wmul@multiplier
___wmul@multiplier:	; 2 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x0
	global	___lwmod@divisor
___lwmod@divisor:	; 2 bytes @ 0x0
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x0
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x1
??___bmul:	; 1 bytes @ 0x1
	global	uart_send_char@c
uart_send_char@c:	; 1 bytes @ 0x1
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x1
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x2
	global	uart_send_char@i
uart_send_char@i:	; 1 bytes @ 0x2
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x2
	global	___wmul@multiplicand
___wmul@multiplicand:	; 2 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x2
	global	___lwmod@dividend
___lwmod@dividend:	; 2 bytes @ 0x2
	ds	1
?_uart_send_string:	; 1 bytes @ 0x3
??_Update_LED_Global:	; 1 bytes @ 0x3
??_System_Init:	; 1 bytes @ 0x3
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x3
	global	Enter_DiodeTest@idx
Enter_DiodeTest@idx:	; 1 bytes @ 0x3
	global	uart_send_string@str
uart_send_string@str:	; 2 bytes @ 0x3
	ds	1
??___wmul:	; 1 bytes @ 0x4
??___awdiv:	; 1 bytes @ 0x4
??___lwdiv:	; 1 bytes @ 0x4
??___lwmod:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x4
	global	___lwmod@counter
___lwmod@counter:	; 1 bytes @ 0x4
	global	___wmul@product
___wmul@product:	; 2 bytes @ 0x4
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x4
	ds	1
??_uart_send_string:	; 1 bytes @ 0x5
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x5
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x6
	global	Update_LED_Global@hasDet
Update_LED_Global@hasDet:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	1
?_uart_send_number:	; 1 bytes @ 0x7
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x7
	global	Update_LED_Global@hasFull
Update_LED_Global@hasFull:	; 1 bytes @ 0x7
	global	uart_send_number@num
uart_send_number@num:	; 2 bytes @ 0x7
	ds	1
??_CCCV_Control:	; 1 bytes @ 0x8
??___lmul:	; 1 bytes @ 0x8
	global	Update_LED_Global@sT0IE
Update_LED_Global@sT0IE:	; 1 bytes @ 0x8
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x8
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x8
	ds	1
??_uart_send_number:	; 1 bytes @ 0x9
	global	Update_LED_Global@s_466
Update_LED_Global@s_466:	; 1 bytes @ 0x9
	global	uart_send_number@buf
uart_send_number@buf:	; 6 bytes @ 0x9
	ds	1
	global	Update_LED_Global@hasErr
Update_LED_Global@hasErr:	; 1 bytes @ 0xA
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0xA
	ds	1
	global	Update_LED_Global@hasChg
Update_LED_Global@hasChg:	; 1 bytes @ 0xB
	ds	1
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0xC
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0xC
	global	Update_LED_Global@s_465
Update_LED_Global@s_465:	; 1 bytes @ 0xC
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0xC
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0xC
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0xD
	global	Update_LED_Global@mask
Update_LED_Global@mask:	; 2 bytes @ 0xD
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0xE
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0xE
	ds	1
	global	uart_send_number@i
uart_send_number@i:	; 1 bytes @ 0xF
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0xF
	global	Update_LED_Global@s
Update_LED_Global@s:	; 1 bytes @ 0xF
	ds	1
	global	uart_send_number@j
uart_send_number@j:	; 1 bytes @ 0x10
	global	Update_LED_Global@i
Update_LED_Global@i:	; 1 bytes @ 0x10
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0x10
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x10
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x10
	ds	1
??_Print_NtcTemp:	; 1 bytes @ 0x11
	global	_Print_NtcTemp$790
_Print_NtcTemp$790:	; 2 bytes @ 0x11
	ds	1
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x12
	ds	1
	global	_Print_NtcTemp$791
_Print_NtcTemp$791:	; 2 bytes @ 0x13
	ds	1
??___lldiv:	; 1 bytes @ 0x14
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0x14
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x14
	ds	2
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0x16
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0x17
	ds	1
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x18
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0x18
	ds	1
??_Get_Vcc:	; 1 bytes @ 0x19
??_Read_Temperature:	; 1 bytes @ 0x19
??_Print_SystemStatus:	; 1 bytes @ 0x19
?_Route_DetectLi:	; 1 bytes @ 0x19
	global	?_Adc_Norm
?_Adc_Norm:	; 2 bytes @ 0x19
	global	Route_DetectLi@slot_v
Route_DetectLi@slot_v:	; 2 bytes @ 0x19
	global	Get_Vcc@pt
Get_Vcc@pt:	; 4 bytes @ 0x19
	ds	1
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x1A
	ds	1
??_Route_DetectLi:	; 1 bytes @ 0x1B
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x1B
	ds	1
??_Adc_Norm:	; 1 bytes @ 0x1C
	global	Adc_Norm@ch
Adc_Norm@ch:	; 1 bytes @ 0x1C
	ds	1
	global	Adc_Norm@raw
Adc_Norm@raw:	; 2 bytes @ 0x1D
	global	_Print_SystemStatus$792
_Print_SystemStatus$792:	; 2 bytes @ 0x1D
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x1D
	ds	2
	global	Route_DetectLi@bat_mv
Route_DetectLi@bat_mv:	; 2 bytes @ 0x1F
	global	_Print_SystemStatus$793
_Print_SystemStatus$793:	; 2 bytes @ 0x1F
	ds	2
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x21
	global	Print_SystemStatus@pt
Print_SystemStatus@pt:	; 4 bytes @ 0x21
	global	Route_DetectLi@vx_mv
Route_DetectLi@vx_mv:	; 4 bytes @ 0x21
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x23
	ds	2
	global	Print_SystemStatus@s
Print_SystemStatus@s:	; 1 bytes @ 0x25
	global	Route_DetectLi@bat_mv_long
Route_DetectLi@bat_mv_long:	; 4 bytes @ 0x25
	ds	1
	global	_Print_SystemStatus$293
_Print_SystemStatus$293:	; 2 bytes @ 0x26
	ds	2
	global	Print_SystemStatus@v
Print_SystemStatus@v:	; 2 bytes @ 0x28
	ds	1
	global	Route_DetectLi@st
Route_DetectLi@st:	; 1 bytes @ 0x29
	ds	1
	global	Route_DetectLi@idx
Route_DetectLi@idx:	; 1 bytes @ 0x2A
	global	Print_SystemStatus@vx_mv
Print_SystemStatus@vx_mv:	; 4 bytes @ 0x2A
	ds	1
??_Route_LiIon:	; 1 bytes @ 0x2B
?_Route_LinearLi:	; 1 bytes @ 0x2B
?_Detect_Classify:	; 1 bytes @ 0x2B
	global	Detect_Classify@fromHighV
Detect_Classify@fromHighV:	; 1 bytes @ 0x2B
	global	Route_LinearLi@pre
Route_LinearLi@pre:	; 2 bytes @ 0x2B
	ds	1
??_Detect_Classify:	; 1 bytes @ 0x2C
	ds	1
??_Route_LinearLi:	; 1 bytes @ 0x2D
	ds	1
	global	Route_LiIon@idx
Route_LiIon@idx:	; 1 bytes @ 0x2E
	global	Print_SystemStatus@vcc_mv
Print_SystemStatus@vcc_mv:	; 2 bytes @ 0x2E
	ds	1
	global	Detect_Classify@idx
Detect_Classify@idx:	; 1 bytes @ 0x2F
	ds	1
	global	Route_LinearLi@idx
Route_LinearLi@idx:	; 1 bytes @ 0x30
	global	Print_SystemStatus@bat_mv_long
Print_SystemStatus@bat_mv_long:	; 4 bytes @ 0x30
	ds	1
??_Slot_Charge_Ctrl:	; 1 bytes @ 0x31
	ds	3
	global	Print_SystemStatus@tc
Print_SystemStatus@tc:	; 1 bytes @ 0x34
	ds	1
	global	Print_SystemStatus@t
Print_SystemStatus@t:	; 1 bytes @ 0x35
	ds	1
	global	Print_SystemStatus@d
Print_SystemStatus@d:	; 2 bytes @ 0x36
	global	Slot_Charge_Ctrl@v_init
Slot_Charge_Ctrl@v_init:	; 2 bytes @ 0x36
	ds	2
	global	Print_SystemStatus@i
Print_SystemStatus@i:	; 1 bytes @ 0x38
	global	Slot_Charge_Ctrl@vcc_norm_pre
Slot_Charge_Ctrl@vcc_norm_pre:	; 2 bytes @ 0x38
	ds	2
	global	Slot_Charge_Ctrl@vcc_norm_now
Slot_Charge_Ctrl@vcc_norm_now:	; 2 bytes @ 0x3A
	ds	2
	global	Slot_Charge_Ctrl@ptTick
Slot_Charge_Ctrl@ptTick:	; 2 bytes @ 0x3C
	ds	2
	global	Slot_Charge_Ctrl@vcc_norm
Slot_Charge_Ctrl@vcc_norm:	; 2 bytes @ 0x3E
	ds	2
	global	Slot_Charge_Ctrl@pt
Slot_Charge_Ctrl@pt:	; 1 bytes @ 0x40
	ds	1
	global	_Slot_Charge_Ctrl$441
_Slot_Charge_Ctrl$441:	; 2 bytes @ 0x41
	ds	2
	global	Slot_Charge_Ctrl@charge_ticks_prev
Slot_Charge_Ctrl@charge_ticks_prev:	; 2 bytes @ 0x43
	ds	2
	global	Slot_Charge_Ctrl@newv
Slot_Charge_Ctrl@newv:	; 2 bytes @ 0x45
	ds	2
	global	Slot_Charge_Ctrl@v_ref
Slot_Charge_Ctrl@v_ref:	; 2 bytes @ 0x47
	ds	2
	global	Slot_Charge_Ctrl@dly
Slot_Charge_Ctrl@dly:	; 1 bytes @ 0x49
	ds	1
	global	Slot_Charge_Ctrl@diff
Slot_Charge_Ctrl@diff:	; 2 bytes @ 0x4A
	ds	2
	global	Slot_Charge_Ctrl@pre
Slot_Charge_Ctrl@pre:	; 2 bytes @ 0x4C
	ds	2
	global	Slot_Charge_Ctrl@idx
Slot_Charge_Ctrl@idx:	; 1 bytes @ 0x4E
	ds	1
	global	main@i
main@i:	; 1 bytes @ 0x4F
	ds	1
;!
;!Data Sizes:
;!    Strings     254
;!    Constant    12
;!    Data        8
;!    BSS         189
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14      8      14
;!    BANK0            80     80      80
;!    BANK1            80      2      74
;!    BANK3            80      0      48
;!    BANK2            80      0      72

;!
;!Pointer List with Targets:
;!
;!    uart_send_string@str	PTR const unsigned char  size(2) Largest target is 25
;!		 -> STR_38(CODE[10]), STR_37(CODE[21]), STR_36(CODE[3]), STR_35(CODE[3]), 
;!		 -> STR_34(CODE[5]), STR_33(CODE[5]), STR_32(CODE[5]), STR_31(CODE[6]), 
;!		 -> STR_30(CODE[6]), STR_29(CODE[6]), STR_28(CODE[6]), STR_27(CODE[6]), 
;!		 -> STR_26(CODE[6]), STR_25(CODE[16]), STR_24(CODE[13]), STR_23(CODE[15]), 
;!		 -> STR_22(CODE[7]), STR_21(CODE[5]), STR_20(CODE[5]), STR_19(CODE[6]), 
;!		 -> STR_18(CODE[6]), STR_17(CODE[6]), STR_16(CODE[6]), STR_15(CODE[7]), 
;!		 -> STR_14(CODE[4]), STR_13(CODE[6]), STR_12(CODE[6]), STR_11(CODE[3]), 
;!		 -> STR_10(CODE[9]), STR_9(CODE[2]), STR_8(CODE[6]), STR_7(CODE[5]), 
;!		 -> STR_6(CODE[6]), STR_5(CODE[8]), STR_4(CODE[25]), STR_3(CODE[4]), 
;!		 -> STR_2(CODE[2]), STR_1(CODE[5]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->_Sink_Set
;!    _Sink_Set->_Sink_Slot_Off
;!    _Sink_Set->_Sink_Slot_On
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Slot_Charge_Ctrl
;!    _Update_LED_Global->___bmul
;!    _System_Init->___bmul
;!    _Slot_Charge_Ctrl->_Route_LinearLi
;!    _Route_LinearLi->_Route_DetectLi
;!    _Route_LiIon->_Route_DetectLi
;!    _Detect_Classify->_Route_DetectLi
;!    _Route_DetectLi->___lldiv
;!    _Get_Vcc->___lldiv
;!    _Adc_Norm->___lldiv
;!    _Read_Temperature->___lldiv
;!    _Print_SystemStatus->___lldiv
;!    ___lldiv->___lmul
;!    _Print_NtcTemp->_uart_send_number
;!    _uart_send_string->_uart_send_char
;!    _uart_send_number->___lwdiv
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    None.
;!
;!Critical Paths under _main in BANK1
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 3     3      0   66704
;!                                             79 BANK0      1     1      0
;!                                              0 BANK1      2     2      0
;!                       _CCCV_Control
;!                    _Display_Service
;!                            _Get_Vcc
;!                      _Print_NtcTemp
;!                 _Print_SystemStatus
;!                   _Read_Temperature
;!                  _Sense_Pins_AsSink
;!                 _Sense_Pins_Restore
;!                   _Slot_Charge_Ctrl
;!                        _System_Init
;!                  _Update_LED_Global
;!                  _Wait_Display_Idle
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _Wait_Display_Idle                                    1     1      0       0
;!                                              0 BANK0      1     1      0
;! ---------------------------------------------------------------------------------
;! (1) _Update_LED_Global                                   14    14      0    2080
;!                                              3 BANK0     14    14      0
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0    1090
;!                                              3 BANK0      1     1      0
;!                            _AD_Init
;!                             ___bmul
;!                          _uart_init
;! ---------------------------------------------------------------------------------
;! (2) _uart_init                                            0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Slot_Charge_Ctrl                                    30    30      0   32403
;!                                             49 BANK0     30    30      0
;!                           _Adc_Norm
;!                 _Detect_BatteryType
;!                    _Detect_Classify
;!                    _Enter_DiodeTest
;!                            _Get_Vcc
;!                        _Route_LiIon
;!                     _Route_LinearLi
;!                             ___bmul
;!                            ___lldiv
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (2) ___wmul                                               6     2      4    2810
;!                                              0 BANK0      6     2      4
;! ---------------------------------------------------------------------------------
;! (2) _Route_LinearLi                                       6     4      2    3930
;!                                             43 BANK0      6     4      2
;!                     _Route_DetectLi
;! ---------------------------------------------------------------------------------
;! (2) _Route_LiIon                                          4     4      0    3413
;!                                             43 BANK0      4     4      0
;!                     _Route_DetectLi
;! ---------------------------------------------------------------------------------
;! (2) _Enter_DiodeTest                                      4     4      0      62
;!                                              0 BANK0      4     4      0
;! ---------------------------------------------------------------------------------
;! (2) _Detect_Classify                                      5     4      1    7222
;!                                             43 BANK0      5     4      1
;!                            _Get_Vcc
;!                     _Route_DetectLi
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (3) _Route_DetectLi                                      18    16      2    3351
;!                                             25 BANK0     18    16      2
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (2) _Get_Vcc                                              4     4      0    2462
;!                                             25 BANK0      4     4      0
;!                         _ADC_Sample
;!                            ___lldiv
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     251
;!                                              0 BANK0      2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _Adc_Norm                                             6     3      3    3731
;!                                             25 BANK0      6     3      3
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (1) _Sense_Pins_Restore                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Sense_Pins_AsSink                                    0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Read_Temperature                                    12    12      0    4815
;!                                             25 BANK0     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (1) _Print_SystemStatus                                  32    32      0   12148
;!                                             25 BANK0     32    32      0
;!                         _ADC_Sample
;!                             ___bmul
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (4) ___lmul                                              12     4      8    1207
;!                                              0 BANK0     12     4      8
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1398
;!                                             12 BANK0     13     5      8
;!                             ___lmul (ARG)
;!                             ___wmul (ARG)
;! ---------------------------------------------------------------------------------
;! (3) _ADC_Sample                                          18    17      1    1030
;!                                              0 BANK0     18    17      1
;! ---------------------------------------------------------------------------------
;! (1) _Print_NtcTemp                                        4     4      0    6430
;!                                             17 BANK0      4     4      0
;!                            ___lwdiv
;!                            ___lwmod
;!                   _uart_send_number
;!                   _uart_send_string
;! ---------------------------------------------------------------------------------
;! (1) _uart_send_string                                     2     0      2    2637
;!                                              3 BANK0      2     0      2
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_number                                    10     8      2    2628
;!                                              7 BANK0     10     8      2
;!                             ___bmul (ARG)
;!                            ___lwdiv
;!                            ___lwmod
;!                     _uart_send_char
;! ---------------------------------------------------------------------------------
;! (2) _uart_send_char                                       3     3      0     102
;!                                              0 BANK0      3     3      0
;! ---------------------------------------------------------------------------------
;! (3) ___lwmod                                              5     1      4     378
;!                                              0 BANK0      5     1      4
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4     777
;!                                              0 BANK0      7     3      4
;! ---------------------------------------------------------------------------------
;! (1) _Display_Service                                      0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _CCCV_Control                                        20    20      0    2540
;!                                              8 BANK0     20    20      0
;!                            ___awdiv
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1     836
;!                                              0 BANK0      3     2      1
;! ---------------------------------------------------------------------------------
;! (2) ___awdiv                                              8     4      4     606
;!                                              0 BANK0      8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 4
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (5) _Isr_Timer                                            3     3      0     391
;!                                              5 COMMON     3     3      0
;!                 _PowerOnLedSequence
;!                           _Sink_Set
;! ---------------------------------------------------------------------------------
;! (6) _Sink_Set                                             4     1      3     391
;!                                              1 COMMON     4     1      3
;!                      _Sink_Slot_Off
;!                       _Sink_Slot_On
;! ---------------------------------------------------------------------------------
;! (7) _Sink_Slot_On                                         1     1      0      22
;!                                              0 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (7) _Sink_Slot_Off                                        1     1      0      22
;!                                              0 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (6) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 7
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     ___bmul
;!   _Display_Service
;!   _Get_Vcc
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!       ___wmul (ARG)
;!   _Print_NtcTemp
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Print_SystemStatus
;!     _ADC_Sample
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!       ___wmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!     ___lwmod
;!     _uart_send_char
;!     _uart_send_number
;!       ___bmul (ARG)
;!       ___lwdiv (ARG)
;!       ___lwmod (ARG)
;!       _uart_send_char (ARG)
;!     _uart_send_string
;!       _uart_send_char
;!   _Read_Temperature
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!       ___wmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!   _Sense_Pins_AsSink
;!   _Sense_Pins_Restore
;!   _Slot_Charge_Ctrl
;!     _Adc_Norm
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!         ___wmul (ARG)
;!       ___lmul
;!     _Detect_BatteryType
;!     _Detect_Classify
;!       _Get_Vcc
;!         _ADC_Sample
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!       _Route_DetectLi
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!         ___lmul
;!       ___lwdiv
;!     _Enter_DiodeTest
;!     _Get_Vcc
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!         ___wmul (ARG)
;!     _Route_LiIon
;!       _Route_DetectLi
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!         ___lmul
;!     _Route_LinearLi
;!       _Route_DetectLi
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!         ___lmul
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!       ___wmul (ARG)
;!     ___wmul
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!     _uart_init
;!   _Update_LED_Global
;!     ___bmul
;!   _Wait_Display_Idle
;!   _uart_send_string
;!     _uart_send_char
;!
;! _Isr_Timer (ROOT)
;!   _PowerOnLedSequence
;!   _Sink_Set
;!     _Sink_Slot_Off
;!     _Sink_Slot_On
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50      0      30       8       60.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      0      48      10       90.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50      2      4A       6       92.5%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     50      50       4      100.0%
;!BITBANK0            50      0       0       3        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      8       E       1      100.0%
;!BITCOMMON            E      0       1       0        7.1%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     120      12        0.0%
;!ABS                  0      0     120      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 594 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   79[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       2       0       0
;;      Totals:         0       1       2       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels required when called:    7
;; This function calls:
;;		_CCCV_Control
;;		_Display_Service
;;		_Get_Vcc
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_Read_Temperature
;;		_Sense_Pins_AsSink
;;		_Sense_Pins_Restore
;;		_Slot_Charge_Ctrl
;;		_System_Init
;;		_Update_LED_Global
;;		_Wait_Display_Idle
;;		_uart_send_string
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"main.c"
	line	594
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"main.c"
	line	594
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 1
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	599
	
l7619:	
	opt asmopt_push
opt asmopt_off
movlw	52
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_main+0)^080h+0+1),f
	movlw	241
movwf	((??_main+0)^080h+0),f
	u11857:
decfsz	((??_main+0)^080h+0),f
	goto	u11857
	decfsz	((??_main+0)^080h+0+1),f
	goto	u11857
opt asmopt_pop

	line	600
# 600 "main.c"
clrwdt ;# 
psect	maintext
	line	603
	
l7621:	
	fcall	_System_Init
	line	606
	
l7623:	
	movlw	low(((STR_37)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_37)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	607
	
l7625:	
	movlw	low(((STR_38)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_38)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	611
	
l516:	
	line	613
# 613 "main.c"
clrwdt ;# 
psect	maintext
	line	619
	
l7627:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_hwTick+1)^080h,w	;volatile
	movwf	(_g_elapsedTicks+1)^080h
	movf	(_g_hwTick)^080h,w	;volatile
	movwf	(_g_elapsedTicks)^080h
	
l7629:	
	movf	(_g_lastHwTick)^080h,w
	subwf	(_g_elapsedTicks)^080h,f
	movf	(_g_lastHwTick+1)^080h,w
	skipc
	decf	(_g_elapsedTicks+1)^080h,f
	subwf	(_g_elapsedTicks+1)^080h,f
	line	620
	
l7631:	
	movf	((_g_elapsedTicks)^080h),w
iorwf	((_g_elapsedTicks+1)^080h),w
	btfss	status,2
	goto	u11781
	goto	u11780
u11781:
	goto	l7635
u11780:
	line	621
	
l7633:	
	clrf	(_g_elapsedTicks)^080h
	incf	(_g_elapsedTicks)^080h,f
	clrf	(_g_elapsedTicks+1)^080h
	line	622
	
l7635:	
	movf	(_g_hwTick+1)^080h,w	;volatile
	movwf	(_g_lastHwTick+1)^080h
	movf	(_g_hwTick)^080h,w	;volatile
	movwf	(_g_lastHwTick)^080h
	line	625
	
l7637:	
	fcall	_Get_Vcc
	line	638
	
l7639:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_powerOnPhase)^080h,w
	skipc
	goto	u11791
	goto	u11790
u11791:
	goto	l7671
u11790:
	line	642
	
l7641:	
	btfsc	(_s_senseRestored/8),(_s_senseRestored)&7
	goto	u11801
	goto	u11800
u11801:
	goto	l7647
u11800:
	line	644
	
l7643:	
	fcall	_Sense_Pins_Restore
	line	645
	
l7645:	
	bsf	(_s_senseRestored/8),(_s_senseRestored)&7
	line	651
	
l7647:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(main@i)
	line	653
	
l7653:	
	fcall	_Wait_Display_Idle
	line	654
	
l7655:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@i),w
	fcall	_Slot_Charge_Ctrl
	line	655
	
l7657:	
	fcall	_Display_Service
	line	651
	
l7659:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(main@i),f
	
l7661:	
	movlw	low(0Ch)
	subwf	(main@i),w
	skipc
	goto	u11811
	goto	u11810
u11811:
	goto	l7653
u11810:
	line	659
	
l7663:	
	fcall	_CCCV_Control
	line	662
	
l7665:	
	movlw	low(01Dh)
	subwf	(_g_pwmDuty),w	;volatile
	skipc
	goto	u11821
	goto	u11820
u11821:
	goto	l7669
u11820:
	line	663
	
l7667:	
	movlw	low(01Ch)
	movwf	(_g_pwmDuty)	;volatile
	line	666
	
l7669:	
	fcall	_Update_LED_Global
	line	667
	goto	l7673
	line	671
	
l7671:	
	fcall	_Sense_Pins_AsSink
	line	675
	
l7673:	
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u11831
	goto	u11830
u11831:
	goto	l7679
u11830:
	line	677
	
l7675:	
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	678
	
l7677:	
	fcall	_Read_Temperature
	line	683
	
l7679:	
	btfss	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	goto	u11841
	goto	u11840
u11841:
	goto	l516
u11840:
	line	685
	
l7681:	
	bcf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	686
	
l7683:	
	fcall	_Print_SystemStatus
	line	687
	fcall	_Print_NtcTemp
	goto	l516
	global	start
	ljmp	start
	opt stack 0
	line	691
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_Wait_Display_Idle

;; *************** function _Wait_Display_Idle *****************
;; Defined at:
;;		line 566 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	566
global __ptext1
__ptext1:	;psect for function _Wait_Display_Idle
psect	text1
	file	"main.c"
	line	566
	global	__size_of_Wait_Display_Idle
	__size_of_Wait_Display_Idle	equ	__end_of_Wait_Display_Idle-_Wait_Display_Idle
	
_Wait_Display_Idle:	
;incstack = 0
	opt	stack 4
; Regs used in _Wait_Display_Idle: [wreg+status,2+status,0]
	line	568
	
l6469:	
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	569
	goto	l495
	
l496:	
	line	570
# 570 "main.c"
clrwdt ;# 
psect	text1
	
l495:	
	line	569
	btfsc	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	goto	u8891
	goto	u8890
u8891:
	goto	l496
u8890:
	line	573
	
l6471:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	((_g_sinkMask)^080h),w	;volatile
iorwf	((_g_sinkMask+1)^080h),w	;volatile
	btfsc	status,2
	goto	u8901
	goto	u8900
u8901:
	goto	l499
u8900:
	line	574
	
l6473:	
	opt asmopt_push
opt asmopt_off
	movlw	65
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Wait_Display_Idle+0)+0),f
	u11867:
decfsz	(??_Wait_Display_Idle+0)+0,f
	goto	u11867
	nop2
opt asmopt_pop

	line	575
	
l499:	
	return
	opt stack 0
GLOBAL	__end_of_Wait_Display_Idle
	__end_of_Wait_Display_Idle:
	signat	_Wait_Display_Idle,89
	global	_Update_LED_Global

;; *************** function _Update_LED_Global *****************
;; Defined at:
;;		line 60 in file "led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    9[BANK0 ] unsigned char 
;;  s               1   12[BANK0 ] unsigned char 
;;  s               1   15[BANK0 ] unsigned char 
;;  sT0IE           1    8[BANK0 ] unsigned char 
;;  mask            2   13[BANK0 ] unsigned int 
;;  i               1   16[BANK0 ] unsigned char 
;;  hasChg          1   11[BANK0 ] unsigned char 
;;  hasErr          1   10[BANK0 ] unsigned char 
;;  hasFull         1    7[BANK0 ] unsigned char 
;;  hasDet          1    6[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      11       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0      14       0       0       0
;;Total ram usage:       14 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"led.c"
	line	60
global __ptext2
__ptext2:	;psect for function _Update_LED_Global
psect	text2
	file	"led.c"
	line	60
	global	__size_of_Update_LED_Global
	__size_of_Update_LED_Global	equ	__end_of_Update_LED_Global-_Update_LED_Global
	
_Update_LED_Global:	
;incstack = 0
	opt	stack 3
; Regs used in _Update_LED_Global: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	63
	
l7441:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Update_LED_Global@hasErr)
	line	64
	clrf	(Update_LED_Global@hasChg)
	line	65
	clrf	(Update_LED_Global@hasDet)
	line	66
	clrf	(Update_LED_Global@hasFull)
	line	67
	clrf	(Update_LED_Global@mask)
	clrf	(Update_LED_Global@mask+1)
	line	70
	clrf	(Update_LED_Global@i)
	line	72
	
l7447:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Global@s)
	line	73
	
l7449:	
		movlw	7
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u11381
	goto	u11380
u11381:
	goto	l7453
u11380:
	line	75
	
l7451:	
	clrf	(Update_LED_Global@hasErr)
	incf	(Update_LED_Global@hasErr),f
	line	76
	goto	l7479
	line	78
	
l7453:	
		movlw	2
	xorwf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u11391
	goto	u11390
u11391:
	goto	l7461
u11390:
	
l7455:	
		movlw	3
	xorwf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u11401
	goto	u11400
u11401:
	goto	l7461
u11400:
	
l7457:	
		movlw	4
	xorwf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u11411
	goto	u11410
u11411:
	goto	l7461
u11410:
	
l7459:	
		movlw	5
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u11421
	goto	u11420
u11421:
	goto	l7465
u11420:
	line	83
	
l7461:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Update_LED_Global+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Update_LED_Global+0)+0+1
	movlw	0Fh
	subwf	1+(??_Update_LED_Global+0)+0,w
	movlw	096h
	skipnz
	subwf	0+(??_Update_LED_Global+0)+0,w
	skipnc
	goto	u11431
	goto	u11430
u11431:
	goto	l7479
u11430:
	line	84
	
l7463:	
	clrf	(Update_LED_Global@hasChg)
	incf	(Update_LED_Global@hasChg),f
	goto	l7479
	line	86
	
l7465:	
		decf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u11441
	goto	u11440
u11441:
	goto	l7471
u11440:
	
l7467:	
		movlw	8
	xorwf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u11451
	goto	u11450
u11451:
	goto	l7471
u11450:
	
l7469:	
		movlw	9
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u11461
	goto	u11460
u11461:
	goto	l7475
u11460:
	line	88
	
l7471:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Update_LED_Global+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Update_LED_Global+0)+0+1
	movlw	0Fh
	subwf	1+(??_Update_LED_Global+0)+0,w
	movlw	096h
	skipnz
	subwf	0+(??_Update_LED_Global+0)+0,w
	skipnc
	goto	u11471
	goto	u11470
u11471:
	goto	l1018
u11470:
	line	89
	
l7473:	
	clrf	(Update_LED_Global@hasDet)
	incf	(Update_LED_Global@hasDet),f
	goto	l7479
	line	91
	
l7475:	
		movlw	6
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u11481
	goto	u11480
u11481:
	goto	l1018
u11480:
	line	93
	
l7477:	
	clrf	(Update_LED_Global@hasFull)
	incf	(Update_LED_Global@hasFull),f
	goto	l7479
	line	95
	
l1018:	
	line	70
	
l7479:	
	incf	(Update_LED_Global@i),f
	
l7481:	
	movlw	low(0Ch)
	subwf	(Update_LED_Global@i),w
	skipc
	goto	u11491
	goto	u11490
u11491:
	goto	l7447
u11490:
	line	100
	
l7483:	
	movf	((Update_LED_Global@hasErr)),w
	btfsc	status,2
	goto	u11501
	goto	u11500
u11501:
	goto	l7503
u11500:
	line	102
	
l7485:	
	clrf	(Update_LED_Global@i)
	line	104
	
l7491:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Global@s_465)
	line	105
	
l7493:	
		movlw	7
	xorwf	((Update_LED_Global@s_465)),w
	btfsc	status,2
	goto	u11511
	goto	u11510
u11511:
	goto	l7499
u11510:
	
l7495:	
		movlw	4
	xorwf	((Update_LED_Global@s_465)),w
	btfsc	status,2
	goto	u11521
	goto	u11520
u11521:
	goto	l7499
u11520:
	
l7497:	
		movlw	5
	xorwf	((Update_LED_Global@s_465)),w
	btfss	status,2
	goto	u11531
	goto	u11530
u11531:
	goto	l7501
u11530:
	line	106
	
l7499:	
	incf	(Update_LED_Global@i),w
	movwf	(??_Update_LED_Global+0)+0
	movlw	01h
	movwf	(??_Update_LED_Global+1)+0
	movlw	0
	movwf	(??_Update_LED_Global+1)+0+1
	goto	u11544
u11545:
	clrc
	rlf	(??_Update_LED_Global+1)+0,f
	rlf	(??_Update_LED_Global+1)+1,f
u11544:
	decfsz	(??_Update_LED_Global+0)+0,f
	goto	u11545
	
	movf	0+(??_Update_LED_Global+1)+0,w
	iorwf	(Update_LED_Global@mask),f
	movf	1+(??_Update_LED_Global+1)+0,w
	iorwf	(Update_LED_Global@mask+1),f
	line	102
	
l7501:	
	incf	(Update_LED_Global@i),f
	movlw	low(0Ch)
	subwf	(Update_LED_Global@i),w
	skipc
	goto	u11551
	goto	u11550
u11551:
	goto	l7491
u11550:
	goto	l7523
	line	109
	
l7503:	
	movf	((Update_LED_Global@hasChg)),w
	btfsc	status,2
	goto	u11561
	goto	u11560
u11561:
	goto	l7523
u11560:
	line	111
	
l7505:	
	clrf	(Update_LED_Global@i)
	line	113
	
l7511:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Global@s_466)
	line	114
	
l7513:	
		movlw	4
	xorwf	((Update_LED_Global@s_466)),w
	btfsc	status,2
	goto	u11571
	goto	u11570
u11571:
	goto	l7517
u11570:
	
l7515:	
		movlw	5
	xorwf	((Update_LED_Global@s_466)),w
	btfss	status,2
	goto	u11581
	goto	u11580
u11581:
	goto	l7521
u11580:
	
l7517:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Update_LED_Global+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Update_LED_Global+0)+0+1
	movlw	0Fh
	subwf	1+(??_Update_LED_Global+0)+0,w
	movlw	096h
	skipnz
	subwf	0+(??_Update_LED_Global+0)+0,w
	skipnc
	goto	u11591
	goto	u11590
u11591:
	goto	l7521
u11590:
	line	115
	
l7519:	
	incf	(Update_LED_Global@i),w
	movwf	(??_Update_LED_Global+0)+0
	movlw	01h
	movwf	(??_Update_LED_Global+1)+0
	movlw	0
	movwf	(??_Update_LED_Global+1)+0+1
	goto	u11604
u11605:
	clrc
	rlf	(??_Update_LED_Global+1)+0,f
	rlf	(??_Update_LED_Global+1)+1,f
u11604:
	decfsz	(??_Update_LED_Global+0)+0,f
	goto	u11605
	
	movf	0+(??_Update_LED_Global+1)+0,w
	iorwf	(Update_LED_Global@mask),f
	movf	1+(??_Update_LED_Global+1)+0,w
	iorwf	(Update_LED_Global@mask+1),f
	line	111
	
l7521:	
	incf	(Update_LED_Global@i),f
	movlw	low(0Ch)
	subwf	(Update_LED_Global@i),w
	skipc
	goto	u11611
	goto	u11610
u11611:
	goto	l7511
u11610:
	line	129
	
l7523:	
	movf	(11),w	;volatile
	movwf	(Update_LED_Global@sT0IE)
	
l7525:	
	movlw	low(020h)
	andwf	(Update_LED_Global@sT0IE),f
	line	130
	
l7527:	
	bcf	(11)+(5/8),(5)&7	;volatile
	line	131
	
l7529:	
	movf	((Update_LED_Global@hasErr)),w
	btfsc	status,2
	goto	u11621
	goto	u11620
u11621:
	goto	l7545
u11620:
	line	134
	
l7531:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_elapsedTicks)^080h,w
	addwf	(_s_ledBlinkCnt)^080h,f
	line	135
	
l7533:	
	movlw	low(019h)
	subwf	(_s_ledBlinkCnt)^080h,w
	skipc
	goto	u11631
	goto	u11630
u11631:
	goto	l7537
u11630:
	line	136
	
l7535:	
	clrf	(_s_ledBlinkCnt)^080h
	line	137
	
l7537:	
	movlw	low(0Ch)
	subwf	(_s_ledBlinkCnt)^080h,w
	skipnc
	goto	u11641
	goto	u11640
u11641:
	goto	l1040
u11640:
	line	139
	
l7539:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	140
	
l7541:	
	bcf	status, 6	;RP1=0, select bank0
	movf	(Update_LED_Global@mask+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_sinkMask+1)^080h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(Update_LED_Global@mask),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_sinkMask)^080h	;volatile
	line	141
	goto	l7579
	line	142
	
l1040:	
	line	144
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	145
	
l7543:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(_g_sinkMask)^080h	;volatile
	clrf	(_g_sinkMask+1)^080h	;volatile
	goto	l7579
	line	148
	
l7545:	
	movf	((Update_LED_Global@hasChg)),w
	btfsc	status,2
	goto	u11651
	goto	u11650
u11651:
	goto	l7555
u11650:
	line	151
	
l7547:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_ledBlinkCnt)^080h
	line	152
	
l7549:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	
l7551:	
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	l7541
	line	155
	
l7555:	
	movf	((Update_LED_Global@hasDet)),w
	btfsc	status,2
	goto	u11661
	goto	u11660
u11661:
	goto	l7563
u11660:
	line	159
	
l7557:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_ledBlinkCnt)^080h
	line	160
	
l7559:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	
l7561:	
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	161
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(_g_sinkMask)^080h	;volatile
	clrf	(_g_sinkMask+1)^080h	;volatile
	line	162
	goto	l7579
	line	163
	
l7563:	
	movf	((Update_LED_Global@hasFull)),w
	btfsc	status,2
	goto	u11671
	goto	u11670
u11671:
	goto	l7573
u11670:
	line	167
	
l7565:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_ledBlinkCnt)^080h
	line	168
	
l7567:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	
l7569:	
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	goto	l7541
	line	174
	
l7573:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_ledBlinkCnt)^080h
	line	175
	
l7575:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	
l7577:	
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	176
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(_g_sinkMask)^080h	;volatile
	clrf	(_g_sinkMask+1)^080h	;volatile
	line	178
	
l7579:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Update_LED_Global@sT0IE),w
	iorwf	(11),f	;volatile
	line	180
	
l1049:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Global
	__end_of_Update_LED_Global:
	signat	_Update_LED_Global,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 71 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1    3[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;;		_uart_init
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	71
global __ptext3
__ptext3:	;psect for function _System_Init
psect	text3
	file	"main.c"
	line	71
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	76
	
l6169:	
# 76 "main.c"
nop ;# 
	line	77
# 77 "main.c"
clrwdt ;# 
psect	text3
	line	78
	
l6171:	
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	82
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	83
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	84
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l6173:	
	clrf	(262)^0100h	;volatile
	line	86
	
l6175:	
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l6177:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	89
	
l6179:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l6181:	
	clrf	(135)^080h	;volatile
	line	90
	
l6183:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l6185:	
	clrf	(7)	;volatile
	line	91
	
l6187:	
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	92
	
l6189:	
	clrf	(277)^0100h	;volatile
	line	95
	
l6191:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l6193:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	98
	
l6195:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	99
	
l6197:	
	clrf	(406)^0180h	;volatile
	line	106
	
l6199:	
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	107
	
l6201:	
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	108
	
l6203:	
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	109
	
l6205:	
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	112
	
l6207:	
	fcall	_AD_Init
	line	116
	
l6209:	
	fcall	_uart_init
	line	123
	bcf	status, 6	;RP1=0, select bank0
	clrf	(1)	;volatile
	line	124
	
l6211:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	125
	
l6213:	
	bcf	(90/8),(90)&7	;volatile
	line	126
	
l6215:	
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	130
	clrf	(_g_pwmDuty)	;volatile
	line	131
	clrf	(_g_pwmCounter)^080h	;volatile
	line	132
	
l6217:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	133
	
l6219:	
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	134
	
l6221:	
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	135
	
l6223:	
	bcf	(55/8),(55)&7	;volatile
	line	138
	clrf	(System_Init@i)
	line	140
	
l6229:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	141
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	142
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	143
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	144
	
l6231:	
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	145
	
l6233:	
	movf	(System_Init@i),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	138
	
l6235:	
	incf	(System_Init@i),f
	
l6237:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u8691
	goto	u8690
u8691:
	goto	l6229
u8690:
	line	149
	
l373:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_uart_init

;; *************** function _uart_init *****************
;; Defined at:
;;		line 21 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"uart_dbg.c"
	line	21
global __ptext4
__ptext4:	;psect for function _uart_init
psect	text4
	file	"uart_dbg.c"
	line	21
	global	__size_of_uart_init
	__size_of_uart_init	equ	__end_of_uart_init-_uart_init
	
_uart_init:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_init: []
	line	23
	
l5909:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(261)^0100h+(4/8),(4)&7	;volatile
	line	24
	bcf	(265)^0100h+(4/8),(4)&7	;volatile
	line	25
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	26
	
l558:	
	return
	opt stack 0
GLOBAL	__end_of_uart_init
	__end_of_uart_init:
	signat	_uart_init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	23
global __ptext5
__ptext5:	;psect for function _AD_Init
psect	text5
	file	"adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l5903:	
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
	clrf	(406)^0180h	;volatile
	line	27
	
l5905:	
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l5907:	
	clrf	(150)^080h	;volatile
	line	29
	
l535:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Slot_Charge_Ctrl

;; *************** function _Slot_Charge_Ctrl *****************
;; Defined at:
;;		line 427 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   78[BANK0 ] unsigned char 
;;  vcc_norm        2   62[BANK0 ] unsigned int 
;;  pre             2   76[BANK0 ] unsigned int 
;;  diff            2   74[BANK0 ] int 
;;  vcc_norm_now    2   58[BANK0 ] unsigned int 
;;  vcc_norm_pre    2   56[BANK0 ] unsigned int 
;;  ptTick          2   60[BANK0 ] unsigned int 
;;  pt              1   64[BANK0 ] unsigned char 
;;  v_ref           2   71[BANK0 ] unsigned int 
;;  v_init          2   54[BANK0 ] unsigned int 
;;  newv            2   69[BANK0 ] unsigned int 
;;  charge_ticks    2   67[BANK0 ] unsigned int 
;;  dly             1   73[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      25       0       0       0
;;      Temps:          0       5       0       0       0
;;      Totals:         0      30       0       0       0
;;Total ram usage:       30 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_Adc_Norm
;;		_Detect_BatteryType
;;		_Detect_Classify
;;		_Enter_DiodeTest
;;		_Get_Vcc
;;		_Route_LiIon
;;		_Route_LinearLi
;;		___bmul
;;		___lldiv
;;		___wmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	427
global __ptext6
__ptext6:	;psect for function _Slot_Charge_Ctrl
psect	text6
	file	"charge_mgr.c"
	line	427
	global	__size_of_Slot_Charge_Ctrl
	__size_of_Slot_Charge_Ctrl	equ	__end_of_Slot_Charge_Ctrl-_Slot_Charge_Ctrl
	
_Slot_Charge_Ctrl:	
;incstack = 0
	opt	stack 1
; Regs used in _Slot_Charge_Ctrl: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	movwf	(Slot_Charge_Ctrl@idx)
	line	433
	
l6481:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(_s_work)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	6
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
u8940:
	
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	((??_Slot_Charge_Ctrl+0)+0+2)
	incf	fsr,w
	movwf	((??_Slot_Charge_Ctrl+0)+0+3)
	movf	(??_Slot_Charge_Ctrl+0)+0,w
	movwf	fsr
	bcf	status, 7	;select IRP bank1
	
	movf	((??_Slot_Charge_Ctrl+0)+0+2),w
	movwf	indf
	incf	fsr,w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	((??_Slot_Charge_Ctrl+0)+0+3),w
	movwf	fsr
	decfsz	((??_Slot_Charge_Ctrl+0)+0+1),f
	goto	u8940
	
	line	438
	
l6483:	
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+04h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@charge_ticks_prev+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+04h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@charge_ticks_prev)
	line	439
	
l6485:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_elapsedTicks)^080h,w
	addwf	0+(_s_work)^080h+04h,f
	skipnc
	incf	1+(_s_work)^080h+04h,f
	movf	(_g_elapsedTicks+1)^080h,w
	addwf	1+(_s_work)^080h+04h,f
	line	447
	
l6487:	
		decf	((_s_work)^080h),w
	btfsc	status,2
	goto	u8951
	goto	u8950
u8951:
	goto	l6493
u8950:
	
l6489:	
		movlw	8
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u8961
	goto	u8960
u8961:
	goto	l6493
u8960:
	
l6491:	
		movlw	9
	xorwf	((_s_work)^080h),w
	btfss	status,2
	goto	u8971
	goto	u8970
u8971:
	goto	l6511
u8970:
	
l6493:	
		incf	((_g_detectOwner)^080h),w
	btfsc	status,2
	goto	u8981
	goto	u8980
u8981:
	goto	l6511
u8980:
	
l6495:	
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipnz
	goto	u8991
	goto	u8990
u8991:
	goto	l6511
u8990:
	line	451
	
l6497:	
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectWaiter)^080h),w
	btfss	status,2
	goto	u9001
	goto	u9000
u9001:
	goto	l6503
u9000:
	line	452
	
l6499:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectWaiter)^080h
	goto	l6503
	line	453
	
l690:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l6505
	
l692:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l6505
	
l693:	
	bsf	(51/8),(51)&7	;volatile
	goto	l6505
	
l694:	
	bsf	(50/8),(50)&7	;volatile
	goto	l6505
	
l695:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l6505
	
l696:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l6505
	
l697:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l6505
	
l698:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l6505
	
l699:	
	bsf	(48/8),(48)&7	;volatile
	goto	l6505
	
l700:	
	bsf	(49/8),(49)&7	;volatile
	goto	l6505
	
l701:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l6505
	
l702:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l6505
	
l6503:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l690
	xorlw	1^0	; case 1
	skipnz
	goto	l692
	xorlw	2^1	; case 2
	skipnz
	goto	l693
	xorlw	3^2	; case 3
	skipnz
	goto	l694
	xorlw	4^3	; case 4
	skipnz
	goto	l695
	xorlw	5^4	; case 5
	skipnz
	goto	l696
	xorlw	6^5	; case 6
	skipnz
	goto	l697
	xorlw	7^6	; case 7
	skipnz
	goto	l698
	xorlw	8^7	; case 8
	skipnz
	goto	l699
	xorlw	9^8	; case 9
	skipnz
	goto	l700
	xorlw	10^9	; case 10
	skipnz
	goto	l701
	xorlw	11^10	; case 11
	skipnz
	goto	l702
	goto	l6505
	opt asmopt_pop

	line	454
	
l6505:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_s_work)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+4,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+5,w
	movwf	indf
	goto	l704
	line	459
	
l707:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l6513
	
l709:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l6513
	
l710:	
	bsf	(51/8),(51)&7	;volatile
	goto	l6513
	
l711:	
	bsf	(50/8),(50)&7	;volatile
	goto	l6513
	
l712:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l6513
	
l713:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l6513
	
l714:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l6513
	
l715:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l6513
	
l716:	
	bsf	(48/8),(48)&7	;volatile
	goto	l6513
	
l717:	
	bsf	(49/8),(49)&7	;volatile
	goto	l6513
	
l718:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l6513
	
l719:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l6513
	
l6511:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l707
	xorlw	1^0	; case 1
	skipnz
	goto	l709
	xorlw	2^1	; case 2
	skipnz
	goto	l710
	xorlw	3^2	; case 3
	skipnz
	goto	l711
	xorlw	4^3	; case 4
	skipnz
	goto	l712
	xorlw	5^4	; case 5
	skipnz
	goto	l713
	xorlw	6^5	; case 6
	skipnz
	goto	l714
	xorlw	7^6	; case 7
	skipnz
	goto	l715
	xorlw	8^7	; case 8
	skipnz
	goto	l716
	xorlw	9^8	; case 9
	skipnz
	goto	l717
	xorlw	10^9	; case 10
	skipnz
	goto	l718
	xorlw	11^10	; case 11
	skipnz
	goto	l719
	goto	l6513
	opt asmopt_pop

	line	460
	
l6513:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
		decf	((_s_work)^080h),w
	btfsc	status,2
	goto	u9011
	goto	u9010
u9011:
	goto	l6519
u9010:
	
l6515:	
		movlw	8
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u9021
	goto	u9020
u9021:
	goto	l6519
u9020:
	
l6517:	
		movlw	9
	xorwf	((_s_work)^080h),w
	btfss	status,2
	goto	u9031
	goto	u9030
u9031:
	goto	l6531
u9030:
	line	463
	
l6519:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Slot_Charge_Ctrl@dly)
	
l6521:	
	movlw	low(014h)
	subwf	(Slot_Charge_Ctrl@dly),w
	skipc
	goto	u9041
	goto	u9040
u9041:
	goto	l6525
u9040:
	goto	l6533
	line	464
	
l6525:	
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u11877:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u11877
	nop
opt asmopt_pop

	line	463
	
l6527:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Slot_Charge_Ctrl@dly),f
	goto	l6521
	line	468
	
l6531:	
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u11887:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u11887
	nop
opt asmopt_pop

	line	472
	
l6533:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(((_s_adcChannels)|8000h))
	movwf	fsr0
	movlw	high(((_s_adcChannels)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	fcall	_Adc_Norm
	movf	(1+(?_Adc_Norm)),w
	movwf	(Slot_Charge_Ctrl@newv+1)
	movf	(0+(?_Adc_Norm)),w
	movwf	(Slot_Charge_Ctrl@newv)
	line	476
	
l6535:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u9051
	goto	u9050
u9051:
	goto	l6543
u9050:
	
l6537:	
		movlw	4
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u9061
	goto	u9060
u9061:
	goto	l6541
u9060:
	
l6539:	
		movlw	5
	xorwf	((_s_work)^080h),w
	btfss	status,2
	goto	u9071
	goto	u9070
u9071:
	goto	l6543
u9070:
	
l6541:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Slot_Charge_Ctrl@newv+1),w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@newv),w
	skipnc
	goto	u9081
	goto	u9080
u9081:
	goto	l7253
u9080:
	line	478
	
l6543:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@newv+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	1+(_s_work)^080h+02h
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@newv),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+02h
	goto	l7253
	line	487
	
l6545:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u9091
	goto	u9090
u9091:
	goto	l6551
u9090:
	line	489
	
l6547:	
	movlw	09h
	subwf	1+(_s_work)^080h+04h,w
	movlw	060h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u9101
	goto	u9100
u9101:
	goto	l6551
u9100:
	goto	l7255
	line	497
	
l6551:	
		incf	((_g_detectOwner)^080h),w
	btfsc	status,2
	goto	u9111
	goto	u9110
u9111:
	goto	l6555
u9110:
	
l6553:	
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u9121
	goto	u9120
u9121:
	goto	l7255
u9120:
	
l6555:	
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectWaiter)^080h),w
	btfsc	status,2
	goto	u9131
	goto	u9130
u9131:
	goto	l6559
u9130:
	
l6557:	
	movf	(_g_detectWaiter)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipnz
	goto	u9141
	goto	u9140
u9141:
	goto	l6559
u9140:
	goto	l7255
	line	500
	
l6559:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	501
	
l6561:	
	clrf	(_s_work)^080h
	incf	(_s_work)^080h,f
	line	502
	
l6563:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	503
	
l6565:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9154
u9155:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9154:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9155
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	506
	
l6567:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u9161
	goto	u9160
u9161:
	goto	l6571
u9160:
	line	507
	
l6569:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	goto	l7255
	line	509
	
l6571:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l7255
	line	516
	
l6573:	
	bcf	status, 5	;RP0=0, select bank0
	movf	((Slot_Charge_Ctrl@charge_ticks_prev)),w
iorwf	((Slot_Charge_Ctrl@charge_ticks_prev+1)),w
	btfss	status,2
	goto	u9171
	goto	u9170
u9171:
	goto	l6581
u9170:
	
l6575:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(0+(_s_work)^080h+04h),w
iorwf	(1+(_s_work)^080h+04h),w
	btfsc	status,2
	goto	u9181
	goto	u9180
u9181:
	goto	l6581
u9180:
	line	518
	
l6577:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	519
	
l6579:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9194
u9195:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9194:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9195
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	522
	
l6581:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u9201
	goto	u9200
u9201:
	goto	l6585
u9200:
	goto	l7255
	line	537
	
l6585:	
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Slot_Charge_Ctrl@charge_ticks_prev+1),w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@charge_ticks_prev),w
	skipnc
	goto	u9211
	goto	u9210
u9211:
	goto	l6595
u9210:
	
l6587:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u9221
	goto	u9220
u9221:
	goto	l6595
u9220:
	line	539
	
l6589:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	540
	
l6591:	
	movlw	0Bh
	subwf	1+(_s_work)^080h+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u9231
	goto	u9230
u9231:
	goto	l7255
u9230:
	line	541
	
l6593:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9244
u9245:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9244:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9245
	
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag+1)^080h,f
	goto	l7255
	line	544
	
l6595:	
	movlw	0Bh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u9251
	goto	u9250
u9251:
	goto	l6657
u9250:
	
l6597:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u9261
	goto	u9260
u9261:
	goto	l6657
u9260:
	line	556
	
l6599:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9274
u9275:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9274:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9275
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfss	status,2
	goto	u9281
	goto	u9280
u9281:
	goto	l6613
u9280:
	
l6601:	
		movlw	5
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u9291
	goto	u9290
u9291:
	goto	l6613
u9290:
	
l6603:	
	movlw	0Dh
	subwf	1+(_s_work)^080h+02h,w
	movlw	0ADh
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u9301
	goto	u9300
u9301:
	goto	l6613
u9300:
	line	558
	
l6605:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	559
	
l6607:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	560
	
l6609:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	561
	
l6611:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	562
	goto	l7255
	line	572
	
l6613:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_init)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_init+1)
	line	574
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	bcf	status, 7	;select IRP bank1
	subwf	indf,w
	skipc
	goto	u9311
	goto	u9310
u9311:
	goto	l6637
u9310:
	line	579
	
l6615:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9324
u9325:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9324:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9325
	
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag+1)^080h,f
	line	581
	
l6617:	
	movlw	0Bh
	subwf	1+(_s_work)^080h+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u9331
	goto	u9330
u9331:
	goto	l6625
u9330:
	line	584
	
l6619:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9344
u9345:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9344:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9345
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	585
	
l6621:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	586
	
l6623:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9354
u9355:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9354:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9355
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	587
	goto	l6669
	line	588
	
l6625:	
	movlw	04h
	subwf	1+(_s_work)^080h+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u9361
	goto	u9360
u9361:
	goto	l6635
u9360:
	line	595
	
l6627:	
	movlw	01h
	subwf	1+(_s_work)^080h+04h,w
	movlw	09h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u9371
	goto	u9370
u9371:
	goto	l6569
u9370:
	line	597
	
l6629:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Detect_Classify@fromHighV)
	incf	(Detect_Classify@fromHighV),f
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	598
	goto	l7255
	line	607
	
l6635:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Detect_Classify@fromHighV)
	incf	(Detect_Classify@fromHighV),f
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	608
	goto	l7255
	line	616
	
l6637:	
	movlw	04h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u9381
	goto	u9380
u9381:
	goto	l6641
u9380:
	line	618
	
l6639:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Detect_Classify@fromHighV)
	incf	(Detect_Classify@fromHighV),f
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	619
	goto	l7255
	line	624
	
l6641:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	625
	
l6643:	
	movf	0+(_s_work)^080h+02h,w
	addlw	low(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v_init+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9395
	movf	(Slot_Charge_Ctrl@v_init),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9395:
	skipnc
	goto	u9391
	goto	u9390
u9391:
	goto	l6647
u9390:
	line	626
	
l6645:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l760
	line	628
	
l6647:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	
l760:	
	line	629
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u9401
	goto	u9400
u9401:
	goto	l6651
u9400:
	goto	l7255
	line	632
	
l6651:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9414
u9415:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9414:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9415
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u9421
	goto	u9420
u9421:
	goto	l6655
u9420:
	goto	l7255
	line	634
	
l6655:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6669
	line	637
	
l6657:	
	movlw	04h
	subwf	1+(_s_work)^080h+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u9431
	goto	u9430
u9431:
	goto	l6669
u9430:
	
l6659:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u9441
	goto	u9440
u9441:
	goto	l6669
u9440:
	line	639
	
l6661:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_ref)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_ref+1)
	line	640
	
l6663:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v_ref+1),w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v_ref),w
	skipnc
	goto	u9451
	goto	u9450
u9451:
	goto	l6669
u9450:
	
l6665:	
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	addlw	low(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v_ref+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9465
	movf	(Slot_Charge_Ctrl@v_ref),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9465:
	skipnc
	goto	u9461
	goto	u9460
u9461:
	goto	l6669
u9460:
	goto	l6569
	line	650
	
l6669:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9474
u9475:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9474:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9475
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u9481
	goto	u9480
u9481:
	goto	l6677
u9480:
	line	652
	
l6671:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9494
u9495:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9494:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9495
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	653
	
l6673:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	654
	
l6675:	
	movlw	low(05h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	655
	goto	l767
	line	658
	
l6677:	
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Detect_BatteryType@voltage+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	664
	
l6679:	
	movf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u9501
	goto	u9500
u9501:
	goto	l767
u9500:
	
l6681:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u9511
	goto	u9510
u9511:
	goto	l767
u9510:
	
l6683:	
	movlw	04h
	subwf	1+(_s_work)^080h+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u9521
	goto	u9520
u9521:
	goto	l767
u9520:
	goto	l6675
	line	666
	
l767:	
	line	670
	movlw	01h
	subwf	1+(_s_work)^080h+02h,w
	movlw	0F4h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u9531
	goto	u9530
u9531:
	goto	l6691
u9530:
	line	672
	
l6687:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	673
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u9541
	goto	u9540
u9541:
	goto	l6699
u9540:
	goto	l7255
	line	677
	
l6691:	
		movlw	5
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u9551
	goto	u9550
u9551:
	goto	l6699
u9550:
	
l6693:	
		decf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u9561
	goto	u9560
u9561:
	goto	l6699
u9560:
	
l6695:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u9571
	goto	u9570
u9571:
	goto	l6699
u9570:
	line	679
	
l6697:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	686
	
l6699:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Detect_Classify@fromHighV)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	687
	goto	l7255
	line	692
	
l6701:	
	movlw	0
	subwf	1+(_s_work)^080h+04h,w
	movlw	05h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u9581
	goto	u9580
u9581:
	goto	l6705
u9580:
	goto	l7255
	line	697
	
l6705:	
	fcall	_Get_Vcc
	line	703
	
l6707:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	0D2h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u9591
	goto	u9590
u9591:
	goto	l6717
u9590:
	
l6709:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0D2h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u9601
	goto	u9600
u9601:
	goto	l6717
u9600:
	line	705
	
l6711:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_s_work)^080h+01h
	line	706
	clrf	(_s_work)^080h
	line	707
	
l6713:	
	movlw	low(0FFh)
	movwf	(_g_detectOwner)^080h
	line	708
	
l6715:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9614
u9615:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9614:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9615
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	709
	goto	l7255
	line	719
	
l6717:	
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(0+(?___wmul)),w
	movwf	((??_Slot_Charge_Ctrl+0)+0)
	movf	(1+(?___wmul)),w
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
	clrf	((??_Slot_Charge_Ctrl+0)+0+2)
	clrf	((??_Slot_Charge_Ctrl+0)+0+3)
	movlw	0Ch
u9625:
	clrc
	rlf	(??_Slot_Charge_Ctrl+0)+0,f
	rlf	(??_Slot_Charge_Ctrl+0)+1,f
	rlf	(??_Slot_Charge_Ctrl+0)+2,f
	rlf	(??_Slot_Charge_Ctrl+0)+3,f
u9620:
	addlw	-1
	skipz
	goto	u9625
	movf	3+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_pre+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_pre)
	line	720
	movf	(_g_vcc_mv),w
	movwf	(___lldiv@dividend)
	movf	(_g_vcc_mv+1),w
	movwf	((___lldiv@dividend))+1
	clrf	2+((___lldiv@dividend))
	clrf	3+((___lldiv@dividend))
	movlw	0Ch
	movwf	(??_Slot_Charge_Ctrl+0)+0
u9635:
	clrc
	rlf	(___lldiv@dividend),f
	rlf	(___lldiv@dividend+1),f
	rlf	(___lldiv@dividend+2),f
	rlf	(___lldiv@dividend+3),f
	decfsz	(??_Slot_Charge_Ctrl+0)+0
	goto	u9635
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_now+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_now)
	line	722
	
l6719:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	(Slot_Charge_Ctrl@vcc_norm_pre+1),w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u9645
	movf	(Slot_Charge_Ctrl@vcc_norm_pre),w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u9645:
	skipc
	goto	u9641
	goto	u9640
u9641:
	goto	l6729
u9640:
	
l6721:	
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@vcc_norm_now+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9655
	movf	(Slot_Charge_Ctrl@vcc_norm_now),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9655:
	skipc
	goto	u9651
	goto	u9650
u9651:
	goto	l6729
u9650:
	goto	l6711
	line	735
	
l6729:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(012Ch)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(012Ch)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9665
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9665:
	skipnc
	goto	u9661
	goto	u9660
u9661:
	goto	l6737
u9660:
	
l6731:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u9671
	goto	u9670
u9671:
	goto	l6737
u9670:
	line	737
	
l6733:	
	movlw	low(02h)
	movwf	0+(_s_work)^080h+01h
	line	738
	movlw	low(07h)
	movwf	(_s_work)^080h
	line	739
	movlw	low(0FFh)
	movwf	(_g_detectOwner)^080h
	goto	l6715
	line	749
	
l6737:	
	swapf	(_g_impData+1),w
	andlw	15
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(0C8h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9685
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9685:
	skipnc
	goto	u9681
	goto	u9680
u9681:
	goto	l6743
u9680:
	
l6739:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Ch
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	01Ch
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u9691
	goto	u9690
u9691:
	goto	l6743
u9690:
	line	751
	
l6741:	
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	752
	goto	l7255
	line	761
	
l6743:	
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9704
u9705:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9704:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9705
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfss	status,2
	goto	u9711
	goto	u9710
u9711:
	goto	l6755
u9710:
	
l6745:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u9725
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u9725:
	skipnc
	goto	u9721
	goto	u9720
u9721:
	goto	l6755
u9720:
	
l6747:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipc
	incf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	03h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0E9h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipc
	goto	u9731
	goto	u9730
u9731:
	goto	l6755
u9730:
	line	763
	
l6749:	
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	764
	movlw	low(07h)
	movwf	(_s_work)^080h
	line	765
	movlw	low(0FFh)
	movwf	(_g_detectOwner)^080h
	line	766
	
l6751:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u9744
u9745:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u9744:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u9745
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	goto	l6611
	line	775
	
l6755:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Dh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0ADh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u9751
	goto	u9750
u9751:
	goto	l6761
u9750:
	
l6757:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(0C8h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9765
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9765:
	skipc
	goto	u9761
	goto	u9760
u9761:
	goto	l6761
u9760:
	line	777
	
l6759:	
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Enter_DiodeTest
	line	778
	goto	l7255
	line	786
	
l6761:	
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Enter_DiodeTest
	line	788
	goto	l7255
	line	804
	
l6763:	
	movf	(_g_diodeTraceCnt)^080h,w
	addlw	01h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@pt)
	line	805
	
l6765:	
	movf	(Slot_Charge_Ctrl@pt),w
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	07h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(1+(?___wmul)),w
	movwf	(Slot_Charge_Ctrl@ptTick+1)
	movf	(0+(?___wmul)),w
	movwf	(Slot_Charge_Ctrl@ptTick)
	line	806
	
l6767:	
	movf	(Slot_Charge_Ctrl@ptTick+1),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	skipz
	goto	u9775
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@ptTick),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+04h,w
u9775:
	skipnc
	goto	u9771
	goto	u9770
u9771:
	goto	l6771
u9770:
	goto	l6787
	line	809
	
l6771:	
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff)
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	(Slot_Charge_Ctrl@diff),f
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	decf	(Slot_Charge_Ctrl@diff+1),f
	subwf	(Slot_Charge_Ctrl@diff+1),f
	line	810
	rlf	(Slot_Charge_Ctrl@diff+1),w
	rrf	(Slot_Charge_Ctrl@diff+1),f
	rrf	(Slot_Charge_Ctrl@diff),f
	rlf	(Slot_Charge_Ctrl@diff+1),w
	rrf	(Slot_Charge_Ctrl@diff+1),f
	rrf	(Slot_Charge_Ctrl@diff),f
	line	811
	
l6773:	
	movf	(Slot_Charge_Ctrl@diff+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u9785
	movlw	080h
	subwf	(Slot_Charge_Ctrl@diff),w
u9785:

	skipc
	goto	u9781
	goto	u9780
u9781:
	goto	l6777
u9780:
	
l6775:	
	movlw	07Fh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff)
	clrf	(Slot_Charge_Ctrl@diff+1)
	line	812
	
l6777:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@diff+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u9795
	movlw	080h
	subwf	(Slot_Charge_Ctrl@diff),w
u9795:

	skipnc
	goto	u9791
	goto	u9790
u9791:
	goto	l6781
u9790:
	
l6779:	
	movlw	080h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff)
	movlw	0FFh
	movwf	((Slot_Charge_Ctrl@diff))+1
	line	813
	
l6781:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_diodeTraceCnt)^080h,w
	addlw	low(_g_diodeTrace|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@diff),w
	addlw	080h
	bcf	status, 7	;select IRP bank1
	movwf	indf
	
l6783:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_diodeTraceCnt)^080h,f
	line	802
	
l6785:	
	movlw	low(04h)
	subwf	(_g_diodeTraceCnt)^080h,w
	skipc
	goto	u9801
	goto	u9800
u9801:
	goto	l6763
u9800:
	line	826
	
l6787:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	034h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u9811
	goto	u9810
u9811:
	goto	l6797
u9810:
	
l6789:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(0384h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(0384h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u9825
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u9825:
	skipnc
	goto	u9821
	goto	u9820
u9821:
	goto	l6797
u9820:
	line	830
	
l6791:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9835
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9835:
	skipnc
	goto	u9831
	goto	u9830
u9831:
	goto	l6795
u9830:
	line	831
	
l6793:	
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l7255
	line	833
	
l6795:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(Route_LinearLi@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l7255
	line	845
	
l6797:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Bh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0B9h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u9841
	goto	u9840
u9841:
	goto	l6805
u9840:
	
l6799:	
	movlw	0Bh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u9851
	goto	u9850
u9851:
	goto	l6805
u9850:
	
l6801:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u9865
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u9865:
	skipnc
	goto	u9861
	goto	u9860
u9861:
	goto	l6805
u9860:
	line	847
	
l6803:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_LinearLi@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	848
	goto	l7255
	line	858
	
l6805:	
	movlw	0Bh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u9871
	goto	u9870
u9871:
	goto	l6815
u9870:
	
l6807:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	034h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u9881
	goto	u9880
u9881:
	goto	l6815
u9880:
	goto	l6749
	line	879
	
l6815:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	014h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u9891
	goto	u9890
u9891:
	goto	l6827
u9890:
	
l6817:	
	movlw	08h
	subwf	1+(_s_work)^080h+02h,w
	movlw	035h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u9901
	goto	u9900
u9901:
	goto	l6827
u9900:
	
l6819:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u9911
	goto	u9910
u9911:
	goto	l6827
u9910:
	
l6821:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	addlw	low(0A0h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(0A0h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u9925
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u9925:
	skipc
	goto	u9921
	goto	u9920
u9921:
	goto	l6827
u9920:
	
l6823:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u9935
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u9935:
	skipc
	goto	u9931
	goto	u9930
u9931:
	goto	l6827
u9930:
	line	881
	
l6825:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(Route_LinearLi@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	882
	goto	l7255
	line	890
	
l6827:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u9941
	goto	u9940
u9941:
	goto	l7255
u9940:
	line	892
	
l6829:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Slot_Charge_Ctrl@pre)
	line	901
	
l6831:	
	movf	(_g_vcc_mv),w
	movwf	(___lldiv@dividend)
	movf	(_g_vcc_mv+1),w
	movwf	((___lldiv@dividend))+1
	clrf	2+((___lldiv@dividend))
	clrf	3+((___lldiv@dividend))
	movlw	0Ch
	movwf	(??_Slot_Charge_Ctrl+0)+0
u9955:
	clrc
	rlf	(___lldiv@dividend),f
	rlf	(___lldiv@dividend+1),f
	rlf	(___lldiv@dividend+2),f
	rlf	(___lldiv@dividend+3),f
	decfsz	(??_Slot_Charge_Ctrl+0)+0
	goto	u9955
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm)
	line	902
	
l6833:	
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@vcc_norm+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9965
	movf	(Slot_Charge_Ctrl@vcc_norm),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9965:
	skipc
	goto	u9961
	goto	u9960
u9961:
	goto	l6841
u9960:
	line	904
	
l6835:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u9975
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u9975:
	skipnc
	goto	u9971
	goto	u9970
u9971:
	goto	l6839
u9970:
	line	905
	
l6837:	
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l7255
	line	907
	
l6839:	
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l7255
	line	918
	
l6841:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0ADh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipc
	goto	u9981
	goto	u9980
u9981:
	goto	l6853
u9980:
	
l6843:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u9991
	goto	u9990
u9991:
	goto	l6853
u9990:
	
l6845:	
	movf	(Slot_Charge_Ctrl@pre),w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u10005
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u10005:
	skipc
	goto	u10001
	goto	u10000
u10001:
	goto	l6853
u10000:
	line	920
	
l6847:	
	swapf	(_g_impData+1),w
	andlw	15
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u10015
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u10015:
	skipnc
	goto	u10011
	goto	u10010
u10011:
	goto	l6851
u10010:
	line	921
	
l6849:	
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l7255
	line	923
	
l6851:	
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l7255
	line	944
	
l6853:	
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	029h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10021
	goto	u10020
u10021:
	goto	l6869
u10020:
	
l6855:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u10031
	goto	u10030
u10031:
	goto	l6869
u10030:
	
l6857:	
	movlw	08h
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	034h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipc
	goto	u10041
	goto	u10040
u10041:
	goto	l6869
u10040:
	
l6859:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0ACh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u10051
	goto	u10050
u10051:
	goto	l6869
u10050:
	
l6861:	
	movlw	0Bh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0B8h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u10061
	goto	u10060
u10061:
	goto	l6865
u10060:
	
l6863:	
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u10075
	movf	(Slot_Charge_Ctrl@pre),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u10075:
	skipnc
	goto	u10071
	goto	u10070
u10071:
	goto	l6867
u10070:
	
l6865:	
	movf	(Slot_Charge_Ctrl@pre),w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u10085
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u10085:
	skipc
	goto	u10081
	goto	u10080
u10081:
	goto	l6869
u10080:
	line	946
	
l6867:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	947
	goto	l7255
	line	955
	
l6869:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@pre),w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u10095
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u10095:
	skipnc
	goto	u10091
	goto	u10090
u10091:
	goto	l6749
u10090:
	
l6871:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u10101
	goto	u10100
u10101:
	goto	l6749
u10100:
	
l6873:	
	movlw	07h
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	091h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipc
	goto	u10111
	goto	u10110
u10111:
	goto	l6749
u10110:
	
l6875:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0ACh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u10121
	goto	u10120
u10121:
	goto	l6749
u10120:
	line	957
	
l6877:	
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	958
	goto	l7255
	line	971
	
l6885:	
	movlw	017h
	subwf	1+(_s_work)^080h+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u10131
	goto	u10130
u10131:
	goto	l6889
u10130:
	line	973
	
l6887:	
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	974
	goto	l7255
	line	976
	
l6889:	
	movlw	02h
	subwf	1+(_s_work)^080h+02h,w
	movlw	0EFh
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10141
	goto	u10140
u10141:
	goto	l6895
u10140:
	line	978
	
l6891:	
	movlw	low(03h)
	movwf	(_s_work)^080h
	line	979
	
l6893:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	980
	goto	l7255
	line	982
	
l6895:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10151
	goto	u10150
u10151:
	goto	l7255
u10150:
	goto	l6887
	line	991
	
l6899:	
	movlw	075h
	subwf	1+(_s_work)^080h+04h,w
	movlw	031h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u10161
	goto	u10160
u10161:
	goto	l6903
u10160:
	goto	l6887
	line	996
	
l6903:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10171
	goto	u10170
u10171:
	goto	l6909
u10170:
	line	998
	
l6905:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	999
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u10181
	goto	u10180
u10181:
	goto	l6911
u10180:
	goto	l6887
	line	1007
	
l6909:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	1009
	
l6911:	
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	08Ch
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10191
	goto	u10190
u10191:
	goto	l7255
u10190:
	line	1011
	
l6913:	
	movlw	low(04h)
	movwf	(_s_work)^080h
	line	1012
	
l6915:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	1013
	
l6917:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1014
	
l6919:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1015
	
l6921:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	1016
	
l6923:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l7255
	line	1022
	
l6925:	
	movlw	0EAh
	subwf	1+(_s_work)^080h+04h,w
	movlw	060h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u10201
	goto	u10200
u10201:
	goto	l6931
u10200:
	line	1024
	
l6927:	
	movlw	060h
	subwf	0+(_s_work)^080h+04h,f
	movlw	0EAh
	skipc
	decf	1+(_s_work)^080h+04h,f
	subwf	1+(_s_work)^080h+04h,f
	line	1025
	
l6929:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1030
	
l6931:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(07Fh)
	bsf	status, 7	;select IRP bank3
	andwf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	low(012h)
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u10211
	goto	u10210
u10211:
	goto	l6935
u10210:
	goto	l6887
	line	1039
	
l6935:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10221
	goto	u10220
u10221:
	goto	l6941
u10220:
	
l6937:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u10231
	goto	u10230
u10231:
	goto	l6941
u10230:
	goto	l6949
	line	1043
	
l6941:	
	movlw	017h
	subwf	1+(_s_work)^080h+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u10241
	goto	u10240
u10241:
	goto	l6945
u10240:
	goto	l6949
	line	1051
	
l6945:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u10255
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u10255:
	skipnc
	goto	u10251
	goto	u10250
u10251:
	goto	l6949
u10250:
	
l6947:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	1058
	
l6949:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u10261
	goto	u10260
u10261:
	goto	l6995
u10260:
	line	1060
	
l6951:	
	movlw	07h
	subwf	1+(_s_work)^080h+02h,w
	movlw	0D0h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u10271
	goto	u10270
u10271:
	goto	l6961
u10270:
	line	1062
	
l6953:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1063
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u10281
	goto	u10280
u10281:
	goto	l6963
u10280:
	line	1065
	
l6955:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1066
	
l6957:	
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l6893
	line	1073
	
l6961:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	1083
	
l6963:	
	movlw	06h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	040h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u10291
	goto	u10290
u10291:
	goto	l7029
u10290:
	line	1085
	
l6965:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	1086
	
l6967:	
	movlw	0Ah
	subwf	1+(_s_work)^080h+02h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10301
	goto	u10300
u10301:
	goto	l6979
u10300:
	
l6969:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u10311
	goto	u10310
u10311:
	goto	l6979
u10310:
	line	1088
	
l6971:	
	movlw	low(05h)
	movwf	(_s_work)^080h
	line	1089
	
l6973:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6921
	line	1093
	
l6979:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u10325
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u10325:
	skipc
	goto	u10321
	goto	u10320
u10321:
	goto	l6983
u10320:
	line	1095
	
l6981:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	indf,f
	line	1096
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	1097
	goto	l7255
	line	1098
	
l6983:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	(indf),w
	btfsc	status,2
	goto	u10331
	goto	u10330
u10331:
	goto	l6987
u10330:
	goto	l6569
	line	1102
	
l6987:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	btfss	indf,(7)&7
	goto	u10341
	goto	u10340
u10341:
	goto	l6991
u10340:
	goto	l6887
	line	1108
	
l6991:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(7/8),(7)&7
	line	1109
	
l6993:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_work)^080h
	incf	(_s_work)^080h,f
	line	1110
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	1111
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l7255
	line	1120
	
l6995:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u10355
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u10355:
	skipnc
	goto	u10351
	goto	u10350
u10351:
	goto	l6999
u10350:
	
l6997:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipc
	incf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	01h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipnc
	goto	u10361
	goto	u10360
u10361:
	goto	l7001
u10360:
	
l6999:	
	movlw	07h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	0D0h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u10371
	goto	u10370
u10371:
	goto	l7013
u10370:
	line	1122
	
l7001:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1123
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u10381
	goto	u10380
u10381:
	goto	l7005
u10380:
	goto	l7255
	line	1125
	
l7005:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1126
	
l7007:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_work)^080h
	incf	(_s_work)^080h,f
	goto	l6893
	line	1132
	
l7013:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	1140
	
l7015:	
	movlw	017h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u10391
	goto	u10390
u10391:
	goto	l7021
u10390:
	line	1142
	
l7017:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u10405
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u10405:
	skipc
	goto	u10401
	goto	u10400
u10401:
	goto	l7021
u10400:
	line	1143
	
l7019:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	indf,f
	line	1145
	
l7021:	
	movlw	017h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u10411
	goto	u10410
u10411:
	goto	l7029
u10410:
	
l7023:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	(indf),w
	btfss	status,2
	goto	u10421
	goto	u10420
u10421:
	goto	l7029
u10420:
	goto	l6957
	line	1159
	
l7029:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10431
	goto	u10430
u10431:
	goto	l7037
u10430:
	
l7031:	
		decf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u10441
	goto	u10440
u10441:
	goto	l7037
u10440:
	line	1161
	
l7033:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l6893
	line	1169
	
l7037:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10451
	goto	u10450
u10451:
	goto	l7045
u10450:
	
l7039:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u10461
	goto	u10460
u10461:
	goto	l7045
u10460:
	line	1171
	
l7041:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1172
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u10471
	goto	u10470
u10471:
	goto	l7255
u10470:
	goto	l6887
	line	1180
	
l7045:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	1182
	
l7047:	
	movlw	0Ch
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	01Ch
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10481
	goto	u10480
u10481:
	goto	l7255
u10480:
	
l7049:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10491
	goto	u10490
u10491:
	goto	l7053
u10490:
	
l7051:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u10501
	goto	u10500
u10501:
	goto	l7255
u10500:
	line	1184
	
l7053:	
	movlw	low(05h)
	movwf	(_s_work)^080h
	line	1185
	
l7055:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	1186
	
l7057:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l7255
	line	1193
	
l7059:	
	movlw	017h
	subwf	1+(_s_work)^080h+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u10511
	goto	u10510
u10511:
	goto	l857
u10510:
	line	1194
	
l7061:	
	movlw	low(06h)
	movwf	(_s_work)^080h
	
l857:	
	line	1202
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10521
	goto	u10520
u10521:
	goto	l7067
u10520:
	
l7063:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u10531
	goto	u10530
u10531:
	goto	l7067
u10530:
	goto	l7255
	line	1212
	
l7067:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u10541
	goto	u10540
u10541:
	goto	l7089
u10540:
	
l7069:	
	movlw	017h
	subwf	1+(_s_work)^080h+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u10551
	goto	u10550
u10551:
	goto	l7089
u10550:
	
l7071:	
		decf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u10561
	goto	u10560
u10561:
	goto	l7089
u10560:
	line	1214
	
l7073:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfss	status,2
	goto	u10571
	goto	u10570
u10571:
	goto	l7077
u10570:
	line	1216
	
l7075:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	1217
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	1218
	goto	l7089
	line	1219
	
l7077:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u10585
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u10585:
	skipc
	goto	u10581
	goto	u10580
u10581:
	goto	l7087
u10580:
	line	1221
	
l7079:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	movlw	low(03h)
	subwf	(indf),w
	skipc
	goto	u10591
	goto	u10590
u10591:
	goto	l861
u10590:
	line	1223
	
l7081:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l6957
	line	1231
	
l7087:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l7089
	line	1232
	
l861:	
	line	1240
	
l7089:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10601
	goto	u10600
u10601:
	goto	l7119
u10600:
	line	1242
	
l7091:	
		decf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u10611
	goto	u10610
u10611:
	goto	l7103
u10610:
	line	1244
	
l7093:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1245
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u10621
	goto	u10620
u10621:
	goto	l7097
u10620:
	goto	l7255
	line	1247
	
l7097:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l7033
	line	1252
	
l7103:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u10631
	goto	u10630
u10631:
	goto	l7107
u10630:
	goto	l7255
	line	1257
	
l7107:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1258
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u10641
	goto	u10640
u10641:
	goto	l7111
u10640:
	goto	l7255
	line	1260
	
l7111:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1261
	
l7113:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_s_work)^080h+01h
	line	1262
	
l7115:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_work)^080h
	goto	l6893
	line	1272
	
l7119:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u10651
	goto	u10650
u10651:
	goto	l7133
u10650:
	line	1274
	
l7121:	
	movlw	07h
	subwf	1+(_s_work)^080h+02h,w
	movlw	0D0h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u10661
	goto	u10660
u10661:
	goto	l7131
u10660:
	line	1276
	
l7123:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1277
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u10671
	goto	u10670
u10671:
	goto	l7149
u10670:
	goto	l6955
	line	1287
	
l7131:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l7149
	line	1292
	
l7133:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u10685
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u10685:
	skipnc
	goto	u10681
	goto	u10680
u10681:
	goto	l7131
u10680:
	
l7135:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipc
	incf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	01h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipc
	goto	u10691
	goto	u10690
u10691:
	goto	l7131
u10690:
	line	1294
	
l7137:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1295
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipc
	goto	u10701
	goto	u10700
u10701:
	goto	l7149
u10700:
	line	1297
	
l7139:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1298
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1300
	
l7141:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_s_work)^080h+01h
	goto	l7007
	line	1316
	
l7149:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10711
	goto	u10710
u10711:
	goto	l7157
u10710:
	
l7151:	
		decf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u10721
	goto	u10720
u10721:
	goto	l7157
u10720:
	line	1318
	
l7153:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1319
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u10731
	goto	u10730
u10731:
	goto	l7255
u10730:
	goto	l6887
	line	1327
	
l7157:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l7255
	line	1338
	
l7159:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10741
	goto	u10740
u10741:
	goto	l7177
u10740:
	line	1340
	
l7161:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1341
	
l7163:	
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u10751
	goto	u10750
u10751:
	goto	l7167
u10750:
	
l7165:	
	movlw	02h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Slot_Charge_Ctrl$441)
	clrf	(_Slot_Charge_Ctrl$441+1)
	goto	l7169
	
l7167:	
	movlw	032h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Slot_Charge_Ctrl$441)
	clrf	(_Slot_Charge_Ctrl$441+1)
	
l7169:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(_Slot_Charge_Ctrl$441+1),w
	xorlw	80h
	sublw	080h
	skipz
	goto	u10765
	movf	(_Slot_Charge_Ctrl$441),w
	subwf	indf,w
u10765:

	skipc
	goto	u10761
	goto	u10760
u10761:
	goto	l7255
u10760:
	line	1343
	
l7171:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l7115
	line	1352
	
l7177:	
	movlw	0Ah
	subwf	1+(_s_work)^080h+02h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u10771
	goto	u10770
u10771:
	goto	l6611
u10770:
	line	1354
	
l7179:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1355
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u10781
	goto	u10780
u10781:
	goto	l7183
u10780:
	goto	l7255
	line	1357
	
l7183:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1358
	
l7185:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	1359
	
l7187:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	1360
	
l7189:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l6973
	line	1373
	
l7199:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10791
	goto	u10790
u10791:
	goto	l7215
u10790:
	line	1375
	
l7201:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1376
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u10801
	goto	u10800
u10801:
	goto	l7205
u10800:
	goto	l7255
	line	1378
	
l7205:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1379
	
l7207:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_s_work)^080h+01h
	line	1380
	
l7209:	
	clrf	(_s_work)^080h
	goto	l7055
	line	1393
	
l7215:	
		movlw	2
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u10811
	goto	u10810
u10811:
	goto	l7219
u10810:
	
l7217:	
		movlw	3
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u10821
	goto	u10820
u10821:
	goto	l7235
u10820:
	line	1395
	
l7219:	
	movlw	0Ah
	subwf	1+(_s_work)^080h+02h,w
	movlw	08Dh
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10831
	goto	u10830
u10831:
	goto	l6611
u10830:
	
l7221:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u10844
u10845:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u10844:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u10845
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u10851
	goto	u10850
u10851:
	goto	l6611
u10850:
	line	1397
	
l7223:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1398
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u10861
	goto	u10860
u10861:
	goto	l7005
u10860:
	goto	l7255
	line	1411
	
l7235:	
	movlw	02h
	subwf	1+(_s_work)^080h+02h,w
	movlw	0EFh
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u10871
	goto	u10870
u10871:
	goto	l6611
u10870:
	line	1413
	
l7237:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1414
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u10881
	goto	u10880
u10881:
	goto	l7005
u10880:
	goto	l7255
	line	1427
	
l7249:	
	clrf	(_s_work)^080h
	line	1428
	goto	l7255
	line	482
	
l7253:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_s_work)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l6545
	xorlw	1^0	; case 1
	skipnz
	goto	l6573
	xorlw	2^1	; case 2
	skipnz
	goto	l6885
	xorlw	3^2	; case 3
	skipnz
	goto	l6899
	xorlw	4^3	; case 4
	skipnz
	goto	l6925
	xorlw	5^4	; case 5
	skipnz
	goto	l7059
	xorlw	6^5	; case 6
	skipnz
	goto	l7159
	xorlw	7^6	; case 7
	skipnz
	goto	l7199
	xorlw	8^7	; case 8
	skipnz
	goto	l6701
	xorlw	9^8	; case 9
	skipnz
	goto	l6785
	goto	l7249
	opt asmopt_pop

	line	1440
	
l7255:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
		decf	((_s_work)^080h),w
	btfsc	status,2
	goto	u10891
	goto	u10890
u10891:
	goto	l7261
u10890:
	
l7257:	
		movlw	8
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u10901
	goto	u10900
u10901:
	goto	l7261
u10900:
	
l7259:	
		movlw	9
	xorwf	((_s_work)^080h),w
	btfss	status,2
	goto	u10911
	goto	u10910
u10911:
	goto	l7265
u10910:
	line	1442
	
l7261:	
		incf	((_g_detectOwner)^080h),w
	btfss	status,2
	goto	u10921
	goto	u10920
u10921:
	goto	l908
u10920:
	line	1443
	
l7263:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	goto	l908
	line	1447
	
l7265:	
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u10931
	goto	u10930
u10931:
	goto	l908
u10930:
	line	1448
	
l7267:	
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	1449
	
l908:	
	line	1455
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_detectWaiter)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u10941
	goto	u10940
u10941:
	goto	l7277
u10940:
	
l7269:	
	bsf	status, 5	;RP0=1, select bank1
		decf	((_s_work)^080h),w
	btfsc	status,2
	goto	u10951
	goto	u10950
u10951:
	goto	l7277
u10950:
	
l7271:	
		movlw	8
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u10961
	goto	u10960
u10961:
	goto	l7277
u10960:
	
l7273:	
		movlw	9
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u10971
	goto	u10970
u10971:
	goto	l7277
u10970:
	line	1456
	
l7275:	
	movlw	low(0FFh)
	movwf	(_g_detectWaiter)^080h
	line	1458
	
l7277:	
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_s_work)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+4,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+5,w
	movwf	indf
	line	1467
	
l7279:	
		movlw	2
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u10981
	goto	u10980
u10981:
	goto	l7287
u10980:
	
l7281:	
		movlw	3
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u10991
	goto	u10990
u10991:
	goto	l7287
u10990:
	
l7283:	
		movlw	4
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u11001
	goto	u11000
u11001:
	goto	l7287
u11000:
	
l7285:	
		movlw	5
	xorwf	((_s_work)^080h),w
	btfss	status,2
	goto	u11011
	goto	u11010
u11011:
	goto	l7293
u11010:
	
l7287:	
		incf	((_g_detectOwner)^080h),w
	btfsc	status,2
	goto	u11021
	goto	u11020
u11021:
	goto	l7293
u11020:
	goto	l7291
	line	1469
	
l916:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l704
	
l918:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l704
	
l919:	
	bsf	(51/8),(51)&7	;volatile
	goto	l704
	
l920:	
	bsf	(50/8),(50)&7	;volatile
	goto	l704
	
l921:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l704
	
l922:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l704
	
l923:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l704
	
l924:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l704
	
l925:	
	bsf	(48/8),(48)&7	;volatile
	goto	l704
	
l926:	
	bsf	(49/8),(49)&7	;volatile
	goto	l704
	
l927:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l704
	
l928:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l704
	
l7291:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l916
	xorlw	1^0	; case 1
	skipnz
	goto	l918
	xorlw	2^1	; case 2
	skipnz
	goto	l919
	xorlw	3^2	; case 3
	skipnz
	goto	l920
	xorlw	4^3	; case 4
	skipnz
	goto	l921
	xorlw	5^4	; case 5
	skipnz
	goto	l922
	xorlw	6^5	; case 6
	skipnz
	goto	l923
	xorlw	7^6	; case 7
	skipnz
	goto	l924
	xorlw	8^7	; case 8
	skipnz
	goto	l925
	xorlw	9^8	; case 9
	skipnz
	goto	l926
	xorlw	10^9	; case 10
	skipnz
	goto	l927
	xorlw	11^10	; case 11
	skipnz
	goto	l928
	goto	l704
	opt asmopt_pop

	line	1474
	
l7293:	
		movlw	2
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u11031
	goto	u11030
u11031:
	goto	l7307
u11030:
	
l7295:	
		movlw	3
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u11041
	goto	u11040
u11041:
	goto	l7307
u11040:
	
l7297:	
		movlw	4
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u11051
	goto	u11050
u11051:
	goto	l7307
u11050:
	
l7299:	
		movlw	5
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u11061
	goto	u11060
u11061:
	goto	l7307
u11060:
	
l7301:	
		movlw	8
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u11071
	goto	u11070
u11071:
	goto	l7305
u11070:
	
l7303:	
		decf	((_s_work)^080h),w
	btfss	status,2
	goto	u11081
	goto	u11080
u11081:
	goto	l7317
u11080:
	
l7305:	
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u11091
	goto	u11090
u11091:
	goto	l7317
u11090:
	
l7307:	
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u11101
	goto	u11100
u11101:
	goto	l7317
u11100:
	
l7309:	
	movf	((_g_vccProtect)^080h),w
	btfss	status,2
	goto	u11111
	goto	u11110
u11111:
	goto	l7317
u11110:
	goto	l7313
	line	1476
	
l938:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	l704
	
l940:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	l704
	
l941:	
	bcf	(51/8),(51)&7	;volatile
	goto	l704
	
l942:	
	bcf	(50/8),(50)&7	;volatile
	goto	l704
	
l943:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	l704
	
l944:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	l704
	
l945:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l704
	
l946:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l704
	
l947:	
	bcf	(48/8),(48)&7	;volatile
	goto	l704
	
l948:	
	bcf	(49/8),(49)&7	;volatile
	goto	l704
	
l949:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l704
	
l950:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l704
	
l7313:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l938
	xorlw	1^0	; case 1
	skipnz
	goto	l940
	xorlw	2^1	; case 2
	skipnz
	goto	l941
	xorlw	3^2	; case 3
	skipnz
	goto	l942
	xorlw	4^3	; case 4
	skipnz
	goto	l943
	xorlw	5^4	; case 5
	skipnz
	goto	l944
	xorlw	6^5	; case 6
	skipnz
	goto	l945
	xorlw	7^6	; case 7
	skipnz
	goto	l946
	xorlw	8^7	; case 8
	skipnz
	goto	l947
	xorlw	9^8	; case 9
	skipnz
	goto	l948
	xorlw	10^9	; case 10
	skipnz
	goto	l949
	xorlw	11^10	; case 11
	skipnz
	goto	l950
	goto	l704
	opt asmopt_pop

	line	1480
	
l7317:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l916
	xorlw	1^0	; case 1
	skipnz
	goto	l918
	xorlw	2^1	; case 2
	skipnz
	goto	l919
	xorlw	3^2	; case 3
	skipnz
	goto	l920
	xorlw	4^3	; case 4
	skipnz
	goto	l921
	xorlw	5^4	; case 5
	skipnz
	goto	l922
	xorlw	6^5	; case 6
	skipnz
	goto	l923
	xorlw	7^6	; case 7
	skipnz
	goto	l924
	xorlw	8^7	; case 8
	skipnz
	goto	l925
	xorlw	9^8	; case 9
	skipnz
	goto	l926
	xorlw	10^9	; case 10
	skipnz
	goto	l927
	xorlw	11^10	; case 11
	skipnz
	goto	l928
	goto	l704
	opt asmopt_pop

	line	1482
	
l704:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_Charge_Ctrl
	__end_of_Slot_Charge_Ctrl:
	signat	_Slot_Charge_Ctrl,4217
	global	___wmul

;; *************** function ___wmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
;; Parameters:    Size  Location     Type
;;  multiplier      2    0[BANK0 ] unsigned int 
;;  multiplicand    2    2[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  product         2    4[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       6       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
global __ptext7
__ptext7:	;psect for function ___wmul
psect	text7
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
	global	__size_of___wmul
	__size_of___wmul	equ	__end_of___wmul-___wmul
	
___wmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___wmul: [wreg+status,2+status,0]
	line	43
	
l6095:	
	clrf	(___wmul@product)
	clrf	(___wmul@product+1)
	line	45
	
l6097:	
	btfss	(___wmul@multiplier),(0)&7
	goto	u8581
	goto	u8580
u8581:
	goto	l6101
u8580:
	line	46
	
l6099:	
	movf	(___wmul@multiplicand),w
	addwf	(___wmul@product),f
	skipnc
	incf	(___wmul@product+1),f
	movf	(___wmul@multiplicand+1),w
	addwf	(___wmul@product+1),f
	line	47
	
l6101:	
	clrc
	rlf	(___wmul@multiplicand),f
	rlf	(___wmul@multiplicand+1),f
	line	48
	
l6103:	
	clrc
	rrf	(___wmul@multiplier+1),f
	rrf	(___wmul@multiplier),f
	line	49
	
l6105:	
	movf	((___wmul@multiplier)),w
iorwf	((___wmul@multiplier+1)),w
	btfss	status,2
	goto	u8591
	goto	u8590
u8591:
	goto	l6097
u8590:
	line	52
	
l6107:	
	movf	(___wmul@product+1),w
	movwf	(?___wmul+1)
	movf	(___wmul@product),w
	movwf	(?___wmul)
	line	53
	
l1063:	
	return
	opt stack 0
GLOBAL	__end_of___wmul
	__end_of___wmul:
	signat	___wmul,8314
	global	_Route_LinearLi

;; *************** function _Route_LinearLi *****************
;; Defined at:
;;		line 315 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  pre             2   43[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1   48[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       6       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Route_DetectLi
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	315
global __ptext8
__ptext8:	;psect for function _Route_LinearLi
psect	text8
	file	"charge_mgr.c"
	line	315
	global	__size_of_Route_LinearLi
	__size_of_Route_LinearLi	equ	__end_of_Route_LinearLi-_Route_LinearLi
	
_Route_LinearLi:	
;incstack = 0
	opt	stack 1
; Regs used in _Route_LinearLi: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	movwf	(Route_LinearLi@idx)
	line	317
	
l6009:	
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	318
	
l6011:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Route_LinearLi@idx),w
	movwf	(??_Route_LinearLi+0)+0
	movlw	01h
	movwf	(??_Route_LinearLi+1)+0
	movlw	0
	movwf	(??_Route_LinearLi+1)+0+1
	goto	u8444
u8445:
	clrc
	rlf	(??_Route_LinearLi+1)+0,f
	rlf	(??_Route_LinearLi+1)+1,f
u8444:
	decfsz	(??_Route_LinearLi+0)+0,f
	goto	u8445
	
	comf	(??_Route_LinearLi+1)+0,f
	comf	(??_Route_LinearLi+1)+1,f
	movf	0+(??_Route_LinearLi+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Route_LinearLi+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	319
	
l6013:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Route_LinearLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	btfss	indf,(7)&7
	goto	u8451
	goto	u8450
u8451:
	goto	l6019
u8450:
	line	321
	
l6015:	
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	322
	movlw	low(07h)
	goto	l662
	line	324
	
l6019:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	325
	
l6021:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	326
	
l6023:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Route_LinearLi@pre+1),w
	movwf	(Route_DetectLi@slot_v+1)
	movf	(Route_LinearLi@pre),w
	movwf	(Route_DetectLi@slot_v)
	movf	(Route_LinearLi@idx),w
	fcall	_Route_DetectLi
	line	327
	
l662:	
	return
	opt stack 0
GLOBAL	__end_of_Route_LinearLi
	__end_of_Route_LinearLi:
	signat	_Route_LinearLi,8313
	global	_Route_LiIon

;; *************** function _Route_LiIon *****************
;; Defined at:
;;		line 290 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   46[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Route_DetectLi
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	290
global __ptext9
__ptext9:	;psect for function _Route_LiIon
psect	text9
	file	"charge_mgr.c"
	line	290
	global	__size_of_Route_LiIon
	__size_of_Route_LiIon	equ	__end_of_Route_LiIon-_Route_LiIon
	
_Route_LiIon:	
;incstack = 0
	opt	stack 1
; Regs used in _Route_LiIon: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	movwf	(Route_LiIon@idx)
	line	292
	
l5997:	
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	293
	
l5999:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Route_LiIon@idx),w
	movwf	(??_Route_LiIon+0)+0
	movlw	01h
	movwf	(??_Route_LiIon+1)+0
	movlw	0
	movwf	(??_Route_LiIon+1)+0+1
	goto	u8434
u8435:
	clrc
	rlf	(??_Route_LiIon+1)+0,f
	rlf	(??_Route_LiIon+1)+1,f
u8434:
	decfsz	(??_Route_LiIon+0)+0,f
	goto	u8435
	
	comf	(??_Route_LiIon+1)+0,f
	comf	(??_Route_LiIon+1)+1,f
	movf	0+(??_Route_LiIon+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Route_LiIon+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	294
	
l6001:	
	clrf	0+(_s_work)^080h+01h
	incf	0+(_s_work)^080h+01h,f
	line	295
	
l6003:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	296
	
l6005:	
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_DetectLi@slot_v+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_DetectLi@slot_v)
	movf	(Route_LiIon@idx),w
	fcall	_Route_DetectLi
	line	297
	
l658:	
	return
	opt stack 0
GLOBAL	__end_of_Route_LiIon
	__end_of_Route_LiIon:
	signat	_Route_LiIon,4217
	global	_Enter_DiodeTest

;; *************** function _Enter_DiodeTest *****************
;; Defined at:
;;		line 406 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    3[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=0
	line	406
global __ptext10
__ptext10:	;psect for function _Enter_DiodeTest
psect	text10
	file	"charge_mgr.c"
	line	406
	global	__size_of_Enter_DiodeTest
	__size_of_Enter_DiodeTest	equ	__end_of_Enter_DiodeTest-_Enter_DiodeTest
	
_Enter_DiodeTest:	
;incstack = 0
	opt	stack 3
; Regs used in _Enter_DiodeTest: [wreg+status,2+status,0]
	movwf	(Enter_DiodeTest@idx)
	line	408
	
l6087:	
	movlw	low(09h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	409
	
l6089:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	410
	
l6091:	
	clrf	(_g_diodeTraceCnt)^080h
	line	411
	bcf	status, 5	;RP0=0, select bank0
	movf	(Enter_DiodeTest@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_diodeTraceSlot)^080h
	line	412
	
l6093:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Enter_DiodeTest@idx),w
	movwf	(??_Enter_DiodeTest+0)+0
	movlw	01h
	movwf	(??_Enter_DiodeTest+1)+0
	movlw	0
	movwf	(??_Enter_DiodeTest+1)+0+1
	goto	u8574
u8575:
	clrc
	rlf	(??_Enter_DiodeTest+1)+0,f
	rlf	(??_Enter_DiodeTest+1)+1,f
u8574:
	decfsz	(??_Enter_DiodeTest+0)+0,f
	goto	u8575
	
	comf	(??_Enter_DiodeTest+1)+0,f
	comf	(??_Enter_DiodeTest+1)+1,f
	movf	0+(??_Enter_DiodeTest+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Enter_DiodeTest+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	413
	
l681:	
	return
	opt stack 0
GLOBAL	__end_of_Enter_DiodeTest
	__end_of_Enter_DiodeTest:
	signat	_Enter_DiodeTest,4217
	global	_Detect_Classify

;; *************** function _Detect_Classify *****************
;; Defined at:
;;		line 342 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  fromHighV       1   43[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   47[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       5       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Get_Vcc
;;		_Route_DetectLi
;;		___lwdiv
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	line	342
global __ptext11
__ptext11:	;psect for function _Detect_Classify
psect	text11
	file	"charge_mgr.c"
	line	342
	global	__size_of_Detect_Classify
	__size_of_Detect_Classify	equ	__end_of_Detect_Classify-_Detect_Classify
	
_Detect_Classify:	
;incstack = 0
	opt	stack 1
; Regs used in _Detect_Classify: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	movwf	(Detect_Classify@idx)
	line	344
	
l6027:	
	movf	((Detect_Classify@fromHighV)),w
	btfsc	status,2
	goto	u8461
	goto	u8460
u8461:
	goto	l6035
u8460:
	line	352
	
l6029:	
	incf	(Detect_Classify@idx),w
	movwf	(??_Detect_Classify+0)+0
	movlw	01h
	movwf	(??_Detect_Classify+1)+0
	movlw	0
	movwf	(??_Detect_Classify+1)+0+1
	goto	u8474
u8475:
	clrc
	rlf	(??_Detect_Classify+1)+0,f
	rlf	(??_Detect_Classify+1)+1,f
u8474:
	decfsz	(??_Detect_Classify+0)+0,f
	goto	u8475
	
	comf	(??_Detect_Classify+1)+0,f
	comf	(??_Detect_Classify+1)+1,f
	movf	0+(??_Detect_Classify+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Detect_Classify+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	353
	
l6031:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Detect_Classify@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	354
	
l6033:	
	movlw	low(05h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	356
	
l6035:	
		movlw	5
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u8481
	goto	u8480
u8481:
	goto	l6057
u8480:
	line	360
	
l6037:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	361
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8491
	goto	u8490
u8491:
	goto	l6041
u8490:
	goto	l668
	line	365
	
l6041:	
	movf	(Detect_Classify@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	366
	
l6043:	
	fcall	_Get_Vcc
	line	368
	
l6045:	
	movlw	064h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_vcc_mv),w
	addlw	low(032h)
	movwf	(___lwdiv@dividend)
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(_g_impData+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_g_impData)
	movlw	0Ch
	
u8505:
	clrc
	rlf	(_g_impData),f
	rlf	(_g_impData+1),f
	addlw	-1
	skipz
	goto	u8505
	movlw	(0A000h >> 8)
	addwf	(_g_impData+1),f
	movlw	010h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	0
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u8511
	goto	u8510
u8511:
	goto	l6049
u8510:
	
l6047:	
	movf	0+(_s_work)^080h+02h,w
	iorwf	(_g_impData),f
	movf	1+(_s_work)^080h+02h,w
	iorwf	(_g_impData+1),f
	goto	l672
	
l6049:	
	movlw	0FFh
	iorwf	(_g_impData),f
	movlw	0Fh
	iorwf	(_g_impData+1),f
	
l672:	
	line	369
	movlw	low(08h)
	movwf	(_s_work)^080h
	line	370
	
l6051:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	371
	
l6053:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l668
	line	374
	
l6057:	
		decf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u8521
	goto	u8520
u8521:
	goto	l6061
u8520:
	
l6059:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u8531
	goto	u8530
u8531:
	goto	l6071
u8530:
	line	377
	
l6061:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	378
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u8541
	goto	u8540
u8541:
	goto	l6065
u8540:
	goto	l668
	line	380
	
l6065:	
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_DetectLi@slot_v+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_DetectLi@slot_v)
	movf	(Detect_Classify@idx),w
	fcall	_Route_DetectLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	381
	
l6067:	
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	goto	l668
	line	384
	
l6071:	
	movf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u8551
	goto	u8550
u8551:
	goto	l6077
u8550:
	line	387
	
l6073:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u8561
	goto	u8560
u8561:
	goto	l6077
u8560:
	goto	l668
	line	389
	
l6077:	
	movlw	low(07h)
	movwf	(_s_work)^080h
	goto	l6053
	line	396
	
l668:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_Classify
	__end_of_Detect_Classify:
	signat	_Detect_Classify,8313
	global	_Route_DetectLi

;; *************** function _Route_DetectLi *****************
;; Defined at:
;;		line 218 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  slot_v          2   25[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1   42[BANK0 ] unsigned char 
;;  bat_mv_long     4   37[BANK0 ] unsigned long 
;;  vx_mv           4   33[BANK0 ] unsigned long 
;;  bat_mv          2   31[BANK0 ] unsigned int 
;;  st              1   41[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0      12       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      18       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_Route_LiIon
;;		_Route_LinearLi
;;		_Detect_Classify
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	line	218
global __ptext12
__ptext12:	;psect for function _Route_DetectLi
psect	text12
	file	"charge_mgr.c"
	line	218
	global	__size_of_Route_DetectLi
	__size_of_Route_DetectLi	equ	__end_of_Route_DetectLi-_Route_DetectLi
	
_Route_DetectLi:	
;incstack = 0
	opt	stack 1
; Regs used in _Route_DetectLi: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	movwf	(Route_DetectLi@idx)
	line	231
	
l5815:	
	movf	(Route_DetectLi@slot_v),w
	movwf	(___lmul@multiplier)
	movf	(Route_DetectLi@slot_v+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv)

	
l5817:	
	movlw	0Ch
u8185:
	clrc
	rrf	(Route_DetectLi@vx_mv+3),f
	rrf	(Route_DetectLi@vx_mv+2),f
	rrf	(Route_DetectLi@vx_mv+1),f
	rrf	(Route_DetectLi@vx_mv),f
	addlw	-1
	skipz
	goto	u8185

	line	232
	
l5819:	
	movf	(Route_DetectLi@vx_mv+3),w
	movwf	(___lmul@multiplier+3)
	movf	(Route_DetectLi@vx_mv+2),w
	movwf	(___lmul@multiplier+2)
	movf	(Route_DetectLi@vx_mv+1),w
	movwf	(___lmul@multiplier+1)
	movf	(Route_DetectLi@vx_mv),w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long+3)
	movf	(2+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long+2)
	movf	(1+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long+1)
	movf	(0+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long)

	
l5821:	
	movlw	070h
	addwf	(Route_DetectLi@bat_mv_long),f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Route_DetectLi@bat_mv_long+1),f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Route_DetectLi@bat_mv_long+2),f
	movlw	0
	skipnc
movlw 1
	addwf	(Route_DetectLi@bat_mv_long+3),f
	line	233
	
l5823:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Route_DetectLi+0)+0)
	movlw	01h
	movwf	((??_Route_DetectLi+0)+0+1)
	movlw	0
	movwf	((??_Route_DetectLi+0)+0+2)
	movlw	0
	movwf	((??_Route_DetectLi+0)+0+3)
	movf	(Route_DetectLi@bat_mv_long),w
	addwf	(??_Route_DetectLi+0)+0,f
	movf	(Route_DetectLi@bat_mv_long+1),w
	skipnc
	incfsz	(Route_DetectLi@bat_mv_long+1),w
	goto	u8190
	goto	u8191
u8190:
	addwf	(??_Route_DetectLi+0)+1,f
u8191:
	movf	(Route_DetectLi@bat_mv_long+2),w
	skipnc
	incfsz	(Route_DetectLi@bat_mv_long+2),w
	goto	u8192
	goto	u8193
u8192:
	addwf	(??_Route_DetectLi+0)+2,f
u8193:
	movf	(Route_DetectLi@bat_mv_long+3),w
	skipnc
	incf	(Route_DetectLi@bat_mv_long+3),w
	addwf	(??_Route_DetectLi+0)+3,f
	movf	3+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Route_DetectLi@bat_mv+1)
	movf	(0+(?___lldiv)),w
	movwf	(Route_DetectLi@bat_mv)
	line	236
	
l5825:	
	movlw	0Ch
	subwf	(Route_DetectLi@slot_v+1),w
	movlw	0A3h
	skipnz
	subwf	(Route_DetectLi@slot_v),w
	skipnc
	goto	u8201
	goto	u8200
u8201:
	goto	l5829
u8200:
	
l5827:	
	movlw	0EAh
	subwf	(Route_DetectLi@bat_mv+1),w
	movlw	061h
	skipnz
	subwf	(Route_DetectLi@bat_mv),w
	skipc
	goto	u8211
	goto	u8210
u8211:
	goto	l5841
u8210:
	line	238
	
l5829:	
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u8221
	goto	u8220
u8221:
	goto	l5833
u8220:
	line	240
	
l5831:	
	movlw	low(07h)
	movwf	(Route_DetectLi@st)
	line	241
	goto	l5849
	line	244
	
l5833:	
	movlw	low(05h)
	movwf	(Route_DetectLi@st)
	line	245
	
l5835:	
	clrc
	rlf	(Route_DetectLi@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Route_DetectLi@slot_v),w
	movwf	indf
	incf	fsr0,f
	movf	(Route_DetectLi@slot_v+1),w
	movwf	indf
	line	246
	
l5837:	
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	247
	
l5839:	
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_stableCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l5849
	line	252
	
l5841:	
	movlw	low(04h)
	movwf	(Route_DetectLi@st)
	line	253
	
l5843:	
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(080h)
	bsf	status, 7	;select IRP bank3
	andwf	indf,f
	line	255
	
l5845:	
	clrc
	rlf	(Route_DetectLi@idx),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(Route_DetectLi@slot_v),w
	movwf	indf
	incf	fsr0,f
	movf	(Route_DetectLi@slot_v+1),w
	movwf	indf
	goto	l5839
	line	258
	
l5849:	
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	259
	
l5851:	
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	260
	
l5853:	
	movf	(Route_DetectLi@st),w
	line	261
	
l655:	
	return
	opt stack 0
GLOBAL	__end_of_Route_DetectLi
	__end_of_Route_DetectLi:
	signat	_Route_DetectLi,8313
	global	_Get_Vcc

;; *************** function _Get_Vcc *****************
;; Defined at:
;;		line 81 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   25[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  2   76[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;; This function is called by:
;;		_main
;;		_Detect_Classify
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=0
	line	81
global __ptext13
__ptext13:	;psect for function _Get_Vcc
psect	text13
	file	"charge_mgr.c"
	line	81
	global	__size_of_Get_Vcc
	__size_of_Get_Vcc	equ	__end_of_Get_Vcc-_Get_Vcc
	
_Get_Vcc:	
;incstack = 0
	opt	stack 2
; Regs used in _Get_Vcc: [wreg+status,2+status,0+pclath+cstack]
	line	83
	
l5807:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u8171
	goto	u8170
u8171:
	goto	l616
u8170:
	line	85
	
l5809:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Get_Vcc@pt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Get_Vcc@pt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Get_Vcc@pt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Get_Vcc@pt)

	line	86
	
l5811:	
	movf	(Get_Vcc@pt+1),w
	movwf	(_g_vcc_mv+1)
	movf	(Get_Vcc@pt),w
	movwf	(_g_vcc_mv)
	line	89
	
l616:	
	return
	opt stack 0
GLOBAL	__end_of_Get_Vcc
	__end_of_Get_Vcc:
	signat	_Get_Vcc,90
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 142 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2    0[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	line	142
global __ptext14
__ptext14:	;psect for function _Detect_BatteryType
psect	text14
	file	"charge_mgr.c"
	line	142
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	144
	
l5965:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u8371
	goto	u8370
u8371:
	goto	l5971
u8370:
	line	145
	
l5967:	
	movlw	low(0)
	goto	l639
	line	146
	
l5971:	
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u8381
	goto	u8380
u8381:
	goto	l5977
u8380:
	goto	l5967
	line	161
	
l5977:	
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u8391
	goto	u8390
u8391:
	goto	l5985
u8390:
	
l5979:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u8401
	goto	u8400
u8401:
	goto	l5985
u8400:
	line	162
	
l5981:	
	movlw	low(05h)
	goto	l639
	line	167
	
l5985:	
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u8411
	goto	u8410
u8411:
	goto	l5967
u8410:
	
l5987:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u8421
	goto	u8420
u8421:
	goto	l5967
u8420:
	line	168
	
l5989:	
	movlw	low(01h)
	line	171
	
l639:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_Adc_Norm

;; *************** function _Adc_Norm *****************
;; Defined at:
;;		line 98 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  ch              1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  ch              1   28[BANK0 ] unsigned char 
;;  raw             2   29[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   25[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       3       0       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       6       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=0
	line	98
global __ptext15
__ptext15:	;psect for function _Adc_Norm
psect	text15
	file	"charge_mgr.c"
	line	98
	global	__size_of_Adc_Norm
	__size_of_Adc_Norm	equ	__end_of_Adc_Norm-_Adc_Norm
	
_Adc_Norm:	
;incstack = 0
	opt	stack 2
; Regs used in _Adc_Norm: [wreg+status,2+status,0+pclath+cstack]
	movwf	(Adc_Norm@ch)
	line	101
	
l5947:	
	clrf	(ADC_Sample@adldo)
	movf	(Adc_Norm@ch),w
	fcall	_ADC_Sample
	xorlw	0A5h
	skipnz
	goto	u8351
	goto	u8350
u8351:
	goto	l5953
u8350:
	line	102
	
l5949:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(?_Adc_Norm)
	clrf	(?_Adc_Norm+1)
	goto	l620
	line	103
	
l5953:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Adc_Norm@raw+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Adc_Norm@raw)
	line	104
	
l5955:	
	movf	((_g_vcc_mv)),w
iorwf	((_g_vcc_mv+1)),w
	btfss	status,2
	goto	u8361
	goto	u8360
u8361:
	goto	l5961
u8360:
	line	105
	
l5957:	
	movf	(Adc_Norm@raw+1),w
	movwf	(?_Adc_Norm+1)
	movf	(Adc_Norm@raw),w
	movwf	(?_Adc_Norm)
	goto	l620
	line	106
	
l5961:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	movf	(Adc_Norm@raw),w
	movwf	(___lmul@multiplier)
	movf	(Adc_Norm@raw+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movf	(_g_vcc_mv),w
	movwf	(___lmul@multiplicand)
	movf	(_g_vcc_mv+1),w
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(?_Adc_Norm+1)
	movf	(0+(?___lldiv)),w
	movwf	(?_Adc_Norm)
	line	107
	
l620:	
	return
	opt stack 0
GLOBAL	__end_of_Adc_Norm
	__end_of_Adc_Norm:
	signat	_Adc_Norm,4218
	global	_Sense_Pins_Restore

;; *************** function _Sense_Pins_Restore *****************
;; Defined at:
;;		line 545 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	545
global __ptext16
__ptext16:	;psect for function _Sense_Pins_Restore
psect	text16
	file	"main.c"
	line	545
	global	__size_of_Sense_Pins_Restore
	__size_of_Sense_Pins_Restore	equ	__end_of_Sense_Pins_Restore-_Sense_Pins_Restore
	
_Sense_Pins_Restore:	
;incstack = 0
	opt	stack 4
; Regs used in _Sense_Pins_Restore: [wreg+status,2+status,0]
	line	547
	
l6459:	
	movlw	low(0F0h)
	iorwf	(133)^080h,f	;volatile
	line	548
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(5),f	;volatile
	line	549
	movlw	low(0F0h)
	bsf	status, 6	;RP1=1, select bank2
	iorwf	(276)^0100h,f	;volatile
	line	550
	movlw	low(07h)
	iorwf	(261)^0100h,f	;volatile
	line	551
	
l6461:	
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	552
	
l6463:	
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	553
	
l6465:	
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	554
	
l6467:	
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	555
	
l492:	
	return
	opt stack 0
GLOBAL	__end_of_Sense_Pins_Restore
	__end_of_Sense_Pins_Restore:
	signat	_Sense_Pins_Restore,89
	global	_Sense_Pins_AsSink

;; *************** function _Sense_Pins_AsSink *****************
;; Defined at:
;;		line 533 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=0
	line	533
global __ptext17
__ptext17:	;psect for function _Sense_Pins_AsSink
psect	text17
	file	"main.c"
	line	533
	global	__size_of_Sense_Pins_AsSink
	__size_of_Sense_Pins_AsSink	equ	__end_of_Sense_Pins_AsSink-_Sense_Pins_AsSink
	
_Sense_Pins_AsSink:	
;incstack = 0
	opt	stack 4
; Regs used in _Sense_Pins_AsSink: [wreg+status,2+status,0]
	line	536
	
l6433:	
	movlw	low(0Fh)
	andwf	(147)^080h,f	;volatile
	movlw	low(0Fh)
	andwf	(133)^080h,f	;volatile
	
l6435:	
	bcf	(1076/8)^080h,(1076)&7	;volatile
	
l6437:	
	bcf	(1077/8)^080h,(1077)&7	;volatile
	
l6439:	
	bcf	(1078/8)^080h,(1078)&7	;volatile
	
l6441:	
	bcf	(1079/8)^080h,(1079)&7	;volatile
	line	538
	movlw	low(0CFh)
	andwf	(148)^080h,f	;volatile
	movlw	low(0CFh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(5),f	;volatile
	
l6443:	
	bcf	(52/8),(52)&7	;volatile
	
l6445:	
	bcf	(53/8),(53)&7	;volatile
	line	540
	movlw	low(0C3h)
	bsf	status, 5	;RP0=1, select bank1
	andwf	(140)^080h,f	;volatile
	movlw	low(0C3h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	andwf	(276)^0100h,f	;volatile
	
l6447:	
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	
l6449:	
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	
l6451:	
	bcf	(2108/8)^0100h,(2108)&7	;volatile
	
l6453:	
	bcf	(2109/8)^0100h,(2109)&7	;volatile
	line	542
	movlw	low(0FCh)
	andwf	(265)^0100h,f	;volatile
	movlw	low(0FCh)
	andwf	(261)^0100h,f	;volatile
	
l6455:	
	bcf	(2096/8)^0100h,(2096)&7	;volatile
	
l6457:	
	bcf	(2097/8)^0100h,(2097)&7	;volatile
	line	543
	
l489:	
	return
	opt stack 0
GLOBAL	__end_of_Sense_Pins_AsSink
	__end_of_Sense_Pins_AsSink:
	signat	_Sense_Pins_AsSink,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 109 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   29[BANK0 ] unsigned long 
;;  temp_x10        2   35[BANK0 ] unsigned int 
;;  ntcVal          2   33[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   84[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 100/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	109
global __ptext18
__ptext18:	;psect for function _Read_Temperature
psect	text18
	file	"charge_mgr.c"
	line	109
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 3
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	114
	
l7581:	
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_test_adc)^080h
	line	115
	
l7583:	
		movlw	165
	xorwf	((_test_adc)^080h),w
	btfsc	status,2
	goto	u11681
	goto	u11680
u11681:
	goto	l7587
u11680:
	goto	l625
	line	118
	
l7587:	
	movf	(_adresult+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Read_Temperature@ntcVal+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Read_Temperature@ntcVal)
	line	119
	movlw	0
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u11691
	goto	u11690
u11691:
	goto	l625
u11690:
	
l7589:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u11701
	goto	u11700
u11701:
	goto	l7591
u11700:
	goto	l625
	line	124
	
l7591:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	010h
	movwf	(___lldiv@divisor+1)
	movlw	0
	movwf	(___lldiv@divisor)

	movf	(Read_Temperature@ntcVal),w
	movwf	((??_Read_Temperature+0)+0)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((??_Read_Temperature+0)+0+1)
	clrf	((??_Read_Temperature+0)+0+2)
	clrf	((??_Read_Temperature+0)+0+3)
	movf	0+(??_Read_Temperature+0)+0,w
	subwf	(___lldiv@divisor),f
	movf	1+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)+0,w
	goto	u11715
	goto	u11716
u11715:
	subwf	(___lldiv@divisor+1),f
u11716:
	movf	2+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)+0,w
	goto	u11717
	goto	u11718
u11717:
	subwf	(___lldiv@divisor+2),f
u11718:
	movf	3+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)+0,w
	goto	u11719
	goto	u11710
u11719:
	subwf	(___lldiv@divisor+3),f
u11710:

	movf	(Read_Temperature@ntcVal),w
	movwf	(___lmul@multiplier)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	027h
	movwf	(___lmul@multiplicand+1)
	movlw	010h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Read_Temperature@rt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Read_Temperature@rt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@rt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@rt)

	line	125
	
l7593:	
		movf	(Read_Temperature@rt+3),w
	btfss	status,2
	goto	u11720
	movf	(Read_Temperature@rt+2),w
	btfss	status,2
	goto	u11720
	movlw	39
	subwf	(Read_Temperature@rt+1),w
	skipz
	goto	u11723
	movlw	16
	subwf	(Read_Temperature@rt),w
	skipz
	goto	u11723
u11723:
	btfss	status,0
	goto	u11721
	goto	u11720

u11721:
	goto	l7599
u11720:
	line	126
	
l7595:	
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l7597:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0F0h
	movwf	((??_Read_Temperature+0)+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+3)
	movf	(Read_Temperature@rt),w
	addwf	(??_Read_Temperature+0)+0,f
	movf	(Read_Temperature@rt+1),w
	skipnc
	incfsz	(Read_Temperature@rt+1),w
	goto	u11730
	goto	u11731
u11730:
	addwf	(??_Read_Temperature+0)+1,f
u11731:
	movf	(Read_Temperature@rt+2),w
	skipnc
	incfsz	(Read_Temperature@rt+2),w
	goto	u11732
	goto	u11733
u11732:
	addwf	(??_Read_Temperature+0)+2,f
u11733:
	movf	(Read_Temperature@rt+3),w
	skipnc
	incf	(Read_Temperature@rt+3),w
	addwf	(??_Read_Temperature+0)+3,f
	movf	3+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+3)
	movf	2+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+2)
	movf	1+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+1)
	movf	0+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier)

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(0+(?___lldiv)),w
	subwf	(Read_Temperature@temp_x10),f
	movf	(1+(?___lldiv)),w
	skipc
	decf	(Read_Temperature@temp_x10+1),f
	subwf	(Read_Temperature@temp_x10+1),f
	goto	l7603
	line	128
	
l7599:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0
	movwf	(___lmul@multiplier+3)
	movlw	0
	movwf	(___lmul@multiplier+2)
	movlw	027h
	movwf	(___lmul@multiplier+1)
	movlw	010h
	movwf	(___lmul@multiplier)

	movf	(Read_Temperature@rt),w
	subwf	(___lmul@multiplier),f
	movf	(Read_Temperature@rt+1),w
	skipc
	incfsz	(Read_Temperature@rt+1),w
	subwf	(___lmul@multiplier+1),f
	movf	(Read_Temperature@rt+2),w
	skipc
	incfsz	(Read_Temperature@rt+2),w
	subwf	(___lmul@multiplier+2),f
	movf	(Read_Temperature@rt+3),w
	skipc
	incfsz	(Read_Temperature@rt+3),w
	subwf	(___lmul@multiplier+3),f
	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10)
	
l7601:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10),f
	skipnc
	incf	(Read_Temperature@temp_x10+1),f
	line	129
	
l7603:	
	movlw	0
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipnc
	goto	u11741
	goto	u11740
u11741:
	goto	l631
u11740:
	
l7605:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l631:	
	line	130
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipc
	goto	u11751
	goto	u11750
u11751:
	goto	l632
u11750:
	
l7607:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)
	movlw	02h
	movwf	((Read_Temperature@temp_x10))+1
	
l632:	
	line	133
	movf	(Read_Temperature@temp_x10+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_temperature+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(Read_Temperature@temp_x10),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_temperature)^080h
	line	134
	
l7609:	
	movlw	0Ah
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u11761
	goto	u11760
u11761:
	goto	l7613
u11760:
	line	135
	
l7611:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	incf	(_g_tempProtect)^080h,f
	goto	l625
	line	136
	
l7613:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u11771
	goto	u11770
u11771:
	goto	l625
u11770:
	line	137
	
l7615:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	line	140
	
l625:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	_Print_SystemStatus

;; *************** function _Print_SystemStatus *****************
;; Defined at:
;;		line 355 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  d               2   54[BANK0 ] int 
;;  t               1   53[BANK0 ] unsigned char 
;;  bat_mv_long     4   48[BANK0 ] unsigned long 
;;  tc              1   52[BANK0 ] unsigned char 
;;  vx_mv           4   42[BANK0 ] unsigned long 
;;  v               2   40[BANK0 ] unsigned int 
;;  s               1   37[BANK0 ] unsigned char 
;;  pt              4   33[BANK0 ] unsigned long 
;;  vcc_mv          2   46[BANK0 ] unsigned int 
;;  i               1   56[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      28       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      32       0       0       0
;;Total ram usage:       32 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ADC_Sample
;;		___bmul
;;		___lldiv
;;		___lmul
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	355
global __ptext19
__ptext19:	;psect for function _Print_SystemStatus
psect	text19
	file	"main.c"
	line	355
	global	__size_of_Print_SystemStatus
	__size_of_Print_SystemStatus	equ	__end_of_Print_SystemStatus-_Print_SystemStatus
	
_Print_SystemStatus:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_SystemStatus: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	360
	
l6251:	
	movlw	low(((STR_4)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_4)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	361
	movlw	low(((STR_5)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_5)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	362
	movlw	low(((STR_6)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_6)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	365
	
l6253:	
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_test_adc)^080h
	line	366
	
l6255:	
		movlw	165
	xorwf	((_test_adc)^080h),w
	btfss	status,2
	goto	u8701
	goto	u8700
u8701:
	goto	l6261
u8700:
	line	368
	
l6257:	
	movf	(_adresult)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Print_SystemStatus@pt)

	line	369
	
l6259:	
	movf	(Print_SystemStatus@pt+1),w
	movwf	(Print_SystemStatus@vcc_mv+1)
	movf	(Print_SystemStatus@pt),w
	movwf	(Print_SystemStatus@vcc_mv)
	line	370
	goto	l446
	line	372
	
l6261:	
	movlw	088h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Print_SystemStatus@vcc_mv)
	movlw	013h
	movwf	((Print_SystemStatus@vcc_mv))+1
	
l446:	
	line	374
	movf	(Print_SystemStatus@vcc_mv+1),w
	movwf	(_g_vcc_mv+1)
	movf	(Print_SystemStatus@vcc_mv),w
	movwf	(_g_vcc_mv)
	line	376
	
l6263:	
	movlw	low(((STR_7)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_7)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	377
	
l6265:	
	movf	(Print_SystemStatus@vcc_mv+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@vcc_mv),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	378
	
l6267:	
	movlw	low(((STR_8)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_8)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	379
	
l6269:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(_Print_SystemStatus$792+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_Print_SystemStatus$792)
	
l6271:	
	movf	(_Print_SystemStatus$792+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$792),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	380
	
l6273:	
	movlw	low(((STR_9)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_9)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	381
	
l6275:	
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	movwf	(_Print_SystemStatus$793+1)
	movf	(0+(?___lwmod)),w
	movwf	(_Print_SystemStatus$793)
	
l6277:	
	movf	(_Print_SystemStatus$793+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$793),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	382
	
l6279:	
	movlw	low(((STR_10)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_10)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	383
	
l6281:	
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectOwner)^080h),w
	btfsc	status,2
	goto	u8711
	goto	u8710
u8711:
	goto	l6285
u8710:
	
l6283:	
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_SystemStatus$293)
	clrf	(_Print_SystemStatus$293+1)
	goto	l6287
	
l6285:	
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Print_SystemStatus$293)
	clrf	(_Print_SystemStatus$293+1)
	
l6287:	
	movf	(_Print_SystemStatus$293+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_SystemStatus$293),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	384
	
l6289:	
	movlw	low(((STR_11)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_11)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	389
	
l6291:	
	clrf	(Print_SystemStatus@i)
	line	394
	
l6297:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Print_SystemStatus@v)
	incf	fsr0,f
	movf	indf,w
	movwf	(Print_SystemStatus@v+1)
	line	395
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Print_SystemStatus@s)
	line	397
	
l6299:	
	movlw	low(042h)
	fcall	_uart_send_char
	line	398
	
l6301:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@i),w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	incf	(uart_send_number@num),f
	skipnz
	incf	(uart_send_number@num+1),f
	fcall	_uart_send_number
	line	399
	movlw	low(03Dh)
	fcall	_uart_send_char
	line	400
	
l6303:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@v+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@v),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	406
	
l6305:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@v),w
	movwf	(___lmul@multiplier)
	movf	(Print_SystemStatus@v+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(Print_SystemStatus@vx_mv)

	
l6307:	
	movlw	0Ch
u8725:
	clrc
	rrf	(Print_SystemStatus@vx_mv+3),f
	rrf	(Print_SystemStatus@vx_mv+2),f
	rrf	(Print_SystemStatus@vx_mv+1),f
	rrf	(Print_SystemStatus@vx_mv),f
	addlw	-1
	skipz
	goto	u8725

	line	407
	
l6309:	
	movlw	0C8h
	movwf	((??_Print_SystemStatus+0)+0)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+3)
	movf	(Print_SystemStatus@vx_mv),w
	addwf	(??_Print_SystemStatus+0)+0,f
	movf	(Print_SystemStatus@vx_mv+1),w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+1),w
	goto	u8730
	goto	u8731
u8730:
	addwf	(??_Print_SystemStatus+0)+1,f
u8731:
	movf	(Print_SystemStatus@vx_mv+2),w
	skipnc
	incfsz	(Print_SystemStatus@vx_mv+2),w
	goto	u8732
	goto	u8733
u8732:
	addwf	(??_Print_SystemStatus+0)+2,f
u8733:
	movf	(Print_SystemStatus@vx_mv+3),w
	skipnc
	incf	(Print_SystemStatus@vx_mv+3),w
	addwf	(??_Print_SystemStatus+0)+3,f
		movf	(??_Print_SystemStatus+0)+3,w
	btfss	status,2
	goto	u8740
	movf	(??_Print_SystemStatus+0)+2,w
	btfss	status,2
	goto	u8740
	movlw	19
	subwf	(??_Print_SystemStatus+0)+1,w
	skipz
	goto	u8743
	movlw	136
	subwf	(??_Print_SystemStatus+0)+0,w
	skipz
	goto	u8743
u8743:
	btfss	status,0
	goto	u8741
	goto	u8740

u8741:
	goto	l6313
u8740:
	line	409
	
l6311:	
	movlw	low(((STR_12)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_12)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	410
	goto	l6325
	line	413
	
l6313:	
	movf	(Print_SystemStatus@vx_mv+3),w
	movwf	(___lmul@multiplier+3)
	movf	(Print_SystemStatus@vx_mv+2),w
	movwf	(___lmul@multiplier+2)
	movf	(Print_SystemStatus@vx_mv+1),w
	movwf	(___lmul@multiplier+1)
	movf	(Print_SystemStatus@vx_mv),w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+3)
	movf	(2+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+2)
	movf	(1+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long+1)
	movf	(0+(?___lmul)),w
	movwf	(Print_SystemStatus@bat_mv_long)

	
l6315:	
	movlw	070h
	addwf	(Print_SystemStatus@bat_mv_long),f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Print_SystemStatus@bat_mv_long+1),f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Print_SystemStatus@bat_mv_long+2),f
	movlw	0
	skipnc
movlw 1
	addwf	(Print_SystemStatus@bat_mv_long+3),f
	line	414
	
l6317:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Print_SystemStatus+0)+0)
	movlw	01h
	movwf	((??_Print_SystemStatus+0)+0+1)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+2)
	movlw	0
	movwf	((??_Print_SystemStatus+0)+0+3)
	movf	(Print_SystemStatus@bat_mv_long),w
	addwf	(??_Print_SystemStatus+0)+0,f
	movf	(Print_SystemStatus@bat_mv_long+1),w
	skipnc
	incfsz	(Print_SystemStatus@bat_mv_long+1),w
	goto	u8750
	goto	u8751
u8750:
	addwf	(??_Print_SystemStatus+0)+1,f
u8751:
	movf	(Print_SystemStatus@bat_mv_long+2),w
	skipnc
	incfsz	(Print_SystemStatus@bat_mv_long+2),w
	goto	u8752
	goto	u8753
u8752:
	addwf	(??_Print_SystemStatus+0)+2,f
u8753:
	movf	(Print_SystemStatus@bat_mv_long+3),w
	skipnc
	incf	(Print_SystemStatus@bat_mv_long+3),w
	addwf	(??_Print_SystemStatus+0)+3,f
	movf	3+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Print_SystemStatus+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+3)
	movf	(2+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+2)
	movf	(1+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long+1)
	movf	(0+(?___lldiv)),w
	movwf	(Print_SystemStatus@bat_mv_long)

	line	415
	
l6319:	
	movlw	low(((STR_13)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_13)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	416
	
l6321:	
	movf	(Print_SystemStatus@bat_mv_long+1),w
	movwf	(uart_send_number@num+1)
	movf	(Print_SystemStatus@bat_mv_long),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	417
	
l6323:	
	movlw	low(((STR_14)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_14)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	422
	
l6325:	
	movlw	low(020h)
	fcall	_uart_send_char
	line	423
	goto	l6381
	line	425
	
l6327:	
	movlw	low(((STR_15)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_15)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6383
	line	427
	
l6329:	
	movlw	low(((STR_16)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_16)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	428
	
l6331:	
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	((??_Print_SystemStatus+0)+0),w
iorwf	((??_Print_SystemStatus+0)+1),w
	btfsc	status,2
	goto	u8761
	goto	u8760
u8761:
	goto	l6383
u8760:
	line	430
	
l6333:	
	movlw	low(((STR_17)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_17)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	431
	
l6335:	
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(uart_send_number@num)
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	goto	l6383
	line	434
	
l6337:	
	movlw	low(((STR_18)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_18)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6383
	line	435
	
l6339:	
	movlw	low(((STR_19)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_19)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6383
	line	436
	
l6341:	
	movlw	low(((STR_20)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_20)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6383
	line	437
	
l6343:	
	movlw	low(((STR_21)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_21)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6383
	line	438
	
l6345:	
	movlw	low(((STR_22)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_22)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6383
	line	441
	
l6347:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Print_SystemStatus@t)
	line	442
	
l6349:	
		movlw	2
	xorwf	((Print_SystemStatus@t)),w
	btfsc	status,2
	goto	u8771
	goto	u8770
u8771:
	goto	l6353
u8770:
	
l6351:	
		movlw	3
	xorwf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u8781
	goto	u8780
u8781:
	goto	l6355
u8780:
	line	443
	
l6353:	
	movlw	low(((STR_23)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_23)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6365
	line	444
	
l6355:	
		decf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u8791
	goto	u8790
u8791:
	goto	l6359
u8790:
	line	445
	
l6357:	
	movlw	low(((STR_24)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_24)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6365
	line	446
	
l6359:	
		movlw	6
	xorwf	((Print_SystemStatus@t)),w
	btfss	status,2
	goto	u8801
	goto	u8800
u8801:
	goto	l6363
u8800:
	line	447
	
l6361:	
	movlw	low(((STR_25)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_25)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6365
	line	449
	
l6363:	
	movlw	low(((STR_26)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_26)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	450
	
l6365:	
	clrc
	rlf	(Print_SystemStatus@i),w
	addlw	low(_g_slotRefV|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	((??_Print_SystemStatus+0)+0),w
iorwf	((??_Print_SystemStatus+0)+1),w
	btfsc	status,2
	goto	u8811
	goto	u8810
u8811:
	goto	l6383
u8810:
	line	452
	
l6367:	
	movlw	low(((STR_27)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_27)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6335
	line	457
	
l6371:	
	movlw	low(((STR_28)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_28)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6383
	line	459
	
l6373:	
	movlw	low(((STR_29)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_29)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	460
	movlw	low(((STR_30)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_30)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	461
	
l6375:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(uart_send_number@num)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(uart_send_number@num)
	fcall	_uart_send_number
	line	462
	goto	l6383
	line	463
	
l6377:	
	movlw	low(((STR_31)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_31)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	goto	l6383
	line	423
	
l6381:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@s),w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l6327
	xorlw	1^0	; case 1
	skipnz
	goto	l6329
	xorlw	2^1	; case 2
	skipnz
	goto	l6337
	xorlw	3^2	; case 3
	skipnz
	goto	l6339
	xorlw	4^3	; case 4
	skipnz
	goto	l6341
	xorlw	5^4	; case 5
	skipnz
	goto	l6343
	xorlw	6^5	; case 6
	skipnz
	goto	l6345
	xorlw	7^6	; case 7
	skipnz
	goto	l6347
	xorlw	8^7	; case 8
	skipnz
	goto	l6371
	xorlw	9^8	; case 9
	skipnz
	goto	l6373
	goto	l6377
	opt asmopt_pop

	line	467
	
l6383:	
	movlw	low(((STR_32)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_32)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	468
	
l6385:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(uart_send_number@num)
	incf	fsr0,f
	movf	indf,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	469
	
l6387:	
	movlw	low(((STR_33)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_33)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	470
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Print_SystemStatus@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(uart_send_number@num)
	clrf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	473
	
l6389:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	((_g_diodeTraceCnt)^080h),w
	btfsc	status,2
	goto	u8821
	goto	u8820
u8821:
	goto	l6425
u8820:
	
l6391:	
	movf	(_g_diodeTraceSlot)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Print_SystemStatus@i),w
	skipz
	goto	u8831
	goto	u8830
u8831:
	goto	l6425
u8830:
	line	476
	
l6393:	
	movlw	low(((STR_34)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_34)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	477
	
l6395:	
	clrf	(Print_SystemStatus@tc)
	goto	l6419
	line	479
	
l6397:	
	movf	(Print_SystemStatus@tc),w
	addlw	low(_g_diodeTrace|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(Print_SystemStatus@d)
	clrf	(Print_SystemStatus@d+1)
	
l6399:	
	movlw	-128
	addwf	(Print_SystemStatus@d),f
	skipc
	decf	(Print_SystemStatus@d+1),f
	line	480
	
l6401:	
	btfss	(Print_SystemStatus@d+1),7
	goto	u8841
	goto	u8840
u8841:
	goto	l6407
u8840:
	line	482
	
l6403:	
	movlw	low(02Dh)
	fcall	_uart_send_char
	line	483
	
l6405:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	comf	(Print_SystemStatus@d),f
	comf	(Print_SystemStatus@d+1),f
	incf	(Print_SystemStatus@d),f
	skipnz
	incf	(Print_SystemStatus@d+1),f
	line	484
	goto	l6411
	line	485
	
l6407:	
	movf	(Print_SystemStatus@d+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u8855
	movlw	01h
	subwf	(Print_SystemStatus@d),w
u8855:

	skipc
	goto	u8851
	goto	u8850
u8851:
	goto	l6411
u8850:
	line	486
	
l6409:	
	movlw	low(02Bh)
	fcall	_uart_send_char
	line	487
	
l6411:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Print_SystemStatus@d+1),w
	movwf	(??_Print_SystemStatus+0)+0+1
	movf	(Print_SystemStatus@d),w
	movwf	(??_Print_SystemStatus+0)+0
	clrc
	rlf	(??_Print_SystemStatus+0)+0,f
	rlf	(??_Print_SystemStatus+0)+1,f
	clrc
	rlf	(??_Print_SystemStatus+0)+0,f
	rlf	(??_Print_SystemStatus+0)+1,f
	movf	0+(??_Print_SystemStatus+0)+0,w
	movwf	(uart_send_number@num)
	movf	1+(??_Print_SystemStatus+0)+0,w
	movwf	(uart_send_number@num+1)
	fcall	_uart_send_number
	line	488
	
l6413:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_diodeTraceCnt)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Print_SystemStatus+0)+0
	clrf	(??_Print_SystemStatus+0)+0+1
	movf	(Print_SystemStatus@tc),w
	addlw	low(01h)
	movwf	(??_Print_SystemStatus+2)+0
	movlw	high(01h)
	skipnc
	movlw	(high(01h)+1)&0ffh
	movwf	((??_Print_SystemStatus+2)+0)+1
	movf	1+(??_Print_SystemStatus+0)+0,w
	subwf	1+(??_Print_SystemStatus+2)+0,w
	skipz
	goto	u8865
	movf	0+(??_Print_SystemStatus+0)+0,w
	subwf	0+(??_Print_SystemStatus+2)+0,w
u8865:
	skipnc
	goto	u8861
	goto	u8860
u8861:
	goto	l6417
u8860:
	line	489
	
l6415:	
	movlw	low(02Ch)
	fcall	_uart_send_char
	line	477
	
l6417:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Print_SystemStatus@tc),f
	
l6419:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_diodeTraceCnt)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Print_SystemStatus@tc),w
	skipc
	goto	u8871
	goto	u8870
u8871:
	goto	l6397
u8870:
	line	491
	
l6421:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_diodeTraceCnt)^080h
	line	492
	
l6423:	
	movlw	low(0FFh)
	movwf	(_g_diodeTraceSlot)^080h
	line	496
	
l6425:	
	movlw	low(((STR_35)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_35)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	389
	
l6427:	
	incf	(Print_SystemStatus@i),f
	
l6429:	
	movlw	low(0Ch)
	subwf	(Print_SystemStatus@i),w
	skipc
	goto	u8881
	goto	u8880
u8881:
	goto	l6297
u8880:
	line	499
	
l6431:	
	movlw	low(((STR_36)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_36)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	500
	
l486:	
	return
	opt stack 0
GLOBAL	__end_of_Print_SystemStatus
	__end_of_Print_SystemStatus:
	signat	_Print_SystemStatus,89
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    0[BANK0 ] unsigned long 
;;  multiplicand    4    4[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    8[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    0[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Route_DetectLi
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext20
__ptext20:	;psect for function ___lmul
psect	text20
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 1
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l5745:	
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l1072:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u8081
	goto	u8080
u8081:
	goto	l5749
u8080:
	line	122
	
l5747:	
	movf	(___lmul@multiplicand),w
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8091
	addwf	(___lmul@product+1),f
u8091:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8092
	addwf	(___lmul@product+2),f
u8092:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8093
	addwf	(___lmul@product+3),f
u8093:

	line	123
	
l5749:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l5751:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u8101
	goto	u8100
u8101:
	goto	l1072
u8100:
	line	128
	
l5753:	
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l1075:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4   12[BANK0 ] unsigned long 
;;  dividend        4   16[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   20[BANK0 ] unsigned long 
;;  counter         1   24[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4   12[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      13       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Route_DetectLi
;;		_Slot_Charge_Ctrl
;;		_Get_Vcc
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext21
__ptext21:	;psect for function ___lldiv
psect	text21
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l5757:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l5759:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u8111
	goto	u8110
u8111:
	goto	l5779
u8110:
	line	16
	
l5761:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l5765
	line	18
	
l5763:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l5765:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u8121
	goto	u8120
u8121:
	goto	l5763
u8120:
	line	22
	
l5767:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l5769:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u8135
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u8135
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u8135
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u8135:
	skipc
	goto	u8131
	goto	u8130
u8131:
	goto	l5775
u8130:
	line	24
	
l5771:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l5773:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l5775:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l5777:	
	decfsz	(___lldiv@counter),f
	goto	u8141
	goto	u8140
u8141:
	goto	l5767
u8140:
	line	30
	
l5779:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l1347:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    0[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    6[BANK0 ] unsigned char 
;;  j               1    5[BANK0 ] unsigned char 
;;  adsum           4    8[BANK0 ] volatile unsigned long 
;;  ad_temp         2   16[BANK0 ] volatile unsigned int 
;;  admax           2   14[BANK0 ] volatile unsigned int 
;;  admin           2   12[BANK0 ] volatile unsigned int 
;;  i               1    7[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      18       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_Get_Vcc
;;		_Adc_Norm
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	file	"adc_drv.c"
	line	49
global __ptext22
__ptext22:	;psect for function _ADC_Sample
psect	text22
	file	"adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 2
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
	movwf	(ADC_Sample@adch)
	line	51
	
l5679:	
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	52
	
l5681:	
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	53
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	54
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	58
	
l5683:	
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u7931
	goto	u7930
u7931:
	goto	l5689
u7930:
	
l5685:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u7941
	goto	u7940
u7941:
	goto	l5689
u7940:
	line	60
	
l5687:	
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	61
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u11897:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u11897
	nop
opt asmopt_pop

	line	62
	goto	l5691
	line	64
	
l5689:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	67
	
l5691:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(ADC_Sample@adch),(4)&7
	goto	u7951
	goto	u7950
u7951:
	goto	l540
u7950:
	line	69
	
l5693:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l5695:	
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(ADC_Sample@adch),f
	line	71
	goto	l5697
	line	72
	
l540:	
	line	73
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l5697:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@i)
	line	79
	
l5703:	
	movf	(ADC_Sample@adch),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u7965:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u7965
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l5705:	
	opt asmopt_push
opt asmopt_off
	movlw	5
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u11907:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u11907
	nop2
opt asmopt_pop

	line	81
	
l5707:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l5709:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	85
	goto	l544
	
l545:	
	line	87
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u7971
	goto	u7970
u7971:
	goto	l544
u7970:
	line	89
	
l5711:	
	movlw	low(0)
	goto	l547
	line	90
	
l544:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u7981
	goto	u7980
u7981:
	goto	l545
u7980:
	line	93
	
l5715:	
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
l5717:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
l5719:	
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u7991
	goto	u7990
u7991:
	goto	l5723
u7990:
	line	98
	
l5721:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	99
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	100
	goto	l550
	line	102
	
l5723:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u8005
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u8005:
	skipnc
	goto	u8001
	goto	u8000
u8001:
	goto	l5727
u8000:
	line	103
	
l5725:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	l550
	line	105
	
l5727:	
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u8015
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u8015:
	skipnc
	goto	u8011
	goto	u8010
u8011:
	goto	l550
u8010:
	line	106
	
l5729:	
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	108
	
l550:	
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8021
	addwf	(ADC_Sample@adsum+1),f	;volatile
u8021:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8022
	addwf	(ADC_Sample@adsum+2),f	;volatile
u8022:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8023
	addwf	(ADC_Sample@adsum+3),f	;volatile
u8023:

	line	76
	
l5731:	
	incf	(ADC_Sample@i),f
	
l5733:	
	movlw	low(022h)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u8031
	goto	u8030
u8031:
	goto	l5703
u8030:
	line	112
	
l5735:	
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u8045
	goto	u8046
u8045:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u8046:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u8047
	goto	u8048
u8047:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u8048:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u8049
	goto	u8040
u8049:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u8040:

	line	113
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u8055
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u8055
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u8055
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u8055:
	skipc
	goto	u8051
	goto	u8050
u8051:
	goto	l554
u8050:
	line	114
	
l5737:	
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u8065
	goto	u8066
u8065:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u8066:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u8067
	goto	u8068
u8067:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u8068:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u8069
	goto	u8060
u8069:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u8060:

	goto	l5739
	line	115
	
l554:	
	line	116
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	118
	
l5739:	
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u8075:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u8070:
	addlw	-1
	skipz
	goto	u8075
	movf	1+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_adresult+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_adresult)^080h
	line	119
	
l5741:	
	movlw	low(0A5h)
	line	120
	
l547:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Print_NtcTemp

;; *************** function _Print_NtcTemp *****************
;; Defined at:
;;		line 334 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_number
;;		_uart_send_string
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	334
global __ptext23
__ptext23:	;psect for function _Print_NtcTemp
psect	text23
	file	"main.c"
	line	334
	global	__size_of_Print_NtcTemp
	__size_of_Print_NtcTemp	equ	__end_of_Print_NtcTemp-_Print_NtcTemp
	
_Print_NtcTemp:	
;incstack = 0
	opt	stack 2
; Regs used in _Print_NtcTemp: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	336
	
l6239:	
	movlw	low(((STR_1)|8000h))
	movwf	(uart_send_string@str)
	movlw	high(((STR_1)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	337
	
l6241:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$790+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_Print_NtcTemp$790)
	
l6243:	
	movf	(_Print_NtcTemp$790+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$790),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	338
	
l6245:	
	movlw	low(((STR_2)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_2)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	339
	
l6247:	
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_temperature)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(1+(?___lwmod)),w
	movwf	(_Print_NtcTemp$791+1)
	movf	(0+(?___lwmod)),w
	movwf	(_Print_NtcTemp$791)
	movf	(_Print_NtcTemp$791+1),w
	movwf	(uart_send_number@num+1)
	movf	(_Print_NtcTemp$791),w
	movwf	(uart_send_number@num)
	fcall	_uart_send_number
	line	340
	
l6249:	
	movlw	low(((STR_3)|8000h))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_string@str)
	movlw	high(((STR_3)|8000h))
	movwf	((uart_send_string@str))+1
	fcall	_uart_send_string
	line	341
	
l442:	
	return
	opt stack 0
GLOBAL	__end_of_Print_NtcTemp
	__end_of_Print_NtcTemp:
	signat	_Print_NtcTemp,89
	global	_uart_send_string

;; *************** function _uart_send_string *****************
;; Defined at:
;;		line 61 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  str             2    3[BANK0 ] PTR const unsigned char 
;;		 -> STR_38(10), STR_37(21), STR_36(3), STR_35(3), 
;;		 -> STR_34(5), STR_33(5), STR_32(5), STR_31(6), 
;;		 -> STR_30(6), STR_29(6), STR_28(6), STR_27(6), 
;;		 -> STR_26(6), STR_25(16), STR_24(13), STR_23(15), 
;;		 -> STR_22(7), STR_21(5), STR_20(5), STR_19(6), 
;;		 -> STR_18(6), STR_17(6), STR_16(6), STR_15(7), 
;;		 -> STR_14(4), STR_13(6), STR_12(6), STR_11(3), 
;;		 -> STR_10(9), STR_9(2), STR_8(6), STR_7(5), 
;;		 -> STR_6(6), STR_5(8), STR_4(25), STR_3(4), 
;;		 -> STR_2(2), STR_1(5), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;;		_main
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=0
	file	"uart_dbg.c"
	line	61
global __ptext24
__ptext24:	;psect for function _uart_send_string
psect	text24
	file	"uart_dbg.c"
	line	61
	global	__size_of_uart_send_string
	__size_of_uart_send_string	equ	__end_of_uart_send_string-_uart_send_string
	
_uart_send_string:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_string: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	63
	
l5911:	
	goto	l5917
	line	65
	
l5913:	
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	fcall	_uart_send_char
	
l5915:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(uart_send_string@str),f
	skipnz
	incf	(uart_send_string@str+1),f
	line	66
# 66 "uart_dbg.c"
clrwdt ;# 
psect	text24
	line	63
	
l5917:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(uart_send_string@str+1),w
	movwf	btemp+1
	movf	(uart_send_string@str),w
	movwf	fsr0
	fcall	stringtab
	xorlw	0
	skipz
	goto	u8311
	goto	u8310
u8311:
	goto	l5913
u8310:
	line	68
	
l571:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_string
	__end_of_uart_send_string:
	signat	_uart_send_string,4217
	global	_uart_send_number

;; *************** function _uart_send_number *****************
;; Defined at:
;;		line 77 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  num             2    7[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  buf             6    9[BANK0 ] unsigned char [6]
;;  j               1   16[BANK0 ] unsigned char 
;;  i               1   15[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      10       0       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lwdiv
;;		___lwmod
;;		_uart_send_char
;; This function is called by:
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=0
	line	77
global __ptext25
__ptext25:	;psect for function _uart_send_number
psect	text25
	file	"uart_dbg.c"
	line	77
	global	__size_of_uart_send_number
	__size_of_uart_send_number	equ	__end_of_uart_send_number-_uart_send_number
	
_uart_send_number:	
;incstack = 0
	opt	stack 2
; Regs used in _uart_send_number: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	80
	
l5919:	
	clrf	(uart_send_number@i)
	line	84
	
l5921:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u8321
	goto	u8320
u8321:
	goto	l5933
u8320:
	line	86
	
l5923:	
	movlw	low(030h)
	fcall	_uart_send_char
	goto	l575
	line	93
	
l5927:	
	movf	(uart_send_number@i),w
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	0Ah
	movwf	(___lwmod@divisor)
	clrf	(___lwmod@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwmod@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwmod@dividend)
	fcall	___lwmod
	movf	(0+(?___lwmod)),w
	addlw	030h
	bcf	status, 7	;select IRP bank0
	movwf	indf
	
l5929:	
	incf	(uart_send_number@i),f
	line	94
	
l5931:	
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(uart_send_number@num+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(uart_send_number@num),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(uart_send_number@num+1)
	movf	(0+(?___lwdiv)),w
	movwf	(uart_send_number@num)
	line	91
	
l5933:	
	movf	((uart_send_number@num)),w
iorwf	((uart_send_number@num+1)),w
	btfss	status,2
	goto	u8331
	goto	u8330
u8331:
	goto	l5927
u8330:
	line	98
	
l5935:	
	movf	(uart_send_number@i),w
	movwf	(uart_send_number@j)
	
l5937:	
	movf	((uart_send_number@j)),w
	btfss	status,2
	goto	u8341
	goto	u8340
u8341:
	goto	l5941
u8340:
	goto	l575
	line	99
	
l5941:	
	movf	(uart_send_number@j),w
	addlw	0FFh
	addlw	low(uart_send_number@buf|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	fcall	_uart_send_char
	line	98
	
l5943:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decf	(uart_send_number@j),f
	goto	l5937
	line	100
	
l575:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_number
	__end_of_uart_send_number:
	signat	_uart_send_number,4217
	global	_uart_send_char

;; *************** function _uart_send_char *****************
;; Defined at:
;;		line 35 in file "uart_dbg.c"
;; Parameters:    Size  Location     Type
;;  c               1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  c               1    1[BANK0 ] unsigned char 
;;  i               1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Print_SystemStatus
;;		_uart_send_string
;;		_uart_send_number
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=0
	line	35
global __ptext26
__ptext26:	;psect for function _uart_send_char
psect	text26
	file	"uart_dbg.c"
	line	35
	global	__size_of_uart_send_char
	__size_of_uart_send_char	equ	__end_of_uart_send_char-_uart_send_char
	
_uart_send_char:	
;incstack = 0
	opt	stack 3
; Regs used in _uart_send_char: [wreg+status,2+status,0]
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(uart_send_char@c)
	line	38
	
l5783:	
	bcf	(95/8),(95)&7	;volatile
	line	39
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	40
	
l5785:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u11917:
decfsz	(??_uart_send_char+0)+0,f
	goto	u11917
	nop2
opt asmopt_pop

	line	41
	
l5787:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(uart_send_char@i)
	line	42
	
l561:	
	line	43
	btfss	(uart_send_char@c),(0)&7
	goto	u8151
	goto	u8150
u8151:
	goto	l563
u8150:
	line	44
	
l5793:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	goto	l5795
	line	45
	
l563:	
	line	46
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	47
	
l5795:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u11927:
decfsz	(??_uart_send_char+0)+0,f
	goto	u11927
	nop2
opt asmopt_pop

	line	48
	
l5797:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rrf	(uart_send_char@c),f
	line	41
	
l5799:	
	incf	(uart_send_char@i),f
	
l5801:	
	movlw	low(08h)
	subwf	(uart_send_char@i),w
	skipc
	goto	u8161
	goto	u8160
u8161:
	goto	l561
u8160:
	
l562:	
	line	50
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	51
	
l5803:	
	opt asmopt_push
opt asmopt_off
	movlw	137
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_uart_send_char+0)+0),f
	u11937:
decfsz	(??_uart_send_char+0)+0,f
	goto	u11937
	nop2
opt asmopt_pop

	line	52
	
l5805:	
	bsf	(95/8),(95)&7	;volatile
	line	53
	
l565:	
	return
	opt stack 0
GLOBAL	__end_of_uart_send_char
	__end_of_uart_send_char:
	signat	_uart_send_char,4217
	global	___lwmod

;; *************** function ___lwmod *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK0 ] unsigned int 
;;  dividend        2    2[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  counter         1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       5       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
global __ptext27
__ptext27:	;psect for function ___lwmod
psect	text27
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwmod.c"
	line	6
	global	__size_of___lwmod
	__size_of___lwmod	equ	__end_of___lwmod-___lwmod
	
___lwmod:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwmod: [wreg+status,2+status,0]
	line	13
	
l5883:	
	movf	((___lwmod@divisor)),w
iorwf	((___lwmod@divisor+1)),w
	btfsc	status,2
	goto	u8271
	goto	u8270
u8271:
	goto	l5899
u8270:
	line	14
	
l5885:	
	clrf	(___lwmod@counter)
	incf	(___lwmod@counter),f
	line	15
	goto	l5889
	line	16
	
l5887:	
	clrc
	rlf	(___lwmod@divisor),f
	rlf	(___lwmod@divisor+1),f
	line	17
	incf	(___lwmod@counter),f
	line	15
	
l5889:	
	btfss	(___lwmod@divisor+1),(15)&7
	goto	u8281
	goto	u8280
u8281:
	goto	l5887
u8280:
	line	20
	
l5891:	
	movf	(___lwmod@divisor+1),w
	subwf	(___lwmod@dividend+1),w
	skipz
	goto	u8295
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),w
u8295:
	skipc
	goto	u8291
	goto	u8290
u8291:
	goto	l5895
u8290:
	line	21
	
l5893:	
	movf	(___lwmod@divisor),w
	subwf	(___lwmod@dividend),f
	movf	(___lwmod@divisor+1),w
	skipc
	decf	(___lwmod@dividend+1),f
	subwf	(___lwmod@dividend+1),f
	line	22
	
l5895:	
	clrc
	rrf	(___lwmod@divisor+1),f
	rrf	(___lwmod@divisor),f
	line	23
	
l5897:	
	decfsz	(___lwmod@counter),f
	goto	u8301
	goto	u8300
u8301:
	goto	l5891
u8300:
	line	25
	
l5899:	
	movf	(___lwmod@dividend+1),w
	movwf	(?___lwmod+1)
	movf	(___lwmod@dividend),w
	movwf	(?___lwmod)
	line	26
	
l1410:	
	return
	opt stack 0
GLOBAL	__end_of___lwmod
	__end_of___lwmod:
	signat	___lwmod,8314
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK0 ] unsigned int 
;;  dividend        2    2[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    5[BANK0 ] unsigned int 
;;  counter         1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       7       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_uart_send_number
;;		_Read_Temperature
;;		_Detect_Classify
;;		_Print_NtcTemp
;;		_Print_SystemStatus
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext28
__ptext28:	;psect for function ___lwdiv
psect	text28
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l5857:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l5859:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u8231
	goto	u8230
u8231:
	goto	l5879
u8230:
	line	16
	
l5861:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l5865
	line	18
	
l5863:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l5865:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u8241
	goto	u8240
u8241:
	goto	l5863
u8240:
	line	22
	
l5867:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l5869:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u8255
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u8255:
	skipc
	goto	u8251
	goto	u8250
u8251:
	goto	l5875
u8250:
	line	24
	
l5871:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l5873:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l5875:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l5877:	
	decfsz	(___lwdiv@counter),f
	goto	u8261
	goto	u8260
u8261:
	goto	l5867
u8260:
	line	30
	
l5879:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l1400:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	_Display_Service

;; *************** function _Display_Service *****************
;; Defined at:
;;		line 577 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 800/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	577
global __ptext29
__ptext29:	;psect for function _Display_Service
psect	text29
	file	"main.c"
	line	577
	global	__size_of_Display_Service
	__size_of_Display_Service	equ	__end_of_Display_Service-_Display_Service
	
_Display_Service:	
;incstack = 0
	opt	stack 4
; Regs used in _Display_Service: [wreg+status,2+status,0]
	line	581
	
l6475:	
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	582
	
l6477:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	((_g_sinkMask)^080h),w	;volatile
iorwf	((_g_sinkMask+1)^080h),w	;volatile
	btfss	status,2
	goto	u8911
	goto	u8910
u8911:
	goto	l504
u8910:
	goto	l503
	line	584
	
l505:	
	line	585
# 585 "main.c"
clrwdt ;# 
psect	text29
	
l504:	
	line	584
	btfss	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	goto	u8921
	goto	u8920
u8921:
	goto	l505
u8920:
	goto	l507
	line	586
	
l508:	
	line	587
# 587 "main.c"
clrwdt ;# 
psect	text29
	
l507:	
	line	586
	btfsc	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	goto	u8931
	goto	u8930
u8931:
	goto	l508
u8930:
	line	588
	
l503:	
	return
	opt stack 0
GLOBAL	__end_of_Display_Service
	__end_of_Display_Service:
	signat	_Display_Service,89
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 1500 in file "charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2   16[BANK0 ] unsigned int 
;;  s               1   27[BANK0 ] unsigned char 
;;  duty            2   24[BANK0 ] int 
;;  error           2   20[BANK0 ] int 
;;  adjust          2   10[BANK0 ] int 
;;  duty_initial    1   23[BANK0 ] unsigned char 
;;  duty_target     1   22[BANK0 ] unsigned char 
;;  maxV            2   18[BANK0 ] unsigned int 
;;  i               1   26[BANK0 ] unsigned char 
;;  preCount        1   15[BANK0 ] unsigned char 
;;  ccCount         1   14[BANK0 ] unsigned char 
;;  cvCount         1   13[BANK0 ] unsigned char 
;;  hasCharging     1   12[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          0       2       0       0       0
;;      Totals:         0      20       0       0       0
;;Total ram usage:       20 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___awdiv
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text30,local,class=CODE,delta=2,merge=1,group=0
	file	"charge_mgr.c"
	line	1500
global __ptext30
__ptext30:	;psect for function _CCCV_Control
psect	text30
	file	"charge_mgr.c"
	line	1500
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 3
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1503
	
l7319:	
	clrf	(CCCV_Control@hasCharging)
	line	1504
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	1505
	clrf	(CCCV_Control@cvCount)
	line	1506
	clrf	(CCCV_Control@ccCount)
	line	1507
	clrf	(CCCV_Control@preCount)
	line	1510
	
l7321:	
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u11121
	goto	u11120
u11121:
	goto	l7327
u11120:
	line	1512
	
l7323:	
	movlw	011h
	subwf	(_g_vcc_mv+1),w
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv),w
	skipc
	goto	u11131
	goto	u11130
u11131:
	goto	l7331
u11130:
	line	1513
	
l7325:	
	clrf	(_g_vccProtect)^080h
	goto	l7331
	line	1517
	
l7327:	
	movlw	011h
	subwf	(_g_vcc_mv+1),w
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv),w
	skipnc
	goto	u11141
	goto	u11140
u11141:
	goto	l7331
u11140:
	line	1518
	
l7329:	
	clrf	(_g_vccProtect)^080h
	incf	(_g_vccProtect)^080h,f
	line	1522
	
l7331:	
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u11151
	goto	u11150
u11151:
	goto	l7335
u11150:
	
l7333:	
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u11161
	goto	u11160
u11161:
	goto	l7339
u11160:
	line	1524
	
l7335:	
	clrf	(_g_pwmDuty)	;volatile
	line	1525
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	l978
	line	1530
	
l7339:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(CCCV_Control@i)
	line	1532
	
l7345:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(CCCV_Control@s)
	line	1536
	
l7347:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u11171
	goto	u11170
u11171:
	goto	l983
u11170:
	
l7349:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u11181
	goto	u11180
u11181:
	goto	l983
u11180:
	
l7351:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u11191
	goto	u11190
u11191:
	goto	l983
u11190:
	
l7353:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u11201
	goto	u11200
u11201:
	goto	l983
u11200:
	
l7355:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u11211
	goto	u11210
u11211:
	goto	l981
u11210:
	
l983:	
	line	1538
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	1540
	
l7357:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	1541
	
l7359:	
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u11225
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u11225:
	skipnc
	goto	u11221
	goto	u11220
u11221:
	goto	l7363
u11220:
	
l7361:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	1543
	
l7363:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u11231
	goto	u11230
u11231:
	goto	l7367
u11230:
	line	1544
	
l7365:	
	incf	(CCCV_Control@cvCount),f
	line	1545
	
l7367:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u11241
	goto	u11240
u11241:
	goto	l7371
u11240:
	line	1546
	
l7369:	
	incf	(CCCV_Control@ccCount),f
	line	1547
	
l7371:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u11251
	goto	u11250
u11251:
	goto	l7375
u11250:
	
l7373:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u11261
	goto	u11260
u11261:
	goto	l981
u11260:
	line	1548
	
l7375:	
	incf	(CCCV_Control@preCount),f
	line	1549
	
l981:	
	line	1530
	incf	(CCCV_Control@i),f
	
l7377:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u11271
	goto	u11270
u11271:
	goto	l7345
u11270:
	line	1553
	
l7379:	
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u11281
	goto	u11280
u11281:
	goto	l7385
u11280:
	goto	l7335
	line	1564
	
l7385:	
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u11291
	goto	u11290
u11291:
	goto	l7415
u11290:
	line	1568
	
l7387:	
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u11301
	goto	u11300
u11301:
	goto	l7391
u11300:
	line	1571
	
l7389:	
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	1572
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	1573
	goto	l7399
	line	1574
	
l7391:	
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u11311
	goto	u11310
u11311:
	goto	l7395
u11310:
	line	1577
	
l7393:	
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	1578
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	1579
	goto	l7399
	line	1584
	
l7395:	
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	l978
	line	1588
	
l7399:	
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u11321
	goto	u11320
u11321:
	goto	l7407
u11320:
	line	1591
	
l7401:	
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	1592
	
l7403:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u11331
	goto	u11330
u11331:
	goto	l978
u11330:
	line	1593
	
l7405:	
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	l978
	line	1595
	
l7407:	
	line	1598
	
l7409:	
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	1599
	goto	l978
	line	1614
	
l7415:	
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	1617
	movf	(CCCV_Control@error),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral)^080h,f
	skipnc
	incf	(_g_cvIntegral+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(CCCV_Control@error+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral+1)^080h,f
	line	1618
	
l7417:	
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u11345
	movlw	0C9h
	subwf	(_g_cvIntegral)^080h,w
u11345:

	skipc
	goto	u11341
	goto	u11340
u11341:
	goto	l7421
u11340:
	line	1619
	
l7419:	
	movlw	0C8h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	l7425
	line	1620
	
l7421:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u11355
	movlw	038h
	subwf	(_g_cvIntegral)^080h,w
u11355:

	skipnc
	goto	u11351
	goto	u11350
u11351:
	goto	l7425
u11350:
	line	1621
	
l7423:	
	movlw	038h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	movlw	0FFh
	movwf	((_g_cvIntegral)^080h)+1
	line	1624
	
l7425:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_cvIntegral)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_cvIntegral+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	1625
	
l7427:	
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
l7429:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	1628
	
l7431:	
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u11365
	movlw	021h
	subwf	(CCCV_Control@duty),w
u11365:

	skipc
	goto	u11361
	goto	u11360
u11361:
	goto	l7435
u11360:
	
l7433:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1629
	
l7435:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u11371
	goto	u11370
u11371:
	goto	l7439
u11370:
	
l7437:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1631
	
l7439:	
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	1633
	
l978:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    2[BANK0 ] unsigned char 
;;  product         1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Print_SystemStatus
;;		_Slot_Charge_Ctrl
;;		_CCCV_Control
;;		_Update_LED_Global
;; This function uses a non-reentrant model
;;
psect	text31,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext31
__ptext31:	;psect for function ___bmul
psect	text31
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___bmul: [wreg+status,2+status,0]
	movwf	(___bmul@multiplier)
	line	6
	
l6111:	
	clrf	(___bmul@product)
	line	43
	
l6113:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u8601
	goto	u8600
u8601:
	goto	l6117
u8600:
	line	44
	
l6115:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l6117:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l6119:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u8611
	goto	u8610
u8611:
	goto	l6113
u8610:
	line	50
	
l6121:	
	movf	(___bmul@product),w
	line	51
	
l1081:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK0 ] int 
;;  dividend        2    2[BANK0 ] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[BANK0 ] int 
;;  sign            1    5[BANK0 ] unsigned char 
;;  counter         1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       8       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text32,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext32
__ptext32:	;psect for function ___awdiv
psect	text32
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
l6125:	
	clrf	(___awdiv@sign)
	line	15
	
l6127:	
	btfss	(___awdiv@divisor+1),7
	goto	u8621
	goto	u8620
u8621:
	goto	l6133
u8620:
	line	16
	
l6129:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
l6131:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
l6133:	
	btfss	(___awdiv@dividend+1),7
	goto	u8631
	goto	u8630
u8631:
	goto	l6139
u8630:
	line	20
	
l6135:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
l6137:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
l6139:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
l6141:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u8641
	goto	u8640
u8641:
	goto	l6161
u8640:
	line	25
	
l6143:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	l6147
	line	27
	
l6145:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
l6147:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u8651
	goto	u8650
u8651:
	goto	l6145
u8650:
	line	31
	
l6149:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
l6151:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u8665
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u8665:
	skipc
	goto	u8661
	goto	u8660
u8661:
	goto	l6157
u8660:
	line	33
	
l6153:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
l6155:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
l6157:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
l6159:	
	decfsz	(___awdiv@counter),f
	goto	u8671
	goto	u8670
u8671:
	goto	l6149
u8670:
	line	39
	
l6161:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u8681
	goto	u8680
u8681:
	goto	l6165
u8680:
	line	40
	
l6163:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
l6165:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
l1193:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 228 in file "main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          3       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_PowerOnLedSequence
;;		_Sink_Set
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text33,local,class=CODE,delta=2,merge=1,group=0
	file	"main.c"
	line	228
global __ptext33
__ptext33:	;psect for function _Isr_Timer
psect	text33
	file	"main.c"
	line	228
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 1
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	ljmp	_Isr_Timer
psect	text33
	line	231
	
i1l5535:	
	btfss	(90/8),(90)&7	;volatile
	goto	u770_21
	goto	u770_20
u770_21:
	goto	i1l430
u770_20:
	line	233
	
i1l5537:	
	bcf	(90/8),(90)&7	;volatile
	line	234
	
i1l5539:	
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(129)^080h	;volatile
	line	235
# 235 "main.c"
clrwdt ;# 
psect	text33
	line	238
	
i1l5541:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(_g_pwmCounter)^080h,f	;volatile
	line	239
	
i1l5543:	
	movlw	low(020h)
	subwf	(_g_pwmCounter)^080h,w	;volatile
	skipc
	goto	u771_21
	goto	u771_20
u771_21:
	goto	i1l5547
u771_20:
	line	240
	
i1l5545:	
	clrf	(_g_pwmCounter)^080h	;volatile
	line	242
	
i1l5547:	
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u772_21
	goto	u772_20
u772_21:
	goto	i1l424
u772_20:
	
i1l5549:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter)^080h,w	;volatile
	skipnc
	goto	u773_21
	goto	u773_20
u773_21:
	goto	i1l424
u773_20:
	line	243
	
i1l5551:	
	bcf	status, 5	;RP0=0, select bank0
	bsf	(55/8),(55)&7	;volatile
	goto	i1l5553
	line	244
	
i1l424:	
	line	245
	bcf	status, 5	;RP0=0, select bank0
	bcf	(55/8),(55)&7	;volatile
	line	251
	
i1l5553:	
	movlw	low(050h)
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_hwTickDiv)^080h,f	;volatile
	subwf	((_g_hwTickDiv)^080h),w	;volatile
	skipc
	goto	u774_21
	goto	u774_20
u774_21:
	goto	i1l5569
u774_20:
	line	253
	
i1l5555:	
	clrf	(_g_hwTickDiv)^080h	;volatile
	line	254
	
i1l5557:	
	incf	(_g_hwTick)^080h,f	;volatile
	skipnz
	incf	(_g_hwTick+1)^080h,f	;volatile
	line	255
	
i1l5559:	
	movlw	low(02h)
	subwf	(_g_powerOnPhase)^080h,w
	skipnc
	goto	u775_21
	goto	u775_20
u775_21:
	goto	i1l5563
u775_20:
	line	256
	
i1l5561:	
	incf	(_g_powerOnTimer)^080h,f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1)^080h,f	;volatile
	line	258
	
i1l5563:	
	incf	(_g_printTick)^080h,f	;volatile
	skipnz
	incf	(_g_printTick+1)^080h,f	;volatile
	movlw	0
	subwf	((_g_printTick+1)^080h),w	;volatile
	movlw	0C8h
	skipnz
	subwf	((_g_printTick)^080h),w	;volatile
	skipc
	goto	u776_21
	goto	u776_20
u776_21:
	goto	i1l5569
u776_20:
	line	260
	
i1l5565:	
	clrf	(_g_printTick)^080h	;volatile
	clrf	(_g_printTick+1)^080h	;volatile
	line	261
	
i1l5567:	
	bsf	(_g_printFlag/8),(_g_printFlag)&7	;volatile
	line	270
	
i1l5569:	
	movlw	low(02h)
	subwf	(_g_powerOnPhase)^080h,w	;volatile
	skipnc
	goto	u777_21
	goto	u777_20
u777_21:
	goto	i1l5575
u777_20:
	line	272
	
i1l5571:	
	fcall	_PowerOnLedSequence
	goto	i1l430
	line	273
	
i1l5573:	
	goto	i1l430
	line	277
	
i1l5575:	
	movf	((_g_tempPhase)^080h),w	;volatile
	btfss	status,2
	goto	u778_21
	goto	u778_20
u778_21:
	goto	i1l5587
u778_20:
	line	279
	
i1l5577:	
	incf	(_g_tempReadRoundCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1)^080h,f	;volatile
	line	280
	
i1l5579:	
	movlw	0
	subwf	(_g_tempReadRoundCnt+1)^080h,w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt)^080h,w	;volatile
	skipc
	goto	u779_21
	goto	u779_20
u779_21:
	goto	i1l5595
u779_20:
	line	282
	
i1l5581:	
	clrf	(_g_tempReadRoundCnt)^080h	;volatile
	clrf	(_g_tempReadRoundCnt+1)^080h	;volatile
	line	283
	
i1l5583:	
	movlw	low(01h)
	movwf	(_g_tempPhase)^080h	;volatile
	line	284
	
i1l5585:	
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	goto	i1l5595
	line	289
	
i1l5587:	
	incf	(_g_tempSettleCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1)^080h,f	;volatile
	line	290
	
i1l5589:	
	movlw	0
	subwf	(_g_tempSettleCnt+1)^080h,w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt)^080h,w	;volatile
	skipc
	goto	u780_21
	goto	u780_20
u780_21:
	goto	i1l5595
u780_20:
	line	292
	
i1l5591:	
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	293
	
i1l5593:	
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	line	294
	clrf	(_g_tempPhase)^080h	;volatile
	line	308
	
i1l5595:	
		movlw	28
	xorwf	((_g_pwmCounter)^080h),w	;volatile
	btfss	status,2
	goto	u781_21
	goto	u781_20
u781_21:
	goto	i1l5605
u781_20:
	line	310
	
i1l5597:	
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u782_21
	goto	u782_20
u782_21:
	goto	i1l430
u782_20:
	
i1l5599:	
	movf	((_g_sinkMask)^080h),w	;volatile
iorwf	((_g_sinkMask+1)^080h),w	;volatile
	btfsc	status,2
	goto	u783_21
	goto	u783_20
u783_21:
	goto	i1l430
u783_20:
	line	312
	
i1l5601:	
	movf	(_g_sinkMask+1)^080h,w	;volatile
	movwf	(Sink_Set@mask+1)
	movf	(_g_sinkMask)^080h,w	;volatile
	movwf	(Sink_Set@mask)
	clrf	(Sink_Set@on)
	incf	(Sink_Set@on),f
	fcall	_Sink_Set
	line	313
	
i1l5603:	
	bsf	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	goto	i1l430
	line	316
	
i1l5605:	
	movf	((_g_pwmCounter)^080h),w
	btfss	status,2
	goto	u784_21
	goto	u784_20
u784_21:
	goto	i1l430
u784_20:
	line	318
	
i1l5607:	
	btfss	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	goto	u785_21
	goto	u785_20
u785_21:
	goto	i1l5573
u785_20:
	line	322
	
i1l5609:	
	movlw	0FFh
	movwf	(Sink_Set@mask)
	movlw	0Fh
	movwf	((Sink_Set@mask))+1
	clrf	(Sink_Set@on)
	fcall	_Sink_Set
	line	323
	
i1l5611:	
	bcf	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	line	327
	
i1l430:	
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	_Sink_Set

;; *************** function _Sink_Set *****************
;; Defined at:
;;		line 202 in file "main.c"
;; Parameters:    Size  Location     Type
;;  mask            2    1[COMMON] unsigned int 
;;  on              1    3[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  i               1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         3       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		_Sink_Slot_Off
;;		_Sink_Slot_On
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text34,local,class=CODE,delta=2,merge=1,group=0
	line	202
global __ptext34
__ptext34:	;psect for function _Sink_Set
psect	text34
	file	"main.c"
	line	202
	global	__size_of_Sink_Set
	__size_of_Sink_Set	equ	__end_of_Sink_Set-_Sink_Set
	
_Sink_Set:	
;incstack = 0
	opt	stack 1
; Regs used in _Sink_Set: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	205
	
i1l4117:	
	clrf	(Sink_Set@i)
	line	206
	
i1l412:	
	line	207
	btfss	(Sink_Set@mask),(0)&7
	goto	u455_21
	goto	u455_20
u455_21:
	goto	i1l4129
u455_20:
	line	209
	
i1l4123:	
	movf	((Sink_Set@on)),w
	btfsc	status,2
	goto	u456_21
	goto	u456_20
u456_21:
	goto	i1l4127
u456_20:
	line	210
	
i1l4125:	
	movf	(Sink_Set@i),w
	fcall	_Sink_Slot_On
	goto	i1l4129
	line	212
	
i1l4127:	
	movf	(Sink_Set@i),w
	fcall	_Sink_Slot_Off
	line	214
	
i1l4129:	
	clrc
	rrf	(Sink_Set@mask+1),f
	rrf	(Sink_Set@mask),f
	line	205
	
i1l4131:	
	incf	(Sink_Set@i),f
	
i1l4133:	
	movlw	low(0Ch)
	subwf	(Sink_Set@i),w
	skipc
	goto	u457_21
	goto	u457_20
u457_21:
	goto	i1l412
u457_20:
	line	216
	
i1l417:	
	return
	opt stack 0
GLOBAL	__end_of_Sink_Set
	__end_of_Sink_Set:
	signat	_Sink_Set,8313
	global	_Sink_Slot_On

;; *************** function _Sink_Slot_On *****************
;; Defined at:
;;		line 161 in file "main.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    0[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 0/100
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         1       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Sink_Set
;; This function uses a non-reentrant model
;;
psect	text35,local,class=CODE,delta=2,merge=1,group=0
	line	161
global __ptext35
__ptext35:	;psect for function _Sink_Slot_On
psect	text35
	file	"main.c"
	line	161
	global	__size_of_Sink_Slot_On
	__size_of_Sink_Slot_On	equ	__end_of_Sink_Slot_On-_Sink_Slot_On
	
_Sink_Slot_On:	
;incstack = 0
	opt	stack 1
; Regs used in _Sink_Slot_On: [wreg-fsr0h+status,2+status,0]
	movwf	(Sink_Slot_On@idx)
	line	163
	
i1l3777:	
	goto	i1l3781
	line	165
	
i1l377:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(265)^0100h+(1/8),(1)&7	;volatile
	bcf	(261)^0100h+(1/8),(1)&7	;volatile
	bcf	(2097/8)^0100h,(2097)&7	;volatile
	goto	i1l391
	line	166
	
i1l379:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(265)^0100h+(0/8),(0)&7	;volatile
	bcf	(261)^0100h+(0/8),(0)&7	;volatile
	bcf	(2096/8)^0100h,(2096)&7	;volatile
	goto	i1l391
	line	167
	
i1l380:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(148)^080h+(4/8),(4)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	(5)+(4/8),(4)&7	;volatile
	bcf	(52/8),(52)&7	;volatile
	goto	i1l391
	line	168
	
i1l381:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(148)^080h+(5/8),(5)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	(5)+(5/8),(5)&7	;volatile
	bcf	(53/8),(53)&7	;volatile
	goto	i1l391
	line	169
	
i1l382:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(147)^080h+(5/8),(5)&7	;volatile
	bcf	(133)^080h+(5/8),(5)&7	;volatile
	bcf	(1077/8)^080h,(1077)&7	;volatile
	goto	i1l391
	line	170
	
i1l383:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(147)^080h+(4/8),(4)&7	;volatile
	bcf	(133)^080h+(4/8),(4)&7	;volatile
	bcf	(1076/8)^080h,(1076)&7	;volatile
	goto	i1l391
	line	171
	
i1l384:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(140)^080h+(4/8),(4)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(276)^0100h+(4/8),(4)&7	;volatile
	bcf	(2108/8)^0100h,(2108)&7	;volatile
	goto	i1l391
	line	172
	
i1l385:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(140)^080h+(5/8),(5)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(276)^0100h+(5/8),(5)&7	;volatile
	bcf	(2109/8)^0100h,(2109)&7	;volatile
	goto	i1l391
	line	173
	
i1l386:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(140)^080h+(3/8),(3)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(276)^0100h+(3/8),(3)&7	;volatile
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l391
	line	174
	
i1l387:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(140)^080h+(2/8),(2)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(276)^0100h+(2/8),(2)&7	;volatile
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l391
	line	175
	
i1l388:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(147)^080h+(7/8),(7)&7	;volatile
	bcf	(133)^080h+(7/8),(7)&7	;volatile
	bcf	(1079/8)^080h,(1079)&7	;volatile
	goto	i1l391
	line	176
	
i1l389:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(147)^080h+(6/8),(6)&7	;volatile
	bcf	(133)^080h+(6/8),(6)&7	;volatile
	bcf	(1078/8)^080h,(1078)&7	;volatile
	goto	i1l391
	line	163
	
i1l3781:	
	movf	(Sink_Slot_On@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l377
	xorlw	1^0	; case 1
	skipnz
	goto	i1l379
	xorlw	2^1	; case 2
	skipnz
	goto	i1l380
	xorlw	3^2	; case 3
	skipnz
	goto	i1l381
	xorlw	4^3	; case 4
	skipnz
	goto	i1l382
	xorlw	5^4	; case 5
	skipnz
	goto	i1l383
	xorlw	6^5	; case 6
	skipnz
	goto	i1l384
	xorlw	7^6	; case 7
	skipnz
	goto	i1l385
	xorlw	8^7	; case 8
	skipnz
	goto	i1l386
	xorlw	9^8	; case 9
	skipnz
	goto	i1l387
	xorlw	10^9	; case 10
	skipnz
	goto	i1l388
	xorlw	11^10	; case 11
	skipnz
	goto	i1l389
	goto	i1l391
	opt asmopt_pop

	line	179
	
i1l391:	
	return
	opt stack 0
GLOBAL	__end_of_Sink_Slot_On
	__end_of_Sink_Slot_On:
	signat	_Sink_Slot_On,4217
	global	_Sink_Slot_Off

;; *************** function _Sink_Slot_Off *****************
;; Defined at:
;;		line 181 in file "main.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    0[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 0/100
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         1       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Sink_Set
;; This function uses a non-reentrant model
;;
psect	text36,local,class=CODE,delta=2,merge=1,group=0
	line	181
global __ptext36
__ptext36:	;psect for function _Sink_Slot_Off
psect	text36
	file	"main.c"
	line	181
	global	__size_of_Sink_Slot_Off
	__size_of_Sink_Slot_Off	equ	__end_of_Sink_Slot_Off-_Sink_Slot_Off
	
_Sink_Slot_Off:	
;incstack = 0
	opt	stack 1
; Regs used in _Sink_Slot_Off: [wreg-fsr0h+status,2+status,0]
	movwf	(Sink_Slot_Off@idx)
	line	183
	
i1l3783:	
	goto	i1l3787
	line	185
	
i1l395:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(261)^0100h+(1/8),(1)&7	;volatile
	bsf	(265)^0100h+(1/8),(1)&7	;volatile
	goto	i1l409
	line	186
	
i1l397:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(261)^0100h+(0/8),(0)&7	;volatile
	bsf	(265)^0100h+(0/8),(0)&7	;volatile
	goto	i1l409
	line	187
	
i1l398:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(5)+(4/8),(4)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(148)^080h+(4/8),(4)&7	;volatile
	goto	i1l409
	line	188
	
i1l399:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(5)+(5/8),(5)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(148)^080h+(5/8),(5)&7	;volatile
	goto	i1l409
	line	189
	
i1l400:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(133)^080h+(5/8),(5)&7	;volatile
	bsf	(147)^080h+(5/8),(5)&7	;volatile
	goto	i1l409
	line	190
	
i1l401:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(133)^080h+(4/8),(4)&7	;volatile
	bsf	(147)^080h+(4/8),(4)&7	;volatile
	goto	i1l409
	line	191
	
i1l402:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(276)^0100h+(4/8),(4)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(140)^080h+(4/8),(4)&7	;volatile
	goto	i1l409
	line	192
	
i1l403:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(276)^0100h+(5/8),(5)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(140)^080h+(5/8),(5)&7	;volatile
	goto	i1l409
	line	193
	
i1l404:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(276)^0100h+(3/8),(3)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(140)^080h+(3/8),(3)&7	;volatile
	goto	i1l409
	line	194
	
i1l405:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(276)^0100h+(2/8),(2)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(140)^080h+(2/8),(2)&7	;volatile
	goto	i1l409
	line	195
	
i1l406:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(133)^080h+(7/8),(7)&7	;volatile
	bsf	(147)^080h+(7/8),(7)&7	;volatile
	goto	i1l409
	line	196
	
i1l407:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(133)^080h+(6/8),(6)&7	;volatile
	bsf	(147)^080h+(6/8),(6)&7	;volatile
	goto	i1l409
	line	183
	
i1l3787:	
	movf	(Sink_Slot_Off@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l395
	xorlw	1^0	; case 1
	skipnz
	goto	i1l397
	xorlw	2^1	; case 2
	skipnz
	goto	i1l398
	xorlw	3^2	; case 3
	skipnz
	goto	i1l399
	xorlw	4^3	; case 4
	skipnz
	goto	i1l400
	xorlw	5^4	; case 5
	skipnz
	goto	i1l401
	xorlw	6^5	; case 6
	skipnz
	goto	i1l402
	xorlw	7^6	; case 7
	skipnz
	goto	i1l403
	xorlw	8^7	; case 8
	skipnz
	goto	i1l404
	xorlw	9^8	; case 9
	skipnz
	goto	i1l405
	xorlw	10^9	; case 10
	skipnz
	goto	i1l406
	xorlw	11^10	; case 11
	skipnz
	goto	i1l407
	goto	i1l409
	opt asmopt_pop

	line	199
	
i1l409:	
	return
	opt stack 0
GLOBAL	__end_of_Sink_Slot_Off
	__end_of_Sink_Slot_Off:
	signat	_Sink_Slot_Off,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 200 in file "led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text37,local,class=CODE,delta=2,merge=1,group=0
	file	"led.c"
	line	200
global __ptext37
__ptext37:	;psect for function _PowerOnLedSequence
psect	text37
	file	"led.c"
	line	200
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 2
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	204
	
i1l4135:	
	movf	((_g_powerOnPhase)^080h),w	;volatile
	btfss	status,2
	goto	u458_21
	goto	u458_20
u458_21:
	goto	i1l4145
u458_20:
	line	207
	
i1l4137:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	208
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	209
	
i1l4139:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u459_21
	goto	u459_20
u459_21:
	goto	i1l1057
u459_20:
	line	211
	
i1l4141:	
	clrf	(_g_powerOnTimer)^080h	;volatile
	clrf	(_g_powerOnTimer+1)^080h	;volatile
	line	212
	
i1l4143:	
	movlw	low(01h)
	movwf	(_g_powerOnPhase)^080h	;volatile
	goto	i1l1057
	line	215
	
i1l4145:	
		decf	((_g_powerOnPhase)^080h),w	;volatile
	btfss	status,2
	goto	u460_21
	goto	u460_20
u460_21:
	goto	i1l1057
u460_20:
	line	218
	
i1l4147:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	219
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	220
	
i1l4149:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u461_21
	goto	u461_20
u461_21:
	goto	i1l1057
u461_20:
	line	222
	
i1l4151:	
	clrf	(_g_powerOnTimer)^080h	;volatile
	clrf	(_g_powerOnTimer+1)^080h	;volatile
	line	223
	
i1l4153:	
	movlw	low(02h)
	movwf	(_g_powerOnPhase)^080h	;volatile
	line	227
	
i1l1057:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
