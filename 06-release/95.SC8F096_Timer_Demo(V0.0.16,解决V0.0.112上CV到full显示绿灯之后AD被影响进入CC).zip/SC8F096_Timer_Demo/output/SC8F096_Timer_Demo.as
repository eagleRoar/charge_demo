opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	SC8F096
opt include "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\sc8f096.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
# 13 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INDF EQU 00H ;# 
# 20 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPTION_REG EQU 01H ;# 
# 27 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCL EQU 02H ;# 
# 34 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
STATUS EQU 03H ;# 
# 41 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
FSR EQU 04H ;# 
# 48 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISB EQU 05H ;# 
# 55 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTB EQU 06H ;# 
# 62 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDB EQU 07H ;# 
# 69 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUB EQU 08H ;# 
# 76 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCB EQU 09H ;# 
# 83 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PCLATH EQU 0AH ;# 
# 90 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
INTCON EQU 0BH ;# 
# 97 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
QCCON EQU 0CH ;# 
# 104 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR1 EQU 0DH ;# 
# 111 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE1 EQU 0EH ;# 
# 118 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON0 EQU 0FH ;# 
# 125 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP1CON1 EQU 10H ;# 
# 132 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PR2 EQU 11H ;# 
# 139 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR2 EQU 12H ;# 
# 146 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T2CON EQU 13H ;# 
# 153 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OSCCON EQU 14H ;# 
# 160 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON0 EQU 15H ;# 
# 167 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON1 EQU 16H ;# 
# 174 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTL EQU 17H ;# 
# 181 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMTH EQU 18H ;# 
# 188 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD0L EQU 19H ;# 
# 195 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD1L EQU 1AH ;# 
# 202 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD4L EQU 1BH ;# 
# 209 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMT4L EQU 1CH ;# 
# 216 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMCON2 EQU 1DH ;# 
# 223 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMDH EQU 1EH ;# 
# 230 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM01DT EQU 1FH ;# 
# 237 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR0 EQU 81H ;# 
# 244 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISA EQU 85H ;# 
# 251 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTA EQU 86H ;# 
# 258 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPDA EQU 87H ;# 
# 265 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUA EQU 88H ;# 
# 272 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IOCA EQU 89H ;# 
# 279 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL3 EQU 8CH ;# 
# 286 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON1 EQU 8DH ;# 
# 293 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EECON2 EQU 8EH ;# 
# 300 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDAT EQU 8FH ;# 
# 307 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEDATH EQU 90H ;# 
# 314 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADR EQU 91H ;# 
# 321 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
EEADRH EQU 92H ;# 
# 328 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL0 EQU 93H ;# 
# 335 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL1 EQU 94H ;# 
# 342 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON0 EQU 95H ;# 
# 349 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADCON1 EQU 96H ;# 
# 356 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESL EQU 98H ;# 
# 363 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ADRESH EQU 99H ;# 
# 370 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON0 EQU 9AH ;# 
# 377 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD2L EQU 9BH ;# 
# 384 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWMD3L EQU 9CH ;# 
# 391 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PWM23DT EQU 9DH ;# 
# 398 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN0 EQU 9EH ;# 
# 405 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CMP2CON1 EQU 9FH ;# 
# 412 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISC EQU 105H ;# 
# 419 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTC EQU 106H ;# 
# 426 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PORTD EQU 107H ;# 
# 433 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUC EQU 108H ;# 
# 440 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
ANSEL2 EQU 109H ;# 
# 447 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1L EQU 10CH ;# 
# 454 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TMR1H EQU 10DH ;# 
# 461 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
T1CON EQU 10EH ;# 
# 468 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIR2 EQU 10FH ;# 
# 475 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PIE2 EQU 110H ;# 
# 482 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON0 EQU 111H ;# 
# 489 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON1 EQU 112H ;# 
# 496 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYCON2 EQU 113H ;# 
# 503 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TRISD EQU 114H ;# 
# 510 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
WPUD EQU 115H ;# 
# 517 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAL EQU 116H ;# 
# 524 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
KEYDATAH EQU 117H ;# 
# 531 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA0 EQU 118H ;# 
# 538 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA0 EQU 119H ;# 
# 545 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG0 EQU 11AH ;# 
# 552 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG0 EQU 11BH ;# 
# 559 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG0 EQU 11CH ;# 
# 566 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON0 EQU 11DH ;# 
# 573 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDCON1 EQU 11EH ;# 
# 580 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN1 EQU 11FH ;# 
# 587 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN2 EQU 181H ;# 
# 594 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXSTA1 EQU 185H ;# 
# 601 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCSTA1 EQU 186H ;# 
# 608 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
TXREG1 EQU 187H ;# 
# 615 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
RCREG1 EQU 188H ;# 
# 622 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SPBRG1 EQU 189H ;# 
# 629 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPACON EQU 18CH ;# 
# 636 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
OPAADJ EQU 18DH ;# 
# 643 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR0 EQU 18EH ;# 
# 650 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LEDCTR1 EQU 18FH ;# 
# 657 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON EQU 190H ;# 
# 664 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICCON2 EQU 191H ;# 
# 671 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICSTAT EQU 192H ;# 
# 678 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICBUF EQU 193H ;# 
# 685 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
IICADD EQU 194H ;# 
# 692 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC0CON EQU 195H ;# 
# 699 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
CC1CON EQU 196H ;# 
# 706 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON0 EQU 197H ;# 
# 713 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDCON1 EQU 198H ;# 
# 720 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDADD EQU 199H ;# 
# 727 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDRDATA EQU 19AH ;# 
# 734 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
PDSDATA EQU 19BH ;# 
# 741 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDADD EQU 19CH ;# 
# 748 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
LCDDATA EQU 19DH ;# 
# 755 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
COMEN EQU 19EH ;# 
# 762 "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\include\SC8F096.h"
SEGEN3 EQU 19FH ;# 
	FNCALL	_main,_CCCV_Control
	FNCALL	_main,_Display_Service
	FNCALL	_main,_Get_Vcc
	FNCALL	_main,_Read_Temperature
	FNCALL	_main,_Sense_Pins_AsSink
	FNCALL	_main,_Sense_Pins_Restore
	FNCALL	_main,_Slot_Charge_Ctrl
	FNCALL	_main,_System_Init
	FNCALL	_main,_Update_LED_Global
	FNCALL	_main,_Wait_Display_Idle
	FNCALL	_Update_LED_Global,___bmul
	FNCALL	_System_Init,_AD_Init
	FNCALL	_System_Init,___bmul
	FNCALL	_Slot_Charge_Ctrl,_Adc_Norm
	FNCALL	_Slot_Charge_Ctrl,_Detect_BatteryType
	FNCALL	_Slot_Charge_Ctrl,_Detect_Classify
	FNCALL	_Slot_Charge_Ctrl,_Enter_DiodeTest
	FNCALL	_Slot_Charge_Ctrl,_Get_Vcc
	FNCALL	_Slot_Charge_Ctrl,_Route_LiIon
	FNCALL	_Slot_Charge_Ctrl,_Route_LinearLi
	FNCALL	_Slot_Charge_Ctrl,___bmul
	FNCALL	_Slot_Charge_Ctrl,___lldiv
	FNCALL	_Slot_Charge_Ctrl,___wmul
	FNCALL	_Route_LinearLi,_Route_DetectLi
	FNCALL	_Route_LiIon,_Route_DetectLi
	FNCALL	_Detect_Classify,_Get_Vcc
	FNCALL	_Detect_Classify,_Route_DetectLi
	FNCALL	_Detect_Classify,___lwdiv
	FNCALL	_Route_DetectLi,___lldiv
	FNCALL	_Route_DetectLi,___lmul
	FNCALL	_Get_Vcc,_ADC_Sample
	FNCALL	_Get_Vcc,___lldiv
	FNCALL	_Adc_Norm,_ADC_Sample
	FNCALL	_Adc_Norm,___lldiv
	FNCALL	_Adc_Norm,___lmul
	FNCALL	_Read_Temperature,_ADC_Sample
	FNCALL	_Read_Temperature,___lldiv
	FNCALL	_Read_Temperature,___lmul
	FNCALL	_Read_Temperature,___lwdiv
	FNCALL	_CCCV_Control,___awdiv
	FNCALL	_CCCV_Control,___bmul
	FNROOT	_main
	FNCALL	_Isr_Timer,_PowerOnLedSequence
	FNCALL	_Isr_Timer,_Sink_Set
	FNCALL	_Sink_Set,_Sink_Slot_Off
	FNCALL	_Sink_Set,_Sink_Slot_On
	FNCALL	intlevel1,_Isr_Timer
	global	intlevel1
	FNROOT	intlevel1
	global	_g_vcc_mv
	global	_g_elapsedTicks
	global	_g_detectWaiter
	global	_g_detectOwner
psect	idataCOMMON,class=CODE,space=0,delta=2,noexec
global __pidataCOMMON
__pidataCOMMON:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	15

;initializer for _g_vcc_mv
	retlw	088h
	retlw	013h

psect	idataBANK1,class=CODE,space=0,delta=2,noexec
global __pidataBANK1
__pidataBANK1:
	line	29

;initializer for _g_elapsedTicks
	retlw	01h
	retlw	0

	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	35

;initializer for _g_detectWaiter
	retlw	0FFh
	line	29

;initializer for _g_detectOwner
	retlw	0FFh
	global	_s_adcChannels
psect	strings,class=STRING,delta=2,noexec
global __pstrings
__pstrings:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 1 byte each
stringcode:stringdir:
movlw high(stringdir)
movwf pclath
movf fsr,w
incf fsr
	addwf pc
	global __stringbase
__stringbase:
	retlw	0
psect	strings
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	50
_s_adcChannels:
	retlw	011h
	retlw	010h
	retlw	0Ch
	retlw	0Dh
	retlw	05h
	retlw	04h
	retlw	01Ch
	retlw	01Dh
	retlw	01Bh
	retlw	01Ah
	retlw	07h
	retlw	06h
	global __end_of_s_adcChannels
__end_of_s_adcChannels:
	global	_s_adcChannels
	global	_g_impData
	global	_g_pwmDuty
	global	_s_senseRestored
	global	_g_doNtcRead
	global	_g_adcBusy
	global	_g_dispWin
	global	_g_slotRefV
	global	_g_detectLowCnt
	global	_s_work
	global	_g_highVFlag
	global	_g_capFlag
	global	_g_tempReadRoundCnt
	global	_g_tempSettleCnt
	global	_g_sinkMask
	global	_g_lastHwTick
	global	_g_hwTick
	global	_g_powerOnTimer
	global	_g_cvIntegral
	global	_s_ledBlinkCnt
	global	_g_diodeTraceCnt
	global	_g_vccProtect
	global	_g_tempProtect
	global	_test_adc
	global	_g_tempPhase
	global	_g_hwTickDiv
	global	_g_powerOnPhase
	global	_g_pwmCounter
	global	_adresult
	global	_g_slot
	global	_g_stableCnt
	global	_g_ovCnt
	global	_g_ccBlocks
	global	_g_diodeTrace
	global	_OSCCON
_OSCCON	set	20
	global	_INTCON
_INTCON	set	11
	global	_IOCB
_IOCB	set	9
	global	_WPUB
_WPUB	set	8
	global	_WPDB
_WPDB	set	7
	global	_PORTB
_PORTB	set	6
	global	_TRISB
_TRISB	set	5
	global	_OPTION_REG
_OPTION_REG	set	1
	global	_RB1
_RB1	set	0x31
	global	_RB0
_RB0	set	0x30
	global	_RB2
_RB2	set	0x32
	global	_RB3
_RB3	set	0x33
	global	_RB5
_RB5	set	0x35
	global	_RB4
_RB4	set	0x34
	global	_RB7
_RB7	set	0x37
	global	_RB6
_RB6	set	0x36
	global	_T0IF
_T0IF	set	0x5A
	global	_ADRESH
_ADRESH	set	153
	global	_ADRESL
_ADRESL	set	152
	global	_ADCON1
_ADCON1	set	150
	global	_ADCON0
_ADCON0	set	149
	global	_ANSEL1
_ANSEL1	set	148
	global	_ANSEL0
_ANSEL0	set	147
	global	_ANSEL3
_ANSEL3	set	140
	global	_IOCA
_IOCA	set	137
	global	_WPUA
_WPUA	set	136
	global	_WPDA
_WPDA	set	135
	global	_PORTA
_PORTA	set	134
	global	_TRISA
_TRISA	set	133
	global	_TMR0
_TMR0	set	129
	global	_RA2
_RA2	set	0x432
	global	_RA3
_RA3	set	0x433
	global	_RA1
_RA1	set	0x431
	global	_RA0
_RA0	set	0x430
	global	_GODONE
_GODONE	set	0x4A9
	global	_CHS4
_CHS4	set	0x4B6
	global	_LDO_EN
_LDO_EN	set	0x4B2
	global	_RA6
_RA6	set	0x436
	global	_RA7
_RA7	set	0x437
	global	_RA4
_RA4	set	0x434
	global	_RA5
_RA5	set	0x435
	global	_WPUD
_WPUD	set	277
	global	_TRISD
_TRISD	set	276
	global	_ANSEL2
_ANSEL2	set	265
	global	_WPUC
_WPUC	set	264
	global	_PORTD
_PORTD	set	263
	global	_PORTC
_PORTC	set	262
	global	_TRISC
_TRISC	set	261
	global	_RD0
_RD0	set	0x838
	global	_RD1
_RD1	set	0x839
	global	_RD2
_RD2	set	0x83A
	global	_RD3
_RD3	set	0x83B
	global	_RD5
_RD5	set	0x83D
	global	_RD4
_RD4	set	0x83C
	global	_RC0
_RC0	set	0x830
	global	_RC1
_RC1	set	0x831
	global	_RC5
_RC5	set	0x835
	global	_RC4
_RC4	set	0x834
	global	_CC1CON
_CC1CON	set	406
	global	_CC0CON
_CC0CON	set	405
; #config settings
	file	"SC8F096_Timer_Demo.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_s_senseRestored:
       ds      1

_g_doNtcRead:
       ds      1

_g_adcBusy:
       ds      1

_g_dispWin:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_g_impData:
       ds      2

_g_pwmDuty:
       ds      1

psect	dataCOMMON,class=COMMON,space=1,noexec
global __pdataCOMMON
__pdataCOMMON:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	15
_g_vcc_mv:
       ds      2

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_g_slotRefV:
       ds      24

_g_detectLowCnt:
       ds      12

_s_work:
       ds      6

_g_highVFlag:
       ds      2

_g_capFlag:
       ds      2

_g_tempReadRoundCnt:
       ds      2

_g_tempSettleCnt:
       ds      2

_g_sinkMask:
       ds      2

_g_lastHwTick:
       ds      2

_g_hwTick:
       ds      2

_g_powerOnTimer:
       ds      2

_g_cvIntegral:
       ds      2

_s_ledBlinkCnt:
       ds      1

_g_diodeTraceCnt:
       ds      1

_g_vccProtect:
       ds      1

_g_tempProtect:
       ds      1

_test_adc:
       ds      1

_g_tempPhase:
       ds      1

_g_hwTickDiv:
       ds      1

_g_powerOnPhase:
       ds      1

_g_pwmCounter:
       ds      1

_adresult:
       ds      2

psect	dataBANK1,class=BANK1,space=1,noexec
global __pdataBANK1
__pdataBANK1:
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	29
_g_elapsedTicks:
       ds      2

psect	dataBANK1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	35
_g_detectWaiter:
       ds      1

psect	dataBANK1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	29
_g_detectOwner:
       ds      1

psect	bssBANK3,class=BANK3,space=1,noexec
global __pbssBANK3
__pbssBANK3:
_g_stableCnt:
       ds      12

_g_ovCnt:
       ds      12

_g_ccBlocks:
       ds      12

_g_diodeTrace:
       ds      4

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_g_slot:
       ds      72

	file	"SC8F096_Timer_Demo.as"
	line	#
; Initialize objects allocated to BANK1
	global __pidataBANK1
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 5	;RP0=1, select bank1
	fcall	__pidataBANK1+0		;fetch initializer
	movwf	__pdataBANK1+0&07fh		
	fcall	__pidataBANK1+1		;fetch initializer
	movwf	__pdataBANK1+1&07fh		
	fcall	__pidataBANK1+2		;fetch initializer
	movwf	__pdataBANK1+2&07fh		
	fcall	__pidataBANK1+3		;fetch initializer
	movwf	__pdataBANK1+3&07fh		
; Initialize objects allocated to COMMON
	global __pidataCOMMON
psect cinit,class=CODE,delta=2,merge=1
	fcall	__pidataCOMMON+0		;fetch initializer
	movwf	__pdataCOMMON+0&07fh		
	fcall	__pidataCOMMON+1		;fetch initializer
	movwf	__pdataCOMMON+1&07fh		
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BANK3
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK3)
	movwf	fsr
	movlw	low((__pbssBANK3)+028h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+048h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+047h)
	fcall	clear_ram0
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
	clrf	((__pbssCOMMON)+1)&07Fh
	clrf	((__pbssCOMMON)+2)&07Fh
; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
??_main:	; 1 bytes @ 0x0
	ds	2
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?_AD_Init:	; 1 bytes @ 0x0
?_PowerOnLedSequence:	; 1 bytes @ 0x0
??_PowerOnLedSequence:	; 1 bytes @ 0x0
?_Slot_Charge_Ctrl:	; 1 bytes @ 0x0
?_CCCV_Control:	; 1 bytes @ 0x0
?_Update_LED_Global:	; 1 bytes @ 0x0
?_System_Init:	; 1 bytes @ 0x0
?_Sink_Slot_On:	; 1 bytes @ 0x0
??_Sink_Slot_On:	; 1 bytes @ 0x0
?_Sink_Slot_Off:	; 1 bytes @ 0x0
??_Sink_Slot_Off:	; 1 bytes @ 0x0
?_Isr_Timer:	; 1 bytes @ 0x0
?_Sense_Pins_AsSink:	; 1 bytes @ 0x0
?_Sense_Pins_Restore:	; 1 bytes @ 0x0
?_Wait_Display_Idle:	; 1 bytes @ 0x0
?_Display_Service:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?_Route_LiIon:	; 1 bytes @ 0x0
?_Enter_DiodeTest:	; 1 bytes @ 0x0
?_Get_Vcc:	; 2 bytes @ 0x0
?_Read_Temperature:	; 2 bytes @ 0x0
	global	Sink_Slot_On@idx
Sink_Slot_On@idx:	; 1 bytes @ 0x0
	global	Sink_Slot_Off@idx
Sink_Slot_Off@idx:	; 1 bytes @ 0x0
	ds	1
?_Sink_Set:	; 1 bytes @ 0x1
	global	Sink_Set@mask
Sink_Set@mask:	; 2 bytes @ 0x1
	ds	2
	global	Sink_Set@on
Sink_Set@on:	; 1 bytes @ 0x3
	ds	1
??_Sink_Set:	; 1 bytes @ 0x4
	global	Sink_Set@i
Sink_Set@i:	; 1 bytes @ 0x4
	ds	1
??_Isr_Timer:	; 1 bytes @ 0x5
	ds	3
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
??_AD_Init:	; 1 bytes @ 0x0
??_Sense_Pins_AsSink:	; 1 bytes @ 0x0
??_Sense_Pins_Restore:	; 1 bytes @ 0x0
??_Wait_Display_Idle:	; 1 bytes @ 0x0
??_Display_Service:	; 1 bytes @ 0x0
?_ADC_Sample:	; 1 bytes @ 0x0
?_Detect_BatteryType:	; 1 bytes @ 0x0
??_Enter_DiodeTest:	; 1 bytes @ 0x0
?___bmul:	; 1 bytes @ 0x0
	global	?___wmul
?___wmul:	; 2 bytes @ 0x0
	global	?___awdiv
?___awdiv:	; 2 bytes @ 0x0
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x0
	global	?___lmul
?___lmul:	; 4 bytes @ 0x0
	global	ADC_Sample@adldo
ADC_Sample@adldo:	; 1 bytes @ 0x0
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x0
	global	Detect_BatteryType@voltage
Detect_BatteryType@voltage:	; 2 bytes @ 0x0
	global	___wmul@multiplier
___wmul@multiplier:	; 2 bytes @ 0x0
	global	___awdiv@divisor
___awdiv@divisor:	; 2 bytes @ 0x0
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x0
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x0
	ds	1
??_ADC_Sample:	; 1 bytes @ 0x1
??___bmul:	; 1 bytes @ 0x1
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x1
	ds	1
??_Detect_BatteryType:	; 1 bytes @ 0x2
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x2
	global	___wmul@multiplicand
___wmul@multiplicand:	; 2 bytes @ 0x2
	global	___awdiv@dividend
___awdiv@dividend:	; 2 bytes @ 0x2
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_Update_LED_Global:	; 1 bytes @ 0x3
??_System_Init:	; 1 bytes @ 0x3
	global	System_Init@i
System_Init@i:	; 1 bytes @ 0x3
	global	Enter_DiodeTest@idx
Enter_DiodeTest@idx:	; 1 bytes @ 0x3
	ds	1
??___wmul:	; 1 bytes @ 0x4
??___awdiv:	; 1 bytes @ 0x4
??___lwdiv:	; 1 bytes @ 0x4
	global	___awdiv@counter
___awdiv@counter:	; 1 bytes @ 0x4
	global	___wmul@product
___wmul@product:	; 2 bytes @ 0x4
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x4
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x4
	ds	1
	global	ADC_Sample@j
ADC_Sample@j:	; 1 bytes @ 0x5
	global	___awdiv@sign
___awdiv@sign:	; 1 bytes @ 0x5
	ds	1
	global	ADC_Sample@adch
ADC_Sample@adch:	; 1 bytes @ 0x6
	global	Update_LED_Global@hasDet
Update_LED_Global@hasDet:	; 1 bytes @ 0x6
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x6
	global	___awdiv@quotient
___awdiv@quotient:	; 2 bytes @ 0x6
	ds	1
	global	ADC_Sample@i
ADC_Sample@i:	; 1 bytes @ 0x7
	global	Update_LED_Global@hasFull
Update_LED_Global@hasFull:	; 1 bytes @ 0x7
	ds	1
??_CCCV_Control:	; 1 bytes @ 0x8
??___lmul:	; 1 bytes @ 0x8
	global	Update_LED_Global@sT0IE
Update_LED_Global@sT0IE:	; 1 bytes @ 0x8
	global	ADC_Sample@adsum
ADC_Sample@adsum:	; 4 bytes @ 0x8
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x8
	ds	1
	global	Update_LED_Global@s_366
Update_LED_Global@s_366:	; 1 bytes @ 0x9
	ds	1
	global	Update_LED_Global@hasErr
Update_LED_Global@hasErr:	; 1 bytes @ 0xA
	global	CCCV_Control@adjust
CCCV_Control@adjust:	; 2 bytes @ 0xA
	ds	1
	global	Update_LED_Global@hasChg
Update_LED_Global@hasChg:	; 1 bytes @ 0xB
	ds	1
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0xC
	global	CCCV_Control@hasCharging
CCCV_Control@hasCharging:	; 1 bytes @ 0xC
	global	Update_LED_Global@s_365
Update_LED_Global@s_365:	; 1 bytes @ 0xC
	global	ADC_Sample@admin
ADC_Sample@admin:	; 2 bytes @ 0xC
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0xC
	ds	1
	global	CCCV_Control@cvCount
CCCV_Control@cvCount:	; 1 bytes @ 0xD
	global	Update_LED_Global@mask
Update_LED_Global@mask:	; 2 bytes @ 0xD
	ds	1
	global	CCCV_Control@ccCount
CCCV_Control@ccCount:	; 1 bytes @ 0xE
	global	ADC_Sample@admax
ADC_Sample@admax:	; 2 bytes @ 0xE
	ds	1
	global	CCCV_Control@preCount
CCCV_Control@preCount:	; 1 bytes @ 0xF
	global	Update_LED_Global@s
Update_LED_Global@s:	; 1 bytes @ 0xF
	ds	1
	global	Update_LED_Global@i
Update_LED_Global@i:	; 1 bytes @ 0x10
	global	ADC_Sample@ad_temp
ADC_Sample@ad_temp:	; 2 bytes @ 0x10
	global	CCCV_Control@vt
CCCV_Control@vt:	; 2 bytes @ 0x10
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x10
	ds	2
	global	CCCV_Control@maxV
CCCV_Control@maxV:	; 2 bytes @ 0x12
	ds	2
??___lldiv:	; 1 bytes @ 0x14
	global	CCCV_Control@error
CCCV_Control@error:	; 2 bytes @ 0x14
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x14
	ds	2
	global	CCCV_Control@duty_target
CCCV_Control@duty_target:	; 1 bytes @ 0x16
	ds	1
	global	CCCV_Control@duty_initial
CCCV_Control@duty_initial:	; 1 bytes @ 0x17
	ds	1
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0x18
	global	CCCV_Control@duty
CCCV_Control@duty:	; 2 bytes @ 0x18
	ds	1
??_Get_Vcc:	; 1 bytes @ 0x19
??_Read_Temperature:	; 1 bytes @ 0x19
?_Route_DetectLi:	; 1 bytes @ 0x19
	global	?_Adc_Norm
?_Adc_Norm:	; 2 bytes @ 0x19
	global	Route_DetectLi@slot_v
Route_DetectLi@slot_v:	; 2 bytes @ 0x19
	global	Get_Vcc@pt
Get_Vcc@pt:	; 4 bytes @ 0x19
	ds	1
	global	CCCV_Control@i
CCCV_Control@i:	; 1 bytes @ 0x1A
	ds	1
??_Route_DetectLi:	; 1 bytes @ 0x1B
	global	CCCV_Control@s
CCCV_Control@s:	; 1 bytes @ 0x1B
	ds	1
??_Adc_Norm:	; 1 bytes @ 0x1C
	global	Adc_Norm@ch
Adc_Norm@ch:	; 1 bytes @ 0x1C
	ds	1
	global	Adc_Norm@raw
Adc_Norm@raw:	; 2 bytes @ 0x1D
	global	Read_Temperature@rt
Read_Temperature@rt:	; 4 bytes @ 0x1D
	ds	2
	global	Route_DetectLi@bat_mv
Route_DetectLi@bat_mv:	; 2 bytes @ 0x1F
	ds	2
	global	Read_Temperature@ntcVal
Read_Temperature@ntcVal:	; 2 bytes @ 0x21
	global	Route_DetectLi@vx_mv
Route_DetectLi@vx_mv:	; 4 bytes @ 0x21
	ds	2
	global	Read_Temperature@temp_x10
Read_Temperature@temp_x10:	; 2 bytes @ 0x23
	ds	2
	global	Route_DetectLi@bat_mv_long
Route_DetectLi@bat_mv_long:	; 4 bytes @ 0x25
	ds	4
	global	Route_DetectLi@st
Route_DetectLi@st:	; 1 bytes @ 0x29
	ds	1
	global	Route_DetectLi@idx
Route_DetectLi@idx:	; 1 bytes @ 0x2A
	ds	1
??_Route_LiIon:	; 1 bytes @ 0x2B
?_Route_LinearLi:	; 1 bytes @ 0x2B
?_Detect_Classify:	; 1 bytes @ 0x2B
	global	Detect_Classify@fromHighV
Detect_Classify@fromHighV:	; 1 bytes @ 0x2B
	global	Route_LinearLi@pre
Route_LinearLi@pre:	; 2 bytes @ 0x2B
	ds	1
??_Detect_Classify:	; 1 bytes @ 0x2C
	ds	1
??_Route_LinearLi:	; 1 bytes @ 0x2D
	ds	1
	global	Route_LiIon@idx
Route_LiIon@idx:	; 1 bytes @ 0x2E
	ds	1
	global	Detect_Classify@idx
Detect_Classify@idx:	; 1 bytes @ 0x2F
	ds	1
	global	Route_LinearLi@idx
Route_LinearLi@idx:	; 1 bytes @ 0x30
	ds	1
??_Slot_Charge_Ctrl:	; 1 bytes @ 0x31
	ds	5
	global	Slot_Charge_Ctrl@v_init
Slot_Charge_Ctrl@v_init:	; 2 bytes @ 0x36
	ds	2
	global	Slot_Charge_Ctrl@vcc_norm_pre
Slot_Charge_Ctrl@vcc_norm_pre:	; 2 bytes @ 0x38
	ds	2
	global	Slot_Charge_Ctrl@vcc_norm_now
Slot_Charge_Ctrl@vcc_norm_now:	; 2 bytes @ 0x3A
	ds	2
	global	Slot_Charge_Ctrl@ptTick
Slot_Charge_Ctrl@ptTick:	; 2 bytes @ 0x3C
	ds	2
	global	Slot_Charge_Ctrl@vcc_norm
Slot_Charge_Ctrl@vcc_norm:	; 2 bytes @ 0x3E
	ds	2
	global	_Slot_Charge_Ctrl$341
_Slot_Charge_Ctrl$341:	; 2 bytes @ 0x40
	ds	2
	global	Slot_Charge_Ctrl@pt
Slot_Charge_Ctrl@pt:	; 1 bytes @ 0x42
	ds	1
	global	Slot_Charge_Ctrl@charge_ticks_prev
Slot_Charge_Ctrl@charge_ticks_prev:	; 2 bytes @ 0x43
	ds	2
	global	Slot_Charge_Ctrl@newv
Slot_Charge_Ctrl@newv:	; 2 bytes @ 0x45
	ds	2
	global	Slot_Charge_Ctrl@v_ref
Slot_Charge_Ctrl@v_ref:	; 2 bytes @ 0x47
	ds	2
	global	Slot_Charge_Ctrl@dly
Slot_Charge_Ctrl@dly:	; 1 bytes @ 0x49
	ds	1
	global	Slot_Charge_Ctrl@diff
Slot_Charge_Ctrl@diff:	; 2 bytes @ 0x4A
	ds	2
	global	Slot_Charge_Ctrl@pre
Slot_Charge_Ctrl@pre:	; 2 bytes @ 0x4C
	ds	2
	global	Slot_Charge_Ctrl@idx
Slot_Charge_Ctrl@idx:	; 1 bytes @ 0x4E
	ds	1
	global	main@i
main@i:	; 1 bytes @ 0x4F
	ds	1
;!
;!Data Sizes:
;!    Strings     0
;!    Constant    12
;!    Data        6
;!    BSS         186
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14      8      14
;!    BANK0            80     80      80
;!    BANK1            80      2      77
;!    BANK3            80      0      40
;!    BANK2            80      0      72

;!
;!Pointer List with Targets:
;!
;!    None.


;!
;!Critical Paths under _main in COMMON
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in COMMON
;!
;!    _Isr_Timer->_Sink_Set
;!    _Sink_Set->_Sink_Slot_Off
;!    _Sink_Set->_Sink_Slot_On
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Slot_Charge_Ctrl
;!    _Update_LED_Global->___bmul
;!    _System_Init->___bmul
;!    _Slot_Charge_Ctrl->_Route_LinearLi
;!    _Route_LinearLi->_Route_DetectLi
;!    _Route_LiIon->_Route_DetectLi
;!    _Detect_Classify->_Route_DetectLi
;!    _Route_DetectLi->___lldiv
;!    _Get_Vcc->___lldiv
;!    _Adc_Norm->___lldiv
;!    _Read_Temperature->___lldiv
;!    ___lldiv->___lmul
;!    _CCCV_Control->___awdiv
;!
;!Critical Paths under _Isr_Timer in BANK0
;!
;!    None.
;!
;!Critical Paths under _main in BANK1
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK3
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK3
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Isr_Timer in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 2, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 3     3      0   32701
;!                                             79 BANK0      1     1      0
;!                                              0 BANK1      2     2      0
;!                       _CCCV_Control
;!                    _Display_Service
;!                            _Get_Vcc
;!                   _Read_Temperature
;!                  _Sense_Pins_AsSink
;!                 _Sense_Pins_Restore
;!                   _Slot_Charge_Ctrl
;!                        _System_Init
;!                  _Update_LED_Global
;!                  _Wait_Display_Idle
;! ---------------------------------------------------------------------------------
;! (1) _Wait_Display_Idle                                    1     1      0       0
;!                                              0 BANK0      1     1      0
;! ---------------------------------------------------------------------------------
;! (1) _Update_LED_Global                                   14    14      0    1340
;!                                              3 BANK0     14    14      0
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (1) _System_Init                                          1     1      0     660
;!                                              3 BANK0      1     1      0
;!                            _AD_Init
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) _AD_Init                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Slot_Charge_Ctrl                                    30    30      0   23720
;!                                             49 BANK0     30    30      0
;!                           _Adc_Norm
;!                 _Detect_BatteryType
;!                    _Detect_Classify
;!                    _Enter_DiodeTest
;!                            _Get_Vcc
;!                        _Route_LiIon
;!                     _Route_LinearLi
;!                             ___bmul
;!                            ___lldiv
;!                             ___wmul
;! ---------------------------------------------------------------------------------
;! (2) ___wmul                                               6     2      4    2058
;!                                              0 BANK0      6     2      4
;! ---------------------------------------------------------------------------------
;! (2) _Route_LinearLi                                       6     4      2    2932
;!                                             43 BANK0      6     4      2
;!                     _Route_DetectLi
;! ---------------------------------------------------------------------------------
;! (2) _Route_LiIon                                          4     4      0    2517
;!                                             43 BANK0      4     4      0
;!                     _Route_DetectLi
;! ---------------------------------------------------------------------------------
;! (2) _Enter_DiodeTest                                      4     4      0      33
;!                                              0 BANK0      4     4      0
;! ---------------------------------------------------------------------------------
;! (2) _Detect_Classify                                      5     4      1    5318
;!                                             43 BANK0      5     4      1
;!                            _Get_Vcc
;!                     _Route_DetectLi
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (3) _Route_DetectLi                                      18    16      2    2473
;!                                             25 BANK0     18    16      2
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (2) _Get_Vcc                                              4     4      0    1889
;!                                             25 BANK0      4     4      0
;!                         _ADC_Sample
;!                            ___lldiv
;! ---------------------------------------------------------------------------------
;! (2) _Detect_BatteryType                                   2     0      2     185
;!                                              0 BANK0      2     0      2
;! ---------------------------------------------------------------------------------
;! (2) _Adc_Norm                                             6     3      3    2683
;!                                             25 BANK0      6     3      3
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;! ---------------------------------------------------------------------------------
;! (1) _Sense_Pins_Restore                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Sense_Pins_AsSink                                    0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Read_Temperature                                    12    12      0    3363
;!                                             25 BANK0     12    12      0
;!                         _ADC_Sample
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4     480
;!                                              0 BANK0      7     3      4
;! ---------------------------------------------------------------------------------
;! (4) ___lmul                                              12     4      8     750
;!                                              0 BANK0     12     4      8
;! ---------------------------------------------------------------------------------
;! (2) ___lldiv                                             13     5      8    1182
;!                                             12 BANK0     13     5      8
;!                             ___lmul (ARG)
;!                             ___wmul (ARG)
;! ---------------------------------------------------------------------------------
;! (3) _ADC_Sample                                          18    17      1     684
;!                                              0 BANK0     18    17      1
;! ---------------------------------------------------------------------------------
;! (1) _Display_Service                                      0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _CCCV_Control                                        20    20      0    1661
;!                                              8 BANK0     20    20      0
;!                            ___awdiv
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (2) ___bmul                                               3     2      1     482
;!                                              0 BANK0      3     2      1
;! ---------------------------------------------------------------------------------
;! (2) ___awdiv                                              8     4      4     428
;!                                              0 BANK0      8     4      4
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 4
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (5) _Isr_Timer                                            3     3      0     391
;!                                              5 COMMON     3     3      0
;!                 _PowerOnLedSequence
;!                           _Sink_Set
;! ---------------------------------------------------------------------------------
;! (6) _Sink_Set                                             4     1      3     391
;!                                              1 COMMON     4     1      3
;!                      _Sink_Slot_Off
;!                       _Sink_Slot_On
;! ---------------------------------------------------------------------------------
;! (7) _Sink_Slot_On                                         1     1      0      22
;!                                              0 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (7) _Sink_Slot_Off                                        1     1      0      22
;!                                              0 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (6) _PowerOnLedSequence                                   0     0      0       0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 7
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _CCCV_Control
;!     ___awdiv
;!     ___bmul
;!   _Display_Service
;!   _Get_Vcc
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!       ___wmul (ARG)
;!   _Read_Temperature
;!     _ADC_Sample
;!     ___lldiv
;!       ___lmul (ARG)
;!       ___wmul (ARG)
;!     ___lmul
;!     ___lwdiv
;!   _Sense_Pins_AsSink
;!   _Sense_Pins_Restore
;!   _Slot_Charge_Ctrl
;!     _Adc_Norm
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!         ___wmul (ARG)
;!       ___lmul
;!     _Detect_BatteryType
;!     _Detect_Classify
;!       _Get_Vcc
;!         _ADC_Sample
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!       _Route_DetectLi
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!         ___lmul
;!       ___lwdiv
;!     _Enter_DiodeTest
;!     _Get_Vcc
;!       _ADC_Sample
;!       ___lldiv
;!         ___lmul (ARG)
;!         ___wmul (ARG)
;!     _Route_LiIon
;!       _Route_DetectLi
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!         ___lmul
;!     _Route_LinearLi
;!       _Route_DetectLi
;!         ___lldiv
;!           ___lmul (ARG)
;!           ___wmul (ARG)
;!         ___lmul
;!     ___bmul
;!     ___lldiv
;!       ___lmul (ARG)
;!       ___wmul (ARG)
;!     ___wmul
;!   _System_Init
;!     _AD_Init
;!     ___bmul
;!   _Update_LED_Global
;!     ___bmul
;!   _Wait_Display_Idle
;!
;! _Isr_Timer (ROOT)
;!   _PowerOnLedSequence
;!   _Sink_Set
;!     _Sink_Slot_Off
;!     _Sink_Slot_On
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BANK3               50      0      28       8       50.0%
;!BITBANK3            50      0       0       7        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITSFR3              0      0       0       4        0.0%
;!BANK2               50      0      48      10       90.0%
;!BITBANK2            50      0       0       9        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!BANK1               50      2      4D       6       96.3%
;!BITBANK1            50      0       0       5        0.0%
;!SFR1                 0      0       0       2        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!BANK0               50     50      50       4      100.0%
;!BITBANK0            50      0       0       3        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR0              0      0       0       1        0.0%
;!COMMON               E      8       E       1      100.0%
;!BITCOMMON            E      0       1       0        7.1%
;!CODE                 0      0       0       0        0.0%
;!DATA                 0      0     11B      12        0.0%
;!ABS                  0      0     11B      11        0.0%
;!NULL                 0      0       0       0        0.0%
;!STACK                0      0       0       2        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 594 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1   79[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       2       0       0
;;      Totals:         0       1       2       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels required when called:    7
;; This function calls:
;;		_CCCV_Control
;;		_Display_Service
;;		_Get_Vcc
;;		_Read_Temperature
;;		_Sense_Pins_AsSink
;;		_Sense_Pins_Restore
;;		_Slot_Charge_Ctrl
;;		_System_Init
;;		_Update_LED_Global
;;		_Wait_Display_Idle
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	594
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	594
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 1
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	599
	
l4969:	
;main.c: 596: unsigned char i;
;main.c: 599: _delay((unsigned long)((10)*(16000000/4000.0)));
	opt asmopt_push
opt asmopt_off
movlw	52
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
movwf	((??_main+0)^080h+0+1),f
	movlw	241
movwf	((??_main+0)^080h+0),f
	u7697:
decfsz	((??_main+0)^080h+0),f
	goto	u7697
	decfsz	((??_main+0)^080h+0+1),f
	goto	u7697
opt asmopt_pop

	line	600
# 600 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	603
	
l4971:	
;main.c: 603: System_Init();
	fcall	_System_Init
	line	611
;main.c: 611: while(1)
	
l434:	
	line	613
# 613 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	maintext
	line	619
	
l4973:	
;main.c: 619: g_elapsedTicks = g_hwTick - g_lastHwTick;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_hwTick+1)^080h,w	;volatile
	movwf	(_g_elapsedTicks+1)^080h
	movf	(_g_hwTick)^080h,w	;volatile
	movwf	(_g_elapsedTicks)^080h
	
l4975:	
	movf	(_g_lastHwTick)^080h,w
	subwf	(_g_elapsedTicks)^080h,f
	movf	(_g_lastHwTick+1)^080h,w
	skipc
	decf	(_g_elapsedTicks+1)^080h,f
	subwf	(_g_elapsedTicks+1)^080h,f
	line	620
	
l4977:	
;main.c: 620: if(g_elapsedTicks == 0U)
	movf	((_g_elapsedTicks)^080h),w
iorwf	((_g_elapsedTicks+1)^080h),w
	btfss	status,2
	goto	u7631
	goto	u7630
u7631:
	goto	l4981
u7630:
	line	621
	
l4979:	
;main.c: 621: g_elapsedTicks = 1U;
	clrf	(_g_elapsedTicks)^080h
	incf	(_g_elapsedTicks)^080h,f
	clrf	(_g_elapsedTicks+1)^080h
	line	622
	
l4981:	
;main.c: 622: g_lastHwTick = g_hwTick;
	movf	(_g_hwTick+1)^080h,w	;volatile
	movwf	(_g_lastHwTick+1)^080h
	movf	(_g_hwTick)^080h,w	;volatile
	movwf	(_g_lastHwTick)^080h
	line	625
	
l4983:	
;main.c: 625: Get_Vcc();
	fcall	_Get_Vcc
	line	638
	
l4985:	
;main.c: 638: if(g_powerOnPhase >= 2U)
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_g_powerOnPhase)^080h,w
	skipc
	goto	u7641
	goto	u7640
u7641:
	goto	l5017
u7640:
	line	642
	
l4987:	
;main.c: 639: {
;main.c: 642: if(!s_senseRestored)
	btfsc	(_s_senseRestored/8),(_s_senseRestored)&7
	goto	u7651
	goto	u7650
u7651:
	goto	l4993
u7650:
	line	644
	
l4989:	
;main.c: 643: {
;main.c: 644: Sense_Pins_Restore();
	fcall	_Sense_Pins_Restore
	line	645
	
l4991:	
;main.c: 645: s_senseRestored = 1;
	bsf	(_s_senseRestored/8),(_s_senseRestored)&7
	line	651
	
l4993:	
;main.c: 646: }
;main.c: 651: for(i = 0; i < 12; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(main@i)
	line	653
	
l4999:	
;main.c: 652: {
;main.c: 653: Wait_Display_Idle();
	fcall	_Wait_Display_Idle
	line	654
	
l5001:	
;main.c: 654: Slot_Charge_Ctrl(i);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(main@i),w
	fcall	_Slot_Charge_Ctrl
	line	655
	
l5003:	
;main.c: 655: Display_Service();
	fcall	_Display_Service
	line	651
	
l5005:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(main@i),f
	
l5007:	
	movlw	low(0Ch)
	subwf	(main@i),w
	skipc
	goto	u7661
	goto	u7660
u7661:
	goto	l4999
u7660:
	line	659
	
l5009:	
;main.c: 656: }
;main.c: 659: CCCV_Control();
	fcall	_CCCV_Control
	line	662
	
l5011:	
;main.c: 662: if(g_pwmDuty > 28)
	movlw	low(01Dh)
	subwf	(_g_pwmDuty),w	;volatile
	skipc
	goto	u7671
	goto	u7670
u7671:
	goto	l5015
u7670:
	line	663
	
l5013:	
;main.c: 663: g_pwmDuty = 28;
	movlw	low(01Ch)
	movwf	(_g_pwmDuty)	;volatile
	line	666
	
l5015:	
;main.c: 666: Update_LED_Global();
	fcall	_Update_LED_Global
	line	667
;main.c: 667: }
	goto	l5019
	line	671
	
l5017:	
;main.c: 668: else
;main.c: 669: {
;main.c: 671: Sense_Pins_AsSink();
	fcall	_Sense_Pins_AsSink
	line	675
	
l5019:	
;main.c: 672: }
;main.c: 675: if(g_doNtcRead)
	btfss	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	goto	u7681
	goto	u7680
u7681:
	goto	l434
u7680:
	line	677
	
l5021:	
;main.c: 676: {
;main.c: 677: g_doNtcRead = 0;
	bcf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	678
	
l5023:	
;main.c: 678: Read_Temperature();
	fcall	_Read_Temperature
	goto	l434
	global	start
	ljmp	start
	opt stack 0
	line	691
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_Wait_Display_Idle

;; *************** function _Wait_Display_Idle *****************
;; Defined at:
;;		line 566 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       1       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	566
global __ptext1
__ptext1:	;psect for function _Wait_Display_Idle
psect	text1
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	566
	global	__size_of_Wait_Display_Idle
	__size_of_Wait_Display_Idle	equ	__end_of_Wait_Display_Idle-_Wait_Display_Idle
	
_Wait_Display_Idle:	
;incstack = 0
	opt	stack 4
; Regs used in _Wait_Display_Idle: [wreg+status,2+status,0]
	line	568
	
l3747:	
;main.c: 568: g_adcBusy = 1;
	bsf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	569
;main.c: 569: while(g_dispWin)
	goto	l413
	
l414:	
	line	570
# 570 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text1
	
l413:	
	line	569
	btfsc	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	goto	u4591
	goto	u4590
u4591:
	goto	l414
u4590:
	line	573
	
l3749:	
;main.c: 573: if(g_sinkMask != 0U)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	((_g_sinkMask)^080h),w	;volatile
iorwf	((_g_sinkMask+1)^080h),w	;volatile
	btfsc	status,2
	goto	u4601
	goto	u4600
u4601:
	goto	l417
u4600:
	line	574
	
l3751:	
;main.c: 574: _delay((unsigned long)((50)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	65
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Wait_Display_Idle+0)+0),f
	u7707:
decfsz	(??_Wait_Display_Idle+0)+0,f
	goto	u7707
	nop2
opt asmopt_pop

	line	575
	
l417:	
	return
	opt stack 0
GLOBAL	__end_of_Wait_Display_Idle
	__end_of_Wait_Display_Idle:
	signat	_Wait_Display_Idle,89
	global	_Update_LED_Global

;; *************** function _Update_LED_Global *****************
;; Defined at:
;;		line 60 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  s               1    9[BANK0 ] unsigned char 
;;  s               1   12[BANK0 ] unsigned char 
;;  s               1   15[BANK0 ] unsigned char 
;;  sT0IE           1    8[BANK0 ] unsigned char 
;;  mask            2   13[BANK0 ] unsigned int 
;;  i               1   16[BANK0 ] unsigned char 
;;  hasChg          1   11[BANK0 ] unsigned char 
;;  hasErr          1   10[BANK0 ] unsigned char 
;;  hasFull         1    7[BANK0 ] unsigned char 
;;  hasDet          1    6[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      11       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0      14       0       0       0
;;Total ram usage:       14 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	60
global __ptext2
__ptext2:	;psect for function _Update_LED_Global
psect	text2
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	60
	global	__size_of_Update_LED_Global
	__size_of_Update_LED_Global	equ	__end_of_Update_LED_Global-_Update_LED_Global
	
_Update_LED_Global:	
;incstack = 0
	opt	stack 3
; Regs used in _Update_LED_Global: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	63
	
l4719:	
;led.c: 62: unsigned char i;
;led.c: 63: unsigned char hasErr = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Update_LED_Global@hasErr)
	line	64
;led.c: 64: unsigned char hasChg = 0;
	clrf	(Update_LED_Global@hasChg)
	line	65
;led.c: 65: unsigned char hasDet = 0;
	clrf	(Update_LED_Global@hasDet)
	line	66
;led.c: 66: unsigned char hasFull = 0;
	clrf	(Update_LED_Global@hasFull)
	line	67
;led.c: 67: unsigned int mask = 0;
	clrf	(Update_LED_Global@mask)
	clrf	(Update_LED_Global@mask+1)
	line	70
;led.c: 70: for(i = 0; i < 12; i++)
	clrf	(Update_LED_Global@i)
	line	72
	
l4725:	
;led.c: 71: {
;led.c: 72: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Global@s)
	line	73
	
l4727:	
;led.c: 73: if(s == 7)
		movlw	7
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u7081
	goto	u7080
u7081:
	goto	l4731
u7080:
	line	75
	
l4729:	
;led.c: 74: {
;led.c: 75: hasErr = 1;
	clrf	(Update_LED_Global@hasErr)
	incf	(Update_LED_Global@hasErr),f
	line	76
;led.c: 76: }
	goto	l4757
	line	78
	
l4731:	
;led.c: 77: else if(s == 2 || s == 3 ||
;led.c: 78: s == 4 || s == 5)
		movlw	2
	xorwf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u7091
	goto	u7090
u7091:
	goto	l4739
u7090:
	
l4733:	
		movlw	3
	xorwf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u7101
	goto	u7100
u7101:
	goto	l4739
u7100:
	
l4735:	
		movlw	4
	xorwf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u7111
	goto	u7110
u7111:
	goto	l4739
u7110:
	
l4737:	
		movlw	5
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u7121
	goto	u7120
u7121:
	goto	l4743
u7120:
	line	83
	
l4739:	
;led.c: 79: {
;led.c: 83: if(g_slot[(unsigned char)(i)].voltage < 3990)
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Update_LED_Global+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Update_LED_Global+0)+0+1
	movlw	0Fh
	subwf	1+(??_Update_LED_Global+0)+0,w
	movlw	096h
	skipnz
	subwf	0+(??_Update_LED_Global+0)+0,w
	skipnc
	goto	u7131
	goto	u7130
u7131:
	goto	l4757
u7130:
	line	84
	
l4741:	
;led.c: 84: hasChg = 1;
	clrf	(Update_LED_Global@hasChg)
	incf	(Update_LED_Global@hasChg),f
	goto	l4757
	line	86
	
l4743:	
;led.c: 86: else if(s == 1 || s == 8 || s == 9)
		decf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u7141
	goto	u7140
u7141:
	goto	l4749
u7140:
	
l4745:	
		movlw	8
	xorwf	((Update_LED_Global@s)),w
	btfsc	status,2
	goto	u7151
	goto	u7150
u7151:
	goto	l4749
u7150:
	
l4747:	
		movlw	9
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u7161
	goto	u7160
u7161:
	goto	l4753
u7160:
	line	88
	
l4749:	
;led.c: 87: {
;led.c: 88: if(g_slot[(unsigned char)(i)].voltage < 3990)
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Update_LED_Global+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Update_LED_Global+0)+0+1
	movlw	0Fh
	subwf	1+(??_Update_LED_Global+0)+0,w
	movlw	096h
	skipnz
	subwf	0+(??_Update_LED_Global+0)+0,w
	skipnc
	goto	u7171
	goto	u7170
u7171:
	goto	l910
u7170:
	line	89
	
l4751:	
;led.c: 89: hasDet = 1;
	clrf	(Update_LED_Global@hasDet)
	incf	(Update_LED_Global@hasDet),f
	goto	l4757
	line	91
	
l4753:	
;led.c: 91: else if(s == 6)
		movlw	6
	xorwf	((Update_LED_Global@s)),w
	btfss	status,2
	goto	u7181
	goto	u7180
u7181:
	goto	l910
u7180:
	line	93
	
l4755:	
;led.c: 92: {
;led.c: 93: hasFull = 1;
	clrf	(Update_LED_Global@hasFull)
	incf	(Update_LED_Global@hasFull),f
	goto	l4757
	line	95
	
l910:	
	line	70
	
l4757:	
	incf	(Update_LED_Global@i),f
	
l4759:	
	movlw	low(0Ch)
	subwf	(Update_LED_Global@i),w
	skipc
	goto	u7191
	goto	u7190
u7191:
	goto	l4725
u7190:
	line	100
	
l4761:	
;led.c: 94: }
;led.c: 95: }
;led.c: 100: if(hasErr)
	movf	((Update_LED_Global@hasErr)),w
	btfsc	status,2
	goto	u7201
	goto	u7200
u7201:
	goto	l4781
u7200:
	line	102
	
l4763:	
;led.c: 101: {
;led.c: 102: for(i = 0; i < 12; i++)
	clrf	(Update_LED_Global@i)
	line	104
	
l4769:	
;led.c: 103: {
;led.c: 104: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Global@s_365)
	line	105
	
l4771:	
;led.c: 105: if(s == 7 || s == 4 || s == 5)
		movlw	7
	xorwf	((Update_LED_Global@s_365)),w
	btfsc	status,2
	goto	u7211
	goto	u7210
u7211:
	goto	l4777
u7210:
	
l4773:	
		movlw	4
	xorwf	((Update_LED_Global@s_365)),w
	btfsc	status,2
	goto	u7221
	goto	u7220
u7221:
	goto	l4777
u7220:
	
l4775:	
		movlw	5
	xorwf	((Update_LED_Global@s_365)),w
	btfss	status,2
	goto	u7231
	goto	u7230
u7231:
	goto	l4779
u7230:
	line	106
	
l4777:	
;led.c: 106: mask |= (unsigned int)1 << i;
	incf	(Update_LED_Global@i),w
	movwf	(??_Update_LED_Global+0)+0
	movlw	01h
	movwf	(??_Update_LED_Global+1)+0
	movlw	0
	movwf	(??_Update_LED_Global+1)+0+1
	goto	u7244
u7245:
	clrc
	rlf	(??_Update_LED_Global+1)+0,f
	rlf	(??_Update_LED_Global+1)+1,f
u7244:
	decfsz	(??_Update_LED_Global+0)+0,f
	goto	u7245
	
	movf	0+(??_Update_LED_Global+1)+0,w
	iorwf	(Update_LED_Global@mask),f
	movf	1+(??_Update_LED_Global+1)+0,w
	iorwf	(Update_LED_Global@mask+1),f
	line	102
	
l4779:	
	incf	(Update_LED_Global@i),f
	movlw	low(0Ch)
	subwf	(Update_LED_Global@i),w
	skipc
	goto	u7251
	goto	u7250
u7251:
	goto	l4769
u7250:
	goto	l4801
	line	109
	
l4781:	
;led.c: 109: else if(hasChg)
	movf	((Update_LED_Global@hasChg)),w
	btfsc	status,2
	goto	u7261
	goto	u7260
u7261:
	goto	l4801
u7260:
	line	111
	
l4783:	
;led.c: 110: {
;led.c: 111: for(i = 0; i < 12; i++)
	clrf	(Update_LED_Global@i)
	line	113
	
l4789:	
;led.c: 112: {
;led.c: 113: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(Update_LED_Global@s_366)
	line	114
	
l4791:	
;led.c: 114: if((s == 4 || s == 5) && g_slot[(unsigned char)(i)].voltage < 3990)
		movlw	4
	xorwf	((Update_LED_Global@s_366)),w
	btfsc	status,2
	goto	u7271
	goto	u7270
u7271:
	goto	l4795
u7270:
	
l4793:	
		movlw	5
	xorwf	((Update_LED_Global@s_366)),w
	btfss	status,2
	goto	u7281
	goto	u7280
u7281:
	goto	l4799
u7280:
	
l4795:	
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Update_LED_Global@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Update_LED_Global+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Update_LED_Global+0)+0+1
	movlw	0Fh
	subwf	1+(??_Update_LED_Global+0)+0,w
	movlw	096h
	skipnz
	subwf	0+(??_Update_LED_Global+0)+0,w
	skipnc
	goto	u7291
	goto	u7290
u7291:
	goto	l4799
u7290:
	line	115
	
l4797:	
;led.c: 115: mask |= (unsigned int)1 << i;
	incf	(Update_LED_Global@i),w
	movwf	(??_Update_LED_Global+0)+0
	movlw	01h
	movwf	(??_Update_LED_Global+1)+0
	movlw	0
	movwf	(??_Update_LED_Global+1)+0+1
	goto	u7304
u7305:
	clrc
	rlf	(??_Update_LED_Global+1)+0,f
	rlf	(??_Update_LED_Global+1)+1,f
u7304:
	decfsz	(??_Update_LED_Global+0)+0,f
	goto	u7305
	
	movf	0+(??_Update_LED_Global+1)+0,w
	iorwf	(Update_LED_Global@mask),f
	movf	1+(??_Update_LED_Global+1)+0,w
	iorwf	(Update_LED_Global@mask+1),f
	line	111
	
l4799:	
	incf	(Update_LED_Global@i),f
	movlw	low(0Ch)
	subwf	(Update_LED_Global@i),w
	skipc
	goto	u7311
	goto	u7310
u7311:
	goto	l4789
u7310:
	line	129
	
l4801:	
;led.c: 116: }
;led.c: 117: }
;led.c: 128: {
;led.c: 129: unsigned char sT0IE = INTCON & 0x20U;
	movf	(11),w	;volatile
	movwf	(Update_LED_Global@sT0IE)
	
l4803:	
	movlw	low(020h)
	andwf	(Update_LED_Global@sT0IE),f
	line	130
	
l4805:	
;led.c: 130: INTCON &= ~0x20U;
	bcf	(11)+(5/8),(5)&7	;volatile
	line	131
	
l4807:	
;led.c: 131: if(hasErr)
	movf	((Update_LED_Global@hasErr)),w
	btfsc	status,2
	goto	u7321
	goto	u7320
u7321:
	goto	l4823
u7320:
	line	134
	
l4809:	
;led.c: 132: {
;led.c: 134: s_ledBlinkCnt = (unsigned char)(s_ledBlinkCnt + g_elapsedTicks);
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_elapsedTicks)^080h,w
	addwf	(_s_ledBlinkCnt)^080h,f
	line	135
	
l4811:	
;led.c: 135: if(s_ledBlinkCnt >= (100 / 4))
	movlw	low(019h)
	subwf	(_s_ledBlinkCnt)^080h,w
	skipc
	goto	u7331
	goto	u7330
u7331:
	goto	l4815
u7330:
	line	136
	
l4813:	
;led.c: 136: s_ledBlinkCnt = 0;
	clrf	(_s_ledBlinkCnt)^080h
	line	137
	
l4815:	
;led.c: 137: if(s_ledBlinkCnt < ((100 / 4) / 2))
	movlw	low(0Ch)
	subwf	(_s_ledBlinkCnt)^080h,w
	skipnc
	goto	u7341
	goto	u7340
u7341:
	goto	l932
u7340:
	line	139
	
l4817:	
;led.c: 138: {
;led.c: 139: RC4 = 0; RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	140
	
l4819:	
;led.c: 140: g_sinkMask = mask;
	bcf	status, 6	;RP1=0, select bank0
	movf	(Update_LED_Global@mask+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_sinkMask+1)^080h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(Update_LED_Global@mask),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_sinkMask)^080h	;volatile
	line	141
;led.c: 141: }
	goto	l4857
	line	142
	
l932:	
	line	144
;led.c: 142: else
;led.c: 143: {
;led.c: 144: RC4 = 1; RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	145
	
l4821:	
;led.c: 145: g_sinkMask = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(_g_sinkMask)^080h	;volatile
	clrf	(_g_sinkMask+1)^080h	;volatile
	goto	l4857
	line	148
	
l4823:	
;led.c: 148: else if(hasChg)
	movf	((Update_LED_Global@hasChg)),w
	btfsc	status,2
	goto	u7351
	goto	u7350
u7351:
	goto	l4833
u7350:
	line	151
	
l4825:	
;led.c: 149: {
;led.c: 151: s_ledBlinkCnt = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_ledBlinkCnt)^080h
	line	152
	
l4827:	
;led.c: 152: RC4 = 0; RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	
l4829:	
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	goto	l4819
	line	155
	
l4833:	
;led.c: 155: else if(hasDet)
	movf	((Update_LED_Global@hasDet)),w
	btfsc	status,2
	goto	u7361
	goto	u7360
u7361:
	goto	l4841
u7360:
	line	159
	
l4835:	
;led.c: 156: {
;led.c: 159: s_ledBlinkCnt = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_ledBlinkCnt)^080h
	line	160
	
l4837:	
;led.c: 160: RC4 = 1; RC5 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	
l4839:	
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	161
;led.c: 161: g_sinkMask = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(_g_sinkMask)^080h	;volatile
	clrf	(_g_sinkMask+1)^080h	;volatile
	line	162
;led.c: 162: }
	goto	l4857
	line	163
	
l4841:	
;led.c: 163: else if(hasFull)
	movf	((Update_LED_Global@hasFull)),w
	btfsc	status,2
	goto	u7371
	goto	u7370
u7371:
	goto	l4851
u7370:
	line	167
	
l4843:	
;led.c: 164: {
;led.c: 167: s_ledBlinkCnt = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_ledBlinkCnt)^080h
	line	168
	
l4845:	
;led.c: 168: RC4 = 1; RC5 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	
l4847:	
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	goto	l4819
	line	174
	
l4851:	
;led.c: 171: else
;led.c: 172: {
;led.c: 174: s_ledBlinkCnt = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_ledBlinkCnt)^080h
	line	175
	
l4853:	
;led.c: 175: RC4 = 1; RC5 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	
l4855:	
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	176
;led.c: 176: g_sinkMask = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(_g_sinkMask)^080h	;volatile
	clrf	(_g_sinkMask+1)^080h	;volatile
	line	178
	
l4857:	
;led.c: 177: }
;led.c: 178: INTCON |= sT0IE;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Update_LED_Global@sT0IE),w
	iorwf	(11),f	;volatile
	line	180
	
l941:	
	return
	opt stack 0
GLOBAL	__end_of_Update_LED_Global
	__end_of_Update_LED_Global:
	signat	_Update_LED_Global,89
	global	_System_Init

;; *************** function _System_Init *****************
;; Defined at:
;;		line 71 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               1    3[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_AD_Init
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	71
global __ptext3
__ptext3:	;psect for function _System_Init
psect	text3
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	71
	global	__size_of_System_Init
	__size_of_System_Init	equ	__end_of_System_Init-_System_Init
	
_System_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _System_Init: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	76
	
l3597:	
# 76 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
nop ;# 
	line	77
# 77 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text3
	line	78
	
l3599:	
;main.c: 78: OSCCON = 0x72;
	movlw	low(072h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(20)	;volatile
	line	82
;main.c: 82: TRISA = 0xF0; PORTA = 0x0F;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	movlw	low(0Fh)
	movwf	(134)^080h	;volatile
	line	83
;main.c: 83: TRISB = 0x30; PORTB = 0x4F;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	movlw	low(04Fh)
	movwf	(6)	;volatile
	line	84
;main.c: 84: TRISC = 0x07; PORTC = 0x00;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(261)^0100h	;volatile
	
l3601:	
	clrf	(262)^0100h	;volatile
	line	86
	
l3603:	
;main.c: 86: TRISD = 0xF0; PORTD = 0x0F;
	movlw	low(0F0h)
	movwf	(276)^0100h	;volatile
	
l3605:	
	movlw	low(0Fh)
	movwf	(263)^0100h	;volatile
	line	89
	
l3607:	
;main.c: 89: WPUA = 0x00; WPDA = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(136)^080h	;volatile
	
l3609:	
	clrf	(135)^080h	;volatile
	line	90
	
l3611:	
;main.c: 90: WPUB = 0x00; WPDB = 0x00;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(8)	;volatile
	
l3613:	
	clrf	(7)	;volatile
	line	91
	
l3615:	
;main.c: 91: WPUC = 0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	(264)^0100h	;volatile
	line	92
	
l3617:	
;main.c: 92: WPUD = 0x00;
	clrf	(277)^0100h	;volatile
	line	95
	
l3619:	
;main.c: 95: IOCA = 0x00; IOCB = 0x00;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(137)^080h	;volatile
	
l3621:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(9)	;volatile
	line	98
	
l3623:	
;main.c: 98: CC0CON = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	99
	
l3625:	
;main.c: 99: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	106
	
l3627:	
;main.c: 106: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	107
	
l3629:	
;main.c: 107: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	108
	
l3631:	
;main.c: 108: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	109
	
l3633:	
;main.c: 109: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	112
	
l3635:	
;main.c: 112: AD_Init();
	fcall	_AD_Init
	line	123
	
l3637:	
;main.c: 123: OPTION_REG = 0x00;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(1)	;volatile
	line	124
	
l3639:	
;main.c: 124: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(129)^080h	;volatile
	line	125
	
l3641:	
;main.c: 125: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	126
	
l3643:	
;main.c: 126: INTCON = 0xE0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	130
	
l3645:	
;main.c: 130: g_pwmDuty = 0;
	clrf	(_g_pwmDuty)	;volatile
	line	131
	
l3647:	
;main.c: 131: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)^080h	;volatile
	line	132
	
l3649:	
;main.c: 132: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	133
	
l3651:	
;main.c: 133: RC5 = 1;
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	134
	
l3653:	
;main.c: 134: RB6 = 1;
	bcf	status, 6	;RP1=0, select bank0
	bsf	(54/8),(54)&7	;volatile
	line	135
	
l3655:	
;main.c: 135: RB7 = 0;
	bcf	(55/8),(55)&7	;volatile
	line	138
	
l3657:	
;main.c: 138: for(i = 0; i < 12; i++)
	clrf	(System_Init@i)
	line	140
	
l3663:	
;main.c: 139: {
;main.c: 140: g_slot[i].state = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	141
;main.c: 141: g_slot[i].type = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	line	142
;main.c: 142: g_slot[i].voltage = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	143
;main.c: 143: g_slot[i].chargeTimer = 0;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(System_Init@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+04h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	144
	
l3665:	
;main.c: 144: g_ccBlocks[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	145
	
l3667:	
;main.c: 145: g_ovCnt[i] = 0;
	movf	(System_Init@i),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	138
	
l3669:	
	incf	(System_Init@i),f
	
l3671:	
	movlw	low(0Ch)
	subwf	(System_Init@i),w
	skipc
	goto	u4511
	goto	u4510
u4511:
	goto	l3663
u4510:
	line	149
	
l339:	
	return
	opt stack 0
GLOBAL	__end_of_System_Init
	__end_of_System_Init:
	signat	_System_Init,89
	global	_AD_Init

;; *************** function _AD_Init *****************
;; Defined at:
;;		line 23 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
global __ptext4
__ptext4:	;psect for function _AD_Init
psect	text4
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	23
	global	__size_of_AD_Init
	__size_of_AD_Init	equ	__end_of_AD_Init-_AD_Init
	
_AD_Init:	
;incstack = 0
	opt	stack 3
; Regs used in _AD_Init: [wreg+status,2]
	line	25
	
l3357:	
;adc_drv.c: 25: CC0CON = 0;
	bsf	status, 6	;RP1=1, select bank3
	clrf	(405)^0180h	;volatile
	line	26
;adc_drv.c: 26: CC1CON = 0;
	clrf	(406)^0180h	;volatile
	line	27
	
l3359:	
;adc_drv.c: 27: ADCON0 = 0X81;
	movlw	low(081h)
	bcf	status, 6	;RP1=0, select bank1
	movwf	(149)^080h	;volatile
	line	28
	
l3361:	
;adc_drv.c: 28: ADCON1 = 0;
	clrf	(150)^080h	;volatile
	line	29
	
l452:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Init
	__end_of_AD_Init:
	signat	_AD_Init,89
	global	_Slot_Charge_Ctrl

;; *************** function _Slot_Charge_Ctrl *****************
;; Defined at:
;;		line 427 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   78[BANK0 ] unsigned char 
;;  vcc_norm        2   62[BANK0 ] unsigned int 
;;  pre             2   76[BANK0 ] unsigned int 
;;  diff            2   74[BANK0 ] int 
;;  vcc_norm_now    2   58[BANK0 ] unsigned int 
;;  vcc_norm_pre    2   56[BANK0 ] unsigned int 
;;  ptTick          2   60[BANK0 ] unsigned int 
;;  pt              1   66[BANK0 ] unsigned char 
;;  v_ref           2   71[BANK0 ] unsigned int 
;;  v_init          2   54[BANK0 ] unsigned int 
;;  newv            2   69[BANK0 ] unsigned int 
;;  charge_ticks    2   67[BANK0 ] unsigned int 
;;  dly             1   73[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 800/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      25       0       0       0
;;      Temps:          0       5       0       0       0
;;      Totals:         0      30       0       0       0
;;Total ram usage:       30 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_Adc_Norm
;;		_Detect_BatteryType
;;		_Detect_Classify
;;		_Enter_DiodeTest
;;		_Get_Vcc
;;		_Route_LiIon
;;		_Route_LinearLi
;;		___bmul
;;		___lldiv
;;		___wmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	427
global __ptext5
__ptext5:	;psect for function _Slot_Charge_Ctrl
psect	text5
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	427
	global	__size_of_Slot_Charge_Ctrl
	__size_of_Slot_Charge_Ctrl	equ	__end_of_Slot_Charge_Ctrl-_Slot_Charge_Ctrl
	
_Slot_Charge_Ctrl:	
;incstack = 0
	opt	stack 1
; Regs used in _Slot_Charge_Ctrl: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
;Slot_Charge_Ctrl@idx stored from wreg
	movwf	(Slot_Charge_Ctrl@idx)
	line	433
	
l3759:	
;charge_mgr.c: 429: unsigned int charge_ticks_prev;
;charge_mgr.c: 430: unsigned char dly;
;charge_mgr.c: 433: s_work = g_slot[idx];
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(_s_work)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	6
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
u4640:
	
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	((??_Slot_Charge_Ctrl+0)+0+2)
	incf	fsr,w
	movwf	((??_Slot_Charge_Ctrl+0)+0+3)
	movf	(??_Slot_Charge_Ctrl+0)+0,w
	movwf	fsr
	bcf	status, 7	;select IRP bank1
	
	movf	((??_Slot_Charge_Ctrl+0)+0+2),w
	movwf	indf
	incf	fsr,w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	((??_Slot_Charge_Ctrl+0)+0+3),w
	movwf	fsr
	decfsz	((??_Slot_Charge_Ctrl+0)+0+1),f
	goto	u4640
	
	line	438
	
l3761:	
;charge_mgr.c: 438: charge_ticks_prev = s_work.chargeTimer;
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+04h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@charge_ticks_prev+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+04h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@charge_ticks_prev)
	line	439
	
l3763:	
;charge_mgr.c: 439: s_work.chargeTimer += (unsigned int)g_elapsedTicks;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_elapsedTicks)^080h,w
	addwf	0+(_s_work)^080h+04h,f
	skipnc
	incf	1+(_s_work)^080h+04h,f
	movf	(_g_elapsedTicks+1)^080h,w
	addwf	1+(_s_work)^080h+04h,f
	line	447
	
l3765:	
;charge_mgr.c: 446: if((s_work.state == 1 || s_work.state == 8 || s_work.state == 9) &&
;charge_mgr.c: 447: g_detectOwner != 0xFF && g_detectOwner != idx)
		decf	((_s_work)^080h),w
	btfsc	status,2
	goto	u4651
	goto	u4650
u4651:
	goto	l3771
u4650:
	
l3767:	
		movlw	8
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u4661
	goto	u4660
u4661:
	goto	l3771
u4660:
	
l3769:	
		movlw	9
	xorwf	((_s_work)^080h),w
	btfss	status,2
	goto	u4671
	goto	u4670
u4671:
	goto	l3789
u4670:
	
l3771:	
		incf	((_g_detectOwner)^080h),w
	btfsc	status,2
	goto	u4681
	goto	u4680
u4681:
	goto	l3789
u4680:
	
l3773:	
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipnz
	goto	u4691
	goto	u4690
u4691:
	goto	l3789
u4690:
	line	451
	
l3775:	
;charge_mgr.c: 448: {
;charge_mgr.c: 451: if(g_detectWaiter == 0xFF)
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectWaiter)^080h),w
	btfss	status,2
	goto	u4701
	goto	u4700
u4701:
	goto	l3781
u4700:
	line	452
	
l3777:	
;charge_mgr.c: 452: g_detectWaiter = idx;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectWaiter)^080h
	goto	l3781
	line	453
	
l582:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l3783
	
l584:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l3783
	
l585:	
	bsf	(51/8),(51)&7	;volatile
	goto	l3783
	
l586:	
	bsf	(50/8),(50)&7	;volatile
	goto	l3783
	
l587:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l3783
	
l588:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l3783
	
l589:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l3783
	
l590:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l3783
	
l591:	
	bsf	(48/8),(48)&7	;volatile
	goto	l3783
	
l592:	
	bsf	(49/8),(49)&7	;volatile
	goto	l3783
	
l593:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l3783
	
l594:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l3783
	
l3781:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l582
	xorlw	1^0	; case 1
	skipnz
	goto	l584
	xorlw	2^1	; case 2
	skipnz
	goto	l585
	xorlw	3^2	; case 3
	skipnz
	goto	l586
	xorlw	4^3	; case 4
	skipnz
	goto	l587
	xorlw	5^4	; case 5
	skipnz
	goto	l588
	xorlw	6^5	; case 6
	skipnz
	goto	l589
	xorlw	7^6	; case 7
	skipnz
	goto	l590
	xorlw	8^7	; case 8
	skipnz
	goto	l591
	xorlw	9^8	; case 9
	skipnz
	goto	l592
	xorlw	10^9	; case 10
	skipnz
	goto	l593
	xorlw	11^10	; case 11
	skipnz
	goto	l594
	goto	l3783
	opt asmopt_pop

	line	454
	
l3783:	
;charge_mgr.c: 454: g_slot[idx] = s_work;
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_s_work)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+4,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+5,w
	movwf	indf
	goto	l596
	line	459
	
l599:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l3791
	
l601:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l3791
	
l602:	
	bsf	(51/8),(51)&7	;volatile
	goto	l3791
	
l603:	
	bsf	(50/8),(50)&7	;volatile
	goto	l3791
	
l604:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l3791
	
l605:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l3791
	
l606:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l3791
	
l607:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l3791
	
l608:	
	bsf	(48/8),(48)&7	;volatile
	goto	l3791
	
l609:	
	bsf	(49/8),(49)&7	;volatile
	goto	l3791
	
l610:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l3791
	
l611:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l3791
	
l3789:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l599
	xorlw	1^0	; case 1
	skipnz
	goto	l601
	xorlw	2^1	; case 2
	skipnz
	goto	l602
	xorlw	3^2	; case 3
	skipnz
	goto	l603
	xorlw	4^3	; case 4
	skipnz
	goto	l604
	xorlw	5^4	; case 5
	skipnz
	goto	l605
	xorlw	6^5	; case 6
	skipnz
	goto	l606
	xorlw	7^6	; case 7
	skipnz
	goto	l607
	xorlw	8^7	; case 8
	skipnz
	goto	l608
	xorlw	9^8	; case 9
	skipnz
	goto	l609
	xorlw	10^9	; case 10
	skipnz
	goto	l610
	xorlw	11^10	; case 11
	skipnz
	goto	l611
	goto	l3791
	opt asmopt_pop

	line	460
	
l3791:	
;charge_mgr.c: 460: if(s_work.state == 1 || s_work.state == 8 || s_work.state == 9)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
		decf	((_s_work)^080h),w
	btfsc	status,2
	goto	u4711
	goto	u4710
u4711:
	goto	l3797
u4710:
	
l3793:	
		movlw	8
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u4721
	goto	u4720
u4721:
	goto	l3797
u4720:
	
l3795:	
		movlw	9
	xorwf	((_s_work)^080h),w
	btfss	status,2
	goto	u4731
	goto	u4730
u4731:
	goto	l3809
u4730:
	line	463
	
l3797:	
;charge_mgr.c: 461: {
;charge_mgr.c: 463: for(dly = 0; dly < 20; dly++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Slot_Charge_Ctrl@dly)
	
l3799:	
	movlw	low(014h)
	subwf	(Slot_Charge_Ctrl@dly),w
	skipc
	goto	u4741
	goto	u4740
u4741:
	goto	l3803
u4740:
	goto	l3811
	line	464
	
l3803:	
;charge_mgr.c: 464: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u7717:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7717
	nop
opt asmopt_pop

	line	463
	
l3805:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Slot_Charge_Ctrl@dly),f
	goto	l3799
	line	468
	
l3809:	
;charge_mgr.c: 466: else
;charge_mgr.c: 467: {
;charge_mgr.c: 468: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_Slot_Charge_Ctrl+0)+0),f
	u7727:
decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u7727
	nop
opt asmopt_pop

	line	472
	
l3811:	
;charge_mgr.c: 469: }
;charge_mgr.c: 471: {
;charge_mgr.c: 472: unsigned int newv = Adc_Norm(s_adcChannels[idx]);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low((((_s_adcChannels)-__stringbase)|8000h))
	movwf	fsr0
	fcall	stringdir
	fcall	_Adc_Norm
	movf	(1+(?_Adc_Norm)),w
	movwf	(Slot_Charge_Ctrl@newv+1)
	movf	(0+(?_Adc_Norm)),w
	movwf	(Slot_Charge_Ctrl@newv)
	line	476
	
l3813:	
;charge_mgr.c: 474: if(!(s_work.type == 6 &&
;charge_mgr.c: 475: (s_work.state == 4 || s_work.state == 5) &&
;charge_mgr.c: 476: newv >= 3990))
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u4751
	goto	u4750
u4751:
	goto	l3821
u4750:
	
l3815:	
		movlw	4
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u4761
	goto	u4760
u4761:
	goto	l3819
u4760:
	
l3817:	
		movlw	5
	xorwf	((_s_work)^080h),w
	btfss	status,2
	goto	u4771
	goto	u4770
u4771:
	goto	l3821
u4770:
	
l3819:	
	movlw	0Fh
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Slot_Charge_Ctrl@newv+1),w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@newv),w
	skipnc
	goto	u4781
	goto	u4780
u4781:
	goto	l4531
u4780:
	line	478
	
l3821:	
;charge_mgr.c: 477: {
;charge_mgr.c: 478: s_work.voltage = newv;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@newv+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	1+(_s_work)^080h+02h
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@newv),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+02h
	goto	l4531
	line	487
	
l3823:	
;charge_mgr.c: 487: if(s_work.voltage >= 3990)
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u4791
	goto	u4790
u4791:
	goto	l3829
u4790:
	line	489
	
l3825:	
;charge_mgr.c: 488: {
;charge_mgr.c: 489: if(s_work.chargeTimer < (2400))
	movlw	09h
	subwf	1+(_s_work)^080h+04h,w
	movlw	060h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u4801
	goto	u4800
u4801:
	goto	l3829
u4800:
	goto	l4533
	line	497
	
l3829:	
;charge_mgr.c: 491: }
;charge_mgr.c: 496: if((g_detectOwner != 0xFF && g_detectOwner != idx) ||
;charge_mgr.c: 497: (g_detectWaiter != 0xFF && g_detectWaiter != idx))
		incf	((_g_detectOwner)^080h),w
	btfsc	status,2
	goto	u4811
	goto	u4810
u4811:
	goto	l3833
u4810:
	
l3831:	
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u4821
	goto	u4820
u4821:
	goto	l4533
u4820:
	
l3833:	
	bsf	status, 5	;RP0=1, select bank1
		incf	((_g_detectWaiter)^080h),w
	btfsc	status,2
	goto	u4831
	goto	u4830
u4831:
	goto	l3837
u4830:
	
l3835:	
	movf	(_g_detectWaiter)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipnz
	goto	u4841
	goto	u4840
u4841:
	goto	l3837
u4840:
	goto	l4533
	line	500
	
l3837:	
;charge_mgr.c: 500: s_work.chargeTimer = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	501
	
l3839:	
;charge_mgr.c: 501: s_work.state = 1;
	clrf	(_s_work)^080h
	incf	(_s_work)^080h,f
	line	502
	
l3841:	
;charge_mgr.c: 502: g_ccBlocks[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	503
	
l3843:	
;charge_mgr.c: 503: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u4854
u4855:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u4854:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u4855
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	506
	
l3845:	
;charge_mgr.c: 506: if(s_work.voltage < 3990)
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u4861
	goto	u4860
u4861:
	goto	l3849
u4860:
	line	507
	
l3847:	
;charge_mgr.c: 507: g_slotRefV[idx] = s_work.voltage;
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	goto	l4533
	line	509
	
l3849:	
;charge_mgr.c: 508: else
;charge_mgr.c: 509: g_slotRefV[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l4533
	line	516
	
l3851:	
;charge_mgr.c: 516: if(charge_ticks_prev < 1U && s_work.chargeTimer >= 1U)
	bcf	status, 5	;RP0=0, select bank0
	movf	((Slot_Charge_Ctrl@charge_ticks_prev)),w
iorwf	((Slot_Charge_Ctrl@charge_ticks_prev+1)),w
	btfss	status,2
	goto	u4871
	goto	u4870
u4871:
	goto	l3859
u4870:
	
l3853:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(0+(_s_work)^080h+04h),w
iorwf	(1+(_s_work)^080h+04h),w
	btfsc	status,2
	goto	u4881
	goto	u4880
u4881:
	goto	l3859
u4880:
	line	518
	
l3855:	
;charge_mgr.c: 517: {
;charge_mgr.c: 518: (g_stableCnt[idx]) = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	519
	
l3857:	
;charge_mgr.c: 519: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u4894
u4895:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u4894:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u4895
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	522
	
l3859:	
;charge_mgr.c: 520: }
;charge_mgr.c: 522: if(s_work.chargeTimer < (240))
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u4901
	goto	u4900
u4901:
	goto	l3863
u4900:
	goto	l4533
	line	537
	
l3863:	
;charge_mgr.c: 529: }
;charge_mgr.c: 537: if(charge_ticks_prev < (240) && s_work.chargeTimer >= (240))
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Slot_Charge_Ctrl@charge_ticks_prev+1),w
	movlw	0F0h
	skipnz
	subwf	(Slot_Charge_Ctrl@charge_ticks_prev),w
	skipnc
	goto	u4911
	goto	u4910
u4911:
	goto	l3873
u4910:
	
l3865:	
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u4921
	goto	u4920
u4921:
	goto	l3873
u4920:
	line	539
	
l3867:	
;charge_mgr.c: 538: {
;charge_mgr.c: 539: g_slotRefV[idx] = s_work.voltage;
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	540
	
l3869:	
;charge_mgr.c: 540: if(s_work.voltage > 2900)
	movlw	0Bh
	subwf	1+(_s_work)^080h+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u4931
	goto	u4930
u4931:
	goto	l4533
u4930:
	line	541
	
l3871:	
;charge_mgr.c: 541: g_capFlag |= (unsigned int)1 << idx;
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u4944
u4945:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u4944:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u4945
	
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_capFlag+1)^080h,f
	goto	l4533
	line	544
	
l3873:	
;charge_mgr.c: 543: }
;charge_mgr.c: 544: if(s_work.voltage > 2900 && s_work.voltage < 3990)
	movlw	0Bh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u4951
	goto	u4950
u4951:
	goto	l3935
u4950:
	
l3875:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u4961
	goto	u4960
u4961:
	goto	l3935
u4960:
	line	556
	
l3877:	
;charge_mgr.c: 545: {
;charge_mgr.c: 555: if(!(g_capFlag & ((unsigned int)1 << idx)) && s_work.type != 5 &&
;charge_mgr.c: 556: s_work.voltage <= 3500)
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u4974
u4975:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u4974:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u4975
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfss	status,2
	goto	u4981
	goto	u4980
u4981:
	goto	l3891
u4980:
	
l3879:	
		movlw	5
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u4991
	goto	u4990
u4991:
	goto	l3891
u4990:
	
l3881:	
	movlw	0Dh
	subwf	1+(_s_work)^080h+02h,w
	movlw	0ADh
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u5001
	goto	u5000
u5001:
	goto	l3891
u5000:
	line	558
	
l3883:	
;charge_mgr.c: 557: {
;charge_mgr.c: 558: s_work.chargeTimer = 0;
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	559
	
l3885:	
;charge_mgr.c: 559: g_slotRefV[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	560
	
l3887:	
;charge_mgr.c: 560: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	561
	
l3889:	
;charge_mgr.c: 561: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	562
;charge_mgr.c: 562: break;
	goto	l4533
	line	572
	
l3891:	
;charge_mgr.c: 563: }
;charge_mgr.c: 572: unsigned int v_init = g_slotRefV[idx];
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_init)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_init+1)
	line	574
;charge_mgr.c: 574: if((g_stableCnt[idx]) >= 20)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u5011
	goto	u5010
u5011:
	goto	l3915
u5010:
	line	579
	
l3893:	
;charge_mgr.c: 575: {
;charge_mgr.c: 579: g_highVFlag |= (unsigned int)1 << idx;
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5024
u5025:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5024:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5025
	
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(_g_highVFlag+1)^080h,f
	line	581
	
l3895:	
;charge_mgr.c: 581: if(s_work.voltage <= 2900)
	movlw	0Bh
	subwf	1+(_s_work)^080h+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u5031
	goto	u5030
u5031:
	goto	l3903
u5030:
	line	584
	
l3897:	
;charge_mgr.c: 582: {
;charge_mgr.c: 584: g_capFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5044
u5045:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5044:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5045
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	585
	
l3899:	
;charge_mgr.c: 585: (g_stableCnt[idx]) = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	586
	
l3901:	
;charge_mgr.c: 586: g_highVFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5054
u5055:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5054:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5055
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	587
;charge_mgr.c: 587: }
	goto	l3947
	line	588
	
l3903:	
;charge_mgr.c: 588: else if(s_work.chargeTimer < (240) + (800))
	movlw	04h
	subwf	1+(_s_work)^080h+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u5061
	goto	u5060
u5061:
	goto	l3913
u5060:
	line	595
	
l3905:	
;charge_mgr.c: 589: {
;charge_mgr.c: 595: if(s_work.chargeTimer >= (240) + 25U)
	movlw	01h
	subwf	1+(_s_work)^080h+04h,w
	movlw	09h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u5071
	goto	u5070
u5071:
	goto	l3847
u5070:
	line	597
	
l3907:	
;charge_mgr.c: 596: {
;charge_mgr.c: 597: Detect_Classify(idx, 1);
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Detect_Classify@fromHighV)
	incf	(Detect_Classify@fromHighV),f
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	598
;charge_mgr.c: 598: break;
	goto	l4533
	line	607
	
l3913:	
;charge_mgr.c: 604: else
;charge_mgr.c: 605: {
;charge_mgr.c: 607: Detect_Classify(idx, 1);
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Detect_Classify@fromHighV)
	incf	(Detect_Classify@fromHighV),f
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	608
;charge_mgr.c: 608: break;
	goto	l4533
	line	616
	
l3915:	
;charge_mgr.c: 611: else
;charge_mgr.c: 612: {
;charge_mgr.c: 616: if(s_work.chargeTimer >= (240) + (800))
	movlw	04h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u5081
	goto	u5080
u5081:
	goto	l3919
u5080:
	line	618
	
l3917:	
;charge_mgr.c: 617: {
;charge_mgr.c: 618: Detect_Classify(idx, 1);
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Detect_Classify@fromHighV)
	incf	(Detect_Classify@fromHighV),f
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	619
;charge_mgr.c: 619: break;
	goto	l4533
	line	624
	
l3919:	
;charge_mgr.c: 620: }
;charge_mgr.c: 624: g_slotRefV[idx] = s_work.voltage;
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	625
	
l3921:	
;charge_mgr.c: 625: if(s_work.voltage + 50 < v_init)
	movf	0+(_s_work)^080h+02h,w
	addlw	low(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v_init+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5095
	movf	(Slot_Charge_Ctrl@v_init),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5095:
	skipnc
	goto	u5091
	goto	u5090
u5091:
	goto	l3925
u5090:
	line	626
	
l3923:	
;charge_mgr.c: 626: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l652
	line	628
	
l3925:	
;charge_mgr.c: 627: else
;charge_mgr.c: 628: (g_stableCnt[idx])++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	
l652:	
	line	629
;charge_mgr.c: 629: if((g_stableCnt[idx]) < 20)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(014h)
	subwf	indf,w
	skipnc
	goto	u5101
	goto	u5100
u5101:
	goto	l3929
u5100:
	goto	l4533
	line	632
	
l3929:	
;charge_mgr.c: 632: if(g_capFlag & ((unsigned int)1 << idx))
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5114
u5115:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5114:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5115
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u5121
	goto	u5120
u5121:
	goto	l3933
u5120:
	goto	l4533
	line	634
	
l3933:	
;charge_mgr.c: 634: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l3947
	line	637
	
l3935:	
;charge_mgr.c: 637: else if(s_work.chargeTimer < (240) + (800) && s_work.voltage < 3990)
	movlw	04h
	subwf	1+(_s_work)^080h+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u5131
	goto	u5130
u5131:
	goto	l3947
u5130:
	
l3937:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u5141
	goto	u5140
u5141:
	goto	l3947
u5140:
	line	639
	
l3939:	
;charge_mgr.c: 638: {
;charge_mgr.c: 639: unsigned int v_ref = g_slotRefV[idx];
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_ref)
	incf	fsr0,f
	movf	indf,w
	movwf	(Slot_Charge_Ctrl@v_ref+1)
	line	640
	
l3941:	
;charge_mgr.c: 640: if(v_ref < 3990 && s_work.voltage + 50 < v_ref)
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@v_ref+1),w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@v_ref),w
	skipnc
	goto	u5151
	goto	u5150
u5151:
	goto	l3947
u5150:
	
l3943:	
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	addlw	low(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(032h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@v_ref+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5165
	movf	(Slot_Charge_Ctrl@v_ref),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5165:
	skipnc
	goto	u5161
	goto	u5160
u5161:
	goto	l3947
u5160:
	goto	l3847
	line	650
	
l3947:	
;charge_mgr.c: 644: }
;charge_mgr.c: 645: }
;charge_mgr.c: 650: if(g_capFlag & ((unsigned int)1 << idx))
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5174
u5175:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5174:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5175
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_capFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u5181
	goto	u5180
u5181:
	goto	l3955
u5180:
	line	652
	
l3949:	
;charge_mgr.c: 651: {
;charge_mgr.c: 652: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5194
u5195:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5194:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5195
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	653
	
l3951:	
;charge_mgr.c: 653: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	654
	
l3953:	
;charge_mgr.c: 654: s_work.type = 5;
	movlw	low(05h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	655
;charge_mgr.c: 655: }
	goto	l659
	line	658
	
l3955:	
;charge_mgr.c: 656: else
;charge_mgr.c: 657: {
;charge_mgr.c: 658: s_work.type = Detect_BatteryType(s_work.voltage);
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Detect_BatteryType@voltage+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Detect_BatteryType@voltage)
	fcall	_Detect_BatteryType
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	664
	
l3957:	
;charge_mgr.c: 663: if(s_work.type == 0 && s_work.voltage >= 3990 &&
;charge_mgr.c: 664: s_work.chargeTimer >= (240) + (800))
	movf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u5201
	goto	u5200
u5201:
	goto	l659
u5200:
	
l3959:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5211
	goto	u5210
u5211:
	goto	l659
u5210:
	
l3961:	
	movlw	04h
	subwf	1+(_s_work)^080h+04h,w
	movlw	010h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u5221
	goto	u5220
u5221:
	goto	l659
u5220:
	goto	l3953
	line	666
	
l659:	
	line	670
;charge_mgr.c: 666: }
;charge_mgr.c: 670: if(s_work.voltage < 500)
	movlw	01h
	subwf	1+(_s_work)^080h+02h,w
	movlw	0F4h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u5231
	goto	u5230
u5231:
	goto	l3969
u5230:
	line	672
	
l3965:	
;charge_mgr.c: 671: {
;charge_mgr.c: 672: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	673
;charge_mgr.c: 673: if(g_detectLowCnt[idx] < 5)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipnc
	goto	u5241
	goto	u5240
u5241:
	goto	l3977
u5240:
	goto	l4533
	line	677
	
l3969:	
;charge_mgr.c: 677: else if(s_work.type != 5 && s_work.type != 1 && s_work.type != 6)
		movlw	5
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u5251
	goto	u5250
u5251:
	goto	l3977
u5250:
	
l3971:	
		decf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u5261
	goto	u5260
u5261:
	goto	l3977
u5260:
	
l3973:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u5271
	goto	u5270
u5271:
	goto	l3977
u5270:
	line	679
	
l3975:	
;charge_mgr.c: 678: {
;charge_mgr.c: 679: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	686
	
l3977:	
;charge_mgr.c: 680: }
;charge_mgr.c: 686: Detect_Classify(idx, 0);
	bcf	status, 5	;RP0=0, select bank0
	clrf	(Detect_Classify@fromHighV)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Detect_Classify
	line	687
;charge_mgr.c: 687: break;
	goto	l4533
	line	692
	
l3979:	
;charge_mgr.c: 692: if(s_work.chargeTimer < 5)
	movlw	0
	subwf	1+(_s_work)^080h+04h,w
	movlw	05h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u5281
	goto	u5280
u5281:
	goto	l3983
u5280:
	goto	l4533
	line	697
	
l3983:	
;charge_mgr.c: 695: {
;charge_mgr.c: 697: Get_Vcc();
	fcall	_Get_Vcc
	line	703
	
l3985:	
;charge_mgr.c: 703: if(s_work.voltage >= 4050U && ((g_impData) & 0x0FFFU) >= 4050U)
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	0D2h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5291
	goto	u5290
u5291:
	goto	l3995
u5290:
	
l3987:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0D2h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u5301
	goto	u5300
u5301:
	goto	l3995
u5300:
	line	705
	
l3989:	
;charge_mgr.c: 704: {
;charge_mgr.c: 705: s_work.type = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_s_work)^080h+01h
	line	706
;charge_mgr.c: 706: s_work.state = 0;
	clrf	(_s_work)^080h
	line	707
	
l3991:	
;charge_mgr.c: 707: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_detectOwner)^080h
	line	708
	
l3993:	
;charge_mgr.c: 708: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5314
u5315:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5314:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5315
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	709
;charge_mgr.c: 709: break;
	goto	l4533
	line	719
	
l3995:	
;charge_mgr.c: 710: }
;charge_mgr.c: 718: {
;charge_mgr.c: 719: unsigned int vcc_norm_pre = ((unsigned int)(((unsigned long)((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U)) * 4096UL) / 5000UL));
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(0+(?___wmul)),w
	movwf	((??_Slot_Charge_Ctrl+0)+0)
	movf	(1+(?___wmul)),w
	movwf	((??_Slot_Charge_Ctrl+0)+0+1)
	clrf	((??_Slot_Charge_Ctrl+0)+0+2)
	clrf	((??_Slot_Charge_Ctrl+0)+0+3)
	movlw	0Ch
u5325:
	clrc
	rlf	(??_Slot_Charge_Ctrl+0)+0,f
	rlf	(??_Slot_Charge_Ctrl+0)+1,f
	rlf	(??_Slot_Charge_Ctrl+0)+2,f
	rlf	(??_Slot_Charge_Ctrl+0)+3,f
u5320:
	addlw	-1
	skipz
	goto	u5325
	movf	3+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_pre+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_pre)
	line	720
;charge_mgr.c: 720: unsigned int vcc_norm_now = ((unsigned int)(((unsigned long)(g_vcc_mv) * 4096UL) / 5000UL));
	movf	(_g_vcc_mv),w
	movwf	(___lldiv@dividend)
	movf	(_g_vcc_mv+1),w
	movwf	((___lldiv@dividend))+1
	clrf	2+((___lldiv@dividend))
	clrf	3+((___lldiv@dividend))
	movlw	0Ch
	movwf	(??_Slot_Charge_Ctrl+0)+0
u5335:
	clrc
	rlf	(___lldiv@dividend),f
	rlf	(___lldiv@dividend+1),f
	rlf	(___lldiv@dividend+2),f
	rlf	(___lldiv@dividend+3),f
	decfsz	(??_Slot_Charge_Ctrl+0)+0
	goto	u5335
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_now+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm_now)
	line	722
	
l3997:	
;charge_mgr.c: 721: if((((g_impData) & 0x0FFFU) + 150 >= vcc_norm_pre) &&
;charge_mgr.c: 722: (s_work.voltage + 150 >= vcc_norm_now))
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	(Slot_Charge_Ctrl@vcc_norm_pre+1),w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u5345
	movf	(Slot_Charge_Ctrl@vcc_norm_pre),w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u5345:
	skipc
	goto	u5341
	goto	u5340
u5341:
	goto	l4007
u5340:
	
l3999:	
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@vcc_norm_now+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5355
	movf	(Slot_Charge_Ctrl@vcc_norm_now),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5355:
	skipc
	goto	u5351
	goto	u5350
u5351:
	goto	l4007
u5350:
	goto	l3989
	line	735
	
l4007:	
;charge_mgr.c: 729: }
;charge_mgr.c: 730: }
;charge_mgr.c: 735: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 300U && s_work.voltage >= 3990)
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(012Ch)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(012Ch)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5365
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5365:
	skipnc
	goto	u5361
	goto	u5360
u5361:
	goto	l4015
u5360:
	
l4009:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5371
	goto	u5370
u5371:
	goto	l4015
u5370:
	line	737
	
l4011:	
;charge_mgr.c: 736: {
;charge_mgr.c: 737: s_work.type = 2;
	movlw	low(02h)
	movwf	0+(_s_work)^080h+01h
	line	738
;charge_mgr.c: 738: s_work.state = 7;
	movlw	low(07h)
	movwf	(_s_work)^080h
	line	739
;charge_mgr.c: 739: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_detectOwner)^080h
	goto	l3993
	line	749
	
l4015:	
;charge_mgr.c: 742: }
;charge_mgr.c: 748: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 200U &&
;charge_mgr.c: 749: ((g_impData) & 0x0FFFU) < 3100U)
	swapf	(_g_impData+1),w
	andlw	15
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(0C8h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5385
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5385:
	skipnc
	goto	u5381
	goto	u5380
u5381:
	goto	l4021
u5380:
	
l4017:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Ch
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	01Ch
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u5391
	goto	u5390
u5391:
	goto	l4021
u5390:
	line	751
	
l4019:	
;charge_mgr.c: 750: {
;charge_mgr.c: 751: s_work.state = Route_LiIon(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	752
;charge_mgr.c: 752: break;
	goto	l4533
	line	761
	
l4021:	
;charge_mgr.c: 753: }
;charge_mgr.c: 759: if(!(g_highVFlag & ((unsigned int)1 << idx)) &&
;charge_mgr.c: 760: (((g_impData) & 0x0FFFU) > s_work.voltage) &&
;charge_mgr.c: 761: (((g_impData) & 0x0FFFU) - s_work.voltage) > 1000U)
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5404
u5405:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5404:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5405
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfss	status,2
	goto	u5411
	goto	u5410
u5411:
	goto	l4033
u5410:
	
l4023:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u5425
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u5425:
	skipnc
	goto	u5421
	goto	u5420
u5421:
	goto	l4033
u5420:
	
l4025:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipc
	incf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	03h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0E9h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipc
	goto	u5431
	goto	u5430
u5431:
	goto	l4033
u5430:
	line	763
	
l4027:	
;charge_mgr.c: 762: {
;charge_mgr.c: 763: s_work.type = 3;
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	764
;charge_mgr.c: 764: s_work.state = 7;
	movlw	low(07h)
	movwf	(_s_work)^080h
	line	765
;charge_mgr.c: 765: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_detectOwner)^080h
	line	766
	
l4029:	
;charge_mgr.c: 766: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u5444
u5445:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u5444:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u5445
	
	comf	(??_Slot_Charge_Ctrl+1)+0,f
	comf	(??_Slot_Charge_Ctrl+1)+1,f
	movf	0+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Slot_Charge_Ctrl+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	goto	l3889
	line	775
	
l4033:	
;charge_mgr.c: 769: }
;charge_mgr.c: 774: if((((g_impData) & 0x0FFFU) > 3500) &&
;charge_mgr.c: 775: ((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) <= g_vcc_mv + 200U))
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Dh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0ADh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u5451
	goto	u5450
u5451:
	goto	l4039
u5450:
	
l4035:	
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(0C8h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(0C8h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5465
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5465:
	skipc
	goto	u5461
	goto	u5460
u5461:
	goto	l4039
u5460:
	line	777
	
l4037:	
;charge_mgr.c: 776: {
;charge_mgr.c: 777: Enter_DiodeTest(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Enter_DiodeTest
	line	778
;charge_mgr.c: 778: break;
	goto	l4533
	line	786
	
l4039:	
;charge_mgr.c: 779: }
;charge_mgr.c: 786: Enter_DiodeTest(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Enter_DiodeTest
	line	788
;charge_mgr.c: 787: }
;charge_mgr.c: 788: break;
	goto	l4533
	line	804
	
l4041:	
;charge_mgr.c: 803: {
;charge_mgr.c: 804: unsigned char pt = (unsigned char)(g_diodeTraceCnt + 1U);
	movf	(_g_diodeTraceCnt)^080h,w
	addlw	01h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@pt)
	line	805
	
l4043:	
;charge_mgr.c: 805: unsigned int ptTick = (unsigned int)pt * 7U;
	movf	(Slot_Charge_Ctrl@pt),w
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	07h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(1+(?___wmul)),w
	movwf	(Slot_Charge_Ctrl@ptTick+1)
	movf	(0+(?___wmul)),w
	movwf	(Slot_Charge_Ctrl@ptTick)
	line	806
	
l4045:	
;charge_mgr.c: 806: if(s_work.chargeTimer < ptTick)
	movf	(Slot_Charge_Ctrl@ptTick+1),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	skipz
	goto	u5475
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@ptTick),w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+04h,w
u5475:
	skipnc
	goto	u5471
	goto	u5470
u5471:
	goto	l4049
u5470:
	goto	l4065
	line	809
	
l4049:	
;charge_mgr.c: 808: {
;charge_mgr.c: 809: signed int diff = (signed int)s_work.voltage - (signed int)((g_impData) & 0x0FFFU);
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff)
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	(Slot_Charge_Ctrl@diff),f
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	decf	(Slot_Charge_Ctrl@diff+1),f
	subwf	(Slot_Charge_Ctrl@diff+1),f
	line	810
;charge_mgr.c: 810: diff >>= 2;
	rlf	(Slot_Charge_Ctrl@diff+1),w
	rrf	(Slot_Charge_Ctrl@diff+1),f
	rrf	(Slot_Charge_Ctrl@diff),f
	rlf	(Slot_Charge_Ctrl@diff+1),w
	rrf	(Slot_Charge_Ctrl@diff+1),f
	rrf	(Slot_Charge_Ctrl@diff),f
	line	811
	
l4051:	
;charge_mgr.c: 811: if(diff > 127) diff = 127;
	movf	(Slot_Charge_Ctrl@diff+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u5485
	movlw	080h
	subwf	(Slot_Charge_Ctrl@diff),w
u5485:

	skipc
	goto	u5481
	goto	u5480
u5481:
	goto	l4055
u5480:
	
l4053:	
	movlw	07Fh
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff)
	clrf	(Slot_Charge_Ctrl@diff+1)
	line	812
	
l4055:	
;charge_mgr.c: 812: if(diff < -128) diff = -128;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@diff+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u5495
	movlw	080h
	subwf	(Slot_Charge_Ctrl@diff),w
u5495:

	skipnc
	goto	u5491
	goto	u5490
u5491:
	goto	l4059
u5490:
	
l4057:	
	movlw	080h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Slot_Charge_Ctrl@diff)
	movlw	0FFh
	movwf	((Slot_Charge_Ctrl@diff))+1
	line	813
	
l4059:	
;charge_mgr.c: 813: g_diodeTrace[g_diodeTraceCnt++] = (unsigned char)(diff + 128);
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_diodeTraceCnt)^080h,w
	addlw	low(_g_diodeTrace|((0x1)<<8))&0ffh
	movwf	fsr0
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@diff),w
	addlw	080h
	bsf	status, 7	;select IRP bank3
	movwf	indf
	
l4061:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_diodeTraceCnt)^080h,f
	line	802
	
l4063:	
	movlw	low(04h)
	subwf	(_g_diodeTraceCnt)^080h,w
	skipc
	goto	u5501
	goto	u5500
u5501:
	goto	l4041
u5500:
	line	826
	
l4065:	
;charge_mgr.c: 814: }
;charge_mgr.c: 815: }
;charge_mgr.c: 816: {
;charge_mgr.c: 825: if(((g_impData) & 0x0FFFU) >= 2100 &&
;charge_mgr.c: 826: s_work.voltage > ((g_impData) & 0x0FFFU) + 900)
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	034h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u5511
	goto	u5510
u5511:
	goto	l4075
u5510:
	
l4067:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(0384h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(0384h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u5525
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u5525:
	skipnc
	goto	u5521
	goto	u5520
u5521:
	goto	l4075
u5520:
	line	830
	
l4069:	
;charge_mgr.c: 827: {
;charge_mgr.c: 830: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150U)
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5535
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5535:
	skipnc
	goto	u5531
	goto	u5530
u5531:
	goto	l4073
u5530:
	line	831
	
l4071:	
;charge_mgr.c: 831: s_work.state = Route_LiIon(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l4533
	line	833
	
l4073:	
;charge_mgr.c: 832: else
;charge_mgr.c: 833: s_work.state = Route_LinearLi(idx, (unsigned int)((g_impData) & 0x0FFFU));
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(Route_LinearLi@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l4533
	line	845
	
l4075:	
;charge_mgr.c: 835: }
;charge_mgr.c: 843: if((((g_impData) & 0x0FFFU) > 3000U) &&
;charge_mgr.c: 844: (s_work.voltage > 2900) &&
;charge_mgr.c: 845: (s_work.voltage < ((g_impData) & 0x0FFFU)))
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	0Bh
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0B9h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u5541
	goto	u5540
u5541:
	goto	l4083
u5540:
	
l4077:	
	movlw	0Bh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5551
	goto	u5550
u5551:
	goto	l4083
u5550:
	
l4079:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u5565
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u5565:
	skipnc
	goto	u5561
	goto	u5560
u5561:
	goto	l4083
u5560:
	line	847
	
l4081:	
;charge_mgr.c: 846: {
;charge_mgr.c: 847: s_work.state = Route_LinearLi(idx, (unsigned int)((g_impData) & 0x0FFFU));
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_LinearLi@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	848
;charge_mgr.c: 848: break;
	goto	l4533
	line	858
	
l4083:	
;charge_mgr.c: 849: }
;charge_mgr.c: 857: if((s_work.voltage > 2900) &&
;charge_mgr.c: 858: (((g_impData) & 0x0FFFU) < 2100))
	movlw	0Bh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	055h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5571
	goto	u5570
u5571:
	goto	l4093
u5570:
	
l4085:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	034h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u5581
	goto	u5580
u5581:
	goto	l4093
u5580:
	goto	l4027
	line	879
	
l4093:	
;charge_mgr.c: 866: }
;charge_mgr.c: 876: if(s_work.chargeTimer >= 20U && s_work.voltage > 2100U &&
;charge_mgr.c: 877: ((g_impData) & 0x0FFFU) <= 2300U &&
;charge_mgr.c: 878: s_work.voltage + 160U >= ((g_impData) & 0x0FFFU) &&
;charge_mgr.c: 879: s_work.voltage <= ((g_impData) & 0x0FFFU) + 150)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	014h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u5591
	goto	u5590
u5591:
	goto	l4105
u5590:
	
l4095:	
	movlw	08h
	subwf	1+(_s_work)^080h+02h,w
	movlw	035h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5601
	goto	u5600
u5601:
	goto	l4105
u5600:
	
l4097:	
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movlw	08h
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movlw	0FDh
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	goto	u5611
	goto	u5610
u5611:
	goto	l4105
u5610:
	
l4099:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	addlw	low(0A0h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(0A0h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u5625
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u5625:
	skipc
	goto	u5621
	goto	u5620
u5621:
	goto	l4105
u5620:
	
l4101:	
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	skipz
	goto	u5635
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
u5635:
	skipc
	goto	u5631
	goto	u5630
u5631:
	goto	l4105
u5630:
	line	881
	
l4103:	
;charge_mgr.c: 880: {
;charge_mgr.c: 881: s_work.state = Route_LinearLi(idx, (unsigned int)((g_impData) & 0x0FFFU));
	movlw	0FFh
	andwf	(_g_impData),w
	movwf	(Route_LinearLi@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	882
;charge_mgr.c: 882: break;
	goto	l4533
	line	890
	
l4105:	
;charge_mgr.c: 883: }
;charge_mgr.c: 890: if(s_work.chargeTimer >= 240)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u5641
	goto	u5640
u5641:
	goto	l4533
u5640:
	line	892
	
l4107:	
;charge_mgr.c: 891: {
;charge_mgr.c: 892: unsigned int pre = (unsigned int)((g_impData) & 0x0FFFU);
	movlw	0FFh
	andwf	(_g_impData),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Slot_Charge_Ctrl@pre)
	movlw	0Fh
	andwf	(_g_impData+1),w
	movwf	1+(Slot_Charge_Ctrl@pre)
	line	901
	
l4109:	
;charge_mgr.c: 900: {
;charge_mgr.c: 901: unsigned int vcc_norm = ((unsigned int)(((unsigned long)(g_vcc_mv) * 4096UL) / 5000UL));
	movf	(_g_vcc_mv),w
	movwf	(___lldiv@dividend)
	movf	(_g_vcc_mv+1),w
	movwf	((___lldiv@dividend))+1
	clrf	2+((___lldiv@dividend))
	clrf	3+((___lldiv@dividend))
	movlw	0Ch
	movwf	(??_Slot_Charge_Ctrl+0)+0
u5655:
	clrc
	rlf	(___lldiv@dividend),f
	rlf	(___lldiv@dividend+1),f
	rlf	(___lldiv@dividend+2),f
	rlf	(___lldiv@dividend+3),f
	decfsz	(??_Slot_Charge_Ctrl+0)+0
	goto	u5655
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm+1)
	movf	(0+(?___lldiv)),w
	movwf	(Slot_Charge_Ctrl@vcc_norm)
	line	902
	
l4111:	
;charge_mgr.c: 902: if(s_work.voltage + 150 >= vcc_norm)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@vcc_norm+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5665
	movf	(Slot_Charge_Ctrl@vcc_norm),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5665:
	skipc
	goto	u5661
	goto	u5660
u5661:
	goto	l4119
u5660:
	line	904
	
l4113:	
;charge_mgr.c: 903: {
;charge_mgr.c: 904: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150U)
	swapf	(_g_impData+1),w
	andlw	15
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5675
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5675:
	skipnc
	goto	u5671
	goto	u5670
u5671:
	goto	l4117
u5670:
	line	905
	
l4115:	
;charge_mgr.c: 905: s_work.state = Route_LiIon(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l4533
	line	907
	
l4117:	
;charge_mgr.c: 906: else
;charge_mgr.c: 907: s_work.state = Route_LinearLi(idx, pre);
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l4533
	line	918
	
l4119:	
;charge_mgr.c: 909: }
;charge_mgr.c: 910: }
;charge_mgr.c: 917: if(pre > 3500 && pre < 3990 &&
;charge_mgr.c: 918: s_work.voltage >= pre + 50)
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0ADh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipc
	goto	u5681
	goto	u5680
u5681:
	goto	l4131
u5680:
	
l4121:	
	movlw	0Fh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	096h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u5691
	goto	u5690
u5691:
	goto	l4131
u5690:
	
l4123:	
	movf	(Slot_Charge_Ctrl@pre),w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u5705
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u5705:
	skipc
	goto	u5701
	goto	u5700
u5701:
	goto	l4131
u5700:
	line	920
	
l4125:	
;charge_mgr.c: 919: {
;charge_mgr.c: 920: if((((((g_impData) >> 12) & 0x0FU) + 38U) * 100U) > g_vcc_mv + 150U)
	swapf	(_g_impData+1),w
	andlw	15
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___wmul@multiplier)
	clrf	(___wmul@multiplier+1)
	movlw	0Fh
	andwf	(___wmul@multiplier),f
	clrf	(___wmul@multiplier+1)
	movlw	026h
	addwf	(___wmul@multiplier),f
	skipnc
	incf	(___wmul@multiplier+1),f
	movlw	064h
	movwf	(___wmul@multiplicand)
	clrf	(___wmul@multiplicand+1)
	fcall	___wmul
	movf	(_g_vcc_mv),w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(1+(?___wmul)),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5715
	movf	(0+(?___wmul)),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5715:
	skipnc
	goto	u5711
	goto	u5710
u5711:
	goto	l4129
u5710:
	line	921
	
l4127:	
;charge_mgr.c: 921: s_work.state = Route_LiIon(idx);
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LiIon
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l4533
	line	923
	
l4129:	
;charge_mgr.c: 922: else
;charge_mgr.c: 923: s_work.state = Route_LinearLi(idx, pre);
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l4533
	line	944
	
l4131:	
;charge_mgr.c: 925: }
;charge_mgr.c: 941: if(s_work.voltage > 2600 && s_work.voltage < 3990 &&
;charge_mgr.c: 942: pre >= 2100 && pre < 3500U &&
;charge_mgr.c: 943: ((pre < 3000 && s_work.voltage + 150U >= pre) ||
;charge_mgr.c: 944: s_work.voltage >= pre + 50))
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	029h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5721
	goto	u5720
u5721:
	goto	l4147
u5720:
	
l4133:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u5731
	goto	u5730
u5731:
	goto	l4147
u5730:
	
l4135:	
	movlw	08h
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	034h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipc
	goto	u5741
	goto	u5740
u5741:
	goto	l4147
u5740:
	
l4137:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0ACh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u5751
	goto	u5750
u5751:
	goto	l4147
u5750:
	
l4139:	
	movlw	0Bh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0B8h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u5761
	goto	u5760
u5761:
	goto	l4143
u5760:
	
l4141:	
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	addlw	low(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipnc
	addlw	1
	addlw	high(096h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5775
	movf	(Slot_Charge_Ctrl@pre),w
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5775:
	skipnc
	goto	u5771
	goto	u5770
u5771:
	goto	l4145
u5770:
	
l4143:	
	movf	(Slot_Charge_Ctrl@pre),w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u5785
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u5785:
	skipc
	goto	u5781
	goto	u5780
u5781:
	goto	l4147
u5780:
	line	946
	
l4145:	
;charge_mgr.c: 945: {
;charge_mgr.c: 946: s_work.state = Route_LinearLi(idx, pre);
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	947
;charge_mgr.c: 947: break;
	goto	l4533
	line	955
	
l4147:	
;charge_mgr.c: 948: }
;charge_mgr.c: 954: if(s_work.voltage > pre + 150 && s_work.voltage < 3990 &&
;charge_mgr.c: 955: pre > 1936 && pre < 3500U)
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@pre),w
	addlw	low(096h)
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movf	(Slot_Charge_Ctrl@pre+1),w
	skipnc
	addlw	1
	addlw	high(096h)
	movwf	1+(??_Slot_Charge_Ctrl+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5795
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5795:
	skipnc
	goto	u5791
	goto	u5790
u5791:
	goto	l4027
u5790:
	
l4149:	
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u5801
	goto	u5800
u5801:
	goto	l4027
u5800:
	
l4151:	
	movlw	07h
	bcf	status, 5	;RP0=0, select bank0
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	091h
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipc
	goto	u5811
	goto	u5810
u5811:
	goto	l4027
u5810:
	
l4153:	
	movlw	0Dh
	subwf	(Slot_Charge_Ctrl@pre+1),w
	movlw	0ACh
	skipnz
	subwf	(Slot_Charge_Ctrl@pre),w
	skipnc
	goto	u5821
	goto	u5820
u5821:
	goto	l4027
u5820:
	line	957
	
l4155:	
;charge_mgr.c: 956: {
;charge_mgr.c: 957: s_work.state = Route_LinearLi(idx, pre);
	movf	(Slot_Charge_Ctrl@pre+1),w
	movwf	(Route_LinearLi@pre+1)
	movf	(Slot_Charge_Ctrl@pre),w
	movwf	(Route_LinearLi@pre)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	_Route_LinearLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	958
;charge_mgr.c: 958: break;
	goto	l4533
	line	971
	
l4163:	
;charge_mgr.c: 971: if(s_work.chargeTimer > (60 * 100))
	movlw	017h
	subwf	1+(_s_work)^080h+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u5831
	goto	u5830
u5831:
	goto	l4167
u5830:
	line	973
	
l4165:	
;charge_mgr.c: 972: {
;charge_mgr.c: 973: s_work.state = 7;
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	974
;charge_mgr.c: 974: break;
	goto	l4533
	line	976
	
l4167:	
;charge_mgr.c: 975: }
;charge_mgr.c: 976: if(s_work.voltage > 750)
	movlw	02h
	subwf	1+(_s_work)^080h+02h,w
	movlw	0EFh
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5841
	goto	u5840
u5841:
	goto	l4173
u5840:
	line	978
	
l4169:	
;charge_mgr.c: 977: {
;charge_mgr.c: 978: s_work.state = 3;
	movlw	low(03h)
	movwf	(_s_work)^080h
	line	979
	
l4171:	
;charge_mgr.c: 979: s_work.chargeTimer = 0;
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	980
;charge_mgr.c: 980: break;
	goto	l4533
	line	982
	
l4173:	
;charge_mgr.c: 981: }
;charge_mgr.c: 982: if(s_work.voltage >= 3850)
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5851
	goto	u5850
u5851:
	goto	l4533
u5850:
	goto	l4165
	line	991
	
l4177:	
;charge_mgr.c: 991: if(s_work.chargeTimer > (300 * 100))
	movlw	075h
	subwf	1+(_s_work)^080h+04h,w
	movlw	031h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u5861
	goto	u5860
u5861:
	goto	l4181
u5860:
	goto	l4165
	line	996
	
l4181:	
;charge_mgr.c: 995: }
;charge_mgr.c: 996: if(s_work.voltage >= 3850)
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5871
	goto	u5870
u5871:
	goto	l4187
u5870:
	line	998
	
l4183:	
;charge_mgr.c: 997: {
;charge_mgr.c: 998: g_ovCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	999
;charge_mgr.c: 999: if(g_ovCnt[idx] >= 5)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u5881
	goto	u5880
u5881:
	goto	l4189
u5880:
	goto	l4165
	line	1007
	
l4187:	
;charge_mgr.c: 1005: else
;charge_mgr.c: 1006: {
;charge_mgr.c: 1007: g_ovCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	1009
	
l4189:	
;charge_mgr.c: 1008: }
;charge_mgr.c: 1009: if(s_work.voltage >= 2700)
	movlw	0Ah
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	08Ch
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5891
	goto	u5890
u5891:
	goto	l4533
u5890:
	line	1011
	
l4191:	
;charge_mgr.c: 1010: {
;charge_mgr.c: 1011: s_work.state = 4;
	movlw	low(04h)
	movwf	(_s_work)^080h
	line	1012
	
l4193:	
;charge_mgr.c: 1012: s_work.chargeTimer = 0;
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	1013
	
l4195:	
;charge_mgr.c: 1013: g_ccBlocks[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1014
	
l4197:	
;charge_mgr.c: 1014: g_ovCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1015
	
l4199:	
;charge_mgr.c: 1015: g_slotRefV[idx] = s_work.voltage;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	1016
	
l4201:	
;charge_mgr.c: 1016: g_stableCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l4533
	line	1022
	
l4203:	
;charge_mgr.c: 1022: if(s_work.chargeTimer >= (600 * 100))
	movlw	0EAh
	subwf	1+(_s_work)^080h+04h,w
	movlw	060h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u5901
	goto	u5900
u5901:
	goto	l4209
u5900:
	line	1024
	
l4205:	
;charge_mgr.c: 1023: {
;charge_mgr.c: 1024: s_work.chargeTimer -= (600 * 100);
	movlw	060h
	subwf	0+(_s_work)^080h+04h,f
	movlw	0EAh
	skipc
	decf	1+(_s_work)^080h+04h,f
	subwf	1+(_s_work)^080h+04h,f
	line	1025
	
l4207:	
;charge_mgr.c: 1025: (g_ccBlocks[idx]++);
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1030
	
l4209:	
;charge_mgr.c: 1026: }
;charge_mgr.c: 1030: if(((g_ccBlocks[idx]) & 0x7FU) >= 18)
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(07Fh)
	bsf	status, 7	;select IRP bank3
	andwf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	low(012h)
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	skipc
	goto	u5911
	goto	u5910
u5911:
	goto	l4213
u5910:
	goto	l4165
	line	1039
	
l4213:	
;charge_mgr.c: 1034: }
;charge_mgr.c: 1039: if(s_work.voltage >= 3990 && s_work.type == 6)
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u5921
	goto	u5920
u5921:
	goto	l4219
u5920:
	
l4215:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u5931
	goto	u5930
u5931:
	goto	l4219
u5930:
	goto	l4227
	line	1043
	
l4219:	
;charge_mgr.c: 1043: else if(s_work.chargeTimer <= (6000))
	movlw	017h
	subwf	1+(_s_work)^080h+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u5941
	goto	u5940
u5941:
	goto	l4223
u5940:
	goto	l4227
	line	1051
	
l4223:	
;charge_mgr.c: 1049: else
;charge_mgr.c: 1050: {
;charge_mgr.c: 1051: if(s_work.voltage > g_slotRefV[idx]) g_slotRefV[idx] = s_work.voltage;
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipz
	goto	u5955
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
u5955:
	skipnc
	goto	u5951
	goto	u5950
u5951:
	goto	l4227
u5950:
	
l4225:	
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	1058
	
l4227:	
;charge_mgr.c: 1052: }
;charge_mgr.c: 1058: if(s_work.type == 6)
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u5961
	goto	u5960
u5961:
	goto	l4273
u5960:
	line	1060
	
l4229:	
;charge_mgr.c: 1059: {
;charge_mgr.c: 1060: if(s_work.voltage < 2000U)
	movlw	07h
	subwf	1+(_s_work)^080h+02h,w
	movlw	0D0h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u5971
	goto	u5970
u5971:
	goto	l4239
u5970:
	line	1062
	
l4231:	
;charge_mgr.c: 1061: {
;charge_mgr.c: 1062: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1063
;charge_mgr.c: 1063: if(g_detectLowCnt[idx] >= 33U)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u5981
	goto	u5980
u5981:
	goto	l4241
u5980:
	line	1065
	
l4233:	
;charge_mgr.c: 1064: {
;charge_mgr.c: 1065: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1066
	
l4235:	
;charge_mgr.c: 1066: s_work.state = 7;
	movlw	low(07h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l4171
	line	1073
	
l4239:	
;charge_mgr.c: 1071: else
;charge_mgr.c: 1072: {
;charge_mgr.c: 1073: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	1083
	
l4241:	
;charge_mgr.c: 1074: }
;charge_mgr.c: 1083: if(s_work.chargeTimer >= 1600)
	movlw	06h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	040h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u5991
	goto	u5990
u5991:
	goto	l4307
u5990:
	line	1085
	
l4243:	
;charge_mgr.c: 1084: {
;charge_mgr.c: 1085: s_work.chargeTimer = 0;
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	1086
	
l4245:	
;charge_mgr.c: 1086: if(s_work.voltage >= 2800U && s_work.voltage < 3990)
	movlw	0Ah
	subwf	1+(_s_work)^080h+02h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6001
	goto	u6000
u6001:
	goto	l4257
u6000:
	
l4247:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u6011
	goto	u6010
u6011:
	goto	l4257
u6010:
	line	1088
	
l4249:	
;charge_mgr.c: 1087: {
;charge_mgr.c: 1088: s_work.state = 5;
	movlw	low(05h)
	movwf	(_s_work)^080h
	line	1089
	
l4251:	
;charge_mgr.c: 1089: g_ccBlocks[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l4199
	line	1093
	
l4257:	
;charge_mgr.c: 1093: else if(s_work.voltage >= g_slotRefV[idx] + (30))
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u6025
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u6025:
	skipc
	goto	u6021
	goto	u6020
u6021:
	goto	l4261
u6020:
	line	1095
	
l4259:	
;charge_mgr.c: 1094: {
;charge_mgr.c: 1095: (g_stableCnt[idx]) = 1;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	indf,f
	line	1096
;charge_mgr.c: 1096: g_slotRefV[idx] = s_work.voltage;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	1097
;charge_mgr.c: 1097: }
	goto	l4533
	line	1098
	
l4261:	
;charge_mgr.c: 1098: else if((g_stableCnt[idx]) != 0)
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfsc	status,2
	goto	u6031
	goto	u6030
u6031:
	goto	l4265
u6030:
	goto	l3847
	line	1102
	
l4265:	
;charge_mgr.c: 1102: else if(((g_ccBlocks[idx]) & 0x80))
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	btfss	indf,(7)&7
	goto	u6041
	goto	u6040
u6041:
	goto	l4269
u6040:
	goto	l4165
	line	1108
	
l4269:	
;charge_mgr.c: 1106: else
;charge_mgr.c: 1107: {
;charge_mgr.c: 1108: (g_ccBlocks[idx] |= 0x80);
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(7/8),(7)&7
	line	1109
	
l4271:	
;charge_mgr.c: 1109: s_work.state = 1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_work)^080h
	incf	(_s_work)^080h,f
	line	1110
;charge_mgr.c: 1110: g_slotRefV[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	1111
;charge_mgr.c: 1111: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l4533
	line	1120
	
l4273:	
;charge_mgr.c: 1116: else
;charge_mgr.c: 1117: {
;charge_mgr.c: 1120: if((s_work.voltage < g_slotRefV[idx] && g_slotRefV[idx] - s_work.voltage > 500) || s_work.voltage < 2000U)
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u6055
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u6055:
	skipnc
	goto	u6051
	goto	u6050
u6051:
	goto	l4277
u6050:
	
l4275:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipc
	incf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	01h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipnc
	goto	u6061
	goto	u6060
u6061:
	goto	l4279
u6060:
	
l4277:	
	movlw	07h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	0D0h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u6071
	goto	u6070
u6071:
	goto	l4291
u6070:
	line	1122
	
l4279:	
;charge_mgr.c: 1121: {
;charge_mgr.c: 1122: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	1123
;charge_mgr.c: 1123: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u6081
	goto	u6080
u6081:
	goto	l4283
u6080:
	goto	l4533
	line	1125
	
l4283:	
;charge_mgr.c: 1125: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1126
	
l4285:	
;charge_mgr.c: 1126: s_work.state = 1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_work)^080h
	incf	(_s_work)^080h,f
	goto	l4171
	line	1132
	
l4291:	
;charge_mgr.c: 1130: else
;charge_mgr.c: 1131: {
;charge_mgr.c: 1132: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1140
	
l4293:	
;charge_mgr.c: 1133: }
;charge_mgr.c: 1140: if(s_work.chargeTimer <= (6000))
	movlw	017h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u6091
	goto	u6090
u6091:
	goto	l4299
u6090:
	line	1142
	
l4295:	
;charge_mgr.c: 1141: {
;charge_mgr.c: 1142: if(s_work.voltage >= g_slotRefV[idx] + (30))
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(01Eh)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(01Eh)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u6105
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u6105:
	skipc
	goto	u6101
	goto	u6100
u6101:
	goto	l4299
u6100:
	line	1143
	
l4297:	
;charge_mgr.c: 1143: (g_stableCnt[idx]) = 1;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	indf,f
	line	1145
	
l4299:	
;charge_mgr.c: 1144: }
;charge_mgr.c: 1145: if(s_work.chargeTimer > (6000) && (g_stableCnt[idx]) == 0)
	movlw	017h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u6111
	goto	u6110
u6111:
	goto	l4307
u6110:
	
l4301:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfss	status,2
	goto	u6121
	goto	u6120
u6121:
	goto	l4307
u6120:
	goto	l4235
	line	1159
	
l4307:	
;charge_mgr.c: 1150: }
;charge_mgr.c: 1151: }
;charge_mgr.c: 1159: if(s_work.voltage >= 3990 && s_work.type == 1)
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6131
	goto	u6130
u6131:
	goto	l4315
u6130:
	
l4309:	
		decf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6141
	goto	u6140
u6141:
	goto	l4315
u6140:
	line	1161
	
l4311:	
;charge_mgr.c: 1160: {
;charge_mgr.c: 1161: s_work.state = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	goto	l4171
	line	1169
	
l4315:	
;charge_mgr.c: 1164: }
;charge_mgr.c: 1169: if(s_work.voltage >= 3850 && s_work.type != 6)
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6151
	goto	u6150
u6151:
	goto	l4323
u6150:
	
l4317:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u6161
	goto	u6160
u6161:
	goto	l4323
u6160:
	line	1171
	
l4319:	
;charge_mgr.c: 1170: {
;charge_mgr.c: 1171: g_ovCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1172
;charge_mgr.c: 1172: if(g_ovCnt[idx] >= 5)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u6171
	goto	u6170
u6171:
	goto	l4533
u6170:
	goto	l4165
	line	1180
	
l4323:	
;charge_mgr.c: 1178: else
;charge_mgr.c: 1179: {
;charge_mgr.c: 1180: g_ovCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	1182
	
l4325:	
;charge_mgr.c: 1182: if(s_work.voltage >= 3100 && !(s_work.voltage >= 3990 && s_work.type == 6))
	movlw	0Ch
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	01Ch
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6181
	goto	u6180
u6181:
	goto	l4533
u6180:
	
l4327:	
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6191
	goto	u6190
u6191:
	goto	l4331
u6190:
	
l4329:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u6201
	goto	u6200
u6201:
	goto	l4533
u6200:
	line	1184
	
l4331:	
;charge_mgr.c: 1183: {
;charge_mgr.c: 1184: s_work.state = 5;
	movlw	low(05h)
	movwf	(_s_work)^080h
	line	1185
	
l4333:	
;charge_mgr.c: 1185: s_work.chargeTimer = 0;
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	1186
	
l4335:	
;charge_mgr.c: 1186: g_ccBlocks[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l4533
	line	1193
	
l4337:	
;charge_mgr.c: 1193: if(s_work.chargeTimer > (60 * 100))
	movlw	017h
	subwf	1+(_s_work)^080h+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipc
	goto	u6211
	goto	u6210
u6211:
	goto	l749
u6210:
	line	1194
	
l4339:	
;charge_mgr.c: 1194: s_work.state = 6;
	movlw	low(06h)
	movwf	(_s_work)^080h
	
l749:	
	line	1202
;charge_mgr.c: 1202: if(s_work.voltage >= 3990 && s_work.type == 6)
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6221
	goto	u6220
u6221:
	goto	l4345
u6220:
	
l4341:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6231
	goto	u6230
u6231:
	goto	l4345
u6230:
	goto	l4533
	line	1212
	
l4345:	
;charge_mgr.c: 1212: if(s_work.voltage < 3990 && s_work.chargeTimer <= (6000) && s_work.type == 1)
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u6241
	goto	u6240
u6241:
	goto	l4367
u6240:
	
l4347:	
	movlw	017h
	subwf	1+(_s_work)^080h+04h,w
	movlw	071h
	skipnz
	subwf	0+(_s_work)^080h+04h,w
	skipnc
	goto	u6251
	goto	u6250
u6251:
	goto	l4367
u6250:
	
l4349:	
		decf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6261
	goto	u6260
u6261:
	goto	l4367
u6260:
	line	1214
	
l4351:	
;charge_mgr.c: 1213: {
;charge_mgr.c: 1214: if((g_ccBlocks[idx]) == 0)
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	(indf),w
	btfss	status,2
	goto	u6271
	goto	u6270
u6271:
	goto	l4355
u6270:
	line	1216
	
l4353:	
;charge_mgr.c: 1215: {
;charge_mgr.c: 1216: g_slotRefV[idx] = s_work.voltage;
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	1+(_s_work)^080h+02h,w
	movwf	indf
	line	1217
;charge_mgr.c: 1217: (g_ccBlocks[idx]) = 1;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	incf	indf,f
	line	1218
;charge_mgr.c: 1218: }
	goto	l4367
	line	1219
	
l4355:	
;charge_mgr.c: 1219: else if(s_work.voltage >= g_slotRefV[idx] + (50))
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	addlw	low(032h)
	movwf	(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movf	1+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u6285
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+2)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u6285:
	skipc
	goto	u6281
	goto	u6280
u6281:
	goto	l4365
u6280:
	line	1221
	
l4357:	
;charge_mgr.c: 1220: {
;charge_mgr.c: 1221: if(++(g_stableCnt[idx]) >= 3)
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	movlw	low(03h)
	subwf	(indf),w
	skipc
	goto	u6291
	goto	u6290
u6291:
	goto	l753
u6290:
	line	1223
	
l4359:	
;charge_mgr.c: 1222: {
;charge_mgr.c: 1223: (g_stableCnt[idx]) = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l4235
	line	1231
	
l4365:	
;charge_mgr.c: 1229: else
;charge_mgr.c: 1230: {
;charge_mgr.c: 1231: (g_stableCnt[idx]) = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l4367
	line	1232
	
l753:	
	line	1240
	
l4367:	
;charge_mgr.c: 1232: }
;charge_mgr.c: 1233: }
;charge_mgr.c: 1240: if(s_work.voltage >= 3990)
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6301
	goto	u6300
u6301:
	goto	l4397
u6300:
	line	1242
	
l4369:	
;charge_mgr.c: 1241: {
;charge_mgr.c: 1242: if(s_work.type == 1)
		decf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6311
	goto	u6310
u6311:
	goto	l4381
u6310:
	line	1244
	
l4371:	
;charge_mgr.c: 1243: {
;charge_mgr.c: 1244: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1245
;charge_mgr.c: 1245: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u6321
	goto	u6320
u6321:
	goto	l4375
u6320:
	goto	l4533
	line	1247
	
l4375:	
;charge_mgr.c: 1247: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	goto	l4311
	line	1252
	
l4381:	
;charge_mgr.c: 1251: }
;charge_mgr.c: 1252: if(s_work.type == 6)
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6331
	goto	u6330
u6331:
	goto	l4385
u6330:
	goto	l4533
	line	1257
	
l4385:	
;charge_mgr.c: 1256: }
;charge_mgr.c: 1257: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1258
;charge_mgr.c: 1258: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u6341
	goto	u6340
u6341:
	goto	l4389
u6340:
	goto	l4533
	line	1260
	
l4389:	
;charge_mgr.c: 1260: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1261
	
l4391:	
;charge_mgr.c: 1261: s_work.type = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_s_work)^080h+01h
	line	1262
	
l4393:	
;charge_mgr.c: 1262: s_work.state = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_s_work)^080h
	goto	l4171
	line	1272
	
l4397:	
;charge_mgr.c: 1265: }
;charge_mgr.c: 1272: if(s_work.type == 6)
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6351
	goto	u6350
u6351:
	goto	l4411
u6350:
	line	1274
	
l4399:	
;charge_mgr.c: 1273: {
;charge_mgr.c: 1274: if(s_work.voltage < 2000U)
	movlw	07h
	subwf	1+(_s_work)^080h+02h,w
	movlw	0D0h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u6361
	goto	u6360
u6361:
	goto	l4409
u6360:
	line	1276
	
l4401:	
;charge_mgr.c: 1275: {
;charge_mgr.c: 1276: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1277
;charge_mgr.c: 1277: if(g_detectLowCnt[idx] >= 33U)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(021h)
	subwf	indf,w
	skipc
	goto	u6371
	goto	u6370
u6371:
	goto	l4427
u6370:
	goto	l4233
	line	1287
	
l4409:	
;charge_mgr.c: 1285: else
;charge_mgr.c: 1286: {
;charge_mgr.c: 1287: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l4427
	line	1292
	
l4411:	
;charge_mgr.c: 1290: else
;charge_mgr.c: 1291: {
;charge_mgr.c: 1292: if(s_work.voltage < g_slotRefV[idx] && g_slotRefV[idx] - s_work.voltage > 500)
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	movf	1+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	skipz
	goto	u6385
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_Slot_Charge_Ctrl+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	0+(_s_work)^080h+02h,w
u6385:
	skipnc
	goto	u6381
	goto	u6380
u6381:
	goto	l4409
u6380:
	
l4413:	
	bcf	status, 5	;RP0=0, select bank0
	clrc
	rlf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Slot_Charge_Ctrl+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	(??_Slot_Charge_Ctrl+2)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	skipc
	incf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_Slot_Charge_Ctrl+0)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+2)+0
	movlw	01h
	subwf	1+(??_Slot_Charge_Ctrl+2)+0,w
	movlw	0F5h
	skipnz
	subwf	0+(??_Slot_Charge_Ctrl+2)+0,w
	skipc
	goto	u6391
	goto	u6390
u6391:
	goto	l4409
u6390:
	line	1294
	
l4415:	
;charge_mgr.c: 1293: {
;charge_mgr.c: 1294: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	incf	indf,f
	line	1295
;charge_mgr.c: 1295: if(g_detectLowCnt[idx] >= 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipc
	goto	u6401
	goto	u6400
u6401:
	goto	l4427
u6400:
	line	1297
	
l4417:	
;charge_mgr.c: 1296: {
;charge_mgr.c: 1297: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1298
;charge_mgr.c: 1298: (g_ccBlocks[idx])++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1300
	
l4419:	
;charge_mgr.c: 1300: s_work.type = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_s_work)^080h+01h
	goto	l4285
	line	1316
	
l4427:	
;charge_mgr.c: 1309: }
;charge_mgr.c: 1310: }
;charge_mgr.c: 1316: if(s_work.voltage >= 3850 && s_work.type == 1)
	movlw	0Fh
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	0Ah
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6411
	goto	u6410
u6411:
	goto	l4435
u6410:
	
l4429:	
		decf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6421
	goto	u6420
u6421:
	goto	l4435
u6420:
	line	1318
	
l4431:	
;charge_mgr.c: 1317: {
;charge_mgr.c: 1318: g_ovCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	line	1319
;charge_mgr.c: 1319: if(g_ovCnt[idx] >= 5)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u6431
	goto	u6430
u6431:
	goto	l4533
u6430:
	goto	l4165
	line	1327
	
l4435:	
;charge_mgr.c: 1325: else
;charge_mgr.c: 1326: {
;charge_mgr.c: 1327: g_ovCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l4533
	line	1338
	
l4437:	
;charge_mgr.c: 1338: if(s_work.voltage >= 3990)
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6441
	goto	u6440
u6441:
	goto	l4455
u6440:
	line	1340
	
l4439:	
;charge_mgr.c: 1339: {
;charge_mgr.c: 1340: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1341
	
l4441:	
;charge_mgr.c: 1341: if(g_detectLowCnt[idx] >= (s_work.type == 6 ? 50 : 2))
		movlw	6
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u6451
	goto	u6450
u6451:
	goto	l4445
u6450:
	
l4443:	
	movlw	02h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Slot_Charge_Ctrl$341)
	clrf	(_Slot_Charge_Ctrl$341+1)
	goto	l4447
	
l4445:	
	movlw	032h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_Slot_Charge_Ctrl$341)
	clrf	(_Slot_Charge_Ctrl$341+1)
	
l4447:	
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(_Slot_Charge_Ctrl$341+1),w
	xorlw	80h
	sublw	080h
	skipz
	goto	u6465
	movf	(_Slot_Charge_Ctrl$341),w
	subwf	indf,w
u6465:

	skipc
	goto	u6461
	goto	u6460
u6461:
	goto	l4533
u6460:
	line	1343
	
l4449:	
;charge_mgr.c: 1342: {
;charge_mgr.c: 1343: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l4393
	line	1352
	
l4455:	
;charge_mgr.c: 1348: }
;charge_mgr.c: 1352: if(s_work.voltage < 2800U)
	movlw	0Ah
	subwf	1+(_s_work)^080h+02h,w
	movlw	0F0h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u6471
	goto	u6470
u6471:
	goto	l3889
u6470:
	line	1354
	
l4457:	
;charge_mgr.c: 1353: {
;charge_mgr.c: 1354: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1355
;charge_mgr.c: 1355: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u6481
	goto	u6480
u6481:
	goto	l4461
u6480:
	goto	l4533
	line	1357
	
l4461:	
;charge_mgr.c: 1357: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1358
	
l4463:	
;charge_mgr.c: 1358: s_work.state = 4;
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	1359
	
l4465:	
;charge_mgr.c: 1359: s_work.chargeTimer = 0;
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	1360
	
l4467:	
;charge_mgr.c: 1360: g_ovCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l4251
	line	1373
	
l4477:	
;charge_mgr.c: 1373: if(s_work.voltage >= 3990)
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6491
	goto	u6490
u6491:
	goto	l4493
u6490:
	line	1375
	
l4479:	
;charge_mgr.c: 1374: {
;charge_mgr.c: 1375: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1376
;charge_mgr.c: 1376: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u6501
	goto	u6500
u6501:
	goto	l4483
u6500:
	goto	l4533
	line	1378
	
l4483:	
;charge_mgr.c: 1378: g_detectLowCnt[idx] = 0;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	1379
	
l4485:	
;charge_mgr.c: 1379: s_work.type = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_s_work)^080h+01h
	line	1380
	
l4487:	
;charge_mgr.c: 1380: s_work.state = 0;
	clrf	(_s_work)^080h
	goto	l4333
	line	1393
	
l4493:	
;charge_mgr.c: 1384: }
;charge_mgr.c: 1393: if(s_work.type == 2 || s_work.type == 3)
		movlw	2
	xorwf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u6511
	goto	u6510
u6511:
	goto	l4497
u6510:
	
l4495:	
		movlw	3
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u6521
	goto	u6520
u6521:
	goto	l4513
u6520:
	line	1395
	
l4497:	
;charge_mgr.c: 1394: {
;charge_mgr.c: 1395: if(s_work.voltage > 2700U && (g_highVFlag & ((unsigned int)1 << idx)))
	movlw	0Ah
	subwf	1+(_s_work)^080h+02h,w
	movlw	08Dh
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6531
	goto	u6530
u6531:
	goto	l3889
u6530:
	
l4499:	
	bcf	status, 5	;RP0=0, select bank0
	incf	(Slot_Charge_Ctrl@idx),w
	movwf	(??_Slot_Charge_Ctrl+0)+0
	movlw	01h
	movwf	(??_Slot_Charge_Ctrl+1)+0
	movlw	0
	movwf	(??_Slot_Charge_Ctrl+1)+0+1
	goto	u6544
u6545:
	clrc
	rlf	(??_Slot_Charge_Ctrl+1)+0,f
	rlf	(??_Slot_Charge_Ctrl+1)+1,f
u6544:
	decfsz	(??_Slot_Charge_Ctrl+0)+0,f
	goto	u6545
	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	0+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	(??_Slot_Charge_Ctrl+3)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_highVFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	andwf	1+(??_Slot_Charge_Ctrl+1)+0,w
	movwf	1+(??_Slot_Charge_Ctrl+3)+0
	movf	((??_Slot_Charge_Ctrl+3)+0),w
iorwf	((??_Slot_Charge_Ctrl+3)+1),w
	btfsc	status,2
	goto	u6551
	goto	u6550
u6551:
	goto	l3889
u6550:
	line	1397
	
l4501:	
;charge_mgr.c: 1396: {
;charge_mgr.c: 1397: g_detectLowCnt[idx]++;
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1398
;charge_mgr.c: 1398: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u6561
	goto	u6560
u6561:
	goto	l4283
u6560:
	goto	l4533
	line	1411
	
l4513:	
;charge_mgr.c: 1409: }
;charge_mgr.c: 1411: if(s_work.voltage > 750)
	movlw	02h
	subwf	1+(_s_work)^080h+02h,w
	movlw	0EFh
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u6571
	goto	u6570
u6571:
	goto	l3889
u6570:
	line	1413
	
l4515:	
;charge_mgr.c: 1412: {
;charge_mgr.c: 1413: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	1414
;charge_mgr.c: 1414: if(g_detectLowCnt[idx] < 2)
	movf	(Slot_Charge_Ctrl@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u6581
	goto	u6580
u6581:
	goto	l4283
u6580:
	goto	l4533
	line	1427
	
l4527:	
;charge_mgr.c: 1427: s_work.state = 0;
	clrf	(_s_work)^080h
	line	1428
;charge_mgr.c: 1428: break;
	goto	l4533
	line	482
	
l4531:	
	bsf	status, 5	;RP0=1, select bank1
	movf	(_s_work)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 10, Range of values is 0 to 9
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           31    16 (average)
; direct_byte           38     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l3823
	xorlw	1^0	; case 1
	skipnz
	goto	l3851
	xorlw	2^1	; case 2
	skipnz
	goto	l4163
	xorlw	3^2	; case 3
	skipnz
	goto	l4177
	xorlw	4^3	; case 4
	skipnz
	goto	l4203
	xorlw	5^4	; case 5
	skipnz
	goto	l4337
	xorlw	6^5	; case 6
	skipnz
	goto	l4437
	xorlw	7^6	; case 7
	skipnz
	goto	l4477
	xorlw	8^7	; case 8
	skipnz
	goto	l3979
	xorlw	9^8	; case 9
	skipnz
	goto	l4063
	goto	l4527
	opt asmopt_pop

	line	1440
	
l4533:	
;charge_mgr.c: 1439: if(s_work.state == 1 || s_work.state == 8 ||
;charge_mgr.c: 1440: s_work.state == 9)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
		decf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6591
	goto	u6590
u6591:
	goto	l4539
u6590:
	
l4535:	
		movlw	8
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6601
	goto	u6600
u6601:
	goto	l4539
u6600:
	
l4537:	
		movlw	9
	xorwf	((_s_work)^080h),w
	btfss	status,2
	goto	u6611
	goto	u6610
u6611:
	goto	l4543
u6610:
	line	1442
	
l4539:	
;charge_mgr.c: 1441: {
;charge_mgr.c: 1442: if(g_detectOwner == 0xFF)
		incf	((_g_detectOwner)^080h),w
	btfss	status,2
	goto	u6621
	goto	u6620
u6621:
	goto	l800
u6620:
	line	1443
	
l4541:	
;charge_mgr.c: 1443: g_detectOwner = idx;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	goto	l800
	line	1447
	
l4543:	
;charge_mgr.c: 1445: else
;charge_mgr.c: 1446: {
;charge_mgr.c: 1447: if(g_detectOwner == idx)
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u6631
	goto	u6630
u6631:
	goto	l800
u6630:
	line	1448
	
l4545:	
;charge_mgr.c: 1448: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	1449
	
l800:	
	line	1455
;charge_mgr.c: 1449: }
;charge_mgr.c: 1453: if(g_detectWaiter == idx &&
;charge_mgr.c: 1454: !(s_work.state == 1 || s_work.state == 8 ||
;charge_mgr.c: 1455: s_work.state == 9))
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_detectWaiter)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u6641
	goto	u6640
u6641:
	goto	l4555
u6640:
	
l4547:	
	bsf	status, 5	;RP0=1, select bank1
		decf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6651
	goto	u6650
u6651:
	goto	l4555
u6650:
	
l4549:	
		movlw	8
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6661
	goto	u6660
u6661:
	goto	l4555
u6660:
	
l4551:	
		movlw	9
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6671
	goto	u6670
u6671:
	goto	l4555
u6670:
	line	1456
	
l4553:	
;charge_mgr.c: 1456: g_detectWaiter = 0xFF;
	movlw	low(0FFh)
	movwf	(_g_detectWaiter)^080h
	line	1458
	
l4555:	
;charge_mgr.c: 1458: g_slot[idx] = s_work;
	movlw	low(06h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___bmul@multiplicand)
	movf	(Slot_Charge_Ctrl@idx),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_s_work)^080h,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+4,w
	movwf	indf
	incf	fsr0,f
	movf	(_s_work)^080h+5,w
	movwf	indf
	line	1467
	
l4557:	
;charge_mgr.c: 1465: if((s_work.state == 2 || s_work.state == 3 ||
;charge_mgr.c: 1466: s_work.state == 4 || s_work.state == 5) &&
;charge_mgr.c: 1467: g_detectOwner != 0xFF)
		movlw	2
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6681
	goto	u6680
u6681:
	goto	l4565
u6680:
	
l4559:	
		movlw	3
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6691
	goto	u6690
u6691:
	goto	l4565
u6690:
	
l4561:	
		movlw	4
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6701
	goto	u6700
u6701:
	goto	l4565
u6700:
	
l4563:	
		movlw	5
	xorwf	((_s_work)^080h),w
	btfss	status,2
	goto	u6711
	goto	u6710
u6711:
	goto	l4571
u6710:
	
l4565:	
		incf	((_g_detectOwner)^080h),w
	btfsc	status,2
	goto	u6721
	goto	u6720
u6721:
	goto	l4571
u6720:
	goto	l4569
	line	1469
	
l808:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1072/8)^080h,(1072)&7	;volatile
	goto	l596
	
l810:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1073/8)^080h,(1073)&7	;volatile
	goto	l596
	
l811:	
	bsf	(51/8),(51)&7	;volatile
	goto	l596
	
l812:	
	bsf	(50/8),(50)&7	;volatile
	goto	l596
	
l813:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1075/8)^080h,(1075)&7	;volatile
	goto	l596
	
l814:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1074/8)^080h,(1074)&7	;volatile
	goto	l596
	
l815:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l596
	
l816:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l596
	
l817:	
	bsf	(48/8),(48)&7	;volatile
	goto	l596
	
l818:	
	bsf	(49/8),(49)&7	;volatile
	goto	l596
	
l819:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l596
	
l820:	
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l596
	
l4569:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l808
	xorlw	1^0	; case 1
	skipnz
	goto	l810
	xorlw	2^1	; case 2
	skipnz
	goto	l811
	xorlw	3^2	; case 3
	skipnz
	goto	l812
	xorlw	4^3	; case 4
	skipnz
	goto	l813
	xorlw	5^4	; case 5
	skipnz
	goto	l814
	xorlw	6^5	; case 6
	skipnz
	goto	l815
	xorlw	7^6	; case 7
	skipnz
	goto	l816
	xorlw	8^7	; case 8
	skipnz
	goto	l817
	xorlw	9^8	; case 9
	skipnz
	goto	l818
	xorlw	10^9	; case 10
	skipnz
	goto	l819
	xorlw	11^10	; case 11
	skipnz
	goto	l820
	goto	l596
	opt asmopt_pop

	line	1474
	
l4571:	
;charge_mgr.c: 1471: else if((s_work.state == 2 || s_work.state == 3 ||
;charge_mgr.c: 1472: s_work.state == 4 || s_work.state == 5 ||
;charge_mgr.c: 1473: ((s_work.state == 8 || s_work.state == 1) && g_detectOwner == idx)) &&
;charge_mgr.c: 1474: !g_tempProtect && !g_vccProtect)
		movlw	2
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6731
	goto	u6730
u6731:
	goto	l4585
u6730:
	
l4573:	
		movlw	3
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6741
	goto	u6740
u6741:
	goto	l4585
u6740:
	
l4575:	
		movlw	4
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6751
	goto	u6750
u6751:
	goto	l4585
u6750:
	
l4577:	
		movlw	5
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6761
	goto	u6760
u6761:
	goto	l4585
u6760:
	
l4579:	
		movlw	8
	xorwf	((_s_work)^080h),w
	btfsc	status,2
	goto	u6771
	goto	u6770
u6771:
	goto	l4583
u6770:
	
l4581:	
		decf	((_s_work)^080h),w
	btfss	status,2
	goto	u6781
	goto	u6780
u6781:
	goto	l4595
u6780:
	
l4583:	
	movf	(_g_detectOwner)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(Slot_Charge_Ctrl@idx),w
	skipz
	goto	u6791
	goto	u6790
u6791:
	goto	l4595
u6790:
	
l4585:	
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u6801
	goto	u6800
u6801:
	goto	l4595
u6800:
	
l4587:	
	movf	((_g_vccProtect)^080h),w
	btfss	status,2
	goto	u6811
	goto	u6810
u6811:
	goto	l4595
u6810:
	goto	l4591
	line	1476
	
l830:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1072/8)^080h,(1072)&7	;volatile
	goto	l596
	
l832:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1073/8)^080h,(1073)&7	;volatile
	goto	l596
	
l833:	
	bcf	(51/8),(51)&7	;volatile
	goto	l596
	
l834:	
	bcf	(50/8),(50)&7	;volatile
	goto	l596
	
l835:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1075/8)^080h,(1075)&7	;volatile
	goto	l596
	
l836:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1074/8)^080h,(1074)&7	;volatile
	goto	l596
	
l837:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2105/8)^0100h,(2105)&7	;volatile
	goto	l596
	
l838:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	l596
	
l839:	
	bcf	(48/8),(48)&7	;volatile
	goto	l596
	
l840:	
	bcf	(49/8),(49)&7	;volatile
	goto	l596
	
l841:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	l596
	
l842:	
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2104/8)^0100h,(2104)&7	;volatile
	goto	l596
	
l4591:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l830
	xorlw	1^0	; case 1
	skipnz
	goto	l832
	xorlw	2^1	; case 2
	skipnz
	goto	l833
	xorlw	3^2	; case 3
	skipnz
	goto	l834
	xorlw	4^3	; case 4
	skipnz
	goto	l835
	xorlw	5^4	; case 5
	skipnz
	goto	l836
	xorlw	6^5	; case 6
	skipnz
	goto	l837
	xorlw	7^6	; case 7
	skipnz
	goto	l838
	xorlw	8^7	; case 8
	skipnz
	goto	l839
	xorlw	9^8	; case 9
	skipnz
	goto	l840
	xorlw	10^9	; case 10
	skipnz
	goto	l841
	xorlw	11^10	; case 11
	skipnz
	goto	l842
	goto	l596
	opt asmopt_pop

	line	1480
	
l4595:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(Slot_Charge_Ctrl@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l808
	xorlw	1^0	; case 1
	skipnz
	goto	l810
	xorlw	2^1	; case 2
	skipnz
	goto	l811
	xorlw	3^2	; case 3
	skipnz
	goto	l812
	xorlw	4^3	; case 4
	skipnz
	goto	l813
	xorlw	5^4	; case 5
	skipnz
	goto	l814
	xorlw	6^5	; case 6
	skipnz
	goto	l815
	xorlw	7^6	; case 7
	skipnz
	goto	l816
	xorlw	8^7	; case 8
	skipnz
	goto	l817
	xorlw	9^8	; case 9
	skipnz
	goto	l818
	xorlw	10^9	; case 10
	skipnz
	goto	l819
	xorlw	11^10	; case 11
	skipnz
	goto	l820
	goto	l596
	opt asmopt_pop

	line	1482
	
l596:	
	return
	opt stack 0
GLOBAL	__end_of_Slot_Charge_Ctrl
	__end_of_Slot_Charge_Ctrl:
	signat	_Slot_Charge_Ctrl,4217
	global	___wmul

;; *************** function ___wmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
;; Parameters:    Size  Location     Type
;;  multiplier      2    0[BANK0 ] unsigned int 
;;  multiplicand    2    2[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  product         2    4[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       6       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
global __ptext6
__ptext6:	;psect for function ___wmul
psect	text6
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul16.c"
	line	15
	global	__size_of___wmul
	__size_of___wmul	equ	__end_of___wmul-___wmul
	
___wmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___wmul: [wreg+status,2+status,0]
	line	43
	
l3523:	
	clrf	(___wmul@product)
	clrf	(___wmul@product+1)
	line	45
	
l3525:	
	btfss	(___wmul@multiplier),(0)&7
	goto	u4401
	goto	u4400
u4401:
	goto	l3529
u4400:
	line	46
	
l3527:	
	movf	(___wmul@multiplicand),w
	addwf	(___wmul@product),f
	skipnc
	incf	(___wmul@product+1),f
	movf	(___wmul@multiplicand+1),w
	addwf	(___wmul@product+1),f
	line	47
	
l3529:	
	clrc
	rlf	(___wmul@multiplicand),f
	rlf	(___wmul@multiplicand+1),f
	line	48
	
l3531:	
	clrc
	rrf	(___wmul@multiplier+1),f
	rrf	(___wmul@multiplier),f
	line	49
	
l3533:	
	movf	((___wmul@multiplier)),w
iorwf	((___wmul@multiplier+1)),w
	btfss	status,2
	goto	u4411
	goto	u4410
u4411:
	goto	l3525
u4410:
	line	52
	
l3535:	
	movf	(___wmul@product+1),w
	movwf	(?___wmul+1)
	movf	(___wmul@product),w
	movwf	(?___wmul)
	line	53
	
l955:	
	return
	opt stack 0
GLOBAL	__end_of___wmul
	__end_of___wmul:
	signat	___wmul,8314
	global	_Route_LinearLi

;; *************** function _Route_LinearLi *****************
;; Defined at:
;;		line 315 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  pre             2   43[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1   48[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       6       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Route_DetectLi
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	315
global __ptext7
__ptext7:	;psect for function _Route_LinearLi
psect	text7
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	315
	global	__size_of_Route_LinearLi
	__size_of_Route_LinearLi	equ	__end_of_Route_LinearLi-_Route_LinearLi
	
_Route_LinearLi:	
;incstack = 0
	opt	stack 1
; Regs used in _Route_LinearLi: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Route_LinearLi@idx stored from wreg
	movwf	(Route_LinearLi@idx)
	line	317
	
l3437:	
;charge_mgr.c: 317: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	318
	
l3439:	
;charge_mgr.c: 318: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Route_LinearLi@idx),w
	movwf	(??_Route_LinearLi+0)+0
	movlw	01h
	movwf	(??_Route_LinearLi+1)+0
	movlw	0
	movwf	(??_Route_LinearLi+1)+0+1
	goto	u4264
u4265:
	clrc
	rlf	(??_Route_LinearLi+1)+0,f
	rlf	(??_Route_LinearLi+1)+1,f
u4264:
	decfsz	(??_Route_LinearLi+0)+0,f
	goto	u4265
	
	comf	(??_Route_LinearLi+1)+0,f
	comf	(??_Route_LinearLi+1)+1,f
	movf	0+(??_Route_LinearLi+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Route_LinearLi+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	319
	
l3441:	
;charge_mgr.c: 319: if(((g_ccBlocks[idx]) & 0x80))
	bcf	status, 5	;RP0=0, select bank0
	movf	(Route_LinearLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	btfss	indf,(7)&7
	goto	u4271
	goto	u4270
u4271:
	goto	l3447
u4270:
	line	321
	
l3443:	
;charge_mgr.c: 320: {
;charge_mgr.c: 321: s_work.type = 3;
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	322
;charge_mgr.c: 322: return 7;
	movlw	low(07h)
	goto	l554
	line	324
	
l3447:	
;charge_mgr.c: 323: }
;charge_mgr.c: 324: s_work.type = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	325
	
l3449:	
;charge_mgr.c: 325: s_work.chargeTimer = 0;
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	326
	
l3451:	
;charge_mgr.c: 326: return Route_DetectLi(idx, pre);
	bcf	status, 5	;RP0=0, select bank0
	movf	(Route_LinearLi@pre+1),w
	movwf	(Route_DetectLi@slot_v+1)
	movf	(Route_LinearLi@pre),w
	movwf	(Route_DetectLi@slot_v)
	movf	(Route_LinearLi@idx),w
	fcall	_Route_DetectLi
	line	327
	
l554:	
	return
	opt stack 0
GLOBAL	__end_of_Route_LinearLi
	__end_of_Route_LinearLi:
	signat	_Route_LinearLi,8313
	global	_Route_LiIon

;; *************** function _Route_LiIon *****************
;; Defined at:
;;		line 290 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   46[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Route_DetectLi
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	290
global __ptext8
__ptext8:	;psect for function _Route_LiIon
psect	text8
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	290
	global	__size_of_Route_LiIon
	__size_of_Route_LiIon	equ	__end_of_Route_LiIon-_Route_LiIon
	
_Route_LiIon:	
;incstack = 0
	opt	stack 1
; Regs used in _Route_LiIon: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Route_LiIon@idx stored from wreg
	movwf	(Route_LiIon@idx)
	line	292
	
l3425:	
;charge_mgr.c: 292: g_detectOwner = 0xFF;
	movlw	low(0FFh)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	293
	
l3427:	
;charge_mgr.c: 293: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Route_LiIon@idx),w
	movwf	(??_Route_LiIon+0)+0
	movlw	01h
	movwf	(??_Route_LiIon+1)+0
	movlw	0
	movwf	(??_Route_LiIon+1)+0+1
	goto	u4254
u4255:
	clrc
	rlf	(??_Route_LiIon+1)+0,f
	rlf	(??_Route_LiIon+1)+1,f
u4254:
	decfsz	(??_Route_LiIon+0)+0,f
	goto	u4255
	
	comf	(??_Route_LiIon+1)+0,f
	comf	(??_Route_LiIon+1)+1,f
	movf	0+(??_Route_LiIon+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Route_LiIon+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	294
	
l3429:	
;charge_mgr.c: 294: s_work.type = 1;
	clrf	0+(_s_work)^080h+01h
	incf	0+(_s_work)^080h+01h,f
	line	295
	
l3431:	
;charge_mgr.c: 295: s_work.chargeTimer = 0;
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	296
	
l3433:	
;charge_mgr.c: 296: return Route_DetectLi(idx, s_work.voltage);
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_DetectLi@slot_v+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_DetectLi@slot_v)
	movf	(Route_LiIon@idx),w
	fcall	_Route_DetectLi
	line	297
	
l550:	
	return
	opt stack 0
GLOBAL	__end_of_Route_LiIon
	__end_of_Route_LiIon:
	signat	_Route_LiIon,4217
	global	_Enter_DiodeTest

;; *************** function _Enter_DiodeTest *****************
;; Defined at:
;;		line 406 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    3[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	406
global __ptext9
__ptext9:	;psect for function _Enter_DiodeTest
psect	text9
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	406
	global	__size_of_Enter_DiodeTest
	__size_of_Enter_DiodeTest	equ	__end_of_Enter_DiodeTest-_Enter_DiodeTest
	
_Enter_DiodeTest:	
;incstack = 0
	opt	stack 3
; Regs used in _Enter_DiodeTest: [wreg+status,2+status,0]
;Enter_DiodeTest@idx stored from wreg
	movwf	(Enter_DiodeTest@idx)
	line	408
	
l3515:	
;charge_mgr.c: 408: s_work.state = 9;
	movlw	low(09h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	409
	
l3517:	
;charge_mgr.c: 409: s_work.chargeTimer = 0;
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	410
	
l3519:	
;charge_mgr.c: 411: g_diodeTraceSlot = (unsigned char)idx;
	clrf	(_g_diodeTraceCnt)^080h
	line	412
	
l3521:	
;charge_mgr.c: 412: g_highVFlag &= ~((unsigned int)1 << idx);
	bcf	status, 5	;RP0=0, select bank0
	incf	(Enter_DiodeTest@idx),w
	movwf	(??_Enter_DiodeTest+0)+0
	movlw	01h
	movwf	(??_Enter_DiodeTest+1)+0
	movlw	0
	movwf	(??_Enter_DiodeTest+1)+0+1
	goto	u4394
u4395:
	clrc
	rlf	(??_Enter_DiodeTest+1)+0,f
	rlf	(??_Enter_DiodeTest+1)+1,f
u4394:
	decfsz	(??_Enter_DiodeTest+0)+0,f
	goto	u4395
	
	comf	(??_Enter_DiodeTest+1)+0,f
	comf	(??_Enter_DiodeTest+1)+1,f
	movf	0+(??_Enter_DiodeTest+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Enter_DiodeTest+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_highVFlag+1)^080h,f
	line	413
	
l573:	
	return
	opt stack 0
GLOBAL	__end_of_Enter_DiodeTest
	__end_of_Enter_DiodeTest:
	signat	_Enter_DiodeTest,4217
	global	_Detect_Classify

;; *************** function _Detect_Classify *****************
;; Defined at:
;;		line 342 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  fromHighV       1   43[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1   47[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       1       0       0       0
;;      Temps:          0       3       0       0       0
;;      Totals:         0       5       0       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_Get_Vcc
;;		_Route_DetectLi
;;		___lwdiv
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=0
	line	342
global __ptext10
__ptext10:	;psect for function _Detect_Classify
psect	text10
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	342
	global	__size_of_Detect_Classify
	__size_of_Detect_Classify	equ	__end_of_Detect_Classify-_Detect_Classify
	
_Detect_Classify:	
;incstack = 0
	opt	stack 1
; Regs used in _Detect_Classify: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Detect_Classify@idx stored from wreg
	movwf	(Detect_Classify@idx)
	line	344
	
l3455:	
;charge_mgr.c: 344: if(fromHighV)
	movf	((Detect_Classify@fromHighV)),w
	btfsc	status,2
	goto	u4281
	goto	u4280
u4281:
	goto	l3463
u4280:
	line	352
	
l3457:	
;charge_mgr.c: 345: {
;charge_mgr.c: 352: g_capFlag &= ~((unsigned int)1 << idx);
	incf	(Detect_Classify@idx),w
	movwf	(??_Detect_Classify+0)+0
	movlw	01h
	movwf	(??_Detect_Classify+1)+0
	movlw	0
	movwf	(??_Detect_Classify+1)+0+1
	goto	u4294
u4295:
	clrc
	rlf	(??_Detect_Classify+1)+0,f
	rlf	(??_Detect_Classify+1)+1,f
u4294:
	decfsz	(??_Detect_Classify+0)+0,f
	goto	u4295
	
	comf	(??_Detect_Classify+1)+0,f
	comf	(??_Detect_Classify+1)+1,f
	movf	0+(??_Detect_Classify+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_Detect_Classify+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(_g_capFlag+1)^080h,f
	line	353
	
l3459:	
;charge_mgr.c: 353: g_stableCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Detect_Classify@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	354
	
l3461:	
;charge_mgr.c: 354: s_work.type = 5;
	movlw	low(05h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_s_work)^080h+01h
	line	356
	
l3463:	
;charge_mgr.c: 355: }
;charge_mgr.c: 356: if(s_work.type == 5)
		movlw	5
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u4301
	goto	u4300
u4301:
	goto	l3485
u4300:
	line	360
	
l3465:	
;charge_mgr.c: 357: {
;charge_mgr.c: 360: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	361
;charge_mgr.c: 361: if(g_detectLowCnt[idx] < 2)
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u4311
	goto	u4310
u4311:
	goto	l3469
u4310:
	goto	l560
	line	365
	
l3469:	
;charge_mgr.c: 365: g_detectOwner = idx;
	movf	(Detect_Classify@idx),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_g_detectOwner)^080h
	line	366
	
l3471:	
;charge_mgr.c: 366: Get_Vcc();
	fcall	_Get_Vcc
	line	368
	
l3473:	
;charge_mgr.c: 368: g_impData = ((((s_work.voltage) > 0x0FFFU) ? 0x0FFFU : (s_work.voltage)) | ((unsigned int)((((g_vcc_mv) + 50U) / 100U) - 38U) << 12));
	movlw	064h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(_g_vcc_mv),w
	addlw	low(032h)
	movwf	(___lwdiv@dividend)
	movf	(_g_vcc_mv+1),w
	skipnc
	addlw	1
	addlw	high(032h)
	movwf	1+(___lwdiv@dividend)
	fcall	___lwdiv
	movf	(1+(?___lwdiv)),w
	movwf	(_g_impData+1)
	movf	(0+(?___lwdiv)),w
	movwf	(_g_impData)
	movlw	0Ch
	
u4325:
	clrc
	rlf	(_g_impData),f
	rlf	(_g_impData+1),f
	addlw	-1
	skipz
	goto	u4325
	movlw	(0A000h >> 8)
	addwf	(_g_impData+1),f
	movlw	010h
	bsf	status, 5	;RP0=1, select bank1
	subwf	1+(_s_work)^080h+02h,w
	movlw	0
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipnc
	goto	u4331
	goto	u4330
u4331:
	goto	l3477
u4330:
	
l3475:	
	movf	0+(_s_work)^080h+02h,w
	iorwf	(_g_impData),f
	movf	1+(_s_work)^080h+02h,w
	iorwf	(_g_impData+1),f
	goto	l564
	
l3477:	
	movlw	0FFh
	iorwf	(_g_impData),f
	movlw	0Fh
	iorwf	(_g_impData+1),f
	
l564:	
	line	369
;charge_mgr.c: 369: s_work.state = 8;
	movlw	low(08h)
	movwf	(_s_work)^080h
	line	370
	
l3479:	
;charge_mgr.c: 370: s_work.chargeTimer = 0;
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	line	371
	
l3481:	
;charge_mgr.c: 371: g_detectLowCnt[idx] = 0;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	goto	l560
	line	374
	
l3485:	
;charge_mgr.c: 373: }
;charge_mgr.c: 374: if(s_work.type == 1 || s_work.type == 6)
		decf	(0+(_s_work)^080h+01h),w
	btfsc	status,2
	goto	u4341
	goto	u4340
u4341:
	goto	l3489
u4340:
	
l3487:	
		movlw	6
	xorwf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u4351
	goto	u4350
u4351:
	goto	l3499
u4350:
	line	377
	
l3489:	
;charge_mgr.c: 375: {
;charge_mgr.c: 377: g_detectLowCnt[idx]++;
	bcf	status, 5	;RP0=0, select bank0
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	incf	indf,f
	line	378
;charge_mgr.c: 378: if(g_detectLowCnt[idx] < 2)
	movf	(Detect_Classify@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	subwf	indf,w
	skipnc
	goto	u4361
	goto	u4360
u4361:
	goto	l3493
u4360:
	goto	l560
	line	380
	
l3493:	
;charge_mgr.c: 380: s_work.state = Route_DetectLi(idx, s_work.voltage);
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_DetectLi@slot_v+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_s_work)^080h+02h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Route_DetectLi@slot_v)
	movf	(Detect_Classify@idx),w
	fcall	_Route_DetectLi
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_s_work)^080h
	line	381
	
l3495:	
;charge_mgr.c: 381: s_work.chargeTimer = 0;
	clrf	0+(_s_work)^080h+04h
	clrf	1+(_s_work)^080h+04h
	goto	l560
	line	384
	
l3499:	
;charge_mgr.c: 383: }
;charge_mgr.c: 384: if(s_work.type == 0)
	movf	(0+(_s_work)^080h+01h),w
	btfss	status,2
	goto	u4371
	goto	u4370
u4371:
	goto	l3505
u4370:
	line	387
	
l3501:	
;charge_mgr.c: 385: {
;charge_mgr.c: 387: if(s_work.voltage >= 3990)
	movlw	0Fh
	subwf	1+(_s_work)^080h+02h,w
	movlw	096h
	skipnz
	subwf	0+(_s_work)^080h+02h,w
	skipc
	goto	u4381
	goto	u4380
u4381:
	goto	l3505
u4380:
	goto	l560
	line	389
	
l3505:	
;charge_mgr.c: 389: s_work.state = 7;
	movlw	low(07h)
	movwf	(_s_work)^080h
	goto	l3481
	line	396
	
l560:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_Classify
	__end_of_Detect_Classify:
	signat	_Detect_Classify,8313
	global	_Route_DetectLi

;; *************** function _Route_DetectLi *****************
;; Defined at:
;;		line 218 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;;  slot_v          2   25[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  idx             1   42[BANK0 ] unsigned char 
;;  bat_mv_long     4   37[BANK0 ] unsigned long 
;;  vx_mv           4   33[BANK0 ] unsigned long 
;;  bat_mv          2   31[BANK0 ] unsigned int 
;;  st              1   41[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0      12       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      18       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_Route_LiIon
;;		_Route_LinearLi
;;		_Detect_Classify
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=0
	line	218
global __ptext11
__ptext11:	;psect for function _Route_DetectLi
psect	text11
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	218
	global	__size_of_Route_DetectLi
	__size_of_Route_DetectLi	equ	__end_of_Route_DetectLi-_Route_DetectLi
	
_Route_DetectLi:	
;incstack = 0
	opt	stack 1
; Regs used in _Route_DetectLi: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;Route_DetectLi@idx stored from wreg
	movwf	(Route_DetectLi@idx)
	line	231
	
l3289:	
;charge_mgr.c: 226: unsigned long vx_mv;
;charge_mgr.c: 227: unsigned long bat_mv_long;
;charge_mgr.c: 228: unsigned int bat_mv;
;charge_mgr.c: 229: unsigned char st;
;charge_mgr.c: 231: vx_mv = (unsigned long)slot_v * 5000UL / 4096UL;
	movf	(Route_DetectLi@slot_v),w
	movwf	(___lmul@multiplier)
	movf	(Route_DetectLi@slot_v+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	013h
	movwf	(___lmul@multiplicand+1)
	movlw	088h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv+3)
	movf	(2+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv+2)
	movf	(1+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv+1)
	movf	(0+(?___lmul)),w
	movwf	(Route_DetectLi@vx_mv)

	
l3291:	
	movlw	0Ch
u4085:
	clrc
	rrf	(Route_DetectLi@vx_mv+3),f
	rrf	(Route_DetectLi@vx_mv+2),f
	rrf	(Route_DetectLi@vx_mv+1),f
	rrf	(Route_DetectLi@vx_mv),f
	addlw	-1
	skipz
	goto	u4085

	line	232
	
l3293:	
;charge_mgr.c: 232: bat_mv_long = 124UL * vx_mv + 206UL * 5000UL;
	movf	(Route_DetectLi@vx_mv+3),w
	movwf	(___lmul@multiplier+3)
	movf	(Route_DetectLi@vx_mv+2),w
	movwf	(___lmul@multiplier+2)
	movf	(Route_DetectLi@vx_mv+1),w
	movwf	(___lmul@multiplier+1)
	movf	(Route_DetectLi@vx_mv),w
	movwf	(___lmul@multiplier)

	movlw	07Ch
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long+3)
	movf	(2+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long+2)
	movf	(1+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long+1)
	movf	(0+(?___lmul)),w
	movwf	(Route_DetectLi@bat_mv_long)

	
l3295:	
	movlw	070h
	addwf	(Route_DetectLi@bat_mv_long),f
	movlw	0B7h
	skipnc
movlw 184
	addwf	(Route_DetectLi@bat_mv_long+1),f
	movlw	0Fh
	skipnc
movlw 16
	addwf	(Route_DetectLi@bat_mv_long+2),f
	movlw	0
	skipnc
movlw 1
	addwf	(Route_DetectLi@bat_mv_long+3),f
	line	233
	
l3297:	
;charge_mgr.c: 233: bat_mv = (unsigned int)((bat_mv_long + 1000UL/2UL) / 1000UL);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	03h
	movwf	(___lldiv@divisor+1)
	movlw	0E8h
	movwf	(___lldiv@divisor)

	movlw	0F4h
	movwf	((??_Route_DetectLi+0)+0)
	movlw	01h
	movwf	((??_Route_DetectLi+0)+0+1)
	movlw	0
	movwf	((??_Route_DetectLi+0)+0+2)
	movlw	0
	movwf	((??_Route_DetectLi+0)+0+3)
	movf	(Route_DetectLi@bat_mv_long),w
	addwf	(??_Route_DetectLi+0)+0,f
	movf	(Route_DetectLi@bat_mv_long+1),w
	skipnc
	incfsz	(Route_DetectLi@bat_mv_long+1),w
	goto	u4090
	goto	u4091
u4090:
	addwf	(??_Route_DetectLi+0)+1,f
u4091:
	movf	(Route_DetectLi@bat_mv_long+2),w
	skipnc
	incfsz	(Route_DetectLi@bat_mv_long+2),w
	goto	u4092
	goto	u4093
u4092:
	addwf	(??_Route_DetectLi+0)+2,f
u4093:
	movf	(Route_DetectLi@bat_mv_long+3),w
	skipnc
	incf	(Route_DetectLi@bat_mv_long+3),w
	addwf	(??_Route_DetectLi+0)+3,f
	movf	3+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend+3)
	movf	2+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend+2)
	movf	1+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend+1)
	movf	0+(??_Route_DetectLi+0)+0,w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Route_DetectLi@bat_mv+1)
	movf	(0+(?___lldiv)),w
	movwf	(Route_DetectLi@bat_mv)
	line	236
	
l3299:	
;charge_mgr.c: 236: if(slot_v >= 3235 || bat_mv > 60000U)
	movlw	0Ch
	subwf	(Route_DetectLi@slot_v+1),w
	movlw	0A3h
	skipnz
	subwf	(Route_DetectLi@slot_v),w
	skipnc
	goto	u4101
	goto	u4100
u4101:
	goto	l3303
u4100:
	
l3301:	
	movlw	0EAh
	subwf	(Route_DetectLi@bat_mv+1),w
	movlw	061h
	skipnz
	subwf	(Route_DetectLi@bat_mv),w
	skipc
	goto	u4111
	goto	u4110
u4111:
	goto	l3315
u4110:
	line	238
	
l3303:	
;charge_mgr.c: 237: {
;charge_mgr.c: 238: if((g_ccBlocks[idx]) >= 2)
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u4121
	goto	u4120
u4121:
	goto	l3307
u4120:
	line	240
	
l3305:	
;charge_mgr.c: 239: {
;charge_mgr.c: 240: st = 7;
	movlw	low(07h)
	movwf	(Route_DetectLi@st)
	line	241
;charge_mgr.c: 241: }
	goto	l3323
	line	244
	
l3307:	
;charge_mgr.c: 242: else
;charge_mgr.c: 243: {
;charge_mgr.c: 244: st = 5;
	movlw	low(05h)
	movwf	(Route_DetectLi@st)
	line	245
	
l3309:	
;charge_mgr.c: 245: g_slotRefV[idx] = slot_v;
	clrc
	rlf	(Route_DetectLi@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Route_DetectLi@slot_v),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	(Route_DetectLi@slot_v+1),w
	movwf	indf
	line	246
	
l3311:	
;charge_mgr.c: 246: g_ccBlocks[idx] = 0;
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	line	247
	
l3313:	
;charge_mgr.c: 247: g_stableCnt[idx] = 0;
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_stableCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l3323
	line	252
	
l3315:	
;charge_mgr.c: 250: else
;charge_mgr.c: 251: {
;charge_mgr.c: 252: st = 4;
	movlw	low(04h)
	movwf	(Route_DetectLi@st)
	line	253
	
l3317:	
;charge_mgr.c: 253: (g_ccBlocks[idx] &= 0x80);
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ccBlocks|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(080h)
	bsf	status, 7	;select IRP bank3
	andwf	indf,f
	line	255
	
l3319:	
;charge_mgr.c: 255: g_slotRefV[idx] = slot_v;
	clrc
	rlf	(Route_DetectLi@idx),w
	addlw	low(_g_slotRefV|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(Route_DetectLi@slot_v),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	incf	fsr0,f
	movf	(Route_DetectLi@slot_v+1),w
	movwf	indf
	goto	l3313
	line	258
	
l3323:	
;charge_mgr.c: 257: }
;charge_mgr.c: 258: g_ovCnt[idx] = 0;
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_ovCnt|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	259
	
l3325:	
;charge_mgr.c: 259: g_detectLowCnt[idx] = 0;
	movf	(Route_DetectLi@idx),w
	addlw	low(_g_detectLowCnt|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	clrf	indf
	line	260
	
l3327:	
;charge_mgr.c: 260: return st;
	movf	(Route_DetectLi@st),w
	line	261
	
l547:	
	return
	opt stack 0
GLOBAL	__end_of_Route_DetectLi
	__end_of_Route_DetectLi:
	signat	_Route_DetectLi,8313
	global	_Get_Vcc

;; *************** function _Get_Vcc *****************
;; Defined at:
;;		line 81 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  pt              4   25[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  2   48[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;; This function is called by:
;;		_main
;;		_Detect_Classify
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=0
	line	81
global __ptext12
__ptext12:	;psect for function _Get_Vcc
psect	text12
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	81
	global	__size_of_Get_Vcc
	__size_of_Get_Vcc	equ	__end_of_Get_Vcc-_Get_Vcc
	
_Get_Vcc:	
;incstack = 0
	opt	stack 2
; Regs used in _Get_Vcc: [wreg+status,2+status,0+pclath+cstack]
	line	83
	
l3281:	
;charge_mgr.c: 83: if(0xA5 == ADC_Sample(31, 0))
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(01Fh)
	fcall	_ADC_Sample
	xorlw	0A5h
	skipz
	goto	u4071
	goto	u4070
u4071:
	goto	l508
u4070:
	line	85
	
l3283:	
;charge_mgr.c: 84: {
;charge_mgr.c: 85: unsigned long pt = (4096UL * 1200UL) / adresult;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	((___lldiv@divisor))+1
	clrf	2+((___lldiv@divisor))
	clrf	3+((___lldiv@divisor))
	movlw	0
	movwf	(___lldiv@dividend+3)
	movlw	04Bh
	movwf	(___lldiv@dividend+2)
	movlw	0
	movwf	(___lldiv@dividend+1)
	movlw	0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Get_Vcc@pt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Get_Vcc@pt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Get_Vcc@pt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Get_Vcc@pt)

	line	86
	
l3285:	
;charge_mgr.c: 86: g_vcc_mv = (unsigned int)pt;
	movf	(Get_Vcc@pt+1),w
	movwf	(_g_vcc_mv+1)
	movf	(Get_Vcc@pt),w
	movwf	(_g_vcc_mv)
	line	89
	
l508:	
	return
	opt stack 0
GLOBAL	__end_of_Get_Vcc
	__end_of_Get_Vcc:
	signat	_Get_Vcc,90
	global	_Detect_BatteryType

;; *************** function _Detect_BatteryType *****************
;; Defined at:
;;		line 142 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  voltage         2    0[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       2       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=0
	line	142
global __ptext13
__ptext13:	;psect for function _Detect_BatteryType
psect	text13
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	142
	global	__size_of_Detect_BatteryType
	__size_of_Detect_BatteryType	equ	__end_of_Detect_BatteryType-_Detect_BatteryType
	
_Detect_BatteryType:	
;incstack = 0
	opt	stack 3
; Regs used in _Detect_BatteryType: [wreg]
	line	144
	
l3393:	
;charge_mgr.c: 144: if(voltage >= 3990)
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u4191
	goto	u4190
u4191:
	goto	l3399
u4190:
	line	145
	
l3395:	
;charge_mgr.c: 145: return 0;
	movlw	low(0)
	goto	l531
	line	146
	
l3399:	
;charge_mgr.c: 146: if(voltage < 500)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u4201
	goto	u4200
u4201:
	goto	l3405
u4200:
	goto	l3395
	line	161
	
l3405:	
;charge_mgr.c: 161: if(voltage >= 1015 && voltage < 3990)
	movlw	03h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F7h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u4211
	goto	u4210
u4211:
	goto	l3413
u4210:
	
l3407:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u4221
	goto	u4220
u4221:
	goto	l3413
u4220:
	line	162
	
l3409:	
;charge_mgr.c: 162: return 5;
	movlw	low(05h)
	goto	l531
	line	167
	
l3413:	
;charge_mgr.c: 167: if(voltage >= 500 && voltage < 3990)
	movlw	01h
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	0F4h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipc
	goto	u4231
	goto	u4230
u4231:
	goto	l3395
u4230:
	
l3415:	
	movlw	0Fh
	subwf	(Detect_BatteryType@voltage+1),w
	movlw	096h
	skipnz
	subwf	(Detect_BatteryType@voltage),w
	skipnc
	goto	u4241
	goto	u4240
u4241:
	goto	l3395
u4240:
	line	168
	
l3417:	
;charge_mgr.c: 168: return 1;
	movlw	low(01h)
	line	171
	
l531:	
	return
	opt stack 0
GLOBAL	__end_of_Detect_BatteryType
	__end_of_Detect_BatteryType:
	signat	_Detect_BatteryType,4217
	global	_Adc_Norm

;; *************** function _Adc_Norm *****************
;; Defined at:
;;		line 98 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;  ch              1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  ch              1   28[BANK0 ] unsigned char 
;;  raw             2   29[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   25[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       3       0       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       6       0       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;; This function is called by:
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=0
	line	98
global __ptext14
__ptext14:	;psect for function _Adc_Norm
psect	text14
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	98
	global	__size_of_Adc_Norm
	__size_of_Adc_Norm	equ	__end_of_Adc_Norm-_Adc_Norm
	
_Adc_Norm:	
;incstack = 0
	opt	stack 2
; Regs used in _Adc_Norm: [wreg+status,2+status,0+pclath+cstack]
;Adc_Norm@ch stored from wreg
	movwf	(Adc_Norm@ch)
	line	101
	
l3375:	
;charge_mgr.c: 100: unsigned int raw;
;charge_mgr.c: 101: if(0xA5 != ADC_Sample(ch, 0))
	clrf	(ADC_Sample@adldo)
	movf	(Adc_Norm@ch),w
	fcall	_ADC_Sample
	xorlw	0A5h
	skipnz
	goto	u4171
	goto	u4170
u4171:
	goto	l3381
u4170:
	line	102
	
l3377:	
;charge_mgr.c: 102: return 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(?_Adc_Norm)
	clrf	(?_Adc_Norm+1)
	goto	l512
	line	103
	
l3381:	
;charge_mgr.c: 103: raw = adresult;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Adc_Norm@raw+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Adc_Norm@raw)
	line	104
	
l3383:	
;charge_mgr.c: 104: if(g_vcc_mv == 0)
	movf	((_g_vcc_mv)),w
iorwf	((_g_vcc_mv+1)),w
	btfss	status,2
	goto	u4181
	goto	u4180
u4181:
	goto	l3389
u4180:
	line	105
	
l3385:	
;charge_mgr.c: 105: return raw;
	movf	(Adc_Norm@raw+1),w
	movwf	(?_Adc_Norm+1)
	movf	(Adc_Norm@raw),w
	movwf	(?_Adc_Norm)
	goto	l512
	line	106
	
l3389:	
;charge_mgr.c: 106: return (unsigned int)(((unsigned long)raw * (unsigned long)g_vcc_mv) / 5000UL);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	013h
	movwf	(___lldiv@divisor+1)
	movlw	088h
	movwf	(___lldiv@divisor)

	movf	(Adc_Norm@raw),w
	movwf	(___lmul@multiplier)
	movf	(Adc_Norm@raw+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movf	(_g_vcc_mv),w
	movwf	(___lmul@multiplicand)
	movf	(_g_vcc_mv+1),w
	movwf	((___lmul@multiplicand))+1
	clrf	2+((___lmul@multiplicand))
	clrf	3+((___lmul@multiplicand))
	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(?_Adc_Norm+1)
	movf	(0+(?___lldiv)),w
	movwf	(?_Adc_Norm)
	line	107
	
l512:	
	return
	opt stack 0
GLOBAL	__end_of_Adc_Norm
	__end_of_Adc_Norm:
	signat	_Adc_Norm,4218
	global	_Sense_Pins_Restore

;; *************** function _Sense_Pins_Restore *****************
;; Defined at:
;;		line 545 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	545
global __ptext15
__ptext15:	;psect for function _Sense_Pins_Restore
psect	text15
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	545
	global	__size_of_Sense_Pins_Restore
	__size_of_Sense_Pins_Restore	equ	__end_of_Sense_Pins_Restore-_Sense_Pins_Restore
	
_Sense_Pins_Restore:	
;incstack = 0
	opt	stack 4
; Regs used in _Sense_Pins_Restore: [wreg+status,2+status,0]
	line	547
	
l3737:	
;main.c: 547: TRISA |= 0xF0;
	movlw	low(0F0h)
	iorwf	(133)^080h,f	;volatile
	line	548
;main.c: 548: TRISB |= 0x30;
	movlw	low(030h)
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(5),f	;volatile
	line	549
;main.c: 549: TRISD |= 0xF0;
	movlw	low(0F0h)
	bsf	status, 6	;RP1=1, select bank2
	iorwf	(276)^0100h,f	;volatile
	line	550
;main.c: 550: TRISC |= 0x07;
	movlw	low(07h)
	iorwf	(261)^0100h,f	;volatile
	line	551
	
l3739:	
;main.c: 551: ANSEL0 = 0xF0;
	movlw	low(0F0h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(147)^080h	;volatile
	line	552
	
l3741:	
;main.c: 552: ANSEL1 = 0x30;
	movlw	low(030h)
	movwf	(148)^080h	;volatile
	line	553
	
l3743:	
;main.c: 553: ANSEL2 = 0x07;
	movlw	low(07h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	(265)^0100h	;volatile
	line	554
	
l3745:	
;main.c: 554: ANSEL3 = 0x3C;
	movlw	low(03Ch)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(140)^080h	;volatile
	line	555
	
l410:	
	return
	opt stack 0
GLOBAL	__end_of_Sense_Pins_Restore
	__end_of_Sense_Pins_Restore:
	signat	_Sense_Pins_Restore,89
	global	_Sense_Pins_AsSink

;; *************** function _Sense_Pins_AsSink *****************
;; Defined at:
;;		line 533 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/900
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=0
	line	533
global __ptext16
__ptext16:	;psect for function _Sense_Pins_AsSink
psect	text16
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	533
	global	__size_of_Sense_Pins_AsSink
	__size_of_Sense_Pins_AsSink	equ	__end_of_Sense_Pins_AsSink-_Sense_Pins_AsSink
	
_Sense_Pins_AsSink:	
;incstack = 0
	opt	stack 4
; Regs used in _Sense_Pins_AsSink: [wreg+status,2+status,0]
	line	536
	
l3711:	
;main.c: 536: ANSEL0 &= 0x0F; TRISA &= 0x0F; RA4 = 0; RA5 = 0; RA6 = 0; RA7 = 0;
	movlw	low(0Fh)
	andwf	(147)^080h,f	;volatile
	movlw	low(0Fh)
	andwf	(133)^080h,f	;volatile
	
l3713:	
	bcf	(1076/8)^080h,(1076)&7	;volatile
	
l3715:	
	bcf	(1077/8)^080h,(1077)&7	;volatile
	
l3717:	
	bcf	(1078/8)^080h,(1078)&7	;volatile
	
l3719:	
	bcf	(1079/8)^080h,(1079)&7	;volatile
	line	538
;main.c: 538: ANSEL1 &= 0xCF; TRISB &= 0xCF; RB4 = 0; RB5 = 0;
	movlw	low(0CFh)
	andwf	(148)^080h,f	;volatile
	movlw	low(0CFh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(5),f	;volatile
	
l3721:	
	bcf	(52/8),(52)&7	;volatile
	
l3723:	
	bcf	(53/8),(53)&7	;volatile
	line	540
;main.c: 540: ANSEL3 &= 0xC3; TRISD &= 0xC3; RD2 = 0; RD3 = 0; RD4 = 0; RD5 = 0;
	movlw	low(0C3h)
	bsf	status, 5	;RP0=1, select bank1
	andwf	(140)^080h,f	;volatile
	movlw	low(0C3h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	andwf	(276)^0100h,f	;volatile
	
l3725:	
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	
l3727:	
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	
l3729:	
	bcf	(2108/8)^0100h,(2108)&7	;volatile
	
l3731:	
	bcf	(2109/8)^0100h,(2109)&7	;volatile
	line	542
;main.c: 542: ANSEL2 &= 0xFC; TRISC &= 0xFC; RC0 = 0; RC1 = 0;
	movlw	low(0FCh)
	andwf	(265)^0100h,f	;volatile
	movlw	low(0FCh)
	andwf	(261)^0100h,f	;volatile
	
l3733:	
	bcf	(2096/8)^0100h,(2096)&7	;volatile
	
l3735:	
	bcf	(2097/8)^0100h,(2097)&7	;volatile
	line	543
	
l407:	
	return
	opt stack 0
GLOBAL	__end_of_Sense_Pins_AsSink
	__end_of_Sense_Pins_AsSink:
	signat	_Sense_Pins_AsSink,89
	global	_Read_Temperature

;; *************** function _Read_Temperature *****************
;; Defined at:
;;		line 109 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  rt              4   29[BANK0 ] unsigned long 
;;  temp_x10        2   35[BANK0 ] unsigned int 
;;  ntcVal          2   33[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2   56[None  ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 100/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       8       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_ADC_Sample
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	109
global __ptext17
__ptext17:	;psect for function _Read_Temperature
psect	text17
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	109
	global	__size_of_Read_Temperature
	__size_of_Read_Temperature	equ	__end_of_Read_Temperature-_Read_Temperature
	
_Read_Temperature:	
;incstack = 0
	opt	stack 3
; Regs used in _Read_Temperature: [wreg+status,2+status,0+pclath+cstack]
	line	114
	
l4859:	
;charge_mgr.c: 111: unsigned int ntcVal;
;charge_mgr.c: 112: unsigned int temp_x10;
;charge_mgr.c: 114: test_adc = ADC_Sample(18, 0);
	bcf	status, 6	;RP1=0, select bank0
	clrf	(ADC_Sample@adldo)
	movlw	low(012h)
	fcall	_ADC_Sample
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_test_adc)^080h
	line	115
	
l4861:	
;charge_mgr.c: 115: if(0xA5 != test_adc)
		movlw	165
	xorwf	((_test_adc)^080h),w
	btfsc	status,2
	goto	u7381
	goto	u7380
u7381:
	goto	l4865
u7380:
	goto	l517
	line	118
	
l4865:	
;charge_mgr.c: 118: ntcVal = adresult;
	movf	(_adresult+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Read_Temperature@ntcVal+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_adresult)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(Read_Temperature@ntcVal)
	line	119
;charge_mgr.c: 119: if(ntcVal < 100 || ntcVal > 3996)
	movlw	0
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u7391
	goto	u7390
u7391:
	goto	l517
u7390:
	
l4867:	
	movlw	0Fh
	subwf	(Read_Temperature@ntcVal+1),w
	movlw	09Dh
	skipnz
	subwf	(Read_Temperature@ntcVal),w
	skipc
	goto	u7401
	goto	u7400
u7401:
	goto	l4869
u7400:
	goto	l517
	line	124
	
l4869:	
;charge_mgr.c: 122: {
;charge_mgr.c: 123: unsigned long rt;
;charge_mgr.c: 124: rt = (unsigned long)ntcVal * 10000UL / (4096UL - ntcVal);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	010h
	movwf	(___lldiv@divisor+1)
	movlw	0
	movwf	(___lldiv@divisor)

	movf	(Read_Temperature@ntcVal),w
	movwf	((??_Read_Temperature+0)+0)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((??_Read_Temperature+0)+0+1)
	clrf	((??_Read_Temperature+0)+0+2)
	clrf	((??_Read_Temperature+0)+0+3)
	movf	0+(??_Read_Temperature+0)+0,w
	subwf	(___lldiv@divisor),f
	movf	1+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	1+(??_Read_Temperature+0)+0,w
	goto	u7415
	goto	u7416
u7415:
	subwf	(___lldiv@divisor+1),f
u7416:
	movf	2+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	2+(??_Read_Temperature+0)+0,w
	goto	u7417
	goto	u7418
u7417:
	subwf	(___lldiv@divisor+2),f
u7418:
	movf	3+(??_Read_Temperature+0)+0,w
	skipc
	incfsz	3+(??_Read_Temperature+0)+0,w
	goto	u7419
	goto	u7410
u7419:
	subwf	(___lldiv@divisor+3),f
u7410:

	movf	(Read_Temperature@ntcVal),w
	movwf	(___lmul@multiplier)
	movf	(Read_Temperature@ntcVal+1),w
	movwf	((___lmul@multiplier))+1
	clrf	2+((___lmul@multiplier))
	clrf	3+((___lmul@multiplier))
	movlw	0
	movwf	(___lmul@multiplicand+3)
	movlw	0
	movwf	(___lmul@multiplicand+2)
	movlw	027h
	movwf	(___lmul@multiplicand+1)
	movlw	010h
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(Read_Temperature@rt+3)
	movf	(2+(?___lldiv)),w
	movwf	(Read_Temperature@rt+2)
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@rt+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@rt)

	line	125
	
l4871:	
;charge_mgr.c: 125: if(rt >= 10000UL)
		movf	(Read_Temperature@rt+3),w
	btfss	status,2
	goto	u7420
	movf	(Read_Temperature@rt+2),w
	btfss	status,2
	goto	u7420
	movlw	39
	subwf	(Read_Temperature@rt+1),w
	skipz
	goto	u7423
	movlw	16
	subwf	(Read_Temperature@rt),w
	skipz
	goto	u7423
u7423:
	btfss	status,0
	goto	u7421
	goto	u7420

u7421:
	goto	l4877
u7420:
	line	126
	
l4873:	
;charge_mgr.c: 126: temp_x10 = 250U - (unsigned int)((rt - 10000UL) * 10UL / 445UL);
	movlw	0FAh
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l4875:	
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0F0h
	movwf	((??_Read_Temperature+0)+0)
	movlw	0D8h
	movwf	((??_Read_Temperature+0)+0+1)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+2)
	movlw	0FFh
	movwf	((??_Read_Temperature+0)+0+3)
	movf	(Read_Temperature@rt),w
	addwf	(??_Read_Temperature+0)+0,f
	movf	(Read_Temperature@rt+1),w
	skipnc
	incfsz	(Read_Temperature@rt+1),w
	goto	u7430
	goto	u7431
u7430:
	addwf	(??_Read_Temperature+0)+1,f
u7431:
	movf	(Read_Temperature@rt+2),w
	skipnc
	incfsz	(Read_Temperature@rt+2),w
	goto	u7432
	goto	u7433
u7432:
	addwf	(??_Read_Temperature+0)+2,f
u7433:
	movf	(Read_Temperature@rt+3),w
	skipnc
	incf	(Read_Temperature@rt+3),w
	addwf	(??_Read_Temperature+0)+3,f
	movf	3+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+3)
	movf	2+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+2)
	movf	1+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier+1)
	movf	0+(??_Read_Temperature+0)+0,w
	movwf	(___lmul@multiplier)

	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(0+(?___lldiv)),w
	subwf	(Read_Temperature@temp_x10),f
	movf	(1+(?___lldiv)),w
	skipc
	decf	(Read_Temperature@temp_x10+1),f
	subwf	(Read_Temperature@temp_x10+1),f
	goto	l4881
	line	128
	
l4877:	
;charge_mgr.c: 127: else
;charge_mgr.c: 128: temp_x10 = 250U + (unsigned int)((10000UL - rt) * 10UL / 445UL);
	movlw	0
	movwf	(___lldiv@divisor+3)
	movlw	0
	movwf	(___lldiv@divisor+2)
	movlw	01h
	movwf	(___lldiv@divisor+1)
	movlw	0BDh
	movwf	(___lldiv@divisor)

	movlw	0
	movwf	(___lmul@multiplier+3)
	movlw	0
	movwf	(___lmul@multiplier+2)
	movlw	027h
	movwf	(___lmul@multiplier+1)
	movlw	010h
	movwf	(___lmul@multiplier)

	movf	(Read_Temperature@rt),w
	subwf	(___lmul@multiplier),f
	movf	(Read_Temperature@rt+1),w
	skipc
	incfsz	(Read_Temperature@rt+1),w
	subwf	(___lmul@multiplier+1),f
	movf	(Read_Temperature@rt+2),w
	skipc
	incfsz	(Read_Temperature@rt+2),w
	subwf	(___lmul@multiplier+2),f
	movf	(Read_Temperature@rt+3),w
	skipc
	incfsz	(Read_Temperature@rt+3),w
	subwf	(___lmul@multiplier+3),f
	movlw	0Ah
	movwf	(___lmul@multiplicand)
	clrf	(___lmul@multiplicand+1)
	clrf	(___lmul@multiplicand+2)
	clrf	(___lmul@multiplicand+3)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(___lldiv@dividend+3)
	movf	(2+(?___lmul)),w
	movwf	(___lldiv@dividend+2)
	movf	(1+(?___lmul)),w
	movwf	(___lldiv@dividend+1)
	movf	(0+(?___lmul)),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(1+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10+1)
	movf	(0+(?___lldiv)),w
	movwf	(Read_Temperature@temp_x10)
	
l4879:	
	movlw	0FAh
	addwf	(Read_Temperature@temp_x10),f
	skipnc
	incf	(Read_Temperature@temp_x10+1),f
	line	129
	
l4881:	
;charge_mgr.c: 129: if(temp_x10 < 100U) temp_x10 = 100U;
	movlw	0
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	064h
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipnc
	goto	u7441
	goto	u7440
u7441:
	goto	l523
u7440:
	
l4883:	
	movlw	064h
	movwf	(Read_Temperature@temp_x10)
	clrf	(Read_Temperature@temp_x10+1)
	
l523:	
	line	130
;charge_mgr.c: 130: if(temp_x10 > 750U) temp_x10 = 750U;
	movlw	02h
	subwf	(Read_Temperature@temp_x10+1),w
	movlw	0EFh
	skipnz
	subwf	(Read_Temperature@temp_x10),w
	skipc
	goto	u7451
	goto	u7450
u7451:
	goto	l4887
u7450:
	
l4885:	
	movlw	0EEh
	movwf	(Read_Temperature@temp_x10)
	movlw	02h
	movwf	((Read_Temperature@temp_x10))+1
	line	134
	
l4887:	
;charge_mgr.c: 134: if((temp_x10 / 10U) >= 60)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	03Ch
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipc
	goto	u7461
	goto	u7460
u7461:
	goto	l4891
u7460:
	line	135
	
l4889:	
;charge_mgr.c: 135: g_tempProtect = 1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	incf	(_g_tempProtect)^080h,f
	goto	l517
	line	136
	
l4891:	
;charge_mgr.c: 136: else if((temp_x10 / 10U) <= 50)
	movlw	0Ah
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(Read_Temperature@temp_x10+1),w
	movwf	(___lwdiv@dividend+1)
	movf	(Read_Temperature@temp_x10),w
	movwf	(___lwdiv@dividend)
	fcall	___lwdiv
	movlw	0
	subwf	(1+(?___lwdiv)),w
	movlw	033h
	skipnz
	subwf	(0+(?___lwdiv)),w
	skipnc
	goto	u7471
	goto	u7470
u7471:
	goto	l517
u7470:
	line	137
	
l4893:	
;charge_mgr.c: 137: g_tempProtect = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_tempProtect)^080h
	line	140
	
l517:	
	return
	opt stack 0
GLOBAL	__end_of_Read_Temperature
	__end_of_Read_Temperature:
	signat	_Read_Temperature,90
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK0 ] unsigned int 
;;  dividend        2    2[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    4[BANK0 ] unsigned int 
;;  counter         1    6[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       3       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       7       0       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Read_Temperature
;;		_Detect_Classify
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
global __ptext18
__ptext18:	;psect for function ___lwdiv
psect	text18
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 2
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l3331:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l3333:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u4131
	goto	u4130
u4131:
	goto	l3353
u4130:
	line	16
	
l3335:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l3339
	line	18
	
l3337:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l3339:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u4141
	goto	u4140
u4141:
	goto	l3337
u4140:
	line	22
	
l3341:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l3343:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u4155
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u4155:
	skipc
	goto	u4151
	goto	u4150
u4151:
	goto	l3349
u4150:
	line	24
	
l3345:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l3347:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l3349:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l3351:	
	decfsz	(___lwdiv@counter),f
	goto	u4161
	goto	u4160
u4161:
	goto	l3341
u4160:
	line	30
	
l3353:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l1292:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    0[BANK0 ] unsigned long 
;;  multiplicand    4    4[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    8[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    0[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      12       0       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Route_DetectLi
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
global __ptext19
__ptext19:	;psect for function ___lmul
psect	text19
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 1
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l3243:	
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l964:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u4001
	goto	u4000
u4001:
	goto	l3247
u4000:
	line	122
	
l3245:	
	movf	(___lmul@multiplicand),w
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u4011
	addwf	(___lmul@product+1),f
u4011:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u4012
	addwf	(___lmul@product+2),f
u4012:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u4013
	addwf	(___lmul@product+3),f
u4013:

	line	123
	
l3247:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l3249:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u4021
	goto	u4020
u4021:
	goto	l964
u4020:
	line	128
	
l3251:	
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l967:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4   12[BANK0 ] unsigned long 
;;  dividend        4   16[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4   20[BANK0 ] unsigned long 
;;  counter         1   24[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4   12[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       8       0       0       0
;;      Locals:         0       5       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0      13       0       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Get_Vcc
;;		_Adc_Norm
;;		_Read_Temperature
;;		_Route_DetectLi
;;		_Slot_Charge_Ctrl
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
global __ptext20
__ptext20:	;psect for function ___lldiv
psect	text20
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l3255:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l3257:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u4031
	goto	u4030
u4031:
	goto	l3277
u4030:
	line	16
	
l3259:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l3263
	line	18
	
l3261:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l3263:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u4041
	goto	u4040
u4041:
	goto	l3261
u4040:
	line	22
	
l3265:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l3267:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u4055
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u4055
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u4055
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u4055:
	skipc
	goto	u4051
	goto	u4050
u4051:
	goto	l3273
u4050:
	line	24
	
l3269:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l3271:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l3273:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l3275:	
	decfsz	(___lldiv@counter),f
	goto	u4061
	goto	u4060
u4061:
	goto	l3265
u4060:
	line	30
	
l3277:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l1239:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_ADC_Sample

;; *************** function _ADC_Sample *****************
;; Defined at:
;;		line 49 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
;; Parameters:    Size  Location     Type
;;  adch            1    wreg     unsigned char 
;;  adldo           1    0[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  adch            1    6[BANK0 ] unsigned char 
;;  j               1    5[BANK0 ] unsigned char 
;;  adsum           4    8[BANK0 ] volatile unsigned long 
;;  ad_temp         2   16[BANK0 ] volatile unsigned int 
;;  admax           2   14[BANK0 ] volatile unsigned int 
;;  admin           2   12[BANK0 ] volatile unsigned int 
;;  i               1    7[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0      13       0       0       0
;;      Temps:          0       4       0       0       0
;;      Totals:         0      18       0       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Get_Vcc
;;		_Adc_Norm
;;		_Read_Temperature
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
global __ptext21
__ptext21:	;psect for function _ADC_Sample
psect	text21
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\adc_drv.c"
	line	49
	global	__size_of_ADC_Sample
	__size_of_ADC_Sample	equ	__end_of_ADC_Sample-_ADC_Sample
	
_ADC_Sample:	
;incstack = 0
	opt	stack 2
; Regs used in _ADC_Sample: [wreg+status,2+status,0]
;ADC_Sample@adch stored from wreg
	movwf	(ADC_Sample@adch)
	line	51
	
l3177:	
;adc_drv.c: 51: volatile unsigned long adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	52
	
l3179:	
;adc_drv.c: 52: volatile unsigned int admin = 0;
	clrf	(ADC_Sample@admin)	;volatile
	clrf	(ADC_Sample@admin+1)	;volatile
	line	53
;adc_drv.c: 53: volatile unsigned int admax = 0;
	clrf	(ADC_Sample@admax)	;volatile
	clrf	(ADC_Sample@admax+1)	;volatile
	line	54
;adc_drv.c: 54: volatile unsigned int ad_temp = 0;
	clrf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	line	58
	
l3181:	
;adc_drv.c: 55: unsigned char i;
;adc_drv.c: 58: if((!LDO_EN) && (adldo & 0x04))
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1202/8)^080h,(1202)&7	;volatile
	goto	u3851
	goto	u3850
u3851:
	goto	l3187
u3850:
	
l3183:	
	bcf	status, 5	;RP0=0, select bank0
	btfss	(ADC_Sample@adldo),(2)&7
	goto	u3861
	goto	u3860
u3861:
	goto	l3187
u3860:
	line	60
	
l3185:	
;adc_drv.c: 59: {
;adc_drv.c: 60: ADCON1 = adldo;
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	61
;adc_drv.c: 61: _delay((unsigned long)((100)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	132
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u7737:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u7737
	nop
opt asmopt_pop

	line	62
;adc_drv.c: 62: }
	goto	l3189
	line	64
	
l3187:	
;adc_drv.c: 63: else
;adc_drv.c: 64: ADCON1 = adldo;
	bcf	status, 5	;RP0=0, select bank0
	movf	(ADC_Sample@adldo),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(150)^080h	;volatile
	line	67
	
l3189:	
;adc_drv.c: 67: if(adch & 0x10)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(ADC_Sample@adch),(4)&7
	goto	u3871
	goto	u3870
u3871:
	goto	l457
u3870:
	line	69
	
l3191:	
;adc_drv.c: 68: {
;adc_drv.c: 69: CHS4 = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1206/8)^080h,(1206)&7	;volatile
	line	70
	
l3193:	
;adc_drv.c: 70: adch &= 0x0f;
	movlw	low(0Fh)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(ADC_Sample@adch),f
	line	71
;adc_drv.c: 71: }
	goto	l3195
	line	72
	
l457:	
	line	73
;adc_drv.c: 72: else
;adc_drv.c: 73: CHS4 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1206/8)^080h,(1206)&7	;volatile
	line	76
	
l3195:	
;adc_drv.c: 76: for(i = 0; i < 34; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@i)
	line	79
	
l3201:	
;adc_drv.c: 77: {
;adc_drv.c: 79: ADCON0 = (unsigned char)(0x81U | ((unsigned int)(adch) << 2));
	movf	(ADC_Sample@adch),w
	movwf	(??_ADC_Sample+0)+0
	movlw	(02h)-1
u3885:
	clrc
	rlf	(??_ADC_Sample+0)+0,f
	addlw	-1
	skipz
	goto	u3885
	clrc
	rlf	(??_ADC_Sample+0)+0,w
	iorlw	081h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(149)^080h	;volatile
	line	80
	
l3203:	
;adc_drv.c: 80: _delay((unsigned long)((5)*(16000000/4000000.0)));
	opt asmopt_push
opt asmopt_off
	movlw	5
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
movwf	((??_ADC_Sample+0)+0),f
	u7747:
decfsz	(??_ADC_Sample+0)+0,f
	goto	u7747
	nop2
opt asmopt_pop

	line	81
	
l3205:	
;adc_drv.c: 81: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1193/8)^080h,(1193)&7	;volatile
	line	84
	
l3207:	
;adc_drv.c: 84: unsigned char j = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ADC_Sample@j)
	line	85
;adc_drv.c: 85: while(GODONE)
	goto	l461
	
l462:	
	line	87
;adc_drv.c: 86: {
;adc_drv.c: 87: _delay((unsigned long)((2)*(16000000/4000000.0)));
		opt asmopt_push
	opt asmopt_off
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	nop2	;2 cycle nop
	opt asmopt_pop

	line	88
;adc_drv.c: 88: if(0 == (--j))
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(ADC_Sample@j),f
	goto	u3891
	goto	u3890
u3891:
	goto	l461
u3890:
	line	89
	
l3209:	
;adc_drv.c: 89: return 0;
	movlw	low(0)
	goto	l464
	line	90
	
l461:	
	line	85
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1193/8)^080h,(1193)&7	;volatile
	goto	u3901
	goto	u3900
u3901:
	goto	l462
u3900:
	line	93
	
l3213:	
;adc_drv.c: 90: }
;adc_drv.c: 93: ad_temp = (unsigned int)((ADRESH << 4) + (ADRESL >> 4));
	movf	(153)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ADC_Sample@ad_temp)	;volatile
	clrf	(ADC_Sample@ad_temp+1)	;volatile
	swapf	(ADC_Sample@ad_temp),f	;volatile
	swapf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp+1),f	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	andlw	0fh
	iorwf	(ADC_Sample@ad_temp+1),f	;volatile
	movlw	0f0h
	andwf	(ADC_Sample@ad_temp),f	;volatile
	
l3215:	
	bsf	status, 5	;RP0=1, select bank1
	swapf	(152)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	addwf	(ADC_Sample@ad_temp),f	;volatile
	skipnc
	incf	(ADC_Sample@ad_temp+1),f	;volatile
	line	96
	
l3217:	
;adc_drv.c: 96: if(0 == admax)
	movf	((ADC_Sample@admax)),w	;volatile
iorwf	((ADC_Sample@admax+1)),w	;volatile
	btfss	status,2
	goto	u3911
	goto	u3910
u3911:
	goto	l3221
u3910:
	line	98
	
l3219:	
;adc_drv.c: 97: {
;adc_drv.c: 98: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	line	99
;adc_drv.c: 99: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	100
;adc_drv.c: 100: }
	goto	l467
	line	102
	
l3221:	
;adc_drv.c: 102: else if(ad_temp > admax)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	subwf	(ADC_Sample@admax+1),w	;volatile
	skipz
	goto	u3925
	movf	(ADC_Sample@ad_temp),w	;volatile
	subwf	(ADC_Sample@admax),w	;volatile
u3925:
	skipnc
	goto	u3921
	goto	u3920
u3921:
	goto	l3225
u3920:
	line	103
	
l3223:	
;adc_drv.c: 103: admax = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admax+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admax)	;volatile
	goto	l467
	line	105
	
l3225:	
;adc_drv.c: 105: else if(ad_temp < admin)
	movf	(ADC_Sample@admin+1),w	;volatile
	subwf	(ADC_Sample@ad_temp+1),w	;volatile
	skipz
	goto	u3935
	movf	(ADC_Sample@admin),w	;volatile
	subwf	(ADC_Sample@ad_temp),w	;volatile
u3935:
	skipnc
	goto	u3931
	goto	u3930
u3931:
	goto	l467
u3930:
	line	106
	
l3227:	
;adc_drv.c: 106: admin = ad_temp;
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	(ADC_Sample@admin+1)	;volatile
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	(ADC_Sample@admin)	;volatile
	line	108
	
l467:	
;adc_drv.c: 108: adsum += ad_temp;
	movf	(ADC_Sample@ad_temp),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@ad_temp+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	addwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3941
	addwf	(ADC_Sample@adsum+1),f	;volatile
u3941:
	movf	2+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3942
	addwf	(ADC_Sample@adsum+2),f	;volatile
u3942:
	movf	3+(??_ADC_Sample+0)+0,w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u3943
	addwf	(ADC_Sample@adsum+3),f	;volatile
u3943:

	line	76
	
l3229:	
	incf	(ADC_Sample@i),f
	
l3231:	
	movlw	low(022h)
	subwf	(ADC_Sample@i),w
	skipc
	goto	u3951
	goto	u3950
u3951:
	goto	l3201
u3950:
	line	112
	
l3233:	
;adc_drv.c: 109: }
;adc_drv.c: 112: adsum -= admax;
	movf	(ADC_Sample@admax),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admax+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u3965
	goto	u3966
u3965:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u3966:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u3967
	goto	u3968
u3967:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u3968:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u3969
	goto	u3960
u3969:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u3960:

	line	113
;adc_drv.c: 113: if(adsum >= admin)
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	3+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+3),w	;volatile
	skipz
	goto	u3975
	movf	2+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+2),w	;volatile
	skipz
	goto	u3975
	movf	1+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum+1),w	;volatile
	skipz
	goto	u3975
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),w	;volatile
u3975:
	skipc
	goto	u3971
	goto	u3970
u3971:
	goto	l471
u3970:
	line	114
	
l3235:	
;adc_drv.c: 114: adsum -= admin;
	movf	(ADC_Sample@admin),w	;volatile
	movwf	((??_ADC_Sample+0)+0)
	movf	(ADC_Sample@admin+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	clrf	((??_ADC_Sample+0)+0+2)
	clrf	((??_ADC_Sample+0)+0+3)
	movf	0+(??_ADC_Sample+0)+0,w
	subwf	(ADC_Sample@adsum),f	;volatile
	movf	1+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	1+(??_ADC_Sample+0)+0,w
	goto	u3985
	goto	u3986
u3985:
	subwf	(ADC_Sample@adsum+1),f	;volatile
u3986:
	movf	2+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	2+(??_ADC_Sample+0)+0,w
	goto	u3987
	goto	u3988
u3987:
	subwf	(ADC_Sample@adsum+2),f	;volatile
u3988:
	movf	3+(??_ADC_Sample+0)+0,w
	skipc
	incfsz	3+(??_ADC_Sample+0)+0,w
	goto	u3989
	goto	u3980
u3989:
	subwf	(ADC_Sample@adsum+3),f	;volatile
u3980:

	goto	l3237
	line	115
	
l471:	
	line	116
;adc_drv.c: 115: else
;adc_drv.c: 116: adsum = 0;
	clrf	(ADC_Sample@adsum)	;volatile
	clrf	(ADC_Sample@adsum+1)	;volatile
	clrf	(ADC_Sample@adsum+2)	;volatile
	clrf	(ADC_Sample@adsum+3)	;volatile
	line	118
	
l3237:	
;adc_drv.c: 118: adresult = adsum >> 5;
	movf	(ADC_Sample@adsum),w	;volatile
	movwf	(??_ADC_Sample+0)+0
	movf	(ADC_Sample@adsum+1),w	;volatile
	movwf	((??_ADC_Sample+0)+0+1)
	movf	(ADC_Sample@adsum+2),w	;volatile
	movwf	((??_ADC_Sample+0)+0+2)
	movf	(ADC_Sample@adsum+3),w	;volatile
	movwf	((??_ADC_Sample+0)+0+3)
	movlw	05h
u3995:
	clrc
	rrf	(??_ADC_Sample+0)+3,f
	rrf	(??_ADC_Sample+0)+2,f
	rrf	(??_ADC_Sample+0)+1,f
	rrf	(??_ADC_Sample+0)+0,f
u3990:
	addlw	-1
	skipz
	goto	u3995
	movf	1+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_adresult+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_ADC_Sample+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_adresult)^080h
	line	119
	
l3239:	
;adc_drv.c: 119: return 0xA5;
	movlw	low(0A5h)
	line	120
	
l464:	
	return
	opt stack 0
GLOBAL	__end_of_ADC_Sample
	__end_of_ADC_Sample:
	signat	_ADC_Sample,8313
	global	_Display_Service

;; *************** function _Display_Service *****************
;; Defined at:
;;		line 577 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 800/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	577
global __ptext22
__ptext22:	;psect for function _Display_Service
psect	text22
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	577
	global	__size_of_Display_Service
	__size_of_Display_Service	equ	__end_of_Display_Service-_Display_Service
	
_Display_Service:	
;incstack = 0
	opt	stack 4
; Regs used in _Display_Service: [wreg+status,2+status,0]
	line	581
	
l3753:	
;main.c: 581: g_adcBusy = 0;
	bcf	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	line	582
	
l3755:	
;main.c: 582: if(g_sinkMask == 0U)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	((_g_sinkMask)^080h),w	;volatile
iorwf	((_g_sinkMask+1)^080h),w	;volatile
	btfss	status,2
	goto	u4611
	goto	u4610
u4611:
	goto	l422
u4610:
	goto	l421
	line	584
	
l423:	
	line	585
# 585 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text22
	
l422:	
	line	584
	btfss	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	goto	u4621
	goto	u4620
u4621:
	goto	l423
u4620:
	goto	l425
	line	586
	
l426:	
	line	587
# 587 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text22
	
l425:	
	line	586
	btfsc	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	goto	u4631
	goto	u4630
u4631:
	goto	l426
u4630:
	line	588
	
l421:	
	return
	opt stack 0
GLOBAL	__end_of_Display_Service
	__end_of_Display_Service:
	signat	_Display_Service,89
	global	_CCCV_Control

;; *************** function _CCCV_Control *****************
;; Defined at:
;;		line 1500 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  vt              2   16[BANK0 ] unsigned int 
;;  s               1   27[BANK0 ] unsigned char 
;;  duty            2   24[BANK0 ] int 
;;  error           2   20[BANK0 ] int 
;;  adjust          2   10[BANK0 ] int 
;;  duty_initial    1   23[BANK0 ] unsigned char 
;;  duty_target     1   22[BANK0 ] unsigned char 
;;  maxV            2   18[BANK0 ] unsigned int 
;;  i               1   26[BANK0 ] unsigned char 
;;  preCount        1   15[BANK0 ] unsigned char 
;;  ccCount         1   14[BANK0 ] unsigned char 
;;  cvCount         1   13[BANK0 ] unsigned char 
;;  hasCharging     1   12[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0      18       0       0       0
;;      Temps:          0       2       0       0       0
;;      Totals:         0      20       0       0       0
;;Total ram usage:       20 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___awdiv
;;		___bmul
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1500
global __ptext23
__ptext23:	;psect for function _CCCV_Control
psect	text23
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\charge_mgr.c"
	line	1500
	global	__size_of_CCCV_Control
	__size_of_CCCV_Control	equ	__end_of_CCCV_Control-_CCCV_Control
	
_CCCV_Control:	
;incstack = 0
	opt	stack 3
; Regs used in _CCCV_Control: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1503
	
l4597:	
;charge_mgr.c: 1502: unsigned char i;
;charge_mgr.c: 1503: unsigned char hasCharging = 0;
	clrf	(CCCV_Control@hasCharging)
	line	1504
;charge_mgr.c: 1504: unsigned int maxV = 0;
	clrf	(CCCV_Control@maxV)
	clrf	(CCCV_Control@maxV+1)
	line	1505
;charge_mgr.c: 1505: unsigned char cvCount = 0;
	clrf	(CCCV_Control@cvCount)
	line	1506
;charge_mgr.c: 1506: unsigned char ccCount = 0;
	clrf	(CCCV_Control@ccCount)
	line	1507
;charge_mgr.c: 1507: unsigned char preCount = 0;
	clrf	(CCCV_Control@preCount)
	line	1510
	
l4599:	
;charge_mgr.c: 1510: if(g_vccProtect)
	bsf	status, 5	;RP0=1, select bank1
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u6821
	goto	u6820
u6821:
	goto	l4605
u6820:
	line	1512
	
l4601:	
;charge_mgr.c: 1511: {
;charge_mgr.c: 1512: if(g_vcc_mv >= 4600)
	movlw	011h
	subwf	(_g_vcc_mv+1),w
	movlw	0F8h
	skipnz
	subwf	(_g_vcc_mv),w
	skipc
	goto	u6831
	goto	u6830
u6831:
	goto	l4609
u6830:
	line	1513
	
l4603:	
;charge_mgr.c: 1513: g_vccProtect = 0;
	clrf	(_g_vccProtect)^080h
	goto	l4609
	line	1517
	
l4605:	
;charge_mgr.c: 1515: else
;charge_mgr.c: 1516: {
;charge_mgr.c: 1517: if(g_vcc_mv < 4400)
	movlw	011h
	subwf	(_g_vcc_mv+1),w
	movlw	030h
	skipnz
	subwf	(_g_vcc_mv),w
	skipnc
	goto	u6841
	goto	u6840
u6841:
	goto	l4609
u6840:
	line	1518
	
l4607:	
;charge_mgr.c: 1518: g_vccProtect = 1;
	clrf	(_g_vccProtect)^080h
	incf	(_g_vccProtect)^080h,f
	line	1522
	
l4609:	
;charge_mgr.c: 1519: }
;charge_mgr.c: 1522: if(g_tempProtect || g_vccProtect)
	movf	((_g_tempProtect)^080h),w
	btfss	status,2
	goto	u6851
	goto	u6850
u6851:
	goto	l4613
u6850:
	
l4611:	
	movf	((_g_vccProtect)^080h),w
	btfsc	status,2
	goto	u6861
	goto	u6860
u6861:
	goto	l4617
u6860:
	line	1524
	
l4613:	
;charge_mgr.c: 1523: {
;charge_mgr.c: 1524: g_pwmDuty = 0;
	clrf	(_g_pwmDuty)	;volatile
	line	1525
;charge_mgr.c: 1525: g_cvIntegral = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	l870
	line	1530
	
l4617:	
;charge_mgr.c: 1527: }
;charge_mgr.c: 1530: for(i = 0; i < 12; i++)
	bcf	status, 5	;RP0=0, select bank0
	clrf	(CCCV_Control@i)
	line	1532
	
l4623:	
;charge_mgr.c: 1531: {
;charge_mgr.c: 1532: unsigned char s = g_slot[(unsigned char)(i)].state;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(CCCV_Control@s)
	line	1536
	
l4625:	
;charge_mgr.c: 1534: if(s == 2 || s == 3 ||
;charge_mgr.c: 1535: s == 4 || s == 5 ||
;charge_mgr.c: 1536: s == 8)
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u6871
	goto	u6870
u6871:
	goto	l875
u6870:
	
l4627:	
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u6881
	goto	u6880
u6881:
	goto	l875
u6880:
	
l4629:	
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u6891
	goto	u6890
u6891:
	goto	l875
u6890:
	
l4631:	
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u6901
	goto	u6900
u6901:
	goto	l875
u6900:
	
l4633:	
		movlw	8
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u6911
	goto	u6910
u6911:
	goto	l873
u6910:
	
l875:	
	line	1538
;charge_mgr.c: 1537: {
;charge_mgr.c: 1538: hasCharging = 1;
	clrf	(CCCV_Control@hasCharging)
	incf	(CCCV_Control@hasCharging),f
	line	1540
	
l4635:	
;charge_mgr.c: 1539: {
;charge_mgr.c: 1540: unsigned int vt = g_slot[(unsigned char)(i)].voltage;
	movlw	low(06h)
	movwf	(___bmul@multiplicand)
	movf	(CCCV_Control@i),w
	fcall	___bmul
	addlw	low(_g_slot|((0x1)<<8)+02h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(CCCV_Control@vt)
	incf	fsr0,f
	movf	indf,w
	movwf	(CCCV_Control@vt+1)
	line	1541
	
l4637:	
;charge_mgr.c: 1541: if(vt > maxV) maxV = vt;
	movf	(CCCV_Control@vt+1),w
	subwf	(CCCV_Control@maxV+1),w
	skipz
	goto	u6925
	movf	(CCCV_Control@vt),w
	subwf	(CCCV_Control@maxV),w
u6925:
	skipnc
	goto	u6921
	goto	u6920
u6921:
	goto	l4641
u6920:
	
l4639:	
	movf	(CCCV_Control@vt+1),w
	movwf	(CCCV_Control@maxV+1)
	movf	(CCCV_Control@vt),w
	movwf	(CCCV_Control@maxV)
	line	1543
	
l4641:	
;charge_mgr.c: 1542: }
;charge_mgr.c: 1543: if(s == 5)
		movlw	5
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u6931
	goto	u6930
u6931:
	goto	l4645
u6930:
	line	1544
	
l4643:	
;charge_mgr.c: 1544: cvCount++;
	incf	(CCCV_Control@cvCount),f
	line	1545
	
l4645:	
;charge_mgr.c: 1545: if(s == 4)
		movlw	4
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u6941
	goto	u6940
u6941:
	goto	l4649
u6940:
	line	1546
	
l4647:	
;charge_mgr.c: 1546: ccCount++;
	incf	(CCCV_Control@ccCount),f
	line	1547
	
l4649:	
;charge_mgr.c: 1547: if(s == 3 || s == 2)
		movlw	3
	xorwf	((CCCV_Control@s)),w
	btfsc	status,2
	goto	u6951
	goto	u6950
u6951:
	goto	l4653
u6950:
	
l4651:	
		movlw	2
	xorwf	((CCCV_Control@s)),w
	btfss	status,2
	goto	u6961
	goto	u6960
u6961:
	goto	l873
u6960:
	line	1548
	
l4653:	
;charge_mgr.c: 1548: preCount++;
	incf	(CCCV_Control@preCount),f
	line	1549
	
l873:	
	line	1530
	incf	(CCCV_Control@i),f
	
l4655:	
	movlw	low(0Ch)
	subwf	(CCCV_Control@i),w
	skipc
	goto	u6971
	goto	u6970
u6971:
	goto	l4623
u6970:
	line	1553
	
l4657:	
;charge_mgr.c: 1549: }
;charge_mgr.c: 1550: }
;charge_mgr.c: 1553: if(!hasCharging)
	movf	((CCCV_Control@hasCharging)),w
	btfss	status,2
	goto	u6981
	goto	u6980
u6981:
	goto	l4663
u6980:
	goto	l4613
	line	1564
	
l4663:	
;charge_mgr.c: 1558: }
;charge_mgr.c: 1564: if(cvCount == 0)
	movf	((CCCV_Control@cvCount)),w
	btfss	status,2
	goto	u6991
	goto	u6990
u6991:
	goto	l4693
u6990:
	line	1568
	
l4665:	
;charge_mgr.c: 1565: {
;charge_mgr.c: 1566: unsigned char duty_target, duty_initial;
;charge_mgr.c: 1568: if(ccCount > 0)
	movf	((CCCV_Control@ccCount)),w
	btfsc	status,2
	goto	u7001
	goto	u7000
u7001:
	goto	l4669
u7000:
	line	1571
	
l4667:	
;charge_mgr.c: 1569: {
;charge_mgr.c: 1571: duty_target = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_target)
	line	1572
;charge_mgr.c: 1572: duty_initial = 25;
	movlw	low(019h)
	movwf	(CCCV_Control@duty_initial)
	line	1573
;charge_mgr.c: 1573: }
	goto	l4677
	line	1574
	
l4669:	
;charge_mgr.c: 1574: else if(preCount > 0)
	movf	((CCCV_Control@preCount)),w
	btfsc	status,2
	goto	u7011
	goto	u7010
u7011:
	goto	l4673
u7010:
	line	1577
	
l4671:	
;charge_mgr.c: 1575: {
;charge_mgr.c: 1577: duty_target = 8;
	movlw	low(08h)
	movwf	(CCCV_Control@duty_target)
	line	1578
;charge_mgr.c: 1578: duty_initial = 5;
	movlw	low(05h)
	movwf	(CCCV_Control@duty_initial)
	line	1579
;charge_mgr.c: 1579: }
	goto	l4677
	line	1584
	
l4673:	
;charge_mgr.c: 1580: else
;charge_mgr.c: 1581: {
;charge_mgr.c: 1584: g_pwmDuty = 25;
	movlw	low(019h)
	movwf	(_g_pwmDuty)	;volatile
	goto	l870
	line	1588
	
l4677:	
;charge_mgr.c: 1586: }
;charge_mgr.c: 1588: if(g_pwmDuty < duty_initial)
	movf	(CCCV_Control@duty_initial),w
	subwf	(_g_pwmDuty),w	;volatile
	skipnc
	goto	u7021
	goto	u7020
u7021:
	goto	l4685
u7020:
	line	1591
	
l4679:	
;charge_mgr.c: 1589: {
;charge_mgr.c: 1591: g_pwmDuty += 3;
	movlw	low(03h)
	addwf	(_g_pwmDuty),f	;volatile
	line	1592
	
l4681:	
;charge_mgr.c: 1592: if(g_pwmDuty > duty_initial)
	movf	(_g_pwmDuty),w	;volatile
	subwf	(CCCV_Control@duty_initial),w
	skipnc
	goto	u7031
	goto	u7030
u7031:
	goto	l870
u7030:
	line	1593
	
l4683:	
;charge_mgr.c: 1593: g_pwmDuty = duty_initial;
	movf	(CCCV_Control@duty_initial),w
	movwf	(_g_pwmDuty)	;volatile
	goto	l870
	line	1595
	
l4685:	
	line	1598
	
l4687:	
;charge_mgr.c: 1596: {
;charge_mgr.c: 1598: g_pwmDuty = duty_target;
	movf	(CCCV_Control@duty_target),w
	movwf	(_g_pwmDuty)	;volatile
	line	1599
;charge_mgr.c: 1599: }
	goto	l870
	line	1614
	
l4693:	
;charge_mgr.c: 1606: }
;charge_mgr.c: 1613: {
;charge_mgr.c: 1614: int error = (int)(3100) - (int)(maxV);
	movlw	01Ch
	movwf	(CCCV_Control@error)
	movlw	0Ch
	movwf	((CCCV_Control@error))+1
	movf	(CCCV_Control@maxV),w
	subwf	(CCCV_Control@error),f
	movf	(CCCV_Control@maxV+1),w
	skipc
	decf	(CCCV_Control@error+1),f
	subwf	(CCCV_Control@error+1),f
	line	1617
;charge_mgr.c: 1617: g_cvIntegral += error * 1;
	movf	(CCCV_Control@error),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral)^080h,f
	skipnc
	incf	(_g_cvIntegral+1)^080h,f
	bcf	status, 5	;RP0=0, select bank0
	movf	(CCCV_Control@error+1),w
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_g_cvIntegral+1)^080h,f
	line	1618
	
l4695:	
;charge_mgr.c: 1618: if(g_cvIntegral > 200)
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u7045
	movlw	0C9h
	subwf	(_g_cvIntegral)^080h,w
u7045:

	skipc
	goto	u7041
	goto	u7040
u7041:
	goto	l4699
u7040:
	line	1619
	
l4697:	
;charge_mgr.c: 1619: g_cvIntegral = 200;
	movlw	0C8h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	clrf	(_g_cvIntegral+1)^080h
	goto	l4703
	line	1620
	
l4699:	
;charge_mgr.c: 1620: else if(g_cvIntegral < -200)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(_g_cvIntegral+1)^080h,w
	xorlw	80h
	movwf	btemp+1
	movlw	(0FFh)^80h
	subwf	btemp+1,w
	skipz
	goto	u7055
	movlw	038h
	subwf	(_g_cvIntegral)^080h,w
u7055:

	skipnc
	goto	u7051
	goto	u7050
u7051:
	goto	l4703
u7050:
	line	1621
	
l4701:	
;charge_mgr.c: 1621: g_cvIntegral = -200;
	movlw	038h
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(_g_cvIntegral)^080h
	movlw	0FFh
	movwf	((_g_cvIntegral)^080h)+1
	line	1624
	
l4703:	
;charge_mgr.c: 1624: int adjust = (error * 4 + g_cvIntegral) / 8;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(CCCV_Control@error+1),w
	movwf	(??_CCCV_Control+0)+0+1
	movf	(CCCV_Control@error),w
	movwf	(??_CCCV_Control+0)+0
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	clrc
	rlf	(??_CCCV_Control+0)+0,f
	rlf	(??_CCCV_Control+0)+1,f
	movf	0+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend)
	movf	1+(??_CCCV_Control+0)+0,w
	movwf	(___awdiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_cvIntegral)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___awdiv@dividend),f
	skipnc
	incf	(___awdiv@dividend+1),f
	bsf	status, 5	;RP0=1, select bank1
	movf	(_g_cvIntegral+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	addwf	(___awdiv@dividend+1),f
	movlw	08h
	movwf	(___awdiv@divisor)
	clrf	(___awdiv@divisor+1)
	fcall	___awdiv
	movf	(1+(?___awdiv)),w
	movwf	(CCCV_Control@adjust+1)
	movf	(0+(?___awdiv)),w
	movwf	(CCCV_Control@adjust)
	line	1625
	
l4705:	
;charge_mgr.c: 1625: int duty = (int)g_pwmDuty + adjust;
	movf	(_g_pwmDuty),w	;volatile
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	
l4707:	
	movf	(CCCV_Control@adjust),w
	addwf	(CCCV_Control@duty),f
	skipnc
	incf	(CCCV_Control@duty+1),f
	movf	(CCCV_Control@adjust+1),w
	addwf	(CCCV_Control@duty+1),f
	line	1628
	
l4709:	
;charge_mgr.c: 1628: if(duty > 32) duty = 32;
	movf	(CCCV_Control@duty+1),w
	xorlw	80h
	movwf	btemp+1
	movlw	(0)^80h
	subwf	btemp+1,w
	skipz
	goto	u7065
	movlw	021h
	subwf	(CCCV_Control@duty),w
u7065:

	skipc
	goto	u7061
	goto	u7060
u7061:
	goto	l4713
u7060:
	
l4711:	
	movlw	020h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1629
	
l4713:	
;charge_mgr.c: 1629: if(duty < 0) duty = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(CCCV_Control@duty+1),7
	goto	u7071
	goto	u7070
u7071:
	goto	l4717
u7070:
	
l4715:	
	clrf	(CCCV_Control@duty)
	clrf	(CCCV_Control@duty+1)
	line	1631
	
l4717:	
;charge_mgr.c: 1631: g_pwmDuty = (unsigned char)duty;
	movf	(CCCV_Control@duty),w
	movwf	(_g_pwmDuty)	;volatile
	line	1633
	
l870:	
	return
	opt stack 0
GLOBAL	__end_of_CCCV_Control
	__end_of_CCCV_Control:
	signat	_CCCV_Control,89
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    0[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    2[BANK0 ] unsigned char 
;;  product         1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       1       0       0       0
;;      Locals:         0       2       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       3       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_System_Init
;;		_Slot_Charge_Ctrl
;;		_CCCV_Control
;;		_Update_LED_Global
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
global __ptext24
__ptext24:	;psect for function ___bmul
psect	text24
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 3
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	movwf	(___bmul@multiplier)
	line	6
	
l3539:	
	clrf	(___bmul@product)
	line	43
	
l3541:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u4421
	goto	u4420
u4421:
	goto	l3545
u4420:
	line	44
	
l3543:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l3545:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l3547:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u4431
	goto	u4430
u4431:
	goto	l3541
u4430:
	line	50
	
l3549:	
	movf	(___bmul@product),w
	line	51
	
l973:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	___awdiv

;; *************** function ___awdiv *****************
;; Defined at:
;;		line 6 in file "D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK0 ] int 
;;  dividend        2    2[BANK0 ] int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    6[BANK0 ] int 
;;  sign            1    5[BANK0 ] unsigned char 
;;  counter         1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       4       0       0       0
;;      Locals:         0       4       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       8       0       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_CCCV_Control
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=1
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
global __ptext25
__ptext25:	;psect for function ___awdiv
psect	text25
	file	"D:\6.software\58.SCMCU_IDE\SCMCU_IDE_V2.00.16\data\sources\common\awdiv.c"
	line	6
	global	__size_of___awdiv
	__size_of___awdiv	equ	__end_of___awdiv-___awdiv
	
___awdiv:	
;incstack = 0
	opt	stack 3
; Regs used in ___awdiv: [wreg+status,2+status,0]
	line	14
	
l3553:	
	clrf	(___awdiv@sign)
	line	15
	
l3555:	
	btfss	(___awdiv@divisor+1),7
	goto	u4441
	goto	u4440
u4441:
	goto	l3561
u4440:
	line	16
	
l3557:	
	comf	(___awdiv@divisor),f
	comf	(___awdiv@divisor+1),f
	incf	(___awdiv@divisor),f
	skipnz
	incf	(___awdiv@divisor+1),f
	line	17
	
l3559:	
	clrf	(___awdiv@sign)
	incf	(___awdiv@sign),f
	line	19
	
l3561:	
	btfss	(___awdiv@dividend+1),7
	goto	u4451
	goto	u4450
u4451:
	goto	l3567
u4450:
	line	20
	
l3563:	
	comf	(___awdiv@dividend),f
	comf	(___awdiv@dividend+1),f
	incf	(___awdiv@dividend),f
	skipnz
	incf	(___awdiv@dividend+1),f
	line	21
	
l3565:	
	movlw	low(01h)
	xorwf	(___awdiv@sign),f
	line	23
	
l3567:	
	clrf	(___awdiv@quotient)
	clrf	(___awdiv@quotient+1)
	line	24
	
l3569:	
	movf	((___awdiv@divisor)),w
iorwf	((___awdiv@divisor+1)),w
	btfsc	status,2
	goto	u4461
	goto	u4460
u4461:
	goto	l3589
u4460:
	line	25
	
l3571:	
	clrf	(___awdiv@counter)
	incf	(___awdiv@counter),f
	line	26
	goto	l3575
	line	27
	
l3573:	
	clrc
	rlf	(___awdiv@divisor),f
	rlf	(___awdiv@divisor+1),f
	line	28
	incf	(___awdiv@counter),f
	line	26
	
l3575:	
	btfss	(___awdiv@divisor+1),(15)&7
	goto	u4471
	goto	u4470
u4471:
	goto	l3573
u4470:
	line	31
	
l3577:	
	clrc
	rlf	(___awdiv@quotient),f
	rlf	(___awdiv@quotient+1),f
	line	32
	
l3579:	
	movf	(___awdiv@divisor+1),w
	subwf	(___awdiv@dividend+1),w
	skipz
	goto	u4485
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),w
u4485:
	skipc
	goto	u4481
	goto	u4480
u4481:
	goto	l3585
u4480:
	line	33
	
l3581:	
	movf	(___awdiv@divisor),w
	subwf	(___awdiv@dividend),f
	movf	(___awdiv@divisor+1),w
	skipc
	decf	(___awdiv@dividend+1),f
	subwf	(___awdiv@dividend+1),f
	line	34
	
l3583:	
	bsf	(___awdiv@quotient)+(0/8),(0)&7
	line	36
	
l3585:	
	clrc
	rrf	(___awdiv@divisor+1),f
	rrf	(___awdiv@divisor),f
	line	37
	
l3587:	
	decfsz	(___awdiv@counter),f
	goto	u4491
	goto	u4490
u4491:
	goto	l3577
u4490:
	line	39
	
l3589:	
	movf	((___awdiv@sign)),w
	btfsc	status,2
	goto	u4501
	goto	u4500
u4501:
	goto	l3593
u4500:
	line	40
	
l3591:	
	comf	(___awdiv@quotient),f
	comf	(___awdiv@quotient+1),f
	incf	(___awdiv@quotient),f
	skipnz
	incf	(___awdiv@quotient+1),f
	line	41
	
l3593:	
	movf	(___awdiv@quotient+1),w
	movwf	(?___awdiv+1)
	movf	(___awdiv@quotient),w
	movwf	(?___awdiv)
	line	42
	
l1085:	
	return
	opt stack 0
GLOBAL	__end_of___awdiv
	__end_of___awdiv:
	signat	___awdiv,8314
	global	_Isr_Timer

;; *************** function _Isr_Timer *****************
;; Defined at:
;;		line 228 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          3       0       0       0       0
;;      Totals:         3       0       0       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		_PowerOnLedSequence
;;		_Sink_Set
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	228
global __ptext26
__ptext26:	;psect for function _Isr_Timer
psect	text26
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	228
	global	__size_of_Isr_Timer
	__size_of_Isr_Timer	equ	__end_of_Isr_Timer-_Isr_Timer
	
_Isr_Timer:	
;incstack = 0
	opt	stack 1
; Regs used in _Isr_Timer: [wreg-fsr0h+status,2+status,0+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Isr_Timer+0)
	movf	fsr0,w
	movwf	(??_Isr_Timer+1)
	movf	pclath,w
	movwf	(??_Isr_Timer+2)
	ljmp	_Isr_Timer
psect	text26
	line	231
	
i1l4897:	
;main.c: 231: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u748_21
	goto	u748_20
u748_21:
	goto	i1l395
u748_20:
	line	233
	
i1l4899:	
;main.c: 232: {
;main.c: 233: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	234
	
i1l4901:	
;main.c: 234: TMR0 = 6;
	movlw	low(06h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(129)^080h	;volatile
	line	235
# 235 "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
clrwdt ;# 
psect	text26
	line	238
	
i1l4903:	
;main.c: 238: g_pwmCounter++;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	incf	(_g_pwmCounter)^080h,f	;volatile
	line	239
	
i1l4905:	
;main.c: 239: if(g_pwmCounter >= 32)
	movlw	low(020h)
	subwf	(_g_pwmCounter)^080h,w	;volatile
	skipc
	goto	u749_21
	goto	u749_20
u749_21:
	goto	i1l4909
u749_20:
	line	240
	
i1l4907:	
;main.c: 240: g_pwmCounter = 0;
	clrf	(_g_pwmCounter)^080h	;volatile
	line	242
	
i1l4909:	
;main.c: 242: if(g_pwmDuty > 0 && g_pwmCounter < g_pwmDuty)
	movf	((_g_pwmDuty)),w	;volatile
	btfsc	status,2
	goto	u750_21
	goto	u750_20
u750_21:
	goto	i1l390
u750_20:
	
i1l4911:	
	movf	(_g_pwmDuty),w	;volatile
	subwf	(_g_pwmCounter)^080h,w	;volatile
	skipnc
	goto	u751_21
	goto	u751_20
u751_21:
	goto	i1l390
u751_20:
	line	243
	
i1l4913:	
;main.c: 243: RB7 = 1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(55/8),(55)&7	;volatile
	goto	i1l4915
	line	244
	
i1l390:	
	line	245
;main.c: 244: else
;main.c: 245: RB7 = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(55/8),(55)&7	;volatile
	line	251
	
i1l4915:	
;main.c: 251: if(++g_hwTickDiv >= 80U)
	movlw	low(050h)
	bsf	status, 5	;RP0=1, select bank1
	incf	(_g_hwTickDiv)^080h,f	;volatile
	subwf	((_g_hwTickDiv)^080h),w	;volatile
	skipc
	goto	u752_21
	goto	u752_20
u752_21:
	goto	i1l4925
u752_20:
	line	253
	
i1l4917:	
;main.c: 252: {
;main.c: 253: g_hwTickDiv = 0;
	clrf	(_g_hwTickDiv)^080h	;volatile
	line	254
	
i1l4919:	
;main.c: 254: g_hwTick++;
	incf	(_g_hwTick)^080h,f	;volatile
	skipnz
	incf	(_g_hwTick+1)^080h,f	;volatile
	line	255
	
i1l4921:	
;main.c: 255: if(g_powerOnPhase < 2U)
	movlw	low(02h)
	subwf	(_g_powerOnPhase)^080h,w
	skipnc
	goto	u753_21
	goto	u753_20
u753_21:
	goto	i1l4925
u753_20:
	line	256
	
i1l4923:	
;main.c: 256: g_powerOnTimer++;
	incf	(_g_powerOnTimer)^080h,f	;volatile
	skipnz
	incf	(_g_powerOnTimer+1)^080h,f	;volatile
	line	270
	
i1l4925:	
;main.c: 264: }
;main.c: 270: if(g_powerOnPhase < 2)
	movlw	low(02h)
	subwf	(_g_powerOnPhase)^080h,w	;volatile
	skipnc
	goto	u754_21
	goto	u754_20
u754_21:
	goto	i1l4931
u754_20:
	line	272
	
i1l4927:	
;main.c: 271: {
;main.c: 272: PowerOnLedSequence();
	fcall	_PowerOnLedSequence
	goto	i1l395
	line	273
	
i1l4929:	
;main.c: 273: return;
	goto	i1l395
	line	277
	
i1l4931:	
;main.c: 274: }
;main.c: 277: if(g_tempPhase == 0)
	movf	((_g_tempPhase)^080h),w	;volatile
	btfss	status,2
	goto	u755_21
	goto	u755_20
u755_21:
	goto	i1l4943
u755_20:
	line	279
	
i1l4933:	
;main.c: 278: {
;main.c: 279: g_tempReadRoundCnt++;
	incf	(_g_tempReadRoundCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempReadRoundCnt+1)^080h,f	;volatile
	line	280
	
i1l4935:	
;main.c: 280: if(g_tempReadRoundCnt >= 200)
	movlw	0
	subwf	(_g_tempReadRoundCnt+1)^080h,w	;volatile
	movlw	0C8h
	skipnz
	subwf	(_g_tempReadRoundCnt)^080h,w	;volatile
	skipc
	goto	u756_21
	goto	u756_20
u756_21:
	goto	i1l4951
u756_20:
	line	282
	
i1l4937:	
;main.c: 281: {
;main.c: 282: g_tempReadRoundCnt = 0;
	clrf	(_g_tempReadRoundCnt)^080h	;volatile
	clrf	(_g_tempReadRoundCnt+1)^080h	;volatile
	line	283
	
i1l4939:	
;main.c: 283: g_tempPhase = 1;
	movlw	low(01h)
	movwf	(_g_tempPhase)^080h	;volatile
	line	284
	
i1l4941:	
;main.c: 284: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	goto	i1l4951
	line	289
	
i1l4943:	
;main.c: 287: else
;main.c: 288: {
;main.c: 289: g_tempSettleCnt++;
	incf	(_g_tempSettleCnt)^080h,f	;volatile
	skipnz
	incf	(_g_tempSettleCnt+1)^080h,f	;volatile
	line	290
	
i1l4945:	
;main.c: 290: if(g_tempSettleCnt >= 60)
	movlw	0
	subwf	(_g_tempSettleCnt+1)^080h,w	;volatile
	movlw	03Ch
	skipnz
	subwf	(_g_tempSettleCnt)^080h,w	;volatile
	skipc
	goto	u757_21
	goto	u757_20
u757_21:
	goto	i1l4951
u757_20:
	line	292
	
i1l4947:	
;main.c: 291: {
;main.c: 292: g_doNtcRead = 1;
	bsf	(_g_doNtcRead/8),(_g_doNtcRead)&7	;volatile
	line	293
	
i1l4949:	
;main.c: 293: g_tempSettleCnt = 0;
	clrf	(_g_tempSettleCnt)^080h	;volatile
	clrf	(_g_tempSettleCnt+1)^080h	;volatile
	line	294
;main.c: 294: g_tempPhase = 0;
	clrf	(_g_tempPhase)^080h	;volatile
	line	308
	
i1l4951:	
;main.c: 295: }
;main.c: 296: }
;main.c: 308: if(g_pwmCounter == 28)
		movlw	28
	xorwf	((_g_pwmCounter)^080h),w	;volatile
	btfss	status,2
	goto	u758_21
	goto	u758_20
u758_21:
	goto	i1l4961
u758_20:
	line	310
	
i1l4953:	
;main.c: 309: {
;main.c: 310: if(!g_adcBusy && g_sinkMask != 0U)
	btfsc	(_g_adcBusy/8),(_g_adcBusy)&7	;volatile
	goto	u759_21
	goto	u759_20
u759_21:
	goto	i1l395
u759_20:
	
i1l4955:	
	movf	((_g_sinkMask)^080h),w	;volatile
iorwf	((_g_sinkMask+1)^080h),w	;volatile
	btfsc	status,2
	goto	u760_21
	goto	u760_20
u760_21:
	goto	i1l395
u760_20:
	line	312
	
i1l4957:	
;main.c: 311: {
;main.c: 312: Sink_Set(g_sinkMask, 1);
	movf	(_g_sinkMask+1)^080h,w	;volatile
	movwf	(Sink_Set@mask+1)
	movf	(_g_sinkMask)^080h,w	;volatile
	movwf	(Sink_Set@mask)
	clrf	(Sink_Set@on)
	incf	(Sink_Set@on),f
	fcall	_Sink_Set
	line	313
	
i1l4959:	
;main.c: 313: g_dispWin = 1;
	bsf	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	goto	i1l395
	line	316
	
i1l4961:	
;main.c: 316: else if(g_pwmCounter == 0U)
	movf	((_g_pwmCounter)^080h),w
	btfss	status,2
	goto	u761_21
	goto	u761_20
u761_21:
	goto	i1l395
u761_20:
	line	318
	
i1l4963:	
;main.c: 317: {
;main.c: 318: if(g_dispWin)
	btfss	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	goto	u762_21
	goto	u762_20
u762_21:
	goto	i1l4929
u762_20:
	line	322
	
i1l4965:	
;main.c: 319: {
;main.c: 322: Sink_Set((unsigned int)0x0FFFU, 0);
	movlw	0FFh
	movwf	(Sink_Set@mask)
	movlw	0Fh
	movwf	((Sink_Set@mask))+1
	clrf	(Sink_Set@on)
	fcall	_Sink_Set
	line	323
	
i1l4967:	
;main.c: 323: g_dispWin = 0;
	bcf	(_g_dispWin/8),(_g_dispWin)&7	;volatile
	line	327
	
i1l395:	
	movf	(??_Isr_Timer+2),w
	movwf	pclath
	movf	(??_Isr_Timer+1),w
	movwf	fsr0
	swapf	(??_Isr_Timer+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Isr_Timer
	__end_of_Isr_Timer:
	signat	_Isr_Timer,89
	global	_Sink_Set

;; *************** function _Sink_Set *****************
;; Defined at:
;;		line 202 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;  mask            2    1[COMMON] unsigned int 
;;  on              1    3[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  i               1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         3       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         4       0       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    1
;; This function calls:
;;		_Sink_Slot_Off
;;		_Sink_Slot_On
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=0
	line	202
global __ptext27
__ptext27:	;psect for function _Sink_Set
psect	text27
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	202
	global	__size_of_Sink_Set
	__size_of_Sink_Set	equ	__end_of_Sink_Set-_Sink_Set
	
_Sink_Set:	
;incstack = 0
	opt	stack 1
; Regs used in _Sink_Set: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	205
	
i1l3673:	
;main.c: 204: unsigned char i;
;main.c: 205: for(i = 0; i < 12; i++)
	clrf	(Sink_Set@i)
	line	206
	
i1l378:	
	line	207
;main.c: 206: {
;main.c: 207: if(mask & 1U)
	btfss	(Sink_Set@mask),(0)&7
	goto	u452_21
	goto	u452_20
u452_21:
	goto	i1l3685
u452_20:
	line	209
	
i1l3679:	
;main.c: 208: {
;main.c: 209: if(on)
	movf	((Sink_Set@on)),w
	btfsc	status,2
	goto	u453_21
	goto	u453_20
u453_21:
	goto	i1l3683
u453_20:
	line	210
	
i1l3681:	
;main.c: 210: Sink_Slot_On(i);
	movf	(Sink_Set@i),w
	fcall	_Sink_Slot_On
	goto	i1l3685
	line	212
	
i1l3683:	
;main.c: 211: else
;main.c: 212: Sink_Slot_Off(i);
	movf	(Sink_Set@i),w
	fcall	_Sink_Slot_Off
	line	214
	
i1l3685:	
;main.c: 213: }
;main.c: 214: mask >>= 1;
	clrc
	rrf	(Sink_Set@mask+1),f
	rrf	(Sink_Set@mask),f
	line	205
	
i1l3687:	
	incf	(Sink_Set@i),f
	
i1l3689:	
	movlw	low(0Ch)
	subwf	(Sink_Set@i),w
	skipc
	goto	u454_21
	goto	u454_20
u454_21:
	goto	i1l378
u454_20:
	line	216
	
i1l383:	
	return
	opt stack 0
GLOBAL	__end_of_Sink_Set
	__end_of_Sink_Set:
	signat	_Sink_Set,8313
	global	_Sink_Slot_On

;; *************** function _Sink_Slot_On *****************
;; Defined at:
;;		line 161 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    0[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 0/100
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         1       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Sink_Set
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=0
	line	161
global __ptext28
__ptext28:	;psect for function _Sink_Slot_On
psect	text28
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	161
	global	__size_of_Sink_Slot_On
	__size_of_Sink_Slot_On	equ	__end_of_Sink_Slot_On-_Sink_Slot_On
	
_Sink_Slot_On:	
;incstack = 0
	opt	stack 1
; Regs used in _Sink_Slot_On: [wreg-fsr0h+status,2+status,0]
;Sink_Slot_On@idx stored from wreg
	movwf	(Sink_Slot_On@idx)
	line	163
	
i1l3363:	
;main.c: 163: switch(idx)
	goto	i1l3367
	line	165
;main.c: 164: {
;main.c: 165: case 0: ANSEL2 &= 0xFD; TRISC &= 0xFD; RC1 = 0; break;
	
i1l343:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(265)^0100h+(1/8),(1)&7	;volatile
	bcf	(261)^0100h+(1/8),(1)&7	;volatile
	bcf	(2097/8)^0100h,(2097)&7	;volatile
	goto	i1l357
	line	166
;main.c: 166: case 1: ANSEL2 &= 0xFE; TRISC &= 0xFE; RC0 = 0; break;
	
i1l345:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(265)^0100h+(0/8),(0)&7	;volatile
	bcf	(261)^0100h+(0/8),(0)&7	;volatile
	bcf	(2096/8)^0100h,(2096)&7	;volatile
	goto	i1l357
	line	167
;main.c: 167: case 2: ANSEL1 &= 0xEF; TRISB &= 0xEF; RB4 = 0; break;
	
i1l346:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(148)^080h+(4/8),(4)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	(5)+(4/8),(4)&7	;volatile
	bcf	(52/8),(52)&7	;volatile
	goto	i1l357
	line	168
;main.c: 168: case 3: ANSEL1 &= 0xDF; TRISB &= 0xDF; RB5 = 0; break;
	
i1l347:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(148)^080h+(5/8),(5)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	(5)+(5/8),(5)&7	;volatile
	bcf	(53/8),(53)&7	;volatile
	goto	i1l357
	line	169
;main.c: 169: case 4: ANSEL0 &= 0xDF; TRISA &= 0xDF; RA5 = 0; break;
	
i1l348:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(147)^080h+(5/8),(5)&7	;volatile
	bcf	(133)^080h+(5/8),(5)&7	;volatile
	bcf	(1077/8)^080h,(1077)&7	;volatile
	goto	i1l357
	line	170
;main.c: 170: case 5: ANSEL0 &= 0xEF; TRISA &= 0xEF; RA4 = 0; break;
	
i1l349:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(147)^080h+(4/8),(4)&7	;volatile
	bcf	(133)^080h+(4/8),(4)&7	;volatile
	bcf	(1076/8)^080h,(1076)&7	;volatile
	goto	i1l357
	line	171
;main.c: 171: case 6: ANSEL3 &= 0xEF; TRISD &= 0xEF; RD4 = 0; break;
	
i1l350:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(140)^080h+(4/8),(4)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(276)^0100h+(4/8),(4)&7	;volatile
	bcf	(2108/8)^0100h,(2108)&7	;volatile
	goto	i1l357
	line	172
;main.c: 172: case 7: ANSEL3 &= 0xDF; TRISD &= 0xDF; RD5 = 0; break;
	
i1l351:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(140)^080h+(5/8),(5)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(276)^0100h+(5/8),(5)&7	;volatile
	bcf	(2109/8)^0100h,(2109)&7	;volatile
	goto	i1l357
	line	173
;main.c: 173: case 8: ANSEL3 &= 0xF7; TRISD &= 0xF7; RD3 = 0; break;
	
i1l352:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(140)^080h+(3/8),(3)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(276)^0100h+(3/8),(3)&7	;volatile
	bcf	(2107/8)^0100h,(2107)&7	;volatile
	goto	i1l357
	line	174
;main.c: 174: case 9: ANSEL3 &= 0xFB; TRISD &= 0xFB; RD2 = 0; break;
	
i1l353:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(140)^080h+(2/8),(2)&7	;volatile
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(276)^0100h+(2/8),(2)&7	;volatile
	bcf	(2106/8)^0100h,(2106)&7	;volatile
	goto	i1l357
	line	175
;main.c: 175: case 10: ANSEL0 &= 0x7F; TRISA &= 0x7F; RA7 = 0; break;
	
i1l354:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(147)^080h+(7/8),(7)&7	;volatile
	bcf	(133)^080h+(7/8),(7)&7	;volatile
	bcf	(1079/8)^080h,(1079)&7	;volatile
	goto	i1l357
	line	176
;main.c: 176: case 11: ANSEL0 &= 0xBF; TRISA &= 0xBF; RA6 = 0; break;
	
i1l355:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(147)^080h+(6/8),(6)&7	;volatile
	bcf	(133)^080h+(6/8),(6)&7	;volatile
	bcf	(1078/8)^080h,(1078)&7	;volatile
	goto	i1l357
	line	163
	
i1l3367:	
	movf	(Sink_Slot_On@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l343
	xorlw	1^0	; case 1
	skipnz
	goto	i1l345
	xorlw	2^1	; case 2
	skipnz
	goto	i1l346
	xorlw	3^2	; case 3
	skipnz
	goto	i1l347
	xorlw	4^3	; case 4
	skipnz
	goto	i1l348
	xorlw	5^4	; case 5
	skipnz
	goto	i1l349
	xorlw	6^5	; case 6
	skipnz
	goto	i1l350
	xorlw	7^6	; case 7
	skipnz
	goto	i1l351
	xorlw	8^7	; case 8
	skipnz
	goto	i1l352
	xorlw	9^8	; case 9
	skipnz
	goto	i1l353
	xorlw	10^9	; case 10
	skipnz
	goto	i1l354
	xorlw	11^10	; case 11
	skipnz
	goto	i1l355
	goto	i1l357
	opt asmopt_pop

	line	179
	
i1l357:	
	return
	opt stack 0
GLOBAL	__end_of_Sink_Slot_On
	__end_of_Sink_Slot_On:
	signat	_Sink_Slot_On,4217
	global	_Sink_Slot_Off

;; *************** function _Sink_Slot_Off *****************
;; Defined at:
;;		line 181 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
;; Parameters:    Size  Location     Type
;;  idx             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  idx             1    0[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 0/100
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         1       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         1       0       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Sink_Set
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=0
	line	181
global __ptext29
__ptext29:	;psect for function _Sink_Slot_Off
psect	text29
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\main.c"
	line	181
	global	__size_of_Sink_Slot_Off
	__size_of_Sink_Slot_Off	equ	__end_of_Sink_Slot_Off-_Sink_Slot_Off
	
_Sink_Slot_Off:	
;incstack = 0
	opt	stack 1
; Regs used in _Sink_Slot_Off: [wreg-fsr0h+status,2+status,0]
;Sink_Slot_Off@idx stored from wreg
	movwf	(Sink_Slot_Off@idx)
	line	183
	
i1l3369:	
;main.c: 183: switch(idx)
	goto	i1l3373
	line	185
;main.c: 184: {
;main.c: 185: case 0: TRISC |= 0x02; ANSEL2 |= 0x02; break;
	
i1l361:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(261)^0100h+(1/8),(1)&7	;volatile
	bsf	(265)^0100h+(1/8),(1)&7	;volatile
	goto	i1l375
	line	186
;main.c: 186: case 1: TRISC |= 0x01; ANSEL2 |= 0x01; break;
	
i1l363:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(261)^0100h+(0/8),(0)&7	;volatile
	bsf	(265)^0100h+(0/8),(0)&7	;volatile
	goto	i1l375
	line	187
;main.c: 187: case 2: TRISB |= 0x10; ANSEL1 |= 0x10; break;
	
i1l364:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(5)+(4/8),(4)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(148)^080h+(4/8),(4)&7	;volatile
	goto	i1l375
	line	188
;main.c: 188: case 3: TRISB |= 0x20; ANSEL1 |= 0x20; break;
	
i1l365:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	bsf	(5)+(5/8),(5)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bsf	(148)^080h+(5/8),(5)&7	;volatile
	goto	i1l375
	line	189
;main.c: 189: case 4: TRISA |= 0x20; ANSEL0 |= 0x20; break;
	
i1l366:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(133)^080h+(5/8),(5)&7	;volatile
	bsf	(147)^080h+(5/8),(5)&7	;volatile
	goto	i1l375
	line	190
;main.c: 190: case 5: TRISA |= 0x10; ANSEL0 |= 0x10; break;
	
i1l367:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(133)^080h+(4/8),(4)&7	;volatile
	bsf	(147)^080h+(4/8),(4)&7	;volatile
	goto	i1l375
	line	191
;main.c: 191: case 6: TRISD |= 0x10; ANSEL3 |= 0x10; break;
	
i1l368:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(276)^0100h+(4/8),(4)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(140)^080h+(4/8),(4)&7	;volatile
	goto	i1l375
	line	192
;main.c: 192: case 7: TRISD |= 0x20; ANSEL3 |= 0x20; break;
	
i1l369:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(276)^0100h+(5/8),(5)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(140)^080h+(5/8),(5)&7	;volatile
	goto	i1l375
	line	193
;main.c: 193: case 8: TRISD |= 0x08; ANSEL3 |= 0x08; break;
	
i1l370:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(276)^0100h+(3/8),(3)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(140)^080h+(3/8),(3)&7	;volatile
	goto	i1l375
	line	194
;main.c: 194: case 9: TRISD |= 0x04; ANSEL3 |= 0x04; break;
	
i1l371:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(276)^0100h+(2/8),(2)&7	;volatile
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(140)^080h+(2/8),(2)&7	;volatile
	goto	i1l375
	line	195
;main.c: 195: case 10: TRISA |= 0x80; ANSEL0 |= 0x80; break;
	
i1l372:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(133)^080h+(7/8),(7)&7	;volatile
	bsf	(147)^080h+(7/8),(7)&7	;volatile
	goto	i1l375
	line	196
;main.c: 196: case 11: TRISA |= 0x40; ANSEL0 |= 0x40; break;
	
i1l373:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(133)^080h+(6/8),(6)&7	;volatile
	bsf	(147)^080h+(6/8),(6)&7	;volatile
	goto	i1l375
	line	183
	
i1l3373:	
	movf	(Sink_Slot_Off@idx),w
	; Switch size 1, requested type "space"
; Number of cases is 12, Range of values is 0 to 11
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           37    19 (average)
; direct_byte           44     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	i1l361
	xorlw	1^0	; case 1
	skipnz
	goto	i1l363
	xorlw	2^1	; case 2
	skipnz
	goto	i1l364
	xorlw	3^2	; case 3
	skipnz
	goto	i1l365
	xorlw	4^3	; case 4
	skipnz
	goto	i1l366
	xorlw	5^4	; case 5
	skipnz
	goto	i1l367
	xorlw	6^5	; case 6
	skipnz
	goto	i1l368
	xorlw	7^6	; case 7
	skipnz
	goto	i1l369
	xorlw	8^7	; case 8
	skipnz
	goto	i1l370
	xorlw	9^8	; case 9
	skipnz
	goto	i1l371
	xorlw	10^9	; case 10
	skipnz
	goto	i1l372
	xorlw	11^10	; case 11
	skipnz
	goto	i1l373
	goto	i1l375
	opt asmopt_pop

	line	199
	
i1l375:	
	return
	opt stack 0
GLOBAL	__end_of_Sink_Slot_Off
	__end_of_Sink_Slot_Off:
	signat	_Sink_Slot_Off,4217
	global	_PowerOnLedSequence

;; *************** function _PowerOnLedSequence *****************
;; Defined at:
;;		line 200 in file "E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK3   BANK2
;;      Params:         0       0       0       0       0
;;      Locals:         0       0       0       0       0
;;      Temps:          0       0       0       0       0
;;      Totals:         0       0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Isr_Timer
;; This function uses a non-reentrant model
;;
psect	text30,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	200
global __ptext30
__ptext30:	;psect for function _PowerOnLedSequence
psect	text30
	file	"E:\1.workspace\7.other\17.charge_demo\charge_demo\06-release\SC8F096_Timer_Demo\led.c"
	line	200
	global	__size_of_PowerOnLedSequence
	__size_of_PowerOnLedSequence	equ	__end_of_PowerOnLedSequence-_PowerOnLedSequence
	
_PowerOnLedSequence:	
;incstack = 0
	opt	stack 2
; Regs used in _PowerOnLedSequence: [wreg+status,2+status,0]
	line	204
	
i1l3691:	
;led.c: 204: if(g_powerOnPhase == 0)
	movf	((_g_powerOnPhase)^080h),w	;volatile
	btfss	status,2
	goto	u455_21
	goto	u455_20
u455_21:
	goto	i1l3701
u455_20:
	line	207
	
i1l3693:	
;led.c: 205: {
;led.c: 207: RC4 = 1;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2100/8)^0100h,(2100)&7	;volatile
	line	208
;led.c: 208: RC5 = 0;
	bcf	(2101/8)^0100h,(2101)&7	;volatile
	line	209
	
i1l3695:	
;led.c: 209: if(g_powerOnTimer >= 100)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u456_21
	goto	u456_20
u456_21:
	goto	i1l949
u456_20:
	line	211
	
i1l3697:	
;led.c: 210: {
;led.c: 211: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)^080h	;volatile
	clrf	(_g_powerOnTimer+1)^080h	;volatile
	line	212
	
i1l3699:	
;led.c: 212: g_powerOnPhase = 1;
	movlw	low(01h)
	movwf	(_g_powerOnPhase)^080h	;volatile
	goto	i1l949
	line	215
	
i1l3701:	
;led.c: 215: else if(g_powerOnPhase == 1)
		decf	((_g_powerOnPhase)^080h),w	;volatile
	btfss	status,2
	goto	u457_21
	goto	u457_20
u457_21:
	goto	i1l949
u457_20:
	line	218
	
i1l3703:	
;led.c: 216: {
;led.c: 218: RC4 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2100/8)^0100h,(2100)&7	;volatile
	line	219
;led.c: 219: RC5 = 1;
	bsf	(2101/8)^0100h,(2101)&7	;volatile
	line	220
	
i1l3705:	
;led.c: 220: if(g_powerOnTimer >= 100)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	subwf	(_g_powerOnTimer+1)^080h,w	;volatile
	movlw	064h
	skipnz
	subwf	(_g_powerOnTimer)^080h,w	;volatile
	skipc
	goto	u458_21
	goto	u458_20
u458_21:
	goto	i1l949
u458_20:
	line	222
	
i1l3707:	
;led.c: 221: {
;led.c: 222: g_powerOnTimer = 0;
	clrf	(_g_powerOnTimer)^080h	;volatile
	clrf	(_g_powerOnTimer+1)^080h	;volatile
	line	223
	
i1l3709:	
;led.c: 223: g_powerOnPhase = 2;
	movlw	low(02h)
	movwf	(_g_powerOnPhase)^080h	;volatile
	line	227
	
i1l949:	
	return
	opt stack 0
GLOBAL	__end_of_PowerOnLedSequence
	__end_of_PowerOnLedSequence:
	signat	_PowerOnLedSequence,89
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end
